"""
Rényi 差分隐私 (Rényi Differential Privacy, RDP)

Rényi 差分隐私是一种基于 Rényi 散度的差分隐私变体，
它提供了比传统 (ε, δ)-差分隐私更紧致的组合性质。

数学原理:
    Rényi 散度（阶数 α）定义为:
        D_α(P || Q) = (1/(α-1)) * log E_Q[(dP/dQ)^α]
    
    对于 α > 1，机制 M 满足 (α, ε)-RDP 如果:
        D_α(M(D) || M(D')) ≤ ε
    
    对于所有相邻数据集 D 和 D' 成立。

与传统差分隐私的关系:
    - 若机制满足 (α, ε)-RDP，则它满足 (ε + log(1/δ)/(α-1), δ)-DP
    - 若机制满足 (ε, 0)-DP，则它对所有 α > 1 满足 (α, ε²/2)-RDP
    - 若机制满足 (ε, δ)-DP，则它对所有 α > 1 满足 (α, ε + log(1/δ)/(α-1))-RDP

组合性质:
    RDP 的组合是线性的：
        若 M₁ 满足 (α, ε₁)-RDP，M₂ 满足 (α, ε₂)-RDP，
        则组合机制 (M₁, M₂) 满足 (α, ε₁ + ε₂)-RDP。
    
    这使得 RDP 特别适合分析大量查询的组合隐私预算。

常用机制的 RDP 参数:
    1. 高斯机制:
        ε_RDP(α) = α / (2σ²)
    
    2. 随机响应:
        ε_RDP(α) = (1/(α-1)) * log[(1-γ)^α * e^ε + γ^α * e^(-ε(α-1))]
        其中 γ 为翻转概率

优势:
    - 组合计算简单（线性相加）
    - 转换到 (ε, δ)-DP 时通常比高级组合定理更紧
    - 特别适合分析迭代算法（如深度学习中的 SGD）

参考:
    Mironov, I. (2017). Rényi Differential Privacy.
    IEEE 30th Computer Security Foundations Symposium (CSF).
"""

import numpy as np
from typing import List, Tuple, Optional, Dict, Union
import warnings


class RenyiDifferentialPrivacy:
    """
    Rényi 差分隐私类
    
    用于跟踪和管理多个差分隐私机制组合后的 RDP 参数，
    并支持将 RDP 转换为传统的 (ε, δ)-差分隐私。
    
    属性:
        orders (List[float]): Rényi 散度的阶数列表
        rdp_epsilons (Dict[float, float]): 每个阶数对应的 RDP 参数
        
    示例:
        >>> rdp = RenyiDifferentialPrivacy(orders=list(range(2, 100)))
        >>> # 添加高斯机制
        >>> rdp.add_gaussian_mechanism(sigma=1.0, num_compositions=100)
        >>> # 转换为 (ε, δ)-DP
        >>> eps, delta = rdp.get_epsilon_delta(target_delta=1e-5)
        >>> print(f"等效隐私参数: ε={eps:.4f}, δ={delta:.2e}")
    """
    
    def __init__(
        self,
        orders: Optional[List[float]] = None,
        rdp_epsilons: Optional[Dict[float, float]] = None
    ) -> None:
        """
        初始化 Rényi 差分隐私计算器
        
        参数:
            orders (Optional[List[float]]): Rényi 散度的阶数列表
                - 常用值: [1.25, 1.5, 1.75, 2, 3, 4, 5, 10, 20, 50, 100]
                - 若未提供，使用默认列表
            rdp_epsilons (Optional[Dict[float, float]]): 预定义的 RDP 参数
                - 键为阶数 α，值为对应的 ε_RDP(α)
        
        异常:
            ValueError: 当阶数列表为空或包含无效值时抛出
        
        注意:
            阶数的选择影响转换到 (ε, δ)-DP 的紧致性。
            通常需要尝试多个阶数来找到最优转换。
        """
        # 设置默认阶数列表
        if orders is None:
            # 常用阶数列表，覆盖从接近 1 到较大的值
            orders = [
                1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 7, 8, 9, 10,
                12, 14, 16, 18, 20, 25, 30, 40, 50, 60, 80, 100, 200, 500, 1000
            ]
        
        # 验证阶数
        if not orders:
            raise ValueError("阶数列表不能为空")
        
        for alpha in orders:
            if alpha <= 1:
                raise ValueError(
                    f"Rényi 散度阶数必须大于 1，当前值: {alpha}"
                )
        
        self._orders: List[float] = sorted(orders)
        
        # 初始化 RDP 参数
        if rdp_epsilons is not None:
            self._rdp_epsilons: Dict[float, float] = dict(rdp_epsilons)
            # 确保所有阶数都有对应的值
            for alpha in self._orders:
                if alpha not in self._rdp_epsilons:
                    self._rdp_epsilons[alpha] = 0.0
        else:
            self._rdp_epsilons: Dict[float, float] = {
                alpha: 0.0 for alpha in self._orders
            }
        
        # 记录添加的机制
        self._mechanisms: List[Dict[str, any]] = []
    
    @property
    def orders(self) -> List[float]:
        """获取 Rényi 散度的阶数列表"""
        return self._orders.copy()
    
    @property
    def rdp_epsilons(self) -> Dict[float, float]:
        """获取每个阶数对应的 RDP 参数"""
        return self._rdp_epsilons.copy()
    
    def get_rdp_epsilon(self, alpha: float) -> float:
        """
        获取指定阶数的 RDP 参数
        
        参数:
            alpha (float): Rényi 散度阶数
        
        返回:
            float: 对应的 ε_RDP(α)
        
        异常:
            ValueError: 当阶数不在列表中时抛出
        """
        if alpha not in self._rdp_epsilons:
            raise ValueError(f"阶数 {alpha} 不在当前阶数列表中")
        return self._rdp_epsilons[alpha]
    
    def add_rdp(self, alpha: float, epsilon: float) -> None:
        """
        添加 RDP 参数（线性组合）
        
        数学公式:
            ε_total(α) = ε₁(α) + ε₂(α)
        
        参数:
            alpha (float): Rényi 散度阶数
            epsilon (float): 该阶数下的 RDP 参数
        
        异常:
            ValueError: 当 epsilon 为负数时抛出
        """
        if epsilon < 0:
            raise ValueError(f"RDP 参数必须为非负数，当前值: {epsilon}")
        
        if alpha in self._rdp_epsilons:
            self._rdp_epsilons[alpha] += epsilon
        else:
            # 如果阶数不在列表中，添加它
            self._orders.append(alpha)
            self._orders.sort()
            self._rdp_epsilons[alpha] = epsilon
        
        self._mechanisms.append({
            'type': 'rdp',
            'alpha': alpha,
            'epsilon': epsilon
        })
    
    def add_gaussian_mechanism(
        self,
        sigma: float,
        num_compositions: int = 1
    ) -> None:
        """
        添加高斯机制的 RDP 参数
        
        数学公式:
            对于标准差为 σ 的高斯机制，
            ε_RDP(α) = α / (2σ²)
        
        对于 k 次组合:
            ε_RDP(α) = k * α / (2σ²)
        
        参数:
            sigma (float): 高斯噪声的标准差
            num_compositions (int): 组合次数，默认为 1
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> rdp = RenyiDifferentialPrivacy()
            >>> rdp.add_gaussian_mechanism(sigma=1.0, num_compositions=100)
        """
        if sigma <= 0:
            raise ValueError(f"标准差必须为正数，当前值: {sigma}")
        if num_compositions < 0:
            raise ValueError(f"组合次数必须为非负数，当前值: {num_compositions}")
        
        # 计算每个阶数的 RDP 参数
        for alpha in self._orders:
            epsilon = num_compositions * alpha / (2 * sigma ** 2)
            self._rdp_epsilons[alpha] += epsilon
        
        self._mechanisms.append({
            'type': 'gaussian',
            'sigma': sigma,
            'num_compositions': num_compositions
        })
    
    def add_laplace_mechanism(
        self,
        epsilon: float,
        num_compositions: int = 1
    ) -> None:
        """
        添加拉普拉斯机制的 RDP 参数
        
        拉普拉斯机制满足 (ε, 0)-DP，可以转换为 RDP:
            ε_RDP(α) ≤ min{ε, ε² * α / 2}
        
        使用更紧的上界（Balle & Wang, 2018）:
            ε_RDP(α) ≤ log[(1 - 1/(2α)) * e^ε + 1/(2α) * e^(-ε)]
            
        或简化上界:
            ε_RDP(α) ≤ ε² * α / 2  （当 ε 较小时）
        
        参数:
            epsilon (float): 拉普拉斯机制的隐私预算
            num_compositions (int): 组合次数，默认为 1
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> rdp = RenyiDifferentialPrivacy()
            >>> rdp.add_laplace_mechanism(epsilon=0.1, num_compositions=100)
        """
        if epsilon <= 0:
            raise ValueError(f"隐私预算必须为正数，当前值: {epsilon}")
        if num_compositions < 0:
            raise ValueError(f"组合次数必须为非负数，当前值: {num_compositions}")
        
        # 计算每个阶数的 RDP 参数
        for alpha in self._orders:
            # 使用简化上界: ε_RDP(α) ≤ ε² * α / 2
            rdp_epsilon = num_compositions * (epsilon ** 2) * alpha / 2
            self._rdp_epsilons[alpha] += rdp_epsilon
        
        self._mechanisms.append({
            'type': 'laplace',
            'epsilon': epsilon,
            'num_compositions': num_compositions
        })
    
    def add_randomized_response(
        self,
        epsilon: float,
        num_compositions: int = 1
    ) -> None:
        """
        添加随机响应机制的 RDP 参数
        
        数学公式:
            对于隐私参数为 ε 的随机响应机制，
            ε_RDP(α) = (1/(α-1)) * log[(e^ε)^α / (e^ε + 1)^(α-1) + 1 / (e^ε + 1)^(α-1)]
        
        简化计算:
            ε_RDP(α) = (1/(α-1)) * log[(e^(α*ε) + 1) / (e^ε + 1)^(α-1)]
        
        参数:
            epsilon (float): 随机响应的隐私预算
            num_compositions (int): 组合次数，默认为 1
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> rdp = RenyiDifferentialPrivacy()
            >>> rdp.add_randomized_response(epsilon=1.0, num_compositions=50)
        """
        if epsilon <= 0:
            raise ValueError(f"隐私预算必须为正数，当前值: {epsilon}")
        if num_compositions < 0:
            raise ValueError(f"组合次数必须为非负数，当前值: {num_compositions}")
        
        exp_epsilon = np.exp(epsilon)
        
        for alpha in self._orders:
            # 计算 RDP 参数
            # ε_RDP(α) = (1/(α-1)) * log[(e^(α*ε) + 1) / (e^ε + 1)^(α-1)]
            numerator = np.exp(alpha * epsilon) + 1
            denominator = (exp_epsilon + 1) ** (alpha - 1)
            rdp_epsilon = num_compositions * np.log(numerator / denominator) / (alpha - 1)
            
            self._rdp_epsilons[alpha] += rdp_epsilon
        
        self._mechanisms.append({
            'type': 'randomized_response',
            'epsilon': epsilon,
            'num_compositions': num_compositions
        })
    
    def add_subsampled_gaussian(
        self,
        sigma: float,
        sampling_rate: float,
        num_steps: int
    ) -> None:
        """
        添加子采样高斯机制的 RDP 参数（用于差分隐私 SGD）
        
        使用 Wang et al. (2018) 的矩会计方法计算子采样高斯的 RDP。
        
        参数:
            sigma (float): 高斯噪声的标准差
            sampling_rate (float): 批采样率 q = batch_size / dataset_size
            num_steps (int): 迭代步数
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> rdp = RenyiDifferentialPrivacy()
            >>> rdp.add_subsampled_gaussian(
            ...     sigma=1.0,
            ...     sampling_rate=0.01,
            ...     num_steps=1000
            ... )
        """
        if sigma <= 0:
            raise ValueError(f"标准差必须为正数，当前值: {sigma}")
        if not 0 < sampling_rate <= 1:
            raise ValueError(f"采样率必须在 (0, 1] 区间内，当前值: {sampling_rate}")
        if num_steps < 0:
            raise ValueError(f"迭代步数必须为非负数，当前值: {num_steps}")
        
        # 使用子采样高斯的 RDP 上界
        # 基于 Wang et al. (2018) 的结果
        for alpha in self._orders:
            # 子采样放大效应
            # ε_RDP(α) ≈ q² * α / (2σ²) * num_steps （当 q 较小时）
            # 更精确的计算使用对数矩生成函数
            
            # 简化计算：使用子采样放大引理
            # 对于子采样高斯，RDP 参数约为非子采样版本的 q² 倍
            base_epsilon = alpha / (2 * sigma ** 2)
            amplification_factor = sampling_rate ** 2
            rdp_epsilon = num_steps * amplification_factor * base_epsilon
            
            self._rdp_epsilons[alpha] += rdp_epsilon
        
        self._mechanisms.append({
            'type': 'subsampled_gaussian',
            'sigma': sigma,
            'sampling_rate': sampling_rate,
            'num_steps': num_steps
        })
    
    def get_epsilon_delta(
        self,
        target_delta: float,
        target_epsilon: Optional[float] = None
    ) -> Union[Tuple[float, float], float]:
        """
        将 RDP 转换为 (ε, δ)-差分隐私
        
        转换公式:
            若机制满足 (α, ε_RDP(α))-RDP，则它满足
            (ε_RDP(α) + log(1/δ)/(α-1), δ)-DP
        
        对于给定的 δ，最优的 ε 为:
            ε = min_α {ε_RDP(α) + log(1/δ)/(α-1)}
        
        参数:
            target_delta (float): 目标松弛参数 δ
            target_epsilon (Optional[float]): 若提供，计算满足该 ε 所需的最小 δ
        
        返回:
            若 target_epsilon 为 None，返回 (epsilon, delta) 元组
            若 target_epsilon 不为 None，返回所需的最小 delta
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> rdp = RenyiDifferentialPrivacy()
            >>> rdp.add_gaussian_mechanism(sigma=1.0, num_compositions=100)
            >>> eps, delta = rdp.get_epsilon_delta(target_delta=1e-5)
            >>> print(f"等效隐私参数: ε={eps:.4f}, δ={delta:.2e}")
        """
        if target_delta is not None and not 0 < target_delta < 1:
            raise ValueError(f"δ 必须在 (0, 1) 区间内，当前值: {target_delta}")
        
        if target_epsilon is None:
            # 计算给定 δ 下的最小 ε
            min_epsilon = float('inf')
            best_alpha = None
            
            for alpha in self._orders:
                rdp_epsilon = self._rdp_epsilons[alpha]
                # ε = ε_RDP(α) + log(1/δ)/(α-1)
                epsilon = rdp_epsilon + np.log(1 / target_delta) / (alpha - 1)
                
                if epsilon < min_epsilon:
                    min_epsilon = epsilon
                    best_alpha = alpha
            
            if best_alpha is None:
                raise RuntimeError("无法计算隐私参数，请检查 RDP 设置")
            
            return (min_epsilon, target_delta)
        
        else:
            # 计算给定 ε 下的最小 δ
            # ε = ε_RDP(α) + log(1/δ)/(α-1)
            # log(1/δ) = (ε - ε_RDP(α)) * (α-1)
            # δ = exp(-(ε - ε_RDP(α)) * (α-1))
            
            min_delta = float('inf')
            
            for alpha in self._orders:
                rdp_epsilon = self._rdp_epsilons[alpha]
                
                if target_epsilon > rdp_epsilon:
                    log_inv_delta = (target_epsilon - rdp_epsilon) * (alpha - 1)
                    delta = np.exp(-log_inv_delta)
                    min_delta = min(min_delta, delta)
            
            if min_delta == float('inf'):
                return 1.0  # 无法满足给定的 ε
            
            return min_delta
    
    def compute_epsilon_for_delta_range(
        self,
        delta_range: List[float]
    ) -> List[Tuple[float, float]]:
        """
        计算一系列 δ 值对应的 ε
        
        参数:
            delta_range (List[float]): δ 值列表
        
        返回:
            List[Tuple[float, float]]: [(δ₁, ε₁), (δ₂, ε₂), ...] 列表
        
        示例:
            >>> rdp = RenyiDifferentialPrivacy()
            >>> rdp.add_gaussian_mechanism(sigma=1.0, num_compositions=100)
            >>> results = rdp.compute_epsilon_for_delta_range([1e-4, 1e-5, 1e-6])
        """
        results = []
        for delta in delta_range:
            eps, _ = self.get_epsilon_delta(target_delta=delta)
            results.append((delta, eps))
        return results
    
    def compose_with(self, other: 'RenyiDifferentialPrivacy') -> 'RenyiDifferentialPrivacy':
        """
        与另一个 RDP 对象组合
        
        数学公式:
            ε_total(α) = ε₁(α) + ε₂(α)
        
        参数:
            other (RenyiDifferentialPrivacy): 另一个 RDP 对象
        
        返回:
            RenyiDifferentialPrivacy: 新的组合后的 RDP 对象
        
        示例:
            >>> rdp1 = RenyiDifferentialPrivacy()
            >>> rdp1.add_gaussian_mechanism(sigma=1.0, num_compositions=10)
            >>> rdp2 = RenyiDifferentialPrivacy()
            >>> rdp2.add_laplace_mechanism(epsilon=0.5, num_compositions=5)
            >>> combined = rdp1.compose_with(rdp2)
        """
        # 合并阶数列表
        all_orders = list(set(self._orders) | set(other._orders))
        
        # 创建新的 RDP 对象
        new_rdp = RenyiDifferentialPrivacy(orders=all_orders)
        
        # 合并 RDP 参数
        for alpha in all_orders:
            eps1 = self._rdp_epsilons.get(alpha, 0.0)
            eps2 = other._rdp_epsilons.get(alpha, 0.0)
            new_rdp._rdp_epsilons[alpha] = eps1 + eps2
        
        # 复制机制记录
        new_rdp._mechanisms = self._mechanisms + other._mechanisms
        
        return new_rdp
    
    def get_optimal_order(self, target_delta: float) -> Tuple[float, float]:
        """
        获取给定 δ 下的最优阶数
        
        参数:
            target_delta (float): 目标松弛参数
        
        返回:
            Tuple[float, float]: (最优阶数 α, 对应的 ε)
        
        示例:
            >>> rdp = RenyiDifferentialPrivacy()
            >>> rdp.add_gaussian_mechanism(sigma=1.0, num_compositions=100)
            >>> alpha, eps = rdp.get_optimal_order(target_delta=1e-5)
            >>> print(f"最优阶数: α={alpha}, ε={eps:.4f}")
        """
        min_epsilon = float('inf')
        best_alpha = None
        
        for alpha in self._orders:
            rdp_epsilon = self._rdp_epsilons[alpha]
            epsilon = rdp_epsilon + np.log(1 / target_delta) / (alpha - 1)
            
            if epsilon < min_epsilon:
                min_epsilon = epsilon
                best_alpha = alpha
        
        if best_alpha is None:
            raise RuntimeError("无法找到最优阶数")
        
        return (best_alpha, min_epsilon)
    
    def reset(self) -> None:
        """
        重置所有 RDP 参数
        
        示例:
            >>> rdp.reset()
        """
        for alpha in self._orders:
            self._rdp_epsilons[alpha] = 0.0
        self._mechanisms.clear()
    
    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        return (
            f"RenyiDifferentialPrivacy("
            f"orders={len(self._orders)}, "
            f"mechanisms={len(self._mechanisms)})"
        )
    
    def __str__(self) -> str:
        """返回对象的可读字符串"""
        return (
            f"Rényi 差分隐私 | "
            f"阶数数量={len(self._orders)}, "
            f"机制数量={len(self._mechanisms)}"
        )
