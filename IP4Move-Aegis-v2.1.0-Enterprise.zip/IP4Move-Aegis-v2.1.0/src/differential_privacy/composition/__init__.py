"""
差分隐私组合模块

本模块提供差分隐私组合定理的实现，用于精确计算多次查询后的总隐私预算。
支持基本组合、高级组合以及 Rényi 差分隐私等先进的组合方法。

主要组件:
    - RenyiDifferentialPrivacy: Rényi 差分隐私类，提供更紧的隐私组合上界
    - AdvancedComposition: 高级组合类，使用高级组合定理
    - BasicComposition: 基本组合类，使用基本组合定理

数学基础:
    组合定理允许我们分析多个差分隐私机制组合后的隐私保证。
    基本组合定理给出线性上界，而 Rényi 差分隐私可以给出更精确的结果。

使用示例:
    >>> from differential_privacy.composition import RenyiDifferentialPrivacy
    >>> rdp = RenyiDifferentialPrivacy(orders=list(range(2, 100)))
    >>> rdp.add_gaussian_mechanism(sigma=1.0, num_compositions=100)
    >>> eps, delta = rdp.get_epsilon_delta(target_delta=1e-5)

参考:
    Mironov, I. (2017). Rényi Differential Privacy.
    Dwork, C., & Roth, A. (2014). The Algorithmic Foundations of Differential Privacy.

作者: IP4Move Team
版本: 1.0.5
"""

from .renyi import RenyiDifferentialPrivacy

__all__ = [
    "RenyiDifferentialPrivacy",
]

__version__ = "1.0.5"
