"""
差分隐私机制模块

本模块提供各种差分隐私机制的实现对噪声添加机制进行统一封装，
支持拉普拉斯机制、高斯机制和指数机制等经典差分隐私算法。

主要组件:
    - LaplaceMechanism: 拉普拉斯机制，适用于数值型查询
    - GaussianMechanism: 高斯机制，适用于需要更平滑噪声的场景
    - ExponentialMechanism: 指数机制，适用于非数值型输出

使用示例:
    >>> from differential_privacy.mechanisms import LaplaceMechanism
    >>> mechanism = LaplaceMechanism(epsilon=1.0, sensitivity=1.0)
    >>> noisy_result = mechanism.add_noise(100.0)

数学基础:
    差分隐私的数学定义为：对于任意两个相邻数据集 D 和 D'，以及任意输出集合 S，
    满足：
        Pr[M(D) ∈ S] ≤ exp(ε) * Pr[M(D') ∈ S] + δ
    
    其中 ε 为隐私预算，δ 为松弛参数。

作者: IP4Move Team
版本: 1.0.5
"""

from .laplace import LaplaceMechanism
from .gaussian import GaussianMechanism
from .exponential import ExponentialMechanism

__all__ = [
    "LaplaceMechanism",
    "GaussianMechanism", 
    "ExponentialMechanism",
]

__version__ = "1.0.5"
