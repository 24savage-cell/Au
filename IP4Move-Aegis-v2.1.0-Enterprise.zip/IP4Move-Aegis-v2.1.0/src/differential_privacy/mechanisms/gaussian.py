"""
高斯机制 (Gaussian Mechanism)

高斯机制通过在查询结果上添加服从高斯（正态）分布的噪声来实现差分隐私保护。
与拉普拉斯机制相比，高斯机制产生的噪声更加平滑，在某些场景下能提供更好的效用。

数学原理:
    高斯分布的概率密度函数为:
        N(x | μ, σ²) = (1 / √(2πσ²)) * exp(-(x-μ)² / (2σ²))
    
    其中:
        - μ: 均值参数（噪声中心，通常为 0）
        - σ: 标准差参数
        - σ²: 方差参数

    对于 (ε, δ)-差分隐私的高斯机制，噪声标准差为:
        σ = √(2 * ln(1.25/δ)) * Δf / ε
    
    或更一般的:
        σ = Δf * √(2 * ln(1.25/δ)) / ε

    隐私保证:
        高斯机制满足 (ε, δ)-差分隐私，其中 δ > 0。
        这意味着隐私保证以概率 (1-δ) 成立。

与拉普拉斯机制的比较:
    优点:
        - 噪声更平滑，在某些统计查询中效用更好
        - 更适合高维数据
        - 与机器学习方法更兼容
    
    缺点:
        - 仅提供 (ε, δ)-差分隐私，而非纯差分隐私
        - 需要选择合适的 δ 参数

使用场景:
    - 深度学习中的梯度扰动
    - 高维数值查询
    - 需要平滑噪声的场景
    - 当 δ > 0 可接受时

参考:
    Dwork, C., & Roth, A. (2014). The Algorithmic Foundations of Differential Privacy.
    Abadi, M., et al. (2016). Deep Learning with Differential Privacy.
"""

import numpy as np
from typing import Union, Tuple, Optional
import warnings
import math


class GaussianMechanism:
    """
    高斯机制类
    
    通过在查询结果上添加高斯噪声来实现 (ε, δ)-差分隐私保护。
    支持标量和向量输入，提供灵活的隐私参数管理。
    
    属性:
        epsilon (float): 隐私预算参数
        delta (float): 松弛参数，控制隐私保证的失败概率
        sensitivity (float): 查询的全局敏感度
        sigma (float): 高斯分布的标准差参数
        
    示例:
        >>> mechanism = GaussianMechanism(epsilon=1.0, delta=1e-5, sensitivity=1.0)
        >>> true_value = 100.0
        >>> noisy_value = mechanism.add_noise(true_value)
        >>> print(f"原始值: {true_value}, 加噪后: {noisy_value}")
    """
    
    def __init__(
        self,
        epsilon: float,
        delta: float,
        sensitivity: float,
        random_state: Optional[int] = None,
        sigma: Optional[float] = None
    ) -> None:
        """
        初始化高斯机制
        
        参数:
            epsilon (float): 隐私预算参数，必须为正数
                - 较小的 epsilon 提供更强的隐私保护
                - 常用的取值范围: 0.1 ~ 10.0
            delta (float): 松弛参数，必须在 (0, 1) 区间内
                - 控制隐私保证的失败概率
                - 常用取值: 1e-6 ~ 1e-4
            sensitivity (float): 查询的全局敏感度，必须为非负数
            random_state (Optional[int]): 随机数种子，用于结果复现
            sigma (Optional[float]): 手动指定的标准差参数
                - 若提供，则覆盖根据 epsilon/delta 计算的值
                - 用于高级用户自定义噪声尺度
        
        异常:
            ValueError: 当参数不合法时抛出
        
        注意:
            delta 的选择需要在隐私保证和噪声大小之间权衡。
            一般建议 delta << 1/n，其中 n 为数据集大小。
        """
        # 参数验证
        if epsilon <= 0:
            raise ValueError(
                f"隐私预算 epsilon 必须为正数，当前值: {epsilon}"
            )
        if not 0 < delta < 1:
            raise ValueError(
                f"松弛参数 delta 必须在 (0, 1) 区间内，当前值: {delta}"
            )
        if sensitivity < 0:
            raise ValueError(
                f"敏感度 sensitivity 必须为非负数，当前值: {sensitivity}"
            )
        
        self._epsilon: float = float(epsilon)
        self._delta: float = float(delta)
        self._sensitivity: float = float(sensitivity)
        self._random_state: Optional[int] = random_state
        
        # 设置随机数生成器
        self._rng = np.random.RandomState(random_state)
        
        # 计算或设置标准差
        if sigma is not None:
            if sigma <= 0:
                raise ValueError(
                    f"标准差 sigma 必须为正数，当前值: {sigma}"
                )
            self._sigma: float = float(sigma)
        else:
            self._sigma = self._compute_sigma(epsilon, delta, sensitivity)
        
        # 隐私警告
        if epsilon > 10:
            warnings.warn(
                f"隐私预算 epsilon={epsilon} 较大，隐私保护较弱。",
                UserWarning
            )
        if delta > 1e-4:
            warnings.warn(
                f"松弛参数 delta={delta} 较大，隐私保证较弱。"
                f"建议 delta ≤ 1e-5 以获得更强的隐私保证。",
                UserWarning
            )
    
    def _compute_sigma(
        self,
        epsilon: float,
        delta: float,
        sensitivity: float
    ) -> float:
        """
        计算满足 (ε, δ)-差分隐私的高斯噪声标准差
        
        数学公式:
            σ = √(2 * ln(1.25/δ)) * Δf / ε
        
        这是基于文献中的标准结果，适用于 ε ∈ (0, 1) 的情况。
        对于更大的 epsilon，可能需要使用更复杂的计算方法。
        
        参数:
            epsilon (float): 隐私预算
            delta (float): 松弛参数
            sensitivity (float): 全局敏感度
        
        返回:
            float: 计算得到的标准差
        """
        # 标准公式: σ = √(2 * ln(1.25/δ)) * Δf / ε
        sigma = np.sqrt(2.0 * np.log(1.25 / delta)) * sensitivity / epsilon
        return float(sigma)
    
    @property
    def epsilon(self) -> float:
        """获取隐私预算参数"""
        return self._epsilon
    
    @property
    def delta(self) -> float:
        """获取松弛参数"""
        return self._delta
    
    @property
    def sensitivity(self) -> float:
        """获取全局敏感度"""
        return self._sensitivity
    
    @property
    def sigma(self) -> float:
        """获取高斯分布的标准差参数"""
        return self._sigma
    
    @property
    def variance(self) -> float:
        """获取高斯分布的方差 σ²"""
        return self._sigma ** 2
    
    def add_noise(
        self,
        value: Union[float, np.ndarray],
        epsilon: Optional[float] = None,
        delta: Optional[float] = None
    ) -> Union[float, np.ndarray]:
        """
        向输入值添加高斯噪声
        
        数学公式:
            M(v) = v + η, 其中 η ~ N(0, σ²)
            σ = √(2 * ln(1.25/δ)) * Δf / ε
        
        参数:
            value (Union[float, np.ndarray]): 原始查询结果
                - 支持标量（float）或数组（numpy.ndarray）
            epsilon (Optional[float]): 临时指定的隐私预算
            delta (Optional[float]): 临时指定的松弛参数
        
        返回:
            Union[float, np.ndarray]: 添加噪声后的结果
        
        异常:
            ValueError: 当临时参数不合法时抛出
        
        示例:
            >>> mechanism = GaussianMechanism(epsilon=1.0, delta=1e-5, sensitivity=1.0)
            >>> noisy = mechanism.add_noise(100.0)
            >>> noisy_array = mechanism.add_noise(np.array([1.0, 2.0, 3.0]))
        """
        # 确定使用的参数
        eps = epsilon if epsilon is not None else self._epsilon
        delt = delta if delta is not None else self._delta
        
        if eps <= 0:
            raise ValueError(f"隐私预算必须为正数，当前值: {eps}")
        if not 0 < delt < 1:
            raise ValueError(f"松弛参数必须在 (0, 1) 区间内，当前值: {delt}")
        
        # 计算标准差
        sigma = self._compute_sigma(eps, delt, self._sensitivity)
        
        # 生成高斯噪声
        noise = self._rng.normal(loc=0.0, scale=sigma, size=np.shape(value))
        
        # 添加噪声
        result = np.asarray(value) + noise
        
        # 保持原始类型
        if isinstance(value, (int, float)):
            return float(result)
        return result
    
    def get_epsilon_delta(
        self,
        epsilon: Optional[float] = None,
        delta: Optional[float] = None
    ) -> Tuple[float, float]:
        """
        获取当前机制的 (ε, δ) 隐私参数
        
        参数:
            epsilon (Optional[float]): 指定的隐私预算
            delta (Optional[float]): 指定的松弛参数
        
        返回:
            Tuple[float, float]: (epsilon, delta) 元组
        
        示例:
            >>> mechanism = GaussianMechanism(epsilon=1.0, delta=1e-5, sensitivity=1.0)
            >>> eps, delta = mechanism.get_epsilon_delta()
            >>> print(f"({eps}, {delta})")  # 输出: (1.0, 1e-05)
        """
        eps = epsilon if epsilon is not None else self._epsilon
        delt = delta if delta is not None else self._delta
        return (eps, delt)
    
    def compose(
        self,
        num_compositions: int,
        epsilon_per_query: Optional[float] = None,
        delta_per_query: Optional[float] = None
    ) -> Tuple[float, float]:
        """
        计算多次查询组合后的隐私参数
        
        使用高级组合定理（Advanced Composition）计算 k 次查询后的总隐私预算。
        
        数学公式（高级组合定理）:
            对于 k 次 (ε, δ)-差分隐私机制的查询，
            对于任意 δ' > 0，组合后满足:
                (ε', kδ + δ')-差分隐私
            其中:
                ε' = √(2k * ln(1/δ')) * ε + k * ε * (e^ε - 1) / (e^ε + 1)
        
        简化版本（当 ε 较小时）:
            ε' ≈ √(2k * ln(1/δ')) * ε
        
        参数:
            num_compositions (int): 查询次数，必须为正整数
            epsilon_per_query (Optional[float]): 每次查询的隐私预算
            delta_per_query (Optional[float]): 每次查询的松弛参数
        
        返回:
            Tuple[float, float]: 组合后的 (epsilon, delta) 参数
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> mechanism = GaussianMechanism(epsilon=0.1, delta=1e-6, sensitivity=1.0)
            >>> total_eps, total_delta = mechanism.compose(num_compositions=100)
            >>> print(f"100次查询后总隐私预算: ({total_eps:.4f}, {total_delta:.2e})")
        """
        if not isinstance(num_compositions, int) or num_compositions <= 0:
            raise ValueError(
                f"查询次数必须为正整数，当前值: {num_compositions}"
            )
        
        eps = epsilon_per_query if epsilon_per_query is not None else self._epsilon
        delt = delta_per_query if delta_per_query is not None else self._delta
        
        # 高级组合定理
        # 选择 δ' = delt（与单次查询相同）
        delta_prime = delt
        
        # 计算组合后的 epsilon
        # ε' = √(2k * ln(1/δ')) * ε + k * ε² / 2  (近似)
        sqrt_term = np.sqrt(2 * num_compositions * np.log(1 / delta_prime))
        epsilon_composed = sqrt_term * eps + num_compositions * eps * (np.exp(eps) - 1) / (np.exp(eps) + 1)
        
        # 组合后的 delta
        delta_composed = num_compositions * delt + delta_prime
        
        return (float(epsilon_composed), float(delta_composed))
    
    def confidence_interval(
        self,
        confidence: float = 0.95,
        epsilon: Optional[float] = None,
        delta: Optional[float] = None
    ) -> float:
        """
        计算噪声的置信区间半径
        
        对于标准正态分布，给定置信水平 α，区间半径为 z_α * σ，
        其中 z_α 是标准正态分布的 (1+α)/2 分位数。
        
        数学原理:
            P(|η| ≤ z_α * σ) = α
            其中 z_α = Φ⁻¹((1+α)/2)，Φ 为标准正态分布的 CDF
        
        常用值:
            - 90% 置信区间: z ≈ 1.645
            - 95% 置信区间: z ≈ 1.96
            - 99% 置信区间: z ≈ 2.576
        
        参数:
            confidence (float): 置信水平，必须在 (0, 1) 区间内
            epsilon (Optional[float]): 指定的隐私预算
            delta (Optional[float]): 指定的松弛参数
        
        返回:
            float: 置信区间半径
        
        异常:
            ValueError: 当 confidence 不在 (0, 1) 区间内时抛出
        
        示例:
            >>> mechanism = GaussianMechanism(epsilon=1.0, delta=1e-5, sensitivity=1.0)
            >>> radius = mechanism.confidence_interval(confidence=0.95)
            >>> print(f"95% 置信区间半径: ±{radius:.4f}")
        """
        if not 0 < confidence < 1:
            raise ValueError(
                f"置信水平必须在 (0, 1) 区间内，当前值: {confidence}"
            )
        
        eps = epsilon if epsilon is not None else self._epsilon
        delt = delta if delta is not None else self._delta
        
        sigma = self._compute_sigma(eps, delt, self._sensitivity)
        
        # 计算 z 分数
        # 使用正态分布的分位数函数（逆 CDF）
        alpha = (1 + confidence) / 2
        z_score = self._compute_z_score(alpha)
        
        radius = z_score * sigma
        return float(radius)
    
    def _compute_z_score(self, quantile: float) -> float:
        """
        计算标准正态分布的分位数（逆 CDF）
        
        使用近似公式计算标准正态分布的逆累积分布函数。
        
        参数:
            quantile (float): 分位数，必须在 (0, 1) 区间内
        
        返回:
            float: 对应的 z 分数
        """
        # 使用 numpy 的近似方法
        # 对于更精确的值，可以使用 scipy.stats.norm.ppf
        # 这里使用简单的近似公式
        
        # 确保在有效范围内
        quantile = max(0.0001, min(0.9999, quantile))
        
        # 使用逆误差函数近似
        # Φ⁻¹(p) ≈ √2 * erf⁻¹(2p - 1)
        # 这里使用 numpy 的近似实现
        
        # 简单的近似公式（Abramowitz and Stegun）
        p = quantile
        if p < 0.5:
            p = 1 - p
            sign = -1
        else:
            sign = 1
        
        t = np.sqrt(-2 * np.log(1 - p))
        # 多项式近似
        c0 = 2.515517
        c1 = 0.802853
        c2 = 0.010328
        d1 = 1.432788
        d2 = 0.189269
        d3 = 0.001308
        
        z = t - (c0 + c1 * t + c2 * t**2) / (1 + d1 * t + d2 * t**2 + d3 * t**3)
        
        return sign * z
    
    def calibrate_sigma(
        self,
        target_epsilon: float,
        target_delta: float
    ) -> float:
        """
        根据目标隐私参数校准噪声标准差
        
        计算满足目标 (ε, δ)-差分隐私所需的高斯噪声标准差。
        
        参数:
            target_epsilon (float): 目标隐私预算
            target_delta (float): 目标松弛参数
        
        返回:
            float: 所需的噪声标准差
        
        示例:
            >>> mechanism = GaussianMechanism(epsilon=1.0, delta=1e-5, sensitivity=1.0)
            >>> sigma = mechanism.calibrate_sigma(target_epsilon=0.5, target_delta=1e-6)
            >>> print(f"所需标准差: {sigma:.4f}")
        """
        if target_epsilon <= 0:
            raise ValueError(f"目标隐私预算必须为正数，当前值: {target_epsilon}")
        if not 0 < target_delta < 1:
            raise ValueError(f"目标松弛参数必须在 (0, 1) 区间内，当前值: {target_delta}")
        
        return self._compute_sigma(target_epsilon, target_delta, self._sensitivity)
    
    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        return (
            f"GaussianMechanism("
            f"epsilon={self._epsilon}, "
            f"delta={self._delta}, "
            f"sensitivity={self._sensitivity}, "
            f"sigma={self._sigma:.4f})"
        )
    
    def __str__(self) -> str:
        """返回对象的可读字符串"""
        return (
            f"高斯机制 | "
            f"ε={self._epsilon}, "
            f"δ={self._delta:.2e}, "
            f"Δf={self._sensitivity}, "
            f"σ={self._sigma:.4f}"
        )
