"""
指数机制 (Exponential Mechanism)

指数机制是差分隐私中用于处理非数值型输出的重要机制。
与拉普拉斯和高斯机制不同，指数机制从离散输出空间中采样，
而非直接添加数值噪声。这使得它特别适用于选择、排序和分类等任务。

数学原理:
    给定输出空间 R 和效用函数 u: D × R → ℝ，
    指数机制以以下概率选择输出 r ∈ R:
    
        Pr[M(D) = r] ∝ exp(ε * u(D, r) / (2 * Δu))
    
    或归一化形式:
        Pr[M(D) = r] = exp(ε * u(D, r) / (2 * Δu)) / Σ_{r'∈R} exp(ε * u(D, r') / (2 * Δu))
    
    其中:
        - ε: 隐私预算参数
        - u(D, r): 效用函数，衡量输出 r 在数据集 D 上的质量
        - Δu: 效用函数的全局敏感度
        - Δu = max_{D~D'} max_{r∈R} |u(D, r) - u(D', r)|

    隐私保证:
        指数机制满足 (ε, 0)-差分隐私，即纯差分隐私。

效用保证:
    设 r* 为最优输出（效用最大），则以至少 1-β 的概率，
    指数机制选择的输出 r 满足:
        u(D, r) ≥ u(D, r*) - (2 * Δu / ε) * ln(|R|/β)

使用场景:
    - 从候选集合中选择最佳元素（如最佳分类器、最佳特征等）
    - 离散输出的随机化（如位置隐私中的位置选择）
    - 排序和推荐任务
    - 任何效用函数可定义的场景

与拉普拉斯机制的比较:
    优点:
        - 适用于非数值型输出
        - 自然地处理离散输出空间
        - 保持输出的语义有效性
    
    缺点:
        - 需要定义效用函数
        - 计算复杂度与输出空间大小相关
        - 需要枚举所有可能的输出

参考:
    McSherry, F., & Talwar, K. (2007). Mechanism Design via Differential Privacy.
    Dwork, C., & Roth, A. (2014). The Algorithmic Foundations of Differential Privacy.
"""

import numpy as np
from typing import List, Tuple, Callable, Optional, TypeVar, Generic, Any
import warnings

T = TypeVar('T')


class ExponentialMechanism:
    """
    指数机制类
    
    通过从离散输出空间中按指数加权概率采样来实现差分隐私保护。
    适用于非数值型输出和选择任务。
    
    属性:
        epsilon (float): 隐私预算参数
        sensitivity (float): 效用函数的全局敏感度
        output_space (List[T]): 候选输出空间
        utility_function (Callable): 效用函数
        
    示例:
        >>> # 定义效用函数：选择与查询最接近的元素
        >>> def utility(data, output):
        ...     return -abs(data - output)
        >>> 
        >>> mechanism = ExponentialMechanism(
        ...     epsilon=1.0,
        ...     sensitivity=1.0,
        ...     output_space=[1, 2, 3, 4, 5],
        ...     utility_function=utility
        ... )
        >>> selected = mechanism.select(data=3.0)
        >>> print(f"选择结果: {selected}")
    """
    
    def __init__(
        self,
        epsilon: float,
        sensitivity: float,
        output_space: List[T],
        utility_function: Callable[[Any, T], float],
        random_state: Optional[int] = None
    ) -> None:
        """
        初始化指数机制
        
        参数:
            epsilon (float): 隐私预算参数，必须为正数
                - 较小的 epsilon 提供更均匀的采样分布
                - 较大的 epsilon 更倾向于选择高效用输出
            sensitivity (float): 效用函数的全局敏感度 Δu
                - 定义为相邻数据集上效用函数的最大差异
            output_space (List[T]): 候选输出空间
                - 包含所有可能的输出选项
            utility_function (Callable[[Any, T], float]): 效用函数
                - 签名: utility_function(data, output) -> float
                - 返回值越大，表示该输出越优
            random_state (Optional[int]): 随机数种子，用于结果复现
        
        异常:
            ValueError: 当参数不合法时抛出
        
        注意:
            效用函数的全局敏感度计算需要仔细分析。
            对于计数查询，敏感度通常为 1。
        """
        # 参数验证
        if epsilon <= 0:
            raise ValueError(
                f"隐私预算 epsilon 必须为正数，当前值: {epsilon}"
            )
        if sensitivity <= 0:
            raise ValueError(
                f"敏感度 sensitivity 必须为正数，当前值: {sensitivity}"
            )
        if not output_space:
            raise ValueError("输出空间不能为空")
        if not callable(utility_function):
            raise ValueError("效用函数必须是可调用的")
        
        self._epsilon: float = float(epsilon)
        self._sensitivity: float = float(sensitivity)
        self._output_space: List[T] = list(output_space)
        self._utility_function: Callable[[Any, T], float] = utility_function
        self._random_state: Optional[int] = random_state
        
        # 设置随机数生成器
        self._rng = np.random.RandomState(random_state)
        
        # 缓存计算结果
        self._cached_data: Optional[Any] = None
        self._cached_scores: Optional[np.ndarray] = None
        self._cached_probabilities: Optional[np.ndarray] = None
        
        # 隐私警告
        if epsilon > 10:
            warnings.warn(
                f"隐私预算 epsilon={epsilon} 较大，隐私保护较弱。",
                UserWarning
            )
    
    @property
    def epsilon(self) -> float:
        """获取隐私预算参数"""
        return self._epsilon
    
    @property
    def sensitivity(self) -> float:
        """获取效用函数的全局敏感度"""
        return self._sensitivity
    
    @property
    def output_space(self) -> List[T]:
        """获取候选输出空间"""
        return self._output_space.copy()
    
    @property
    def output_space_size(self) -> int:
        """获取输出空间的大小 |R|"""
        return len(self._output_space)
    
    def _compute_scores(self, data: Any) -> np.ndarray:
        """
        计算所有输出的效用分数
        
        参数:
            data: 输入数据集或查询
        
        返回:
            np.ndarray: 每个输出的效用分数数组
        """
        scores = np.array([
            self._utility_function(data, output)
            for output in self._output_space
        ])
        return scores
    
    def _compute_probabilities(self, scores: np.ndarray) -> np.ndarray:
        """
        根据效用分数计算选择概率
        
        数学公式:
            p(r) = exp(ε * u(r) / (2 * Δu)) / Σ exp(ε * u(r') / (2 * Δu))
        
        参数:
            scores (np.ndarray): 效用分数数组
        
        返回:
            np.ndarray: 归一化的概率分布
        """
        # 计算指数权重
        # w(r) = exp(ε * u(r) / (2 * Δu))
        weights = np.exp(scores * self._epsilon / (2 * self._sensitivity))
        
        # 归一化
        total_weight = np.sum(weights)
        if total_weight == 0:
            # 如果所有权值为 0，使用均匀分布
            probabilities = np.ones(len(scores)) / len(scores)
        else:
            probabilities = weights / total_weight
        
        return probabilities
    
    def select(
        self,
        data: Any,
        use_cache: bool = False
    ) -> T:
        """
        根据指数机制选择一个输出
        
        数学过程:
            1. 计算每个输出的效用分数: u(D, r)
            2. 计算指数权重: w(r) = exp(ε * u(D, r) / (2 * Δu))
            3. 归一化得到概率分布: p(r) = w(r) / Σ w(r')
            4. 根据概率分布随机采样一个输出
        
        参数:
            data: 输入数据集或查询
            use_cache (bool): 是否使用缓存的分数和概率
                - 若多次对相同数据调用，设为 True 可提高性能
        
        返回:
            T: 根据指数机制选择的输出
        
        示例:
            >>> mechanism = ExponentialMechanism(
            ...     epsilon=1.0,
            ...     sensitivity=1.0,
            ...     output_space=['A', 'B', 'C'],
            ...     utility_function=lambda d, o: 1 if o == d else 0
            ... )
            >>> selected = mechanism.select(data='A')
        """
        # 检查缓存
        if use_cache and self._cached_data == data and self._cached_probabilities is not None:
            probabilities = self._cached_probabilities
        else:
            # 计算效用分数
            scores = self._compute_scores(data)
            
            # 计算概率分布
            probabilities = self._compute_probabilities(scores)
            
            # 更新缓存
            if use_cache:
                self._cached_data = data
                self._cached_scores = scores
                self._cached_probabilities = probabilities
        
        # 根据概率分布采样
        selected_index = self._rng.choice(len(self._output_space), p=probabilities)
        
        return self._output_space[selected_index]
    
    def select_multiple(
        self,
        data: Any,
        num_selections: int,
        with_replacement: bool = False
    ) -> List[T]:
        """
        根据指数机制选择多个输出
        
        注意：多次选择会累积隐私预算。
        若 num_selections = k，则总隐私预算为 k * ε。
        
        参数:
            data: 输入数据集或查询
            num_selections (int): 选择次数
            with_replacement (bool): 是否允许重复选择
                - True: 有放回抽样
                - False: 无放回抽样（num_selections ≤ |R|）
        
        返回:
            List[T]: 选择的输出列表
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> mechanism = ExponentialMechanism(...)
            >>> top3 = mechanism.select_multiple(data, num_selections=3)
        """
        if num_selections <= 0:
            raise ValueError(
                f"选择次数必须为正整数，当前值: {num_selections}"
            )
        
        if not with_replacement and num_selections > len(self._output_space):
            raise ValueError(
                f"无放回抽样时，选择次数不能超过输出空间大小 "
                f"({num_selections} > {len(self._output_space)})"
            )
        
        # 计算概率分布
        scores = self._compute_scores(data)
        probabilities = self._compute_probabilities(scores)
        
        if with_replacement:
            # 有放回抽样
            selected_indices = self._rng.choice(
                len(self._output_space),
                size=num_selections,
                p=probabilities
            )
        else:
            # 无放回抽样
            selected_indices = self._rng.choice(
                len(self._output_space),
                size=num_selections,
                replace=False,
                p=probabilities
            )
        
        return [self._output_space[i] for i in selected_indices]
    
    def get_probabilities(self, data: Any) -> List[Tuple[T, float]]:
        """
        获取每个输出的选择概率
        
        参数:
            data: 输入数据集或查询
        
        返回:
            List[Tuple[T, float]]: (输出, 概率) 的列表
        
        示例:
            >>> mechanism = ExponentialMechanism(...)
            >>> probs = mechanism.get_probabilities(data)
            >>> for output, prob in probs:
            ...     print(f"{output}: {prob:.4f}")
        """
        scores = self._compute_scores(data)
        probabilities = self._compute_probabilities(scores)
        
        return list(zip(self._output_space, probabilities))
    
    def get_epsilon_delta(
        self,
        epsilon: Optional[float] = None
    ) -> Tuple[float, float]:
        """
        获取当前机制的 (ε, δ) 隐私参数
        
        指数机制满足纯差分隐私，即 δ = 0。
        
        参数:
            epsilon (Optional[float]): 指定的隐私预算
        
        返回:
            Tuple[float, float]: (epsilon, delta) 元组
        
        示例:
            >>> mechanism = ExponentialMechanism(...)
            >>> eps, delta = mechanism.get_epsilon_delta()
            >>> print(f"({eps}, {delta})")  # 输出: (1.0, 0.0)
        """
        eps = epsilon if epsilon is not None else self._epsilon
        return (eps, 0.0)
    
    def compose(
        self,
        num_compositions: int,
        epsilon_per_query: Optional[float] = None
    ) -> Tuple[float, float]:
        """
        计算多次查询组合后的隐私参数
        
        使用基本组合定理计算 k 次独立查询后的总隐私预算。
        
        数学公式:
            对于 k 次 (ε, 0)-差分隐私机制的查询，
            组合后满足 (kε, 0)-差分隐私。
        
        参数:
            num_compositions (int): 查询次数，必须为正整数
            epsilon_per_query (Optional[float]): 每次查询的隐私预算
        
        返回:
            Tuple[float, float]: 组合后的 (epsilon, delta) 参数
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> mechanism = ExponentialMechanism(epsilon=0.1, ...)
            >>> total_eps, total_delta = mechanism.compose(num_compositions=10)
        """
        if not isinstance(num_compositions, int) or num_compositions <= 0:
            raise ValueError(
                f"查询次数必须为正整数，当前值: {num_compositions}"
            )
        
        eps = epsilon_per_query if epsilon_per_query is not None else self._epsilon
        total_epsilon = num_compositions * eps
        
        return (total_epsilon, 0.0)
    
    def expected_utility(self, data: Any) -> float:
        """
        计算期望效用
        
        E[u] = Σ p(r) * u(D, r)
        
        参数:
            data: 输入数据集或查询
        
        返回:
            float: 期望效用值
        
        示例:
            >>> mechanism = ExponentialMechanism(...)
            >>> expected = mechanism.expected_utility(data)
            >>> print(f"期望效用: {expected:.4f}")
        """
        scores = self._compute_scores(data)
        probabilities = self._compute_probabilities(scores)
        
        return float(np.sum(scores * probabilities))
    
    def utility_gap_bound(
        self,
        confidence: float = 0.95,
        epsilon: Optional[float] = None
    ) -> float:
        """
        计算效用差距的理论上界
        
        根据指数机制的效用保证，以至少 (1-β) 的概率，
        选择的输出与最优输出的效用差距满足:
            u(r*) - u(r) ≤ (2 * Δu / ε) * ln(|R|/β)
        
        参数:
            confidence (float): 置信水平，必须在 (0, 1) 区间内
            epsilon (Optional[float]): 指定的隐私预算
        
        返回:
            float: 效用差距上界
        
        异常:
            ValueError: 当参数不合法时抛出
        
        示例:
            >>> mechanism = ExponentialMechanism(...)
            >>> gap = mechanism.utility_gap_bound(confidence=0.95)
            >>> print(f"95% 置信度下效用差距上界: {gap:.4f}")
        """
        if not 0 < confidence < 1:
            raise ValueError(
                f"置信水平必须在 (0, 1) 区间内，当前值: {confidence}"
            )
        
        eps = epsilon if epsilon is not None else self._epsilon
        beta = 1 - confidence
        
        # 效用差距上界
        gap = (2 * self._sensitivity / eps) * np.log(len(self._output_space) / beta)
        
        return float(gap)
    
    def clear_cache(self) -> None:
        """
        清除缓存的分数和概率
        
        示例:
            >>> mechanism.clear_cache()
        """
        self._cached_data = None
        self._cached_scores = None
        self._cached_probabilities = None
    
    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        return (
            f"ExponentialMechanism("
            f"epsilon={self._epsilon}, "
            f"sensitivity={self._sensitivity}, "
            f"output_space_size={len(self._output_space)})"
        )
    
    def __str__(self) -> str:
        """返回对象的可读字符串"""
        return (
            f"指数机制 | "
            f"ε={self._epsilon}, "
            f"Δu={self._sensitivity}, "
            f"|R|={len(self._output_space)}"
        )


class ReportNoisyMax(ExponentialMechanism):
    """
    带噪声最大值报告机制 (Report Noisy Max)
    
    这是指数机制的一个特例，用于从多个候选中选择效用最高的选项。
    它在每个效用分数上添加拉普拉斯噪声，然后选择噪声后的最大值。
    
    数学等价性:
        当输出空间为有限集合时，Report Noisy Max 与指数机制等价。
        但 Report Noisy Max 在实现上更高效，时间复杂度为 O(|R|)。
    
    使用场景:
        - 从多个选项中选择最佳者
        - 投票和聚合任务
        - 特征选择
    
    示例:
        >>> def score_function(data, candidate):
        ...     # 返回候选者的得分
        ...     return data.get(candidate, 0)
        >>> 
        >>> mechanism = ReportNoisyMax(
        ...     epsilon=1.0,
        ...     sensitivity=1.0,
        ...     candidates=['A', 'B', 'C'],
        ...     score_function=score_function
        ... )
        >>> best = mechanism.select(data={'A': 10, 'B': 5, 'C': 8})
    """
    
    def __init__(
        self,
        epsilon: float,
        sensitivity: float,
        candidates: List[T],
        score_function: Callable[[Any, T], float],
        random_state: Optional[int] = None
    ) -> None:
        """
        初始化带噪声最大值报告机制
        
        参数:
            epsilon (float): 隐私预算参数
            sensitivity (float): 评分函数的全局敏感度
            candidates (List[T]): 候选者列表
            score_function (Callable[[Any, T], float]): 评分函数
            random_state (Optional[int]): 随机数种子
        """
        # Report Noisy Max 等价于使用评分函数作为效用函数的指数机制
        super().__init__(
            epsilon=epsilon,
            sensitivity=sensitivity,
            output_space=candidates,
            utility_function=score_function,
            random_state=random_state
        )
        
        self._candidates = candidates
        self._score_function = score_function
    
    def select(self, data: Any, use_cache: bool = False) -> T:
        """
        选择带噪声的最大值
        
        实现方式:
            1. 为每个候选者计算分数
            2. 添加拉普拉斯噪声: s'(r) = s(r) + Lap(0, 2*Δu/ε)
            3. 选择噪声后分数最高的候选者
        
        参数:
            data: 输入数据
            use_cache: 是否使用缓存
        
        返回:
            T: 选择的候选者
        """
        # 计算所有候选者的分数
        scores = np.array([
            self._score_function(data, candidate)
            for candidate in self._candidates
        ])
        
        # 添加拉普拉斯噪声
        # 噪声尺度 b = 2 * Δu / ε
        scale = 2 * self._sensitivity / self._epsilon
        noise = self._rng.laplace(loc=0.0, scale=scale, size=len(scores))
        noisy_scores = scores + noise
        
        # 选择噪声后分数最高的候选者
        best_index = np.argmax(noisy_scores)
        
        return self._candidates[best_index]
    
    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        return (
            f"ReportNoisyMax("
            f"epsilon={self._epsilon}, "
            f"sensitivity={self._sensitivity}, "
            f"num_candidates={len(self._candidates)})"
        )
    
    def __str__(self) -> str:
        """返回对象的可读字符串"""
        return (
            f"带噪声最大值报告 | "
            f"ε={self._epsilon}, "
            f"Δs={self._sensitivity}, "
            f"候选数={len(self._candidates)}"
        )
