"""
拉普拉斯机制 (Laplace Mechanism)

拉普拉斯机制是差分隐私中最基础且广泛使用的机制之一，
通过在查询结果上添加服从拉普拉斯分布的噪声来实现隐私保护。

数学原理:
    拉普拉斯分布的概率密度函数为:
        Lap(x | μ, b) = (1 / 2b) * exp(-|x - μ| / b)
    
    其中:
        - μ: 位置参数（噪声中心）
        - b: 尺度参数，b = Δf / ε
        - Δf: 查询的敏感度（全局敏感度）
        - ε: 隐私预算参数

    对于拉普拉斯机制，噪声尺度与隐私预算的关系为:
        b = Δf / ε

    隐私保证:
        拉普拉斯机制满足 (ε, 0)-差分隐私，即纯差分隐私。

使用场景:
    - 数值型查询（如计数、求和、均值等）
    - 需要严格隐私保证的场景
    - 敏感度较小的查询

参考:
    Dwork, C., & Roth, A. (2014). The Algorithmic Foundations of Differential Privacy.
"""

import numpy as np
from typing import Union, Tuple, Optional
import warnings


class LaplaceMechanism:
    """
    拉普拉斯机制类
    
    通过在查询结果上添加拉普拉斯噪声来实现差分隐私保护。
    支持标量和向量输入，提供完整的隐私参数管理。
    
    属性:
        epsilon (float): 隐私预算参数，控制隐私保护强度
        sensitivity (float): 查询的全局敏感度
        scale (float): 拉普拉斯分布的尺度参数 b = sensitivity / epsilon
        
    示例:
        >>> mechanism = LaplaceMechanism(epsilon=1.0, sensitivity=1.0)
        >>> true_value = 100.0
        >>> noisy_value = mechanism.add_noise(true_value)
        >>> print(f"原始值: {true_value}, 加噪后: {noisy_value}")
    """
    
    def __init__(
        self,
        epsilon: float,
        sensitivity: float,
        random_state: Optional[int] = None
    ) -> None:
        """
        初始化拉普拉斯机制
        
        参数:
            epsilon (float): 隐私预算参数，必须为正数
                - 较小的 epsilon 提供更强的隐私保护，但噪声更大
                - 常用的取值范围: 0.1 ~ 10.0
            sensitivity (float): 查询的全局敏感度
                - 定义为相邻数据集上查询结果的最大差异
            random_state (Optional[int]): 随机数种子，用于结果复现
        
        异常:
            ValueError: 当 epsilon <= 0 或 sensitivity < 0 时抛出
        
        注意:
            隐私预算 epsilon 的选择需要在隐私保护和数据效用之间权衡。
            一般建议 epsilon ≤ 1 为强隐私，1 < epsilon < 10 为中等隐私。
        """
        # 参数验证
        if epsilon <= 0:
            raise ValueError(
                f"隐私预算 epsilon 必须为正数，当前值: {epsilon}"
            )
        if sensitivity < 0:
            raise ValueError(
                f"敏感度 sensitivity 必须为非负数，当前值: {sensitivity}"
            )
        
        self._epsilon: float = float(epsilon)
        self._sensitivity: float = float(sensitivity)
        self._scale: float = sensitivity / epsilon
        self._random_state: Optional[int] = random_state
        
        # 设置随机数生成器
        self._rng = np.random.RandomState(random_state)
        
        # 隐私警告
        if epsilon > 10:
            warnings.warn(
                f"隐私预算 epsilon={epsilon} 较大，隐私保护较弱。"
                "建议 epsilon ≤ 10 以获得有意义的隐私保证。",
                UserWarning
            )
    
    @property
    def epsilon(self) -> float:
        """获取隐私预算参数"""
        return self._epsilon
    
    @property
    def sensitivity(self) -> float:
        """获取全局敏感度"""
        return self._sensitivity
    
    @property
    def scale(self) -> float:
        """获取拉普拉斯分布的尺度参数 b = Δf / ε"""
        return self._scale
    
    def add_noise(
        self,
        value: Union[float, np.ndarray],
        epsilon: Optional[float] = None
    ) -> Union[float, np.ndarray]:
        """
        向输入值添加拉普拉斯噪声
        
        数学公式:
            M(v) = v + η, 其中 η ~ Lap(0, b), b = Δf / ε
        
        参数:
            value (Union[float, np.ndarray]): 原始查询结果
                - 支持标量（float）或数组（numpy.ndarray）
            epsilon (Optional[float]): 临时指定的隐私预算
                - 若提供，则覆盖初始化时的 epsilon
                - 用于同一机制实例在不同查询中使用不同隐私预算的场景
        
        返回:
            Union[float, np.ndarray]: 添加噪声后的结果，类型与输入一致
        
        异常:
            ValueError: 当临时 epsilon 不合法时抛出
            TypeError: 当输入类型不支持时抛出
        
        示例:
            >>> mechanism = LaplaceMechanism(epsilon=1.0, sensitivity=1.0)
            >>> # 标量输入
            >>> noisy_scalar = mechanism.add_noise(100.0)
            >>> # 数组输入
            >>> noisy_array = mechanism.add_noise(np.array([1.0, 2.0, 3.0]))
            >>> # 临时指定隐私预算
            >>> noisy_with_temp = mechanism.add_noise(100.0, epsilon=0.5)
        """
        # 确定使用的隐私预算
        used_epsilon = epsilon if epsilon is not None else self._epsilon
        
        if used_epsilon <= 0:
            raise ValueError(f"隐私预算必须为正数，当前值: {used_epsilon}")
        
        # 计算尺度参数
        scale = self._sensitivity / used_epsilon
        
        # 生成拉普拉斯噪声
        # numpy 的 laplace 函数使用 loc 和 scale 参数
        # loc = 0 表示噪声以 0 为中心
        noise = self._rng.laplace(loc=0.0, scale=scale, size=np.shape(value))
        
        # 添加噪声并返回
        result = np.asarray(value) + noise
        
        # 保持原始类型
        if isinstance(value, (int, float)):
            return float(result)
        return result
    
    def get_epsilon_delta(
        self,
        epsilon: Optional[float] = None
    ) -> Tuple[float, float]:
        """
        获取当前机制的 (ε, δ) 隐私参数
        
        拉普拉斯机制满足纯差分隐私，即 δ = 0。
        
        参数:
            epsilon (Optional[float]): 指定的隐私预算
                - 若提供，则计算该预算下的隐私参数
                - 否则使用初始化时的隐私预算
        
        返回:
            Tuple[float, float]: (epsilon, delta) 元组
                - epsilon: 隐私预算参数
                - delta: 松弛参数（拉普拉斯机制恒为 0）
        
        示例:
            >>> mechanism = LaplaceMechanism(epsilon=1.0, sensitivity=1.0)
            >>> eps, delta = mechanism.get_epsilon_delta()
            >>> print(f"({eps}, {delta})")  # 输出: (1.0, 0.0)
        """
        eps = epsilon if epsilon is not None else self._epsilon
        return (eps, 0.0)
    
    def compose(
        self,
        num_compositions: int,
        epsilon_per_query: Optional[float] = None
    ) -> Tuple[float, float]:
        """
        计算多次查询组合后的隐私参数
        
        使用基本组合定理（Basic Composition）计算 k 次独立查询后的总隐私预算。
        
        数学公式:
            对于 k 次 (ε, 0)-差分隐私机制的查询，
            组合后满足 (kε, 0)-差分隐私。
        
        参数:
            num_compositions (int): 查询次数，必须为正整数
            epsilon_per_query (Optional[float]): 每次查询的隐私预算
                - 若提供，则使用该值计算
                - 否则使用初始化时的隐私预算
        
        返回:
            Tuple[float, float]: 组合后的 (epsilon, delta) 参数
        
        异常:
            ValueError: 当 num_compositions 不是正整数时抛出
        
        注意:
            基本组合定理给出的隐私预算上界较为宽松。
            对于大量查询，建议使用高级组合定理或 Rényi 差分隐私进行更精确的计算。
        
        示例:
            >>> mechanism = LaplaceMechanism(epsilon=0.1, sensitivity=1.0)
            >>> total_eps, total_delta = mechanism.compose(num_compositions=10)
            >>> print(f"10次查询后总隐私预算: ({total_eps}, {total_delta})")
        """
        if not isinstance(num_compositions, int) or num_compositions <= 0:
            raise ValueError(
                f"查询次数必须为正整数，当前值: {num_compositions}"
            )
        
        eps = epsilon_per_query if epsilon_per_query is not None else self._epsilon
        total_epsilon = num_compositions * eps
        
        return (total_epsilon, 0.0)
    
    def variance(self, epsilon: Optional[float] = None) -> float:
        """
        计算拉普拉斯噪声的方差
        
        数学公式:
            Var[Lap(μ, b)] = 2b² = 2(Δf/ε)²
        
        参数:
            epsilon (Optional[float]): 指定的隐私预算
        
        返回:
            float: 噪声方差
        
        示例:
            >>> mechanism = LaplaceMechanism(epsilon=1.0, sensitivity=1.0)
            >>> var = mechanism.variance()
            >>> print(f"噪声方差: {var}")  # 输出: 2.0
        """
        eps = epsilon if epsilon is not None else self._epsilon
        scale = self._sensitivity / eps
        return 2.0 * (scale ** 2)
    
    def confidence_interval(
        self,
        confidence: float = 0.95,
        epsilon: Optional[float] = None
    ) -> float:
        """
        计算噪声的置信区间半径
        
        给定置信水平，计算噪声值落在该区间内的边界。
        
        数学原理:
            拉普拉斯分布的累积分布函数为:
                F(x) = 0.5 * exp(x/b)  当 x < 0
                F(x) = 1 - 0.5 * exp(-x/b)  当 x ≥ 0
            
            对于置信水平 α，区间半径 r 满足:
                P(|η| ≤ r) = α
                r = -b * ln(1 - α)
        
        参数:
            confidence (float): 置信水平，必须在 (0, 1) 区间内
                - 默认为 0.95，表示 95% 置信区间
            epsilon (Optional[float]): 指定的隐私预算
        
        返回:
            float: 置信区间半径
        
        异常:
            ValueError: 当 confidence 不在 (0, 1) 区间内时抛出
        
        示例:
            >>> mechanism = LaplaceMechanism(epsilon=1.0, sensitivity=1.0)
            >>> radius = mechanism.confidence_interval(confidence=0.95)
            >>> print(f"95% 置信区间半径: ±{radius:.4f}")
        """
        if not 0 < confidence < 1:
            raise ValueError(
                f"置信水平必须在 (0, 1) 区间内，当前值: {confidence}"
            )
        
        eps = epsilon if epsilon is not None else self._epsilon
        scale = self._sensitivity / eps
        
        # 计算置信区间半径
        # P(|η| ≤ r) = confidence
        # r = -b * ln(1 - confidence)
        radius = -scale * np.log(1 - confidence)
        
        return float(radius)
    
    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        return (
            f"LaplaceMechanism("
            f"epsilon={self._epsilon}, "
            f"sensitivity={self._sensitivity}, "
            f"scale={self._scale:.4f})"
        )
    
    def __str__(self) -> str:
        """返回对象的可读字符串"""
        return (
            f"拉普拉斯机制 | "
            f"ε={self._epsilon}, "
            f"Δf={self._sensitivity}, "
            f"b={self._scale:.4f}"
        )
