"""
隐私预算管理模块

本模块提供隐私预算的跟踪、管理和审计功能，
确保差分隐私应用在使用过程中不超出预设的隐私预算限制。

主要组件:
    - PrivacyBudgetAccountant: 隐私预算会计类
        - 跟踪累积隐私预算消耗
        - 支持多种组合方法
        - 提供预算预警和限制功能

功能特性:
    - 实时预算跟踪
    - 预算上限控制
    - 多种组合定理支持
    - 详细的审计日志

使用示例:
    >>> from differential_privacy.budget import PrivacyBudgetAccountant
    >>> accountant = PrivacyBudgetAccountant(
    ...     epsilon_budget=10.0,
    ...     delta_budget=1e-5
    ... )
    >>> 
    >>> # 添加隐私消耗
    >>> if accountant.check_budget(epsilon=0.1, delta=1e-6):
    ...     accountant.spend(epsilon=0.1, delta=1e-6)
    ...     # 执行差分隐私查询
    ... else:
    ...     print("预算不足")
    >>> 
    >>> # 查看剩余预算
    >>> remaining = accountant.get_remaining_budget()
    >>> print(f"剩余预算: ε={remaining['epsilon']:.2f}, δ={remaining['delta']:.2e}")

数学基础:
    隐私预算会计基于差分隐私的组合定理，
    精确跟踪多个查询累积的隐私损失。

作者: IP4Move Team
版本: 1.0.5
"""

from .accountant import PrivacyBudgetAccountant

__all__ = [
    "PrivacyBudgetAccountant",
]

__version__ = "1.0.5"
