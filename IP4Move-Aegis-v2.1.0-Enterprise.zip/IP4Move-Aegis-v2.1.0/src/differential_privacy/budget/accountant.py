"""
隐私预算会计 (Privacy Budget Accountant)

隐私预算会计是差分隐私系统中的核心组件，负责跟踪和管理隐私预算的消耗。
它确保系统在使用过程中不会超出预设的隐私预算限制，并提供详细的审计日志。

数学原理:
    隐私预算会计基于差分隐私的组合定理工作：
    
    1. 基本组合定理:
        k 次 (ε, δ)-DP 查询组合后满足 (kε, kδ)-DP
    
    2. 高级组合定理:
        k 次 (ε, δ)-DP 查询组合后满足 (ε', kδ + δ')-DP
        其中 ε' = √(2k * ln(1/δ')) * ε + k * ε * (e^ε - 1) / (e^ε + 1)
    
    3. Rényi 差分隐私组合:
        k 次 (α, ε_RDP)-RDP 查询组合后满足 (α, k * ε_RDP)-RDP
        然后转换为 (ε, δ)-DP

功能特性:
    - 实时跟踪累积隐私损失
    - 支持多种组合方法（基本、高级、RDP）
    - 预算预警和硬限制
    - 详细的审计日志
    - 支持预算重置和回滚

使用场景:
    - 交互式数据查询系统
    - 差分隐私机器学习训练
    - 隐私保护数据分析管道
    - 任何需要跟踪隐私消耗的应用

参考:
    Dwork, C., & Roth, A. (2014). The Algorithmic Foundations of Differential Privacy.
    Mironov, I. (2017). Rényi Differential Privacy.
"""

import numpy as np
from typing import List, Tuple, Optional, Dict, Any, Union
from datetime import datetime
from enum import Enum
import warnings


class CompositionMethod(Enum):
    """组合方法枚举"""
    BASIC = "basic"           # 基本组合定理
    ADVANCED = "advanced"     # 高级组合定理
    RDP = "rdp"               # Rényi 差分隐私


class BudgetEntry:
    """
    预算消耗记录条目
    
    记录单次隐私预算消耗的详细信息。
    """
    
    def __init__(
        self,
        epsilon: float,
        delta: float,
        mechanism_type: str,
        description: Optional[str] = None,
        timestamp: Optional[datetime] = None
    ) -> None:
        """
        初始化预算记录条目
        
        参数:
            epsilon (float): 消耗的 ε 预算
            delta (float): 消耗的 δ 预算
            mechanism_type (str): 机制类型
            description (Optional[str]): 描述信息
            timestamp (Optional[datetime]): 时间戳
        """
        self.epsilon = epsilon
        self.delta = delta
        self.mechanism_type = mechanism_type
        self.description = description or ""
        self.timestamp = timestamp or datetime.now()
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'epsilon': self.epsilon,
            'delta': self.delta,
            'mechanism_type': self.mechanism_type,
            'description': self.description,
            'timestamp': self.timestamp.isoformat()
        }
    
    def __repr__(self) -> str:
        return (
            f"BudgetEntry(ε={self.epsilon}, δ={self.delta:.2e}, "
            f"type={self.mechanism_type})"
        )


class PrivacyBudgetAccountant:
    """
    隐私预算会计类
    
    负责跟踪和管理隐私预算的消耗，确保不超出预设的预算限制。
    支持多种组合方法和详细的审计日志。
    
    属性:
        epsilon_budget (float): 总 ε 预算
        delta_budget (float): 总 δ 预算
        epsilon_spent (float): 已消耗的 ε 预算
        delta_spent (float): 已消耗的 δ 预算
        composition_method (CompositionMethod): 使用的组合方法
        
    示例:
        >>> accountant = PrivacyBudgetAccountant(
        ...     epsilon_budget=10.0,
        ...     delta_budget=1e-5,
        ...     composition_method=CompositionMethod.RDP
        ... )
        >>> 
        >>> # 检查并消耗预算
        >>> if accountant.check_budget(epsilon=0.1, delta=1e-6):
        ...     accountant.spend(
        ...         epsilon=0.1,
        ...         delta=1e-6,
        ...         mechanism_type="Laplace",
        ...         description="计数查询"
        ...     )
        ...     # 执行查询
        >>> 
        >>> # 查看预算状态
        >>> status = accountant.get_budget_status()
        >>> print(f"剩余预算: ε={status['remaining_epsilon']:.2f}")
    """
    
    def __init__(
        self,
        epsilon_budget: float,
        delta_budget: float,
        composition_method: CompositionMethod = CompositionMethod.BASIC,
        warning_threshold: float = 0.8,
        hard_limit: bool = True
    ) -> None:
        """
        初始化隐私预算会计
        
        参数:
            epsilon_budget (float): 总 ε 预算，必须为正数
            delta_budget (float): 总 δ 预算，必须在 [0, 1) 区间内
            composition_method (CompositionMethod): 组合方法
                - BASIC: 基本组合定理（线性相加）
                - ADVANCED: 高级组合定理（更紧的上界）
                - RDP: Rényi 差分隐私（最紧的上界）
            warning_threshold (float): 预算警告阈值（0-1之间）
                - 当预算使用超过此阈值时发出警告
            hard_limit (bool): 是否启用硬限制
                - True: 超出预算时抛出异常
                - False: 仅发出警告
        
        异常:
            ValueError: 当参数不合法时抛出
        
        注意:
            预算的选择需要在隐私保护和数据效用之间权衡。
            一般建议 epsilon_budget ≤ 10，delta_budget ≤ 1/n²（n 为数据集大小）。
        """
        # 参数验证
        if epsilon_budget <= 0:
            raise ValueError(f"ε 预算必须为正数，当前值: {epsilon_budget}")
        if not 0 <= delta_budget < 1:
            raise ValueError(f"δ 预算必须在 [0, 1) 区间内，当前值: {delta_budget}")
        if not 0 < warning_threshold <= 1:
            raise ValueError(
                f"警告阈值必须在 (0, 1] 区间内，当前值: {warning_threshold}"
            )
        
        self._epsilon_budget: float = float(epsilon_budget)
        self._delta_budget: float = float(delta_budget)
        self._composition_method: CompositionMethod = composition_method
        self._warning_threshold: float = warning_threshold
        self._hard_limit: bool = hard_limit
        
        # 初始化预算消耗
        self._epsilon_spent: float = 0.0
        self._delta_spent: float = 0.0
        
        # 审计日志
        self._budget_history: List[BudgetEntry] = []
        
        # RDP 专用数据（当使用 RDP 组合时）
        self._rdp_orders: List[float] = [
            1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 7, 8, 9, 10,
            12, 14, 16, 18, 20, 25, 30, 40, 50, 60, 80, 100
        ]
        self._rdp_epsilon: Dict[float, float] = {
            alpha: 0.0 for alpha in self._rdp_orders
        }
        
        # 高级组合专用数据
        self._advanced_composition_epsilon: float = 0.0
        self._advanced_composition_delta: float = 0.0
        self._num_compositions: int = 0
    
    @property
    def epsilon_budget(self) -> float:
        """获取总 ε 预算"""
        return self._epsilon_budget
    
    @property
    def delta_budget(self) -> float:
        """获取总 δ 预算"""
        return self._delta_budget
    
    @property
    def epsilon_spent(self) -> float:
        """获取已消耗的 ε 预算"""
        return self._epsilon_spent
    
    @property
    def delta_spent(self) -> float:
        """获取已消耗的 δ 预算"""
        return self._delta_spent
    
    @property
    def epsilon_remaining(self) -> float:
        """获取剩余的 ε 预算"""
        return self._epsilon_budget - self._epsilon_spent
    
    @property
    def delta_remaining(self) -> float:
        """获取剩余的 δ 预算"""
        return self._delta_budget - self._delta_spent
    
    @property
    def composition_method(self) -> CompositionMethod:
        """获取当前使用的组合方法"""
        return self._composition_method
    
    def _update_budget_basic(
        self,
        epsilon: float,
        delta: float
    ) -> Tuple[float, float]:
        """
        使用基本组合定理更新预算
        
        数学公式:
            ε_total = Σ ε_i
            δ_total = Σ δ_i
        
        参数:
            epsilon (float): 新消耗的 ε
            delta (float): 新消耗的 δ
        
        返回:
            Tuple[float, float]: (总 ε, 总 δ)
        """
        self._epsilon_spent += epsilon
        self._delta_spent += delta
        return (self._epsilon_spent, self._delta_spent)
    
    def _update_budget_advanced(
        self,
        epsilon: float,
        delta: float
    ) -> Tuple[float, float]:
        """
        使用高级组合定理更新预算
        
        数学公式:
            对于 k 次查询，选择 δ' = δ_budget / 2
            ε' = √(2k * ln(1/δ')) * ε_max + k * ε_max * (e^ε_max - 1) / (e^ε_max + 1)
            δ' = k * δ + δ'
        
        参数:
            epsilon (float): 单次查询的 ε
            delta (float): 单次查询的 δ
        
        返回:
            Tuple[float, float]: (组合后的 ε, 组合后的 δ)
        """
        self._num_compositions += 1
        
        # 假设所有查询使用相同的 ε 和 δ
        # 实际应用中可能需要更复杂的跟踪
        delta_prime = self._delta_budget / 2 if self._delta_budget > 0 else 1e-10
        
        sqrt_term = np.sqrt(2 * self._num_compositions * np.log(1 / delta_prime))
        epsilon_composed = (
            sqrt_term * epsilon +
            self._num_compositions * epsilon * (np.exp(epsilon) - 1) / (np.exp(epsilon) + 1)
        )
        delta_composed = self._num_compositions * delta + delta_prime
        
        self._epsilon_spent = epsilon_composed
        self._delta_spent = delta_composed
        
        return (epsilon_composed, delta_composed)
    
    def _update_budget_rdp(
        self,
        epsilon: float,
        delta: float,
        mechanism_type: str = "generic"
    ) -> Tuple[float, float]:
        """
        使用 Rényi 差分隐私更新预算
        
        数学公式:
            对于高斯机制: ε_RDP(α) = α / (2σ²)
            对于拉普拉斯机制: ε_RDP(α) ≈ ε² * α / 2
            
            转换到 (ε, δ)-DP:
            ε = min_α {ε_RDP(α) + log(1/δ)/(α-1)}
        
        参数:
            epsilon (float): 机制的 ε 参数
            delta (float): 机制的 δ 参数
            mechanism_type (str): 机制类型
        
        返回:
            Tuple[float, float]: (转换后的 ε, δ)
        """
        # 根据机制类型更新 RDP 参数
        if mechanism_type.lower() in ["gaussian", "高斯"]:
            # 从 (ε, δ)-DP 反推高斯噪声的标准差
            # σ = √(2 * ln(1.25/δ)) / ε
            if delta > 0:
                sigma = np.sqrt(2 * np.log(1.25 / delta)) / epsilon
                for alpha in self._rdp_orders:
                    self._rdp_epsilon[alpha] += alpha / (2 * sigma ** 2)
            else:
                # 纯 DP 情况，使用近似
                for alpha in self._rdp_orders:
                    self._rdp_epsilon[alpha] += epsilon ** 2 * alpha / 2
        
        elif mechanism_type.lower() in ["laplace", "拉普拉斯"]:
            # 拉普拉斯机制的 RDP 上界
            for alpha in self._rdp_orders:
                self._rdp_epsilon[alpha] += epsilon ** 2 * alpha / 2
        
        else:
            # 通用转换：假设为 (ε, δ)-DP
            for alpha in self._rdp_orders:
                self._rdp_epsilon[alpha] += epsilon + np.log(1 / max(delta, 1e-10)) / (alpha - 1)
        
        # 转换为 (ε, δ)-DP
        target_delta = self._delta_budget if self._delta_budget > 0 else 1e-10
        min_epsilon = float('inf')
        
        for alpha in self._rdp_orders:
            eps = self._rdp_epsilon[alpha] + np.log(1 / target_delta) / (alpha - 1)
            min_epsilon = min(min_epsilon, eps)
        
        self._epsilon_spent = min_epsilon
        self._delta_spent = target_delta
        
        return (min_epsilon, target_delta)
    
    def check_budget(
        self,
        epsilon: float,
        delta: float = 0.0
    ) -> bool:
        """
        检查是否有足够的预算
        
        参数:
            epsilon (float): 需要消耗的 ε 预算
            delta (float): 需要消耗的 δ 预算
        
        返回:
            bool: 是否有足够的预算
        
        示例:
            >>> if accountant.check_budget(epsilon=0.1, delta=1e-6):
            ...     # 执行查询
            ...     pass
        """
        if epsilon < 0 or delta < 0:
            return False
        
        # 根据组合方法计算新的预算消耗
        if self._composition_method == CompositionMethod.BASIC:
            new_epsilon = self._epsilon_spent + epsilon
            new_delta = self._delta_spent + delta
        
        elif self._composition_method == CompositionMethod.ADVANCED:
            # 简化检查：假设线性增长
            new_epsilon = self._epsilon_spent + epsilon * 1.5  # 保守估计
            new_delta = self._delta_spent + delta
        
        elif self._composition_method == CompositionMethod.RDP:
            # 简化检查
            new_epsilon = self._epsilon_spent + epsilon * 1.2  # 保守估计
            new_delta = self._delta_spent + delta
        
        else:
            new_epsilon = self._epsilon_spent + epsilon
            new_delta = self._delta_spent + delta
        
        return (new_epsilon <= self._epsilon_budget and 
                new_delta <= self._delta_budget)
    
    def spend(
        self,
        epsilon: float,
        delta: float = 0.0,
        mechanism_type: str = "generic",
        description: Optional[str] = None
    ) -> Tuple[float, float]:
        """
        消耗隐私预算
        
        参数:
            epsilon (float): 消耗的 ε 预算
            delta (float): 消耗的 δ 预算
            mechanism_type (str): 机制类型
            description (Optional[str]): 描述信息
        
        返回:
            Tuple[float, float]: (剩余 ε, 剩余 δ)
        
        异常:
            ValueError: 当预算不足且启用硬限制时抛出
        
        示例:
            >>> remaining = accountant.spend(
            ...     epsilon=0.1,
            ...     delta=1e-6,
            ...     mechanism_type="Laplace",
            ...     description="计数查询"
            ... )
        """
        if epsilon < 0 or delta < 0:
            raise ValueError("消耗的预算必须为非负数")
        
        # 检查预算
        if not self.check_budget(epsilon, delta):
            message = (
                f"隐私预算不足: 需要 (ε={epsilon}, δ={delta:.2e}), "
                f"剩余 (ε={self.epsilon_remaining:.4f}, δ={self.delta_remaining:.2e})"
            )
            if self._hard_limit:
                raise ValueError(message)
            else:
                warnings.warn(message, UserWarning)
        
        # 更新预算
        if self._composition_method == CompositionMethod.BASIC:
            self._update_budget_basic(epsilon, delta)
        
        elif self._composition_method == CompositionMethod.ADVANCED:
            self._update_budget_advanced(epsilon, delta)
        
        elif self._composition_method == CompositionMethod.RDP:
            self._update_budget_rdp(epsilon, delta, mechanism_type)
        
        # 记录审计日志
        entry = BudgetEntry(
            epsilon=epsilon,
            delta=delta,
            mechanism_type=mechanism_type,
            description=description
        )
        self._budget_history.append(entry)
        
        # 检查警告阈值
        epsilon_usage = self._epsilon_spent / self._epsilon_budget
        if epsilon_usage >= self._warning_threshold:
            warnings.warn(
                f"隐私预算警告: 已使用 {epsilon_usage*100:.1f}% 的 ε 预算",
                UserWarning
            )
        
        return (self.epsilon_remaining, self.delta_remaining)
    
    def get_remaining_budget(self) -> Dict[str, float]:
        """
        获取剩余预算
        
        返回:
            Dict[str, float]: 包含剩余预算的字典
                - epsilon: 剩余 ε 预算
                - delta: 剩余 δ 预算
                - epsilon_ratio: ε 预算使用比例
                - delta_ratio: δ 预算使用比例
        
        示例:
            >>> remaining = accountant.get_remaining_budget()
            >>> print(f"剩余: ε={remaining['epsilon']:.2f}, δ={remaining['delta']:.2e}")
        """
        return {
            'epsilon': self.epsilon_remaining,
            'delta': self.delta_remaining,
            'epsilon_ratio': self._epsilon_spent / self._epsilon_budget,
            'delta_ratio': (self._delta_spent / self._delta_budget 
                          if self._delta_budget > 0 else 0.0)
        }
    
    def get_budget_status(self) -> Dict[str, Any]:
        """
        获取完整的预算状态
        
        返回:
            Dict[str, Any]: 包含完整预算状态的字典
        
        示例:
            >>> status = accountant.get_budget_status()
            >>> print(status)
        """
        remaining = self.get_remaining_budget()
        
        return {
            'epsilon_budget': self._epsilon_budget,
            'delta_budget': self._delta_budget,
            'epsilon_spent': self._epsilon_spent,
            'delta_spent': self._delta_spent,
            'epsilon_remaining': remaining['epsilon'],
            'delta_remaining': remaining['delta'],
            'epsilon_usage_ratio': remaining['epsilon_ratio'],
            'delta_usage_ratio': remaining['delta_ratio'],
            'composition_method': self._composition_method.value,
            'num_queries': len(self._budget_history),
            'is_exhausted': (self.epsilon_remaining <= 0 or 
                           (self._delta_budget > 0 and self.delta_remaining <= 0))
        }
    
    def get_budget_history(self) -> List[Dict[str, Any]]:
        """
        获取预算消耗历史
        
        返回:
            List[Dict[str, Any]]: 预算消耗记录列表
        
        示例:
            >>> history = accountant.get_budget_history()
            >>> for entry in history:
            ...     print(f"{entry['mechanism_type']}: ε={entry['epsilon']}")
        """
        return [entry.to_dict() for entry in self._budget_history]
    
    def reset(self) -> None:
        """
        重置预算会计
        
        清空所有预算消耗记录，恢复到初始状态。
        
        示例:
            >>> accountant.reset()
        """
        self._epsilon_spent = 0.0
        self._delta_spent = 0.0
        self._budget_history.clear()
        self._num_compositions = 0
        self._advanced_composition_epsilon = 0.0
        self._advanced_composition_delta = 0.0
        
        # 重置 RDP 数据
        for alpha in self._rdp_orders:
            self._rdp_epsilon[alpha] = 0.0
    
    def set_composition_method(self, method: CompositionMethod) -> None:
        """
        更改组合方法
        
        注意：更改组合方法会重置预算计算。
        
        参数:
            method (CompositionMethod): 新的组合方法
        
        示例:
            >>> accountant.set_composition_method(CompositionMethod.RDP)
        """
        self._composition_method = method
        self.reset()
    
    def estimate_remaining_queries(
        self,
        epsilon_per_query: float,
        delta_per_query: float = 0.0
    ) -> int:
        """
        估计剩余可执行的查询次数
        
        参数:
            epsilon_per_query (float): 每次查询的 ε 消耗
            delta_per_query (float): 每次查询的 δ 消耗
        
        返回:
            int: 估计的剩余查询次数
        
        示例:
            >>> remaining = accountant.estimate_remaining_queries(
            ...     epsilon_per_query=0.1,
            ...     delta_per_query=1e-6
            ... )
            >>> print(f"还可执行约 {remaining} 次查询")
        """
        if epsilon_per_query <= 0:
            return 0
        
        remaining_epsilon = self.epsilon_remaining
        remaining_delta = self.delta_remaining
        
        # 根据组合方法调整估计
        if self._composition_method == CompositionMethod.BASIC:
            epsilon_estimate = int(remaining_epsilon / epsilon_per_query)
        
        elif self._composition_method == CompositionMethod.ADVANCED:
            # 高级组合允许更多查询
            epsilon_estimate = int(remaining_epsilon / (epsilon_per_query * 0.7))
        
        elif self._composition_method == CompositionMethod.RDP:
            # RDP 通常允许最多查询
            epsilon_estimate = int(remaining_epsilon / (epsilon_per_query * 0.5))
        
        else:
            epsilon_estimate = int(remaining_epsilon / epsilon_per_query)
        
        # 考虑 δ 预算
        if delta_per_query > 0 and self._delta_budget > 0:
            delta_estimate = int(remaining_delta / delta_per_query)
            epsilon_estimate = min(epsilon_estimate, delta_estimate)
        
        return max(0, epsilon_estimate)
    
    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        return (
            f"PrivacyBudgetAccountant("
            f"budget=({self._epsilon_budget}, {self._delta_budget:.2e}), "
            f"spent=({self._epsilon_spent:.4f}, {self._delta_spent:.2e}), "
            f"method={self._composition_method.value})"
        )
    
    def __str__(self) -> str:
        """返回对象的可读字符串"""
        remaining = self.get_remaining_budget()
        return (
            f"隐私预算会计 | "
            f"预算: ε={self._epsilon_budget}, δ={self._delta_budget:.2e} | "
            f"已用: ε={self._epsilon_spent:.4f}({remaining['epsilon_ratio']*100:.1f}%), "
            f"δ={self._delta_spent:.2e} | "
            f"方法: {self._composition_method.value}"
        )
