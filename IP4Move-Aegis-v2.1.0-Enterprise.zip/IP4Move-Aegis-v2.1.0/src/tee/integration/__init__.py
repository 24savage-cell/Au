"""
TEE集成子模块

包含第三方库集成：
- Graphene-SGX集成
- OpenEnclave集成
"""

from .graphenelib import GrapheneSGX
from .openenclave import OpenEnclave

__all__ = [
    "GrapheneSGX",
    "OpenEnclave",
]
