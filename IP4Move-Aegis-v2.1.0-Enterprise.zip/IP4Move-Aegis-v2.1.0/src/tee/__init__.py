"""
可信执行环境(TEE)集成模块

提供与各种TEE技术的集成支持：
- Intel SGX
- AMD SEV
- ARM TrustZone

主要组件:
    - providers: TEE提供者实现
    - enclave: Enclave管理
    - applications: TEE应用
    - integration: 第三方库集成
"""

from .providers.intel_sgx import IntelSGXProvider
from .providers.amd_sev import AMDSEVProvider
from .providers.arm_trustzone import ARMTrustZoneProvider
from .enclave.enclave_manager import EnclaveManager
from .enclave.sealed_storage import SealedStorage
from .enclave.remote_attestation import RemoteAttestation

__version__ = "1.0.0"
__author__ = "IP4Move Team"

__all__ = [
    # 提供者
    "IntelSGXProvider",
    "AMDSEVProvider",
    "ARMTrustZoneProvider",
    # Enclave管理
    "EnclaveManager",
    "SealedStorage",
    "RemoteAttestation",
]
