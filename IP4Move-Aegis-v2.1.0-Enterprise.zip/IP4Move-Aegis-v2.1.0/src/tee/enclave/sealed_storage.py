"""
密封存储模块

提供Enclave内数据的密封存储功能，确保数据持久化和安全。
"""

import logging
import hashlib
import json
from typing import Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class SealedData:
    """密封数据结构"""
    ciphertext: bytes
    iv: bytes
    tag: bytes
    policy: Dict[str, Any]
    timestamp: datetime


class SealedStorage:
    """
    密封存储
    
    在Enclave内加密数据，可安全存储到外部存储。
    支持基于Enclave身份的访问控制。
    
    示例:
        >>> storage = SealedStorage(enclave_id="enclave_001")
        >>> 
        >>> # 密封数据
        >>> data = b"sensitive data"
        >>> sealed = storage.seal(data, policy={"debug": False})
        >>> 
        >>> # 解封数据
        >>> unsealed = storage.unseal(sealed)
    """
    
    def __init__(self, enclave_id: str):
        """
        初始化密封存储
        
        Args:
            enclave_id: Enclave ID
        """
        self.enclave_id = enclave_id
        self.sealed_items: Dict[str, SealedData] = {}
        
        logger.info(f"初始化密封存储: {enclave_id}")
    
    def seal(self, plaintext: bytes, 
             policy: Optional[Dict[str, Any]] = None) -> bytes:
        """
        密封数据
        
        Args:
            plaintext: 明文数据
            policy: 密封策略
            
        Returns:
            密封后的数据
        """
        if policy is None:
            policy = {}
        
        # 派生密封密钥（模拟）
        key = self._derive_sealing_key()
        
        # 加密数据（模拟AES-GCM）
        iv = self._generate_iv()
        ciphertext = self._encrypt(plaintext, key, iv)
        tag = self._compute_tag(ciphertext, key)
        
        sealed_data = SealedData(
            ciphertext=ciphertext,
            iv=iv,
            tag=tag,
            policy=policy,
            timestamp=datetime.now()
        )
        
        # 序列化
        item_id = hashlib.sha256(ciphertext).hexdigest()[:16]
        self.sealed_items[item_id] = sealed_data
        
        logger.debug(f"数据已密封: {item_id}")
        
        return self._serialize(sealed_data)
    
    def unseal(self, sealed_blob: bytes) -> Optional[bytes]:
        """
        解封数据
        
        Args:
            sealed_blob: 密封数据
            
        Returns:
            明文数据
        """
        try:
            sealed_data = self._deserialize(sealed_blob)
            
            # 验证策略
            if not self._check_policy(sealed_data.policy):
                logger.warning("密封策略检查失败")
                return None
            
            # 派生密钥
            key = self._derive_sealing_key()
            
            # 验证标签
            computed_tag = self._compute_tag(sealed_data.ciphertext, key)
            if computed_tag != sealed_data.tag:
                logger.warning("标签验证失败")
                return None
            
            # 解密
            plaintext = self._decrypt(
                sealed_data.ciphertext, 
                key, 
                sealed_data.iv
            )
            
            logger.debug("数据解封成功")
            return plaintext
            
        except Exception as e:
            logger.error(f"解封失败: {e}")
            return None
    
    def _derive_sealing_key(self) -> bytes:
        """
        派生密封密钥
        
        Returns:
            密钥
        """
        # 基于Enclave ID和平台信息派生密钥
        key_material = f"{self.enclave_id}_sealing_key".encode()
        return hashlib.sha256(key_material).digest()
    
    def _generate_iv(self) -> bytes:
        """
        生成初始化向量
        
        Returns:
            IV
        """
        import os
        return os.urandom(12)  # 96-bit IV for GCM
    
    def _encrypt(self, plaintext: bytes, key: bytes, iv: bytes) -> bytes:
        """
        加密数据（模拟）
        
        Args:
            plaintext: 明文
            key: 密钥
            iv: 初始化向量
            
        Returns:
            密文
        """
        # 简化的XOR加密（实际应使用AES-GCM）
        return bytes(p ^ key[i % len(key)] for i, p in enumerate(plaintext))
    
    def _decrypt(self, ciphertext: bytes, key: bytes, iv: bytes) -> bytes:
        """
        解密数据（模拟）
        
        Args:
            ciphertext: 密文
            key: 密钥
            iv: 初始化向量
            
        Returns:
            明文
        """
        # XOR解密
        return bytes(c ^ key[i % len(key)] for i, c in enumerate(ciphertext))
    
    def _compute_tag(self, ciphertext: bytes, key: bytes) -> bytes:
        """
        计算认证标签
        
        Args:
            ciphertext: 密文
            key: 密钥
            
        Returns:
            标签
        """
        return hashlib.sha256(ciphertext + key).digest()[:16]
    
    def _check_policy(self, policy: Dict[str, Any]) -> bool:
        """
        检查密封策略
        
        Args:
            policy: 策略
            
        Returns:
            是否通过
        """
        # 检查debug策略
        if policy.get("debug") == False:
            # 实际应检查Enclave是否在debug模式
            pass
        
        return True
    
    def _serialize(self, sealed_data: SealedData) -> bytes:
        """
        序列化密封数据
        
        Args:
            sealed_data: 密封数据
            
        Returns:
            序列化数据
        """
        data = {
            'ciphertext': sealed_data.ciphertext.hex(),
            'iv': sealed_data.iv.hex(),
            'tag': sealed_data.tag.hex(),
            'policy': sealed_data.policy,
            'timestamp': sealed_data.timestamp.isoformat()
        }
        return json.dumps(data).encode()
    
    def _deserialize(self, blob: bytes) -> SealedData:
        """
        反序列化密封数据
        
        Args:
            blob: 序列化数据
            
        Returns:
            密封数据
        """
        data = json.loads(blob.decode())
        return SealedData(
            ciphertext=bytes.fromhex(data['ciphertext']),
            iv=bytes.fromhex(data['iv']),
            tag=bytes.fromhex(data['tag']),
            policy=data['policy'],
            timestamp=datetime.fromisoformat(data['timestamp'])
        )
