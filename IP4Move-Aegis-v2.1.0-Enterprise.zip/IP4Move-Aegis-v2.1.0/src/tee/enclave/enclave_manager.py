"""
Enclave管理器

管理Enclave的生命周期：创建、初始化、运行、销毁。
"""

import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class EnclaveStatus(Enum):
    """Enclave状态"""
    CREATED = "created"
    INITIALIZED = "initialized"
    RUNNING = "running"
    PAUSED = "paused"
    DESTROYED = "destroyed"


@dataclass
class EnclaveConfig:
    """Enclave配置"""
    enclave_path: str
    memory_size: int
    debug: bool = False
    enable_kss: bool = False  # Key Separation and Sharing


class EnclaveManager:
    """
    Enclave管理器
    
    统一管理不同TEE技术的Enclave。
    
    示例:
        >>> manager = EnclaveManager()
        >>> 
        >>> # 创建Enclave
        >>> config = EnclaveConfig(
        ...     enclave_path="/path/to/enclave.signed.so",
        ...     memory_size=16*1024*1024
        ... )
        >>> enclave = manager.create_enclave(config)
        >>> 
        >>> # 初始化
        >>> manager.initialize_enclave(enclave.id)
        >>> 
        >>> # 销毁
        >>> manager.destroy_enclave(enclave.id)
    """
    
    def __init__(self):
        """初始化Enclave管理器"""
        self.enclaves: Dict[str, Dict[str, Any]] = {}
        self.providers: Dict[str, Any] = {}
        
        logger.info("初始化Enclave管理器")
    
    def register_provider(self, name: str, provider: Any):
        """
        注册TEE提供者
        
        Args:
            name: 提供者名称
            provider: 提供者实例
        """
        self.providers[name] = provider
        logger.info(f"注册提供者: {name}")
    
    def create_enclave(self, config: EnclaveConfig,
                       provider_name: str = "sgx") -> Any:
        """
        创建Enclave
        
        Args:
            config: Enclave配置
            provider_name: 提供者名称
            
        Returns:
            Enclave实例
        """
        if provider_name not in self.providers:
            raise ValueError(f"提供者不存在: {provider_name}")
        
        provider = self.providers[provider_name]
        
        if provider_name == "sgx":
            enclave = provider.create_enclave(
                config.enclave_path, 
                config.debug
            )
        elif provider_name == "sev":
            enclave = provider.create_vm(config.memory_size)
        else:
            raise ValueError(f"不支持的提供者: {provider_name}")
        
        self.enclaves[enclave.enclave_id if hasattr(enclave, 'enclave_id') else enclave.vm_id] = {
            'enclave': enclave,
            'provider': provider_name,
            'status': EnclaveStatus.CREATED
        }
        
        return enclave
    
    def initialize_enclave(self, enclave_id: str) -> bool:
        """
        初始化Enclave
        
        Args:
            enclave_id: Enclave ID
            
        Returns:
            是否成功
        """
        if enclave_id not in self.enclaves:
            return False
        
        self.enclaves[enclave_id]['status'] = EnclaveStatus.INITIALIZED
        logger.info(f"Enclave初始化成功: {enclave_id}")
        return True
    
    def destroy_enclave(self, enclave_id: str) -> bool:
        """
        销毁Enclave
        
        Args:
            enclave_id: Enclave ID
            
        Returns:
            是否成功
        """
        if enclave_id not in self.enclaves:
            return False
        
        info = self.enclaves[enclave_id]
        provider = self.providers.get(info['provider'])
        
        if provider:
            if info['provider'] == 'sgx':
                provider.destroy_enclave(enclave_id)
        
        del self.enclaves[enclave_id]
        logger.info(f"Enclave销毁成功: {enclave_id}")
        return True
    
    def get_enclave_status(self, enclave_id: str) -> Optional[EnclaveStatus]:
        """
        获取Enclave状态
        
        Args:
            enclave_id: Enclave ID
            
        Returns:
            Enclave状态
        """
        if enclave_id in self.enclaves:
            return self.enclaves[enclave_id]['status']
        return None
    
    def list_enclaves(self) -> List[str]:
        """
        列出所有Enclave
        
        Returns:
            Enclave ID列表
        """
        return list(self.enclaves.keys())
