"""
安全预言机模块

在TEE内安全地获取链下数据。
"""

import logging
import hashlib
import json
from typing import Any, Optional, Dict, Callable
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class OracleData:
    """预言机数据"""
    data: Any
    timestamp: datetime
    source: str
    signature: bytes


class SecureOracle:
    """
    安全预言机
    
    在TEE内安全获取链下数据，提供可验证的数据源。
    
    示例:
        >>> oracle = SecureOracle(enclave_id="enclave_001")
        >>> 
        >>> # 获取外部数据
        >>> data = oracle.fetch_data("https://api.example.com/price")
        >>> print(f"价格: {data.data}")
    """
    
    def __init__(self, enclave_id: str):
        """
        初始化安全预言机
        
        Args:
            enclave_id: Enclave ID
        """
        self.enclave_id = enclave_id
        self.data_sources: Dict[str, Callable] = {}
        self.cache: Dict[str, OracleData] = {}
        
        logger.info(f"初始化安全预言机: {enclave_id}")
    
    def register_source(self, name: str, fetcher: Callable[[], Any]):
        """
        注册数据源
        
        Args:
            name: 数据源名称
            fetcher: 数据获取函数
        """
        self.data_sources[name] = fetcher
        logger.info(f"注册数据源: {name}")
    
    def fetch_data(self, source: str,
                   use_cache: bool = True,
                   cache_duration: int = 60) -> Optional[OracleData]:
        """
        获取数据
        
        Args:
            source: 数据源名称或URL
            use_cache: 是否使用缓存
            cache_duration: 缓存有效期（秒）
            
        Returns:
            预言机数据
        """
        # 检查缓存
        if use_cache and source in self.cache:
            cached = self.cache[source]
            elapsed = (datetime.now() - cached.timestamp).total_seconds()
            if elapsed < cache_duration:
                logger.debug(f"返回缓存数据: {source}")
                return cached
        
        # 获取数据
        try:
            if source in self.data_sources:
                data = self.data_sources[source]()
            else:
                # 模拟HTTP请求
                data = self._simulate_fetch(source)
            
            # 创建OracleData
            oracle_data = OracleData(
                data=data,
                timestamp=datetime.now(),
                source=source,
                signature=self._sign_data(data)
            )
            
            # 缓存
            if use_cache:
                self.cache[source] = oracle_data
            
            logger.info(f"获取数据成功: {source}")
            return oracle_data
            
        except Exception as e:
            logger.error(f"获取数据失败: {source}, {e}")
            return None
    
    def _simulate_fetch(self, url: str) -> Any:
        """
        模拟数据获取
        
        Args:
            url: URL
            
        Returns:
            数据
        """
        # 模拟返回数据
        return {"price": 100.0, "timestamp": datetime.now().isoformat()}
    
    def _sign_data(self, data: Any) -> bytes:
        """
        签名数据
        
        Args:
            data: 数据
            
        Returns:
            签名
        """
        # 模拟签名
        data_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(data_str.encode()).digest()
    
    def verify_data(self, oracle_data: OracleData) -> bool:
        """
        验证预言机数据
        
        Args:
            oracle_data: 预言机数据
            
        Returns:
            是否有效
        """
        expected_signature = self._sign_data(oracle_data.data)
        return oracle_data.signature == expected_signature
