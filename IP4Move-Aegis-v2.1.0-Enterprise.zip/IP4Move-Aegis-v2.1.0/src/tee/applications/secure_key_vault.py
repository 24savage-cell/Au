"""
安全密钥库模块

在TEE内安全地生成、存储、使用和轮换密钥。
"""

import logging
import hashlib
import secrets
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)


class KeyType(Enum):
    """密钥类型"""
    AES = "aes"
    RSA = "rsa"
    ECC = "ecc"
    HMAC = "hmac"


class KeyStatus(Enum):
    """密钥状态"""
    ACTIVE = "active"
    EXPIRED = "expired"
    REVOKED = "revoked"
    ROTATED = "rotated"


@dataclass
class KeyMetadata:
    """密钥元数据"""
    key_id: str
    key_type: KeyType
    created_at: datetime
    expires_at: datetime
    status: KeyStatus
    version: int
    usage_count: int


class SecureKeyVault:
    """
    安全密钥库
    
    在TEE内安全地管理密钥生命周期。
    
    示例:
        >>> vault = SecureKeyVault(enclave_id="enclave_001")
        >>> 
        >>> # 生成密钥
        >>> key_id = vault.generate_key(KeyType.AES, key_size=256)
        >>> 
        >>> # 使用密钥加密
        >>> ciphertext = vault.encrypt(key_id, b"plaintext")
        >>> 
        >>> # 轮换密钥
        >>> new_key_id = vault.rotate_key(key_id)
    """
    
    def __init__(self, enclave_id: str):
        """
        初始化安全密钥库
        
        Args:
            enclave_id: Enclave ID
        """
        self.enclave_id = enclave_id
        self.keys: Dict[str, bytes] = {}
        self.metadata: Dict[str, KeyMetadata] = {}
        
        logger.info(f"初始化安全密钥库: {enclave_id}")
    
    def generate_key(self, key_type: KeyType,
                     key_size: int = 256,
                     expiry_days: int = 365) -> str:
        """
        生成密钥
        
        Args:
            key_type: 密钥类型
            key_size: 密钥大小（比特）
            expiry_days: 过期天数
            
        Returns:
            密钥ID
        """
        key_id = secrets.token_hex(16)
        
        # 生成密钥材料
        key_bytes = secrets.token_bytes(key_size // 8)
        
        self.keys[key_id] = key_bytes
        
        # 创建元数据
        now = datetime.now()
        metadata = KeyMetadata(
            key_id=key_id,
            key_type=key_type,
            created_at=now,
            expires_at=now + timedelta(days=expiry_days),
            status=KeyStatus.ACTIVE,
            version=1,
            usage_count=0
        )
        self.metadata[key_id] = metadata
        
        logger.info(f"生成密钥: {key_id}, 类型={key_type.value}")
        return key_id
    
    def get_key(self, key_id: str) -> Optional[bytes]:
        """
        获取密钥
        
        Args:
            key_id: 密钥ID
            
        Returns:
            密钥材料
        """
        if key_id not in self.keys:
            return None
        
        metadata = self.metadata.get(key_id)
        if metadata:
            if metadata.status != KeyStatus.ACTIVE:
                logger.warning(f"密钥状态异常: {key_id}, {metadata.status}")
                return None
            
            if datetime.now() > metadata.expires_at:
                logger.warning(f"密钥已过期: {key_id}")
                metadata.status = KeyStatus.EXPIRED
                return None
            
            metadata.usage_count += 1
        
        return self.keys[key_id]
    
    def encrypt(self, key_id: str, plaintext: bytes) -> Optional[bytes]:
        """
        使用密钥加密
        
        Args:
            key_id: 密钥ID
            plaintext: 明文
            
        Returns:
            密文
        """
        key = self.get_key(key_id)
        if not key:
            return None
        
        # 简化的XOR加密（实际应使用AES-GCM）
        iv = secrets.token_bytes(16)
        ciphertext = bytes(p ^ key[i % len(key)] for i, p in enumerate(plaintext))
        
        return iv + ciphertext
    
    def decrypt(self, key_id: str, ciphertext: bytes) -> Optional[bytes]:
        """
        使用密钥解密
        
        Args:
            key_id: 密钥ID
            ciphertext: 密文
            
        Returns:
            明文
        """
        key = self.get_key(key_id)
        if not key:
            return None
        
        # 跳过IV
        actual_ciphertext = ciphertext[16:]
        
        # XOR解密
        plaintext = bytes(c ^ key[i % len(key)] for i, c in enumerate(actual_ciphertext))
        
        return plaintext
    
    def rotate_key(self, key_id: str) -> Optional[str]:
        """
        轮换密钥
        
        Args:
            key_id: 旧密钥ID
            
        Returns:
            新密钥ID
        """
        if key_id not in self.keys:
            return None
        
        old_metadata = self.metadata[key_id]
        
        # 生成新密钥
        new_key_id = self.generate_key(
            old_metadata.key_type,
            key_size=len(self.keys[key_id]) * 8
        )
        
        # 更新旧密钥状态
        old_metadata.status = KeyStatus.ROTATED
        
        logger.info(f"密钥轮换: {key_id} -> {new_key_id}")
        return new_key_id
    
    def revoke_key(self, key_id: str) -> bool:
        """
        撤销密钥
        
        Args:
            key_id: 密钥ID
            
        Returns:
            是否成功
        """
        if key_id not in self.keys:
            return False
        
        self.metadata[key_id].status = KeyStatus.REVOKED
        logger.info(f"密钥已撤销: {key_id}")
        return True
    
    def list_keys(self) -> List[KeyMetadata]:
        """
        列出所有密钥
        
        Returns:
            密钥元数据列表
        """
        return list(self.metadata.values())
