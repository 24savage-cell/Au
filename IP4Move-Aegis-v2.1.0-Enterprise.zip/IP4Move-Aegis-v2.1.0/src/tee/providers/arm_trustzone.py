"""
ARM TrustZone提供者实现

提供ARM TrustZone的集成支持。
包括安全世界切换和可信应用管理。
"""

import logging
import hashlib
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class TrustZoneError(Exception):
    """TrustZone错误"""
    pass


class World(Enum):
    """执行世界"""
    NORMAL = "normal"
    SECURE = "secure"


class TAState(Enum):
    """可信应用状态"""
    UNLOADED = "unloaded"
    LOADED = "loaded"
    RUNNING = "running"


@dataclass
class TAInfo:
    """可信应用信息"""
    ta_id: str
    uuid: str
    state: TAState
    memory_size: int


class ARMTrustZoneProvider:
    """
    ARM TrustZone提供者
    
    提供TrustZone安全世界切换和可信应用管理。
    
    示例:
        >>> tz = ARMTrustZoneProvider()
        >>> 
        >>> # 加载可信应用
        >>> ta = tz.load_trusted_app("/path/to/ta.elf")
        >>> 
        >>> # 调用可信应用
        >>> result = tz.invoke_command(ta.ta_id, 0, data)
    """
    
    def __init__(self):
        """初始化TrustZone提供者"""
        self.current_world = World.NORMAL
        self.trusted_apps: Dict[str, TAInfo] = {}
        self.command_handlers: Dict[str, Dict[int, Callable]] = {}
        
        logger.info("初始化ARM TrustZone提供者")
    
    def is_trustzone_available(self) -> bool:
        """
        检查TrustZone是否可用
        
        Returns:
            TrustZone是否可用
        """
        try:
            return True  # 模拟可用
        except Exception:
            return False
    
    def switch_world(self, target_world: World):
        """
        切换执行世界
        
        Args:
            target_world: 目标世界
        """
        if self.current_world != target_world:
            logger.debug(f"切换世界: {self.current_world.value} -> {target_world.value}")
            self.current_world = target_world
    
    def load_trusted_app(self, ta_path: str,
                         memory_size: int = 1024*1024) -> TAInfo:
        """
        加载可信应用
        
        Args:
            ta_path: 可信应用路径
            memory_size: 内存大小
            
        Returns:
            可信应用信息
        """
        logger.info(f"加载可信应用: {ta_path}")
        
        ta_id = hashlib.sha256(ta_path.encode()).hexdigest()[:16]
        uuid = hashlib.md5(ta_path.encode()).hexdigest()
        
        ta_info = TAInfo(
            ta_id=ta_id,
            uuid=uuid,
            state=TAState.LOADED,
            memory_size=memory_size
        )
        
        self.trusted_apps[ta_id] = ta_info
        self.command_handlers[ta_id] = {}
        
        logger.info(f"可信应用加载成功: {ta_id}")
        return ta_info
    
    def invoke_command(self, ta_id: str, command_id: int,
                       data: bytes) -> bytes:
        """
        调用可信应用命令
        
        Args:
            ta_id: 可信应用ID
            command_id: 命令ID
            data: 输入数据
            
        Returns:
            输出数据
        """
        if ta_id not in self.trusted_apps:
            raise TrustZoneError(f"可信应用不存在: {ta_id}")
        
        # 切换到安全世界
        self.switch_world(World.SECURE)
        
        try:
            # 执行命令
            if command_id in self.command_handlers.get(ta_id, {}):
                result = self.command_handlers[ta_id][command_id](data)
            else:
                result = b""
            
            return result
        finally:
            # 切换回正常世界
            self.switch_world(World.NORMAL)
    
    def register_command(self, ta_id: str, command_id: int,
                         handler: Callable[[bytes], bytes]):
        """
        注册命令处理器
        
        Args:
            ta_id: 可信应用ID
            command_id: 命令ID
            handler: 处理函数
        """
        if ta_id not in self.command_handlers:
            self.command_handlers[ta_id] = {}
        
        self.command_handlers[ta_id][command_id] = handler
