"""
客户端安全增强模块 (Client Security Enhancement Module)

本模块提供了客户端层面的安全增强功能，包括：
- 内存加密管理：对客户端内存中的敏感信息进行AES-256-GCM加密存储
- 反调试和反注入保护：检测并防御调试器和代码注入攻击
- 沙箱化运行环境：限制进程权限和资源访问
- 浏览器指纹随机化：生成一致的随机浏览器指纹以保护隐私

This module provides client-side security enhancement features, including
memory encryption management, anti-debug/anti-injection protection, sandboxed
execution environment, and browser fingerprint randomization.
"""

from src.client_security.secure_client import (
    MemoryEncryptionManager,
    AntiDebugProtection,
    SandboxEnvironment,
    BrowserFingerprintRandomizer,
)

__all__ = [
    "MemoryEncryptionManager",
    "AntiDebugProtection",
    "SandboxEnvironment",
    "BrowserFingerprintRandomizer",
]

__version__ = "1.0.0"
__author__ = "IP4Move-Aegis Security Team"
