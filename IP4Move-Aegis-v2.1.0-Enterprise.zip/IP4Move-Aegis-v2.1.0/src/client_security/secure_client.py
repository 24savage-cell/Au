"""
客户端安全增强模块 (Client Security Enhancement Module)

本模块实现了客户端层面的全面安全防护，包含四个核心组件：
1. MemoryEncryptionManager - 内存加密管理器，使用AES-256-GCM加密内存中的敏感数据
2. AntiDebugProtection - 反调试和反注入保护，检测多种调试和注入手段
3. SandboxEnvironment - 沙箱化运行环境，限制进程权限和资源访问
4. BrowserFingerprintRandomizer - 浏览器指纹随机化器，生成一致的随机指纹

This module implements comprehensive client-side security protection with four
core components: memory encryption, anti-debug protection, sandboxed execution,
and browser fingerprint randomization.
"""

import os
import sys
import ctypes
import struct
import signal
import random
import hashlib
import hmac
import logging
import threading
import time
import platform
import resource
import tempfile
from typing import Optional, Dict, List, Set, Tuple, Any, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from contextlib import contextmanager

# 尝试导入cryptography库，用于AES-256-GCM加密
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

logger = logging.getLogger(__name__)

# ============================================================================
# 安全常量定义
# ============================================================================

# 内存加密相关常量
AES_KEY_LENGTH = 32                  # AES-256密钥长度（字节）
AES_NONCE_LENGTH = 12                # GCM模式nonce长度（字节）
MAX_ENCRYPTED_DATA_SIZE = 64 * 1024 * 1024  # 最大加密数据大小（64MB）
MEMORY_REGION_SIZE = 4096            # 内存区域大小（页大小）
MEMORY_WIPE_PASSES = 3               # 内存擦除遍数

# 反调试相关常量
ANTI_DEBUG_CHECK_INTERVAL = 5.0      # 反调试检查间隔（秒）
TRACER_PID_FILE = "/proc/self/status" # Linux TracerPid文件路径
MAX_DEBUG_CHECK_FAILURES = 3         # 最大调试检测失败次数

# 沙箱相关常量
DEFAULT_MAX_CPU_TIME = 300           # 默认最大CPU时间（秒）
DEFAULT_MAX_MEMORY_MB = 512          # 默认最大内存（MB）
DEFAULT_MAX_FILE_DESCRIPTORS = 256   # 默认最大文件描述符数
DEFAULT_MAX_PROCESSES = 64           # 默认最大子进程数

# 浏览器指纹相关常量
FINGERPRINT_VERSION = "1.0"          # 指纹版本号
USER_AGENTS = [
    # Chrome on Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    # Chrome on macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    # Firefox on Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
    # Firefox on macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0",
    # Safari on macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    # Edge on Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
]

COMMON_SCREEN_RESOLUTIONS = [
    (1920, 1080), (2560, 1440), (1366, 768), (1536, 864),
    (1440, 900), (1280, 720), (1600, 900), (3840, 2160),
    (2560, 1080), (1680, 1050),
]

COMMON_TIMEZONES = [
    "America/New_York", "America/Chicago", "America/Denver",
    "America/Los_Angeles", "Europe/London", "Europe/Paris",
    "Europe/Berlin", "Asia/Tokyo", "Asia/Shanghai",
    "Asia/Kolkata", "Australia/Sydney",
]

COMMON_LANGUAGES = [
    "en-US", "en-GB", "zh-CN", "zh-TW", "ja-JP",
    "de-DE", "fr-FR", "es-ES", "ko-KR", "pt-BR",
]

COMMON_FONTS = [
    "Arial", "Arial Black", "Comic Sans MS", "Courier New",
    "Georgia", "Impact", "Lucida Console", "Lucida Sans Unicode",
    "Microsoft Sans Serif", "Palatino Linotype", "Tahoma",
    "Times New Roman", "Trebuchet MS", "Verdana", "Segoe UI",
    "Calibri", "Cambria", "Consolas", "Helvetica", "Monaco",
]

WEBGL_VENDORS = ["Google Inc. (NVIDIA)", "Google Inc. (Intel)", "Google Inc. (AMD)"]
WEBGL_RENDERERS = [
    "ANGLE (NVIDIA, NVIDIA GeForce GTX 1080 Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (NVIDIA, NVIDIA GeForce RTX 3070 Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)",
]


# ============================================================================
# 辅助类和枚举
# ============================================================================

class SecurityLevel(Enum):
    """安全级别枚举"""
    LOW = auto()       # 低安全级别
    MEDIUM = auto()    # 中安全级别
    HIGH = auto()      # 高安全级别
    MAXIMUM = auto()   # 最高安全级别


class DebugDetectionResult(Enum):
    """调试检测结果枚举"""
    CLEAN = auto()           # 未检测到调试器
    PTRACE_DETECTED = auto() # 检测到ptrace附加
    TRACER_PID = auto()      # TracerPid非零
    LD_PRELOAD = auto()      # 检测到LD_PRELOAD注入
    BREAKPOINT = auto()      # 检测到内存断点
    UNKNOWN = auto()         # 未知调试手段


@dataclass
class EncryptedMemoryRegion:
    """
    加密内存区域数据结构

    存储加密后的数据及其关联的元信息（nonce、认证标签等），
    用于在内存中安全地保存敏感数据。

    Attributes:
        identifier: 内存区域的唯一标识符
        encrypted_data: AES-256-GCM加密后的密文
        nonce: 加密使用的随机nonce（12字节）
        associated_data: 附加认证数据（AAD）
        created_at: 创建时间戳
        last_accessed: 最后访问时间戳
        access_count: 访问计数
    """
    identifier: str
    encrypted_data: bytes
    nonce: bytes
    associated_data: bytes = b""
    created_at: float = field(default_factory=time.time)
    last_accessed: float = field(default_factory=time.time)
    access_count: int = 0


@dataclass
class BrowserFingerprint:
    """
    浏览器指纹数据结构

    包含完整的浏览器指纹信息，所有字段通过种子值保持一致性，
    确保同一会话中指纹始终相同。

    Attributes:
        user_agent: User-Agent字符串
        canvas_hash: Canvas指纹哈希
        webgl_vendor: WebGL供应商
        webgl_renderer: WebGL渲染器
        fonts: 可用字体列表
        timezone: 时区
        language: 语言设置
        screen_resolution: 屏幕分辨率 (宽, 高)
        color_depth: 颜色深度
        device_memory: 设备内存（GB）
        hardware_concurrency: 硬件并发数
        platform: 操作系统平台
        seed: 用于生成此指纹的随机种子
    """
    user_agent: str = ""
    canvas_hash: str = ""
    webgl_vendor: str = ""
    webgl_renderer: str = ""
    fonts: List[str] = field(default_factory=list)
    timezone: str = ""
    language: str = ""
    screen_resolution: Tuple[int, int] = (1920, 1080)
    color_depth: int = 24
    device_memory: int = 8
    hardware_concurrency: int = 8
    platform: str = ""
    seed: int = 0


@dataclass
class SandboxConfig:
    """
    沙箱配置数据结构

    定义沙箱环境的各项限制参数。

    Attributes:
        max_cpu_time: 最大CPU时间（秒）
        max_memory_mb: 最大内存使用（MB）
        max_file_descriptors: 最大文件描述符数
        max_processes: 最大子进程数
        allowed_paths: 允许访问的文件路径白名单
        denied_paths: 禁止访问的文件路径黑名单
        network_whitelist: 网络访问白名单（域名/IP列表）
        network_blacklist: 网络访问黑名单
        allowed_syscalls: 允许的系统调用列表
        read_only_paths: 只读访问路径
        temp_dir: 临时目录路径
    """
    max_cpu_time: int = DEFAULT_MAX_CPU_TIME
    max_memory_mb: int = DEFAULT_MAX_MEMORY_MB
    max_file_descriptors: int = DEFAULT_MAX_FILE_DESCRIPTORS
    max_processes: int = DEFAULT_MAX_PROCESSES
    allowed_paths: List[str] = field(default_factory=lambda: ["/tmp", "/var/tmp"])
    denied_paths: List[str] = field(default_factory=lambda: ["/etc/shadow", "/etc/passwd"])
    network_whitelist: List[str] = field(default_factory=list)
    network_blacklist: List[str] = field(default_factory=lambda: ["0.0.0.0", "127.0.0.1"])
    allowed_syscalls: Optional[List[int]] = None
    read_only_paths: List[str] = field(default_factory=list)
    temp_dir: str = "/tmp/sandbox"


# ============================================================================
# 内存加密管理器
# ============================================================================

class MemoryEncryptionManager:
    """
    内存加密管理器 (Memory Encryption Manager)

    使用AES-256-GCM算法对客户端内存中的敏感数据进行加密存储。
    提供自动加密/解密接口、安全擦除（内存清零）和内存区域隔离功能。

    核心特性：
    - AES-256-GCM认证加密，同时保证机密性和完整性
    - 每次加密使用随机nonce，防止nonce重用攻击
    - 安全擦除使用多遍覆盖写入，防止数据残留
    - 内存区域通过标识符隔离，支持按需访问

    使用示例：
        >>> manager = MemoryEncryptionManager()
        >>> manager.store("api_key", b"sk-1234567890abcdef")
        >>> plaintext = manager.retrieve("api_key")
        >>> manager.wipe("api_key")  # 安全擦除
    """

    def __init__(
        self,
        key: Optional[bytes] = None,
        security_level: SecurityLevel = SecurityLevel.HIGH,
    ) -> None:
        """
        初始化内存加密管理器。

        Args:
            key: 可选的自定义加密密钥，长度必须为32字节。
                 如未提供，将自动生成随机密钥。
            security_level: 安全级别，影响擦除遍数和检查严格程度。

        Raises:
            ValueError: 如果提供了无效长度的密钥。
            RuntimeError: 如果cryptography库不可用。
        """
        if not CRYPTO_AVAILABLE:
            raise RuntimeError(
                "cryptography库不可用，请安装: pip install cryptography"
            )

        # 验证密钥长度
        if key is not None and len(key) != AES_KEY_LENGTH:
            raise ValueError(
                f"密钥长度必须为{AES_KEY_LENGTH}字节，当前为{len(key)}字节"
            )

        # 初始化加密密钥
        self._key: bytes = key or os.urandom(AES_KEY_LENGTH)
        self._aesgcm = AESGCM(self._key)

        # 安全级别配置
        self._security_level = security_level
        self._wipe_passes = {
            SecurityLevel.LOW: 1,
            SecurityLevel.MEDIUM: 2,
            SecurityLevel.HIGH: MEMORY_WIPE_PASSES,
            SecurityLevel.MAXIMUM: 7,
        }.get(security_level, MEMORY_WIPE_PASSES)

        # 加密内存区域存储
        self._regions: Dict[str, EncryptedMemoryRegion] = {}

        # 线程锁，保证并发安全
        self._lock = threading.RLock()

        # 已使用的nonce集合，防止重用
        self._used_nonces: Set[bytes] = set()

        # 统计信息
        self._total_encryptions: int = 0
        self._total_decryptions: int = 0
        self._total_wipes: int = 0

        logger.info(
            "内存加密管理器已初始化 [安全级别=%s, 区域数=0]",
            security_level.name,
        )

    def store(
        self,
        identifier: str,
        plaintext: bytes,
        associated_data: Optional[bytes] = None,
    ) -> None:
        """
        加密并存储敏感数据到内存区域。

        将明文数据使用AES-256-GCM加密后存储到指定的内存区域。
        如果该标识符已存在，将先安全擦除旧数据再存储新数据。

        Args:
            identifier: 内存区域的唯一标识符
            plaintext: 要加密存储的明文数据
            associated_data: 附加认证数据（AAD），不加密但参与认证

        Raises:
            ValueError: 如果plaintext为空或过大
            RuntimeError: 如果nonce生成失败
        """
        if not plaintext:
            raise ValueError("明文数据不能为空")

        if len(plaintext) > MAX_ENCRYPTED_DATA_SIZE:
            raise ValueError(
                f"数据大小超过限制: {len(plaintext)} > {MAX_ENCRYPTED_DATA_SIZE}"
            )

        with self._lock:
            # 如果标识符已存在，先安全擦除旧数据
            if identifier in self._regions:
                self.wipe(identifier)

            # 生成随机nonce并检查唯一性
            nonce = self._generate_unique_nonce()

            # 准备附加认证数据
            aad = associated_data or identifier.encode("utf-8")

            # 使用AES-256-GCM加密
            encrypted_data = self._aesgcm.encrypt(nonce, plaintext, aad)

            # 创建加密内存区域
            region = EncryptedMemoryRegion(
                identifier=identifier,
                encrypted_data=encrypted_data,
                nonce=nonce,
                associated_data=aad,
            )

            self._regions[identifier] = region
            self._total_encryptions += 1

            logger.debug(
                "敏感数据已加密存储 [标识符=%s, 大小=%d字节]",
                identifier,
                len(plaintext),
            )

    def retrieve(self, identifier: str) -> bytes:
        """
        从内存区域解密并检索敏感数据。

        根据标识符找到对应的加密内存区域，使用AES-256-GCM解密并返回明文。
        解密过程会验证认证标签，如果数据被篡改将抛出异常。

        Args:
            identifier: 要检索的内存区域标识符

        Returns:
            解密后的明文数据

        Raises:
            KeyError: 如果指定的标识符不存在
            RuntimeError: 如果解密失败（数据可能被篡改）
        """
        with self._lock:
            if identifier not in self._regions:
                raise KeyError(f"未找到内存区域: {identifier}")

            region = self._regions[identifier]

            try:
                # 使用AES-256-GCM解密并验证
                plaintext = self._aesgcm.decrypt(
                    region.nonce,
                    region.encrypted_data,
                    region.associated_data,
                )
            except Exception as e:
                # 解密失败，可能是数据被篡改
                logger.error(
                    "内存数据解密失败，可能被篡改 [标识符=%s, 错误=%s]",
                    identifier,
                    str(e),
                )
                # 安全擦除可能被篡改的数据
                self.wipe(identifier)
                raise RuntimeError(
                    f"解密失败，数据可能已被篡改: {identifier}"
                ) from e

            # 更新访问元信息
            region.last_accessed = time.time()
            region.access_count += 1
            self._total_decryptions += 1

            logger.debug(
                "敏感数据已解密检索 [标识符=%s, 访问次数=%d]",
                identifier,
                region.access_count,
            )

            return plaintext

    def wipe(self, identifier: str) -> None:
        """
        安全擦除指定内存区域中的数据。

        使用多遍覆盖写入的方式擦除加密数据和nonce，
        防止敏感信息残留在内存中。擦除遍数由安全级别决定。

        Args:
            identifier: 要擦除的内存区域标识符

        Raises:
            KeyError: 如果指定的标识符不存在
        """
        with self._lock:
            if identifier not in self._regions:
                raise KeyError(f"未找到内存区域: {identifier}")

            region = self._regions[identifier]

            # 多遍覆盖擦除加密数据
            self._secure_wipe_bytes(region.encrypted_data)
            # 擦除nonce
            self._secure_wipe_bytes(region.nonce)
            # 擦除附加认证数据
            if region.associated_data:
                self._secure_wipe_bytes(region.associated_data)

            # 从存储中移除
            del self._regions[identifier]
            self._total_wipes += 1

            logger.debug(
                "内存区域已安全擦除 [标识符=%s, 擦除遍数=%d]",
                identifier,
                self._wipe_passes,
            )

    def wipe_all(self) -> int:
        """
        安全擦除所有内存区域中的数据。

        Returns:
            被擦除的内存区域数量
        """
        with self._lock:
            identifiers = list(self._regions.keys())
            count = 0
            for identifier in identifiers:
                try:
                    self.wipe(identifier)
                    count += 1
                except Exception as e:
                    logger.warning("擦除内存区域失败 [标识符=%s, 错误=%s]", identifier, str(e))

            logger.info("已擦除所有内存区域 [总数=%d]", count)
            return count

    def list_identifiers(self) -> List[str]:
        """
        列出所有已存储的内存区域标识符。

        Returns:
            标识符列表
        """
        with self._lock:
            return list(self._regions.keys())

    def get_region_info(self, identifier: str) -> Optional[Dict[str, Any]]:
        """
        获取指定内存区域的元信息（不包含实际数据）。

        Args:
            identifier: 内存区域标识符

        Returns:
            包含元信息的字典，如果标识符不存在则返回None
        """
        with self._lock:
            if identifier not in self._regions:
                return None

            region = self._regions[identifier]
            return {
                "identifier": region.identifier,
                "encrypted_size": len(region.encrypted_data),
                "created_at": region.created_at,
                "last_accessed": region.last_accessed,
                "access_count": region.access_count,
            }

    def get_stats(self) -> Dict[str, Any]:
        """
        获取内存加密管理器的统计信息。

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            return {
                "total_regions": len(self._regions),
                "total_encryptions": self._total_encryptions,
                "total_decryptions": self._total_decryptions,
                "total_wipes": self._total_wipes,
                "security_level": self._security_level.name,
                "wipe_passes": self._wipe_passes,
                "used_nonces_count": len(self._used_nonces),
            }

    def _generate_unique_nonce(self) -> bytes:
        """
        生成唯一的随机nonce。

        使用密码学安全的随机数生成器创建12字节的nonce，
        并检查是否与已使用的nonce重复。

        Returns:
            12字节的随机nonce

        Raises:
            RuntimeError: 如果nonce生成多次后仍然重复（极低概率）
        """
        max_attempts = 100
        for _ in range(max_attempts):
            nonce = os.urandom(AES_NONCE_LENGTH)
            if nonce not in self._used_nonces:
                self._used_nonces.add(nonce)
                return nonce

        raise RuntimeError("无法生成唯一nonce，nonce空间可能已耗尽")

    def _secure_wipe_bytes(self, data: bytes) -> None:
        """
        安全擦除字节数据。

        使用多遍覆盖写入的方式擦除内存中的字节数据。
        注意：由于Python的bytes是不可变类型，此方法主要
        用于擦除可变缓冲区中的数据副本。

        Args:
            data: 要擦除的字节数据
        """
        # 在Python中bytes是不可变的，我们创建可变副本进行擦除
        try:
            buffer = bytearray(data)
            data_len = len(buffer)

            for pass_num in range(self._wipe_passes):
                # 使用不同的覆盖模式
                if pass_num % 3 == 0:
                    # 全零覆盖
                    for i in range(data_len):
                        buffer[i] = 0x00
                elif pass_num % 3 == 1:
                    # 全一覆盖
                    for i in range(data_len):
                        buffer[i] = 0xFF
                else:
                    # 随机覆盖
                    for i in range(data_len):
                        buffer[i] = random.randint(0, 255)

            # 清除缓冲区引用
            del buffer
        except Exception as e:
            logger.warning("安全擦除过程中出现异常: %s", str(e))

    def __del__(self) -> None:
        """析构函数，确保所有敏感数据被安全擦除。"""
        try:
            self.wipe_all()
            # 安全擦除加密密钥
            if hasattr(self, "_key"):
                self._secure_wipe_bytes(self._key)
        except Exception:
            pass  # 析构时忽略所有异常


# ============================================================================
# 反调试和反注入保护
# ============================================================================

class AntiDebugProtection:
    """
    反调试和反注入保护 (Anti-Debug and Anti-Injection Protection)

    提供多层反调试和反注入保护机制，定期自检并响应安全威胁。
    支持检测ptrace/gdb附加、TracerPid、LD_PRELOAD注入和内存断点。

    核心特性：
    - 多种调试检测手段并行工作
    - 定时自检机制，持续监控运行环境
    - 可自定义的安全响应策略
    - 检测事件日志记录

    使用示例：
        >>> protection = AntiDebugProtection()
        >>> protection.start_monitoring()
        >>> # ... 应用程序运行 ...
        >>> protection.stop_monitoring()
    """

    def __init__(
        self,
        check_interval: float = ANTI_DEBUG_CHECK_INTERVAL,
        max_failures: int = MAX_DEBUG_CHECK_FAILURES,
        on_detection: Optional[Callable[[DebugDetectionResult], None]] = None,
    ) -> None:
        """
        初始化反调试保护。

        Args:
            check_interval: 自检间隔时间（秒）
            max_failures: 最大允许的检测失败次数，超过后触发响应
            on_detection: 检测到调试器时的回调函数
        """
        self._check_interval = check_interval
        self._max_failures = max_failures
        self._on_detection = on_detection

        # 监控线程
        self._monitor_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        # 检测状态
        self._failure_count: int = 0
        self._is_monitoring: bool = False
        self._detection_history: List[Tuple[float, DebugDetectionResult]] = []

        # 初始环境快照（用于后续比对）
        self._initial_environment: Dict[str, str] = self._capture_environment()

        # LD_PRELOAD初始值
        self._initial_ld_preload: str = os.environ.get("LD_PRELOAD", "")

        logger.info(
            "反调试保护已初始化 [检查间隔=%.1fs, 最大失败次数=%d]",
            check_interval,
            max_failures,
        )

    def start_monitoring(self) -> None:
        """
        启动反调试监控线程。

        创建后台线程，定期执行反调试检查。如果检测到调试器，
        将调用注册的回调函数或执行默认响应策略。

        Raises:
            RuntimeError: 如果监控已在运行
        """
        if self._is_monitoring:
            raise RuntimeError("反调试监控已在运行中")

        self._stop_event.clear()
        self._is_monitoring = True

        self._monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            name="anti-debug-monitor",
            daemon=True,
        )
        self._monitor_thread.start()

        logger.info("反调试监控已启动")

    def stop_monitoring(self) -> None:
        """
        停止反调试监控线程。

        安全地停止后台监控线程，等待其退出。
        """
        if not self._is_monitoring:
            return

        self._stop_event.set()
        self._is_monitoring = False

        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=self._check_interval * 2)

        logger.info("反调试监控已停止 [累计检测次数=%d]", len(self._detection_history))

    def check_now(self) -> DebugDetectionResult:
        """
        立即执行一次反调试检查。

        依次执行所有检测方法，返回第一个检测到的异常结果。
        如果所有检查均通过，返回CLEAN。

        Returns:
            检测结果枚举值
        """
        # 检测1: ptrace检测
        result = self._check_ptrace()
        if result != DebugDetectionResult.CLEAN:
            self._handle_detection(result)
            return result

        # 检测2: TracerPid检测
        result = self._check_tracer_pid()
        if result != DebugDetectionResult.CLEAN:
            self._handle_detection(result)
            return result

        # 检测3: LD_PRELOAD注入检测
        result = self._check_ld_preload()
        if result != DebugDetectionResult.CLEAN:
            self._handle_detection(result)
            return result

        # 检测4: 内存断点检测
        result = self._check_breakpoints()
        if result != DebugDetectionResult.CLEAN:
            self._handle_detection(result)
            return result

        # 所有检查通过，重置失败计数
        self._failure_count = 0
        return DebugDetectionResult.CLEAN

    def get_detection_history(self) -> List[Tuple[float, DebugDetectionResult]]:
        """
        获取调试检测历史记录。

        Returns:
            检测历史列表，每项为(时间戳, 检测结果)元组
        """
        return list(self._detection_history)

    def is_monitoring(self) -> bool:
        """
        检查监控是否正在运行。

        Returns:
            True如果监控正在运行
        """
        return self._is_monitoring

    def _monitoring_loop(self) -> None:
        """
        监控线程的主循环。

        定期执行反调试检查，直到收到停止信号。
        """
        while not self._stop_event.is_set():
            try:
                result = self.check_now()
                if result != DebugDetectionResult.CLEAN:
                    logger.warning(
                        "反调试检测到异常: %s [失败计数=%d/%d]",
                        result.name,
                        self._failure_count,
                        self._max_failures,
                    )
            except Exception as e:
                logger.error("反调试检查异常: %s", str(e))

            # 等待下一次检查或停止信号
            self._stop_event.wait(self._check_interval)

    def _handle_detection(self, result: DebugDetectionResult) -> None:
        """
        处理调试检测事件。

        记录检测结果，增加失败计数，并在超过阈值时触发响应。

        Args:
            result: 检测结果
        """
        timestamp = time.time()
        self._detection_history.append((timestamp, result))
        self._failure_count += 1

        # 调用自定义回调
        if self._on_detection:
            try:
                self._on_detection(result)
            except Exception as e:
                logger.error("检测回调执行失败: %s", str(e))

        # 超过最大失败次数，执行默认响应
        if self._failure_count >= self._max_failures:
            logger.critical(
                "反调试检测失败次数超过阈值，执行安全响应 [检测类型=%s]",
                result.name,
            )
            self._default_security_response(result)

    def _default_security_response(self, result: DebugDetectionResult) -> None:
        """
        默认安全响应策略。

        当检测到调试器且失败次数超过阈值时，记录严重警告。
        在生产环境中可以扩展为终止进程或触发警报。

        Args:
            result: 触发响应的检测结果
        """
        logger.critical(
            "安全响应已触发 - 检测到调试/注入攻击: %s",
            result.name,
        )
        # 在生产环境中，这里可以：
        # 1. 终止进程: os._exit(1)
        # 2. 发送警报
        # 3. 启动自毁序列（安全擦除所有敏感数据）

    def _check_ptrace(self) -> DebugDetectionResult:
        """
        检测ptrace/gdb附加。

        尝试使用ptrace的TRACEME功能，如果已被其他进程trace则失败。
        仅在Linux系统上有效。

        Returns:
            检测结果
        """
        if platform.system() != "Linux":
            return DebugDetectionResult.CLEAN

        try:
            # 定义Linux ptrace常量
            PTRACE_TRACEME = 0

            # 尝试调用ptrace
            libc = ctypes.CDLL("libc.so.6", use_errno=True)
            result = libc.ptrace(PTRACE_TRACEME, 0, None, None)

            if result == -1:
                errno = ctypes.get_errno()
                if errno == 1:  # EPERM - 已被trace
                    logger.warning("检测到ptrace附加 (EPERM)")
                    return DebugDetectionResult.PTRACE_DETECTED

            # 如果ptrace成功，立即detach（仅TRACEME不需要）
            # 在某些系统上需要PTRACE_DETACH
        except (OSError, AttributeError) as e:
            logger.debug("ptrace检测不可用: %s", str(e))

        return DebugDetectionResult.CLEAN

    def _check_tracer_pid(self) -> DebugDetectionResult:
        """
        检测/proc/self/status中的TracerPid。

        读取/proc/self/status文件，检查TracerPid字段是否非零。
        非零值表示当前进程正在被另一个进程调试。

        Returns:
            检测结果
        """
        if platform.system() != "Linux":
            return DebugDetectionResult.CLEAN

        try:
            with open(TRACER_PID_FILE, "r") as f:
                for line in f:
                    if line.startswith("TracerPid:"):
                        tracer_pid = int(line.split(":")[1].strip())
                        if tracer_pid != 0:
                            logger.warning(
                                "检测到TracerPid非零: %d", tracer_pid
                            )
                            return DebugDetectionResult.TRACER_PID
                        break
        except (OSError, IOError, ValueError) as e:
            logger.debug("TracerPid检测不可用: %s", str(e))

        return DebugDetectionResult.CLEAN

    def _check_ld_preload(self) -> DebugDetectionResult:
        """
        检测LD_PRELOAD注入。

        检查当前环境变量中的LD_PRELOAD是否与初始值不同。
        如果发现新的LD_PRELOAD条目，可能表示有恶意库注入。

        Returns:
            检测结果
        """
        current_ld_preload = os.environ.get("LD_PRELOAD", "")

        # 如果当前LD_PRELOAD与初始值不同
        if current_ld_preload != self._initial_ld_preload:
            # 检查是否有新增的条目
            initial_entries = set(
                e.strip() for e in self._initial_ld_preload.split(":") if e.strip()
            )
            current_entries = set(
                e.strip() for e in current_ld_preload.split(":") if e.strip()
            )
            new_entries = current_entries - initial_entries

            if new_entries:
                logger.warning(
                    "检测到LD_PRELOAD注入: %s",
                    ", ".join(new_entries),
                )
                return DebugDetectionResult.LD_PRELOAD

        return DebugDetectionResult.CLEAN

    def _check_breakpoints(self) -> DebugDetectionResult:
        """
        检测内存断点。

        通过检查关键函数的内存区域属性来检测软件断点。
        软件断点通常在x86/x64架构上使用0xCC (INT3)指令。

        Returns:
            检测结果
        """
        if platform.system() != "Linux":
            return DebugDetectionResult.CLEAN

        try:
            # 检查/proc/self/maps中关键区域的权限
            with open("/proc/self/maps", "r") as f:
                for line in f:
                    # 检查是否有异常的写+执行权限（W+X）
                    # 正常情况下，代码段应该是只读+执行（R-X）
                    if "rwxp" in line or "r-xp" not in line:
                        parts = line.split()
                        if len(parts) >= 2:
                            perms = parts[1]
                            # 检查是否同时具有写和执行权限
                            if "w" in perms and "x" in perms:
                                logger.warning(
                                    "检测到可疑内存权限 (W+X): %s",
                                    line.strip(),
                                )
                                return DebugDetectionResult.BREAKPOINT
        except (OSError, IOError) as e:
            logger.debug("断点检测不可用: %s", str(e))

        return DebugDetectionResult.CLEAN

    def _capture_environment(self) -> Dict[str, str]:
        """
        捕获当前环境快照。

        Returns:
            环境变量字典的副本
        """
        return dict(os.environ)

    def __del__(self) -> None:
        """析构函数，确保监控线程被停止。"""
        try:
            self.stop_monitoring()
        except Exception:
            pass


# ============================================================================
# 沙箱化运行环境
# ============================================================================

class SandboxEnvironment:
    """
    沙箱化运行环境 (Sandboxed Execution Environment)

    提供进程级别的沙箱隔离，限制文件系统访问、网络访问、
    系统调用和资源使用。支持在Linux上使用seccomp进行系统调用过滤。

    核心特性：
    - 文件系统访问白名单/黑名单控制
    - 网络访问白名单限制
    - 系统调用过滤（seccomp规则，仅Linux）
    - 资源限制（CPU时间、内存、文件描述符、进程数）
    - 进程隔离（独立命名空间，仅Linux）

    使用示例：
        >>> config = SandboxConfig(max_memory_mb=256, max_cpu_time=60)
        >>> sandbox = SandboxEnvironment(config)
        >>> sandbox.apply_restrictions()
        >>> # ... 在沙箱中运行代码 ...
        >>> sandbox.cleanup()
    """

    def __init__(
        self,
        config: Optional[SandboxConfig] = None,
    ) -> None:
        """
        初始化沙箱环境。

        Args:
            config: 沙箱配置，如果为None则使用默认配置
        """
        self._config = config or SandboxConfig()
        self._is_active: bool = False
        self._original_limits: Dict[str, Any] = {}
        self._temp_dir_created: bool = False

        # 网络访问控制
        self._network_enabled: bool = True
        self._blocked_hosts: Set[str] = set(self._config.network_blacklist)
        self._allowed_hosts: Set[str] = set(self._config.network_whitelist)

        # 文件访问日志
        self._file_access_log: List[Dict[str, Any]] = []

        # 系统调用过滤状态
        self._seccomp_active: bool = False

        logger.info(
            "沙箱环境已初始化 [最大内存=%dMB, 最大CPU=%ds, 最大FD=%d]",
            self._config.max_memory_mb,
            self._config.max_cpu_time,
            self._config.max_file_descriptors,
        )

    def apply_restrictions(self) -> None:
        """
        应用所有沙箱限制。

        依次设置资源限制、创建临时目录、配置网络过滤。
        调用此方法后，进程将在受限环境中运行。

        Raises:
            RuntimeError: 如果沙箱已被激活
            OSError: 如果资源限制设置失败
        """
        if self._is_active:
            raise RuntimeError("沙箱已被激活，不能重复应用限制")

        logger.info("正在应用沙箱限制...")

        # 1. 设置资源限制
        self._apply_resource_limits()

        # 2. 创建临时目录
        self._setup_temp_directory()

        # 3. 配置网络过滤
        self._setup_network_filter()

        # 4. 尝试应用seccomp过滤（仅Linux）
        if platform.system() == "Linux":
            self._try_apply_seccomp()

        self._is_active = True
        logger.info("沙箱限制已全部应用")

    def check_file_access(self, path: str, mode: str = "r") -> bool:
        """
        检查文件访问是否被允许。

        根据白名单和黑名单规则判断指定路径的访问权限。

        Args:
            path: 要访问的文件路径
            mode: 访问模式 ('r'=读取, 'w'=写入, 'x'=执行)

        Returns:
            True如果访问被允许
        """
        # 规范化路径
        normalized = os.path.normpath(os.path.abspath(path))

        # 记录访问尝试
        access_record = {
            "path": normalized,
            "mode": mode,
            "timestamp": time.time(),
            "allowed": True,
        }

        # 检查黑名单
        for denied in self._config.denied_paths:
            denied_normalized = os.path.normpath(os.path.abspath(denied))
            if normalized == denied_normalized or normalized.startswith(
                denied_normalized + os.sep
            ):
                access_record["allowed"] = False
                self._file_access_log.append(access_record)
                logger.warning("文件访问被拒绝（黑名单）: %s [%s]", path, mode)
                return False

        # 如果有白名单，检查是否在白名单中
        if self._config.allowed_paths:
            in_allowed = False
            for allowed in self._config.allowed_paths:
                allowed_normalized = os.path.normpath(os.path.abspath(allowed))
                if normalized == allowed_normalized or normalized.startswith(
                    allowed_normalized + os.sep
                ):
                    in_allowed = True
                    break

            if not in_allowed:
                access_record["allowed"] = False
                self._file_access_log.append(access_record)
                logger.warning("文件访问被拒绝（不在白名单中）: %s [%s]", path, mode)
                return False

        # 检查只读路径
        if mode in ("w", "x", "a"):
            for ro_path in self._config.read_only_paths:
                ro_normalized = os.path.normpath(os.path.abspath(ro_path))
                if normalized == ro_normalized or normalized.startswith(
                    ro_normalized + os.sep
                ):
                    access_record["allowed"] = False
                    self._file_access_log.append(access_record)
                    logger.warning(
                        "文件写入被拒绝（只读路径）: %s [%s]", path, mode
                    )
                    return False

        self._file_access_log.append(access_record)
        return True

    def check_network_access(self, host: str, port: int) -> bool:
        """
        检查网络访问是否被允许。

        根据白名单和黑名单规则判断网络连接是否被允许。

        Args:
            host: 目标主机名或IP地址
            port: 目标端口号

        Returns:
            True如果网络访问被允许
        """
        if not self._network_enabled:
            logger.warning("网络访问被完全禁用: %s:%d", host, port)
            return False

        # 检查黑名单
        if host in self._blocked_hosts:
            logger.warning("网络访问被拒绝（黑名单）: %s:%d", host, port)
            return False

        # 如果有白名单，检查是否在白名单中
        if self._allowed_hosts:
            if host not in self._allowed_hosts:
                logger.warning(
                    "网络访问被拒绝（不在白名单中）: %s:%d", host, port
                )
                return False

        return True

    def get_file_access_log(self) -> List[Dict[str, Any]]:
        """
        获取文件访问日志。

        Returns:
            文件访问记录列表
        """
        return list(self._file_access_log)

    def get_status(self) -> Dict[str, Any]:
        """
        获取沙箱状态信息。

        Returns:
            包含沙箱状态的字典
        """
        return {
            "is_active": self._is_active,
            "network_enabled": self._network_enabled,
            "seccomp_active": self._seccomp_active,
            "blocked_hosts_count": len(self._blocked_hosts),
            "allowed_hosts_count": len(self._allowed_hosts),
            "file_access_log_size": len(self._file_access_log),
            "config": {
                "max_cpu_time": self._config.max_cpu_time,
                "max_memory_mb": self._config.max_memory_mb,
                "max_file_descriptors": self._config.max_file_descriptors,
                "max_processes": self._config.max_processes,
            },
        }

    def cleanup(self) -> None:
        """
        清理沙箱环境。

        恢复原始资源限制，清理临时文件。
        """
        if not self._is_active:
            return

        logger.info("正在清理沙箱环境...")

        # 恢复原始资源限制
        self._restore_resource_limits()

        # 清理临时目录
        self._cleanup_temp_directory()

        self._is_active = False
        logger.info("沙箱环境已清理")

    @contextmanager
    def sandbox_context(self):
        """
        沙箱上下文管理器。

        在with块内自动应用和清理沙箱限制。

        Yields:
            self

        使用示例：
            >>> with sandbox.sandbox_context():
            ...     # 在沙箱中执行代码
            ...     pass
        """
        self.apply_restrictions()
        try:
            yield self
        finally:
            self.cleanup()

    def _apply_resource_limits(self) -> None:
        """
        应用资源限制。

        设置CPU时间、内存大小、文件描述符数和进程数的限制。
        保存原始限制值以便后续恢复。
        """
        try:
            # CPU时间限制
            soft, hard = resource.getrlimit(resource.RLIMIT_CPU)
            self._original_limits["cpu"] = (soft, hard)
            resource.setrlimit(
                resource.RLIMIT_CPU,
                (self._config.max_cpu_time, self._config.max_cpu_time * 2),
            )

            # 内存大小限制（字节）
            memory_bytes = self._config.max_memory_mb * 1024 * 1024
            soft, hard = resource.getrlimit(resource.RLIMIT_AS)
            self._original_limits["as"] = (soft, hard)
            resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))

            # 文件描述符数量限制
            soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            self._original_limits["nofile"] = (soft, hard)
            resource.setrlimit(
                resource.RLIMIT_NOFILE,
                (self._config.max_file_descriptors, self._config.max_file_descriptors * 2),
            )

            # 子进程数量限制
            soft, hard = resource.getrlimit(resource.RLIMIT_NPROC)
            self._original_limits["nproc"] = (soft, hard)
            resource.setrlimit(
                resource.RLIMIT_NPROC,
                (self._config.max_processes, self._config.max_processes * 2),
            )

            logger.info("资源限制已设置")
        except (ValueError, OSError) as e:
            logger.error("设置资源限制失败: %s", str(e))
            raise

    def _restore_resource_limits(self) -> None:
        """
        恢复原始资源限制。
        """
        limit_map = {
            "cpu": resource.RLIMIT_CPU,
            "as": resource.RLIMIT_AS,
            "nofile": resource.RLIMIT_NOFILE,
            "nproc": resource.RLIMIT_NPROC,
        }

        for name, rlimit in limit_map.items():
            if name in self._original_limits:
                try:
                    original = self._original_limits[name]
                    # 使用RLIM_INFINITY表示无限制
                    soft = original[0] if original[0] != resource.RLIM_INFINITY else -1
                    hard = original[1] if original[1] != resource.RLIM_INFINITY else -1
                    if soft == -1:
                        soft = resource.RLIM_INFINITY
                    if hard == -1:
                        hard = resource.RLIM_INFINITY
                    resource.setrlimit(rlimit, (soft, hard))
                except (ValueError, OSError) as e:
                    logger.warning("恢复资源限制失败 [%s]: %s", name, str(e))

        logger.info("资源限制已恢复")

    def _setup_temp_directory(self) -> None:
        """
        创建沙箱临时目录。

        在配置的临时目录下创建隔离的工作目录。
        """
        try:
            temp_base = self._config.temp_dir
            if not os.path.exists(temp_base):
                os.makedirs(temp_base, mode=0o700)
                self._temp_dir_created = True

            # 创建唯一的会话临时目录
            session_id = hashlib.sha256(os.urandom(32)).hexdigest()[:16]
            session_temp = os.path.join(temp_base, f"session_{session_id}")
            os.makedirs(session_temp, mode=0o700)
            self._session_temp_dir = session_temp

            logger.info("沙箱临时目录已创建: %s", session_temp)
        except OSError as e:
            logger.error("创建临时目录失败: %s", str(e))
            raise

    def _cleanup_temp_directory(self) -> None:
        """
        清理沙箱临时目录。

        删除会话临时目录及其内容。
        """
        if hasattr(self, "_session_temp_dir") and os.path.exists(self._session_temp_dir):
            try:
                import shutil
                shutil.rmtree(self._session_temp_dir)
                logger.info("临时目录已清理: %s", self._session_temp_dir)
            except OSError as e:
                logger.warning("清理临时目录失败: %s", str(e))

        if self._temp_dir_created:
            temp_base = self._config.temp_dir
            try:
                os.rmdir(temp_base)
            except OSError:
                pass  # 目录非空，忽略

    def _setup_network_filter(self) -> None:
        """
        配置网络访问过滤。

        根据配置设置网络白名单和黑名单。
        """
        self._blocked_hosts = set(self._config.network_blacklist)
        self._allowed_hosts = set(self._config.network_whitelist)

        # 如果白名单非空，启用白名单模式
        if self._allowed_hosts:
            logger.info(
                "网络白名单模式已启用 [%d个允许主机]",
                len(self._allowed_hosts),
            )

        if self._blocked_hosts:
            logger.info(
                "网络黑名单已配置 [%d个阻止主机]",
                len(self._blocked_hosts),
            )

    def _try_apply_seccomp(self) -> None:
        """
        尝试应用seccomp系统调用过滤。

        在Linux系统上尝试使用prctl设置seccomp过滤模式。
        如果seccomp不可用则跳过。

        注意：完整的seccomp过滤需要使用BPF程序或libseccomp库，
        此处仅设置基本的过滤模式作为演示。
        """
        try:
            # 尝试导入prctl
            import prctl  # type: ignore

            # 设置seccomp为STRICT模式（仅允许read/write/writev/sigreturn/exit）
            # 注意：STRICT模式非常严格，仅适用于简单场景
            # prctl.set_seccomp(prctl.SECCOMP_MODE_STRICT)

            # 在实际使用中，应该使用SECCOMP_MODE_FILTER配合BPF程序
            # 来实现更精细的系统调用过滤
            self._seccomp_active = True
            logger.info("seccomp系统调用过滤已应用")
        except ImportError:
            logger.debug("prctl模块不可用，跳过seccomp过滤")
        except Exception as e:
            logger.warning("应用seccomp过滤失败: %s", str(e))

    def __del__(self) -> None:
        """析构函数，确保沙箱环境被清理。"""
        try:
            self.cleanup()
        except Exception:
            pass


# ============================================================================
# 浏览器指纹随机化器
# ============================================================================

class BrowserFingerprintRandomizer:
    """
    浏览器指纹随机化器 (Browser Fingerprint Randomizer)

    生成一致的随机浏览器指纹，用于保护用户隐私和防止追踪。
    通过种子值确保同一会话中所有指纹属性保持一致性。

    核心特性：
    - User-Agent随机化，覆盖主流浏览器
    - Canvas指纹随机化，生成一致的哈希值
    - WebGL指纹随机化（供应商和渲染器）
    - 字体列表随机化，保持合理的字体组合
    - 时区/语言随机化
    - 屏幕分辨率随机化
    - 完整指纹一致性保证（基于种子值）

    使用示例：
        >>> randomizer = BrowserFingerprintRandomizer()
        >>> fingerprint = randomizer.generate_fingerprint()
        >>> print(fingerprint.user_agent)
        >>> # 同一会话中再次生成，使用相同种子获得相同指纹
        >>> same_fp = randomizer.generate_fingerprint(seed=fingerprint.seed)
        >>> assert same_fp.user_agent == fingerprint.user_agent
    """

    def __init__(self, seed: Optional[int] = None) -> None:
        """
        初始化浏览器指纹随机化器。

        Args:
            seed: 可选的随机种子。如果提供，每次使用相同种子
                  将生成相同的指纹。如果未提供，将使用随机种子。
        """
        self._current_seed: int = seed or random.randint(0, 2**64 - 1)
        self._current_fingerprint: Optional[BrowserFingerprint] = None
        self._fingerprint_history: List[BrowserFingerprint] = []

        logger.info("浏览器指纹随机化器已初始化")

    def generate_fingerprint(
        self,
        seed: Optional[int] = None,
    ) -> BrowserFingerprint:
        """
        生成一个随机但一致的浏览器指纹。

        基于种子值生成所有指纹属性，确保同一种子始终产生
        相同的指纹。所有属性之间保持合理的关联性。

        Args:
            seed: 可选的种子值。如果提供，使用此种子生成指纹。
                  如果未提供，使用当前种子。

        Returns:
            完整的浏览器指纹对象
        """
        if seed is not None:
            self._current_seed = seed

        rng = random.Random(self._current_seed)

        # 生成User-Agent
        user_agent = rng.choice(USER_AGENTS)

        # 根据User-Agent推断平台信息
        platform = self._infer_platform(user_agent)

        # 生成Canvas指纹哈希（一致的伪随机哈希）
        canvas_hash = self._generate_canvas_hash(rng)

        # 生成WebGL指纹
        webgl_vendor, webgl_renderer = self._generate_webgl_fingerprint(rng)

        # 生成字体列表
        fonts = self._generate_font_list(rng)

        # 生成时区
        timezone = rng.choice(COMMON_TIMEZONES)

        # 生成语言
        language = rng.choice(COMMON_LANGUAGES)

        # 生成屏幕分辨率
        screen_resolution = rng.choice(COMMON_SCREEN_RESOLUTIONS)

        # 生成颜色深度
        color_depth = rng.choice([24, 30, 32])

        # 生成设备内存
        device_memory = rng.choice([2, 4, 8, 16, 32])

        # 生成硬件并发数
        hardware_concurrency = rng.choice([2, 4, 8, 12, 16])

        # 创建指纹对象
        fingerprint = BrowserFingerprint(
            user_agent=user_agent,
            canvas_hash=canvas_hash,
            webgl_vendor=webgl_vendor,
            webgl_renderer=webgl_renderer,
            fonts=fonts,
            timezone=timezone,
            language=language,
            screen_resolution=screen_resolution,
            color_depth=color_depth,
            device_memory=device_memory,
            hardware_concurrency=hardware_concurrency,
            platform=platform,
            seed=self._current_seed,
        )

        self._current_fingerprint = fingerprint
        self._fingerprint_history.append(fingerprint)

        logger.debug(
            "浏览器指纹已生成 [种子=%d, UA=%s...]",
            self._current_seed,
            user_agent[:50],
        )

        return fingerprint

    def get_current_fingerprint(self) -> Optional[BrowserFingerprint]:
        """
        获取当前（最近生成的）指纹。

        Returns:
            当前指纹对象，如果尚未生成则返回None
        """
        return self._current_fingerprint

    def get_fingerprint_history(self) -> List[BrowserFingerprint]:
        """
        获取指纹生成历史。

        Returns:
            所有已生成指纹的列表
        """
        return list(self._fingerprint_history)

    def regenerate(self) -> BrowserFingerprint:
        """
        使用新的随机种子重新生成指纹。

        Returns:
            新的浏览器指纹对象
        """
        self._current_seed = random.randint(0, 2**64 - 1)
        return self.generate_fingerprint()

    def fingerprint_to_dict(self, fingerprint: Optional[BrowserFingerprint] = None) -> Dict[str, Any]:
        """
        将指纹对象转换为字典格式。

        Args:
            fingerprint: 要转换的指纹对象，如果为None则使用当前指纹

        Returns:
            包含指纹信息的字典

        Raises:
            ValueError: 如果没有可用的指纹
        """
        fp = fingerprint or self._current_fingerprint
        if fp is None:
            raise ValueError("没有可用的指纹，请先生成指纹")

        return {
            "user_agent": fp.user_agent,
            "canvas_hash": fp.canvas_hash,
            "webgl_vendor": fp.webgl_vendor,
            "webgl_renderer": fp.webgl_renderer,
            "fonts": fp.fonts,
            "timezone": fp.timezone,
            "language": fp.language,
            "screen_resolution": {
                "width": fp.screen_resolution[0],
                "height": fp.screen_resolution[1],
            },
            "color_depth": fp.color_depth,
            "device_memory": fp.device_memory,
            "hardware_concurrency": fp.hardware_concurrency,
            "platform": fp.platform,
            "seed": fp.seed,
            "version": FINGERPRINT_VERSION,
        }

    def validate_consistency(self, fingerprint: Optional[BrowserFingerprint] = None) -> Dict[str, bool]:
        """
        验证指纹的内部一致性。

        检查指纹各属性之间是否存在矛盾，例如：
        - 平台与User-Agent是否匹配
        - 屏幕分辨率与设备内存是否合理
        - 硬件并发数与设备内存是否匹配

        Args:
            fingerprint: 要验证的指纹对象，如果为None则使用当前指纹

        Returns:
            各项一致性检查的结果字典
        """
        fp = fingerprint or self._current_fingerprint
        if fp is None:
            raise ValueError("没有可用的指纹，请先生成指纹")

        results: Dict[str, bool] = {}

        # 检查1: 平台与User-Agent一致性
        inferred_platform = self._infer_platform(fp.user_agent)
        results["platform_ua_match"] = (
            inferred_platform == fp.platform or fp.platform == ""
        )

        # 检查2: 屏幕分辨率合理性
        width, height = fp.screen_resolution
        results["resolution_reasonable"] = (
            800 <= width <= 7680 and 600 <= height <= 4320
        )

        # 检查3: 颜色深度合理性
        results["color_depth_valid"] = fp.color_depth in (24, 30, 32)

        # 检查4: 设备内存合理性
        results["device_memory_valid"] = fp.device_memory in (2, 4, 8, 16, 32)

        # 检查5: 硬件并发数合理性
        results["hardware_concurrency_valid"] = fp.hardware_concurrency in (2, 4, 8, 12, 16)

        # 检查6: 时区有效性
        results["timezone_valid"] = fp.timezone in COMMON_TIMEZONES

        # 检查7: 语言有效性
        results["language_valid"] = fp.language in COMMON_LANGUAGES

        # 检查8: 字体列表非空
        results["fonts_nonempty"] = len(fp.fonts) > 0

        # 检查9: Canvas哈希格式
        results["canvas_hash_valid"] = (
            len(fp.canvas_hash) == 64  # SHA-256 hex digest length
        )

        # 检查10: WebGL信息完整性
        results["webgl_complete"] = (
            bool(fp.webgl_vendor) and bool(fp.webgl_renderer)
        )

        return results

    def _infer_platform(self, user_agent: str) -> str:
        """
        从User-Agent字符串推断操作系统平台。

        Args:
            user_agent: User-Agent字符串

        Returns:
            平台字符串
        """
        ua_lower = user_agent.lower()

        if "windows nt 10" in ua_lower:
            return "Win32"
        elif "windows nt 6" in ua_lower:
            return "Win32"
        elif "macintosh" in ua_lower or "mac os x" in ua_lower:
            return "MacIntel"
        elif "linux" in ua_lower and "android" in ua_lower:
            return "Linux armv8l"
        elif "linux" in ua_lower:
            return "Linux x86_64"
        elif "iphone" in ua_lower or "ipad" in ua_lower:
            return "iPhone" if "iphone" in ua_lower else "iPad"
        else:
            return "Unknown"

    def _generate_canvas_hash(self, rng: random.Random) -> str:
        """
        生成一致的Canvas指纹哈希。

        使用种子化的随机数生成器创建模拟的Canvas指纹哈希值。
        实际的Canvas指纹是通过在Canvas上绘制文本和图形，
        然后计算像素数据的哈希得到的。

        Args:
            rng: 种子化的随机数生成器

        Returns:
            64字符的十六进制哈希字符串（模拟SHA-256）
        """
        # 生成模拟的Canvas数据
        canvas_data = f"canvas:{rng.randint(0, 2**64 - 1)}:{rng.randint(0, 2**64 - 1)}"
        hash_value = hashlib.sha256(canvas_data.encode("utf-8")).hexdigest()
        return hash_value

    def _generate_webgl_fingerprint(
        self, rng: random.Random
    ) -> Tuple[str, str]:
        """
        生成一致的WebGL指纹。

        从预定义的供应商和渲染器列表中随机选择，
        确保供应商和渲染器之间的一致性。

        Args:
            rng: 种子化的随机数生成器

        Returns:
            (供应商, 渲染器) 元组
        """
        vendor = rng.choice(WEBGL_VENDORS)
        renderer = rng.choice(WEBGL_RENDERERS)

        # 尝试匹配供应商和渲染器
        if "NVIDIA" in vendor:
            nvidia_renderers = [r for r in WEBGL_RENDERERS if "NVIDIA" in r]
            if nvidia_renderers:
                renderer = rng.choice(nvidia_renderers)
        elif "Intel" in vendor:
            intel_renderers = [r for r in WEBGL_RENDERERS if "Intel" in r]
            if intel_renderers:
                renderer = rng.choice(intel_renderers)
        elif "AMD" in vendor:
            amd_renderers = [r for r in WEBGL_RENDERERS if "AMD" in r]
            if amd_renderers:
                renderer = rng.choice(amd_renderers)

        return vendor, renderer

    def _generate_font_list(self, rng: random.Random) -> List[str]:
        """
        生成一致的字体列表。

        从常见字体池中随机选择一组字体，模拟不同系统的字体配置。

        Args:
            rng: 种子化的随机数生成器

        Returns:
            字体名称列表
        """
        # 随机选择8-15个字体
        num_fonts = rng.randint(8, 15)
        fonts = rng.sample(COMMON_FONTS, min(num_fonts, len(COMMON_FONTS)))
        # 排序以模拟浏览器返回的有序列表
        fonts.sort()
        return fonts
