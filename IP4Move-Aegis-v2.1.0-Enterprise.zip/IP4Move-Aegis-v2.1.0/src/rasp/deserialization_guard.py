"""
反序列化保护模块

提供pickle、yaml、json等格式的安全反序列化
"""

import asyncio
import json
import logging
import pickle
import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Optional, Callable

from .exception.security_exception import DeserializationException

logger = logging.getLogger(__name__)


class DeserializationFormat(Enum):
    """反序列化格式"""
    PICKLE = "pickle"
    YAML = "yaml"
    JSON = "json"
    XML = "xml"
    MSGPACK = "msgpack"


@dataclass
class DeserializationResult:
    """反序列化结果"""
    success: bool
    data: Any
    format_type: DeserializationFormat
    warnings: list[str]
    errors: list[str]


class SafePickleLoader:
    """
    安全Pickle加载器
    
    限制可反序列化的类，防止代码执行
    """
    
    # 危险的类
    DANGEROUS_CLASSES = {
        "os.system", "os.popen", "subprocess.call", "subprocess.Popen",
        "eval", "exec", "compile", "__import__", "builtins.eval",
        "builtins.exec", "builtins.compile", "builtins.__import__",
        "pickle._loads", "pickle.loads", "cPickle.loads",
        "yaml.load", "yaml.unsafe_load", "yaml.load_all",
    }
    
    # 允许的类白名单
    ALLOWED_MODULES = {
        "builtins", "collections", "datetime", "decimal",
        " fractions", "typing"
    }
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化安全Pickle加载器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.strict_mode = self.config.get("strict", True)
        self.allowed_classes: set[str] = set(
            self.config.get("allowed_classes", [])
        )
        self.blocked_classes: set[str] = set(
            self.config.get("blocked_classes", self.DANGEROUS_CLASSES)
        )
        
    def load(
        self,
        data: bytes,
        encoding: str = "ASCII",
        errors: str = "strict"
    ) -> Any:
        """
        安全加载Pickle数据
        
        Args:
            data: Pickle数据
            encoding: 编码
            errors: 错误处理
            
        Returns:
            反序列化后的对象
            
        Raises:
            DeserializationException: 检测到危险类时抛出
        """
        # 使用自定义Unpickler
        class SafeUnpickler(pickle.Unpickler):
            def find_class(inner_self, module: str, name: str) -> type:
                full_name = f"{module}.{name}"
                
                # 检查是否在黑名单
                if full_name in self.blocked_classes:
                    raise DeserializationException(
                        message=f"危险的类被阻止: {full_name}",
                        format_type="pickle",
                        dangerous_class=full_name
                    )
                    
                # 严格模式下只允许白名单
                if self.strict_mode:
                    if module not in self.ALLOWED_MODULES:
                        if full_name not in self.allowed_classes:
                            raise DeserializationException(
                                message=f"未授权的类: {full_name}",
                                format_type="pickle",
                                dangerous_class=full_name
                            )
                            
                return super().find_class(module, name)
                
        try:
            unpickler = SafeUnpickler(
                data,
                encoding=encoding,
                errors=errors
            )
            return unpickler.load()
        except DeserializationException:
            raise
        except Exception as e:
            raise DeserializationException(
                message=f"Pickle反序列化失败: {str(e)}",
                format_type="pickle"
            )


class SafeYAMLLoader:
    """
    安全YAML加载器
    
    防止YAML反序列化代码执行漏洞
    """
    
    # 危险的YAML标签
    DANGEROUS_TAGS = {
        "!!python/object", "!!python/object/new",
        "!!python/object/apply", "!!python/module",
        "!!python/name", "!!python/tuple",
        "!!python/list", "!!python/dict",
        "!!python/str", "!!python/unicode",
        "!!python/bytes", "!!python/int",
        "!!python/float", "!!python/complex",
        "!!python/bool", "!!python/none",
        "!!python/sequence", "!!python/mapping",
        "!python/object", "!python/object/new",
        "!python/object/apply", "!python/module",
        "!python/name", "!python/tuple",
        "!python/list", "!python/dict",
        "!python/str", "!python/unicode",
        "!python/bytes", "!python/int",
        "!python/float", "!python/complex",
        "!python/bool", "!python/none",
        "!python/sequence", "!python/mapping",
    }
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化安全YAML加载器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.safe_only = self.config.get("safe_only", True)
        self.allowed_tags: set[str] = set(
            self.config.get("allowed_tags", [])
        )
        
    def load(self, data: str) -> Any:
        """
        安全加载YAML数据
        
        Args:
            data: YAML字符串
            
        Returns:
            反序列化后的对象
            
        Raises:
            DeserializationException: 检测到危险标签时抛出
        """
        try:
            import yaml
        except ImportError:
            raise DeserializationException(
                message="PyYAML未安装",
                format_type="yaml"
            )
            
        # 检查危险标签
        for tag in self.DANGEROUS_TAGS:
            if tag in data:
                if tag not in self.allowed_tags:
                    raise DeserializationException(
                        message=f"危险的YAML标签: {tag}",
                        format_type="yaml",
                        dangerous_class=tag
                    )
                    
        try:
            if self.safe_only:
                # 使用安全加载器
                return yaml.safe_load(data)
            else:
                return yaml.load(data, Loader=yaml.SafeLoader)
        except Exception as e:
            raise DeserializationException(
                message=f"YAML反序列化失败: {str(e)}",
                format_type="yaml"
            )


class SafeJSONLoader:
    """
    安全JSON加载器
    
    防止JSON反序列化漏洞
    """
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化安全JSON加载器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.max_depth = self.config.get("max_depth", 100)
        self.max_size = self.config.get("max_size", 10 * 1024 * 1024)  # 10MB
        
    def load(self, data: str) -> Any:
        """
        安全加载JSON数据
        
        Args:
            data: JSON字符串
            
        Returns:
            反序列化后的对象
            
        Raises:
            DeserializationException: 检测到异常时抛出
        """
        # 检查大小
        if len(data) > self.max_size:
            raise DeserializationException(
                message=f"JSON数据过大: {len(data)} bytes",
                format_type="json"
            )
            
        try:
            # 使用自定义解码器限制深度
            def check_depth(obj: Any, depth: int = 0) -> Any:
                if depth > self.max_depth:
                    raise DeserializationException(
                        message=f"JSON嵌套深度超过限制: {self.max_depth}",
                        format_type="json"
                    )
                if isinstance(obj, dict):
                    return {k: check_depth(v, depth + 1) for k, v in obj.items()}
                elif isinstance(obj, list):
                    return [check_depth(item, depth + 1) for item in obj]
                return obj
                
            result = json.loads(data)
            return check_depth(result)
            
        except json.JSONDecodeError as e:
            raise DeserializationException(
                message=f"JSON解析错误: {str(e)}",
                format_type="json"
            )
        except DeserializationException:
            raise
        except Exception as e:
            raise DeserializationException(
                message=f"JSON反序列化失败: {str(e)}",
                format_type="json"
            )


class DeserializationGuard:
    """
    反序列化保护器
    
    提供统一的反序列化安全接口
    """
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化反序列化保护器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        
        # 初始化加载器
        self.pickle_loader = SafePickleLoader(
            self.config.get("pickle", {})
        )
        self.yaml_loader = SafeYAMLLoader(
            self.config.get("yaml", {})
        )
        self.json_loader = SafeJSONLoader(
            self.config.get("json", {})
        )
        
        # 统计
        self._stats = {
            "pickle_loads": 0,
            "yaml_loads": 0,
            "json_loads": 0,
            "blocked_attempts": 0
        }
        
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化保护器"""
        if self._initialized:
            return
            
        logger.info("初始化反序列化保护器...")
        self._initialized = True
        logger.info("反序列化保护器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭保护器"""
        self._initialized = False
        logger.info("反序列化保护器已关闭")
        
    def safe_loads(
        self,
        data: bytes | str,
        format_type: DeserializationFormat
    ) -> DeserializationResult:
        """
        安全反序列化
        
        Args:
            data: 序列化数据
            format_type: 格式类型
            
        Returns:
            反序列化结果
        """
        if not self.enabled:
            return DeserializationResult(
                success=False,
                data=None,
                format_type=format_type,
                warnings=["反序列化保护已禁用"],
                errors=[]
            )
            
        warnings = []
        errors = []
        
        try:
            if format_type == DeserializationFormat.PICKLE:
                self._stats["pickle_loads"] += 1
                if isinstance(data, str):
                    data = data.encode()
                result = self.pickle_loader.load(data)
                
            elif format_type == DeserializationFormat.YAML:
                self._stats["yaml_loads"] += 1
                if isinstance(data, bytes):
                    data = data.decode()
                result = self.yaml_loader.load(data)
                
            elif format_type == DeserializationFormat.JSON:
                self._stats["json_loads"] += 1
                if isinstance(data, bytes):
                    data = data.decode()
                result = self.json_loader.load(data)
                
            else:
                errors.append(f"不支持的格式: {format_type}")
                return DeserializationResult(
                    success=False,
                    data=None,
                    format_type=format_type,
                    warnings=warnings,
                    errors=errors
                )
                
            return DeserializationResult(
                success=True,
                data=result,
                format_type=format_type,
                warnings=warnings,
                errors=errors
            )
            
        except DeserializationException as e:
            self._stats["blocked_attempts"] += 1
            errors.append(str(e))
            return DeserializationResult(
                success=False,
                data=None,
                format_type=format_type,
                warnings=warnings,
                errors=errors
            )
        except Exception as e:
            errors.append(f"反序列化失败: {str(e)}")
            return DeserializationResult(
                success=False,
                data=None,
                format_type=format_type,
                warnings=warnings,
                errors=errors
            )
            
    def safe_loads_pickle(self, data: bytes) -> Any:
        """
        安全加载Pickle
        
        Args:
            data: Pickle数据
            
        Returns:
            反序列化后的对象
        """
        result = self.safe_loads(data, DeserializationFormat.PICKLE)
        if result.success:
            return result.data
        raise DeserializationException(
            message=result.errors[0] if result.errors else "Pickle加载失败",
            format_type="pickle"
        )
        
    def safe_loads_yaml(self, data: str) -> Any:
        """
        安全加载YAML
        
        Args:
            data: YAML数据
            
        Returns:
            反序列化后的对象
        """
        result = self.safe_loads(data, DeserializationFormat.YAML)
        if result.success:
            return result.data
        raise DeserializationException(
            message=result.errors[0] if result.errors else "YAML加载失败",
            format_type="yaml"
        )
        
    def safe_loads_json(self, data: str) -> Any:
        """
        安全加载JSON
        
        Args:
            data: JSON数据
            
        Returns:
            反序列化后的对象
        """
        result = self.safe_loads(data, DeserializationFormat.JSON)
        if result.success:
            return result.data
        raise DeserializationException(
            message=result.errors[0] if result.errors else "JSON加载失败",
            format_type="json"
        )
        
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            **self._stats,
            "enabled": self.enabled
        }
