"""
命令注入检测模块

提供shell命令解析和危险函数拦截功能
"""

import asyncio
import logging
import re
import shlex
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Optional, Union

from .exception.security_exception import CommandInjectionException
from .exception.attack_context import (
    AttackContext,
    AttackContextBuilder,
    AttackSeverity
)

logger = logging.getLogger(__name__)


class CommandType(Enum):
    """命令类型"""
    SHELL = "shell"
    SYSTEM = "system"
    EXEC = "exec"
    PIPE = "pipe"
    BACKGROUND = "background"


@dataclass
class CommandToken:
    """命令词法单元"""
    token_type: str
    value: str
    position: int


@dataclass
class ParsedCommand:
    """解析后的命令"""
    command: str
    arguments: list[str]
    command_type: CommandType
    has_shell_metacharacters: bool
    has_redirection: bool
    has_pipes: bool
    has_substitution: bool


class ShellCommandParser:
    """
    Shell命令解析器
    
    解析shell命令并检测危险结构
    """
    
    # Shell元字符
    SHELL_METACHARACTERS = {
        ";", "&", "|", "<", ">", "(", ")", "{", "}",
        "$", "`", "\\", "'", '"', "*", "?", "[", "]",
        "#", "~", "=", "%"
    }
    
    # 危险命令
    DANGEROUS_COMMANDS = {
        "rm", "dd", "mkfs", "fdisk", "format",
        "wget", "curl", "nc", "netcat", "telnet",
        "bash", "sh", "zsh", "csh", "ksh",
        "python", "perl", "ruby", "php",
        "nc", "ncat", "socat",
        "base64", "xxd", "od", "hexdump"
    }
    
    # 命令注入模式
    INJECTION_PATTERNS = {
        "command_separator": r"[;&]",
        "pipe": r"\|\s*\w+",
        "redirection": r"[<>]\s*\w+",
        "command_substitution": r"`[^`]+`|\$\([^)]+\)",
        "variable_expansion": r"\$\w+|\$\{[^}]+\}",
        "logical_operator": r"&&|\|\|",
        "background": r"&\s*$",
        "newline": r"\n",
    }
    
    def __init__(self):
        """初始化命令解析器"""
        self._compiled_patterns = {
            name: re.compile(pattern)
            for name, pattern in self.INJECTION_PATTERNS.items()
        }
        
    def parse(self, command: str) -> ParsedCommand:
        """
        解析命令
        
        Args:
            command: 命令字符串
            
        Returns:
            解析后的命令对象
        """
        # 检测shell元字符
        has_metacharacters = any(
            c in command for c in self.SHELL_METACHARACTERS
        )
        
        # 检测重定向
        has_redirection = bool(
            self._compiled_patterns["redirection"].search(command)
        )
        
        # 检测管道
        has_pipes = bool(
            self._compiled_patterns["pipe"].search(command)
        )
        
        # 检测命令替换
        has_substitution = bool(
            self._compiled_patterns["command_substitution"].search(command)
        )
        
        # 确定命令类型
        if has_pipes:
            cmd_type = CommandType.PIPE
        elif has_substitution:
            cmd_type = CommandType.EXEC
        elif command.strip().endswith("&"):
            cmd_type = CommandType.BACKGROUND
        else:
            cmd_type = CommandType.SHELL
            
        # 解析参数
        try:
            parts = shlex.split(command)
            cmd = parts[0] if parts else ""
            args = parts[1:] if len(parts) > 1 else []
        except ValueError:
            cmd = command.split()[0] if command else ""
            args = []
            
        return ParsedCommand(
            command=cmd,
            arguments=args,
            command_type=cmd_type,
            has_shell_metacharacters=has_metacharacters,
            has_redirection=has_redirection,
            has_pipes=has_pipes,
            has_substitution=has_substitution
        )
        
    def tokenize(self, command: str) -> list[CommandToken]:
        """
        词法分析
        
        Args:
            command: 命令字符串
            
        Returns:
            词法单元列表
        """
        tokens = []
        position = 0
        
        # 简单的词法分析
        current_token = ""
        in_quotes = False
        quote_char = None
        
        for i, char in enumerate(command):
            if char in ('"', "'") and not in_quotes:
                if current_token:
                    tokens.append(CommandToken("WORD", current_token, position))
                    current_token = ""
                in_quotes = True
                quote_char = char
                position = i
            elif char == quote_char and in_quotes:
                tokens.append(CommandToken("QUOTED", current_token, position))
                current_token = ""
                in_quotes = False
                quote_char = None
            elif char.isspace() and not in_quotes:
                if current_token:
                    tokens.append(CommandToken("WORD", current_token, position))
                    current_token = ""
            elif char in self.SHELL_METACHARACTERS and not in_quotes:
                if current_token:
                    tokens.append(CommandToken("WORD", current_token, position))
                    current_token = ""
                tokens.append(CommandToken("META", char, i))
            else:
                if not current_token:
                    position = i
                current_token += char
                
        if current_token:
            tokens.append(CommandToken("WORD", current_token, position))
            
        return tokens


class CommandInjectionDetector:
    """
    命令注入检测器
    
    检测命令注入攻击并拦截危险函数
    """
    
    # 危险函数列表
    DANGEROUS_FUNCTIONS = [
        "os.system", "os.popen", "os.exec", "os.spawn",
        "subprocess.call", "subprocess.run", "subprocess.Popen",
        "subprocess.check_output", "subprocess.check_call",
        "commands.getoutput", "commands.getstatusoutput",
        "eval", "exec", "compile",
        "input", "raw_input"
    ]
    
    # 命令注入特征
    INJECTION_SIGNATURES = [
        r";\s*\w+",           # 命令分隔符
        r"&&\s*\w+",          # 逻辑与
        r"\|\|\s*\w+",        # 逻辑或
        r"\|\s*\w+",          # 管道
        r"`[^`]+`",           # 命令替换
        r"\$\([^)]+\)",       # 命令替换 $()
        r"<\s*\w+",           # 输入重定向
        r">\s*\w+",           # 输出重定向
        r"\$\w+",             # 变量扩展
        r"\$\{[^}]+\}",       # 变量扩展 ${}
        r"\n\s*\w+",          # 换行符
    ]
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化命令注入检测器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self.block_on_detection = self.config.get("block", True)
        
        # 初始化解析器
        self.parser = ShellCommandParser()
        
        # 编译正则表达式
        self._compiled_signatures = [
            re.compile(pattern) for pattern in self.INJECTION_SIGNATURES
        ]
        
        # 统计
        self._stats = {
            "commands_checked": 0,
            "injections_blocked": 0
        }
        
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化检测器"""
        if self._initialized:
            return
            
        logger.info("初始化命令注入检测器...")
        self._initialized = True
        logger.info("命令注入检测器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭检测器"""
        self._initialized = False
        logger.info("命令注入检测器已关闭")
        
    def detect(self, command: str) -> tuple[bool, float, list[str]]:
        """
        检测命令注入
        
        Args:
            command: 命令字符串
            
        Returns:
            (是否注入, 置信度, 匹配的特征)
        """
        if not self.enabled:
            return False, 0.0, []
            
        self._stats["commands_checked"] += 1
        
        matches = []
        
        # 解析命令
        parsed = self.parser.parse(command)
        
        # 检测危险特征
        for signature in self._compiled_signatures:
            if signature.search(command):
                matches.append(signature.pattern)
                
        # 检测危险命令
        if parsed.command in self.parser.DANGEROUS_COMMANDS:
            matches.append(f"dangerous_command:{parsed.command}")
            
        # 计算置信度
        confidence = min(len(matches) * 0.2 + 0.3, 1.0)
        
        # 根据解析结果调整置信度
        if parsed.has_substitution:
            confidence = min(confidence + 0.3, 1.0)
        if parsed.has_pipes and len(matches) > 0:
            confidence = min(confidence + 0.2, 1.0)
            
        is_injection = len(matches) > 0 and confidence > 0.5
        
        if is_injection:
            self._stats["injections_blocked"] += 1
            
        return is_injection, confidence, matches
        
    def check_and_block(
        self,
        command: str,
        context: Optional[dict] = None
    ) -> None:
        """
        检测并阻断命令注入
        
        Args:
            command: 命令字符串
            context: 额外上下文
            
        Raises:
            CommandInjectionException: 检测到注入时抛出
        """
        is_injection, confidence, matches = self.detect(command)
        
        if is_injection and self.block_on_detection:
            raise CommandInjectionException(
                message="检测到命令注入攻击",
                payload=command[:500],
                command=command[:200],
                context=context
            )
            
    def sanitize_command(self, command: str) -> str:
        """
        净化命令
        
        Args:
            command: 原始命令
            
        Returns:
            净化后的命令
        """
        # 移除危险字符
        dangerous_chars = ";|&$`"
        sanitized = command
        for char in dangerous_chars:
            sanitized = sanitized.replace(char, "")
        return sanitized
        
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            **self._stats,
            "enabled": self.enabled
        }
