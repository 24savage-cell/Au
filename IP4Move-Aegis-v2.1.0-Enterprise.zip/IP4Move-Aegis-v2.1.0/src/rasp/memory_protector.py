"""
内存安全保护模块

提供缓冲区溢出检测和Use-After-Free防护
"""

import asyncio
import logging
import sys
import threading
import traceback
import weakref
from collections import defaultdict
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Optional

from .exception.security_exception import MemorySafetyException

logger = logging.getLogger(__name__)


class MemoryOperation(Enum):
    """内存操作类型"""
    ALLOCATE = auto()
    READ = auto()
    WRITE = auto()
    FREE = auto()
    REALLOC = auto()


@dataclass
class MemoryBlock:
    """内存块信息"""
    address: int
    size: int
    allocation_time: float
    freed: bool = False
    free_time: Optional[float] = None
    stack_trace: list[str] = None
    
    def mark_freed(self) -> None:
        """标记为已释放"""
        self.freed = True
        self.free_time = asyncio.get_event_loop().time() if asyncio.get_event_loop().is_running() else 0


class BufferOverflowDetector:
    """
    缓冲区溢出检测器
    
    检测缓冲区溢出和越界访问
    """
    
    # Canary值用于检测溢出
    CANARY_VALUE = b"\xDE\xAD\xBE\xEF"
    CANARY_SIZE = 4
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化缓冲区溢出检测器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self.use_canaries = self.config.get("use_canaries", True)
        
        # 跟踪的内存块
        self._blocks: dict[int, MemoryBlock] = {}
        self._lock = threading.RLock()
        
        # 统计
        self._stats = {
            "allocations": 0,
            "overflows_detected": 0
        }
        
    def allocate(self, size: int) -> bytearray:
        """
        分配受保护的内存
        
        Args:
            size: 分配大小
            
        Returns:
            受保护的内存块
        """
        if not self.enabled:
            return bytearray(size)
            
        with self._lock:
            # 分配额外空间用于canary
            if self.use_canaries:
                actual_size = size + self.CANARY_SIZE * 2
                buf = bytearray(actual_size)
                # 在前后放置canary
                buf[:self.CANARY_SIZE] = self.CANARY_VALUE
                buf[-self.CANARY_SIZE:] = self.CANARY_VALUE
                # 返回中间部分
                result = memoryview(buf)[self.CANARY_SIZE:-self.CANARY_SIZE]
            else:
                buf = bytearray(size)
                result = memoryview(buf)
                
            # 记录内存块
            block = MemoryBlock(
                address=id(buf),
                size=size,
                allocation_time=asyncio.get_event_loop().time() if asyncio.get_event_loop().is_running() else 0,
                stack_trace=traceback.format_stack()
            )
            self._blocks[id(buf)] = block
            self._stats["allocations"] += 1
            
            return result
            
    def check_canaries(self, buf: bytearray) -> bool:
        """
        检查canary值
        
        Args:
            buf: 内存块
            
        Returns:
            是否完好
        """
        if not self.use_canaries or not self.enabled:
            return True
            
        try:
            # 检查前canary
            if buf[:self.CANARY_SIZE] != self.CANARY_VALUE:
                return False
            # 检查后canary
            if buf[-self.CANARY_SIZE:] != self.CANARY_VALUE:
                return False
            return True
        except Exception:
            return False
            
    def detect_overflow(self, buf: bytearray) -> Optional[str]:
        """
        检测缓冲区溢出
        
        Args:
            buf: 内存块
            
        Returns:
            溢出类型或None
        """
        if not self.enabled:
            return None
            
        with self._lock:
            block_id = id(buf)
            if block_id not in self._blocks:
                return None
                
            if not self.check_canaries(buf):
                self._stats["overflows_detected"] += 1
                
                # 确定溢出方向
                if buf[:self.CANARY_SIZE] != self.CANARY_VALUE:
                    return "UNDERFLOW"
                else:
                    return "OVERFLOW"
                    
        return None
        
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            **self._stats,
            "tracked_blocks": len(self._blocks),
            "enabled": self.enabled
        }


class UseAfterFreeDetector:
    """
    Use-After-Free检测器
    
    检测对已释放内存的访问
    """
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化UAF检测器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self.quarantine_time = self.config.get("quarantine_time", 5.0)
        
        # 跟踪的内存块
        self._active_blocks: dict[int, MemoryBlock] = {}
        self._freed_blocks: dict[int, MemoryBlock] = {}
        self._lock = threading.RLock()
        
        # 统计
        self._stats = {
            "allocations": 0,
            "frees": 0,
            "uaf_detected": 0
        }
        
    def track_allocation(self, obj: Any) -> int:
        """
        跟踪对象分配
        
        Args:
            obj: 分配的对象
            
        Returns:
            对象ID
        """
        if not self.enabled:
            return id(obj)
            
        with self._lock:
            obj_id = id(obj)
            block = MemoryBlock(
                address=obj_id,
                size=sys.getsizeof(obj),
                allocation_time=asyncio.get_event_loop().time() if asyncio.get_event_loop().is_running() else 0,
                stack_trace=traceback.format_stack()
            )
            self._active_blocks[obj_id] = block
            self._stats["allocations"] += 1
            return obj_id
            
    def track_free(self, obj_id: int) -> None:
        """
        跟踪对象释放
        
        Args:
            obj_id: 对象ID
        """
        if not self.enabled:
            return
            
        with self._lock:
            if obj_id in self._active_blocks:
                block = self._active_blocks.pop(obj_id)
                block.mark_freed()
                self._freed_blocks[obj_id] = block
                self._stats["frees"] += 1
                
    def check_access(self, obj_id: int) -> bool:
        """
        检查对象访问
        
        Args:
            obj_id: 对象ID
            
        Returns:
            是否允许访问
            
        Raises:
            MemorySafetyException: 检测到UAF时抛出
        """
        if not self.enabled:
            return True
            
        with self._lock:
            # 检查是否在已释放列表中
            if obj_id in self._freed_blocks:
                self._stats["uaf_detected"] += 1
                block = self._freed_blocks[obj_id]
                raise MemorySafetyException(
                    message="检测到Use-After-Free",
                    memory_operation="ACCESS",
                    address=obj_id,
                    context={
                        "allocation_stack": block.stack_trace,
                        "free_time": block.free_time
                    }
                )
                
            return obj_id in self._active_blocks
            
    def cleanup_quarantine(self) -> None:
        """清理隔离区中的旧块"""
        if not self.enabled:
            return
            
        with self._lock:
            current_time = asyncio.get_event_loop().time() if asyncio.get_event_loop().is_running() else 0
            to_remove = [
                obj_id for obj_id, block in self._freed_blocks.items()
                if block.free_time and (current_time - block.free_time) > self.quarantine_time
            ]
            for obj_id in to_remove:
                del self._freed_blocks[obj_id]
                
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            **self._stats,
            "active_blocks": len(self._active_blocks),
            "quarantined_blocks": len(self._freed_blocks),
            "enabled": self.enabled
        }


class MemoryProtector:
    """
    内存安全保护器
    
    整合缓冲区溢出检测和UAF防护
    """
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化内存保护器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        
        # 初始化检测器
        self.buffer_detector = BufferOverflowDetector(
            self.config.get("buffer", {})
        )
        self.uaf_detector = UseAfterFreeDetector(
            self.config.get("uaf", {})
        )
        
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化保护器"""
        if self._initialized:
            return
            
        logger.info("初始化内存保护器...")
        self._initialized = True
        logger.info("内存保护器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭保护器"""
        self._initialized = False
        logger.info("内存保护器已关闭")
        
    def allocate_protected(self, size: int) -> bytearray:
        """
        分配受保护的内存
        
        Args:
            size: 分配大小
            
        Returns:
            受保护的内存块
        """
        return self.buffer_detector.allocate(size)
        
    def track_object(self, obj: Any) -> int:
        """
        跟踪对象
        
        Args:
            obj: 对象
            
        Returns:
            对象ID
        """
        return self.uaf_detector.track_allocation(obj)
        
    def untrack_object(self, obj_id: int) -> None:
        """
        取消跟踪对象
        
        Args:
            obj_id: 对象ID
        """
        self.uaf_detector.track_free(obj_id)
        
    def check_object_access(self, obj_id: int) -> bool:
        """
        检查对象访问
        
        Args:
            obj_id: 对象ID
            
        Returns:
            是否允许访问
        """
        return self.uaf_detector.check_access(obj_id)
        
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            "buffer_overflow": self.buffer_detector.get_stats(),
            "use_after_free": self.uaf_detector.get_stats(),
            "enabled": self.enabled
        }
