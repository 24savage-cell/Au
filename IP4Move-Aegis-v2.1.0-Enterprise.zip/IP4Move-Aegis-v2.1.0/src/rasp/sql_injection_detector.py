"""
SQL注入检测模块

提供基于模式匹配、语法树分析和统计异常的SQL注入检测
"""

import asyncio
import logging
import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Optional, Union
from datetime import datetime

from .exception.security_exception import SQLInjectionException
from .exception.attack_context import (
    AttackContext,
    AttackContextBuilder,
    AttackSeverity
)

logger = logging.getLogger(__name__)


class SQLInjectionType(Enum):
    """SQL注入类型"""
    UNION_BASED = auto()       # UNION注入
    ERROR_BASED = auto()       # 报错注入
    BOOLEAN_BLIND = auto()     # 布尔盲注
    TIME_BLIND = auto()        # 时间盲注
    STACKED_QUERIES = auto()   # 堆叠查询
    OUT_OF_BAND = auto()       # 带外注入
    UNKNOWN = auto()           # 未知类型


@dataclass
class SQLSyntaxNode:
    """SQL语法树节点"""
    node_type: str
    value: str
    children: list["SQLSyntaxNode"]
    position: int


@dataclass
class DetectionResult:
    """检测结果"""
    is_injection: bool
    injection_type: SQLInjectionType
    confidence: float
    matched_patterns: list[str]
    syntax_anomalies: list[str]
    statistical_score: float


class SQLSyntaxAnalyzer:
    """
    SQL语法分析器
    
    通过解析SQL语法树检测异常结构
    """
    
    # SQL关键字
    SQL_KEYWORDS = {
        "SELECT", "INSERT", "UPDATE", "DELETE", "DROP", "CREATE",
        "ALTER", "TABLE", "FROM", "WHERE", "AND", "OR", "NOT",
        "NULL", "UNION", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER",
        "GROUP", "BY", "ORDER", "HAVING", "LIMIT", "OFFSET",
        "EXEC", "EXECUTE", "XP_", "SP_", "CAST", "CONVERT"
    }
    
    # 危险的SQL函数
    DANGEROUS_FUNCTIONS = {
        "load_file", "into outfile", "into dumpfile",
        "benchmark", "sleep", "waitfor delay",
        "xp_cmdshell", "sp_oamethod", "sp_oacreate"
    }
    
    def __init__(self):
        """初始化语法分析器"""
        self._parse_cache: dict[str, SQLSyntaxNode] = {}
        
    def analyze(self, query: str) -> list[str]:
        """
        分析SQL查询
        
        Args:
            query: SQL查询字符串
            
        Returns:
            检测到的异常列表
        """
        anomalies = []
        query_upper = query.upper()
        
        # 检查注释滥用
        if self._has_comment_abuse(query):
            anomalies.append("COMMENT_ABUSE")
            
        # 检查关键字堆叠
        if self._has_stacked_keywords(query_upper):
            anomalies.append("STACKED_KEYWORDS")
            
        # 检查布尔逻辑异常
        if self._has_boolean_anomaly(query_upper):
            anomalies.append("BOOLEAN_ANOMALY")
            
        # 检查UNION注入
        if self._has_union_injection(query_upper):
            anomalies.append("UNION_INJECTION")
            
        # 检查时间延迟函数
        if self._has_time_delay(query_lower := query.lower()):
            anomalies.append("TIME_DELAY")
            
        # 检查危险函数
        if self._has_dangerous_functions(query_lower):
            anomalies.append("DANGEROUS_FUNCTION")
            
        return anomalies
        
    def _has_comment_abuse(self, query: str) -> bool:
        """检查注释滥用"""
        # 内联注释 /**/ 用于绕过过滤
        inline_comment_pattern = r"/\*!?[\s\w]*\*/"
        if re.search(inline_comment_pattern, query):
            return True
        return False
        
    def _has_stacked_keywords(self, query: str) -> bool:
        """检查关键字堆叠"""
        # 检测多个SELECT或UNION
        select_count = query.count("SELECT")
        union_count = query.count("UNION")
        
        if select_count > 2 or union_count > 1:
            return True
        return False
        
    def _has_boolean_anomaly(self, query: str) -> bool:
        """检查布尔逻辑异常"""
        # 检测 OR 1=1, AND 1=1 等模式
        boolean_patterns = [
            r"OR\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+['\"]?",
            r"AND\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+['\"]?",
            r"OR\s+['\"].*?['\"]\s*=\s*['\"].*?['\"]",
        ]
        
        for pattern in boolean_patterns:
            if re.search(pattern, query, re.IGNORECASE):
                return True
        return False
        
    def _has_union_injection(self, query: str) -> bool:
        """检查UNION注入"""
        union_pattern = r"UNION\s+(ALL\s+)?SELECT"
        if re.search(union_pattern, query, re.IGNORECASE):
            return True
        return False
        
    def _has_time_delay(self, query: str) -> bool:
        """检查时间延迟函数"""
        for func in self.DANGEROUS_FUNCTIONS:
            if func in query:
                return True
        return False
        
    def _has_dangerous_functions(self, query: str) -> bool:
        """检查危险函数调用"""
        dangerous_patterns = [
            r"xp_cmdshell",
            r"sp_oamethod",
            r"sp_oacreate",
            r"load_file\s*\(",
            r"into\s+(outfile|dumpfile)"
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, query, re.IGNORECASE):
                return True
        return False


class SQLInjectionDetector:
    """
    SQL注入检测器
    
    综合使用多种技术检测SQL注入攻击：
    1. 模式匹配：基于正则表达式的特征检测
    2. 语法树分析：分析SQL结构异常
    3. 统计异常：基于熵和字符分布的检测
    
    Attributes:
        syntax_analyzer: SQL语法分析器
        detection_threshold: 检测阈值
    """
    
    # SQL注入特征模式
    INJECTION_PATTERNS = {
        "UNION_SELECT": r"UNION\s+(ALL\s+)?SELECT",
        "ERROR_BASED": r"(AND|OR)\s+\d+=\d+",
        "COMMENT": r"(--|#|/\*)",
        "BOOLEAN_BLIND": r"(AND|OR)\s+\(\s*SELECT\s+",
        "TIME_BLIND": r"(SLEEP|BENCHMARK|WAITFOR\s+DELAY)",
        "STACKED_QUERY": r";\s*(SELECT|INSERT|UPDATE|DELETE|DROP)",
        "QUOTE_ESCAPE": r"['\"]\s*OR\s*['\"]\s*=\s*['\"]",
        "CHAR_ENCODING": r"(CHAR\s*\(|CONCAT\s*\(|0x[0-9a-fA-F]+)",
        "OUT_OF_BAND": r"(LOAD_FILE|INTO\s+OUTFILE|INTO\s+DUMPFILE)",
        "PIGGYBACKED": r";\s*DROP\s+|\s*--\s*DROP\s+",
    }
    
    # 危险的SQL操作
    DANGEROUS_OPERATIONS = [
        "DROP", "DELETE", "TRUNCATE", "ALTER", "GRANT", "REVOKE"
    ]
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化SQL注入检测器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self.detection_threshold = self.config.get("threshold", 0.7)
        self.block_on_detection = self.config.get("block", True)
        
        # 初始化组件
        self.syntax_analyzer = SQLSyntaxAnalyzer()
        
        # 编译正则表达式
        self._compiled_patterns = {
            name: re.compile(pattern, re.IGNORECASE)
            for name, pattern in self.INJECTION_PATTERNS.items()
        }
        
        # 统计
        self._stats = {
            "queries_checked": 0,
            "injections_detected": 0,
            "false_positives": 0
        }
        
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化检测器"""
        if self._initialized:
            return
            
        logger.info("初始化SQL注入检测器...")
        self._initialized = True
        logger.info("SQL注入检测器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭检测器"""
        self._initialized = False
        logger.info("SQL注入检测器已关闭")
        
    def detect(
        self,
        query: str,
        context: Optional[dict] = None
    ) -> DetectionResult:
        """
        检测SQL注入
        
        Args:
            query: SQL查询
            context: 额外上下文
            
        Returns:
            检测结果
        """
        if not self.enabled:
            return DetectionResult(
                is_injection=False,
                injection_type=SQLInjectionType.UNKNOWN,
                confidence=0.0,
                matched_patterns=[],
                syntax_anomalies=[],
                statistical_score=0.0
            )
            
        self._stats["queries_checked"] += 1
        
        # 1. 模式匹配检测
        pattern_matches = self._pattern_match_detection(query)
        
        # 2. 语法树分析
        syntax_anomalies = self.syntax_analyzer.analyze(query)
        
        # 3. 统计异常检测
        statistical_score = self._statistical_detection(query)
        
        # 综合评分
        confidence = self._calculate_confidence(
            pattern_matches,
            syntax_anomalies,
            statistical_score
        )
        
        # 确定注入类型
        injection_type = self._determine_injection_type(
            pattern_matches,
            syntax_anomalies
        )
        
        is_injection = confidence >= self.detection_threshold
        
        if is_injection:
            self._stats["injections_detected"] += 1
            
        return DetectionResult(
            is_injection=is_injection,
            injection_type=injection_type,
            confidence=confidence,
            matched_patterns=pattern_matches,
            syntax_anomalies=syntax_anomalies,
            statistical_score=statistical_score
        )
        
    def check_and_block(
        self,
        query: str,
        context: Optional[dict] = None
    ) -> None:
        """
        检测并阻断SQL注入
        
        Args:
            query: SQL查询
            context: 额外上下文
            
        Raises:
            SQLInjectionException: 检测到注入时抛出
        """
        result = self.detect(query, context)
        
        if result.is_injection and self.block_on_detection:
            # 构建攻击上下文
            attack_context = (
                AttackContextBuilder()
                .with_attack_type("SQL_INJECTION")
                .with_severity(AttackSeverity.CRITICAL)
                .with_detection_method("multi_layer_analysis")
                .with_confidence(result.confidence)
                .with_metadata("injection_type", result.injection_type.name)
                .with_metadata("matched_patterns", result.matched_patterns)
                .with_metadata("syntax_anomalies", result.syntax_anomalies)
                .build()
            )
            
            raise SQLInjectionException(
                message=f"检测到SQL注入攻击: {result.injection_type.name}",
                payload=query[:500],
                query_fragment=self._extract_query_fragment(query),
                context=context
            )
            
    def _pattern_match_detection(self, query: str) -> list[str]:
        """
        基于模式的检测
        
        Args:
            query: SQL查询
            
        Returns:
            匹配的模式列表
        """
        matches = []
        
        for name, pattern in self._compiled_patterns.items():
            if pattern.search(query):
                matches.append(name)
                
        return matches
        
    def _statistical_detection(self, query: str) -> float:
        """
        基于统计的异常检测
        
        使用熵分析和字符分布检测异常
        
        Args:
            query: SQL查询
            
        Returns:
            异常分数 (0-1)
        """
        if not query:
            return 0.0
            
        scores = []
        
        # 1. 熵分析
        entropy_score = self._calculate_entropy(query)
        scores.append(min(entropy_score / 5.0, 1.0))  # 归一化
        
        # 2. 特殊字符比例
        special_chars = sum(1 for c in query if not c.isalnum() and not c.isspace())
        special_ratio = special_chars / len(query)
        scores.append(min(special_ratio * 3, 1.0))
        
        # 3. 关键字密度
        keyword_count = sum(1 for kw in self.syntax_analyzer.SQL_KEYWORDS 
                          if kw in query.upper())
        keyword_density = keyword_count / len(query.split())
        scores.append(min(keyword_density * 2, 1.0))
        
        # 4. 长度异常
        if len(query) > 1000:
            scores.append(0.3)
            
        return sum(scores) / len(scores)
        
    def _calculate_entropy(self, data: str) -> float:
        """
        计算香农熵
        
        Args:
            data: 输入数据
            
        Returns:
            熵值
        """
        if not data:
            return 0.0
            
        # 计算字符频率
        freq = {}
        for char in data:
            freq[char] = freq.get(char, 0) + 1
            
        # 计算熵
        length = len(data)
        entropy = 0.0
        
        for count in freq.values():
            p = count / length
            if p > 0:
                entropy -= p * (p.bit_length() - 1)  # 近似log2
                
        return entropy
        
    def _calculate_confidence(
        self,
        pattern_matches: list[str],
        syntax_anomalies: list[str],
        statistical_score: float
    ) -> float:
        """
        计算综合置信度
        
        Args:
            pattern_matches: 模式匹配结果
            syntax_anomalies: 语法异常
            statistical_score: 统计分数
            
        Returns:
            综合置信度
        """
        # 权重
        pattern_weight = 0.5
        syntax_weight = 0.3
        stat_weight = 0.2
        
        # 模式匹配分数
        pattern_score = min(len(pattern_matches) * 0.25, 1.0)
        
        # 语法异常分数
        syntax_score = min(len(syntax_anomalies) * 0.3, 1.0)
        
        # 加权计算
        confidence = (
            pattern_score * pattern_weight +
            syntax_score * syntax_weight +
            statistical_score * stat_weight
        )
        
        return min(confidence, 1.0)
        
    def _determine_injection_type(
        self,
        pattern_matches: list[str],
        syntax_anomalies: list[str]
    ) -> SQLInjectionType:
        """
        确定注入类型
        
        Args:
            pattern_matches: 模式匹配结果
            syntax_anomalies: 语法异常
            
        Returns:
            注入类型
        """
        if "UNION_SELECT" in pattern_matches:
            return SQLInjectionType.UNION_BASED
        elif "TIME_BLIND" in pattern_matches:
            return SQLInjectionType.TIME_BLIND
        elif "BOOLEAN_BLIND" in pattern_matches:
            return SQLInjectionType.BOOLEAN_BLIND
        elif "STACKED_QUERY" in pattern_matches:
            return SQLInjectionType.STACKED_QUERIES
        elif "OUT_OF_BAND" in pattern_matches:
            return SQLInjectionType.OUT_OF_BAND
        elif "ERROR_BASED" in pattern_matches or "syntax_anomalies" in str(syntax_anomalies):
            return SQLInjectionType.ERROR_BASED
            
        return SQLInjectionType.UNKNOWN
        
    def _extract_query_fragment(self, query: str, max_length: int = 200) -> str:
        """
        提取可疑的查询片段
        
        Args:
            query: SQL查询
            max_length: 最大长度
            
        Returns:
            可疑片段
        """
        # 查找包含关键字的部分
        suspicious_keywords = ["UNION", "SELECT", "OR", "AND", "DROP", "DELETE"]
        
        for keyword in suspicious_keywords:
            idx = query.upper().find(keyword)
            if idx != -1:
                start = max(0, idx - 50)
                end = min(len(query), idx + max_length)
                return query[start:end]
                
        return query[:max_length]
        
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            **self._stats,
            "detection_threshold": self.detection_threshold,
            "enabled": self.enabled
        }
        
    def add_custom_pattern(self, name: str, pattern: str) -> None:
        """
        添加自定义检测模式
        
        Args:
            name: 模式名称
            pattern: 正则表达式
        """
        self._compiled_patterns[name] = re.compile(pattern, re.IGNORECASE)
        logger.info(f"添加自定义SQL注入检测模式: {name}")
