"""
运行时监控模块

提供系统调用Hook、函数调用监控和行为基线学习能力
"""

import asyncio
import functools
import inspect
import logging
import threading
import time
import traceback
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Coroutine, Optional, TypeVar, Union
from datetime import datetime, timedelta

from .exception.security_exception import BehaviorAnomalyException
from .exception.attack_context import (
    AttackContext,
    AttackContextBuilder,
    AttackSeverity,
    AttackStatus
)

# 配置日志
logger = logging.getLogger(__name__)

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])


class MonitorEventType(Enum):
    """监控事件类型"""
    FUNCTION_CALL = auto()
    SYSTEM_CALL = auto()
    FILE_ACCESS = auto()
    NETWORK_OPERATION = auto()
    MEMORY_ALLOCATION = auto()
    AUTHENTICATION = auto()
    AUTHORIZATION = auto()


@dataclass
class FunctionCallEvent:
    """函数调用事件"""
    function_name: str
    module_name: str
    args: tuple
    kwargs: dict
    start_time: datetime
    end_time: Optional[datetime] = None
    return_value: Any = None
    exception: Optional[Exception] = None
    caller_info: dict = field(default_factory=dict)
    
    @property
    def duration_ms(self) -> float:
        """获取执行时长（毫秒）"""
        if self.end_time:
            return (self.end_time - self.start_time).total_seconds() * 1000
        return 0.0


@dataclass
class SystemCallEvent:
    """系统调用事件"""
    syscall_name: str
    args: tuple
    timestamp: datetime
    pid: int
    tid: int
    result: Any = None
    error: Optional[str] = None


@dataclass
class BehaviorPattern:
    """行为模式"""
    pattern_id: str
    pattern_type: str
    frequency: int
    avg_duration_ms: float
    time_window: timedelta
    first_seen: datetime
    last_seen: datetime
    metadata: dict = field(default_factory=dict)


class BehaviorBaseline:
    """
    行为基线学习器
    
    学习应用正常运行时的行为模式，建立基线用于异常检测
    
    Attributes:
        window_size: 滑动窗口大小
        learning_threshold: 学习阈值（调用次数）
        anomaly_threshold: 异常阈值（标准差倍数）
    """
    
    def __init__(
        self,
        window_size: int = 1000,
        learning_threshold: int = 100,
        anomaly_threshold: float = 3.0
    ):
        """
        初始化行为基线学习器
        
        Args:
            window_size: 滑动窗口大小
            learning_threshold: 学习阈值
            anomaly_threshold: 异常阈值
        """
        self.window_size = window_size
        self.learning_threshold = learning_threshold
        self.anomaly_threshold = anomaly_threshold
        
        # 行为数据存储
        self._call_history: dict[str, deque[FunctionCallEvent]] = defaultdict(
            lambda: deque(maxlen=window_size)
        )
        self._baseline_stats: dict[str, dict[str, float]] = {}
        self._patterns: dict[str, BehaviorPattern] = {}
        
        # 线程锁
        self._lock = threading.RLock()
        
        # 学习状态
        self._is_learning = True
        self._call_counts: dict[str, int] = defaultdict(int)
        
    def record_call(self, event: FunctionCallEvent) -> None:
        """
        记录函数调用
        
        Args:
            event: 函数调用事件
        """
        key = f"{event.module_name}.{event.function_name}"
        
        with self._lock:
            self._call_history[key].append(event)
            self._call_counts[key] += 1
            
            # 自动更新基线
            if self._is_learning and self._call_counts[key] >= self.learning_threshold:
                self._update_baseline(key)
                
    def _update_baseline(self, key: str) -> None:
        """
        更新基线统计
        
        Args:
            key: 函数标识
        """
        events = list(self._call_history[key])
        if not events:
            return
            
        durations = [e.duration_ms for e in events]
        
        # 计算统计值
        n = len(durations)
        mean = sum(durations) / n
        variance = sum((d - mean) ** 2 for d in durations) / n
        std_dev = variance ** 0.5
        
        self._baseline_stats[key] = {
            "mean_duration_ms": mean,
            "std_dev": std_dev,
            "min_duration_ms": min(durations),
            "max_duration_ms": max(durations),
            "call_count": n,
            "updated_at": time.time()
        }
        
        logger.debug(f"更新基线: {key}, 均值={mean:.2f}ms, 标准差={std_dev:.2f}ms")
        
    def check_anomaly(self, event: FunctionCallEvent) -> tuple[bool, float]:
        """
        检查是否异常
        
        Args:
            event: 函数调用事件
            
        Returns:
            (是否异常, 异常分数)
        """
        key = f"{event.module_name}.{event.function_name}"
        
        with self._lock:
            stats = self._baseline_stats.get(key)
            
            # 基线尚未建立
            if not stats:
                return False, 0.0
                
            mean = stats["mean_duration_ms"]
            std_dev = stats["std_dev"]
            
            # 避免除零
            if std_dev == 0:
                std_dev = 0.001
                
            # 计算Z-score
            z_score = abs(event.duration_ms - mean) / std_dev
            
            # 检查是否超过阈值
            is_anomaly = z_score > self.anomaly_threshold
            
            return is_anomaly, z_score
            
    def get_baseline_report(self) -> dict[str, Any]:
        """
        获取基线报告
        
        Returns:
            基线统计报告
        """
        with self._lock:
            return {
                "total_functions": len(self._baseline_stats),
                "is_learning": self._is_learning,
                "baselines": dict(self._baseline_stats),
                "patterns": {
                    k: {
                        "type": v.pattern_type,
                        "frequency": v.frequency,
                        "avg_duration_ms": v.avg_duration_ms
                    }
                    for k, v in self._patterns.items()
                }
            }
            
    def start_learning(self) -> None:
        """开始学习模式"""
        self._is_learning = True
        logger.info("行为基线学习模式已启动")
        
    def stop_learning(self) -> None:
        """停止学习模式"""
        self._is_learning = False
        logger.info("行为基线学习模式已停止")
        
    def reset(self) -> None:
        """重置所有基线数据"""
        with self._lock:
            self._call_history.clear()
            self._baseline_stats.clear()
            self._patterns.clear()
            self._call_counts.clear()
            self._is_learning = True
            logger.info("行为基线已重置")


class SystemCallHook:
    """
    系统调用Hook
    
    监控系统调用并检测异常行为
    
    Attributes:
        monitored_syscalls: 监控的系统调用列表
        hook_enabled: 是否启用Hook
    """
    
    # 危险系统调用列表
    DANGEROUS_SYSCALLS = {
        "execve", "execv", "system", "popen",
        "open", "openat", "creat",
        "socket", "connect", "bind", "listen",
        "mmap", "mprotect", "munmap",
        "ptrace", "process_vm_writev"
    }
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化系统调用Hook
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.monitored_syscalls: set[str] = set(
            self.config.get("monitored_syscalls", self.DANGEROUS_SYSCALLS)
        )
        self.hook_enabled = self.config.get("enabled", True)
        self._event_handlers: list[Callable[[SystemCallEvent], None]] = []
        self._syscall_count: dict[str, int] = defaultdict(int)
        
    def register_handler(self, handler: Callable[[SystemCallEvent], None]) -> None:
        """
        注册事件处理器
        
        Args:
            handler: 事件处理函数
        """
        self._event_handlers.append(handler)
        
    def on_syscall(
        self,
        syscall_name: str,
        args: tuple,
        result: Any = None,
        error: Optional[str] = None
    ) -> None:
        """
        系统调用回调
        
        Args:
            syscall_name: 系统调用名
            args: 参数
            result: 结果
            error: 错误信息
        """
        if not self.hook_enabled:
            return
            
        if syscall_name not in self.monitored_syscalls:
            return
            
        event = SystemCallEvent(
            syscall_name=syscall_name,
            args=args,
            timestamp=datetime.utcnow(),
            pid=threading.current_thread().ident or 0,
            tid=threading.get_ident(),
            result=result,
            error=error
        )
        
        self._syscall_count[syscall_name] += 1
        
        # 通知处理器
        for handler in self._event_handlers:
            try:
                handler(event)
            except Exception as e:
                logger.error(f"系统调用处理器错误: {e}")
                
    def get_stats(self) -> dict[str, int]:
        """
        获取统计信息
        
        Returns:
            系统调用统计
        """
        return dict(self._syscall_count)


class RuntimeMonitor:
    """
    运行时监控器
    
    整合函数调用监控、系统调用Hook和行为基线学习
    
    Attributes:
        baseline: 行为基线学习器
        syscall_hook: 系统调用Hook
        monitoring_enabled: 是否启用监控
    """
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化运行时监控器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.monitoring_enabled = self.config.get("enabled", True)
        
        # 初始化组件
        self.baseline = BehaviorBaseline(
            window_size=self.config.get("window_size", 1000),
            learning_threshold=self.config.get("learning_threshold", 100),
            anomaly_threshold=self.config.get("anomaly_threshold", 3.0)
        )
        self.syscall_hook = SystemCallHook(
            self.config.get("syscall", {})
        )
        
        # 事件处理器
        self._anomaly_handlers: list[Callable[[AttackContext], Coroutine]] = []
        
        # 监控状态
        self._initialized = False
        self._monitoring_task: Optional[asyncio.Task] = None
        
    async def initialize(self) -> None:
        """初始化监控器"""
        if self._initialized:
            return
            
        logger.info("初始化运行时监控器...")
        
        # 注册系统调用处理器
        self.syscall_hook.register_handler(self._on_syscall_event)
        
        # 启动后台任务
        self._monitoring_task = asyncio.create_task(self._monitoring_loop())
        
        self._initialized = True
        logger.info("运行时监控器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭监控器"""
        if not self._initialized:
            return
            
        logger.info("关闭运行时监控器...")
        
        if self._monitoring_task:
            self._monitoring_task.cancel()
            try:
                await self._monitoring_task
            except asyncio.CancelledError:
                pass
                
        self._initialized = False
        logger.info("运行时监控器已关闭")
        
    def _on_syscall_event(self, event: SystemCallEvent) -> None:
        """
        系统调用事件处理
        
        Args:
            event: 系统调用事件
        """
        # 检测可疑的系统调用模式
        if self._is_suspicious_syscall_pattern(event):
            logger.warning(f"检测到可疑系统调用: {event.syscall_name}")
            
    def _is_suspicious_syscall_pattern(self, event: SystemCallEvent) -> bool:
        """
        检测可疑的系统调用模式
        
        Args:
            event: 系统调用事件
            
        Returns:
            是否可疑
        """
        # 检测exec系列调用的可疑参数
        if event.syscall_name in ("execve", "system", "popen"):
            if event.args:
                cmd = str(event.args[0])
                suspicious_patterns = ["rm -rf /", "mkfs", "dd if=/dev/zero"]
                return any(p in cmd for p in suspicious_patterns)
        return False
        
    async def _monitoring_loop(self) -> None:
        """监控循环"""
        while True:
            try:
                await asyncio.sleep(60)  # 每分钟检查一次
                
                # 生成监控报告
                report = self.generate_report()
                logger.debug(f"运行时监控报告: {report}")
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"监控循环错误: {e}")
                
    def monitor_function(
        self,
        func: F,
        *,
        track_args: bool = False,
        alert_on_anomaly: bool = True
    ) -> F:
        """
        函数监控装饰器
        
        Args:
            func: 被监控的函数
            track_args: 是否追踪参数
            alert_on_anomaly: 异常时是否告警
            
        Returns:
            包装后的函数
        """
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if not self.monitoring_enabled:
                return func(*args, **kwargs)
                
            # 获取调用者信息
            caller_frame = inspect.currentframe().f_back
            caller_info = {
                "filename": caller_frame.f_code.co_filename,
                "lineno": caller_frame.f_lineno,
                "function": caller_frame.f_code.co_name
            }
            
            # 创建事件
            event = FunctionCallEvent(
                function_name=func.__name__,
                module_name=func.__module__,
                args=args if track_args else (),
                kwargs=kwargs if track_args else {},
                start_time=datetime.utcnow(),
                caller_info=caller_info
            )
            
            try:
                # 执行函数
                result = func(*args, **kwargs)
                event.return_value = result
                return result
                
            except Exception as e:
                event.exception = e
                raise
                
            finally:
                event.end_time = datetime.utcnow()
                
                # 记录到基线
                self.baseline.record_call(event)
                
                # 检查异常
                if alert_on_anomaly:
                    is_anomaly, score = self.baseline.check_anomaly(event)
                    if is_anomaly:
                        self._handle_anomaly(event, score)
                        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            if not self.monitoring_enabled:
                return await func(*args, **kwargs)
                
            caller_frame = inspect.currentframe().f_back
            caller_info = {
                "filename": caller_frame.f_code.co_filename,
                "lineno": caller_frame.f_lineno,
                "function": caller_frame.f_code.co_name
            }
            
            event = FunctionCallEvent(
                function_name=func.__name__,
                module_name=func.__module__,
                args=args if track_args else (),
                kwargs=kwargs if track_args else {},
                start_time=datetime.utcnow(),
                caller_info=caller_info
            )
            
            try:
                result = await func(*args, **kwargs)
                event.return_value = result
                return result
                
            except Exception as e:
                event.exception = e
                raise
                
            finally:
                event.end_time = datetime.utcnow()
                self.baseline.record_call(event)
                
                if alert_on_anomaly:
                    is_anomaly, score = self.baseline.check_anomaly(event)
                    if is_anomaly:
                        await self._handle_anomaly_async(event, score)
                        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper
        
    def _handle_anomaly(self, event: FunctionCallEvent, score: float) -> None:
        """
        处理异常（同步版本）
        
        Args:
            event: 函数调用事件
            score: 异常分数
        """
        key = f"{event.module_name}.{event.function_name}"
        logger.warning(f"检测到行为异常: {key}, 分数={score:.2f}")
        
        # 创建攻击上下文
        context = (
            AttackContextBuilder()
            .with_attack_type("BEHAVIOR_ANOMALY")
            .with_severity(AttackSeverity.MEDIUM)
            .with_application(
                module=event.module_name,
                function=event.function_name
            )
            .with_confidence(min(score / 5.0, 1.0))
            .with_metadata("duration_ms", event.duration_ms)
            .with_metadata("z_score", score)
            .build()
        )
        
        # 异步通知处理器
        asyncio.create_task(self._notify_anomaly_handlers(context))
        
    async def _handle_anomaly_async(self, event: FunctionCallEvent, score: float) -> None:
        """
        处理异常（异步版本）
        
        Args:
            event: 函数调用事件
            score: 异常分数
        """
        self._handle_anomaly(event, score)
        
    async def _notify_anomaly_handlers(self, context: AttackContext) -> None:
        """
        通知异常处理器
        
        Args:
            context: 攻击上下文
        """
        for handler in self._anomaly_handlers:
            try:
                await handler(context)
            except Exception as e:
                logger.error(f"异常处理器错误: {e}")
                
    def register_anomaly_handler(
        self,
        handler: Callable[[AttackContext], Coroutine]
    ) -> None:
        """
        注册异常处理器
        
        Args:
            handler: 异常处理函数
        """
        self._anomaly_handlers.append(handler)
        
    def generate_report(self) -> dict[str, Any]:
        """
        生成监控报告
        
        Returns:
            监控报告
        """
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "monitoring_enabled": self.monitoring_enabled,
            "baseline_report": self.baseline.get_baseline_report(),
            "syscall_stats": self.syscall_hook.get_stats()
        }
        
    def start_learning(self) -> None:
        """启动基线学习"""
        self.baseline.start_learning()
        
    def stop_learning(self) -> None:
        """停止基线学习"""
        self.baseline.stop_learning()
