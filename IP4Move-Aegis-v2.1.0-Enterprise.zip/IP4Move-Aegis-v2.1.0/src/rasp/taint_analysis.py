"""
污点分析引擎模块

提供污点标记、传播追踪和Sink检查功能
"""

import asyncio
import inspect
import logging
import re
import threading
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Coroutine, Optional, TypeVar, Union
from datetime import datetime
from collections import defaultdict

from .exception.security_exception import TaintViolationException
from .exception.attack_context import (
    AttackContext,
    AttackContextBuilder,
    AttackSeverity
)

logger = logging.getLogger(__name__)

T = TypeVar("T")


class TaintLevel(Enum):
    """污点级别"""
    NONE = 0           # 无污染
    LOW = 1            # 低危
    MEDIUM = 2         # 中危
    HIGH = 3           # 高危
    CRITICAL = 4       # 严重


class TaintSourceType(Enum):
    """污点来源类型"""
    USER_INPUT = auto()        # 用户输入
    HTTP_REQUEST = auto()      # HTTP请求
    DATABASE = auto()          # 数据库
    FILE_SYSTEM = auto()       # 文件系统
    NETWORK = auto()           # 网络
    ENVIRONMENT = auto()       # 环境变量
    EXTERNAL_API = auto()      # 外部API


@dataclass
class TaintSource:
    """
    污点来源
    
    记录污点数据的来源信息
    
    Attributes:
        source_id: 来源唯一标识
        source_type: 来源类型
        source_name: 来源名称
        original_value: 原始值
        timestamp: 标记时间
        metadata: 额外元数据
    """
    source_id: str
    source_type: TaintSourceType
    source_name: str
    original_value: Any
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: dict = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "source_id": self.source_id,
            "source_type": self.source_type.name,
            "source_name": self.source_name,
            "original_value": str(self.original_value)[:200],
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata
        }


@dataclass
class TaintSink:
    """
    污点Sink点
    
    定义危险的数据使用位置
    
    Attributes:
        sink_id: Sink唯一标识
        sink_name: Sink名称
        sink_type: Sink类型
        description: 描述
        required_level: 触发告警所需的最低污点级别
    """
    sink_id: str
    sink_name: str
    sink_type: str
    description: str
    required_level: TaintLevel = TaintLevel.LOW
    
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "sink_id": self.sink_id,
            "sink_name": self.sink_name,
            "sink_type": self.sink_type,
            "description": self.description,
            "required_level": self.required_level.name
        }


@dataclass
class TaintMark:
    """
    污点标记
    
    附加在数据上的污点信息
    
    Attributes:
        mark_id: 标记唯一标识
        source: 污点来源
        level: 污点级别
        propagation_path: 传播路径
        transformations: 经历的转换操作
    """
    mark_id: str
    source: TaintSource
    level: TaintLevel
    propagation_path: list[str] = field(default_factory=list)
    transformations: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    def add_propagation_step(self, step: str) -> None:
        """添加传播步骤"""
        self.propagation_path.append(step)
        
    def add_transformation(self, transformation: str) -> None:
        """添加转换操作"""
        self.transformations.append(transformation)
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "mark_id": self.mark_id,
            "source": self.source.to_dict(),
            "level": self.level.name,
            "propagation_path": self.propagation_path,
            "transformations": self.transformations,
            "created_at": self.created_at.isoformat()
        }


class TaintedValue:
    """
    被污染的值
    
    包装任意值并附加污点标记
    
    Attributes:
        value: 实际值
        taint_marks: 污点标记列表
    """
    
    _mark_counter = 0
    _lock = threading.Lock()
    
    def __init__(self, value: Any, taint_marks: Optional[list[TaintMark]] = None):
        """
        初始化被污染的值
        
        Args:
            value: 实际值
            taint_marks: 污点标记列表
        """
        self._value = value
        self._taint_marks = taint_marks or []
        
    @property
    def value(self) -> Any:
        """获取实际值"""
        return self._value
        
    @property
    def taint_marks(self) -> list[TaintMark]:
        """获取污点标记"""
        return self._taint_marks.copy()
        
    @property
    def is_tainted(self) -> bool:
        """检查是否有污点"""
        return len(self._taint_marks) > 0
        
    @property
    def highest_taint_level(self) -> TaintLevel:
        """获取最高污点级别"""
        if not self._taint_marks:
            return TaintLevel.NONE
        return max(mark.level for mark in self._taint_marks)
        
    def add_mark(self, mark: TaintMark) -> "TaintedValue":
        """
        添加污点标记
        
        Args:
            mark: 污点标记
            
        Returns:
            新的TaintedValue实例
        """
        new_marks = self._taint_marks + [mark]
        return TaintedValue(self._value, new_marks)
        
    def merge(self, other: "TaintedValue") -> "TaintedValue":
        """
        合并另一个被污染值的标记
        
        Args:
            other: 另一个被污染值
            
        Returns:
            新的TaintedValue实例
        """
        merged_marks = self._taint_marks + other._taint_marks
        return TaintedValue(self._value, merged_marks)
        
    def propagate(
        self,
        new_value: Any,
        transformation: str,
        propagation_step: str
    ) -> "TaintedValue":
        """
        传播污点到新值
        
        Args:
            new_value: 新值
            transformation: 转换操作
            propagation_step: 传播步骤
            
        Returns:
            新的TaintedValue实例
        """
        new_marks = []
        for mark in self._taint_marks:
            new_mark = TaintMark(
                mark_id=self._generate_mark_id(),
                source=mark.source,
                level=mark.level,
                propagation_path=mark.propagation_path + [propagation_step],
                transformations=mark.transformations + [transformation]
            )
            new_marks.append(new_mark)
        return TaintedValue(new_value, new_marks)
        
    def sanitize(self, sanitizer_name: str) -> "TaintedValue":
        """
        净化污点（降低级别）
        
        Args:
            sanitizer_name: 净化器名称
            
        Returns:
            净化后的TaintedValue
        """
        # 降低所有标记的级别
        sanitized_marks = []
        for mark in self._taint_marks:
            new_level = TaintLevel(max(0, mark.level.value - 1))
            new_mark = TaintMark(
                mark_id=mark.mark_id,
                source=mark.source,
                level=new_level,
                propagation_path=mark.propagation_path + [f"sanitized_by:{sanitizer_name}"],
                transformations=mark.transformations
            )
            sanitized_marks.append(new_mark)
        return TaintedValue(self._value, sanitized_marks)
        
    def clear(self) -> "TaintedValue":
        """
        清除所有污点
        
        Returns:
            清除污点后的TaintedValue
        """
        return TaintedValue(self._value, [])
        
    def get_propagation_summary(self) -> dict[str, Any]:
        """
        获取传播摘要
        
        Returns:
            传播路径摘要
        """
        return {
            "is_tainted": self.is_tainted,
            "highest_level": self.highest_taint_level.name,
            "mark_count": len(self._taint_marks),
            "sources": list(set(
                mark.source.source_name for mark in self._taint_marks
            )),
            "all_paths": [
                mark.propagation_path for mark in self._taint_marks
            ]
        }
        
    @classmethod
    def _generate_mark_id(cls) -> str:
        """生成标记ID"""
        with cls._lock:
            cls._mark_counter += 1
            return f"mark_{cls._mark_counter}_{datetime.utcnow().timestamp()}"
            
    def __str__(self) -> str:
        return f"TaintedValue({self._value}, level={self.highest_taint_level.name})"
        
    def __repr__(self) -> str:
        return self.__str__()
        
    def __eq__(self, other: object) -> bool:
        if isinstance(other, TaintedValue):
            return self._value == other._value
        return self._value == other
        
    def __hash__(self) -> int:
        return hash(self._value)


class TaintAnalysis:
    """
    污点分析引擎
    
    提供完整的污点追踪和分析能力
    
    Attributes:
        sources: 注册的污点来源
        sinks: 注册的污点Sink点
        propagation_rules: 传播规则
    """
    
    # 预定义的常见Sink点
    DEFAULT_SINKS = {
        "sql_execute": TaintSink(
            "sink_sql", "sql_execute", "database",
            "SQL执行函数", TaintLevel.HIGH
        ),
        "eval": TaintSink(
            "sink_eval", "eval", "code_execution",
            "代码执行函数", TaintLevel.CRITICAL
        ),
        "exec": TaintSink(
            "sink_exec", "exec", "code_execution",
            "代码执行函数", TaintLevel.CRITICAL
        ),
        "subprocess_call": TaintSink(
            "sink_subprocess", "subprocess.call", "command_execution",
            "子进程调用", TaintLevel.CRITICAL
        ),
        "os_system": TaintSink(
            "sink_ossystem", "os.system", "command_execution",
            "系统命令执行", TaintLevel.CRITICAL
        ),
        "render_template": TaintSink(
            "sink_template", "render_template", "template",
            "模板渲染", TaintLevel.HIGH
        ),
        "html_output": TaintSink(
            "sink_html", "html_output", "output",
            "HTML输出", TaintLevel.MEDIUM
        ),
    }
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化污点分析引擎
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        
        # 存储
        self._sources: dict[str, TaintSource] = {}
        self._sinks: dict[str, TaintSink] = dict(self.DEFAULT_SINKS)
        self._tainted_objects: dict[int, TaintedValue] = {}
        
        # 传播规则
        self._propagation_rules: dict[str, Callable] = {}
        self._sanitizers: dict[str, Callable] = {}
        
        # 事件处理器
        self._violation_handlers: list[Callable[[AttackContext], Coroutine]] = []
        
        # 统计
        self._stats = {
            "tainted_values_created": 0,
            "violations_detected": 0,
            "propagations": 0
        }
        
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化引擎"""
        if self._initialized:
            return
            
        logger.info("初始化污点分析引擎...")
        
        # 注册默认传播规则
        self._register_default_rules()
        
        self._initialized = True
        logger.info("污点分析引擎初始化完成")
        
    async def shutdown(self) -> None:
        """关闭引擎"""
        self._initialized = False
        logger.info("污点分析引擎已关闭")
        
    def _register_default_rules(self) -> None:
        """注册默认传播规则"""
        # 字符串操作传播规则
        self.register_propagation_rule("str_concat", self._propagate_string_concat)
        self.register_propagation_rule("str_format", self._propagate_string_format)
        self.register_propagation_rule("str_replace", self._propagate_string_replace)
        
        # 集合操作传播规则
        self.register_propagation_rule("list_append", self._propagate_list_append)
        self.register_propagation_rule("dict_set", self._propagate_dict_set)
        
    def register_source(self, source: TaintSource) -> None:
        """
        注册污点来源
        
        Args:
            source: 污点来源
        """
        self._sources[source.source_id] = source
        logger.debug(f"注册污点来源: {source.source_name}")
        
    def register_sink(self, sink: TaintSink) -> None:
        """
        注册污点Sink点
        
        Args:
            sink: 污点Sink点
        """
        self._sinks[sink.sink_id] = sink
        logger.debug(f"注册污点Sink: {sink.sink_name}")
        
    def register_propagation_rule(
        self,
        rule_name: str,
        rule_func: Callable
    ) -> None:
        """
        注册传播规则
        
        Args:
            rule_name: 规则名称
            rule_func: 规则函数
        """
        self._propagation_rules[rule_name] = rule_func
        
    def register_sanitizer(
        self,
        sanitizer_name: str,
        sanitizer_func: Callable[[TaintedValue], TaintedValue]
    ) -> None:
        """
        注册净化器
        
        Args:
            sanitizer_name: 净化器名称
            sanitizer_func: 净化函数
        """
        self._sanitizers[sanitizer_name] = sanitizer_func
        
    def taint(
        self,
        value: Any,
        source: TaintSource,
        level: TaintLevel = TaintLevel.HIGH
    ) -> TaintedValue:
        """
        标记值为污点数据
        
        Args:
            value: 要标记的值
            source: 污点来源
            level: 污点级别
            
        Returns:
            被污染的值
        """
        if not self.enabled:
            return TaintedValue(value, [])
            
        mark = TaintMark(
            mark_id=TaintedValue._generate_mark_id(),
            source=source,
            level=level
        )
        
        tainted = TaintedValue(value, [mark])
        self._tainted_objects[id(tainted)] = tainted
        self._stats["tainted_values_created"] += 1
        
        logger.debug(f"标记污点: {source.source_name}, level={level.name}")
        return tainted
        
    def check_sink(
        self,
        sink_id: str,
        value: Any,
        context: Optional[dict] = None
    ) -> Optional[AttackContext]:
        """
        检查Sink点
        
        Args:
            sink_id: Sink点ID
            value: 要检查的值
            context: 额外上下文
            
        Returns:
            如果检测到违规返回AttackContext，否则None
        """
        if not self.enabled:
            return None
            
        sink = self._sinks.get(sink_id)
        if not sink:
            logger.warning(f"未知的Sink点: {sink_id}")
            return None
            
        # 检查是否为被污染的值
        if not isinstance(value, TaintedValue):
            return None
            
        if not value.is_tainted:
            return None
            
        # 检查污点级别
        if value.highest_taint_level.value < sink.required_level.value:
            return None
            
        # 检测到违规
        self._stats["violations_detected"] += 1
        
        # 构建传播路径
        propagation_paths = [
            mark.propagation_path for mark in value.taint_marks
        ]
        
        # 创建攻击上下文
        attack_context = (
            AttackContextBuilder()
            .with_attack_type("TAINT_VIOLATION")
            .with_severity(AttackSeverity.HIGH)
            .with_detection_method("taint_analysis")
            .with_confidence(0.95)
            .with_metadata("sink", sink.to_dict())
            .with_metadata("taint_level", value.highest_taint_level.name)
            .with_metadata("propagation_paths", propagation_paths)
            .build()
        )
        
        # 抛出异常
        sources = [mark.source.source_name for mark in value.taint_marks]
        raise TaintViolationException(
            message=f"污点违规: 来自 {sources} 的数据到达Sink点 {sink.sink_name}",
            taint_source=sources[0] if sources else "unknown",
            taint_sink=sink.sink_name,
            tainted_data=str(value.value)[:200],
            propagation_path=[p for path in propagation_paths for p in path],
            context=context
        )
        
    def propagate(
        self,
        source_value: Any,
        new_value: Any,
        transformation: str,
        propagation_step: str
    ) -> Any:
        """
        传播污点
        
        Args:
            source_value: 源值
            new_value: 新值
            transformation: 转换操作
            propagation_step: 传播步骤
            
        Returns:
            可能带有污点的新值
        """
        if not self.enabled:
            return new_value
            
        if isinstance(source_value, TaintedValue):
            self._stats["propagations"] += 1
            return source_value.propagate(new_value, transformation, propagation_step)
            
        return new_value
        
    def sanitize(
        self,
        value: Any,
        sanitizer_name: str
    ) -> Any:
        """
        净化污点
        
        Args:
            value: 要净化的值
            sanitizer_name: 净化器名称
            
        Returns:
            净化后的值
        """
        if isinstance(value, TaintedValue):
            return value.sanitize(sanitizer_name)
        return value
        
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            **self._stats,
            "registered_sources": len(self._sources),
            "registered_sinks": len(self._sinks),
            "active_tainted_objects": len(self._tainted_objects)
        }
        
    # 传播规则实现
    def _propagate_string_concat(
        self,
        *values: Any
    ) -> TaintedValue:
        """字符串连接传播"""
        result_parts = []
        all_marks = []
        
        for v in values:
            if isinstance(v, TaintedValue):
                result_parts.append(str(v.value))
                all_marks.extend(v.taint_marks)
            else:
                result_parts.append(str(v))
                
        result = "".join(result_parts)
        
        if all_marks:
            return TaintedValue(result, all_marks)
        return result
        
    def _propagate_string_format(
        self,
        template: Any,
        *args: Any,
        **kwargs: Any
    ) -> TaintedValue:
        """字符串格式化传播"""
        if isinstance(template, TaintedValue):
            template_str = template.value
            marks = list(template.taint_marks)
        else:
            template_str = template
            marks = []
            
        # 检查参数中的污点
        for arg in args:
            if isinstance(arg, TaintedValue):
                marks.extend(arg.taint_marks)
        for v in kwargs.values():
            if isinstance(v, TaintedValue):
                marks.extend(v.taint_marks)
                
        try:
            result = template_str.format(*args, **kwargs)
        except Exception:
            result = template_str
            
        if marks:
            return TaintedValue(result, marks)
        return result
        
    def _propagate_string_replace(
        self,
        value: Any,
        old: str,
        new: str
    ) -> TaintedValue:
        """字符串替换传播"""
        if isinstance(value, TaintedValue):
            result = value.value.replace(old, new)
            return TaintedValue(result, value.taint_marks)
        return value.replace(old, new)
        
    def _propagate_list_append(
        self,
        lst: list,
        item: Any
    ) -> list:
        """列表追加传播"""
        result = lst + [item]
        
        # 收集所有污点
        marks = []
        for v in result:
            if isinstance(v, TaintedValue):
                marks.extend(v.taint_marks)
                
        if marks:
            return TaintedValue(result, marks)
        return result
        
    def _propagate_dict_set(
        self,
        d: dict,
        key: Any,
        value: Any
    ) -> dict:
        """字典设置传播"""
        result = {**d, key: value}
        
        marks = []
        for v in result.values():
            if isinstance(v, TaintedValue):
                marks.extend(v.taint_marks)
                
        if marks:
            return TaintedValue(result, marks)
        return result


def taint_source(
    source_type: TaintSourceType,
    source_name: str,
    level: TaintLevel = TaintLevel.HIGH
) -> Callable:
    """
    污点来源装饰器
    
    标记函数返回值为污点数据
    
    Args:
        source_type: 来源类型
        source_name: 来源名称
        level: 污点级别
        
    Returns:
        装饰器函数
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            
            # 获取引擎实例（从调用上下文）
            engine = kwargs.get("_taint_engine")
            if engine:
                source = TaintSource(
                    source_id=f"{source_name}_{datetime.utcnow().timestamp()}",
                    source_type=source_type,
                    source_name=source_name,
                    original_value=result
                )
                return engine.taint(result, source, level)
            return result
            
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            result = await func(*args, **kwargs)
            
            engine = kwargs.get("_taint_engine")
            if engine:
                source = TaintSource(
                    source_id=f"{source_name}_{datetime.utcnow().timestamp()}",
                    source_type=source_type,
                    source_name=source_name,
                    original_value=result
                )
                return engine.taint(result, source, level)
            return result
            
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper
    return decorator


def check_taint_sink(sink_id: str) -> Callable:
    """
    Sink点检查装饰器
    
    检查函数参数是否为污点数据
    
    Args:
        sink_id: Sink点ID
        
    Returns:
        装饰器函数
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # 检查所有参数
            engine = kwargs.get("_taint_engine")
            if engine:
                for arg in args:
                    engine.check_sink(sink_id, arg)
                for v in kwargs.values():
                    engine.check_sink(sink_id, v)
                    
            return func(*args, **kwargs)
            
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            engine = kwargs.get("_taint_engine")
            if engine:
                for arg in args:
                    engine.check_sink(sink_id, arg)
                for v in kwargs.values():
                    engine.check_sink(sink_id, v)
                    
            return await func(*args, **kwargs)
            
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper
    return decorator
