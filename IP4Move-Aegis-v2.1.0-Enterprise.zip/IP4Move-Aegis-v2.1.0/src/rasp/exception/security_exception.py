"""
RASP安全异常定义模块

定义RASP模块中使用的各种安全相关异常类
"""

from enum import Enum, auto
from typing import Any, Optional
from datetime import datetime


class AttackType(Enum):
    """攻击类型枚举"""
    SQL_INJECTION = auto()
    XSS = auto()
    COMMAND_INJECTION = auto()
    PATH_TRAVERSAL = auto()
    DESERIALIZATION = auto()
    MEMORY_SAFETY = auto()
    TAINT_VIOLATION = auto()
    BEHAVIOR_ANOMALY = auto()
    UNKNOWN = auto()


class RASPSecurityException(Exception):
    """
    RASP安全异常基类
    
    所有RASP安全异常的基类，提供统一的异常处理接口
    
    Attributes:
        message: 异常消息
        attack_type: 攻击类型
        timestamp: 异常发生时间
        context: 异常上下文信息
    """
    
    def __init__(
        self,
        message: str,
        attack_type: AttackType = AttackType.UNKNOWN,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化安全异常
        
        Args:
            message: 异常消息
            attack_type: 攻击类型
            context: 异常上下文信息
        """
        super().__init__(message)
        self.message = message
        self.attack_type = attack_type
        self.timestamp = datetime.utcnow()
        self.context = context or {}
        
    def to_dict(self) -> dict[str, Any]:
        """
        将异常转换为字典格式
        
        Returns:
            包含异常信息的字典
        """
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "attack_type": self.attack_type.name,
            "timestamp": self.timestamp.isoformat(),
            "context": self.context
        }
        
    def __str__(self) -> str:
        return f"[{self.attack_type.name}] {self.message}"
        
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message='{self.message}', attack_type={self.attack_type.name})"


class InjectionAttackException(RASPSecurityException):
    """
    注入攻击异常
    
    用于SQL注入、命令注入、代码注入等攻击类型
    
    Attributes:
        payload: 检测到的攻击载荷
        injection_point: 注入点位置
    """
    
    def __init__(
        self,
        message: str,
        attack_type: AttackType,
        payload: str,
        injection_point: Optional[str] = None,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化注入攻击异常
        
        Args:
            message: 异常消息
            attack_type: 攻击类型
            payload: 攻击载荷
            injection_point: 注入点位置
            context: 异常上下文
        """
        super().__init__(message, attack_type, context)
        self.payload = payload
        self.injection_point = injection_point
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典，包含注入攻击特有信息"""
        data = super().to_dict()
        data.update({
            "payload": self.payload,
            "injection_point": self.injection_point
        })
        return data


class SQLInjectionException(InjectionAttackException):
    """SQL注入攻击异常"""
    
    def __init__(
        self,
        message: str,
        payload: str,
        query_fragment: Optional[str] = None,
        injection_point: Optional[str] = None,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化SQL注入异常
        
        Args:
            message: 异常消息
            payload: SQL注入载荷
            query_fragment: 受影响的SQL片段
            injection_point: 注入点
            context: 上下文
        """
        super().__init__(
            message,
            AttackType.SQL_INJECTION,
            payload,
            injection_point,
            context
        )
        self.query_fragment = query_fragment
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        data = super().to_dict()
        data["query_fragment"] = self.query_fragment
        return data


class XSSAttackException(InjectionAttackException):
    """XSS攻击异常"""
    
    def __init__(
        self,
        message: str,
        payload: str,
        xss_type: str,  # 'reflected', 'stored', 'dom'
        injection_point: Optional[str] = None,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化XSS攻击异常
        
        Args:
            message: 异常消息
            payload: XSS载荷
            xss_type: XSS类型
            injection_point: 注入点
            context: 上下文
        """
        super().__init__(
            message,
            AttackType.XSS,
            payload,
            injection_point,
            context
        )
        self.xss_type = xss_type
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        data = super().to_dict()
        data["xss_type"] = self.xss_type
        return data


class CommandInjectionException(InjectionAttackException):
    """命令注入攻击异常"""
    
    def __init__(
        self,
        message: str,
        payload: str,
        command: Optional[str] = None,
        injection_point: Optional[str] = None,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化命令注入异常
        
        Args:
            message: 异常消息
            payload: 注入的命令
            command: 原始命令
            injection_point: 注入点
            context: 上下文
        """
        super().__init__(
            message,
            AttackType.COMMAND_INJECTION,
            payload,
            injection_point,
            context
        )
        self.command = command
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        data = super().to_dict()
        data["command"] = self.command
        return data


class TaintViolationException(RASPSecurityException):
    """
    污点违规异常
    
    当污点数据到达Sink点时抛出
    
    Attributes:
        taint_source: 污点来源
        taint_sink: 污点Sink点
        tainted_data: 被污染的数据
        propagation_path: 污点传播路径
    """
    
    def __init__(
        self,
        message: str,
        taint_source: str,
        taint_sink: str,
        tainted_data: Any,
        propagation_path: Optional[list[str]] = None,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化污点违规异常
        
        Args:
            message: 异常消息
            taint_source: 污点来源
            taint_sink: 污点Sink点
            tainted_data: 被污染的数据
            propagation_path: 传播路径
            context: 上下文
        """
        super().__init__(message, AttackType.TAINT_VIOLATION, context)
        self.taint_source = taint_source
        self.taint_sink = taint_sink
        self.tainted_data = tainted_data
        self.propagation_path = propagation_path or []
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        data = super().to_dict()
        data.update({
            "taint_source": self.taint_source,
            "taint_sink": self.taint_sink,
            "tainted_data": str(self.tainted_data),
            "propagation_path": self.propagation_path
        })
        return data


class MemorySafetyException(RASPSecurityException):
    """
    内存安全异常
    
    缓冲区溢出、Use-After-Free等内存安全问题
    
    Attributes:
        memory_operation: 内存操作类型
        address: 内存地址
        size: 操作大小
    """
    
    def __init__(
        self,
        message: str,
        memory_operation: str,
        address: Optional[int] = None,
        size: Optional[int] = None,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化内存安全异常
        
        Args:
            message: 异常消息
            memory_operation: 内存操作类型
            address: 内存地址
            size: 操作大小
            context: 上下文
        """
        super().__init__(message, AttackType.MEMORY_SAFETY, context)
        self.memory_operation = memory_operation
        self.address = address
        self.size = size
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        data = super().to_dict()
        data.update({
            "memory_operation": self.memory_operation,
            "address": hex(self.address) if self.address else None,
            "size": self.size
        })
        return data


class DeserializationException(RASPSecurityException):
    """
    反序列化安全异常
    
    不安全的反序列化操作
    
    Attributes:
        format_type: 序列化格式
        dangerous_class: 检测到的危险类
    """
    
    def __init__(
        self,
        message: str,
        format_type: str,
        dangerous_class: Optional[str] = None,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化反序列化异常
        
        Args:
            message: 异常消息
            format_type: 序列化格式
            dangerous_class: 危险类名
            context: 上下文
        """
        super().__init__(message, AttackType.DESERIALIZATION, context)
        self.format_type = format_type
        self.dangerous_class = dangerous_class
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        data = super().to_dict()
        data.update({
            "format_type": self.format_type,
            "dangerous_class": self.dangerous_class
        })
        return data


class BehaviorAnomalyException(RASPSecurityException):
    """
    行为异常异常
    
    检测到偏离基线的异常行为
    
    Attributes:
        behavior_type: 行为类型
        baseline_deviation: 偏离基线的程度
        confidence: 异常置信度
    """
    
    def __init__(
        self,
        message: str,
        behavior_type: str,
        baseline_deviation: float,
        confidence: float,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化行为异常异常
        
        Args:
            message: 异常消息
            behavior_type: 行为类型
            baseline_deviation: 基线偏离度
            confidence: 置信度
            context: 上下文
        """
        super().__init__(message, AttackType.BEHAVIOR_ANOMALY, context)
        self.behavior_type = behavior_type
        self.baseline_deviation = baseline_deviation
        self.confidence = confidence
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        data = super().to_dict()
        data.update({
            "behavior_type": self.behavior_type,
            "baseline_deviation": self.baseline_deviation,
            "confidence": self.confidence
        })
        return data


class PathTraversalException(InjectionAttackException):
    """路径遍历攻击异常"""
    
    def __init__(
        self,
        message: str,
        payload: str,
        target_path: Optional[str] = None,
        injection_point: Optional[str] = None,
        context: Optional[dict[str, Any]] = None
    ):
        """
        初始化路径遍历异常
        
        Args:
            message: 异常消息
            payload: 攻击载荷
            target_path: 目标路径
            injection_point: 注入点
            context: 上下文
        """
        super().__init__(
            message,
            AttackType.PATH_TRAVERSAL,
            payload,
            injection_point,
            context
        )
        self.target_path = target_path
        
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        data = super().to_dict()
        data["target_path"] = self.target_path
        return data
