"""
攻击上下文模块

定义攻击相关的上下文信息和严重级别
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime
import json
import hashlib
import uuid


class AttackSeverity(Enum):
    """
    攻击严重级别枚举
    
    定义攻击的严重程度，用于响应决策
    """
    CRITICAL = auto()      # 严重：立即阻断，需要人工介入
    HIGH = auto()          # 高：立即阻断，记录详细日志
    MEDIUM = auto()        # 中：告警，可能需要阻断
    LOW = auto()           # 低：记录日志，监控观察
    INFO = auto()          # 信息：仅记录，用于分析
    
    def __str__(self) -> str:
        return self.name
    
    def to_int(self) -> int:
        """转换为整数表示，用于比较"""
        mapping = {
            AttackSeverity.CRITICAL: 5,
            AttackSeverity.HIGH: 4,
            AttackSeverity.MEDIUM: 3,
            AttackSeverity.LOW: 2,
            AttackSeverity.INFO: 1
        }
        return mapping.get(self, 0)


class AttackStatus(Enum):
    """
    攻击状态枚举
    
    记录攻击事件的处理状态
    """
    DETECTED = auto()      # 已检测到
    BLOCKED = auto()       # 已阻断
    ALLOWED = auto()       # 已放行（误报或低风险）
    INVESTIGATING = auto() # 调查中
    RESOLVED = auto()      # 已解决
    FALSE_POSITIVE = auto() # 误报


@dataclass
class RequestContext:
    """
    请求上下文
    
    记录HTTP请求的上下文信息
    
    Attributes:
        request_id: 请求唯一标识
        timestamp: 请求时间戳
        method: HTTP方法
        url: 请求URL
        headers: 请求头
        remote_ip: 客户端IP
        user_agent: 用户代理
        session_id: 会话ID
        user_id: 用户ID
    """
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.utcnow)
    method: str = ""
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    remote_ip: str = ""
    user_agent: str = ""
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "request_id": self.request_id,
            "timestamp": self.timestamp.isoformat(),
            "method": self.method,
            "url": self.url,
            "headers": self.headers,
            "remote_ip": self.remote_ip,
            "user_agent": self.user_agent,
            "session_id": self.session_id,
            "user_id": self.user_id
        }


@dataclass
class ApplicationContext:
    """
    应用上下文
    
    记录应用运行时的上下文信息
    
    Attributes:
        app_name: 应用名称
        app_version: 应用版本
        module: 当前模块
        function: 当前函数
        line_number: 代码行号
        stack_trace: 调用栈
    """
    app_name: str = ""
    app_version: str = ""
    module: str = ""
    function: str = ""
    line_number: int = 0
    stack_trace: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "app_name": self.app_name,
            "app_version": self.app_version,
            "module": self.module,
            "function": self.function,
            "line_number": self.line_number,
            "stack_trace": self.stack_trace
        }


@dataclass
class DataContext:
    """
    数据上下文
    
    记录攻击相关的数据信息
    
    Attributes:
        input_data: 输入数据
        output_data: 输出数据
        data_type: 数据类型
        encoding: 编码方式
        size_bytes: 数据大小
    """
    input_data: Optional[str] = None
    output_data: Optional[str] = None
    data_type: str = ""
    encoding: str = "utf-8"
    size_bytes: int = 0
    
    def get_hash(self) -> str:
        """计算输入数据的哈希值"""
        if self.input_data:
            return hashlib.sha256(
                self.input_data.encode(self.encoding)
            ).hexdigest()[:16]
        return ""
    
    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "input_data": self.input_data[:1000] if self.input_data else None,  # 限制长度
            "output_data": self.output_data[:1000] if self.output_data else None,
            "data_type": self.data_type,
            "encoding": self.encoding,
            "size_bytes": self.size_bytes,
            "data_hash": self.get_hash()
        }


@dataclass
class AttackContext:
    """
    攻击上下文
    
    完整的攻击事件上下文，包含所有相关信息
    
    Attributes:
        attack_id: 攻击唯一标识
        attack_type: 攻击类型
        severity: 严重级别
        status: 处理状态
        request_context: 请求上下文
        app_context: 应用上下文
        data_context: 数据上下文
        detection_method: 检测方法
        confidence: 置信度 (0-1)
        metadata: 额外元数据
    """
    attack_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    attack_type: str = ""
    severity: AttackSeverity = AttackSeverity.MEDIUM
    status: AttackStatus = AttackStatus.DETECTED
    request_context: RequestContext = field(default_factory=RequestContext)
    app_context: ApplicationContext = field(default_factory=ApplicationContext)
    data_context: DataContext = field(default_factory=DataContext)
    detection_method: str = ""
    confidence: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    def update_status(self, status: AttackStatus) -> None:
        """
        更新攻击状态
        
        Args:
            status: 新状态
        """
        self.status = status
        self.updated_at = datetime.utcnow()
        
    def update_severity(self, severity: AttackSeverity) -> None:
        """
        更新严重级别
        
        Args:
            severity: 新严重级别
        """
        self.severity = severity
        self.updated_at = datetime.utcnow()
        
    def add_metadata(self, key: str, value: Any) -> None:
        """
        添加元数据
        
        Args:
            key: 键
            value: 值
        """
        self.metadata[key] = value
        self.updated_at = datetime.utcnow()
        
    def to_dict(self) -> dict[str, Any]:
        """
        转换为完整字典表示
        
        Returns:
            包含所有上下文信息的字典
        """
        return {
            "attack_id": self.attack_id,
            "attack_type": self.attack_type,
            "severity": self.severity.name,
            "status": self.status.name,
            "request_context": self.request_context.to_dict(),
            "app_context": self.app_context.to_dict(),
            "data_context": self.data_context.to_dict(),
            "detection_method": self.detection_method,
            "confidence": self.confidence,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
        
    def to_json(self, indent: Optional[int] = None) -> str:
        """
        转换为JSON字符串
        
        Args:
            indent: 缩进空格数
            
        Returns:
            JSON字符串
        """
        return json.dumps(self.to_dict(), indent=indent, default=str)
        
    def get_fingerprint(self) -> str:
        """
        生成攻击指纹
        
        用于去重和关联相似攻击
        
        Returns:
            攻击指纹哈希
        """
        fingerprint_data = {
            "attack_type": self.attack_type,
            "remote_ip": self.request_context.remote_ip,
            "data_hash": self.data_context.get_hash(),
            "module": self.app_context.module,
            "function": self.app_context.function
        }
        return hashlib.sha256(
            json.dumps(fingerprint_data, sort_keys=True).encode()
        ).hexdigest()[:16]
        
    def should_block(self) -> bool:
        """
        判断是否应当阻断
        
        基于严重级别和置信度做出决策
        
        Returns:
            是否应当阻断
        """
        # 严重级别为CRITICAL或HIGH时阻断
        if self.severity in (AttackSeverity.CRITICAL, AttackSeverity.HIGH):
            return True
        # MEDIUM级别且置信度高时阻断
        if self.severity == AttackSeverity.MEDIUM and self.confidence > 0.8:
            return True
        return False
        
    def get_response_action(self) -> str:
        """
        获取建议的响应动作
        
        Returns:
            响应动作建议
        """
        if self.severity == AttackSeverity.CRITICAL:
            return "BLOCK_AND_ALERT"
        elif self.severity == AttackSeverity.HIGH:
            return "BLOCK"
        elif self.severity == AttackSeverity.MEDIUM:
            if self.confidence > 0.8:
                return "BLOCK"
            else:
                return "ALERT"
        elif self.severity == AttackSeverity.LOW:
            return "LOG"
        else:
            return "MONITOR"


class AttackContextBuilder:
    """
    攻击上下文构建器
    
    使用建造者模式简化AttackContext的创建
    
    Example:
        context = (
            AttackContextBuilder()
            .with_attack_type("SQL_INJECTION")
            .with_severity(AttackSeverity.HIGH)
            .with_request(method="POST", url="/api/login")
            .with_remote_ip("192.168.1.1")
            .with_input_data("' OR 1=1 --")
            .with_confidence(0.95)
            .build()
        )
    """
    
    def __init__(self):
        """初始化构建器"""
        self._attack_context = AttackContext()
        
    def with_attack_id(self, attack_id: str) -> "AttackContextBuilder":
        """设置攻击ID"""
        self._attack_context.attack_id = attack_id
        return self
        
    def with_attack_type(self, attack_type: str) -> "AttackContextBuilder":
        """设置攻击类型"""
        self._attack_context.attack_type = attack_type
        return self
        
    def with_severity(self, severity: AttackSeverity) -> "AttackContextBuilder":
        """设置严重级别"""
        self._attack_context.severity = severity
        return self
        
    def with_status(self, status: AttackStatus) -> "AttackContextBuilder":
        """设置状态"""
        self._attack_context.status = status
        return self
        
    def with_request(
        self,
        method: str = "",
        url: str = "",
        headers: Optional[dict[str, str]] = None
    ) -> "AttackContextBuilder":
        """设置请求信息"""
        self._attack_context.request_context.method = method
        self._attack_context.request_context.url = url
        if headers:
            self._attack_context.request_context.headers = headers
        return self
        
    def with_remote_ip(self, ip: str) -> "AttackContextBuilder":
        """设置远程IP"""
        self._attack_context.request_context.remote_ip = ip
        return self
        
    def with_user_agent(self, user_agent: str) -> "AttackContextBuilder":
        """设置用户代理"""
        self._attack_context.request_context.user_agent = user_agent
        return self
        
    def with_session(self, session_id: str, user_id: Optional[str] = None) -> "AttackContextBuilder":
        """设置会话信息"""
        self._attack_context.request_context.session_id = session_id
        self._attack_context.request_context.user_id = user_id
        return self
        
    def with_application(
        self,
        app_name: str = "",
        app_version: str = "",
        module: str = "",
        function: str = ""
    ) -> "AttackContextBuilder":
        """设置应用信息"""
        self._attack_context.app_context.app_name = app_name
        self._attack_context.app_context.app_version = app_version
        self._attack_context.app_context.module = module
        self._attack_context.app_context.function = function
        return self
        
    def with_stack_trace(self, stack_trace: list[str]) -> "AttackContextBuilder":
        """设置调用栈"""
        self._attack_context.app_context.stack_trace = stack_trace
        return self
        
    def with_input_data(self, data: str, data_type: str = "") -> "AttackContextBuilder":
        """设置输入数据"""
        self._attack_context.data_context.input_data = data
        self._attack_context.data_context.data_type = data_type
        self._attack_context.data_context.size_bytes = len(data.encode())
        return self
        
    def with_output_data(self, data: str) -> "AttackContextBuilder":
        """设置输出数据"""
        self._attack_context.data_context.output_data = data
        return self
        
    def with_detection_method(self, method: str) -> "AttackContextBuilder":
        """设置检测方法"""
        self._attack_context.detection_method = method
        return self
        
    def with_confidence(self, confidence: float) -> "AttackContextBuilder":
        """设置置信度"""
        self._attack_context.confidence = max(0.0, min(1.0, confidence))
        return self
        
    def with_metadata(self, key: str, value: Any) -> "AttackContextBuilder":
        """添加元数据"""
        self._attack_context.metadata[key] = value
        return self
        
    def build(self) -> AttackContext:
        """
        构建AttackContext
        
        Returns:
            构建完成的AttackContext
        """
        return self._attack_context
