"""
RASP (Runtime Application Self-Protection) 运行时应用自保护模块

该模块提供应用层的安全防护能力，包括：
- 运行时行为监控
- 污点分析
- SQL注入检测
- XSS攻击检测
- 命令注入防护
- 反序列化安全
- 内存安全保护

作者: IP4Move Security Team
版本: 1.0.5
"""

from .runtime_monitor import RuntimeMonitor, SystemCallHook, BehaviorBaseline
from .taint_analysis import TaintAnalysis, TaintSource, TaintSink
from .sql_injection_detector import SQLInjectionDetector, SQLSyntaxAnalyzer
from .xss_detector import XSSDetector, DOMXSSDetector, ReflectedXSSDetector
from .command_injection import CommandInjectionDetector, ShellCommandParser
from .deserialization_guard import DeserializationGuard, SafePickleLoader
from .memory_protector import MemoryProtector, BufferOverflowDetector
from .exception.security_exception import (
    RASPSecurityException,
    InjectionAttackException,
    TaintViolationException,
    MemorySafetyException
)
from .exception.attack_context import AttackContext, AttackSeverity

__version__ = "1.0.5"
__author__ = "IP4Move Security Team"

__all__ = [
    # 运行时监控
    "RuntimeMonitor",
    "SystemCallHook",
    "BehaviorBaseline",
    # 污点分析
    "TaintAnalysis",
    "TaintSource",
    "TaintSink",
    # SQL注入
    "SQLInjectionDetector",
    "SQLSyntaxAnalyzer",
    # XSS检测
    "XSSDetector",
    "DOMXSSDetector",
    "ReflectedXSSDetector",
    # 命令注入
    "CommandInjectionDetector",
    "ShellCommandParser",
    # 反序列化
    "DeserializationGuard",
    "SafePickleLoader",
    # 内存保护
    "MemoryProtector",
    "BufferOverflowDetector",
    # 异常
    "RASPSecurityException",
    "InjectionAttackException",
    "TaintViolationException",
    "MemorySafetyException",
    "AttackContext",
    "AttackSeverity",
]


def create_rasp_engine(config: dict | None = None) -> "RASPEngine":
    """
    创建RASP引擎实例
    
    Args:
        config: 配置字典
        
    Returns:
        RASPEngine实例
    """
    return RASPEngine(config)


class RASPEngine:
    """
    RASP引擎主类
    
    整合所有RASP组件，提供统一的安全防护接口
    """
    
    def __init__(self, config: dict | None = None):
        """
        初始化RASP引擎
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self._monitor = RuntimeMonitor(self.config.get("monitor", {}))
        self._taint = TaintAnalysis(self.config.get("taint", {}))
        self._sql_detector = SQLInjectionDetector(self.config.get("sql", {}))
        self._xss_detector = XSSDetector(self.config.get("xss", {}))
        self._cmd_detector = CommandInjectionDetector(self.config.get("cmd", {}))
        self._deser_guard = DeserializationGuard(self.config.get("deser", {}))
        self._mem_protector = MemoryProtector(self.config.get("memory", {}))
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化所有组件"""
        if self._initialized:
            return
            
        await self._monitor.initialize()
        await self._taint.initialize()
        await self._sql_detector.initialize()
        await self._xss_detector.initialize()
        await self._cmd_detector.initialize()
        await self._deser_guard.initialize()
        await self._mem_protector.initialize()
        
        self._initialized = True
        
    async def shutdown(self) -> None:
        """关闭所有组件"""
        await self._monitor.shutdown()
        await self._taint.shutdown()
        await self._sql_detector.shutdown()
        await self._xss_detector.shutdown()
        await self._cmd_detector.shutdown()
        await self._deser_guard.shutdown()
        await self._mem_protector.shutdown()
        
        self._initialized = False
        
    @property
    def monitor(self) -> RuntimeMonitor:
        """获取运行时监控器"""
        return self._monitor
        
    @property
    def taint(self) -> TaintAnalysis:
        """获取污点分析器"""
        return self._taint
        
    @property
    def sql_detector(self) -> SQLInjectionDetector:
        """获取SQL注入检测器"""
        return self._sql_detector
        
    @property
    def xss_detector(self) -> XSSDetector:
        """获取XSS检测器"""
        return self._xss_detector
        
    @property
    def cmd_detector(self) -> CommandInjectionDetector:
        """获取命令注入检测器"""
        return self._cmd_detector
        
    @property
    def deser_guard(self) -> DeserializationGuard:
        """获取反序列化保护器"""
        return self._deser_guard
        
    @property
    def mem_protector(self) -> MemoryProtector:
        """获取内存保护器"""
        return self._mem_protector
