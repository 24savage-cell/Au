"""
XSS攻击检测模块

提供DOM型、反射型和存储型XSS攻击检测
"""

import asyncio
import html
import logging
import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Optional
from urllib.parse import unquote

from .exception.security_exception import XSSAttackException
from .exception.attack_context import (
    AttackContext,
    AttackContextBuilder,
    AttackSeverity
)

logger = logging.getLogger(__name__)


class XSSType(Enum):
    """XSS攻击类型"""
    REFLECTED = "reflected"    # 反射型XSS
    STORED = "stored"          # 存储型XSS
    DOM_BASED = "dom"          # DOM型XSS
    MUTATION = "mutation"      # 变异型XSS
    BLIND = "blind"            # 盲XSS


@dataclass
class XSSDetectionResult:
    """XSS检测结果"""
    is_xss: bool
    xss_type: XSSType
    confidence: float
    matched_vectors: list[str]
    context: str  # HTML/JS/CSS/URL等上下文
    sanitized_payload: str


class DOMXSSDetector:
    """
    DOM型XSS检测器
    
    检测基于DOM操作的XSS攻击
    """
    
    # 危险的DOM操作
    DANGEROUS_DOM_APIS = {
        "innerHTML", "outerHTML", "document.write", "document.writeln",
        "eval", "setTimeout", "setInterval", "Function", "execScript",
        "insertAdjacentHTML", "onevent", "location", "location.href",
        "location.replace", "location.assign", "window.open", "postMessage"
    }
    
    # DOM型XSS特征模式
    DOM_XSS_PATTERNS = {
        "innerhtml_assignment": r"\.innerHTML\s*=\s*.*?(location|document\.URL|document\.documentURI)",
        "eval_location": r"eval\s*\(\s*.*?location",
        "document_write": r"document\.(write|writeln)\s*\(",
        "javascript_protocol": r"javascript:\s*",
        "data_protocol": r"data:text/html",
        "vbscript_protocol": r"vbscript:",
        "expression": r"expression\s*\(",
        "import_expression": r"@import\s+",
    }
    
    def __init__(self):
        """初始化DOM XSS检测器"""
        self._compiled_patterns = {
            name: re.compile(pattern, re.IGNORECASE)
            for name, pattern in self.DOM_XSS_PATTERNS.items()
        }
        
    def detect(self, payload: str) -> tuple[bool, list[str]]:
        """
        检测DOM型XSS
        
        Args:
            payload: 待检测的载荷
            
        Returns:
            (是否XSS, 匹配的向量列表)
        """
        matches = []
        
        for name, pattern in self._compiled_patterns.items():
            if pattern.search(payload):
                matches.append(name)
                
        return len(matches) > 0, matches


class ReflectedXSSDetector:
    """
    反射型XSS检测器
    
    检测反射型XSS攻击模式
    """
    
    # XSS攻击向量
    XSS_VECTORS = {
        # 基础标签
        "script_tag": r"<script[^>]*>[\s\S]*?</script>",
        "img_onerror": r"<img[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "svg_onload": r"<svg[^>]+onload\s*=\s*['\"]?[^'\"]+['\"]?",
        "body_onload": r"<body[^>]+onload\s*=\s*['\"]?[^'\"]+['\"]?",
        "iframe_src": r"<iframe[^>]+src\s*=\s*['\"]?javascript:",
        "object_data": r"<object[^>]+data\s*=\s*['\"]?javascript:",
        "embed_src": r"<embed[^>]+src\s*=\s*['\"]?javascript:",
        "form_action": r"<form[^>]+action\s*=\s*['\"]?javascript:",
        "input_onfocus": r"<input[^>]+onfocus\s*=\s*['\"]?[^'\"]+['\"]?",
        "link_href": r"<link[^>]+href\s*=\s*['\"]?javascript:",
        "meta_refresh": r"<meta[^>]+http-equiv\s*=\s*['\"]?refresh['\"]?[^>]+content\s*=\s*['\"]?\d+;\s*url\s*=\s*javascript:",
        "video_poster": r"<video[^>]+poster\s*=\s*['\"]?javascript:",
        "audio_src": r"<audio[^>]+src\s*=\s*['\"]?javascript:",
        "source_src": r"<source[^>]+src\s*=\s*['\"]?javascript:",
        "track_src": r"<track[^>]+src\s*=\s*['\"]?javascript:",
        "applet_code": r"<applet[^>]+code\s*=\s*['\"]?javascript:",
        "base_href": r"<base[^>]+href\s*=\s*['\"]?javascript:",
        "button_onclick": r"<button[^>]+onclick\s*=\s*['\"]?[^'\"]+['\"]?",
        "marquee_onstart": r"<marquee[^>]+onstart\s*=\s*['\"]?[^'\"]+['\"]?",
        "details_ontoggle": r"<details[^>]+ontoggle\s*=\s*['\"]?[^'\"]+['\"]?",
        "select_onchange": r"<select[^>]+onchange\s*=\s*['\"]?[^'\"]+['\"]?",
        "textarea_oninput": r"<textarea[^>]+oninput\s*=\s*['\"]?[^'\"]+['\"]?",
        "keygen_onfocus": r"<keygen[^>]+onfocus\s*=\s*['\"]?[^'\"]+['\"]?",
        "video_onerror": r"<video[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "audio_onerror": r"<audio[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "source_onerror": r"<source[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "track_onerror": r"<track[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "applet_onerror": r"<applet[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "object_onerror": r"<object[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "embed_onerror": r"<embed[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "iframe_onerror": r"<iframe[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "frame_onerror": r"<frame[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "frameset_onerror": r"<frameset[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "layer_onerror": r"<layer[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "ilayer_onerror": r"<ilayer[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "style_onerror": r"<style[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "link_onerror": r"<link[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "import_onerror": r"<import[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "include_onerror": r"<include[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "view_onerror": r"<view[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fragment_onerror": r"<fragment[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "portal_onerror": r"<portal[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fencedframe_onerror": r"<fencedframe[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "script_onerror": r"<script[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "noscript_onerror": r"<noscript[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "template_onerror": r"<template[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "slot_onerror": r"<slot[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "canvas_onerror": r"<canvas[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "math_onerror": r"<math[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "svg_onerror": r"<svg[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "foreignobject_onerror": r"<foreignobject[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "desc_onerror": r"<desc[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "title_onerror": r"<title[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "use_onerror": r"<use[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "switch_onerror": r"<switch[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "image_onerror": r"<image[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "feimage_onerror": r"<feimage[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "femerge_onerror": r"<femerge[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "femergenode_onerror": r"<femergenode[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "feflood_onerror": r"<feflood[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fegaussianblur_onerror": r"<fegaussianblur[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "feoffset_onerror": r"<feoffset[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fecomposite_onerror": r"<fecomposite[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "femorphology_onerror": r"<femorphology[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fecolormatrix_onerror": r"<fecolormatrix[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fecomponenttransfer_onerror": r"<fecomponenttransfer[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fefunca_onerror": r"<fefunca[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fefuncr_onerror": r"<fefuncr[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fefuncg_onerror": r"<fefuncg[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fefuncb_onerror": r"<fefuncb[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fefunca_onerror": r"<fefunca[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fefunca_onerror": r"<fefunca[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
        "fefunca_onerror": r"<fefunca[^>]+onerror\s*=\s*['\"]?[^'\"]+['\"]?",
    }
    
    def __init__(self):
        """初始化反射型XSS检测器"""
        self._compiled_vectors = {
            name: re.compile(pattern, re.IGNORECASE)
            for name, pattern in self.XSS_VECTORS.items()
        }
        
    def detect(self, payload: str) -> tuple[bool, list[str], str]:
        """
        检测反射型XSS
        
        Args:
            payload: 待检测的载荷
            
        Returns:
            (是否XSS, 匹配的向量列表, 上下文类型)
        """
        matches = []
        
        # URL解码
        decoded = unquote(payload)
        # HTML实体解码
        decoded = html.unescape(decoded)
        
        for name, pattern in self._compiled_vectors.items():
            if pattern.search(decoded):
                matches.append(name)
                
        # 确定上下文
        context = self._determine_context(decoded)
        
        return len(matches) > 0, matches, context
        
    def _determine_context(self, payload: str) -> str:
        """
        确定XSS上下文
        
        Args:
            payload: 载荷
            
        Returns:
            上下文类型
        """
        if "<script" in payload.lower():
            return "script"
        elif "on" in payload.lower() and "=" in payload:
            return "event_handler"
        elif "javascript:" in payload.lower():
            return "javascript_protocol"
        elif "<" in payload and ">" in payload:
            return "html"
        elif "style" in payload.lower():
            return "css"
        return "text"


class XSSDetector:
    """
    XSS攻击检测器
    
    综合检测DOM型、反射型和存储型XSS攻击
    """
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化XSS检测器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self.detection_threshold = self.config.get("threshold", 0.7)
        self.block_on_detection = self.config.get("block", True)
        
        # 初始化子检测器
        self.dom_detector = DOMXSSDetector()
        self.reflected_detector = ReflectedXSSDetector()
        
        # 统计
        self._stats = {
            "payloads_checked": 0,
            "xss_detected": 0
        }
        
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化检测器"""
        if self._initialized:
            return
            
        logger.info("初始化XSS检测器...")
        self._initialized = True
        logger.info("XSS检测器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭检测器"""
        self._initialized = False
        logger.info("XSS检测器已关闭")
        
    def detect(self, payload: str) -> XSSDetectionResult:
        """
        检测XSS攻击
        
        Args:
            payload: 待检测的载荷
            
        Returns:
            检测结果
        """
        if not self.enabled:
            return XSSDetectionResult(
                is_xss=False,
                xss_type=XSSType.REFLECTED,
                confidence=0.0,
                matched_vectors=[],
                context="unknown",
                sanitized_payload=payload
            )
            
        self._stats["payloads_checked"] += 1
        
        # 反射型检测
        is_reflected, reflected_vectors, context = self.reflected_detector.detect(payload)
        
        # DOM型检测
        is_dom, dom_vectors = self.dom_detector.detect(payload)
        
        # 综合判断
        all_vectors = reflected_vectors + dom_vectors
        
        if is_reflected or is_dom:
            self._stats["xss_detected"] += 1
            
            # 确定类型
            if is_dom:
                xss_type = XSSType.DOM_BASED
            else:
                xss_type = XSSType.REFLECTED
                
            confidence = min(len(all_vectors) * 0.2 + 0.5, 1.0)
            
            return XSSDetectionResult(
                is_xss=True,
                xss_type=xss_type,
                confidence=confidence,
                matched_vectors=all_vectors,
                context=context,
                sanitized_payload=self._sanitize_payload(payload)
            )
            
        return XSSDetectionResult(
            is_xss=False,
            xss_type=XSSType.REFLECTED,
            confidence=0.0,
            matched_vectors=[],
            context=context,
            sanitized_payload=payload
        )
        
    def check_and_block(
        self,
        payload: str,
        context: Optional[dict] = None
    ) -> None:
        """
        检测并阻断XSS攻击
        
        Args:
            payload: 待检测的载荷
            context: 额外上下文
            
        Raises:
            XSSAttackException: 检测到XSS时抛出
        """
        result = self.detect(payload)
        
        if result.is_xss and self.block_on_detection:
            raise XSSAttackException(
                message=f"检测到XSS攻击: {result.xss_type.value}",
                payload=payload[:500],
                xss_type=result.xss_type.value,
                context=context
            )
            
    def _sanitize_payload(self, payload: str) -> str:
        """
        净化XSS载荷
        
        Args:
            payload: 原始载荷
            
        Returns:
            净化后的载荷
        """
        # HTML实体编码
        sanitized = html.escape(payload)
        return sanitized
        
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            **self._stats,
            "enabled": self.enabled
        }
