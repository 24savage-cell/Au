"""
通用工具模块

提供安全内存管理、审计日志、负载均衡等通用功能。
"""

from .memory import secure_zero_memory, SecureBuffer
from .audit import AuditLogger, AuditEvent, AuditEventType
from .load_balancer import (
    Backend,
    LoadBalancer,
    RoundRobinBalancer,
    WeightedBalancer,
    ConsistentHashBalancer,
)
from .failover import FailoverManager, Service, ServiceState
from .config_manager import ConfigManager, ConfigChange

__all__ = [
    # 内存安全
    "secure_zero_memory",
    "SecureBuffer",
    # 审计日志
    "AuditLogger",
    "AuditEvent",
    "AuditEventType",
    # 负载均衡
    "Backend",
    "LoadBalancer",
    "RoundRobinBalancer",
    "WeightedBalancer",
    "ConsistentHashBalancer",
    # 故障转移
    "FailoverManager",
    "Service",
    "ServiceState",
    # 配置管理
    "ConfigManager",
    "ConfigChange",
]
