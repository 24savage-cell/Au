"""
LRU 缓存模块 (性能优化版)

提供线程安全的 LRU 缓存实现。
优化:
- 添加统计信息
- 批量操作支持
- 异步清理过期项
"""
import time
import asyncio
from typing import TypeVar, Generic, Optional, Dict, Any, List, Tuple
from collections import OrderedDict
import threading

K = TypeVar('K')
V = TypeVar('V')


class LRUCache(Generic[K, V]):
    """线程安全 LRU 缓存 (性能优化版)"""

    def __init__(self, max_size: int = 1000, ttl: Optional[float] = None):
        self._max_size = max_size
        self._ttl = ttl
        self._cache: OrderedDict[K, tuple[V, float]] = OrderedDict()
        self._lock = threading.RLock()
        
        # 统计信息
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._expirations = 0

    def get(self, key: K) -> Optional[V]:
        """获取缓存值 (优化版)"""
        with self._lock:
            if key not in self._cache:
                self._misses += 1
                return None
            value, timestamp = self._cache[key]
            if self._ttl and time.time() - timestamp > self._ttl:
                del self._cache[key]
                self._expirations += 1
                self._misses += 1
                return None
            self._cache.move_to_end(key)
            self._hits += 1
            return value

    def put(self, key: K, value: V) -> bool:
        """
        设置缓存值 (优化版)
        
        Returns:
            是否发生了驱逐
        """
        evicted = False
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            else:
                if len(self._cache) >= self._max_size:
                    self._cache.popitem(last=False)
                    self._evictions += 1
                    evicted = True
            self._cache[key] = (value, time.time())
        return evicted

    def get_batch(self, keys: List[K]) -> Dict[K, V]:
        """批量获取缓存值"""
        result = {}
        with self._lock:
            for key in keys:
                if key in self._cache:
                    value, timestamp = self._cache[key]
                    if self._ttl and time.time() - timestamp > self._ttl:
                        del self._cache[key]
                        self._expirations += 1
                        self._misses += 1
                    else:
                        self._cache.move_to_end(key)
                        self._hits += 1
                        result[key] = value
                else:
                    self._misses += 1
        return result

    def put_batch(self, items: Dict[K, V]) -> int:
        """
        批量设置缓存值
        
        Returns:
            驱逐的条目数量
        """
        evicted = 0
        with self._lock:
            for key, value in items.items():
                if key not in self._cache and len(self._cache) >= self._max_size:
                    self._cache.popitem(last=False)
                    self._evictions += 1
                    evicted += 1
                self._cache[key] = (value, time.time())
                self._cache.move_to_end(key)
        return evicted

    def invalidate(self, key: K) -> bool:
        """使指定缓存失效"""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False

    def invalidate_batch(self, keys: List[K]) -> int:
        """批量使缓存失效"""
        count = 0
        with self._lock:
            for key in keys:
                if key in self._cache:
                    del self._cache[key]
                    count += 1
        return count

    def clear(self) -> int:
        """清空缓存，返回清空的数量"""
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            return count

    def cleanup_expired(self) -> int:
        """清理过期项，返回清理的数量"""
        if not self._ttl:
            return 0
        
        count = 0
        now = time.time()
        with self._lock:
            expired_keys = [
                key for key, (_, timestamp) in self._cache.items()
                if now - timestamp > self._ttl
            ]
            for key in expired_keys:
                del self._cache[key]
                self._expirations += 1
                count += 1
        return count

    @property
    def size(self) -> int:
        """返回当前缓存大小"""
        with self._lock:
            return len(self._cache)

    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        with self._lock:
            total_requests = self._hits + self._misses
            hit_rate = self._hits / total_requests if total_requests > 0 else 0.0
            
            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "ttl": self._ttl,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": round(hit_rate, 4),
                "evictions": self._evictions,
                "expirations": self._expirations,
            }

    def reset_stats(self) -> None:
        """重置统计信息"""
        with self._lock:
            self._hits = 0
            self._misses = 0
            self._evictions = 0
            self._expirations = 0

    def keys(self) -> List[K]:
        """获取所有缓存键"""
        with self._lock:
            return list(self._cache.keys())

    def items(self) -> List[Tuple[K, V]]:
        """获取所有缓存项"""
        with self._lock:
            return [(k, v[0]) for k, v in self._cache.items()]
