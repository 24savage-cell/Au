"""
对象池模块 (性能优化版)

提供可复用的对象池，减少频繁创建/销毁的开销。
优化:
- 添加统计信息追踪
- 支持预热功能
- 添加对象健康检查
- 优化锁粒度
"""
import asyncio
import time
from typing import TypeVar, Generic, Callable, Optional, Dict, Any
from collections import deque

T = TypeVar('T')


class ObjectPool(Generic[T]):
    """通用对象池 (性能优化版)"""

    def __init__(
        self,
        factory: Callable[[], T],
        reset: Optional[Callable[[T], None]] = None,
        max_size: int = 100,
        health_check: Optional[Callable[[T], bool]] = None,
        warmup_count: int = 0,
    ):
        self._factory = factory
        self._reset = reset
        self._health_check = health_check
        self._max_size = max_size
        self._pool: deque[T] = deque()
        self._lock = asyncio.Lock()
        self._created = 0
        self._acquired = 0
        self._released = 0
        self._hits = 0
        self._misses = 0
        self._health_check_failures = 0
        self._last_stats_reset = time.monotonic()
        
        # 预热对象池
        if warmup_count > 0:
            for _ in range(min(warmup_count, max_size)):
                try:
                    obj = self._factory()
                    self._pool.append(obj)
                    self._created += 1
                except Exception:
                    break

    async def acquire(self) -> T:
        """获取对象 (优化版)"""
        async with self._lock:
            while self._pool:
                obj = self._pool.popleft()
                # 健康检查
                if self._health_check and not self._health_check(obj):
                    self._health_check_failures += 1
                    continue
                if self._reset:
                    self._reset(obj)
                self._hits += 1
                self._acquired += 1
                return obj
            
            self._misses += 1
            self._created += 1
            self._acquired += 1
            return self._factory()

    async def release(self, obj: T) -> bool:
        """
        归还对象 (优化版)
        
        Returns:
            是否成功归还到池中
        """
        async with self._lock:
            self._released += 1
            if len(self._pool) < self._max_size:
                # 健康检查
                if self._health_check and not self._health_check(obj):
                    self._health_check_failures += 1
                    return False
                self._pool.append(obj)
                return True
            return False

    @property
    def size(self) -> int:
        """返回池中可用对象数量"""
        return len(self._pool)

    @property
    def created(self) -> int:
        """返回总共创建的对象数量"""
        return self._created
    
    @property
    def in_use(self) -> int:
        """返回当前正在使用的对象数量"""
        return self._acquired - self._released
    
    def get_stats(self) -> Dict[str, Any]:
        """获取对象池统计信息"""
        total_requests = self._hits + self._misses
        hit_rate = self._hits / total_requests if total_requests > 0 else 0.0
        
        stats = {
            "pool_size": len(self._pool),
            "max_size": self._max_size,
            "created": self._created,
            "in_use": self.in_use,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": round(hit_rate, 4),
            "health_check_failures": self._health_check_failures,
        }
        return stats
    
    def reset_stats(self) -> None:
        """重置统计信息"""
        self._hits = 0
        self._misses = 0
        self._health_check_failures = 0
        self._last_stats_reset = time.monotonic()
    
    async def clear(self) -> int:
        """清空对象池，返回清空的数量"""
        async with self._lock:
            count = len(self._pool)
            self._pool.clear()
            return count
