"""
统一异常定义

定义项目中使用的所有自定义异常。
"""


class IP4MoveError(Exception):
    """基础异常"""
    pass


class SecurityError(IP4MoveError):
    """安全相关错误"""
    pass


class CryptoError(SecurityError):
    """加密操作错误"""
    pass


class NetworkError(IP4MoveError):
    """网络错误"""
    pass


class DHTError(NetworkError):
    """DHT 操作错误"""
    pass


class ConsensusError(IP4MoveError):
    """共识机制错误"""
    pass


class ValidationError(IP4MoveError):
    """输入验证错误"""
    pass


class RateLimitError(IP4MoveError):
    """速率限制错误"""
    pass
