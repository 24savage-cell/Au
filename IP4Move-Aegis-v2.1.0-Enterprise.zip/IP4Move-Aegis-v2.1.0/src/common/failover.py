"""
故障转移管理器

监控服务健康状态，自动切换到备用服务。
"""
import asyncio
import time
from typing import Dict, List, Callable, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum


class ServiceState(Enum):
    """服务状态"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


@dataclass
class Service:
    """服务实例"""
    id: str
    address: str
    port: int
    state: ServiceState = ServiceState.HEALTHY
    last_check: float = field(default_factory=time.time)
    failure_count: int = 0
    success_count: int = 0
    response_time: float = 0.0
    metadata: Dict = field(default_factory=dict)


class FailoverManager:
    """故障转移管理器"""
    
    def __init__(
        self,
        check_interval: float = 10.0,
        failure_threshold: int = 3,
        recovery_threshold: int = 2,
        check_timeout: float = 5.0,
    ):
        self._services: Dict[str, Service] = {}
        self._check_interval = check_interval
        self._failure_threshold = failure_threshold
        self._recovery_threshold = recovery_threshold
        self._check_timeout = check_timeout
        self._checkers: Dict[str, Callable] = {}
        self._task: Optional[asyncio.Task] = None
        self._callbacks: List[Callable[[str, ServiceState, ServiceState], None]] = []
        self._running = False
    
    def register_service(
        self,
        service_id: str,
        address: str,
        port: int,
        checker: Callable[[str, int], bool],
        metadata: Optional[Dict] = None,
    ) -> None:
        """
        注册服务
        
        Args:
            service_id: 服务唯一标识
            address: 服务地址
            port: 服务端口
            checker: 健康检查函数，返回 True 表示健康
            metadata: 服务元数据
        """
        self._services[service_id] = Service(
            id=service_id,
            address=address,
            port=port,
            metadata=metadata or {},
        )
        self._checkers[service_id] = checker
    
    def unregister_service(self, service_id: str) -> bool:
        """注销服务"""
        if service_id in self._services:
            del self._services[service_id]
            if service_id in self._checkers:
                del self._checkers[service_id]
            return True
        return False
    
    def on_state_change(self, callback: Callable[[str, ServiceState, ServiceState], None]) -> None:
        """
        注册状态变更回调
        
        回调函数接收参数：(service_id, old_state, new_state)
        """
        self._callbacks.append(callback)
    
    def remove_state_change_callback(self, callback: Callable) -> bool:
        """移除状态变更回调"""
        if callback in self._callbacks:
            self._callbacks.remove(callback)
            return True
        return False
    
    async def _check_service(self, service: Service) -> Tuple[bool, float]:
        """
        检查服务健康状态
        
        返回: (是否健康, 响应时间)
        """
        checker = self._checkers.get(service.id)
        if not checker:
            return True, 0.0
        
        start_time = time.time()
        try:
            result = await asyncio.wait_for(
                asyncio.to_thread(checker, service.address, service.port),
                timeout=self._check_timeout
            )
            response_time = time.time() - start_time
            return result, response_time
        except asyncio.TimeoutError:
            return False, self._check_timeout
        except Exception:
            return False, 0.0
    
    async def _check_loop(self) -> None:
        """健康检查循环"""
        while self._running:
            for service in list(self._services.values()):
                healthy, response_time = await self._check_service(service)
                old_state = service.state
                
                service.last_check = time.time()
                service.response_time = response_time
                
                if healthy:
                    service.success_count += 1
                    service.failure_count = 0
                    
                    # 从 UNHEALTHY 恢复到 HEALTHY
                    if service.state == ServiceState.UNHEALTHY and \
                       service.success_count >= self._recovery_threshold:
                        service.state = ServiceState.HEALTHY
                    # 从 DEGRADED 恢复到 HEALTHY
                    elif service.state == ServiceState.DEGRADED and \
                         service.success_count >= self._recovery_threshold:
                        service.state = ServiceState.HEALTHY
                else:
                    service.failure_count += 1
                    service.success_count = 0
                    
                    # 从 HEALTHY 降级到 DEGRADED
                    if service.state == ServiceState.HEALTHY and \
                       service.failure_count >= self._failure_threshold // 2:
                        service.state = ServiceState.DEGRADED
                    # 从 DEGRADED 降级到 UNHEALTHY
                    elif service.state in (ServiceState.HEALTHY, ServiceState.DEGRADED) and \
                         service.failure_count >= self._failure_threshold:
                        service.state = ServiceState.UNHEALTHY
                
                # 触发状态变更回调
                if service.state != old_state:
                    for callback in self._callbacks:
                        try:
                            callback(service.id, old_state, service.state)
                        except Exception as e:
                            # 记录错误但不影响其他回调
                            print(f"状态变更回调错误: {e}")
            
            await asyncio.sleep(self._check_interval)
    
    async def start(self) -> None:
        """启动故障转移管理器"""
        if self._running:
            return
        
        self._running = True
        self._task = asyncio.create_task(self._check_loop())
    
    async def stop(self) -> None:
        """停止故障转移管理器"""
        if not self._running:
            return
        
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
    
    def get_service(self, service_id: str) -> Optional[Service]:
        """获取服务信息"""
        return self._services.get(service_id)
    
    def get_healthy_services(self) -> List[Service]:
        """获取健康的服务列表"""
        return [
            s for s in self._services.values()
            if s.state in (ServiceState.HEALTHY, ServiceState.DEGRADED)
        ]
    
    def get_all_services(self) -> List[Service]:
        """获取所有服务"""
        return list(self._services.values())
    
    def get_service_count(self) -> int:
        """获取服务总数"""
        return len(self._services)
    
    def get_healthy_count(self) -> int:
        """获取健康服务数"""
        return len(self.get_healthy_services())
    
    def is_healthy(self, service_id: str) -> bool:
        """检查服务是否健康"""
        service = self._services.get(service_id)
        if not service:
            return False
        return service.state in (ServiceState.HEALTHY, ServiceState.DEGRADED)
    
    def get_service_state(self, service_id: str) -> Optional[ServiceState]:
        """获取服务状态"""
        service = self._services.get(service_id)
        return service.state if service else None
    
    def force_check(self, service_id: str) -> Optional[ServiceState]:
        """
        强制立即检查指定服务
        
        返回检查后的状态
        """
        service = self._services.get(service_id)
        if not service:
            return None
        
        # 同步执行检查
        checker = self._checkers.get(service_id)
        if not checker:
            return service.state
        
        try:
            healthy = checker(service.address, service.port)
            old_state = service.state
            
            service.last_check = time.time()
            
            if healthy:
                service.success_count += 1
                service.failure_count = 0
                if service.state == ServiceState.UNHEALTHY:
                    service.state = ServiceState.HEALTHY
            else:
                service.failure_count += 1
                service.success_count = 0
                if service.state == ServiceState.HEALTHY:
                    service.state = ServiceState.DEGRADED
                elif service.state == ServiceState.DEGRADED:
                    service.state = ServiceState.UNHEALTHY
            
            # 触发回调
            if service.state != old_state:
                for callback in self._callbacks:
                    try:
                        callback(service.id, old_state, service.state)
                    except Exception:
                        pass
            
            return service.state
            
        except Exception:
            return service.state
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        return {
            "total_services": len(self._services),
            "healthy_services": len(self.get_healthy_services()),
            "unhealthy_services": sum(
                1 for s in self._services.values()
                if s.state == ServiceState.UNHEALTHY
            ),
            "degraded_services": sum(
                1 for s in self._services.values()
                if s.state == ServiceState.DEGRADED
            ),
            "check_interval": self._check_interval,
            "running": self._running,
        }


class FailoverRouter:
    """
    故障转移路由器
    
    自动将请求路由到健康的服务实例。
    """
    
    def __init__(self, failover_manager: FailoverManager):
        self._manager = failover_manager
        self._current_index = 0
    
    def get_next_healthy_service(self) -> Optional[Service]:
        """
        获取下一个健康的服务（轮询）
        
        如果没有健康的服务，返回 None。
        """
        healthy = self._manager.get_healthy_services()
        if not healthy:
            return None
        
        service = healthy[self._current_index % len(healthy)]
        self._current_index += 1
        return service
    
    def get_least_response_time_service(self) -> Optional[Service]:
        """
        获取响应时间最短的健康服务
        
        如果没有健康的服务，返回 None。
        """
        healthy = self._manager.get_healthy_services()
        if not healthy:
            return None
        
        return min(healthy, key=lambda s: s.response_time or float('inf'))
    
    async def execute_with_failover(
        self,
        operation: Callable,
        max_retries: int = 3,
    ) -> any:
        """
        执行操作并自动故障转移
        
        如果当前服务失败，自动尝试其他健康服务。
        
        Args:
            operation: 要执行的操作函数，接收 Service 参数
            max_retries: 最大重试次数
        
        Returns:
            操作结果
        
        Raises:
            Exception: 所有服务都失败时抛出异常
        """
        last_error = None
        attempted_services = set()
        
        for _ in range(max_retries):
            service = self.get_next_healthy_service()
            
            if not service:
                raise Exception("没有可用的健康服务")
            
            if service.id in attempted_services:
                # 所有服务都已尝试过
                break
            
            attempted_services.add(service.id)
            
            try:
                return await operation(service)
            except Exception as e:
                last_error = e
                # 标记服务为不健康
                self._manager._services[service.id].state = ServiceState.DEGRADED
                continue
        
        raise last_error or Exception("所有服务都不可用")


# 便捷函数
def create_tcp_health_checker(timeout: float = 5.0) -> Callable[[str, int], bool]:
    """
    创建 TCP 健康检查器
    
    Args:
        timeout: 连接超时时间（秒）
    
    Returns:
        健康检查函数
    """
    def checker(address: str, port: int) -> bool:
        import socket
        try:
            sock = socket.create_connection((address, port), timeout=timeout)
            sock.close()
            return True
        except Exception:
            return False
    return checker


def create_http_health_checker(
    path: str = "/health",
    timeout: float = 5.0,
    expected_status: int = 200,
) -> Callable[[str, int], bool]:
    """
    创建 HTTP 健康检查器
    
    Args:
        path: 健康检查路径
        timeout: 请求超时时间（秒）
        expected_status: 预期的 HTTP 状态码
    
    Returns:
        健康检查函数
    """
    def checker(address: str, port: int) -> bool:
        import urllib.request
        import urllib.error
        
        url = f"http://{address}:{port}{path}"
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.status == expected_status
        except Exception:
            return False
    return checker
