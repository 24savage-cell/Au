"""
内存安全工具

提供敏感数据的安全内存管理。
"""
import ctypes
import sys


def secure_zero_memory(obj: bytearray) -> None:
    """
    安全清零内存
    
    使用 ctypes 确保内存被实际清零，而非仅标记为可回收。
    修复: 添加空值检查和异常处理
    """
    if obj is None:
        return
    if not isinstance(obj, bytearray):
        raise TypeError("Expected bytearray")
    if len(obj) == 0:
        return
    
    try:
        # 获取内存地址
        buf = (ctypes.c_char * len(obj)).from_buffer(obj)
        ctypes.memset(ctypes.addressof(buf), 0, len(obj))
        del buf  # 释放缓冲区引用
    except (BufferError, ValueError):
        # 缓冲区可能已被释放或不可写，尝试直接清零
        for i in range(len(obj)):
            obj[i] = 0


class SecureBuffer:
    """
    安全缓冲区
    
    自动清零的敏感数据缓冲区。
    """
    
    def __init__(self, size: int):
        self._buffer = bytearray(size)
        self._size = size
    
    def __enter__(self):
        return self._buffer
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        secure_zero_memory(self._buffer)
        return False
    
    def __del__(self):
        try:
            secure_zero_memory(self._buffer)
        except:
            pass
    
    @property
    def buffer(self) -> bytearray:
        return self._buffer
