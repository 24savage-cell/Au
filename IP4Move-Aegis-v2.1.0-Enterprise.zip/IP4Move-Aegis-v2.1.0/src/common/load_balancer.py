"""
负载均衡器

支持多种负载均衡策略。
"""
import random
import hashlib
from typing import List, Callable, Optional
from dataclasses import dataclass


@dataclass
class Backend:
    """后端服务"""
    id: str
    address: str
    port: int
    weight: int = 1
    healthy: bool = True
    current_connections: int = 0


class LoadBalancer:
    """负载均衡器基类"""
    
    def __init__(self, backends: List[Backend]):
        self._backends = backends
    
    def select(self, key: Optional[str] = None) -> Optional[Backend]:
        raise NotImplementedError
    
    def mark_healthy(self, backend_id: str) -> None:
        """标记后端为健康"""
        for b in self._backends:
            if b.id == backend_id:
                b.healthy = True
                break
    
    def mark_unhealthy(self, backend_id: str) -> None:
        """标记后端为不健康"""
        for b in self._backends:
            if b.id == backend_id:
                b.healthy = False
                break
    
    def add_backend(self, backend: Backend) -> None:
        """添加后端服务"""
        self._backends.append(backend)
    
    def remove_backend(self, backend_id: str) -> bool:
        """移除后端服务"""
        for i, b in enumerate(self._backends):
            if b.id == backend_id:
                self._backends.pop(i)
                return True
        return False
    
    def update_backend_weight(self, backend_id: str, weight: int) -> bool:
        """更新后端权重"""
        for b in self._backends:
            if b.id == backend_id:
                b.weight = weight
                return True
        return False
    
    @property
    def healthy_backends(self) -> List[Backend]:
        """获取健康的后端列表"""
        return [b for b in self._backends if b.healthy]
    
    @property
    def all_backends(self) -> List[Backend]:
        """获取所有后端"""
        return self._backends.copy()
    
    @property
    def backend_count(self) -> int:
        """获取后端数量"""
        return len(self._backends)
    
    @property
    def healthy_count(self) -> int:
        """获取健康后端数量"""
        return len(self.healthy_backends)


class RoundRobinBalancer(LoadBalancer):
    """轮询负载均衡"""
    
    def __init__(self, backends: List[Backend]):
        super().__init__(backends)
        self._index = 0
    
    def select(self, key: Optional[str] = None) -> Optional[Backend]:
        """轮询选择后端"""
        healthy = self.healthy_backends
        if not healthy:
            return None
        
        backend = healthy[self._index % len(healthy)]
        self._index += 1
        return backend


class WeightedBalancer(LoadBalancer):
    """加权负载均衡"""
    
    def select(self, key: Optional[str] = None) -> Optional[Backend]:
        """加权随机选择后端"""
        healthy = self.healthy_backends
        if not healthy:
            return None
        
        total_weight = sum(b.weight for b in healthy)
        if total_weight <= 0:
            return random.choice(healthy)
        
        point = random.randint(1, total_weight)
        
        current = 0
        for backend in healthy:
            current += backend.weight
            if point <= current:
                return backend
        
        return healthy[-1]


class ConsistentHashBalancer(LoadBalancer):
    """一致性哈希负载均衡"""
    
    def __init__(self, backends: List[Backend], replicas: int = 150):
        super().__init__(backends)
        self._replicas = replicas
        self._ring: dict[int, Backend] = {}
        self._build_ring()
    
    def _build_ring(self) -> None:
        """构建哈希环"""
        self._ring = {}
        for backend in self._backends:
            for i in range(self._replicas):
                key = f"{backend.id}:{i}"
                hash_val = int(hashlib.md5(key.encode()).hexdigest(), 16)
                self._ring[hash_val] = backend
    
    def select(self, key: str) -> Optional[Backend]:
        """
        根据 key 选择后端
        
        Args:
            key: 用于哈希的键（如用户ID、会话ID等）
        """
        if not key:
            raise ValueError("Key is required for consistent hashing")
        
        healthy = {b.id for b in self.healthy_backends}
        hash_val = int(hashlib.md5(key.encode()).hexdigest(), 16)
        
        # 顺时针查找第一个节点
        sorted_hashes = sorted(self._ring.keys())
        for h in sorted_hashes:
            if h >= hash_val and self._ring[h].id in healthy:
                return self._ring[h]
        
        # 回绕到第一个
        for h in sorted_hashes:
            if self._ring[h].id in healthy:
                return self._ring[h]
        
        return None
    
    def add_backend(self, backend: Backend) -> None:
        """添加后端并重建哈希环"""
        super().add_backend(backend)
        self._build_ring()
    
    def remove_backend(self, backend_id: str) -> bool:
        """移除后端并重建哈希环"""
        result = super().remove_backend(backend_id)
        if result:
            self._build_ring()
        return result


class LeastConnectionsBalancer(LoadBalancer):
    """最少连接负载均衡"""
    
    def select(self, key: Optional[str] = None) -> Optional[Backend]:
        """选择当前连接数最少的后端"""
        healthy = self.healthy_backends
        if not healthy:
            return None
        
        return min(healthy, key=lambda b: b.current_connections)
    
    def acquire_backend(self, key: Optional[str] = None) -> Optional[Backend]:
        """获取后端并增加连接计数"""
        backend = self.select(key)
        if backend:
            backend.current_connections += 1
        return backend
    
    def release_backend(self, backend_id: str) -> bool:
        """释放后端连接"""
        for b in self._backends:
            if b.id == backend_id:
                b.current_connections = max(0, b.current_connections - 1)
                return True
        return False


class IPHashBalancer(LoadBalancer):
    """IP 哈希负载均衡"""
    
    def select(self, key: Optional[str] = None) -> Optional[Backend]:
        """
        根据 IP 选择后端
        
        Args:
            key: 客户端 IP 地址
        """
        if not key:
            raise ValueError("IP address is required for IP hash balancing")
        
        healthy = self.healthy_backends
        if not healthy:
            return None
        
        hash_val = int(hashlib.md5(key.encode()).hexdigest(), 16)
        index = hash_val % len(healthy)
        return healthy[index]


class AdaptiveBalancer(LoadBalancer):
    """
    自适应负载均衡器
    
    根据后端响应时间和健康状态动态调整权重。
    """
    
    def __init__(self, backends: List[Backend]):
        super().__init__(backends)
        self._response_times: dict[str, List[float]] = {}
        self._max_history = 10
    
    def record_response_time(self, backend_id: str, response_time: float) -> None:
        """记录后端响应时间"""
        if backend_id not in self._response_times:
            self._response_times[backend_id] = []
        
        self._response_times[backend_id].append(response_time)
        
        # 限制历史记录大小
        if len(self._response_times[backend_id]) > self._max_history:
            self._response_times[backend_id].pop(0)
    
    def _get_avg_response_time(self, backend_id: str) -> float:
        """获取平均响应时间"""
        times = self._response_times.get(backend_id, [])
        if not times:
            return float('inf')
        return sum(times) / len(times)
    
    def select(self, key: Optional[str] = None) -> Optional[Backend]:
        """
        根据响应时间加权选择后端
        
        响应时间越短，被选中的概率越高。
        """
        healthy = self.healthy_backends
        if not healthy:
            return None
        
        # 计算权重（响应时间的倒数）
        weights = []
        for backend in healthy:
            avg_time = self._get_avg_response_time(backend.id)
            # 避免除以零，最小响应时间为 1ms
            weight = 1.0 / max(avg_time, 0.001)
            weights.append(weight)
        
        total_weight = sum(weights)
        if total_weight <= 0:
            return random.choice(healthy)
        
        # 加权随机选择
        point = random.uniform(0, total_weight)
        current = 0.0
        
        for i, backend in enumerate(healthy):
            current += weights[i]
            if point <= current:
                return backend
        
        return healthy[-1]


class LoadBalancerFactory:
    """负载均衡器工厂"""
    
    STRATEGIES = {
        "round_robin": RoundRobinBalancer,
        "weighted": WeightedBalancer,
        "consistent_hash": ConsistentHashBalancer,
        "least_connections": LeastConnectionsBalancer,
        "ip_hash": IPHashBalancer,
        "adaptive": AdaptiveBalancer,
    }
    
    @classmethod
    def create(cls, strategy: str, backends: List[Backend], **kwargs) -> LoadBalancer:
        """
        创建负载均衡器
        
        Args:
            strategy: 负载均衡策略名称
            backends: 后端服务列表
            **kwargs: 额外的参数
        
        Returns:
            负载均衡器实例
        """
        strategy = strategy.lower()
        if strategy not in cls.STRATEGIES:
            raise ValueError(
                f"不支持的负载均衡策略: {strategy}. "
                f"支持的策略: {list(cls.STRATEGIES.keys())}"
            )
        
        balancer_class = cls.STRATEGIES[strategy]
        return balancer_class(backends, **kwargs)
    
    @classmethod
    def get_supported_strategies(cls) -> List[str]:
        """获取支持的策略列表"""
        return list(cls.STRATEGIES.keys())
