"""
配置管理器

支持动态配置热更新，无需重启服务。
"""
import os
import yaml
import json
import time
import asyncio
from typing import Dict, Any, Callable, Optional, List
from dataclasses import dataclass


@dataclass
class ConfigChange:
    """配置变更事件"""
    key: str
    old_value: Any
    new_value: Any
    timestamp: float


class ConfigManager:
    """
    配置管理器
    
    支持从文件加载配置，并监听变更。
    """
    
    def __init__(self, config_path: str, auto_reload: bool = True):
        self._config_path = config_path
        self._config: Dict[str, Any] = {}
        self._callbacks: Dict[str, List[Callable]] = {}
        self._global_callbacks: List[Callable] = []
        self._auto_reload = auto_reload
        self._observer = None
        self._last_modified = 0.0
        self._reload_task: Optional[asyncio.Task] = None
        self._running = False
        
        self._load_config()
        
        if auto_reload:
            self._start_watching()
    
    def _load_config(self) -> None:
        """加载配置文件"""
        try:
            with open(self._config_path, 'r') as f:
                if self._config_path.endswith('.yaml') or self._config_path.endswith('.yml'):
                    self._config = yaml.safe_load(f) or {}
                elif self._config_path.endswith('.json'):
                    self._config = json.load(f)
                else:
                    raise ValueError(f"不支持的配置格式: {self._config_path}")
            
            self._last_modified = os.path.getmtime(self._config_path)
        except FileNotFoundError:
            self._config = {}
        except Exception as e:
            print(f"加载配置失败: {e}")
            self._config = {}
    
    def _start_watching(self) -> None:
        """启动文件监听"""
        try:
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler
            
            class ConfigHandler(FileSystemEventHandler):
                def __init__(self, manager: 'ConfigManager'):
                    self._manager = manager
                    self._last_reload = 0
                
                def on_modified(self, event):
                    if event.src_path == self._manager._config_path:
                        # 防抖
                        now = time.time()
                        if now - self._last_reload > 1.0:
                            self._last_reload = now
                            asyncio.create_task(self._manager._reload())
            
            self._observer = Observer()
            self._observer.schedule(
                ConfigHandler(self),
                os.path.dirname(self._config_path) or '.',
                recursive=False
            )
            self._observer.start()
            self._running = True
            
        except ImportError:
            print("watchdog 未安装，使用轮询方式监听配置变更")
            self._start_polling()
    
    def _start_polling(self) -> None:
        """启动轮询监听"""
        self._running = True
        
        async def poll_loop():
            while self._running:
                try:
                    if os.path.exists(self._config_path):
                        mtime = os.path.getmtime(self._config_path)
                        if mtime > self._last_modified:
                            await self._reload()
                except Exception as e:
                    print(f"轮询配置失败: {e}")
                
                await asyncio.sleep(5.0)  # 每5秒检查一次
        
        self._reload_task = asyncio.create_task(poll_loop())
    
    async def _reload(self) -> None:
        """重新加载配置"""
        old_config = self._config.copy()
        self._load_config()
        
        # 检测变更
        changes = []
        all_keys = set(old_config.keys()) | set(self._config.keys())
        
        for key in all_keys:
            old_val = old_config.get(key)
            new_val = self._config.get(key)
            
            if old_val != new_val:
                change = ConfigChange(key, old_val, new_val, time.time())
                changes.append(change)
                
                # 触发特定键的回调
                for callback in self._callbacks.get(key, []):
                    try:
                        callback(change)
                    except Exception as e:
                        print(f"配置回调错误: {e}")
        
        # 触发全局回调
        for callback in self._global_callbacks:
            try:
                callback(changes)
            except Exception as e:
                print(f"配置全局回调错误: {e}")
        
        if changes:
            print(f"配置已重新加载，变更项: {len(changes)}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置值
        
        支持使用点号访问嵌套配置，如 "database.host"。
        """
        keys = key.split('.')
        value = self._config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any) -> None:
        """
        设置配置值（不持久化到文件）
        
        支持使用点号设置嵌套配置，如 "database.host"。
        """
        keys = key.split('.')
        config = self._config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        old_value = config.get(keys[-1])
        config[keys[-1]] = value
        
        if old_value != value:
            change = ConfigChange(key, old_value, value, time.time())
            for callback in self._callbacks.get(key, []):
                try:
                    callback(change)
                except Exception as e:
                    print(f"配置回调错误: {e}")
    
    def get_all(self) -> Dict[str, Any]:
        """获取所有配置"""
        return self._config.copy()
    
    def on_change(self, key: str, callback: Callable[[ConfigChange], None]) -> None:
        """注册配置变更回调"""
        if key not in self._callbacks:
            self._callbacks[key] = []
        self._callbacks[key].append(callback)
    
    def remove_callback(self, key: str, callback: Callable) -> bool:
        """移除配置变更回调"""
        if key in self._callbacks and callback in self._callbacks[key]:
            self._callbacks[key].remove(callback)
            return True
        return False
    
    def on_any_change(self, callback: Callable[[List[ConfigChange]], None]) -> None:
        """注册全局配置变更回调"""
        self._global_callbacks.append(callback)
    
    def remove_global_callback(self, callback: Callable) -> bool:
        """移除全局配置变更回调"""
        if callback in self._global_callbacks:
            self._global_callbacks.remove(callback)
            return True
        return False
    
    def save(self) -> None:
        """保存配置到文件"""
        try:
            with open(self._config_path, 'w') as f:
                if self._config_path.endswith('.yaml') or self._config_path.endswith('.yml'):
                    yaml.safe_dump(self._config, f, default_flow_style=False)
                elif self._config_path.endswith('.json'):
                    json.dump(self._config, f, indent=2)
            
            self._last_modified = os.path.getmtime(self._config_path)
        except Exception as e:
            raise IOError(f"保存配置失败: {e}")
    
    def stop(self) -> None:
        """停止配置管理器"""
        self._running = False
        
        if self._observer:
            self._observer.stop()
            self._observer.join()
            self._observer = None
        
        if self._reload_task:
            self._reload_task.cancel()
            self._reload_task = None
    
    def reload_now(self) -> None:
        """立即重新加载配置"""
        asyncio.create_task(self._reload())
    
    @property
    def config_path(self) -> str:
        """获取配置文件路径"""
        return self._config_path
    
    @property
    def is_auto_reload(self) -> bool:
        """是否启用自动重载"""
        return self._auto_reload


class ConfigValidator:
    """
    配置验证器
    
    验证配置值的类型和范围。
    """
    
    @staticmethod
    def validate_type(value: Any, expected_type: type) -> bool:
        """验证值类型"""
        return isinstance(value, expected_type)
    
    @staticmethod
    def validate_range(value: int or float, min_val: Optional[float] = None, max_val: Optional[float] = None) -> bool:
        """验证数值范围"""
        if min_val is not None and value < min_val:
            return False
        if max_val is not None and value > max_val:
            return False
        return True
    
    @staticmethod
    def validate_enum(value: Any, allowed_values: List[Any]) -> bool:
        """验证枚举值"""
        return value in allowed_values
    
    @staticmethod
    def validate_string_length(value: str, min_len: int = 0, max_len: Optional[int] = None) -> bool:
        """验证字符串长度"""
        if len(value) < min_len:
            return False
        if max_len is not None and len(value) > max_len:
            return False
        return True
    
    @staticmethod
    def validate_ip_address(value: str) -> bool:
        """验证IP地址"""
        import ipaddress
        try:
            ipaddress.ip_address(value)
            return True
        except ValueError:
            return False
    
    @staticmethod
    def validate_port(value: int) -> bool:
        """验证端口号"""
        return 1 <= value <= 65535


# 便捷函数
def load_config(config_path: str) -> Dict[str, Any]:
    """加载配置文件"""
    try:
        with open(config_path, 'r') as f:
            if config_path.endswith('.yaml') or config_path.endswith('.yml'):
                return yaml.safe_load(f) or {}
            elif config_path.endswith('.json'):
                return json.load(f)
            else:
                raise ValueError(f"不支持的配置格式: {config_path}")
    except FileNotFoundError:
        return {}


def save_config(config_path: str, config: Dict[str, Any]) -> None:
    """保存配置文件"""
    with open(config_path, 'w') as f:
        if config_path.endswith('.yaml') or config_path.endswith('.yml'):
            yaml.safe_dump(config, f, default_flow_style=False)
        elif config_path.endswith('.json'):
            json.dump(config, f, indent=2)
        else:
            raise ValueError(f"不支持的配置格式: {config_path}")
