"""
速率限制器 (性能优化版)

统一的滑动窗口速率限制实现。
优化:
- 添加线程安全锁
- 自动清理过期键
- 统计信息追踪
"""
import time
import threading
from typing import Dict, List, Optional, Any


class RateLimiter:
    """滑动窗口速率限制器 (线程安全版)"""

    def __init__(self, window: float = 60.0, max_requests: int = 100, auto_cleanup_interval: float = 300.0):
        self.window = window
        self.max_requests = max_requests
        self._timestamps: Dict[str, List[float]] = {}
        self._lock = threading.RLock()
        self._last_cleanup = time.time()
        self._auto_cleanup_interval = auto_cleanup_interval
        
        # 统计信息
        self._allowed = 0
        self._denied = 0
        self._total_requests = 0

    def check(self, key: str) -> bool:
        """检查是否允许请求 (线程安全版)"""
        with self._lock:
            self._total_requests += 1
            now = time.time()
            
            # 自动清理过期键
            if now - self._last_cleanup > self._auto_cleanup_interval:
                self._cleanup_expired_keys(now)
                self._last_cleanup = now
            
            if key not in self._timestamps:
                self._timestamps[key] = []

            # 清理过期时间戳
            cutoff = now - self.window
            self._timestamps[key] = [
                t for t in self._timestamps[key]
                if t > cutoff
            ]

            if len(self._timestamps[key]) >= self.max_requests:
                self._denied += 1
                return False

            self._timestamps[key].append(now)
            self._allowed += 1
            return True

    def _cleanup_expired_keys(self, now: Optional[float] = None) -> int:
        """清理过期的键，返回清理的数量"""
        if now is None:
            now = time.time()
        
        cutoff = now - self.window
        expired_keys = [
            key for key, timestamps in self._timestamps.items()
            if not timestamps or all(t <= cutoff for t in timestamps)
        ]
        
        for key in expired_keys:
            del self._timestamps[key]
        
        return len(expired_keys)

    def reset(self, key: str) -> bool:
        """重置指定键的速率限制"""
        with self._lock:
            existed = key in self._timestamps
            self._timestamps.pop(key, None)
            return existed

    def get_count(self, key: str) -> int:
        """获取指定键在当前窗口内的请求数"""
        with self._lock:
            now = time.time()
            if key not in self._timestamps:
                return 0
            cutoff = now - self.window
            return len([t for t in self._timestamps[key] if t > cutoff])

    def get_remaining(self, key: str) -> int:
        """获取指定键在当前窗口内剩余的请求数"""
        with self._lock:
            return max(0, self.max_requests - self.get_count(key))

    def get_reset_time(self, key: str) -> float:
        """获取指定键的速率限制重置时间"""
        with self._lock:
            if key not in self._timestamps or not self._timestamps[key]:
                return 0.0
            oldest = min(self._timestamps[key])
            return oldest + self.window

    def get_stats(self) -> Dict[str, Any]:
        """获取速率限制器统计信息"""
        with self._lock:
            success_rate = self._allowed / self._total_requests if self._total_requests > 0 else 0.0
            return {
                "window": self.window,
                "max_requests": self.max_requests,
                "active_keys": len(self._timestamps),
                "total_requests": self._total_requests,
                "allowed": self._allowed,
                "denied": self._denied,
                "success_rate": round(success_rate, 4),
            }

    def reset_stats(self) -> None:
        """重置统计信息"""
        with self._lock:
            self._allowed = 0
            self._denied = 0
            self._total_requests = 0
