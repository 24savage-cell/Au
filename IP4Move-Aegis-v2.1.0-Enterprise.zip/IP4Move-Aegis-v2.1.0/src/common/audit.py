"""
审计日志系统

记录所有安全相关操作，支持防篡改。
"""
import json
import hashlib
import time
import hmac
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum


class AuditEventType(Enum):
    """审计事件类型"""
    KEY_GENERATION = "key_generation"
    KEY_ACCESS = "key_access"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    DATA_ACCESS = "data_access"
    CONFIG_CHANGE = "config_change"
    NETWORK_CONNECTION = "network_connection"
    SECURITY_ALERT = "security_alert"


@dataclass
class AuditEvent:
    """审计事件"""
    event_type: AuditEventType
    actor: str
    action: str
    resource: str
    result: str
    timestamp: float
    details: Dict[str, Any]
    event_id: str
    previous_hash: str = ""


class AuditLogger:
    """
    审计日志记录器
    
    使用区块链式哈希链确保日志不可篡改。
    """
    
    def __init__(self, log_file: str, hmac_key: bytes):
        self._log_file = log_file
        self._hmac_key = hmac_key
        self._last_hash = self._load_last_hash()
    
    def _load_last_hash(self) -> str:
        """加载最后一个日志条目的哈希"""
        try:
            with open(self._log_file, 'r') as f:
                lines = f.readlines()
                if lines:
                    last_event = json.loads(lines[-1])
                    return last_event['hash']
        except FileNotFoundError:
            pass
        return "0" * 64
    
    def _compute_hash(self, event: AuditEvent) -> str:
        """计算事件哈希"""
        data = json.dumps(asdict(event), sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()
    
    def _compute_chain_hash(self, event_hash: str) -> str:
        """计算链式哈希（包含前一个哈希）"""
        data = self._last_hash + event_hash
        return hashlib.sha256(data.encode()).hexdigest()
    
    def log(self, event: AuditEvent) -> None:
        """记录审计事件"""
        event_hash = self._compute_hash(event)
        chain_hash = self._compute_chain_hash(event_hash)
        
        # 计算 HMAC
        mac = hmac.new(self._hmac_key, chain_hash.encode(), hashlib.sha256).hexdigest()
        
        entry = {
            'event': asdict(event),
            'hash': chain_hash,
            'hmac': mac,
        }
        
        with open(self._log_file, 'a') as f:
            f.write(json.dumps(entry) + '\n')
        
        self._last_hash = chain_hash
    
    def verify_chain(self) -> bool:
        """验证日志链完整性"""
        try:
            with open(self._log_file, 'r') as f:
                lines = f.readlines()
                
            prev_hash = "0" * 64
            for line in lines:
                entry = json.loads(line)
                event = AuditEvent(**entry['event'])
                
                # 验证事件哈希
                expected_hash = self._compute_hash(event)
                expected_chain_hash = hashlib.sha256(
                    (prev_hash + expected_hash).encode()
                ).hexdigest()
                
                if entry['hash'] != expected_chain_hash:
                    return False
                
                # 验证 HMAC
                expected_mac = hmac.new(
                    self._hmac_key,
                    entry['hash'].encode(),
                    hashlib.sha256
                ).hexdigest()
                
                if not hmac.compare_digest(entry['hmac'], expected_mac):
                    return False
                
                prev_hash = entry['hash']
            
            return True
        except Exception:
            return False
