"""
监控与应急响应模块 (Monitoring & Incident Response Module)

本模块提供全网络监控与应急响应功能，包括：
- 全网络实时监控（分布式监控节点、多维指标采集）
- AI异常行为检测（统计方法、机器学习、时序分析）
- 应急响应预案（自动化响应流程、攻击分类）
- 节点快速隔离与替换（自动隔离、流量重路由）

安全级别：网络运维 Level 3
兼容性：Python 3.10+

典型用法:
    from src.monitoring_v2 import (
        NetworkMonitor,
        AnomalyDetector,
        IncidentResponseManager,
        NodeIsolationManager,
    )

    # 全网络监控
    monitor = NetworkMonitor()
    monitor.start_monitoring()

    # 异常检测
    detector = AnomalyDetector()
    anomalies = detector.detect_anomalies(metrics_data)

    # 应急响应
    responder = IncidentResponseManager()
    responder.activate_plan("DDoS_MITIGATION")

    # 节点隔离
    isolator = NodeIsolationManager()
    isolator.isolate_node("compromised-node-001")
"""

# 版本信息
__version__ = "1.0.5"
__author__ = "IP4Move Aegis Security Team"
__protocol_version__ = "MON-2.0"

# 从 intelligent_monitoring 模块导出所有公开类
from src.monitoring_v2.intelligent_monitoring import (
    NetworkMonitor,
    AnomalyDetector,
    IncidentResponseManager,
    NodeIsolationManager,
)

__all__ = [
    "NetworkMonitor",
    "AnomalyDetector",
    "IncidentResponseManager",
    "NodeIsolationManager",
]
