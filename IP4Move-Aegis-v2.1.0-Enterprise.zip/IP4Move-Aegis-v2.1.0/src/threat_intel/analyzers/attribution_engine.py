"""
攻击归因引擎模块

基于TTP匹配进行攻击归因
"""

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class AttributionResult:
    """归因结果"""
    threat_actor: str
    confidence: float
    matched_ttps: list[str]
    evidence: list[str]
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "threat_actor": self.threat_actor,
            "confidence": self.confidence,
            "matched_ttps": self.matched_ttps,
            "evidence": self.evidence
        }


class AttributionEngine:
    """
    攻击归因引擎
    
    基于TTP匹配归因威胁行为者
    """
    
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self._actor_profiles: dict[str, list[str]] = {}
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化"""
        if self._initialized:
            return
        logger.info("初始化归因引擎...")
        self._initialized = True
        logger.info("归因引擎初始化完成")
        
    async def shutdown(self) -> None:
        """关闭"""
        self._initialized = False
        logger.info("归因引擎已关闭")
        
    def add_actor_profile(self, actor: str, ttps: list[str]) -> None:
        """添加威胁行为者档案"""
        self._actor_profiles[actor] = ttps
        
    async def attribute(self, observed_ttps: list[str]) -> list[AttributionResult]:
        """
        归因分析
        
        Args:
            observed_ttps: 观察到的TTP
            
        Returns:
            归因结果列表
        """
        results = []
        
        for actor, profile_ttps in self._actor_profiles.items():
            matched = set(observed_ttps) & set(profile_ttps)
            if matched:
                confidence = len(matched) / len(profile_ttps)
                results.append(AttributionResult(
                    threat_actor=actor,
                    confidence=confidence,
                    matched_ttps=list(matched),
                    evidence=[f"匹配TTP: {t}" for t in matched]
                ))
                
        return sorted(results, key=lambda r: r.confidence, reverse=True)
        
    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        return {
            "actor_profiles": len(self._actor_profiles),
            "enabled": self.enabled
        }
