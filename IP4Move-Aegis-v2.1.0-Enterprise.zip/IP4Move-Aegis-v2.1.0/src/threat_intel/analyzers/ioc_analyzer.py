"""
IOC分析器模块

提供IP、域名、URL、哈希、邮箱等IOC的分析功能
"""

import asyncio
import hashlib
import ipaddress
import logging
import re
from dataclasses import dataclass
from datetime import datetime
from enum import Enum, auto
from typing import Any, Optional

logger = logging.getLogger(__name__)


class IOCTypes(Enum):
    """IOC类型"""
    IP = "ip"
    DOMAIN = "domain"
    URL = "url"
    HASH_MD5 = "hash_md5"
    HASH_SHA1 = "hash_sha1"
    HASH_SHA256 = "hash_sha256"
    EMAIL = "email"
    CVE = "cve"
    MUTEX = "mutex"
    REGISTRY = "registry"
    FILENAME = "filename"


@dataclass
class IOCResult:
    """IOC分析结果"""
    ioc_value: str
    ioc_type: IOCTypes
    is_malicious: bool
    confidence: float
    sources: list[str]
    first_seen: Optional[datetime]
    last_seen: Optional[datetime]
    tags: list[str]
    related_iocs: list[str]
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "ioc_value": self.ioc_value,
            "ioc_type": self.ioc_type.value,
            "is_malicious": self.is_malicious,
            "confidence": self.confidence,
            "sources": self.sources,
            "first_seen": self.first_seen.isoformat() if self.first_seen else None,
            "last_seen": self.last_seen.isoformat() if self.last_seen else None,
            "tags": self.tags,
            "related_iocs": self.related_iocs
        }


class IOCAnalyzer:
    """
    IOC分析器
    
    分析各种类型的IOC指标
    """
    
    # 正则表达式模式
    PATTERNS = {
        IOCTypes.IP: r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$",
        IOCTypes.DOMAIN: r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]$",
        IOCTypes.URL: r"^https?://[^\s/$.?#].[^\s]*$",
        IOCTypes.HASH_MD5: r"^[a-fA-F0-9]{32}$",
        IOCTypes.HASH_SHA1: r"^[a-fA-F0-9]{40}$",
        IOCTypes.HASH_SHA256: r"^[a-fA-F0-9]{64}$",
        IOCTypes.EMAIL: r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
        IOCTypes.CVE: r"^CVE-\d{4}-\d{4,}$",
    }
    
    def __init__(self, config: Optional[dict] = None):
        """
        初始化IOC分析器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        
        # 编译正则表达式
        self._compiled_patterns = {
            ioc_type: re.compile(pattern)
            for ioc_type, pattern in self.PATTERNS.items()
        }
        
        # IOC数据库（模拟）
        self._ioc_db: dict[str, IOCResult] = {}
        
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化分析器"""
        if self._initialized:
            return
            
        logger.info("初始化IOC分析器...")
        self._initialized = True
        logger.info("IOC分析器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭分析器"""
        self._initialized = False
        logger.info("IOC分析器已关闭")
        
    def detect_ioc_type(self, value: str) -> Optional[IOCTypes]:
        """
        检测IOC类型
        
        Args:
            value: IOC值
            
        Returns:
            IOC类型
        """
        for ioc_type, pattern in self._compiled_patterns.items():
            if pattern.match(value):
                return ioc_type
        return None
        
    async def analyze(self, ioc_value: str) -> IOCResult:
        """
        分析IOC
        
        Args:
            ioc_value: IOC值
            
        Returns:
            分析结果
        """
        # 检测类型
        ioc_type = self.detect_ioc_type(ioc_value)
        if not ioc_type:
            ioc_type = IOCTypes.FILENAME
            
        # 检查缓存
        if ioc_value in self._ioc_db:
            return self._ioc_db[ioc_value]
            
        # 执行分析
        result = await self._analyze_by_type(ioc_value, ioc_type)
        
        # 缓存结果
        self._ioc_db[ioc_value] = result
        
        return result
        
    async def _analyze_by_type(self, value: str, ioc_type: IOCTypes) -> IOCResult:
        """
        根据类型分析IOC
        
        Args:
            value: IOC值
            ioc_type: IOC类型
            
        Returns:
            分析结果
        """
        # 模拟分析结果
        is_malicious = self._check_threat_intelligence(value, ioc_type)
        
        return IOCResult(
            ioc_value=value,
            ioc_type=ioc_type,
            is_malicious=is_malicious,
            confidence=0.85 if is_malicious else 0.15,
            sources=["internal_db", "threat_feed"],
            first_seen=datetime.utcnow(),
            last_seen=datetime.utcnow(),
            tags=["suspicious"] if is_malicious else ["clean"],
            related_iocs=[]
        )
        
    def _check_threat_intelligence(self, value: str, ioc_type: IOCTypes) -> bool:
        """
        检查威胁情报
        
        Args:
            value: IOC值
            ioc_type: IOC类型
            
        Returns:
            是否恶意
        """
        # 模拟威胁情报检查
        # 实际实现中会查询多个威胁情报源
        suspicious_patterns = [
            "malware", "phishing", "c2", "botnet", "trojan"
        ]
        return any(pattern in value.lower() for pattern in suspicious_patterns)
        
    def validate_ip(self, ip: str) -> bool:
        """
        验证IP地址
        
        Args:
            ip: IP地址
            
        Returns:
            是否有效
        """
        try:
            ipaddress.ip_address(ip)
            return True
        except ValueError:
            return False
            
    def is_private_ip(self, ip: str) -> bool:
        """
        检查是否为私有IP
        
        Args:
            ip: IP地址
            
        Returns:
            是否私有
        """
        try:
            ip_obj = ipaddress.ip_address(ip)
            return ip_obj.is_private
        except ValueError:
            return False
            
    def get_stats(self) -> dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息
        """
        return {
            "cached_iocs": len(self._ioc_db),
            "enabled": self.enabled
        }
