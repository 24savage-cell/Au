"""
攻击活动追踪模块

追踪和分析攻击活动
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class AttackCampaign:
    """攻击活动"""
    campaign_id: str
    name: str
    description: str
    first_seen: datetime
    last_seen: datetime
    threat_actor: str
    targets: list[str] = field(default_factory=list)
    ttps: list[str] = field(default_factory=list)
    iocs: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "campaign_id": self.campaign_id,
            "name": self.name,
            "description": self.description,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "threat_actor": self.threat_actor,
            "targets": self.targets,
            "ttps": self.ttps,
            "iocs": self.iocs
        }


class CampaignTracker:
    """
    攻击活动追踪器
    
    追踪和分析攻击活动
    """
    
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self._campaigns: dict[str, AttackCampaign] = {}
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化"""
        if self._initialized:
            return
        logger.info("初始化攻击活动追踪器...")
        self._initialized = True
        logger.info("攻击活动追踪器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭"""
        self._initialized = False
        logger.info("攻击活动追踪器已关闭")
        
    def track_campaign(self, campaign: AttackCampaign) -> None:
        """追踪攻击活动"""
        self._campaigns[campaign.campaign_id] = campaign
        logger.info(f"追踪攻击活动: {campaign.name}")
        
    def get_campaign(self, campaign_id: str) -> Optional[AttackCampaign]:
        """获取攻击活动"""
        return self._campaigns.get(campaign_id)
        
    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        return {
            "tracked_campaigns": len(self._campaigns),
            "enabled": self.enabled
        }
