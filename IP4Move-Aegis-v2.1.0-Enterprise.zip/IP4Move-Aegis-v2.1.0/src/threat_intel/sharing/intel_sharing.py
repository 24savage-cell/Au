"""
情报共享模块

多源情报聚合和去重
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class IntelFeed:
    """情报源"""
    feed_id: str
    name: str
    source_type: str
    reliability: float
    last_update: datetime
    indicators: list[dict] = field(default_factory=list)


class IntelSharing:
    """
    情报共享管理器
    
    聚合多源情报并进行去重
    """
    
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        
        self._feeds: dict[str, IntelFeed] = {}
        self._dedup_cache: set[str] = set()
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化"""
        if self._initialized:
            return
        logger.info("初始化情报共享管理器...")
        self._initialized = True
        logger.info("情报共享管理器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭"""
        self._initialized = False
        logger.info("情报共享管理器已关闭")
        
    def add_feed(self, feed: IntelFeed) -> None:
        """添加情报源"""
        self._feeds[feed.feed_id] = feed
        
    def aggregate_indicators(self) -> list[dict]:
        """
        聚合所有情报源的指标
        
        Returns:
            去重后的指标列表
        """
        all_indicators = []
        
        for feed in self._feeds.values():
            for indicator in feed.indicators:
                # 计算指纹
                fingerprint = self._calculate_fingerprint(indicator)
                
                if fingerprint not in self._dedup_cache:
                    self._dedup_cache.add(fingerprint)
                    indicator["source"] = feed.name
                    indicator["reliability"] = feed.reliability
                    all_indicators.append(indicator)
                    
        return all_indicators
        
    def _calculate_fingerprint(self, indicator: dict) -> str:
        """计算指标指纹"""
        data = json.dumps(indicator, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()[:16]
        
    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        return {
            "feeds": len(self._feeds),
            "unique_indicators": len(self._dedup_cache),
            "enabled": self.enabled
        }
