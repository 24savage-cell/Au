"""
TLP执行模块

强制执行Traffic Light Protocol颜色标记
"""

import asyncio
import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


class TLPLevel(Enum):
    """TLP级别"""
    RED = "TLP:RED"       # 仅限接收者
    AMBER = "TLP:AMBER"   # 仅限组织内
    GREEN = "TLP:GREEN"   # 社区内共享
    CLEAR = "TLP:CLEAR"   # 无限制


@dataclass
class TLPClassification:
    """TLP分类"""
    level: TLPLevel
    description: str
    allowed_recipients: list[str]


class TLPEnforcer:
    """
    TLP执行器
    
    强制执行TLP颜色标记规则
    """
    
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)
        self.default_level = TLPLevel(self.config.get("default_level", "TLP:GREEN"))
        self._initialized = False
        
    async def initialize(self) -> None:
        """初始化"""
        if self._initialized:
            return
        logger.info("初始化TLP执行器...")
        self._initialized = True
        logger.info("TLP执行器初始化完成")
        
    async def shutdown(self) -> None:
        """关闭"""
        self._initialized = False
        logger.info("TLP执行器已关闭")
        
    def classify(self, level: TLPLevel, description: str = "") -> TLPClassification:
        """
        分类情报
        
        Args:
            level: TLP级别
            description: 描述
            
        Returns:
            TLP分类
        """
        allowed = self._get_allowed_recipients(level)
        return TLPClassification(
            level=level,
            description=description,
            allowed_recipients=allowed
        )
        
    def _get_allowed_recipients(self, level: TLPLevel) -> list[str]:
        """获取允许接收者"""
        mapping = {
            TLPLevel.RED: ["direct_recipients"],
            TLPLevel.AMBER: ["organization_members"],
            TLPLevel.GREEN: ["community_members"],
            TLPLevel.CLEAR: ["everyone"]
        }
        return mapping.get(level, ["organization_members"])
        
    def can_share(self, classification: TLPClassification, recipient: str) -> bool:
        """
        检查是否可以共享
        
        Args:
            classification: TLP分类
            recipient: 接收者
            
        Returns:
            是否可以共享
        """
        if classification.level == TLPLevel.CLEAR:
            return True
        return recipient in classification.allowed_recipients
        
    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        return {
            "default_level": self.default_level.value,
            "enabled": self.enabled
        }
