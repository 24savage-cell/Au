"""
威胁情报关联模块

提供事件关联和模式匹配
"""

from .event_correlator import EventCorrelator, CorrelationGraph, CorrelationNode, CorrelationEdge
from .pattern_matcher import MITREPatternMatcher, ATTACKPattern

__all__ = [
    "EventCorrelator",
    "CorrelationGraph",
    "CorrelationNode",
    "CorrelationEdge",
    "MITREPatternMatcher",
    "ATTACKPattern",
]
