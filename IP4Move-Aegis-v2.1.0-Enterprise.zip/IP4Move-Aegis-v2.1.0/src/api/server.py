"""
IP.4/Move-Aegis FastAPI 应用

生产级 API 服务器
"""

import os
import re
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

from fastapi import Depends, FastAPI, HTTPException, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from prometheus_client import generate_latest
from prometheus_fastapi_instrumentator import Instrumentator

from src.api.auth import APIKeyInfo, require_admin
from src.health import HealthChecker
from src.logging_config import LogContext, get_logger, setup_logging
from src.metrics import init_system_info

logger = get_logger(__name__)


class APIError(Exception):
    """API 错误基类"""
    def __init__(self, code: str, message: str, status_code: int = 400):
        self.code = code
        self.message = message
        self.status_code = status_code
        super().__init__(message)


def create_app(
    log_level: str = "INFO",
    json_logs: bool = False,
    version: str = "1.0.1",
    cors_origins: Optional[List[str]] = None,
) -> FastAPI:
    """创建 FastAPI 应用实例"""
    setup_logging(log_level=log_level, json_output=json_logs)
    init_system_info(version)

    _is_prod = os.environ.get("IP4MOVE_ENV", "").lower() in ("production", "prod", "live")

    app = FastAPI(
        title="IP.4/Move-Aegis API",
        description="IP.4/Move-Aegis 匿名网络系统 API",
        version=version,
        docs_url=None if _is_prod else "/docs",
        redoc_url=None if _is_prod else "/redoc",
        openapi_url=None if _is_prod else "/openapi.json",
        contact={"name": "IP.4/Move Team", "email": "team@ip4move.org"},
        license_info={"name": "MIT"},
    )

    # CORS 白名单配置
    allowed_origins = cors_origins or [
        "https://ip4move.org",
        "https://admin.ip4move.org",
        "http://localhost:3000",
    ]
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["X-API-Key", "Content-Type", "Authorization", "X-Request-ID"],
        expose_headers=["X-Request-ID", "X-Response-Time"],
        max_age=600,
    )

    app.add_middleware(GZipMiddleware, minimum_size=1000)

    # 请求ID中间件
    @app.middleware("http")
    async def request_id_middleware(request: Request, call_next: Callable) -> Response:
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        request.state.request_id = request_id

        with LogContext(request_id=request_id, path=request.url.path):
            start = time.perf_counter()
            response = await call_next(request)
            duration = time.perf_counter() - start

            response.headers["X-Request-ID"] = request_id
            response.headers["X-Response-Time"] = f"{duration:.3f}s"

            logger.info(
                "request_completed",
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                duration_ms=round(duration * 1000, 2),
            )
        return response

    # --- 安全中间件 ---
    @app.middleware("http")
    async def security_middleware(request: Request, call_next):
        """安全中间件: 请求体大小限制 + 安全响应头 + 日志脱敏"""
        # 请求体大小限制 (10MB)
        if request.method in ("POST", "PUT", "PATCH"):
            content_length = request.headers.get("content-length")
            if content_length:
                try:
                    if int(content_length) > 10 * 1024 * 1024:
                        from fastapi.responses import JSONResponse
                        return JSONResponse(
                            status_code=413,
                            content={"error": {"code": "REQUEST_TOO_LARGE", "message": "Request body exceeds 10MB limit"}},
                        )
                except (ValueError, TypeError):
                    pass

        response = await call_next(request)

        # 安全响应头
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = (
            "accelerometer=(), camera=(), geolocation=(), gyroscope=(), "
            "magnetometer=(), microphone=(), payment=(), usb=()"
        )
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
        # 防止Server版本泄露
        response.headers["Server"] = "IP4Move-Aegis"

        # 生产环境HSTS
        if os.environ.get("IP4MOVE_ENV", "").lower() in ("production", "prod", "live"):
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"

        return response

    # 统一错误处理
    @app.exception_handler(APIError)
    async def api_error_handler(request: Request, exc: APIError) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": {
                    "code": exc.code,
                    "message": exc.message,
                    "request_id": getattr(request.state, "request_id", "unknown"),
                }
            },
        )

    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": {
                    "code": f"HTTP_{exc.status_code}",
                    "message": exc.detail if isinstance(exc.detail, str) else str(exc.detail),
                    "request_id": getattr(request.state, "request_id", "unknown"),
                }
            },
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.error(
            "unhandled_exception",
            exc_type=type(exc).__name__,
            exc_message=str(exc),
        )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": "Internal server error",
                    "request_id": getattr(request.state, "request_id", "unknown"),
                }
            },
        )

    # 健康检查
    health_checker = HealthChecker(version=version)

    @app.get("/health", tags=["Health"])
    async def health_check():
        report = await health_checker.run_checks()
        report_dict = report.to_dict()
        # 移除版本信息，防止信息泄露
        report_dict["version"] = "redacted"
        return JSONResponse(
            status_code=200 if report.status.value == "healthy" else 503,
            content=report_dict,
        )

    @app.get("/health/live", tags=["Health"])
    async def liveness():
        return health_checker.liveness()

    @app.get("/health/ready", tags=["Health"])
    async def readiness():
        return health_checker.readiness()

    # Prometheus 指标 (安全版本 - 强制管理员认证)
    @app.get("/metrics", tags=["Monitoring"])
    async def metrics(request: Request, auth: APIKeyInfo = Depends(require_admin)):
        """安全Metrics端点 - 强制要求管理员权限"""
        return PlainTextResponse(
            content=generate_latest(),
            media_type="text/plain; version=0.0.4; charset=utf-8",
        )

    # 注册路由
    from src.api.routes import (
        crypto_router,
        dht_router,
        mixnet_router,
        node_router,
        routing_router,
        security_router,
    )

    app.include_router(node_router, prefix="/api/v1/nodes", tags=["Node Management"])
    app.include_router(routing_router, prefix="/api/v1/routing", tags=["Routing"])
    app.include_router(crypto_router, prefix="/api/v1/crypto", tags=["Cryptography"])
    app.include_router(mixnet_router, prefix="/api/v1/mixnet", tags=["Mixnet"])
    app.include_router(dht_router, prefix="/api/v1/dht", tags=["DHT"])
    app.include_router(security_router, prefix="/api/v1/security", tags=["Security"])

    # Prometheus 指标收集 (不暴露端点)
    # 注意: 不使用 Instrumentator().expose() 自动暴露端点，因为该端点无认证保护
    # 所有指标通过下方受认证保护的 /metrics 端点访问
    Instrumentator().instrument(app)

    # 受认证保护的内部指标端点 (替代自动暴露的 /metrics/internal)
    @app.get("/metrics/internal", include_in_schema=False)
    async def internal_metrics(request: Request, auth: APIKeyInfo = Depends(require_admin)):
        """内部指标 - 需要管理员认证"""
        from starlette.responses import Response as StarletteResponse
        return StarletteResponse(content=generate_latest(), media_type="text/plain")

    @app.on_event("startup")
    async def startup():
        logger.info("api_starting", version=version)

    @app.on_event("shutdown")
    async def shutdown():
        logger.info("api_shutting_down")

    return app
