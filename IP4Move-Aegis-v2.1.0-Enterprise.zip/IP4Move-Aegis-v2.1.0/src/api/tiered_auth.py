"""
分级API认证系统 - 无感刷新

修复问题:
1. 6小时统一token过期 → 用户体验差
2. 无分级策略 → 控制面和数据面混用
3. 无设备绑定 → 泄露后可滥用

解决方案:
1. 控制面短token (6h) + 数据面长token (7d)
2. 后台无感刷新
3. 设备指纹绑定

版本: v2.1.0
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import secrets
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, Optional, Any, Tuple

logger = logging.getLogger(__name__)

# 尝试导入JWT
try:
    import jwt
    HAS_JWT = True
except ImportError:
    HAS_JWT = False
    logger.warning("PyJWT未安装，使用简化token。pip install PyJWT")


# ============================================================================
# Token类型
# ============================================================================

class TokenType(Enum):
    """Token类型"""
    ACCESS = auto()       # 访问token (短效)
    REFRESH = auto()      # 刷新token (长效)
    DATA_PLANE = auto()   # 数据面token (长效)
    CONTROL_PLANE = auto()  # 控制面token (短效)


class TokenScope(Enum):
    """Token权限范围"""
    READ = "read"
    WRITE = "write"
    ADMIN = "admin"
    DATA = "data"         # 数据面访问
    CONTROL = "control"   # 控制面访问


# ============================================================================
# Token配置
# ============================================================================

@dataclass
class TokenConfig:
    """Token配置"""
    # 控制面 (管理操作) - 短效
    control_access_ttl: int = 6 * 3600      # 6小时
    control_refresh_ttl: int = 24 * 3600    # 24小时
    
    # 数据面 (实际传输) - 长效
    data_access_ttl: int = 7 * 24 * 3600    # 7天
    data_refresh_ttl: int = 30 * 24 * 3600  # 30天
    
    # 设备绑定
    device_binding_enabled: bool = True
    device_fingerprint_size: int = 32
    
    # 刷新策略
    auto_refresh_threshold: float = 0.2     # 剩余20%时自动刷新
    max_refresh_per_hour: int = 10          # 每小时最大刷新次数
    
    # 安全
    issuer: str = "IP4Move-Aegis"
    algorithm: str = "HS256"


# ============================================================================
# 设备指纹
# ============================================================================

@dataclass
class DeviceFingerprint:
    """
    设备指纹
    
    用于绑定token到特定设备，防止token被盗用
    
    组成:
    - User-Agent哈希
    - IP地址 (可选，动态IP用户不适用)
    - 客户端特征
    """
    user_agent_hash: bytes
    client_features: Dict[str, Any] = field(default_factory=dict)
    ip_address: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    
    @classmethod
    def from_request(
        cls,
        user_agent: str,
        ip_address: Optional[str] = None,
        accept_language: Optional[str] = None,
        screen_resolution: Optional[str] = None,
        timezone: Optional[str] = None,
    ) -> "DeviceFingerprint":
        """从请求信息生成设备指纹"""
        # User-Agent哈希
        ua_hash = hashlib.sha256(user_agent.encode()).digest()[:16]
        
        # 客户端特征
        features = {}
        if accept_language:
            features["lang"] = hashlib.md5(accept_language.encode()).hexdigest()[:8]
        if screen_resolution:
            features["screen"] = screen_resolution
        if timezone:
            features["tz"] = timezone
        
        return cls(
            user_agent_hash=ua_hash,
            client_features=features,
            ip_address=ip_address,
        )
    
    def to_token_claim(self) -> Dict[str, Any]:
        """转换为token claim"""
        return {
            "ua": self.user_agent_hash.hex(),
            "feat": self.client_features,
            # 不包含IP，因为可能变化
        }
    
    @classmethod
    def from_token_claim(cls, claim: Dict[str, Any]) -> "DeviceFingerprint":
        """从token claim恢复"""
        return cls(
            user_agent_hash=bytes.fromhex(claim.get("ua", "0" * 32)),
            client_features=claim.get("feat", {}),
        )
    
    def matches(self, other: "DeviceFingerprint", strict: bool = False) -> bool:
        """
        检查是否匹配
        
        Args:
            other: 待匹配的指纹
            strict: 是否严格匹配 (包含IP)
        """
        # User-Agent必须匹配
        if self.user_agent_hash != other.user_agent_hash:
            return False
        
        # 严格模式下IP必须匹配
        if strict and self.ip_address and other.ip_address:
            if self.ip_address != other.ip_address:
                return False
        
        # 客户端特征匹配 (至少50%匹配)
        if self.client_features and other.client_features:
            common_keys = set(self.client_features.keys()) & set(other.client_features.keys())
            if common_keys:
                matches = sum(
                    1 for k in common_keys
                    if self.client_features[k] == other.client_features[k]
                )
                if matches / len(common_keys) < 0.5:
                    return False
        
        return True


# ============================================================================
# Token对
# ============================================================================

@dataclass
class TokenPair:
    """访问token + 刷新token对"""
    access_token: str
    refresh_token: str
    token_type: TokenType
    expires_at: float
    refresh_expires_at: float
    scope: Tuple[TokenScope, ...]
    device_fingerprint: Optional[DeviceFingerprint] = None
    
    def is_access_expired(self) -> bool:
        """访问token是否过期"""
        return time.time() >= self.expires_at
    
    def is_refresh_expired(self) -> bool:
        """刷新token是否过期"""
        return time.time() >= self.refresh_expires_at
    
    def should_refresh(self, threshold: float = 0.2) -> bool:
        """是否应该刷新"""
        if self.is_access_expired() or self.is_refresh_expired():
            return False
        
        remaining = (self.expires_at - time.time()) / (self.expires_at - self.refresh_expires_at + self.expires_at)
        return remaining < threshold
    
    def to_response(self) -> Dict[str, Any]:
        """转换为API响应"""
        return {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "token_type": "bearer",
            "expires_in": int(self.expires_at - time.time()),
            "scope": " ".join(s.value for s in self.scope),
        }


# ============================================================================
# 分级Token管理器
# ============================================================================

class TieredTokenManager:
    """
    分级Token管理器
    
    核心特性:
    1. 控制面短token + 数据面长token
    2. 设备指纹绑定
    3. 无感自动刷新
    4. 刷新频率限制
    """
    
    def __init__(
        self,
        secret_key: bytes,
        config: Optional[TokenConfig] = None,
    ):
        self._secret_key = secret_key
        self._config = config or TokenConfig()
        
        # Token存储 (实际应使用Redis等)
        self._tokens: Dict[str, TokenPair] = {}
        
        # 刷新计数 (user_id -> [timestamps])
        self._refresh_history: Dict[str, list] = {}
        
        # 黑名单
        self._blacklist: set = set()
    
    def _encode_jwt(self, payload: Dict[str, Any]) -> str:
        """编码JWT"""
        if HAS_JWT:
            return jwt.encode(
                payload,
                self._secret_key,
                algorithm=self._config.algorithm,
            )
        else:
            # 简化token: base64(json) + signature
            import base64
            import json
            data = base64.urlsafe_b64encode(json.dumps(payload).encode())
            sig = hmac.new(self._secret_key, data, hashlib.sha256).hexdigest()[:16]
            return f"{data.decode()}.{sig}"
    
    def _decode_jwt(self, token: str) -> Optional[Dict[str, Any]]:
        """解码JWT"""
        try:
            if HAS_JWT:
                return jwt.decode(
                    token,
                    self._secret_key,
                    algorithms=[self._config.algorithm],
                )
            else:
                import base64
                import json
                data, sig = token.rsplit(".", 1)
                expected_sig = hmac.new(
                    self._secret_key,
                    data.encode(),
                    hashlib.sha256,
                ).hexdigest()[:16]
                if sig != expected_sig:
                    return None
                return json.loads(base64.urlsafe_b64decode(data))
        except Exception as e:
            logger.debug(f"Token解码失败: {e}")
            return None
    
    def _generate_token_id(self) -> str:
        """生成唯一token ID"""
        return secrets.token_urlsafe(32)
    
    def _check_refresh_limit(self, user_id: str) -> bool:
        """检查刷新频率限制"""
        now = time.time()
        history = self._refresh_history.get(user_id, [])
        
        # 清理过期记录
        history = [t for t in history if now - t < 3600]
        self._refresh_history[user_id] = history
        
        return len(history) < self._config.max_refresh_per_hour
    
    def _record_refresh(self, user_id: str):
        """记录刷新"""
        if user_id not in self._refresh_history:
            self._refresh_history[user_id] = []
        self._refresh_history[user_id].append(time.time())
    
    def create_control_tokens(
        self,
        user_id: str,
        device: DeviceFingerprint,
        scope: Tuple[TokenScope, ...] = (TokenScope.READ, TokenScope.WRITE),
    ) -> TokenPair:
        """
        创建控制面token对
        
        用于管理操作，短效
        """
        now = time.time()
        
        # 访问token
        access_id = self._generate_token_id()
        access_payload = {
            "jti": access_id,
            "sub": user_id,
            "iat": now,
            "exp": now + self._config.control_access_ttl,
            "iss": self._config.issuer,
            "type": "control_access",
            "scope": [s.value for s in scope],
            "device": device.to_token_claim() if self._config.device_binding_enabled else None,
        }
        access_token = self._encode_jwt(access_payload)
        
        # 刷新token
        refresh_id = self._generate_token_id()
        refresh_payload = {
            "jti": refresh_id,
            "sub": user_id,
            "iat": now,
            "exp": now + self._config.control_refresh_ttl,
            "iss": self._config.issuer,
            "type": "control_refresh",
            "access_jti": access_id,
        }
        refresh_token = self._encode_jwt(refresh_payload)
        
        pair = TokenPair(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type=TokenType.CONTROL_PLANE,
            expires_at=now + self._config.control_access_ttl,
            refresh_expires_at=now + self._config.control_refresh_ttl,
            scope=scope,
            device_fingerprint=device,
        )
        
        self._tokens[access_id] = pair
        logger.info(f"创建控制面token: user={user_id}, scope={[s.value for s in scope]}")
        
        return pair
    
    def create_data_tokens(
        self,
        user_id: str,
        device: DeviceFingerprint,
        scope: Tuple[TokenScope, ...] = (TokenScope.DATA,),
    ) -> TokenPair:
        """
        创建数据面token对
        
        用于实际数据传输，长效
        """
        now = time.time()
        
        # 访问token
        access_id = self._generate_token_id()
        access_payload = {
            "jti": access_id,
            "sub": user_id,
            "iat": now,
            "exp": now + self._config.data_access_ttl,
            "iss": self._config.issuer,
            "type": "data_access",
            "scope": [s.value for s in scope],
            "device": device.to_token_claim() if self._config.device_binding_enabled else None,
        }
        access_token = self._encode_jwt(access_payload)
        
        # 刷新token
        refresh_id = self._generate_token_id()
        refresh_payload = {
            "jti": refresh_id,
            "sub": user_id,
            "iat": now,
            "exp": now + self._config.data_refresh_ttl,
            "iss": self._config.issuer,
            "type": "data_refresh",
            "access_jti": access_id,
        }
        refresh_token = self._encode_jwt(refresh_payload)
        
        pair = TokenPair(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type=TokenType.DATA_PLANE,
            expires_at=now + self._config.data_access_ttl,
            refresh_expires_at=now + self._config.data_refresh_ttl,
            scope=scope,
            device_fingerprint=device,
        )
        
        self._tokens[access_id] = pair
        logger.info(f"创建数据面token: user={user_id}, 有效期={self._config.data_access_ttl/86400:.0f}天")
        
        return pair
    
    def validate_token(
        self,
        token: str,
        expected_scope: Optional[TokenScope] = None,
        device: Optional[DeviceFingerprint] = None,
    ) -> Tuple[bool, Optional[Dict[str, Any]], str]:
        """
        验证token
        
        Args:
            token: 待验证token
            expected_scope: 期望的权限范围
            device: 当前设备指纹
        
        Returns:
            (是否有效, payload, 错误信息)
        """
        # 检查黑名单
        if token in self._blacklist:
            return False, None, "Token已撤销"
        
        # 解码
        payload = self._decode_jwt(token)
        if payload is None:
            return False, None, "Token格式无效"
        
        # 检查过期
        if payload.get("exp", 0) < time.time():
            return False, payload, "Token已过期"
        
        # 检查权限
        if expected_scope:
            token_scopes = payload.get("scope", [])
            if expected_scope.value not in token_scopes:
                return False, payload, f"权限不足: 需要{expected_scope.value}"
        
        # 检查设备绑定
        if self._config.device_binding_enabled and device:
            device_claim = payload.get("device")
            if device_claim:
                token_device = DeviceFingerprint.from_token_claim(device_claim)
                if not token_device.matches(device):
                    return False, payload, "设备不匹配"
        
        return True, payload, ""
    
    def refresh_tokens(
        self,
        refresh_token: str,
        device: Optional[DeviceFingerprint] = None,
    ) -> Optional[TokenPair]:
        """
        刷新token对
        
        无感刷新: 用户无感知，后台自动执行
        """
        # 验证刷新token
        valid, payload, error = self.validate_token(refresh_token)
        if not valid:
            logger.warning(f"刷新token验证失败: {error}")
            return None
        
        # 检查token类型
        token_type = payload.get("type", "")
        if not token_type.endswith("_refresh"):
            logger.warning("非刷新token")
            return None
        
        user_id = payload.get("sub", "")
        
        # 检查刷新频率
        if not self._check_refresh_limit(user_id):
            logger.warning(f"刷新频率超限: user={user_id}")
            return None
        
        # 撤销旧token
        old_access_jti = payload.get("access_jti", "")
        if old_access_jti in self._tokens:
            del self._tokens[old_access_jti]
        self._blacklist.add(refresh_token)
        
        # 创建新token
        if token_type == "control_refresh":
            new_pair = self.create_control_tokens(
                user_id,
                device or DeviceFingerprint(b"\x00" * 16),
                scope=tuple(TokenScope(s) for s in payload.get("scope", ["read"])),
            )
        else:  # data_refresh
            new_pair = self.create_data_tokens(
                user_id,
                device or DeviceFingerprint(b"\x00" * 16),
                scope=tuple(TokenScope(s) for s in payload.get("scope", ["data"])),
            )
        
        # 记录刷新
        self._record_refresh(user_id)
        logger.info(f"Token刷新成功: user={user_id}, type={token_type}")
        
        return new_pair
    
    def revoke_token(self, token: str):
        """撤销token"""
        self._blacklist.add(token)
        
        payload = self._decode_jwt(token)
        if payload:
            jti = payload.get("jti", "")
            if jti in self._tokens:
                del self._tokens[jti]
        
        logger.info("Token已撤销")
    
    def auto_refresh_if_needed(
        self,
        access_token: str,
        refresh_token: str,
        device: Optional[DeviceFingerprint] = None,
    ) -> Optional[TokenPair]:
        """
        自动刷新检查
        
        如果access_token即将过期，自动刷新
        """
        payload = self._decode_jwt(access_token)
        if not payload:
            return None
        
        exp = payload.get("exp", 0)
        now = time.time()
        
        # 检查是否需要刷新
        ttl = exp - now
        original_ttl = exp - payload.get("iat", now)
        
        if ttl / original_ttl < self._config.auto_refresh_threshold:
            return self.refresh_tokens(refresh_token, device)
        
        return None


# ============================================================================
# FastAPI集成
# ============================================================================

def create_auth_dependency(manager: TieredTokenManager):
    """
    创建FastAPI认证依赖
    
    用法:
        @app.get("/protected")
        async def protected_route(user: dict = Depends(auth_dependency)):
            return {"user": user}
    """
    from fastapi import Depends, HTTPException, Request
    from fastapi.security import HTTPBearer
    
    security = HTTPBearer()
    
    async def auth_dependency(
        request: Request,
        credentials = Depends(security),
    ) -> Dict[str, Any]:
        token = credentials.credentials
        
        # 从请求生成设备指纹
        user_agent = request.headers.get("user-agent", "")
        ip = request.client.host if request.client else None
        device = DeviceFingerprint.from_request(user_agent, ip)
        
        valid, payload, error = manager.validate_token(token, device=device)
        
        if not valid:
            raise HTTPException(status_code=401, detail=error)
        
        return payload
    
    return auth_dependency
