"""
节点管理 API

安全说明:
- 节点注册/注销需要管理员权限
- 节点查询只需要普通权限
"""

import time
import asyncio
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from src.api.auth import APIKeyInfo, api_key_manager, require_api_key, require_admin
from src.api.schemas import NodeRegistrationRequest
from src.logging_config import get_logger

logger = get_logger(__name__)
node_router = APIRouter()

# 节点注册表 (内存存储)
_node_registry: Dict[str, Dict[str, Any]] = {}
_registry_lock = asyncio.Lock()  # 并发保护


@node_router.post("/register", response_model=Dict[str, Any])
async def register_node(
    node_data: NodeRegistrationRequest,
    auth: APIKeyInfo = Depends(require_admin),  # 修复: 需要管理员权限
) -> Dict[str, Any]:
    """
    注册新节点
    
    安全说明:
    - 此接口需要管理员权限
    - 防止未授权用户注册恶意节点
    """
    async with _registry_lock:
        if node_data.node_id in _node_registry:
            raise HTTPException(
                status_code=409,
                detail={"error": {"code": "NODE_EXISTS", "message": f"Node {node_data.node_id} already registered"}}
            )

        _node_registry[node_data.node_id] = {
            **node_data.dict(),
            "status": "online",
            "registered_by": auth.name,
            "registered_at": time.time(),
        }

    logger.info("node_registered", node_id=node_data.node_id[:16] + "...", role=node_data.role)
    return {"status": "registered", "node_id": node_data.node_id}


@node_router.delete("/{node_id}", response_model=Dict[str, Any])
async def deregister_node(
    node_id: str,
    auth: APIKeyInfo = Depends(require_admin),  # 修复: 需要管理员权限
) -> Dict[str, Any]:
    """
    注销节点
    
    安全说明:
    - 此接口需要管理员权限
    - 防止未授权用户注销合法节点
    """
    # 输入验证: node_id 格式
    if not node_id or len(node_id) > 128:
        raise HTTPException(
            status_code=400,
            detail={"error": {"code": "INVALID_NODE_ID", "message": "Invalid node_id format"}}
        )
    
    async with _registry_lock:
        if node_id not in _node_registry:
            raise HTTPException(
                status_code=404,
                detail={"error": {"code": "NODE_NOT_FOUND", "message": f"Node {node_id} not found"}}
            )

        del _node_registry[node_id]
    
    logger.info("node_deregistered", node_id=node_id[:16] + "...", admin=auth.name)
    return {"status": "deregistered", "node_id": node_id}


@node_router.get("/{node_id}", response_model=Dict[str, Any])
async def get_node(
    node_id: str,
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """查询节点信息"""
    if node_id not in _node_registry:
        raise HTTPException(
            status_code=404,
            detail={"error": {"code": "NODE_NOT_FOUND", "message": f"Node {node_id} not found"}}
        )
    return _node_registry[node_id]


@node_router.get("/", response_model=Dict[str, Any])
async def list_nodes(
    role: Optional[str] = Query(None, description="按角色过滤"),
    status_filter: Optional[str] = Query(None, alias="status", description="按状态过滤"),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """列出所有节点"""
    nodes = list(_node_registry.values())
    if role:
        nodes = [n for n in nodes if n.get("role") == role]
    if status_filter:
        nodes = [n for n in nodes if n.get("status") == status_filter]

    return {
        "total": len(nodes),
        "limit": limit,
        "offset": offset,
        "nodes": nodes[offset:offset + limit],
    }


@node_router.get("/stats/summary", response_model=Dict[str, Any])
async def node_stats(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """节点统计摘要"""
    nodes = list(_node_registry.values())
    roles: Dict[str, int] = {}
    for n in nodes:
        r = n.get("role", "unknown")
        roles[r] = roles.get(r, 0) + 1

    return {
        "total_nodes": len(nodes),
        "by_role": roles,
        "online": sum(1 for n in nodes if n.get("status") == "online"),
        "offline": sum(1 for n in nodes if n.get("status") == "offline"),
    }
