"""
安全 API

- 攻击检测
- 噪声注入
- TLS 指纹生成
- 协议混淆
- XDP 拦截控制 (新增)
- 全网免疫管理 (新增)
"""

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException

from src.api.auth import APIKeyInfo, require_api_key
from src.client.fingerprint import FingerprintRandomizer
from src.crypto.tls_fingerprint import TLSFingerprintGenerator
from src.logging_config import get_logger
from src.security.attack_detector import AttackDetector, SecureAttackDetector
from src.security.noise_injector import NoiseInjector
from src.security import XDP_AVAILABLE, IMMUNE_SYNC_AVAILABLE

logger = get_logger(__name__)
security_router = APIRouter()

# 全局防御系统引用 (由 main.py 注入)
_defense_system: Optional[Any] = None


def set_defense_system(ds: Any) -> None:
    """设置全局防御系统实例"""
    global _defense_system
    _defense_system = ds


@security_router.get("/attack-detector/stats", response_model=Dict[str, Any])
async def attack_detector_stats(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """获取攻击检测统计"""
    detector = AttackDetector()
    return detector.get_stats()


@security_router.post("/noise/generate", response_model=Dict[str, Any])
async def generate_noise(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    生成噪声包

    - **noise_type**: 噪声类型 (flow_aligned/random)
    - **size**: 包大小 (可选)
    """
    noise_type = request_data.get("noise_type", "flow_aligned")
    injector = NoiseInjector()

    if noise_type == "flow_aligned":
        noise = injector.generate_flow_aligned_noise()
    else:
        noise = injector.generate_noise()

    return {
        "noise_type": noise_type,
        "size": len(noise),
        "noise_hex": noise.hex()[:64] + "...",
    }


@security_router.post("/tls-fingerprint/generate", response_model=Dict[str, Any])
async def generate_tls_fingerprint(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    生成 TLS 指纹

    - **pqc**: 是否包含后量子密钥交换 (默认true)
    """
    pqc = request_data.get("pqc", True)
    generator = TLSFingerprintGenerator()

    if pqc:
        fp = generator.generate_pqc_fingerprint()
    else:
        fp = generator.generate(randomize=True)

    return {
        "ja3_hash": fp.ja3_hash,
        "ja4_hash": fp.ja4_hash,
        "cipher_suites_count": len(fp.cipher_suites),
        "extensions_count": len(fp.extensions),
        "tls_version": fp.tls_version,
        "pqc_enabled": pqc,
    }


@security_router.post("/fingerprint/drift", response_model=Dict[str, Any])
async def drift_fingerprint(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    触发全特征漂移

    每10秒刷新所有指纹特征。
    """
    randomizer = FingerprintRandomizer()
    profile = randomizer.drift_all_features()
    entropy = randomizer.get_entropy_score()

    return {
        "packet_size_mean": profile.packet_size_mean,
        "packet_size_std": profile.packet_size_std,
        "timing_mean_ms": profile.timing_mean_ms,
        "entropy_score": round(entropy, 4),
        "drift_interval_seconds": 10,
    }


# ============================================================
# XDP 拦截控制 API (新增)
# ============================================================

@security_router.get("/xdp/status", response_model=Dict[str, Any])
async def xdp_status(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """获取 XDP 拦截引擎状态"""
    if not XDP_AVAILABLE:
        raise HTTPException(status_code=503, detail="XDP 引擎不可用 (bcc 未安装)")

    if _defense_system is None:
        return {"enabled": False, "loaded": False}

    return {
        "enabled": _defense_system._config.xdp_enabled,
        "loaded": _defense_system._xdp.is_loaded if _defense_system._xdp else False,
        "mode": _defense_system._config.xdp_mode.name,
        "interface": _defense_system._config.xdp_interface,
    }


@security_router.post("/xdp/mode", response_model=Dict[str, Any])
async def set_xdp_mode(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    设置 XDP 运行模式

    - **mode**: 模式 (PASS/LEARN/ENFORCE)
    """
    if not XDP_AVAILABLE:
        raise HTTPException(status_code=503, detail="XDP 引擎不可用")

    mode_str = request_data.get("mode", "LEARN").upper()
    from src.xdp_engine.xdp_controller import XDPMode

    try:
        mode = XDPMode[mode_str]
    except KeyError:
        raise HTTPException(status_code=400, detail=f"无效模式: {mode_str}")

    if _defense_system:
        _defense_system.set_xdp_mode(mode)

    return {"mode": mode.name, "success": True}


@security_router.get("/xdp/banned-ips", response_model=List[Dict[str, Any]])
async def get_banned_ips(
    auth: APIKeyInfo = Depends(require_api_key),
) -> List[Dict[str, Any]]:
    """获取被封禁的 IP 列表"""
    if not XDP_AVAILABLE or _defense_system is None:
        return []

    banned = _defense_system.get_banned_ips()
    return [
        {"ip": ip, "expires_at": expiry if expiry > 0 else None}
        for ip, expiry in banned
    ]


@security_router.post("/xdp/ban", response_model=Dict[str, Any])
async def ban_ip(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    手动封禁 IP

    - **ip**: IP 地址
    - **duration**: 封禁时长(秒), 0=永久
    """
    if not XDP_AVAILABLE:
        raise HTTPException(status_code=503, detail="XDP 引擎不可用")

    ip = request_data.get("ip")
    duration = request_data.get("duration", 3600)

    if not ip:
        raise HTTPException(status_code=400, detail="缺少 ip 参数")

    if _defense_system:
        success = _defense_system.ban_ip(ip, duration)
        return {"ip": ip, "duration": duration, "success": success}

    return {"success": False}


@security_router.post("/xdp/unban", response_model=Dict[str, Any])
async def unban_ip(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    手动解封 IP

    - **ip**: IP 地址
    """
    if not XDP_AVAILABLE:
        raise HTTPException(status_code=503, detail="XDP 引擎不可用")

    ip = request_data.get("ip")
    if not ip:
        raise HTTPException(status_code=400, detail="缺少 ip 参数")

    if _defense_system:
        success = _defense_system.unban_ip(ip)
        return {"ip": ip, "success": success}

    return {"success": False}


@security_router.get("/xdp/stats", response_model=Dict[str, Any])
async def xdp_stats(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """获取 XDP 统计信息"""
    if not XDP_AVAILABLE or _defense_system is None or _defense_system._xdp is None:
        return {"available": False}

    stats = _defense_system._xdp.get_stats()
    return {
        "available": True,
        "total_packets": stats.total_packets,
        "dropped_packets": stats.dropped_packets,
        "banned_ip_drops": stats.banned_ip_drops,
        "flood_drops": stats.flood_drops,
        "tagging_drops": stats.tagging_drops,
        "replay_drops": stats.replay_drops,
        "pass_packets": stats.pass_packets,
    }


# ============================================================
# 全网免疫 API (新增)
# ============================================================

@security_router.get("/immunity/status", response_model=Dict[str, Any])
async def immunity_status(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """获取全网免疫状态"""
    if not IMMUNE_SYNC_AVAILABLE:
        raise HTTPException(status_code=503, detail="免疫同步模块不可用")

    if _defense_system is None:
        return {"enabled": False}

    return {
        "enabled": _defense_system._config.immunity_enabled,
        "auto_block_threshold": _defense_system._config.auto_block_threshold,
    }


@security_router.get("/immunity/stats", response_model=Dict[str, Any])
async def immunity_stats(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """获取免疫统计信息"""
    if not IMMUNE_SYNC_AVAILABLE or _defense_system is None:
        return {"available": False}

    return _defense_system.get_stats().get("immunity", {})


@security_router.post("/immunity/sync", response_model=Dict[str, Any])
async def trigger_immunity_sync(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """手动触发全网免疫同步"""
    if not IMMUNE_SYNC_AVAILABLE:
        raise HTTPException(status_code=503, detail="免疫同步模块不可用")

    if _defense_system is None:
        raise HTTPException(status_code=503, detail="防御系统未初始化")

    import asyncio
    count = asyncio.create_task(_defense_system.full_sync())

    return {"sync_triggered": True}


@security_router.get("/immunity/check/{ip}", response_model=Dict[str, Any])
async def check_immunity(
    ip: str,
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """检查是否对指定 IP 免疫"""
    if not IMMUNE_SYNC_AVAILABLE or _defense_system is None:
        return {"ip": ip, "immune": False, "available": False}

    is_immune = _defense_system.is_immune_to(ip)
    return {"ip": ip, "immune": is_immune, "available": True}


# ============================================================
# 统一防御系统 API (新增)
# ============================================================

@security_router.get("/defense/status", response_model=Dict[str, Any])
async def defense_system_status(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """获取统一防御系统状态"""
    if _defense_system is None:
        return {"initialized": False, "running": False}

    return _defense_system.get_stats()
