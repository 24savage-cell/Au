"""
路由管理 API

- 路径构建
- 路径查询
- 洋葱路由
- 出口聚合

安全说明:
- 所有端点需要认证
- 输入参数有严格的大小和格式限制
- 不暴露内部异常细节
"""

from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException

from src.api.auth import APIKeyInfo, require_api_key
from src.logging_config import get_logger
from src.routing.exit_aggregator import ExitAggregator
from src.routing.onion_router import OnionRouter

logger = get_logger(__name__)
routing_router = APIRouter()

# 安全常量
MIN_HOP_COUNT = 3
MAX_HOP_COUNT = 10
MAX_PLAINTEXT_SIZE = 1024 * 1024  # 1MB
MAX_PATH_NODES = 20
MAX_SECRET_SIZE = 64 * 1024  # 64KB
MAX_SHARDS = 100


@routing_router.post("/path/build", response_model=Dict[str, Any])
async def build_path(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    构建匿名路径

    - **hop_count**: 跳数 (3-10, 默认6)
    - **include_decoys**: 是否包含诱饵路径 (默认true)
    """
    hop_count = request_data.get("hop_count", 6)
    include_decoys = request_data.get("include_decoys", True)

    # 输入验证: hop_count
    if not isinstance(hop_count, int):
        raise HTTPException(status_code=400, detail="hop_count must be an integer")
    if hop_count < MIN_HOP_COUNT or hop_count > MAX_HOP_COUNT:
        raise HTTPException(
            status_code=400,
            detail=f"hop_count must be between {MIN_HOP_COUNT} and {MAX_HOP_COUNT}"
        )

    router = OnionRouter()
    path_id = router.build_path(hop_count=hop_count, include_decoys=include_decoys)

    logger.info("path_built", hop_count=hop_count, include_decoys=include_decoys)

    return {
        "path_id": path_id,
        "hop_count": hop_count,
        "include_decoys": include_decoys,
        "status": "built",
    }


@routing_router.post("/onion/wrap", response_model=Dict[str, Any])
async def onion_wrap(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    洋葱封装数据

    使用 PQC+经典混合加密。
    
    安全说明:
    - plaintext 最大 1MB
    - path_nodes 最多 20 个节点
    """
    plaintext = request_data.get("plaintext", "")
    path_nodes = request_data.get("path_nodes", [])

    # 输入验证: plaintext
    if isinstance(plaintext, str):
        plaintext = plaintext.encode()
    if len(plaintext) > MAX_PLAINTEXT_SIZE:
        raise HTTPException(
            status_code=413,
            detail=f"Plaintext too large: {len(plaintext)} > {MAX_PLAINTEXT_SIZE} bytes"
        )

    # 输入验证: path_nodes
    if not isinstance(path_nodes, list):
        raise HTTPException(status_code=400, detail="path_nodes must be a list")
    if not path_nodes:
        raise HTTPException(status_code=400, detail="path_nodes is required")
    if len(path_nodes) > MAX_PATH_NODES:
        raise HTTPException(
            status_code=400,
            detail=f"Too many path_nodes: {len(path_nodes)} > {MAX_PATH_NODES}"
        )
    
    # 验证每个节点格式
    for i, node in enumerate(path_nodes):
        if not isinstance(node, (str, dict)):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid node format at index {i}"
            )

    try:
        router = OnionRouter()
        wrapped = router.wrap_hybrid(plaintext, path_nodes)

        return {
            "wrapped_size": len(wrapped),
            "wrapped_data": wrapped.hex()[:64] + "...",
            "hop_count": len(path_nodes),
            "encryption": "hybrid-aes-chacha20",
        }
    except Exception as e:
        logger.error("onion_wrap_error", error_type=type(e).__name__)
        raise HTTPException(status_code=500, detail="Onion wrap failed")


@routing_router.post("/exit/shamir-split", response_model=Dict[str, Any])
async def shamir_split(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    Shamir 秘密共享分片

    - **secret**: 秘密数据 (hex)
    - **threshold**: 重建阈值 (默认3)
    - **num_shares**: 总分片数 (默认5)
    
    安全说明:
    - secret 最大 64KB
    - threshold 和 num_shares 范围 2-100
    """
    secret_hex = request_data.get("secret", "")
    threshold = request_data.get("threshold", 3)
    num_shares = request_data.get("num_shares", 5)

    # 输入验证: secret
    if not secret_hex:
        raise HTTPException(status_code=400, detail="secret is required")
    try:
        secret = bytes.fromhex(secret_hex) if isinstance(secret_hex, str) else secret_hex
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid secret format: expected hex string")
    
    if len(secret) > MAX_SECRET_SIZE:
        raise HTTPException(
            status_code=413,
            detail=f"Secret too large: {len(secret)} > {MAX_SECRET_SIZE} bytes"
        )

    # 输入验证: threshold 和 num_shares
    if not isinstance(threshold, int) or threshold < 2:
        raise HTTPException(status_code=400, detail="threshold must be an integer >= 2")
    if not isinstance(num_shares, int) or num_shares < 2:
        raise HTTPException(status_code=400, detail="num_shares must be an integer >= 2")
    if threshold > num_shares:
        raise HTTPException(status_code=400, detail="threshold cannot exceed num_shares")
    if num_shares > MAX_SHARDS:
        raise HTTPException(status_code=400, detail=f"num_shares cannot exceed {MAX_SHARDS}")

    try:
        aggregator = ExitAggregator()
        shards = aggregator.shamir_split(secret, threshold=threshold, num_shares=num_shares)

        return {
            "threshold": threshold,
            "num_shares": num_shares,
            "shard_ids": [s.shard_id for s in shards],
            "shard_sizes": [len(s.data) for s in shards],
            "status": "split",
        }
    except Exception as e:
        logger.error("shamir_split_error", error_type=type(e).__name__)
        raise HTTPException(status_code=500, detail="Shamir split failed")


@routing_router.post("/exit/shamir-reassemble", response_model=Dict[str, Any])
async def shamir_reassemble(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    Shamir 秘密重建
    
    安全说明:
    - shards 列表最多 100 个
    - 每个分片数据最大 128KB
    """
    threshold = request_data.get("threshold", 3)
    shards_data = request_data.get("shards", [])

    # 输入验证: threshold
    if not isinstance(threshold, int) or threshold < 2:
        raise HTTPException(status_code=400, detail="threshold must be an integer >= 2")

    # 输入验证: shards
    if not isinstance(shards_data, list):
        raise HTTPException(status_code=400, detail="shards must be a list")
    if not shards_data:
        raise HTTPException(status_code=400, detail="shards is required")
    if len(shards_data) > MAX_SHARDS:
        raise HTTPException(
            status_code=400,
            detail=f"Too many shards: {len(shards_data)} > {MAX_SHARDS}"
        )

    from src.routing.exit_aggregator import Shard
    shards = []
    for i, s in enumerate(shards_data):
        if not isinstance(s, dict):
            raise HTTPException(status_code=400, detail=f"Invalid shard format at index {i}")
        try:
            shard_data = bytes.fromhex(s.get("data", ""))
        except (ValueError, AttributeError):
            raise HTTPException(status_code=400, detail=f"Invalid shard data at index {i}")
        
        if len(shard_data) > 128 * 1024:
            raise HTTPException(status_code=413, detail=f"Shard {i} too large")
        
        shards.append(Shard(
            shard_id=s.get("shard_id", f"shard_{i}"),
            data=shard_data,
            total_shards=s.get("total_shares", len(shards_data)),
            parity_shards=0
        ))

    aggregator = ExitAggregator()
    try:
        secret = aggregator.shamir_reassemble(shards, threshold=threshold)
        return {
            "secret": secret.hex(),
            "secret_length": len(secret),
            "shards_used": len(shards),
            "status": "reassembled",
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Reassembly failed: insufficient or invalid shards")
    except Exception as e:
        logger.error("shamir_reassemble_error", error_type=type(e).__name__)
        raise HTTPException(status_code=500, detail="Shamir reassembly failed")
