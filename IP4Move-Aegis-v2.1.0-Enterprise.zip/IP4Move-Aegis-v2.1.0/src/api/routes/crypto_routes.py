"""
加密操作 API

- 密钥生成
- 加密/解密
- 签名/验证
- 哈希计算
- PQC 操作

安全说明:
- 密钥对生成仅返回公钥，私钥不通过API返回
- 会话密钥不通过API返回，仅返回用于密钥交换的公钥
- 所有敏感操作需要管理员权限
"""

from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException

from src.api.auth import APIKeyInfo, require_api_key, require_admin
from src.crypto.hashing import BLAKE3Hash, SHA3_512Hash, create_hash_engine
from src.crypto.key_exchange import KyberKeyExchange, X25519KeyExchange
from src.crypto.symmetric import ASCON128aCipher, AES256GCMCipher, create_cipher
from src.logging_config import get_logger

logger = get_logger(__name__)
crypto_router = APIRouter()


@crypto_router.post("/keypair/generate", response_model=Dict[str, Any])
async def generate_keypair(
    algorithm: str = "x25519",
    auth: APIKeyInfo = Depends(require_admin),  # 修复: 需要管理员权限
) -> Dict[str, Any]:
    """
    生成密钥对

    支持算法: x25519, kyber-768
    
    安全说明:
    - 此接口需要管理员权限
    - 仅返回公钥，私钥不通过API返回
    - 私钥应通过安全通道（如HSM、密钥管理系统）分发
    """
    if algorithm == "kyber-768":
        ke = KyberKeyExchange()
        private_key, public_key = ke.generate_keypair()
    elif algorithm == "x25519":
        ke = X25519KeyExchange()
        private_key, public_key = ke.generate_keypair()
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported algorithm: {algorithm}")

    # 安全修复: 不返回私钥
    # 私钥应通过安全通道分发，不应通过API传输
    logger.warning(
        "keypair_generated",
        algorithm=algorithm,
        public_key_prefix=public_key.hex()[:16] + "...",
        admin=auth.name,
    )
    
    return {
        "algorithm": algorithm,
        "public_key": public_key.hex(),
        "private_key_ref": "[SECURE] Private key generated but not returned via API. Use secure key management system.",
    }


@crypto_router.post("/encrypt", response_model=Dict[str, Any])
async def encrypt_data(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    加密数据

    支持算法: aes-256-gcm, chacha20-poly1305, ascon-128a
    
    安全说明:
    - plaintext 最大 1MB
    - key 必须是有效的 hex 编码密钥
    """
    algorithm = request_data.get("algorithm", "aes-256-gcm")
    plaintext = request_data.get("plaintext", "")
    key = request_data.get("key", "")

    # 输入验证
    if isinstance(plaintext, str):
        plaintext = plaintext.encode()
    
    # 大小限制 (1MB)
    MAX_PLAINTEXT_SIZE = 1024 * 1024
    if len(plaintext) > MAX_PLAINTEXT_SIZE:
        raise HTTPException(
            status_code=413,
            detail=f"Plaintext too large: {len(plaintext)} > {MAX_PLAINTEXT_SIZE} bytes"
        )
    
    # 密钥格式验证
    if isinstance(key, str):
        try:
            key = bytes.fromhex(key)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid key format: expected hex string")

    try:
        cipher = create_cipher(algorithm, key)
        ciphertext = cipher.encrypt(plaintext)
        return {
            "algorithm": algorithm,
            "ciphertext": ciphertext.hex(),
            "plaintext_length": len(plaintext),
            "ciphertext_length": len(ciphertext),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Encryption error: {str(e)}")
    except Exception as e:
        # 不暴露内部异常细节
        logger.error("encryption_error", error_type=type(e).__name__)
        raise HTTPException(status_code=500, detail="Encryption failed")


@crypto_router.post("/decrypt", response_model=Dict[str, Any])
async def decrypt_data(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    解密数据
    
    安全说明:
    - ciphertext 最大 2MB
    - key 必须是有效的 hex 编码密钥
    """
    algorithm = request_data.get("algorithm", "aes-256-gcm")
    ciphertext = request_data.get("ciphertext", "")
    key = request_data.get("key", "")

    # 输入验证
    if isinstance(ciphertext, str):
        try:
            ciphertext = bytes.fromhex(ciphertext)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid ciphertext format: expected hex string")
    
    # 大小限制 (2MB)
    MAX_CIPHERTEXT_SIZE = 2 * 1024 * 1024
    if len(ciphertext) > MAX_CIPHERTEXT_SIZE:
        raise HTTPException(
            status_code=413,
            detail=f"Ciphertext too large: {len(ciphertext)} > {MAX_CIPHERTEXT_SIZE} bytes"
        )
    
    if isinstance(key, str):
        try:
            key = bytes.fromhex(key)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid key format: expected hex string")

    try:
        cipher = create_cipher(algorithm, key)
        plaintext = cipher.decrypt(ciphertext)
        return {
            "algorithm": algorithm,
            "plaintext": plaintext.hex(),
            "plaintext_length": len(plaintext),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Decryption error: {str(e)}")
    except Exception as e:
        logger.error("decryption_error", error_type=type(e).__name__)
        raise HTTPException(status_code=500, detail="Decryption failed")


@crypto_router.post("/hash", response_model=Dict[str, Any])
async def hash_data(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    计算哈希

    支持算法: blake3, sha3-512, sha-256
    """
    algorithm = request_data.get("algorithm", "blake3")
    data = request_data.get("data", "")

    if isinstance(data, str):
        data = data.encode()

    engine = create_hash_engine(algorithm)
    digest = engine.hash(data)
    return {
        "algorithm": algorithm,
        "digest": digest.hex(),
        "digest_length": len(digest),
    }


@crypto_router.post("/key-exchange/hybrid", response_model=Dict[str, Any])
async def hybrid_key_exchange(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_admin),  # 修复: 需要管理员权限
) -> Dict[str, Any]:
    """
    混合密钥交换 (Kyber + X25519)

    同时使用后量子和经典密钥交换。
    
    安全说明:
    - 此接口需要管理员权限
    - 会话密钥不通过API返回，仅返回用于密钥交换的公钥/密文
    - 调用方应使用返回的公钥在本地完成密钥派生
    """
    peer_public_key = request_data.get("peer_public_key", "")
    if isinstance(peer_public_key, str):
        try:
            peer_public_key = bytes.fromhex(peer_public_key)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid peer_public_key format: expected hex string")
    
    # 公钥大小验证
    if len(peer_public_key) not in (32, 1088, 1184):  # X25519 或 Kyber 公钥大小
        raise HTTPException(
            status_code=400,
            detail=f"Invalid peer_public_key size: {len(peer_public_key)} bytes"
        )

    ke = KyberKeyExchange()
    public_key, session_key, combined = ke.hybrid_handshake(peer_public_key)

    # 安全修复: 不返回会话密钥
    # 会话密钥应仅存在于通信双方内存中，不应通过API传输
    logger.warning(
        "hybrid_key_exchange_completed",
        public_key_prefix=public_key.hex()[:16] + "...",
        admin=auth.name,
    )
    
    return {
        "algorithm": "kyber-768+x25519",
        "public_key": public_key.hex(),
        "session_key_ref": "[SECURE] Session key derived but not returned via API. Use local key derivation.",
        "public_key_length": len(public_key),
    }
