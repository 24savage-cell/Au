"""
DHT API

- 节点发现
- 路由表查询
- PQC 身份管理
"""

from typing import Any, Dict

from fastapi import APIRouter, Depends

from src.api.auth import APIKeyInfo, require_api_key
from src.dht.dht_node import DHTNode
from src.logging_config import get_logger

logger = get_logger(__name__)
dht_router = APIRouter()


@dht_router.post("/identity/generate", response_model=Dict[str, Any])
async def generate_pqc_identity(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    生成后量子身份密钥对

    使用 CRYSTALS-Dilithium-768 (ML-DSA-65)。
    """
    node = DHTNode()
    signing_key, verify_key = node.generate_pqc_identity()

    return {
        "signing_key": signing_key.hex(),
        "verify_key": verify_key.hex(),
        "algorithm": "ml-dsa-65",
        "signing_key_length": len(signing_key),
        "verify_key_length": len(verify_key),
    }


@dht_router.get("/routing-table", response_model=Dict[str, Any])
async def get_routing_table(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """获取 DHT 路由表"""
    node = DHTNode()
    stats = node.get_stats()
    return {
        "node_id": stats.get("node_id", "unknown"),
        "routing_table_size": stats.get("routing_table_size", 0),
        "known_nodes": stats.get("known_nodes", 0),
        "buckets_active": stats.get("buckets_active", 0),
    }
