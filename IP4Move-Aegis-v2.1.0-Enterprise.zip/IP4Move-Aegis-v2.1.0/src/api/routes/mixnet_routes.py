"""
Mixnet API

- Mix 节点状态
- 延迟队列信息
- 批量转发统计

安全说明:
- 所有端点需要认证
- 输入参数有严格的大小和格式限制
"""

from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException

from src.api.auth import APIKeyInfo, require_api_key
from src.logging_config import get_logger
from src.mixnet.batch_forwarder import BatchForwarder
from src.mixnet.mix_node import MixNode

logger = get_logger(__name__)
mixnet_router = APIRouter()

# 安全常量
MAX_MESSAGES_PER_BATCH = 1000
MAX_MESSAGE_SIZE = 64 * 1024  # 64KB per message
MIN_BATCH_SIZE = 1
MAX_BATCH_SIZE = 100


@mixnet_router.get("/status", response_model=Dict[str, Any])
async def mixnet_status(
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """获取 Mixnet 状态"""
    node = MixNode()
    stats = node.stats
    return {
        "node_id": stats.get("node_id", "unknown"),
        "messages_received": stats.get("messages_received", 0),
        "messages_forwarded": stats.get("messages_forwarded", 0),
        "messages_dropped": stats.get("messages_dropped", 0),
        "queue_size": stats.get("queue_size", 0),
        "delay_entropy": node.get_delay_entropy(),
    }


@mixnet_router.post("/batch/forward", response_model=Dict[str, Any])
async def batch_forward(
    request_data: Dict[str, Any],
    auth: APIKeyInfo = Depends(require_api_key),
) -> Dict[str, Any]:
    """
    批量转发消息

    - **messages**: 消息列表 (最多1000条)
    - **batch_size**: 批量大小 (1-100, 默认10)
    
    安全说明:
    - 消息列表最大1000条
    - 每条消息最大64KB
    - 批量大小范围1-100
    """
    messages = request_data.get("messages", [])
    batch_size = request_data.get("batch_size", 10)

    # 输入验证: messages
    if not isinstance(messages, list):
        raise HTTPException(status_code=400, detail="messages must be a list")
    
    if len(messages) > MAX_MESSAGES_PER_BATCH:
        raise HTTPException(
            status_code=413,
            detail=f"Too many messages: {len(messages)} > {MAX_MESSAGES_PER_BATCH}"
        )
    
    # 验证每条消息的大小
    for i, msg in enumerate(messages):
        if not isinstance(msg, (str, bytes, dict)):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid message type at index {i}: expected str, bytes, or dict"
            )
        msg_size = len(msg) if isinstance(msg, (str, bytes)) else len(str(msg))
        if msg_size > MAX_MESSAGE_SIZE:
            raise HTTPException(
                status_code=413,
                detail=f"Message at index {i} too large: {msg_size} > {MAX_MESSAGE_SIZE} bytes"
            )

    # 输入验证: batch_size
    if not isinstance(batch_size, int):
        raise HTTPException(status_code=400, detail="batch_size must be an integer")
    
    if batch_size < MIN_BATCH_SIZE or batch_size > MAX_BATCH_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"batch_size must be between {MIN_BATCH_SIZE} and {MAX_BATCH_SIZE}"
        )

    forwarder = BatchForwarder(batch_size=batch_size)
    for msg in messages:
        await forwarder.add(msg)

    logger.info(
        "batch_forward_queued",
        message_count=len(messages),
        batch_size=batch_size,
        admin=auth.name,
    )

    return {
        "queued": len(messages),
        "batch_size": batch_size,
        "status": "queued",
    }
