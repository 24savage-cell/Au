"""
IP.4/Move-Aegis REST API

生产级 API 服务层:
- FastAPI 应用
- API 密钥认证
- 速率限制
- 请求ID追踪
- 错误处理
"""

from src.api.server import create_app

__all__ = ["create_app"]
