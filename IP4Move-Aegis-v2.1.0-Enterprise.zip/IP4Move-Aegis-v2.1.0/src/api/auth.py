"""
IP.4/Move-Aegis API 认证 (安全修复版 v2)

修复内容:
- CRITICAL-003: 生产环境强制设置主密钥
- HIGH-002: 移除URL查询参数传递API密钥
- MEDIUM-003: 日志脱敏
- MEDIUM-010: 密钥策略验证
- F-001: 添加JWT令牌支持（含过期验证）
- F-003: API密钥安全存储（仅存储哈希）
- S-001: 速率限制增强
- S-003: 会话管理安全
- H-006: 添加验证码支持接口
- L-003: 密钥轮换机制
"""

import hashlib
import hmac
import os
import secrets
import time
import base64
import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from fastapi import HTTPException, Request, status
from fastapi.security import APIKeyHeader

# 仅使用Header认证，移除Query参数
API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)

# 安全配置常量
MIN_KEY_ENTROPY_BITS = 128
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_DURATION = 300
MIN_MASTER_SECRET_LENGTH = 32
MAX_API_KEYS_PER_USER = 100
KEY_ROTATION_INTERVAL = 86400 * 30  # 30天
MAX_SESSION_DURATION = 3600  # 1小时

logger = logging.getLogger(__name__)


def _is_production() -> bool:
    """检测是否为生产环境"""
    return os.environ.get("IP4MOVE_ENV", "development").lower() in (
        "production", "prod", "live"
    )


def _validate_master_secret() -> bytes:
    """
    验证并获取主密钥
    生产环境: 强制要求设置 AEGIS_MASTER_SECRET
    开发环境: 允许使用默认密钥但发出警告
    """
    env_secret = os.environ.get("AEGIS_MASTER_SECRET")

    if not env_secret:
        if _is_production():
            raise RuntimeError(
                "CRITICAL: AEGIS_MASTER_SECRET environment variable must be set in production! "
                "Generate a secure key with: openssl rand -hex 32"
            )
        else:
            logger.warning(
                "WARNING: Using development default master secret. "
                "Set AEGIS_MASTER_SECRET for production!"
            )
            env_secret = "dev-secret-key-do-not-use-in-production-32ch"

    if len(env_secret) < MIN_MASTER_SECRET_LENGTH:
        raise ValueError(
            f"AEGIS_MASTER_SECRET must be at least {MIN_MASTER_SECRET_LENGTH} characters, "
            f"got {len(env_secret)}"
        )

    return hashlib.sha256(env_secret.encode()).digest()


def _sanitize_log(msg: str) -> str:
    """日志脱敏：移除可能的密钥/密码/令牌"""
    import re
    # 移除hex格式的密钥（32字节=64hex字符）
    msg = re.sub(r'\b[0-9a-fA-F]{64}\b', '[REDACTED_KEY]', msg)
    # 移除base64格式的密钥
    msg = re.sub(r'[A-Za-z0-9+/]{40,}={0,2}', '[REDACTED_TOKEN]', msg)
    return msg


@dataclass
class APIKeyInfo:
    """API 密钥信息"""
    key_hash: str
    name: str
    roles: Set[str] = field(default_factory=lambda: {"read"})
    rate_limit: int = 1000
    created_at: float = field(default_factory=time.time)
    is_active: bool = True
    last_used: float = 0.0
    request_count: int = 0
    failed_attempts: int = 0
    locked_until: float = 0.0
    last_rotation: float = field(default_factory=time.time)


@dataclass
class SessionInfo:
    """会话信息"""
    session_id: str
    key_hash: str
    created_at: float = field(default_factory=time.time)
    last_activity: float = field(default_factory=time.time)
    expires_at: float = 0.0
    ip_address: str = ""
    user_agent: str = ""


class SecureAPIKeyManager:
    """安全API密钥管理器"""

    def __init__(self) -> None:
        # 强制验证主密钥
        self._secret = _validate_master_secret()
        self._keys: Dict[str, APIKeyInfo] = {}
        self._rate_limit_windows: Dict[str, List[float]] = defaultdict(list)
        self._failed_attempts: Dict[str, List[float]] = defaultdict(list)
        self._sessions: Dict[str, SessionInfo] = {}
        self._max_sessions_per_key = 5

    def _hash_key(self, key: str) -> str:
        """安全哈希API密钥"""
        return hmac.new(self._secret, key.encode(), hashlib.sha256).hexdigest()

    def _check_key_entropy(self, key: str) -> bool:
        """检查密钥熵值"""
        if len(key) < 32:
            return False
        import math
        entropy = 0
        for i in range(256):
            p = key.count(chr(i)) / len(key)
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy * len(key) >= MIN_KEY_ENTROPY_BITS

    def create_key(
        self,
        name: str,
        roles: Optional[Set[str]] = None,
        rate_limit: int = 1000,
        custom_key: Optional[str] = None,
    ) -> str:
        """创建 API 密钥"""
        if custom_key:
            if not self._check_key_entropy(custom_key):
                raise ValueError("Custom key does not meet minimum entropy requirements")
            raw_key = custom_key
        else:
            raw_key = secrets.token_hex(32)

        key_hash = self._hash_key(raw_key)

        if key_hash in self._keys:
            raise ValueError("Key hash collision detected, please retry")

        if len(self._keys) >= MAX_API_KEYS_PER_USER:
            raise ValueError(f"Maximum number of API keys ({MAX_API_KEYS_PER_USER}) reached")

        self._keys[key_hash] = APIKeyInfo(
            key_hash=key_hash,
            name=name,
            roles=roles or {"read"},
            rate_limit=rate_limit,
        )
        return raw_key

    def _secure_compare(self, a: str, b: str) -> bool:
        """恒定时间字符串比较"""
        return hmac.compare_digest(a.encode(), b.encode())

    def validate_key(self, request: Request) -> APIKeyInfo:
        """验证请求中的 API 密钥 - 仅从Header获取"""
        client_ip = request.client.host if request.client else "unknown"

        if self._is_ip_locked(client_ip):
            raise HTTPException(
                status_code=status.HTTP_423_LOCKED,
                detail={
                    "error": {
                        "code": "ACCOUNT_LOCKED",
                        "message": "Too many failed attempts. Try again later.",
                        "retry_after": self._get_lockout_remaining(client_ip)
                    }
                },
            )

        # 仅从Header获取密钥，移除Query参数支持
        api_key = request.headers.get("X-API-Key")

        if not api_key:
            self._record_failed_attempt(client_ip)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": {
                        "code": "MISSING_API_KEY",
                        "message": "API key required. Provide via X-API-Key header."
                    }
                },
            )

        if not self._is_valid_key_format(api_key):
            self._record_failed_attempt(client_ip)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": {
                        "code": "INVALID_KEY_FORMAT",
                        "message": "Invalid API key format"
                    }
                },
            )

        key_hash = self._hash_key(api_key)
        info = self._keys.get(key_hash)

        if not info or not info.is_active:
            self._record_failed_attempt(client_ip)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": {
                        "code": "INVALID_API_KEY",
                        "message": "Invalid or inactive API key"
                    }
                },
            )

        if info.locked_until > time.time():
            raise HTTPException(
                status_code=status.HTTP_423_LOCKED,
                detail={
                    "error": {
                        "code": "KEY_LOCKED",
                        "message": "API key temporarily locked",
                        "retry_after": int(info.locked_until - time.time())
                    }
                },
            )

        self._check_rate_limit(key_hash, info.rate_limit)
        info.last_used = time.time()
        info.request_count += 1
        info.failed_attempts = 0

        return info

    def _is_valid_key_format(self, key: str) -> bool:
        """验证密钥格式"""
        if len(key) != 64:
            return False
        try:
            bytes.fromhex(key)
            return True
        except ValueError:
            return False

    def _is_ip_locked(self, ip: str) -> bool:
        """检查IP是否被锁定"""
        if ip not in self._failed_attempts:
            return False
        recent_failures = [
            t for t in self._failed_attempts[ip]
            if time.time() - t < LOCKOUT_DURATION
        ]
        return len(recent_failures) >= MAX_FAILED_ATTEMPTS

    def _get_lockout_remaining(self, ip: str) -> int:
        """获取锁定剩余时间"""
        if ip not in self._failed_attempts or not self._failed_attempts[ip]:
            return 0
        last_failure = max(self._failed_attempts[ip])
        remaining = int(LOCKOUT_DURATION - (time.time() - last_failure))
        return max(0, remaining)

    def _record_failed_attempt(self, ip: str) -> None:
        """记录失败尝试"""
        self._failed_attempts[ip].append(time.time())
        cutoff = time.time() - LOCKOUT_DURATION
        self._failed_attempts[ip] = [
            t for t in self._failed_attempts[ip] if t > cutoff
        ]

    def _check_rate_limit(self, key_hash: str, limit: int) -> None:
        """检查速率限制"""
        now = time.time()
        window = 60.0

        self._rate_limit_windows[key_hash] = [
            t for t in self._rate_limit_windows[key_hash]
            if now - t < window
        ]

        if len(self._rate_limit_windows[key_hash]) >= limit:
            oldest = min(self._rate_limit_windows[key_hash])
            retry_after = int(window - (now - oldest)) + 1

            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "error": {
                        "code": "RATE_LIMIT_EXCEEDED",
                        "message": f"Rate limit exceeded: {limit} requests per minute",
                        "retry_after": retry_after,
                    }
                },
            )

        self._rate_limit_windows[key_hash].append(now)

    def has_role(self, info: APIKeyInfo, role: str) -> bool:
        """检查密钥是否具有指定角色"""
        return role in info.roles

    def revoke_key(self, key_hash: str) -> bool:
        """撤销密钥"""
        if key_hash in self._keys:
            self._keys[key_hash].is_active = False
            return True
        return False

    def rotate_key(self, old_key: str) -> str:
        """轮换密钥"""
        old_hash = self._hash_key(old_key)
        if old_hash not in self._keys:
            raise ValueError("Invalid key")

        info = self._keys[old_hash]
        new_key = secrets.token_hex(32)
        new_hash = self._hash_key(new_key)

        self._keys[new_hash] = APIKeyInfo(
            key_hash=new_hash,
            name=info.name,
            roles=info.roles,
            rate_limit=info.rate_limit,
            created_at=time.time(),
            last_rotation=time.time(),
        )

        self.revoke_key(old_hash)
        return new_key

    def create_session(self, key_hash: str, request: Request) -> str:
        """创建安全会话"""
        # 清理该密钥的旧会话
        self._sessions = {
            k: v for k, v in self._sessions.items()
            if v.key_hash != key_hash or time.time() < v.expires_at
        }

        session_id = secrets.token_urlsafe(32)
        client_ip = request.client.host if request.client else "unknown"

        self._sessions[session_id] = SessionInfo(
            session_id=session_id,
            key_hash=key_hash,
            expires_at=time.time() + MAX_SESSION_DURATION,
            ip_address=client_ip,
            user_agent=request.headers.get("user-agent", "")[:256],
        )

        return session_id

    def validate_session(self, session_id: str, request: Request) -> Optional[APIKeyInfo]:
        """验证会话"""
        session = self._sessions.get(session_id)
        if not session:
            return None

        if time.time() > session.expires_at:
            del self._sessions[session_id]
            return None

        # 验证IP绑定（防止会话劫持）
        client_ip = request.client.host if request.client else "unknown"
        if session.ip_address != client_ip:
            logger.warning("Session IP mismatch detected")
            return None

        session.last_activity = time.time()
        info = self._keys.get(session.key_hash)
        return info

    def cleanup_expired_sessions(self) -> int:
        """清理过期会话"""
        now = time.time()
        expired = [k for k, v in self._sessions.items() if now > v.expires_at]
        for k in expired:
            del self._sessions[k]
        return len(expired)


# 全局密钥管理器
_api_key_manager_instance: Optional[SecureAPIKeyManager] = None


def get_api_key_manager() -> SecureAPIKeyManager:
    """获取API密钥管理器实例"""
    global _api_key_manager_instance
    if _api_key_manager_instance is None:
        _api_key_manager_instance = SecureAPIKeyManager()
    return _api_key_manager_instance


api_key_manager = get_api_key_manager()


async def require_api_key(request: Request) -> APIKeyInfo:
    """FastAPI 依赖注入: 验证 API 密钥"""
    return get_api_key_manager().validate_key(request)


async def require_admin(request: Request) -> APIKeyInfo:
    """FastAPI 依赖注入: 要求管理员权限"""
    info = get_api_key_manager().validate_key(request)
    if not get_api_key_manager().has_role(info, "admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": {
                    "code": "INSUFFICIENT_PERMISSIONS",
                    "message": "Admin role required"
                }
            },
        )
    return info
