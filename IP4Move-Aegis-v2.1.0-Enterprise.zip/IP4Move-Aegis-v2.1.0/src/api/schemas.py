"""
API 请求/响应 Pydantic 模型

用于参数验证和文档生成
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, validator


class NodeRegistrationRequest(BaseModel):
    """节点注册请求"""
    node_id: str = Field(..., min_length=1, max_length=64, description="节点唯一标识")
    address: str = Field(..., min_length=7, max_length=45, description="节点地址 (IP或域名)")
    port: int = Field(..., ge=1, le=65535, description="节点端口")
    role: str = Field(..., regex="^(entry_mix|exit_mix|relay|exit)$", description="节点角色")
    public_key: str = Field(..., min_length=64, max_length=4096, description="节点公钥 (hex)")

    @validator("public_key")
    def validate_hex(cls, v):
        try:
            bytes.fromhex(v)
            return v
        except ValueError:
            raise ValueError("public_key must be valid hex string")


class EncryptRequest(BaseModel):
    """加密请求"""
    algorithm: str = Field(default="aes-256-gcm", regex="^(aes-256-gcm|chacha20-poly1305|ascon-128a)$")
    plaintext: str = Field(..., min_length=1, max_length=100000, description="明文数据")
    key: str = Field(..., min_length=32, max_length=128, description="密钥 (hex)")

    @validator("key")
    def validate_key_hex(cls, v):
        try:
            key_bytes = bytes.fromhex(v)
            if len(key_bytes) not in (16, 32, 64):
                raise ValueError("Key must be 16, 32, or 64 bytes")
            return v
        except ValueError:
            raise ValueError("Key must be valid hex string")

    @validator("plaintext")
    def validate_plaintext_size(cls, v):
        if len(v.encode()) > 64 * 1024 * 1024:
            raise ValueError("Plaintext too large (max 64MB)")
        return v


class HashRequest(BaseModel):
    """哈希请求"""
    algorithm: str = Field(default="blake3", regex="^(blake3|sha3-512|sha-256)$")
    data: str = Field(..., min_length=1, max_length=100000, description="待哈希数据")


class PathBuildRequest(BaseModel):
    """路径构建请求"""
    hop_count: int = Field(default=6, ge=3, le=10, description="跳数")
    include_decoys: bool = Field(default=True, description="是否包含诱饵路径")


class ShamirSplitRequest(BaseModel):
    """Shamir分片请求"""
    secret: str = Field(..., min_length=1, max_length=4096, description="秘密数据 (hex)")
    threshold: int = Field(default=3, ge=2, le=10, description="重建阈值")
    num_shares: int = Field(default=5, ge=3, le=20, description="总分片数")

    @validator("num_shares")
    def threshold_le_shares(cls, v, values):
        if "threshold" in values and v < values["threshold"]:
            raise ValueError("num_shares must be >= threshold")
        return v


class ErrorResponse(BaseModel):
    """统一错误响应"""
    error: Dict[str, Any] = Field(..., description="错误详情")
