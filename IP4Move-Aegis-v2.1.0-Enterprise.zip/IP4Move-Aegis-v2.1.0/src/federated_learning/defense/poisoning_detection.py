"""
投毒检测模块

该模块实现了联邦学习中的投毒攻击检测技术，包括数据投毒检测和模型投毒检测。
用于识别恶意客户端或异常更新，保护联邦学习系统的安全性。

使用numpy进行所有计算，不依赖PyTorch。
"""

import numpy as np
from typing import Optional, Tuple, List, Dict, Union, Callable
from collections import defaultdict
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataPoisoningDetector:
    """
    数据投毒检测类

    该类实现了多种数据投毒检测方法，用于识别训练数据中的恶意样本。
    支持基于统计异常、标签翻转和特征异常等多种检测策略。

    Attributes:
        detection_method (str): 检测方法，可选 'statistical', 'label_flip', 'feature'
        threshold (float): 异常检测阈值
        contamination (float): 预期异常比例

    Examples:
        >>> detector = DataPoisoningDetector(detection_method='statistical')
        >>> X = np.random.randn(100, 10)
        >>> y = np.random.randint(0, 2, 100)
        >>> is_poisoned, scores = detector.detect(X, y)
    """

    def __init__(self, detection_method: str = 'statistical',
                 threshold: float = 3.0,
                 contamination: float = 0.1):
        """
        初始化数据投毒检测器

        Args:
            detection_method: 检测方法，可选 'statistical', 'label_flip', 'feature'
            threshold: 异常检测阈值，默认3.0
            contamination: 预期异常比例，默认0.1

        Raises:
            ValueError: 当参数设置不合法时
        """
        valid_methods = ['statistical', 'label_flip', 'feature', 'ensemble']
        if detection_method not in valid_methods:
            raise ValueError(f"检测方法必须是 {valid_methods} 之一，当前值: {detection_method}")

        if threshold <= 0:
            raise ValueError(f"阈值必须为正数，当前值: {threshold}")

        if not 0 < contamination <= 0.5:
            raise ValueError(f"异常比例必须在(0, 0.5]范围内，当前值: {contamination}")

        self.detection_method = detection_method
        self.threshold = threshold
        self.contamination = contamination
        self._stats_cache = {}

        logger.info(f"DataPoisoningDetector初始化完成，方法: {detection_method}, 阈值: {threshold}")

    def detect(self, X: np.ndarray, y: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
        """
        检测数据投毒

        Args:
            X: 特征矩阵，形状为 (n_samples, n_features)
            y: 标签数组，形状为 (n_samples,)，可选

        Returns:
            Tuple[np.ndarray, np.ndarray]: 返回元组包含:
                - is_poisoned: 布尔数组，表示每个样本是否被投毒
                - anomaly_scores: 异常分数数组，分数越高表示越可疑

        Raises:
            TypeError: 当输入类型不正确时
            ValueError: 当输入数据不合法时
        """
        try:
            if not isinstance(X, np.ndarray):
                raise TypeError(f"X必须是numpy.ndarray类型，当前类型: {type(X)}")

            if X.ndim != 2:
                raise ValueError(f"X必须是二维数组，当前维度: {X.ndim}")

            if y is not None and not isinstance(y, np.ndarray):
                raise TypeError(f"y必须是numpy.ndarray类型，当前类型: {type(y)}")

            if y is not None and len(y) != len(X):
                raise ValueError(f"X和y的样本数量不匹配: {len(X)} vs {len(y)}")

            # 根据检测方法选择对应算法
            if self.detection_method == 'statistical':
                is_poisoned, scores = self._detect_statistical(X)
            elif self.detection_method == 'label_flip':
                if y is None:
                    raise ValueError("label_flip检测方法需要提供标签y")
                is_poisoned, scores = self._detect_label_flip(X, y)
            elif self.detection_method == 'feature':
                is_poisoned, scores = self._detect_feature_anomaly(X)
            elif self.detection_method == 'ensemble':
                if y is None:
                    raise ValueError("ensemble检测方法需要提供标签y")
                is_poisoned, scores = self._detect_ensemble(X, y)
            else:
                raise ValueError(f"未知的检测方法: {self.detection_method}")

            logger.info(f"数据投毒检测完成: 发现 {np.sum(is_poisoned)} 个可疑样本")
            return is_poisoned, scores

        except Exception as e:
            logger.error(f"数据投毒检测失败: {str(e)}")
            raise

    def _detect_statistical(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        基于统计异常检测

        使用Z-score方法检测偏离正常分布的样本。

        Args:
            X: 特征矩阵

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否投毒, 异常分数)
        """
        # 计算每个特征的均值和标准差
        mean = np.mean(X, axis=0)
        std = np.std(X, axis=0)

        # 避免除以零
        std = np.where(std < 1e-10, 1e-10, std)

        # 计算Z-score
        z_scores = np.abs((X - mean) / std)

        # 计算每个样本的最大Z-score
        max_z_scores = np.max(z_scores, axis=1)

        # 基于阈值判断
        is_poisoned = max_z_scores > self.threshold

        # 确保异常比例不超过预期
        if np.sum(is_poisoned) > len(X) * self.contamination:
            threshold_idx = int(len(X) * (1 - self.contamination))
            sorted_scores = np.sort(max_z_scores)
            adaptive_threshold = sorted_scores[min(threshold_idx, len(sorted_scores) - 1)]
            is_poisoned = max_z_scores > adaptive_threshold

        return is_poisoned, max_z_scores

    def _detect_label_flip(self, X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        检测标签翻转攻击

        通过比较样本特征与同类/异类样本的距离来检测异常标签。

        Args:
            X: 特征矩阵
            y: 标签数组

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否投毒, 异常分数)
        """
        anomaly_scores = np.zeros(len(X))
        unique_labels = np.unique(y)

        for label in unique_labels:
            mask = y == label
            same_class = X[mask]
            other_class = X[~mask]

            if len(same_class) == 0 or len(other_class) == 0:
                continue

            # 计算同类中心
            same_center = np.mean(same_class, axis=0)

            # 计算异类中心
            other_center = np.mean(other_class, axis=0)

            # 计算每个样本到同类和异类的距离
            for idx in np.where(mask)[0]:
                dist_to_same = np.linalg.norm(X[idx] - same_center)
                dist_to_other = np.linalg.norm(X[idx] - other_center)

                # 如果到异类的距离更近，则可能是标签翻转
                if dist_to_same > 0:
                    anomaly_scores[idx] = dist_to_other / dist_to_same
                else:
                    anomaly_scores[idx] = dist_to_other

        # 基于阈值判断
        is_poisoned = anomaly_scores > self.threshold

        # 确保异常比例
        if np.sum(is_poisoned) > len(X) * self.contamination:
            threshold_idx = int(len(X) * (1 - self.contamination))
            sorted_scores = np.sort(anomaly_scores)
            adaptive_threshold = sorted_scores[min(threshold_idx, len(sorted_scores) - 1)]
            is_poisoned = anomaly_scores > adaptive_threshold

        return is_poisoned, anomaly_scores

    def _detect_feature_anomaly(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        检测特征异常

        使用局部异常因子(LOF)的简化版本检测特征空间中的异常点。

        Args:
            X: 特征矩阵

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否投毒, 异常分数)
        """
        n_samples = len(X)
        k = min(20, n_samples - 1)  # 邻居数量

        # 计算距离矩阵
        distances = np.zeros((n_samples, n_samples))
        for i in range(n_samples):
            distances[i] = np.linalg.norm(X - X[i], axis=1)

        # 计算k近邻距离
        k_distances = np.partition(distances, k, axis=1)[:, k]

        # 计算可达密度
        reachability_densities = np.zeros(n_samples)
        for i in range(n_samples):
            neighbors = np.argsort(distances[i])[:k+1]
            reach_dist = np.maximum(distances[i][neighbors], k_distances[neighbors])
            reachability_densities[i] = 1.0 / (np.mean(reach_dist) + 1e-10)

        # 计算LOF分数
        lof_scores = np.zeros(n_samples)
        for i in range(n_samples):
            neighbors = np.argsort(distances[i])[:k+1]
            lof_scores[i] = np.mean(reachability_densities[neighbors]) / reachability_densities[i]

        # 基于阈值判断
        is_poisoned = lof_scores > self.threshold

        # 确保异常比例
        if np.sum(is_poisoned) > len(X) * self.contamination:
            threshold_idx = int(len(X) * (1 - self.contamination))
            sorted_scores = np.sort(lof_scores)
            adaptive_threshold = sorted_scores[min(threshold_idx, len(sorted_scores) - 1)]
            is_poisoned = lof_scores > adaptive_threshold

        return is_poisoned, lof_scores

    def _detect_ensemble(self, X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        集成检测方法

        结合多种检测方法的结果。

        Args:
            X: 特征矩阵
            y: 标签数组

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否投毒, 异常分数)
        """
        # 获取各种方法的分数
        _, stat_scores = self._detect_statistical(X)
        _, label_scores = self._detect_label_flip(X, y)
        _, feature_scores = self._detect_feature_anomaly(X)

        # 归一化分数
        def normalize(scores):
            min_val = np.min(scores)
            max_val = np.max(scores)
            if max_val - min_val < 1e-10:
                return np.zeros_like(scores)
            return (scores - min_val) / (max_val - min_val)

        stat_norm = normalize(stat_scores)
        label_norm = normalize(label_scores)
        feature_norm = normalize(feature_scores)

        # 加权平均
        ensemble_scores = 0.3 * stat_norm + 0.4 * label_norm + 0.3 * feature_norm

        # 基于阈值判断
        is_poisoned = ensemble_scores > 0.5  # 归一化后使用0.5作为阈值

        # 确保异常比例
        if np.sum(is_poisoned) > len(X) * self.contamination:
            threshold_idx = int(len(X) * (1 - self.contamination))
            sorted_scores = np.sort(ensemble_scores)
            adaptive_threshold = sorted_scores[min(threshold_idx, len(sorted_scores) - 1)]
            is_poisoned = ensemble_scores > adaptive_threshold

        return is_poisoned, ensemble_scores

    def get_detection_report(self, X: np.ndarray, y: Optional[np.ndarray] = None) -> dict:
        """
        获取详细的检测报告

        Args:
            X: 特征矩阵
            y: 标签数组，可选

        Returns:
            dict: 包含检测详细信息的字典
        """
        try:
            is_poisoned, scores = self.detect(X, y)

            report = {
                "detection_method": self.detection_method,
                "total_samples": len(X),
                "poisoned_samples": int(np.sum(is_poisoned)),
                "poisoned_ratio": float(np.mean(is_poisoned)),
                "mean_anomaly_score": float(np.mean(scores)),
                "max_anomaly_score": float(np.max(scores)),
                "threshold_used": float(self.threshold),
                "contamination": self.contamination
            }

            if y is not None:
                # 分析每个类别的投毒情况
                unique_labels = np.unique(y)
                class_stats = {}
                for label in unique_labels:
                    mask = y == label
                    class_stats[str(label)] = {
                        "total": int(np.sum(mask)),
                        "poisoned": int(np.sum(is_poisoned[mask]))
                    }
                report["class_statistics"] = class_stats

            return report

        except Exception as e:
            logger.error(f"生成检测报告失败: {str(e)}")
            raise


class ModelPoisoningDetector:
    """
    模型投毒检测类

    该类实现了联邦学习中的模型投毒检测方法，用于识别恶意客户端发送的异常模型更新。
    支持基于统计异常、余弦相似度和权重异常等多种检测策略。

    Attributes:
        detection_method (str): 检测方法
        threshold (float): 异常检测阈值
        history_window (int): 历史窗口大小

    Examples:
        >>> detector = ModelPoisoningDetector(detection_method='cosine')
        >>> updates = [np.random.randn(100) for _ in range(10)]
        >>> is_malicious, scores = detector.detect_updates(updates)
    """

    def __init__(self, detection_method: str = 'cosine',
                 threshold: float = 0.5,
                 history_window: int = 5):
        """
        初始化模型投毒检测器

        Args:
            detection_method: 检测方法，可选 'cosine', 'statistical', 'norm', 'trimmed_mean'
            threshold: 异常检测阈值，默认0.5
            history_window: 历史窗口大小，用于基于历史的检测，默认5

        Raises:
            ValueError: 当参数设置不合法时
        """
        valid_methods = ['cosine', 'statistical', 'norm', 'trimmed_mean', 'krum']
        if detection_method not in valid_methods:
            raise ValueError(f"检测方法必须是 {valid_methods} 之一，当前值: {detection_method}")

        if threshold <= 0:
            raise ValueError(f"阈值必须为正数，当前值: {threshold}")

        if history_window < 1:
            raise ValueError(f"历史窗口必须至少为1，当前值: {history_window}")

        self.detection_method = detection_method
        self.threshold = threshold
        self.history_window = history_window
        self._update_history = []

        logger.info(f"ModelPoisoningDetector初始化完成，方法: {detection_method}, 阈值: {threshold}")

    def detect_updates(self, updates: List[np.ndarray],
                       global_model: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
        """
        检测模型更新中的投毒

        Args:
            updates: 客户端模型更新列表，每个元素是一个numpy数组
            global_model: 全局模型参数，可选

        Returns:
            Tuple[np.ndarray, np.ndarray]: 返回元组包含:
                - is_malicious: 布尔数组，表示每个更新是否恶意
                - anomaly_scores: 异常分数数组

        Raises:
            TypeError: 当输入类型不正确时
            ValueError: 当输入数据不合法时
        """
        try:
            if not isinstance(updates, list) or len(updates) == 0:
                raise ValueError("updates必须是非空列表")

            for i, update in enumerate(updates):
                if not isinstance(update, np.ndarray):
                    raise TypeError(f"第{i}个更新必须是numpy.ndarray类型")

            # 根据检测方法选择对应算法
            if self.detection_method == 'cosine':
                is_malicious, scores = self._detect_cosine_similarity(updates)
            elif self.detection_method == 'statistical':
                is_malicious, scores = self._detect_statistical(updates)
            elif self.detection_method == 'norm':
                is_malicious, scores = self._detect_norm_anomaly(updates)
            elif self.detection_method == 'trimmed_mean':
                is_malicious, scores = self._detect_by_trimmed_mean(updates)
            elif self.detection_method == 'krum':
                is_malicious, scores = self._detect_krum(updates)
            else:
                raise ValueError(f"未知的检测方法: {self.detection_method}")

            # 更新历史
            self._update_history.append({
                'is_malicious': is_malicious.copy(),
                'scores': scores.copy()
            })
            if len(self._update_history) > self.history_window:
                self._update_history.pop(0)

            logger.info(f"模型投毒检测完成: 发现 {np.sum(is_malicious)} 个恶意更新")
            return is_malicious, scores

        except Exception as e:
            logger.error(f"模型投毒检测失败: {str(e)}")
            raise

    def _detect_cosine_similarity(self, updates: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """
        基于余弦相似度检测

        检测与其他更新方向差异较大的更新。

        Args:
            updates: 模型更新列表

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否恶意, 异常分数)
        """
        n_updates = len(updates)
        similarity_matrix = np.zeros((n_updates, n_updates))

        # 计算余弦相似度矩阵
        for i in range(n_updates):
            for j in range(n_updates):
                if i != j:
                    norm_i = np.linalg.norm(updates[i])
                    norm_j = np.linalg.norm(updates[j])
                    if norm_i > 0 and norm_j > 0:
                        similarity = np.dot(updates[i], updates[j]) / (norm_i * norm_j)
                        similarity_matrix[i, j] = similarity

        # 计算每个更新的平均相似度
        avg_similarities = np.mean(similarity_matrix, axis=1)

        # 转换为异常分数（相似度越低，异常分数越高）
        anomaly_scores = 1.0 - avg_similarities

        # 基于阈值判断
        is_malicious = anomaly_scores > self.threshold

        return is_malicious, anomaly_scores

    def _detect_statistical(self, updates: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """
        基于统计异常检测

        检测在统计分布上异常的更新。

        Args:
            updates: 模型更新列表

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否恶意, 异常分数)
        """
        # 将更新堆叠成矩阵
        updates_matrix = np.stack(updates)

        # 计算每个维度的均值和标准差
        mean = np.mean(updates_matrix, axis=0)
        std = np.std(updates_matrix, axis=0)

        # 避免除以零
        std = np.where(std < 1e-10, 1e-10, std)

        # 计算每个更新的Z-score
        z_scores = np.abs((updates_matrix - mean) / std)

        # 计算每个更新的平均Z-score
        avg_z_scores = np.mean(z_scores, axis=1)

        # 基于阈值判断
        is_malicious = avg_z_scores > self.threshold

        return is_malicious, avg_z_scores

    def _detect_norm_anomaly(self, updates: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """
        基于范数异常检测

        检测范数异常大或异常小的更新。

        Args:
            updates: 模型更新列表

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否恶意, 异常分数)
        """
        # 计算每个更新的范数
        norms = np.array([np.linalg.norm(update) for update in updates])

        # 计算范数的统计信息
        mean_norm = np.mean(norms)
        std_norm = np.std(norms)

        if std_norm < 1e-10:
            # 所有范数几乎相同
            return np.zeros(len(updates), dtype=bool), np.zeros(len(updates))

        # 计算Z-score
        z_scores = np.abs((norms - mean_norm) / std_norm)

        # 基于阈值判断
        is_malicious = z_scores > self.threshold

        return is_malicious, z_scores

    def _detect_by_trimmed_mean(self, updates: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """
        使用截断均值检测

        计算截断均值，并标记偏离截断均值较远的更新。

        Args:
            updates: 模型更新列表

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否恶意, 异常分数)
        """
        n_updates = len(updates)
        updates_matrix = np.stack(updates)

        # 计算每个维度的截断均值（去掉最大和最小的各20%）
        trim_ratio = 0.2
        trim_count = int(n_updates * trim_ratio)

        trimmed_means = np.zeros(updates_matrix.shape[1])
        for i in range(updates_matrix.shape[1]):
            sorted_vals = np.sort(updates_matrix[:, i])
            trimmed_vals = sorted_vals[trim_count:n_updates-trim_count]
            trimmed_means[i] = np.mean(trimmed_vals)

        # 计算每个更新与截断均值的距离
        distances = np.array([np.linalg.norm(update - trimmed_means) for update in updates])

        # 计算距离的统计信息
        mean_dist = np.mean(distances)
        std_dist = np.std(distances)

        if std_dist < 1e-10:
            return np.zeros(n_updates, dtype=bool), np.zeros(n_updates)

        # 计算Z-score
        z_scores = (distances - mean_dist) / std_dist

        # 基于阈值判断
        is_malicious = z_scores > self.threshold

        return is_malicious, z_scores

    def _detect_krum(self, updates: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """
        Krum算法检测

        选择与其他更新最接近的更新作为基准，标记距离较远的更新。

        Args:
            updates: 模型更新列表

        Returns:
            Tuple[np.ndarray, np.ndarray]: (是否恶意, 异常分数)
        """
        n_updates = len(updates)
        n_neighbors = max(1, n_updates - 2)  # 假设最多有f个恶意客户端，n_neighbors = n - f - 2

        # 计算距离矩阵
        distances = np.zeros((n_updates, n_updates))
        for i in range(n_updates):
            for j in range(n_updates):
                if i != j:
                    distances[i, j] = np.linalg.norm(updates[i] - updates[j])

        # 计算每个更新的Krum分数（到最近的n_neighbors个邻居的距离和）
        krum_scores = np.zeros(n_updates)
        for i in range(n_updates):
            sorted_distances = np.sort(distances[i])
            krum_scores[i] = np.sum(sorted_distances[:n_neighbors])

        # 转换为异常分数（分数越高越异常）
        # 归一化到[0, 1]
        min_score = np.min(krum_scores)
        max_score = np.max(krum_scores)
        if max_score - min_score > 1e-10:
            anomaly_scores = (krum_scores - min_score) / (max_score - min_score)
        else:
            anomaly_scores = np.zeros(n_updates)

        # 基于阈值判断
        is_malicious = anomaly_scores > self.threshold

        return is_malicious, anomaly_scores

    def filter_updates(self, updates: List[np.ndarray],
                       client_ids: Optional[List] = None) -> Tuple[List[np.ndarray], List]:
        """
        过滤恶意更新

        Args:
            updates: 模型更新列表
            client_ids: 客户端ID列表，可选

        Returns:
            Tuple[List[np.ndarray], List]: 返回元组包含:
                - filtered_updates: 过滤后的更新列表
                - filtered_ids: 过滤后的客户端ID列表
        """
        try:
            is_malicious, _ = self.detect_updates(updates)

            filtered_updates = []
            filtered_ids = []

            for i, (update, is_bad) in enumerate(zip(updates, is_malicious)):
                if not is_bad:
                    filtered_updates.append(update)
                    if client_ids is not None:
                        filtered_ids.append(client_ids[i])

            logger.info(f"更新过滤完成: {len(updates)} 个更新中保留了 {len(filtered_updates)} 个")

            return filtered_updates, filtered_ids

        except Exception as e:
            logger.error(f"过滤更新失败: {str(e)}")
            raise

    def get_detection_history(self) -> List[dict]:
        """
        获取检测历史

        Returns:
            List[dict]: 检测历史列表
        """
        return self._update_history.copy()

    def reset_history(self):
        """
        重置检测历史
        """
        self._update_history = []
        logger.info("检测历史已重置")


if __name__ == "__main__":
    # 简单的测试代码
    print("测试投毒检测模块...")

    # 测试DataPoisoningDetector
    print("\n1. 测试DataPoisoningDetector:")
    detector = DataPoisoningDetector(detection_method='statistical')
    X = np.random.randn(100, 10)
    # 添加一些异常样本
    X[0:5] = X[0:5] + 10
    y = np.random.randint(0, 2, 100)
    is_poisoned, scores = detector.detect(X, y)
    print(f"   总样本数: {len(X)}")
    print(f"   检测到投毒样本: {np.sum(is_poisoned)}")
    print(f"   平均异常分数: {np.mean(scores):.4f}")

    # 测试ModelPoisoningDetector
    print("\n2. 测试ModelPoisoningDetector:")
    model_detector = ModelPoisoningDetector(detection_method='cosine')
    updates = [np.random.randn(100) for _ in range(10)]
    # 添加一个恶意更新
    updates[0] = -updates[0] * 5  # 方向相反且幅度大
    is_malicious, scores = model_detector.detect_updates(updates)
    print(f"   总更新数: {len(updates)}")
    print(f"   检测到恶意更新: {np.sum(is_malicious)}")
    print(f"   平均异常分数: {np.mean(scores):.4f}")

    # 测试过滤功能
    filtered_updates, _ = model_detector.filter_updates(updates)
    print(f"   过滤后剩余更新: {len(filtered_updates)}")

    print("\n所有测试完成!")
