"""
梯度压缩模块

该模块实现了联邦学习中的梯度压缩技术，用于减少通信开销。
包含Top-K压缩、随机量化和梯度稀疏化三种方法。

使用numpy进行所有计算，不依赖PyTorch。
"""

import numpy as np
from typing import Optional, Tuple, List, Union
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TopKCompression:
    """
    Top-K梯度压缩类

    该类实现了Top-K梯度压缩算法，只保留梯度中绝对值最大的K个元素，
    其余元素置为零。这种方法可以显著减少通信带宽，同时保持模型性能。

    Attributes:
        compression_ratio (float): 压缩比例，取值范围(0, 1]，表示保留的梯度比例
        seed (Optional[int]): 随机种子，用于结果复现

    Examples:
        >>> compressor = TopKCompression(compression_ratio=0.1)
        >>> gradient = np.random.randn(1000)
        >>> compressed, indices = compressor.compress(gradient)
        >>> recovered = compressor.decompress(compressed, indices, gradient.shape)
    """

    def __init__(self, compression_ratio: float = 0.1, seed: Optional[int] = None):
        """
        初始化TopK压缩器

        Args:
            compression_ratio: 压缩比例，表示保留的梯度比例，默认0.1
            seed: 随机种子，可选

        Raises:
            ValueError: 当compression_ratio不在(0, 1]范围内时
        """
        if not 0 < compression_ratio <= 1.0:
            raise ValueError(f"压缩比例必须在(0, 1]范围内，当前值: {compression_ratio}")

        self.compression_ratio = compression_ratio
        self.seed = seed

        if seed is not None:
            np.random.seed(seed)

        logger.info(f"TopKCompression初始化完成，压缩比例: {compression_ratio}")

    def compress(self, gradient: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        压缩梯度向量

        保留梯度中绝对值最大的K个元素，其余置为零。

        Args:
            gradient: 输入梯度数组，形状为任意numpy数组

        Returns:
            Tuple[np.ndarray, np.ndarray]: 返回元组包含:
                - compressed_gradient: 压缩后的梯度数组
                - indices: 保留元素的索引数组

        Raises:
            TypeError: 当输入不是numpy数组时
            ValueError: 当输入数组为空时
        """
        try:
            # 输入验证
            if not isinstance(gradient, np.ndarray):
                raise TypeError(f"输入必须是numpy.ndarray类型，当前类型: {type(gradient)}")

            if gradient.size == 0:
                raise ValueError("输入梯度数组不能为空")

            # 计算需要保留的元素数量
            k = max(1, int(gradient.size * self.compression_ratio))

            # 获取绝对值最大的k个元素的索引
            flat_gradient = gradient.flatten()
            abs_gradient = np.abs(flat_gradient)

            # 使用argpartition获取前k个最大值的索引
            indices = np.argpartition(abs_gradient, -k)[-k:]

            # 创建压缩后的梯度
            compressed_flat = np.zeros_like(flat_gradient)
            compressed_flat[indices] = flat_gradient[indices]

            # 恢复原始形状
            compressed_gradient = compressed_flat.reshape(gradient.shape)

            logger.debug(f"梯度压缩完成: 原始大小 {gradient.size}, 保留 {k} 个元素")

            return compressed_gradient, indices

        except Exception as e:
            logger.error(f"梯度压缩失败: {str(e)}")
            raise

    def decompress(self, compressed_gradient: np.ndarray, indices: np.ndarray,
                   original_shape: Optional[Tuple] = None) -> np.ndarray:
        """
        解压梯度向量

        Args:
            compressed_gradient: 压缩后的梯度数组
            indices: 保留元素的索引数组
            original_shape: 原始梯度的形状，可选

        Returns:
            np.ndarray: 解压后的梯度数组

        Raises:
            TypeError: 当输入类型不正确时
            ValueError: 当形状不匹配时
        """
        try:
            if not isinstance(compressed_gradient, np.ndarray):
                raise TypeError("compressed_gradient必须是numpy.ndarray类型")

            if not isinstance(indices, np.ndarray):
                raise TypeError("indices必须是numpy.ndarray类型")

            # 如果需要恢复特定形状
            if original_shape is not None:
                result = compressed_gradient.reshape(original_shape)
            else:
                result = compressed_gradient.copy()

            logger.debug(f"梯度解压完成，形状: {result.shape}")
            return result

        except Exception as e:
            logger.error(f"梯度解压失败: {str(e)}")
            raise

    def get_compression_stats(self, original: np.ndarray, compressed: np.ndarray) -> dict:
        """
        获取压缩统计信息

        Args:
            original: 原始梯度
            compressed: 压缩后的梯度

        Returns:
            dict: 包含压缩统计信息的字典
        """
        try:
            original_size = original.nbytes
            compressed_size = np.count_nonzero(compressed) * original.dtype.itemsize + \
                            compressed.size / 8  # 位图开销

            stats = {
                "original_size_bytes": original_size,
                "compressed_size_bytes": compressed_size,
                "compression_ratio": compressed_size / original_size if original_size > 0 else 0,
                "sparsity": 1.0 - (np.count_nonzero(compressed) / compressed.size),
                "reconstruction_error": float(np.linalg.norm(original - compressed))
            }

            return stats

        except Exception as e:
            logger.error(f"获取压缩统计信息失败: {str(e)}")
            raise


class RandomQuantization:
    """
    随机量化压缩类

    该类实现了随机量化算法，将梯度值映射到有限的离散值集合中，
    从而减少每个梯度元素所需的比特数。

    Attributes:
        num_bits (int): 量化比特数
        num_levels (int): 量化级别数

    Examples:
        >>> quantizer = RandomQuantization(num_bits=2)
        >>> gradient = np.random.randn(1000)
        >>> quantized = quantizer.quantize(gradient)
        >>> recovered = quantizer.dequantize(quantized)
    """

    def __init__(self, num_bits: int = 2):
        """
        初始化随机量化器

        Args:
            num_bits: 量化比特数，默认2比特

        Raises:
            ValueError: 当num_bits不在[1, 32]范围内时
        """
        if not 1 <= num_bits <= 32:
            raise ValueError(f"量化比特数必须在[1, 32]范围内，当前值: {num_bits}")

        self.num_bits = num_bits
        self.num_levels = 2 ** num_bits

        logger.info(f"RandomQuantization初始化完成，比特数: {num_bits}, 量化级别: {self.num_levels}")

    def quantize(self, gradient: np.ndarray) -> Tuple[np.ndarray, dict]:
        """
        量化梯度

        使用随机舍入将连续梯度值量化为离散值。

        Args:
            gradient: 输入梯度数组

        Returns:
            Tuple[np.ndarray, dict]: 返回元组包含:
                - quantized_gradient: 量化后的梯度
                - metadata: 包含量化参数的字典（最小值、最大值等）

        Raises:
            TypeError: 当输入不是numpy数组时
            ValueError: 当输入数组为空或包含NaN/Inf时
        """
        try:
            if not isinstance(gradient, np.ndarray):
                raise TypeError(f"输入必须是numpy.ndarray类型，当前类型: {type(gradient)}")

            if gradient.size == 0:
                raise ValueError("输入梯度数组不能为空")

            if np.any(np.isnan(gradient)) or np.any(np.isinf(gradient)):
                raise ValueError("输入梯度包含NaN或Inf值")

            # 计算梯度范围
            grad_min = np.min(gradient)
            grad_max = np.max(gradient)

            if grad_max - grad_min < 1e-10:
                # 所有值几乎相同
                return gradient.copy(), {"min": grad_min, "max": grad_max, "scale": 1.0}

            # 归一化到[0, num_levels-1]
            scale = (grad_max - grad_min) / (self.num_levels - 1)
            normalized = (gradient - grad_min) / scale

            # 随机舍入
            floor_val = np.floor(normalized)
            prob = normalized - floor_val
            random_vals = np.random.random(gradient.shape)
            quantized_levels = floor_val + (random_vals < prob).astype(np.float64)

            # 裁剪到有效范围
            quantized_levels = np.clip(quantized_levels, 0, self.num_levels - 1)

            metadata = {
                "min": grad_min,
                "max": grad_max,
                "scale": scale,
                "num_levels": self.num_levels
            }

            logger.debug(f"梯度量化完成: 范围 [{grad_min:.4f}, {grad_max:.4f}], 级别数: {self.num_levels}")

            return quantized_levels.astype(np.float64), metadata

        except Exception as e:
            logger.error(f"梯度量化失败: {str(e)}")
            raise

    def dequantize(self, quantized_gradient: np.ndarray, metadata: dict) -> np.ndarray:
        """
        反量化梯度

        Args:
            quantized_gradient: 量化后的梯度
            metadata: 包含量化参数的字典

        Returns:
            np.ndarray: 反量化后的梯度

        Raises:
            TypeError: 当输入类型不正确时
            KeyError: 当metadata缺少必要键时
        """
        try:
            if not isinstance(quantized_gradient, np.ndarray):
                raise TypeError("quantized_gradient必须是numpy.ndarray类型")

            required_keys = ["min", "scale"]
            for key in required_keys:
                if key not in metadata:
                    raise KeyError(f"metadata缺少必要键: {key}")

            grad_min = metadata["min"]
            scale = metadata["scale"]

            # 反量化
            dequantized = quantized_gradient * scale + grad_min

            logger.debug(f"梯度反量化完成，形状: {dequantized.shape}")
            return dequantized

        except Exception as e:
            logger.error(f"梯度反量化失败: {str(e)}")
            raise

    def get_quantization_error(self, original: np.ndarray, quantized: np.ndarray,
                               metadata: dict) -> dict:
        """
        计算量化误差统计

        Args:
            original: 原始梯度
            quantized: 量化后的梯度
            metadata: 量化元数据

        Returns:
            dict: 包含误差统计的字典
        """
        try:
            dequantized = self.dequantize(quantized, metadata)

            error = original - dequantized
            mse = np.mean(error ** 2)
            mae = np.mean(np.abs(error))
            max_error = np.max(np.abs(error))
            snr = np.mean(original ** 2) / mse if mse > 0 else float('inf')

            stats = {
                "mse": float(mse),
                "mae": float(mae),
                "max_error": float(max_error),
                "snr_db": float(10 * np.log10(snr)) if snr != float('inf') else float('inf'),
                "compression_ratio": 64 / self.num_bits  # 假设原始是float64
            }

            return stats

        except Exception as e:
            logger.error(f"计算量化误差失败: {str(e)}")
            raise


class GradientSparsification:
    """
    梯度稀疏化类

    该类实现了梯度稀疏化算法，通过设置阈值将小的梯度值置为零，
    从而实现梯度的稀疏表示。

    Attributes:
        threshold (float): 稀疏化阈值
        sparsity_target (Optional[float]): 目标稀疏度

    Examples:
        >>> sparsifier = GradientSparsification(threshold=0.01)
        >>> gradient = np.random.randn(1000)
        >>> sparse_gradient = sparsifier.sparsify(gradient)
    """

    def __init__(self, threshold: Optional[float] = None,
                 sparsity_target: Optional[float] = None):
        """
        初始化梯度稀疏化器

        Args:
            threshold: 稀疏化阈值，绝对值小于该值的梯度将被置零
            sparsity_target: 目标稀疏度，如果指定则自动计算阈值

        Raises:
            ValueError: 当参数设置不合法时
        """
        if threshold is not None and threshold < 0:
            raise ValueError(f"阈值必须非负，当前值: {threshold}")

        if sparsity_target is not None and not 0 <= sparsity_target <= 1:
            raise ValueError(f"目标稀疏度必须在[0, 1]范围内，当前值: {sparsity_target}")

        if threshold is None and sparsity_target is None:
            # 默认使用阈值0.01
            threshold = 0.01

        self.threshold = threshold
        self.sparsity_target = sparsity_target

        logger.info(f"GradientSparsification初始化完成，阈值: {threshold}, 目标稀疏度: {sparsity_target}")

    def _compute_threshold(self, gradient: np.ndarray) -> float:
        """
        根据目标稀疏度计算阈值

        Args:
            gradient: 输入梯度

        Returns:
            float: 计算得到的阈值
        """
        if self.sparsity_target is None:
            return self.threshold if self.threshold is not None else 0.0

        # 根据目标稀疏度计算阈值
        abs_grad = np.abs(gradient.flatten())
        k = int(abs_grad.size * (1 - self.sparsity_target))
        k = max(1, min(k, abs_grad.size - 1))

        # 获取第k大的值作为阈值
        threshold = np.partition(abs_grad, k)[k]

        return threshold

    def sparsify(self, gradient: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        稀疏化梯度

        Args:
            gradient: 输入梯度数组

        Returns:
            Tuple[np.ndarray, np.ndarray]: 返回元组包含:
                - sparse_gradient: 稀疏化后的梯度
                - mask: 稀疏化掩码（True表示保留）

        Raises:
            TypeError: 当输入不是numpy数组时
            ValueError: 当输入数组为空时
        """
        try:
            if not isinstance(gradient, np.ndarray):
                raise TypeError(f"输入必须是numpy.ndarray类型，当前类型: {type(gradient)}")

            if gradient.size == 0:
                raise ValueError("输入梯度数组不能为空")

            # 计算阈值
            threshold = self._compute_threshold(gradient)

            # 创建掩码
            mask = np.abs(gradient) >= threshold

            # 应用掩码
            sparse_gradient = np.where(mask, gradient, 0.0)

            actual_sparsity = 1.0 - (np.count_nonzero(sparse_gradient) / sparse_gradient.size)
            logger.debug(f"梯度稀疏化完成: 阈值 {threshold:.6f}, 实际稀疏度 {actual_sparsity:.4f}")

            return sparse_gradient, mask

        except Exception as e:
            logger.error(f"梯度稀疏化失败: {str(e)}")
            raise

    def desparsify(self, sparse_gradient: np.ndarray) -> np.ndarray:
        """
        反稀疏化（直接返回稀疏梯度）

        Args:
            sparse_gradient: 稀疏化后的梯度

        Returns:
            np.ndarray: 梯度数组
        """
        return sparse_gradient.copy()

    def get_sparsity_info(self, gradient: np.ndarray) -> dict:
        """
        获取稀疏度信息

        Args:
            gradient: 梯度数组

        Returns:
            dict: 包含稀疏度信息的字典
        """
        try:
            nonzero_count = np.count_nonzero(gradient)
            total_count = gradient.size
            sparsity = 1.0 - (nonzero_count / total_count)

            # 计算存储节省
            dense_size = gradient.nbytes
            # 稀疏存储：索引 + 值
            sparse_size = nonzero_count * (gradient.dtype.itemsize + 4)  # 假设4字节索引

            info = {
                "total_elements": total_count,
                "nonzero_elements": nonzero_count,
                "sparsity_ratio": sparsity,
                "dense_size_bytes": dense_size,
                "sparse_size_bytes": sparse_size,
                "storage_savings_ratio": 1.0 - (sparse_size / dense_size) if dense_size > 0 else 0
            }

            return info

        except Exception as e:
            logger.error(f"获取稀疏度信息失败: {str(e)}")
            raise

    def apply_momentum_correction(self, gradient: np.ndarray,
                                  residual: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        应用动量校正

        将被稀疏化掉的梯度累积到残差中，用于下一轮迭代。

        Args:
            gradient: 当前梯度
            residual: 累积残差

        Returns:
            Tuple[np.ndarray, np.ndarray]: 返回元组包含:
                - corrected_gradient: 校正后的梯度
                - new_residual: 新的残差
        """
        try:
            if not isinstance(gradient, np.ndarray) or not isinstance(residual, np.ndarray):
                raise TypeError("输入必须是numpy.ndarray类型")

            if gradient.shape != residual.shape:
                raise ValueError(f"梯度形状 {gradient.shape} 与残差形状 {residual.shape} 不匹配")

            # 添加残差
            corrected = gradient + residual

            # 稀疏化
            sparse_gradient, mask = self.sparsify(corrected)

            # 更新残差（被置零的部分）
            new_residual = np.where(mask, 0.0, corrected)

            logger.debug("动量校正完成")
            return sparse_gradient, new_residual

        except Exception as e:
            logger.error(f"应用动量校正失败: {str(e)}")
            raise


if __name__ == "__main__":
    # 简单的测试代码
    print("测试梯度压缩模块...")

    # 测试TopKCompression
    print("\n1. 测试TopKCompression:")
    topk = TopKCompression(compression_ratio=0.1)
    grad = np.random.randn(100)
    compressed, indices = topk.compress(grad)
    stats = topk.get_compression_stats(grad, compressed)
    print(f"   原始大小: {stats['original_size_bytes']} bytes")
    print(f"   压缩比例: {stats['compression_ratio']:.4f}")
    print(f"   稀疏度: {stats['sparsity']:.4f}")

    # 测试RandomQuantization
    print("\n2. 测试RandomQuantization:")
    quantizer = RandomQuantization(num_bits=2)
    grad = np.random.randn(100)
    quantized, metadata = quantizer.quantize(grad)
    error_stats = quantizer.get_quantization_error(grad, quantized, metadata)
    print(f"   MSE: {error_stats['mse']:.6f}")
    print(f"   SNR: {error_stats['snr_db']:.2f} dB")

    # 测试GradientSparsification
    print("\n3. 测试GradientSparsification:")
    sparsifier = GradientSparsification(sparsity_target=0.9)
    grad = np.random.randn(100)
    sparse, mask = sparsifier.sparsify(grad)
    info = sparsifier.get_sparsity_info(sparse)
    print(f"   稀疏度: {info['sparsity_ratio']:.4f}")
    print(f"   非零元素: {info['nonzero_elements']}")

    print("\n所有测试完成!")
