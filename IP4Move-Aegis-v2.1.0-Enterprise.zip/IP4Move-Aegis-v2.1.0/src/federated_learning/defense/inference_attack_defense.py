"""
推理攻击防御模块

该模块实现了联邦学习中的推理攻击防御技术，包括成员推理攻击防御和属性推理攻击防御。
用于保护训练数据的隐私，防止攻击者从模型中推断出敏感信息。

使用numpy进行所有计算，不依赖PyTorch。
"""

import numpy as np
from typing import Optional, Tuple, List, Dict, Union, Callable
from collections import defaultdict
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MembershipInferenceDefense:
    """
    成员推理攻击防御类

    该类实现了多种成员推理攻击防御方法，用于防止攻击者判断某个样本
    是否被用于训练模型。支持基于差分隐私、模型正则化和输出扰动等防御策略。

    Attributes:
        defense_method (str): 防御方法
        epsilon (float): 隐私预算参数
        noise_scale (float): 噪声规模

    Examples:
        >>> defense = MembershipInferenceDefense(defense_method='dp', epsilon=1.0)
        >>> predictions = np.random.randn(100, 10)
        >>> protected = defense.protect_outputs(predictions)
    """

    def __init__(self, defense_method: str = 'dp',
                 epsilon: float = 1.0,
                 noise_scale: Optional[float] = None,
                 temperature: float = 2.0):
        """
        初始化成员推理防御器

        Args:
            defense_method: 防御方法，可选 'dp', 'temperature', 'topk', 'mixup'
            epsilon: 隐私预算参数，用于差分隐私，默认1.0
            noise_scale: 噪声规模，如果不指定则根据epsilon计算
            temperature: 温度参数，用于温度缩放防御，默认2.0

        Raises:
            ValueError: 当参数设置不合法时
        """
        valid_methods = ['dp', 'temperature', 'topk', 'mixup', 'ensemble']
        if defense_method not in valid_methods:
            raise ValueError(f"防御方法必须是 {valid_methods} 之一，当前值: {defense_method}")

        if epsilon <= 0:
            raise ValueError(f"隐私预算epsilon必须为正数，当前值: {epsilon}")

        if noise_scale is not None and noise_scale < 0:
            raise ValueError(f"噪声规模必须非负，当前值: {noise_scale}")

        if temperature <= 0:
            raise ValueError(f"温度参数必须为正数，当前值: {temperature}")

        self.defense_method = defense_method
        self.epsilon = epsilon
        self.noise_scale = noise_scale if noise_scale is not None else 1.0 / epsilon
        self.temperature = temperature

        logger.info(f"MembershipInferenceDefense初始化完成，方法: {defense_method}, epsilon: {epsilon}")

    def protect_outputs(self, predictions: np.ndarray,
                        labels: Optional[np.ndarray] = None) -> np.ndarray:
        """
        保护模型输出

        对模型输出应用防御机制，减少成员推理攻击的风险。

        Args:
            predictions: 模型预测输出，形状为 (n_samples, n_classes) 或 (n_samples,)
            labels: 真实标签，某些防御方法需要，可选

        Returns:
            np.ndarray: 保护后的预测输出

        Raises:
            TypeError: 当输入类型不正确时
            ValueError: 当输入数据不合法时
        """
        try:
            if not isinstance(predictions, np.ndarray):
                raise TypeError(f"predictions必须是numpy.ndarray类型，当前类型: {type(predictions)}")

            if predictions.size == 0:
                raise ValueError("predictions不能为空")

            # 根据防御方法选择对应策略
            if self.defense_method == 'dp':
                protected = self._apply_dp_noise(predictions)
            elif self.defense_method == 'temperature':
                protected = self._apply_temperature_scaling(predictions)
            elif self.defense_method == 'topk':
                protected = self._apply_topk_confusion(predictions)
            elif self.defense_method == 'mixup':
                if labels is None:
                    raise ValueError("mixup防御方法需要提供标签")
                protected = self._apply_mixup(predictions, labels)
            elif self.defense_method == 'ensemble':
                protected = self._apply_ensemble_defense(predictions)
            else:
                raise ValueError(f"未知的防御方法: {self.defense_method}")

            logger.debug(f"输出保护完成，方法: {self.defense_method}")
            return protected

        except Exception as e:
            logger.error(f"保护输出失败: {str(e)}")
            raise

    def _apply_dp_noise(self, predictions: np.ndarray) -> np.ndarray:
        """
        应用差分隐私噪声

        向预测结果添加拉普拉斯噪声。

        Args:
            predictions: 原始预测

        Returns:
            np.ndarray: 添加噪声后的预测
        """
        # 计算灵敏度（假设为1）
        sensitivity = 1.0

        # 计算噪声规模
        scale = sensitivity / self.epsilon

        # 添加拉普拉斯噪声
        noise = np.random.laplace(0, scale, predictions.shape)
        noisy_predictions = predictions + noise

        # 如果是概率分布，需要重新归一化
        if predictions.ndim > 1 and predictions.shape[1] > 1:
            # softmax输出，确保非负并归一化
            noisy_predictions = np.maximum(noisy_predictions, 0)
            row_sums = noisy_predictions.sum(axis=1, keepdims=True)
            noisy_predictions = noisy_predictions / np.where(row_sums > 0, row_sums, 1)
        elif predictions.ndim > 1 and predictions.shape[1] == 1:
            # 二分类概率，裁剪到[0, 1]
            noisy_predictions = np.clip(noisy_predictions, 0, 1)

        return noisy_predictions

    def _apply_temperature_scaling(self, predictions: np.ndarray) -> np.ndarray:
        """
        应用温度缩放

        通过温度参数平滑softmax输出，降低模型置信度。

        Args:
            predictions: 原始预测（logits或概率）

        Returns:
            np.ndarray: 温度缩放后的预测
        """
        if predictions.ndim == 1 or (predictions.ndim == 2 and predictions.shape[1] == 1):
            # 二分类情况
            if predictions.ndim == 1:
                predictions = predictions.reshape(-1, 1)

            # 假设输入是logits
            probs = 1 / (1 + np.exp(-predictions / self.temperature))
            return probs.flatten() if predictions.shape[1] == 1 else probs
        else:
            # 多分类情况，假设输入是logits
            # 应用温度缩放
            scaled_logits = predictions / self.temperature

            # 应用softmax
            exp_logits = np.exp(scaled_logits - np.max(scaled_logits, axis=1, keepdims=True))
            probs = exp_logits / np.sum(exp_logits, axis=1, keepdims=True)

            return probs

    def _apply_topk_confusion(self, predictions: np.ndarray, k: int = 5) -> np.ndarray:
        """
        应用Top-K混淆

        只保留前k个最大概率，其余置为均匀分布。

        Args:
            predictions: 原始预测（概率分布）
            k: 保留的top类别数

        Returns:
            np.ndarray: 混淆后的预测
        """
        if predictions.ndim == 1:
            predictions = predictions.reshape(1, -1)

        n_samples, n_classes = predictions.shape

        if n_classes <= k:
            return predictions

        # 创建混淆后的输出
        confused = np.zeros_like(predictions)

        for i in range(n_samples):
            # 获取top-k索引
            topk_indices = np.argsort(predictions[i])[-k:]

            # 保留top-k概率
            confused[i, topk_indices] = predictions[i, topk_indices]

            # 归一化
            sum_topk = np.sum(confused[i])
            if sum_topk > 0:
                confused[i] = confused[i] / sum_topk

        return confused

    def _apply_mixup(self, predictions: np.ndarray,
                     labels: np.ndarray, alpha: float = 0.2) -> np.ndarray:
        """
        应用Mixup防御

        将预测与均匀分布混合，降低置信度。

        Args:
            predictions: 原始预测
            labels: 真实标签
            alpha: 混合系数

        Returns:
            np.ndarray: 混合后的预测
        """
        if predictions.ndim == 1:
            predictions = predictions.reshape(1, -1)

        n_samples, n_classes = predictions.shape

        # 创建均匀分布
        uniform = np.ones_like(predictions) / n_classes

        # 混合
        mixed = (1 - alpha) * predictions + alpha * uniform

        return mixed

    def _apply_ensemble_defense(self, predictions: np.ndarray) -> np.ndarray:
        """
        应用集成防御

        结合多种防御方法。

        Args:
            predictions: 原始预测

        Returns:
            np.ndarray: 防御后的预测
        """
        # 应用温度缩放
        temp_scaled = self._apply_temperature_scaling(predictions.copy())

        # 应用Top-K混淆
        topk_confused = self._apply_topk_confusion(temp_scaled)

        # 添加少量噪声
        noise_scale = self.noise_scale * 0.1
        noise = np.random.laplace(0, noise_scale, topk_confused.shape)
        protected = topk_confused + noise

        # 确保非负并归一化
        if protected.ndim > 1 and protected.shape[1] > 1:
            protected = np.maximum(protected, 0)
            row_sums = protected.sum(axis=1, keepdims=True)
            protected = protected / np.where(row_sums > 0, row_sums, 1)

        return protected

    def compute_privacy_loss(self, original: np.ndarray,
                            protected: np.ndarray) -> dict:
        """
        计算隐私保护带来的效用损失

        Args:
            original: 原始预测
            protected: 保护后的预测

        Returns:
            dict: 包含效用损失统计的字典
        """
        try:
            # 计算KL散度
            # 添加小值避免log(0)
            eps = 1e-10
            original_safe = np.clip(original, eps, 1 - eps)
            protected_safe = np.clip(protected, eps, 1 - eps)

            if original.ndim == 1:
                kl_div = np.sum(original_safe * np.log(original_safe / protected_safe))
            else:
                kl_div = np.mean(np.sum(original_safe * np.log(original_safe / protected_safe), axis=1))

            # 计算准确率变化（假设是分类任务）
            original_preds = np.argmax(original, axis=1) if original.ndim > 1 else (original > 0.5).astype(int)
            protected_preds = np.argmax(protected, axis=1) if protected.ndim > 1 else (protected > 0.5).astype(int)

            # 计算预测变化比例
            prediction_change = np.mean(original_preds != protected_preds)

            # 计算置信度变化
            if original.ndim > 1:
                original_conf = np.max(original, axis=1)
                protected_conf = np.max(protected, axis=1)
            else:
                original_conf = np.maximum(original, 1 - original)
                protected_conf = np.maximum(protected, 1 - protected)

            confidence_change = np.mean(original_conf - protected_conf)

            return {
                "kl_divergence": float(kl_div),
                "prediction_change_ratio": float(prediction_change),
                "confidence_reduction": float(confidence_change),
                "mean_original_confidence": float(np.mean(original_conf)),
                "mean_protected_confidence": float(np.mean(protected_conf))
            }

        except Exception as e:
            logger.error(f"计算隐私损失失败: {str(e)}")
            raise

    def evaluate_defense_strength(self, predictions: np.ndarray,
                                  membership_labels: np.ndarray) -> dict:
        """
        评估防御强度

        模拟成员推理攻击并评估防御效果。

        Args:
            predictions: 模型预测置信度
            membership_labels: 真实的成员标签（1表示成员，0表示非成员）

        Returns:
            dict: 包含防御评估指标的字典
        """
        try:
            # 使用预测置信度作为攻击特征
            # 成员样本通常有更高的置信度
            if predictions.ndim > 1:
                confidences = np.max(predictions, axis=1)
            else:
                confidences = predictions

            # 计算攻击准确率（基于阈值）
            threshold = np.median(confidences)
            attack_preds = (confidences > threshold).astype(int)
            attack_accuracy = np.mean(attack_preds == membership_labels)

            # 计算AUC近似值
            member_conf = confidences[membership_labels == 1]
            non_member_conf = confidences[membership_labels == 0]

            # 简单的AUC估计：成员样本置信度大于非成员样本的概率
            auc_estimate = 0.0
            if len(member_conf) > 0 and len(non_member_conf) > 0:
                auc_estimate = np.mean(member_conf[:, None] > non_member_conf[None, :])

            return {
                "attack_accuracy": float(attack_accuracy),
                "auc_estimate": float(auc_estimate),
                "mean_member_confidence": float(np.mean(member_conf)) if len(member_conf) > 0 else 0,
                "mean_non_member_confidence": float(np.mean(non_member_conf)) if len(non_member_conf) > 0 else 0,
                "defense_effectiveness": float(1.0 - abs(attack_accuracy - 0.5) * 2)  # 越接近0.5越有效
            }

        except Exception as e:
            logger.error(f"评估防御强度失败: {str(e)}")
            raise


class AttributeInferenceDefense:
    """
    属性推理攻击防御类

    该类实现了多种属性推理攻击防御方法，用于防止攻击者从模型中
    推断出训练数据的敏感属性。支持基于差分隐私、特征扰动和对抗训练等防御策略。

    Attributes:
        defense_method (str): 防御方法
        epsilon (float): 隐私预算参数
        sensitive_attr_indices (List[int]): 敏感属性索引列表

    Examples:
        >>> defense = AttributeInferenceDefense(defense_method='feature_noise', epsilon=1.0)
        >>> features = np.random.randn(100, 20)
        >>> protected = defense.protect_features(features, sensitive_indices=[0, 1])
    """

    def __init__(self, defense_method: str = 'feature_noise',
                 epsilon: float = 1.0,
                 noise_scale: Optional[float] = None,
                 correlation_threshold: float = 0.1):
        """
        初始化属性推理防御器

        Args:
            defense_method: 防御方法，可选 'feature_noise', 'feature_dropout', 'adversarial', 'pca'
            epsilon: 隐私预算参数，默认1.0
            noise_scale: 噪声规模，如果不指定则根据epsilon计算
            correlation_threshold: 相关性阈值，用于特征选择，默认0.1

        Raises:
            ValueError: 当参数设置不合法时
        """
        valid_methods = ['feature_noise', 'feature_dropout', 'adversarial', 'pca', 'quantization']
        if defense_method not in valid_methods:
            raise ValueError(f"防御方法必须是 {valid_methods} 之一，当前值: {defense_method}")

        if epsilon <= 0:
            raise ValueError(f"隐私预算epsilon必须为正数，当前值: {epsilon}")

        if correlation_threshold < 0 or correlation_threshold > 1:
            raise ValueError(f"相关性阈值必须在[0, 1]范围内，当前值: {correlation_threshold}")

        self.defense_method = defense_method
        self.epsilon = epsilon
        self.noise_scale = noise_scale if noise_scale is not None else 1.0 / epsilon
        self.correlation_threshold = correlation_threshold
        self._projection_matrix = None
        self._sensitive_attrs = None

        logger.info(f"AttributeInferenceDefense初始化完成，方法: {defense_method}, epsilon: {epsilon}")

    def protect_features(self, features: np.ndarray,
                         sensitive_indices: Optional[List[int]] = None,
                         labels: Optional[np.ndarray] = None) -> np.ndarray:
        """
        保护特征数据

        对特征应用防御机制，减少属性推理攻击的风险。

        Args:
            features: 特征矩阵，形状为 (n_samples, n_features)
            sensitive_indices: 敏感属性索引列表，可选
            labels: 标签，某些防御方法需要，可选

        Returns:
            np.ndarray: 保护后的特征

        Raises:
            TypeError: 当输入类型不正确时
            ValueError: 当输入数据不合法时
        """
        try:
            if not isinstance(features, np.ndarray):
                raise TypeError(f"features必须是numpy.ndarray类型，当前类型: {type(features)}")

            if features.ndim != 2:
                raise ValueError(f"features必须是二维数组，当前维度: {features.ndim}")

            self._sensitive_attrs = sensitive_indices

            # 根据防御方法选择对应策略
            if self.defense_method == 'feature_noise':
                protected = self._apply_feature_noise(features, sensitive_indices)
            elif self.defense_method == 'feature_dropout':
                protected = self._apply_feature_dropout(features, sensitive_indices)
            elif self.defense_method == 'adversarial':
                if labels is None:
                    raise ValueError("adversarial防御方法需要提供标签")
                protected = self._apply_adversarial_perturbation(features, labels)
            elif self.defense_method == 'pca':
                protected = self._apply_pca_projection(features)
            elif self.defense_method == 'quantization':
                protected = self._apply_quantization(features)
            else:
                raise ValueError(f"未知的防御方法: {self.defense_method}")

            logger.debug(f"特征保护完成，方法: {self.defense_method}")
            return protected

        except Exception as e:
            logger.error(f"保护特征失败: {str(e)}")
            raise

    def _apply_feature_noise(self, features: np.ndarray,
                             sensitive_indices: Optional[List[int]] = None) -> np.ndarray:
        """
        向特征添加噪声

        向敏感特征或全部特征添加拉普拉斯噪声。

        Args:
            features: 原始特征
            sensitive_indices: 敏感属性索引

        Returns:
            np.ndarray: 添加噪声后的特征
        """
        protected = features.copy()

        if sensitive_indices is not None and len(sensitive_indices) > 0:
            # 只向敏感属性添加噪声
            for idx in sensitive_indices:
                if idx < features.shape[1]:
                    # 计算该特征的灵敏度（使用范围作为估计）
                    feature_range = np.max(features[:, idx]) - np.min(features[:, idx])
                    sensitivity = feature_range if feature_range > 0 else 1.0

                    # 计算噪声规模
                    scale = sensitivity / self.epsilon

                    # 添加噪声
                    noise = np.random.laplace(0, scale, features.shape[0])
                    protected[:, idx] = protected[:, idx] + noise
        else:
            # 向所有特征添加噪声
            for i in range(features.shape[1]):
                feature_range = np.max(features[:, i]) - np.min(features[:, i])
                sensitivity = feature_range if feature_range > 0 else 1.0
                scale = sensitivity / self.epsilon
                noise = np.random.laplace(0, scale, features.shape[0])
                protected[:, i] = protected[:, i] + noise

        return protected

    def _apply_feature_dropout(self, features: np.ndarray,
                               sensitive_indices: Optional[List[int]] = None,
                               dropout_rate: float = 0.1) -> np.ndarray:
        """
        应用特征丢弃

        随机将部分特征值置为零。

        Args:
            features: 原始特征
            sensitive_indices: 敏感属性索引
            dropout_rate: 丢弃率

        Returns:
            np.ndarray: 丢弃后的特征
        """
        protected = features.copy()

        if sensitive_indices is not None and len(sensitive_indices) > 0:
            # 主要对敏感属性进行丢弃
            for idx in sensitive_indices:
                if idx < features.shape[1]:
                    mask = np.random.random(features.shape[0]) > dropout_rate
                    protected[:, idx] = protected[:, idx] * mask
        else:
            # 对所有特征进行随机丢弃
            mask = np.random.random(features.shape) > dropout_rate
            protected = protected * mask

        return protected

    def _apply_adversarial_perturbation(self, features: np.ndarray,
                                        labels: np.ndarray,
                                        epsilon: float = 0.01) -> np.ndarray:
        """
        应用对抗扰动

        添加对抗性扰动来混淆属性推理攻击。

        Args:
            features: 原始特征
            labels: 标签
            epsilon: 扰动强度

        Returns:
            np.ndarray: 扰动后的特征
        """
        # 简化版本：添加与标签相关的随机扰动
        protected = features.copy()

        # 为每个类别添加不同的扰动模式
        unique_labels = np.unique(labels)
        for label in unique_labels:
            mask = labels == label
            n_samples = np.sum(mask)

            if n_samples > 0:
                # 添加随机扰动
                perturbation = np.random.normal(0, epsilon, (n_samples, features.shape[1]))
                protected[mask] = protected[mask] + perturbation

        return protected

    def _apply_pca_projection(self, features: np.ndarray,
                              n_components: Optional[int] = None) -> np.ndarray:
        """
        应用PCA投影

        将特征投影到低维空间，减少敏感信息泄露。

        Args:
            features: 原始特征
            n_components: 主成分数量

        Returns:
            np.ndarray: 投影后的特征
        """
        n_samples, n_features = features.shape

        if n_components is None:
            n_components = max(1, n_features // 2)

        n_components = min(n_components, n_features, n_samples)

        # 中心化
        mean = np.mean(features, axis=0)
        centered = features - mean

        # 计算协方差矩阵
        cov = np.dot(centered.T, centered) / (n_samples - 1)

        # 特征值分解
        eigenvalues, eigenvectors = np.linalg.eigh(cov)

        # 选择前n_components个最大特征值对应的特征向量
        idx = np.argsort(eigenvalues)[::-1][:n_components]
        self._projection_matrix = eigenvectors[:, idx]

        # 投影
        projected = np.dot(centered, self._projection_matrix)

        return projected

    def _apply_quantization(self, features: np.ndarray,
                           n_bins: int = 10) -> np.ndarray:
        """
        应用特征量化

        将连续特征值量化为离散值。

        Args:
            features: 原始特征
            n_bins: 量化桶数量

        Returns:
            np.ndarray: 量化后的特征
        """
        protected = np.zeros_like(features)

        for i in range(features.shape[1]):
            feature_min = np.min(features[:, i])
            feature_max = np.max(features[:, i])

            if feature_max - feature_min < 1e-10:
                protected[:, i] = features[:, i]
            else:
                # 量化
                bins = np.linspace(feature_min, feature_max, n_bins + 1)
                digitized = np.digitize(features[:, i], bins)

                # 使用桶中心值
                bin_centers = (bins[:-1] + bins[1:]) / 2
                protected[:, i] = bin_centers[np.clip(digitized - 1, 0, n_bins - 1)]

        return protected

    def compute_mutual_information(self, features: np.ndarray,
                                   sensitive_attrs: np.ndarray) -> dict:
        """
        计算特征与敏感属性的互信息

        Args:
            features: 特征矩阵
            sensitive_attrs: 敏感属性值

        Returns:
            dict: 包含互信息统计的字典
        """
        try:
            # 简化版本：使用相关性作为互信息的近似
            mi_scores = []

            for i in range(features.shape[1]):
                # 计算皮尔逊相关系数
                if np.std(features[:, i]) > 1e-10 and np.std(sensitive_attrs) > 1e-10:
                    corr = np.corrcoef(features[:, i], sensitive_attrs)[0, 1]
                    # 互信息近似
                    mi = 0.5 * np.log(1 / (1 - corr**2 + 1e-10))
                    mi_scores.append(mi)
                else:
                    mi_scores.append(0)

            mi_scores = np.array(mi_scores)

            return {
                "mean_mutual_information": float(np.mean(mi_scores)),
                "max_mutual_information": float(np.max(mi_scores)),
                "feature_mi_scores": mi_scores.tolist(),
                "high_mi_features": np.where(mi_scores > self.correlation_threshold)[0].tolist()
            }

        except Exception as e:
            logger.error(f"计算互信息失败: {str(e)}")
            raise

    def evaluate_privacy_utility_tradeoff(self, original_features: np.ndarray,
                                          protected_features: np.ndarray,
                                          labels: np.ndarray) -> dict:
        """
        评估隐私-效用权衡

        Args:
            original_features: 原始特征
            protected_features: 保护后的特征
            labels: 标签

        Returns:
            dict: 包含权衡指标的字典
        """
        try:
            # 计算特征变化
            feature_change = np.linalg.norm(original_features - protected_features, axis=1)
            mean_change = np.mean(feature_change)

            # 计算特征相关性保持程度
            if original_features.shape == protected_features.shape:
                correlations = []
                for i in range(original_features.shape[1]):
                    if np.std(original_features[:, i]) > 1e-10 and np.std(protected_features[:, i]) > 1e-10:
                        corr = np.corrcoef(original_features[:, i], protected_features[:, i])[0, 1]
                        correlations.append(corr)
                mean_correlation = np.mean(correlations) if correlations else 0
            else:
                mean_correlation = 0  # 形状改变时无法直接比较

            # 计算类别可分性（简化版本）
            unique_labels = np.unique(labels)
            if len(unique_labels) > 1 and original_features.shape == protected_features.shape:
                # 计算类间距离与类内距离的比值
                original_separability = self._compute_class_separability(original_features, labels)
                protected_separability = self._compute_class_separability(protected_features, labels)
                separability_ratio = protected_separability / (original_separability + 1e-10)
            else:
                separability_ratio = 1.0

            return {
                "mean_feature_change": float(mean_change),
                "mean_feature_correlation": float(mean_correlation),
                "separability_ratio": float(separability_ratio),
                "privacy_utility_score": float((mean_correlation + separability_ratio) / 2)
            }

        except Exception as e:
            logger.error(f"评估隐私-效用权衡失败: {str(e)}")
            raise

    def _compute_class_separability(self, features: np.ndarray, labels: np.ndarray) -> float:
        """
        计算类别可分性

        Args:
            features: 特征
            labels: 标签

        Returns:
            float: 可分性分数
        """
        unique_labels = np.unique(labels)
        if len(unique_labels) < 2:
            return 0.0

        # 计算每个类的中心
        class_centers = []
        for label in unique_labels:
            mask = labels == label
            center = np.mean(features[mask], axis=0)
            class_centers.append(center)

        # 计算类间距离
        between_class_dist = 0
        count = 0
        for i in range(len(class_centers)):
            for j in range(i + 1, len(class_centers)):
                between_class_dist += np.linalg.norm(class_centers[i] - class_centers[j])
                count += 1

        avg_between_dist = between_class_dist / count if count > 0 else 0

        # 计算类内距离
        within_class_dist = 0
        for label, center in zip(unique_labels, class_centers):
            mask = labels == label
            dists = np.linalg.norm(features[mask] - center, axis=1)
            within_class_dist += np.mean(dists)

        avg_within_dist = within_class_dist / len(unique_labels)

        # 可分性 = 类间距离 / 类内距离
        separability = avg_between_dist / (avg_within_dist + 1e-10)

        return separability


if __name__ == "__main__":
    # 简单的测试代码
    print("测试推理攻击防御模块...")

    # 测试MembershipInferenceDefense
    print("\n1. 测试MembershipInferenceDefense:")
    defense = MembershipInferenceDefense(defense_method='temperature', epsilon=1.0)

    # 模拟模型输出（softmax概率）
    predictions = np.random.rand(100, 10)
    predictions = predictions / predictions.sum(axis=1, keepdims=True)

    protected = defense.protect_outputs(predictions)

    # 计算隐私损失
    loss = defense.compute_privacy_loss(predictions, protected)
    print(f"   KL散度: {loss['kl_divergence']:.4f}")
    print(f"   置信度降低: {loss['confidence_reduction']:.4f}")

    # 测试防御强度评估
    membership_labels = np.random.randint(0, 2, 100)
    strength = defense.evaluate_defense_strength(protected, membership_labels)
    print(f"   攻击准确率: {strength['attack_accuracy']:.4f}")
    print(f"   防御有效性: {strength['defense_effectiveness']:.4f}")

    # 测试AttributeInferenceDefense
    print("\n2. 测试AttributeInferenceDefense:")
    attr_defense = AttributeInferenceDefense(defense_method='feature_noise', epsilon=1.0)

    features = np.random.randn(100, 20)
    labels = np.random.randint(0, 2, 100)

    protected_features = attr_defense.protect_features(features, sensitive_indices=[0, 1, 2])

    # 计算互信息
    sensitive_attrs = np.random.randint(0, 2, 100)
    mi_info = attr_defense.compute_mutual_information(protected_features, sensitive_attrs)
    print(f"   平均互信息: {mi_info['mean_mutual_information']:.4f}")
    print(f"   高互信息特征数: {len(mi_info['high_mi_features'])}")

    # 评估隐私-效用权衡
    tradeoff = attr_defense.evaluate_privacy_utility_tradeoff(features, protected_features, labels)
    print(f"   特征变化: {tradeoff['mean_feature_change']:.4f}")
    print(f"   隐私-效用分数: {tradeoff['privacy_utility_score']:.4f}")

    print("\n所有测试完成!")
