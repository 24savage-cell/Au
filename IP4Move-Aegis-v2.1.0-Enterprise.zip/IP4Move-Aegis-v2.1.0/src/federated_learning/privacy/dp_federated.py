"""
差分隐私联邦学习模块

本模块实现了差分隐私保护的联邦学习算法，包括DP-FedAvg等核心算法，
提供梯度裁剪、噪声添加等隐私保护机制。

Classes:
    DPFederatedLearning: 差分隐私联邦学习主类
    DPFedAvg: 差分隐私FedAvg算法实现

Example:
    >>> from dp_federated import DPFedAvg
    >>> dp_fedavg = DPFedAvg(
    ...     num_clients=10,
    ...     noise_multiplier=1.0,
    ...     max_grad_norm=1.0,
    ...     delta=1e-5
    ... )
    >>> dp_fedavg.train_round(client_updates)

Author: IP4Move Team
Version: 1.0.5
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Union, Callable
from dataclasses import dataclass
from abc import ABC, abstractmethod
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class PrivacyBudget:
    """
    隐私预算配置类
    
    用于管理和跟踪差分隐私的隐私预算消耗情况。
    
    Attributes:
        epsilon (float): 隐私预算参数epsilon，控制隐私保护强度
        delta (float): 隐私预算参数delta，表示违反严格差分隐私的概率
        spent_epsilon (float): 已消耗的epsilon预算
        spent_delta (float): 已消耗的delta预算
        
    Example:
        >>> budget = PrivacyBudget(epsilon=1.0, delta=1e-5)
        >>> print(f"剩余预算: ε={budget.epsilon - budget.spent_epsilon}")
    """
    epsilon: float
    delta: float
    spent_epsilon: float = 0.0
    spent_delta: float = 0.0
    
    def __post_init__(self):
        """验证隐私预算参数的合法性"""
        if self.epsilon <= 0:
            raise ValueError(f"epsilon必须为正数，当前值: {self.epsilon}")
        if self.delta <= 0 or self.delta >= 1:
            raise ValueError(f"delta必须在(0, 1)范围内，当前值: {self.delta}")
    
    @property
    def remaining_epsilon(self) -> float:
        """返回剩余的epsilon预算"""
        return max(0.0, self.epsilon - self.spent_epsilon)
    
    @property
    def remaining_delta(self) -> float:
        """返回剩余的delta预算"""
        return max(0.0, self.delta - self.spent_delta)
    
    def spend_budget(self, epsilon_cost: float, delta_cost: float) -> None:
        """
        消耗隐私预算
        
        Args:
            epsilon_cost: 本次操作消耗的epsilon预算
            delta_cost: 本次操作消耗的delta预算
            
        Raises:
            ValueError: 当预算不足时抛出异常
        """
        if epsilon_cost > self.remaining_epsilon:
            raise ValueError(
                f"epsilon预算不足: 需要{epsilon_cost}, 剩余{self.remaining_epsilon}"
            )
        if delta_cost > self.remaining_delta:
            raise ValueError(
                f"delta预算不足: 需要{delta_cost}, 剩余{self.remaining_delta}"
            )
        self.spent_epsilon += epsilon_cost
        self.spent_delta += delta_cost


@dataclass
class DPConfig:
    """
    差分隐私配置类
    
    用于配置差分隐私算法的各项参数。
    
    Attributes:
        noise_multiplier (float): 噪声乘数，控制噪声强度
        max_grad_norm (float): 梯度裁剪的最大范数
        target_delta (float): 目标delta值
        max_steps (Optional[int]): 最大训练步数，用于隐私预算计算
        secure_rng (bool): 是否使用安全随机数生成器
        
    Example:
        >>> config = DPConfig(
        ...     noise_multiplier=1.0,
        ...     max_grad_norm=1.0,
        ...     target_delta=1e-5
        ... )
    """
    noise_multiplier: float
    max_grad_norm: float
    target_delta: float
    max_steps: Optional[int] = None
    secure_rng: bool = False
    
    def __post_init__(self):
        """验证配置参数的合法性"""
        if self.noise_multiplier < 0:
            raise ValueError(f"noise_multiplier必须非负，当前值: {self.noise_multiplier}")
        if self.max_grad_norm <= 0:
            raise ValueError(f"max_grad_norm必须为正数，当前值: {self.max_grad_norm}")
        if self.target_delta <= 0 or self.target_delta >= 1:
            raise ValueError(f"target_delta必须在(0, 1)范围内，当前值: {self.target_delta}")


class DPFederatedLearning(ABC):
    """
    差分隐私联邦学习抽象基类
    
    定义了差分隐私联邦学习的基本接口和通用功能，包括梯度裁剪、
    噪声添加等核心隐私保护机制。
    
    Attributes:
        config (DPConfig): 差分隐私配置
        privacy_budget (PrivacyBudget): 隐私预算管理
        rng (np.random.Generator): 随机数生成器
        
    Methods:
        train_round: 执行一轮差分隐私训练
        aggregate: 聚合客户端更新
        clip_gradients: 裁剪梯度
        add_noise: 添加差分隐私噪声
        
    Example:
        >>> class MyDPFL(DPFederatedLearning):
        ...     def train_round(self, client_updates):
        ...         # 实现具体的训练逻辑
        ...         pass
    """
    
    def __init__(
        self,
        config: DPConfig,
        privacy_budget: Optional[PrivacyBudget] = None
    ):
        """
        初始化差分隐私联邦学习实例
        
        Args:
            config: 差分隐私配置
            privacy_budget: 隐私预算，如不提供则根据config自动创建
            
        Raises:
            TypeError: 当config类型不正确时
        """
        if not isinstance(config, DPConfig):
            raise TypeError(f"config必须是DPConfig类型，当前类型: {type(config)}")
        
        self.config = config
        
        if privacy_budget is None:
            # 根据max_steps估算epsilon
            epsilon = self._compute_epsilon()
            self.privacy_budget = PrivacyBudget(
                epsilon=epsilon,
                delta=config.target_delta
            )
        else:
            self.privacy_budget = privacy_budget
        
        # 初始化随机数生成器
        if config.secure_rng:
            self.rng = np.random.default_rng()
        else:
            self.rng = np.random.default_rng(seed=42)
        
        logger.info(f"初始化DPFederatedLearning: noise_multiplier={config.noise_multiplier}")
    
    def _compute_epsilon(self) -> float:
        """
        根据配置计算隐私预算epsilon
        
        Returns:
            计算得到的epsilon值
        """
        if self.config.max_steps is None:
            return 10.0  # 默认值
        
        # 使用简单的矩会计方法估算epsilon
        # 实际应用中应使用更精确的隐私会计方法
        q = 1.0  # 采样率，假设为全批量
        steps = self.config.max_steps
        sigma = self.config.noise_multiplier
        
        # 简化的epsilon计算
        epsilon = q * np.sqrt(steps) / sigma
        return float(epsilon)
    
    def clip_gradients(
        self,
        gradients: Union[np.ndarray, List[np.ndarray], Dict[str, np.ndarray]],
        max_norm: Optional[float] = None
    ) -> Union[np.ndarray, List[np.ndarray], Dict[str, np.ndarray]]:
        """
        裁剪梯度范数
        
        对梯度进行L2范数裁剪，确保梯度范数不超过max_norm。
        这是差分隐私的关键步骤，用于控制单个样本对模型的影响。
        
        Args:
            gradients: 输入梯度，可以是单个数组、数组列表或字典
            max_norm: 最大梯度范数，如为None则使用config中的值
            
        Returns:
            裁剪后的梯度，类型与输入相同
            
        Raises:
            ValueError: 当梯度包含NaN或Inf时
            TypeError: 当输入类型不支持时
            
        Example:
            >>> gradients = np.random.randn(10, 5)
            >>> clipped = dp_fl.clip_gradients(gradients, max_norm=1.0)
        """
        if max_norm is None:
            max_norm = self.config.max_grad_norm
        
        if max_norm <= 0:
            raise ValueError(f"max_norm必须为正数，当前值: {max_norm}")
        
        # 处理单个数组
        if isinstance(gradients, np.ndarray):
            return self._clip_single_array(gradients, max_norm)
        
        # 处理数组列表
        elif isinstance(gradients, list):
            return [self._clip_single_array(g, max_norm) for g in gradients]
        
        # 处理字典
        elif isinstance(gradients, dict):
            return {k: self._clip_single_array(v, max_norm) 
                   for k, v in gradients.items()}
        
        else:
            raise TypeError(f"不支持的梯度类型: {type(gradients)}")
    
    def _clip_single_array(
        self,
        arr: np.ndarray,
        max_norm: float
    ) -> np.ndarray:
        """
        裁剪单个数组的梯度
        
        Args:
            arr: 输入数组
            max_norm: 最大范数
            
        Returns:
            裁剪后的数组
        """
        # 检查NaN和Inf
        if np.isnan(arr).any() or np.isinf(arr).any():
            raise ValueError("梯度包含NaN或Inf值")
        
        # 计算L2范数
        norm = np.linalg.norm(arr)
        
        # 裁剪
        if norm > max_norm:
            arr = arr * (max_norm / norm)
        
        return arr
    
    def add_noise(
        self,
        arr: np.ndarray,
        noise_multiplier: Optional[float] = None,
        sensitivity: Optional[float] = None
    ) -> np.ndarray:
        """
        向数组添加差分隐私噪声
        
        添加符合差分隐私要求的高斯噪声。
        
        Args:
            arr: 输入数组
            noise_multiplier: 噪声乘数，如为None则使用config中的值
            sensitivity: 敏感度，如为None则使用max_grad_norm
            
        Returns:
            添加噪声后的数组
            
        Raises:
            ValueError: 当参数值无效时
            
        Example:
            >>> arr = np.random.randn(10, 5)
            >>> noisy = dp_fl.add_noise(arr, noise_multiplier=1.0)
        """
        if noise_multiplier is None:
            noise_multiplier = self.config.noise_multiplier
        
        if sensitivity is None:
            sensitivity = self.config.max_grad_norm
        
        if noise_multiplier < 0:
            raise ValueError(f"noise_multiplier必须非负，当前值: {noise_multiplier}")
        if sensitivity <= 0:
            raise ValueError(f"sensitivity必须为正数，当前值: {sensitivity}")
        
        # 计算噪声标准差
        noise_std = noise_multiplier * sensitivity
        
        # 生成高斯噪声
        noise = np.random.randn(*arr.shape) * noise_std
        
        return arr + noise
    
    def compute_rdp(
        self,
        alphas: List[float],
        noise_multiplier: float,
        sampling_probability: float,
        steps: int
    ) -> Dict[float, float]:
        """
        计算Rényi差分隐私(RDP)保证
        
        使用矩会计方法计算RDP参数。
        
        Args:
            alphas: RDP阶数列表
            noise_multiplier: 噪声乘数
            sampling_probability: 采样概率
            steps: 训练步数
            
        Returns:
            各阶alpha对应的epsilon值字典
            
        Example:
            >>> alphas = [1 + x / 10.0 for x in range(1, 1000)]
            >>> rdp = dp_fl.compute_rdp(alphas, 1.0, 0.01, 1000)
        """
        rdp_values = {}
        
        for alpha in alphas:
            if alpha <= 1:
                continue
            
            # 简化的RDP计算
            # 实际应用中应使用完整的矩会计公式
            rdp = alpha * (sampling_probability ** 2) / (2 * (noise_multiplier ** 2))
            rdp = rdp * steps
            rdp_values[alpha] = rdp
        
        return rdp_values
    
    def rdp_to_dp(
        self,
        rdp_values: Dict[float, float],
        delta: float
    ) -> Tuple[float, float]:
        """
        将RDP转换为(ε, δ)-差分隐私
        
        Args:
            rdp_values: RDP值字典
            delta: 目标delta值
            
        Returns:
            (epsilon, delta)元组
        """
        min_epsilon = float('inf')
        
        for alpha, rdp in rdp_values.items():
            epsilon = rdp + np.log(1 / delta) / (alpha - 1)
            min_epsilon = min(min_epsilon, epsilon)
        
        return (min_epsilon, delta)
    
    @abstractmethod
    def train_round(
        self,
        client_updates: List[Dict[str, np.ndarray]],
        **kwargs
    ) -> Dict[str, np.ndarray]:
        """
        执行一轮差分隐私训练
        
        Args:
            client_updates: 客户端更新列表
            **kwargs: 额外参数
            
        Returns:
            聚合后的模型更新
        """
        pass
    
    @abstractmethod
    def aggregate(
        self,
        client_updates: List[Dict[str, np.ndarray]],
        weights: Optional[List[float]] = None
    ) -> Dict[str, np.ndarray]:
        """
        聚合客户端更新
        
        Args:
            client_updates: 客户端更新列表
            weights: 客户端权重列表，如为None则使用均匀权重
            
        Returns:
            聚合后的模型更新
        """
        pass


class DPFedAvg(DPFederatedLearning):
    """
    差分隐私FedAvg算法实现
    
    实现了带差分隐私保护的FedAvg算法，包括梯度裁剪和噪声添加。
    
    Attributes:
        num_clients (int): 客户端数量
        local_steps (int): 本地训练步数
        batch_size (int): 批次大小
        
    Methods:
        train_round: 执行一轮DP-FedAvg训练
        aggregate: 加权聚合客户端更新
        local_update: 执行本地差分隐私训练
        
    Example:
        >>> dp_fedavg = DPFedAvg(
        ...     num_clients=10,
        ...     noise_multiplier=1.0,
        ...     max_grad_norm=1.0,
        ...     delta=1e-5,
        ...     local_steps=5
        ... )
        >>> aggregated = dp_fedavg.train_round(client_updates)
    """
    
    def __init__(
        self,
        num_clients: int,
        noise_multiplier: float,
        max_grad_norm: float,
        delta: float,
        local_steps: int = 1,
        batch_size: int = 32,
        max_steps: Optional[int] = None,
        secure_rng: bool = False,
        privacy_budget: Optional[PrivacyBudget] = None
    ):
        """
        初始化DPFedAvg实例
        
        Args:
            num_clients: 客户端数量
            noise_multiplier: 噪声乘数
            max_grad_norm: 最大梯度范数
            delta: 目标delta值
            local_steps: 本地训练步数
            batch_size: 批次大小
            max_steps: 最大训练步数
            secure_rng: 是否使用安全随机数生成器
            privacy_budget: 隐私预算
            
        Raises:
            ValueError: 当参数值无效时
        """
        if num_clients <= 0:
            raise ValueError(f"num_clients必须为正数，当前值: {num_clients}")
        if local_steps <= 0:
            raise ValueError(f"local_steps必须为正数，当前值: {local_steps}")
        if batch_size <= 0:
            raise ValueError(f"batch_size必须为正数，当前值: {batch_size}")
        
        self.num_clients = num_clients
        self.local_steps = local_steps
        self.batch_size = batch_size
        
        config = DPConfig(
            noise_multiplier=noise_multiplier,
            max_grad_norm=max_grad_norm,
            target_delta=delta,
            max_steps=max_steps,
            secure_rng=secure_rng
        )
        
        super().__init__(config, privacy_budget)
        
        logger.info(
            f"初始化DPFedAvg: num_clients={num_clients}, "
            f"noise_multiplier={noise_multiplier}, local_steps={local_steps}"
        )
    
    def train_round(
        self,
        client_updates: List[Dict[str, np.ndarray]],
        client_weights: Optional[List[float]] = None,
        add_dp_noise: bool = True
    ) -> Dict[str, np.ndarray]:
        """
        执行一轮DP-FedAvg训练
        
        流程：
        1. 裁剪每个客户端的梯度
        2. 聚合裁剪后的梯度
        3. 添加差分隐私噪声（可选）
        
        Args:
            client_updates: 客户端更新列表，每个元素是参数字典
            client_weights: 客户端权重列表，如为None则使用均匀权重
            add_dp_noise: 是否添加差分隐私噪声
            
        Returns:
            聚合后的模型更新
            
        Raises:
            ValueError: 当客户端更新为空或格式不正确时
            RuntimeError: 当隐私预算耗尽时
            
        Example:
            >>> updates = [
            ...     {'layer1.weight': np.random.randn(10, 5)},
            ...     {'layer1.weight': np.random.randn(10, 5)}
            ... ]
            >>> result = dp_fedavg.train_round(updates)
        """
        if not client_updates:
            raise ValueError("客户端更新列表不能为空")
        
        if len(client_updates) > self.num_clients:
            logger.warning(
                f"客户端更新数量({len(client_updates)})超过配置的客户端数量"
                f"({self.num_clients})"
            )
        
        # 检查隐私预算
        if self.privacy_budget.remaining_epsilon <= 0:
            raise RuntimeError("隐私预算已耗尽，无法继续训练")
        
        # 步骤1：裁剪每个客户端的梯度
        clipped_updates = []
        for i, update in enumerate(client_updates):
            try:
                clipped_update = {
                    k: self.clip_gradients(v) 
                    for k, v in update.items()
                }
                clipped_updates.append(clipped_update)
            except Exception as e:
                logger.error(f"裁剪客户端{i}的梯度时出错: {e}")
                raise
        
        # 步骤2：聚合裁剪后的梯度
        aggregated = self.aggregate(clipped_updates, client_weights)
        
        # 步骤3：添加差分隐私噪声
        if add_dp_noise:
            try:
                aggregated = {
                    k: self.add_noise(v) 
                    for k, v in aggregated.items()
                }
                
                # 更新隐私预算
                self._update_privacy_budget()
                
            except Exception as e:
                logger.error(f"添加噪声时出错: {e}")
                raise
        
        logger.info(
            f"完成一轮DP-FedAvg训练，"
            f"剩余隐私预算: ε={self.privacy_budget.remaining_epsilon:.4f}"
        )
        
        return aggregated
    
    def _update_privacy_budget(self) -> None:
        """更新隐私预算消耗"""
        # 简化的预算消耗计算
        # 实际应用中应使用更精确的隐私会计
        epsilon_cost = 1.0 / (self.config.noise_multiplier ** 2)
        delta_cost = self.config.target_delta / self.num_clients
        
        try:
            self.privacy_budget.spend_budget(epsilon_cost, delta_cost)
        except ValueError as e:
            logger.warning(f"隐私预算警告: {e}")
    
    def aggregate(
        self,
        client_updates: List[Dict[str, np.ndarray]],
        weights: Optional[List[float]] = None
    ) -> Dict[str, np.ndarray]:
        """
        加权聚合客户端更新
        
        使用加权平均方式聚合多个客户端的模型更新。
        
        Args:
            client_updates: 客户端更新列表
            weights: 客户端权重列表，如为None则使用均匀权重
            
        Returns:
            聚合后的模型更新字典
            
        Raises:
            ValueError: 当权重数量与客户端数量不匹配时
            
        Example:
            >>> updates = [
            ...     {'w': np.array([1.0, 2.0])},
            ...     {'w': np.array([3.0, 4.0])}
            ... ]
            >>> aggregated = dp_fedavg.aggregate(updates, weights=[0.3, 0.7])
        """
        if not client_updates:
            raise ValueError("客户端更新列表不能为空")
        
        num_clients = len(client_updates)
        
        # 设置权重
        if weights is None:
            weights = [1.0 / num_clients] * num_clients
        else:
            if len(weights) != num_clients:
                raise ValueError(
                    f"权重数量({len(weights)})必须与客户端数量({num_clients})匹配"
                )
            # 归一化权重
            total_weight = sum(weights)
            weights = [w / total_weight for w in weights]
        
        # 获取参数键
        param_keys = client_updates[0].keys()
        
        # 验证所有客户端更新具有相同的参数结构
        for i, update in enumerate(client_updates):
            if set(update.keys()) != set(param_keys):
                raise ValueError(f"客户端{i}的参数结构与第一个客户端不匹配")
        
        # 加权聚合
        aggregated = {}
        for key in param_keys:
            weighted_sum = None
            for i, update in enumerate(client_updates):
                weighted_param = update[key] * weights[i]
                if weighted_sum is None:
                    weighted_sum = weighted_param
                else:
                    weighted_sum = weighted_sum + weighted_param
            aggregated[key] = weighted_sum
        
        return aggregated
    
    def local_update(
        self,
        model,
        data_loader,
        optimizer,
        loss_fn: Callable,
        device: str = 'cpu'
    ) -> Dict[str, np.ndarray]:
        """
        执行本地差分隐私训练
        
        在单个客户端上执行本地训练，应用梯度裁剪。
        
        Args:
            model: 本地模型（支持numpy接口的模型）
            data_loader: 数据加载器
            optimizer: 优化器
            loss_fn: 损失函数
            device: 计算设备（numpy实现中忽略）
            
        Returns:
            本地模型更新（梯度字典）
            
        Example:
            >>> # 使用支持numpy的模型
            >>> update = dp_fedavg.local_update(
            ...     model, data_loader, optimizer, loss_fn
            ... )
        """
        # 保存初始参数
        initial_params = {}
        for name, param in model.named_parameters():
            initial_params[name] = param.copy()
        
        # 本地训练
        for step in range(self.local_steps):
            for batch_idx, (data, target) in enumerate(data_loader):
                optimizer.zero_grad()
                output = model.forward(data)
                loss = loss_fn(output, target)
                
                # 计算梯度并裁剪
                grads = model.backward(loss)
                clipped_grads = {k: self.clip_gradients(v) for k, v in grads.items()}
                
                # 应用梯度
                optimizer.step(clipped_grads)
                
                if batch_idx >= self.local_steps - 1:
                    break
        
        # 计算参数更新
        updates = {}
        for name, param in model.named_parameters():
            updates[name] = param - initial_params[name]
        
        return updates
    
    def get_privacy_spent(self) -> Dict[str, float]:
        """
        获取已消耗的隐私预算
        
        Returns:
            包含已消耗和剩余预算的字典
        """
        return {
            'spent_epsilon': self.privacy_budget.spent_epsilon,
            'spent_delta': self.privacy_budget.spent_delta,
            'remaining_epsilon': self.privacy_budget.remaining_epsilon,
            'remaining_delta': self.privacy_budget.remaining_delta,
            'total_epsilon': self.privacy_budget.epsilon,
            'total_delta': self.privacy_budget.delta
        }


# 向后兼容的别名
DPFederatedAveraging = DPFedAvg


if __name__ == "__main__":
    # 简单的测试代码
    print("测试差分隐私联邦学习模块")
    
    # 测试DPConfig
    config = DPConfig(
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        target_delta=1e-5,
        max_steps=1000
    )
    print(f"DPConfig创建成功: {config}")
    
    # 测试PrivacyBudget
    budget = PrivacyBudget(epsilon=10.0, delta=1e-5)
    print(f"PrivacyBudget创建成功: {budget}")
    
    # 测试DPFedAvg
    dp_fedavg = DPFedAvg(
        num_clients=10,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        delta=1e-5,
        local_steps=5
    )
    print(f"DPFedAvg创建成功")
    
    # 测试梯度裁剪
    test_grad = np.random.randn(5, 3)
    clipped = dp_fedavg.clip_gradients(test_grad, max_norm=1.0)
    print(f"梯度裁剪测试: 原始范数={np.linalg.norm(test_grad):.4f}, "
          f"裁剪后范数={np.linalg.norm(clipped):.4f}")
    
    # 测试噪声添加
    test_array = np.zeros((5, 3))
    noisy = dp_fedavg.add_noise(test_array, noise_multiplier=1.0)
    print(f"噪声添加测试: 噪声范数={np.linalg.norm(noisy):.4f}")
    
    # 测试聚合
    updates = [
        {'w': np.array([1.0, 2.0, 3.0])},
        {'w': np.array([4.0, 5.0, 6.0])}
    ]
    aggregated = dp_fedavg.aggregate(updates)
    print(f"聚合测试: 结果={aggregated}")
    
    print("所有测试通过!")
