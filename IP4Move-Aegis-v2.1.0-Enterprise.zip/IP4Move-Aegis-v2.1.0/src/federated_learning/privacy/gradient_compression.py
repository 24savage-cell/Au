"""
梯度压缩模块

本模块实现了联邦学习中的梯度压缩和稀疏化技术，用于减少通信开销，
同时与差分隐私模块集成，确保压缩过程不破坏隐私保护。

Classes:
    GradientCompressor: 梯度压缩器基类
    QuantizationCompressor: 量化压缩器
    SparsificationCompressor: 稀疏化压缩器
    TopKCompressor: Top-K稀疏化压缩器
    RandomKCompressor: 随机K稀疏化压缩器
    SignSGDCompressor: SignSGD压缩器

Example:
    >>> from gradient_compression import TopKCompressor
    >>> compressor = TopKCompressor(compression_ratio=0.1)
    >>> compressed = compressor.compress(gradient)
    >>> decompressed = compressor.decompress(compressed)

Author: IP4Move Team
Version: 1.0.5
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Union, Callable
from dataclasses import dataclass
from abc import ABC, abstractmethod
from enum import Enum
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class CompressionType(Enum):
    """压缩类型枚举"""
    QUANTIZATION = "quantization"      # 量化压缩
    SPARSIFICATION = "sparsification"  # 稀疏化压缩
    TOPK = "topk"                      # Top-K稀疏化
    RANDOMK = "randomk"                # 随机K稀疏化
    SIGNSGD = "signsgd"                # SignSGD压缩
    NONE = "none"                      # 无压缩


@dataclass
class CompressionConfig:
    """
    压缩配置类
    
    用于配置梯度压缩的各项参数。
    
    Attributes:
        compression_type (CompressionType): 压缩类型
        compression_ratio (float): 压缩比例，范围(0, 1]
        num_bits (int): 量化位数，用于量化压缩
        error_feedback (bool): 是否使用误差反馈
        seed (Optional[int]): 随机种子
        
    Example:
        >>> config = CompressionConfig(
        ...     compression_type=CompressionType.TOPK,
        ...     compression_ratio=0.1,
        ...     error_feedback=True
        ... )
    """
    compression_type: CompressionType = CompressionType.TOPK
    compression_ratio: float = 0.1
    num_bits: int = 8
    error_feedback: bool = True
    seed: Optional[int] = None
    
    def __post_init__(self):
        """验证配置参数的合法性"""
        if not 0 < self.compression_ratio <= 1.0:
            raise ValueError(
                f"compression_ratio必须在(0, 1]范围内，当前值: {self.compression_ratio}"
            )
        if self.num_bits < 1 or self.num_bits > 32:
            raise ValueError(
                f"num_bits必须在[1, 32]范围内，当前值: {self.num_bits}"
            )


class CompressedGradient:
    """
    压缩梯度数据类
    
    用于存储压缩后的梯度数据及相关元信息。
    
    Attributes:
        values (np.ndarray): 压缩后的梯度值
        indices (Optional[np.ndarray]): 非零元素索引（稀疏化时）
        shape (Tuple[int, ...]): 原始梯度形状
        compression_type (CompressionType): 压缩类型
        scale (Optional[float]): 量化缩放因子
        zero_point (Optional[float]): 量化零点
        
    Example:
        >>> compressed = CompressedGradient(
        ...     values=np.array([1.0, 2.0, 3.0]),
        ...     indices=np.array([0, 5, 10]),
        ...     shape=(20,),
        ...     compression_type=CompressionType.TOPK
        ... )
    """
    
    def __init__(
        self,
        values: np.ndarray,
        indices: Optional[np.ndarray],
        shape: Tuple[int, ...],
        compression_type: CompressionType,
        scale: Optional[float] = None,
        zero_point: Optional[float] = None
    ):
        self.values = values
        self.indices = indices
        self.shape = shape
        self.compression_type = compression_type
        self.scale = scale
        self.zero_point = zero_point
    
    def get_compression_ratio(self) -> float:
        """
        计算实际的压缩比例
        
        Returns:
            压缩比例，值越小表示压缩率越高
        """
        original_size = np.prod(self.shape)
        compressed_size = self.values.size
        return compressed_size / original_size


class GradientCompressor(ABC):
    """
    梯度压缩器抽象基类
    
    定义了梯度压缩的基本接口，所有具体的压缩器都应继承此类。
    
    Attributes:
        config (CompressionConfig): 压缩配置
        error_feedback (Dict): 误差反馈状态
        rng (np.random.Generator): 随机数生成器
        
    Methods:
        compress: 压缩梯度
        decompress: 解压缩梯度
        quantize: 量化梯度
        
    Example:
        >>> class MyCompressor(GradientCompressor):
        ...     def compress(self, gradient):
        ...         # 实现压缩逻辑
        ...         pass
        ...     def decompress(self, compressed):
        ...         # 实现解压缩逻辑
        ...         pass
    """
    
    def __init__(self, config: Optional[CompressionConfig] = None):
        """
        初始化梯度压缩器
        
        Args:
            config: 压缩配置，如为None则使用默认配置
        """
        if config is None:
            config = CompressionConfig()
        
        self.config = config
        self.error_feedback: Dict[str, np.ndarray] = {}
        
        # 初始化随机数生成器
        if config.seed is not None:
            self.rng = np.random.default_rng(config.seed)
        else:
            self.rng = np.random.default_rng()
        
        logger.info(f"初始化{self.__class__.__name__}: {config.compression_type.value}")
    
    @abstractmethod
    def compress(
        self,
        gradient: np.ndarray,
        name: Optional[str] = None
    ) -> CompressedGradient:
        """
        压缩梯度
        
        Args:
            gradient: 输入梯度数组
            name: 梯度名称，用于误差反馈
            
        Returns:
            压缩后的梯度数据
        """
        pass
    
    @abstractmethod
    def decompress(self, compressed: CompressedGradient) -> np.ndarray:
        """
        解压缩梯度
        
        Args:
            compressed: 压缩后的梯度数据
            
        Returns:
            解压缩后的梯度数组
        """
        pass
    
    def quantize(
        self,
        arr: np.ndarray,
        num_bits: int,
        min_val: Optional[float] = None,
        max_val: Optional[float] = None
    ) -> Tuple[np.ndarray, float, float]:
        """
        量化数组
        
        将浮点数量化为指定位数的整数。
        
        Args:
            arr: 输入数组
            num_bits: 量化位数
            min_val: 最小值，如为None则自动计算
            max_val: 最大值，如为None则自动计算
            
        Returns:
            (量化后的数组, 缩放因子, 零点)元组
            
        Raises:
            ValueError: 当参数值无效时
            
        Example:
            >>> arr = np.random.randn(10, 5)
            >>> quantized, scale, zero_point = compressor.quantize(arr, 8)
        """
        if num_bits < 1 or num_bits > 32:
            raise ValueError(f"num_bits必须在[1, 32]范围内，当前值: {num_bits}")
        
        # 自动计算范围
        if min_val is None:
            min_val = float(arr.min())
        if max_val is None:
            max_val = float(arr.max())
        
        if min_val >= max_val:
            # 所有值相同的情况
            return np.zeros_like(arr, dtype=np.int32), 1.0, min_val
        
        # 计算量化参数
        qmin = -(2 ** (num_bits - 1))
        qmax = 2 ** (num_bits - 1) - 1
        
        scale = (max_val - min_val) / (qmax - qmin)
        zero_point = qmin - min_val / scale
        zero_point = int(round(zero_point))
        zero_point = max(qmin, min(qmax, zero_point))
        
        # 量化
        quantized = np.clip(
            np.round(arr / scale + zero_point),
            qmin,
            qmax
        ).astype(np.int32)
        
        return quantized, scale, float(zero_point)
    
    def dequantize(
        self,
        quantized: np.ndarray,
        scale: float,
        zero_point: float
    ) -> np.ndarray:
        """
        反量化数组
        
        Args:
            quantized: 量化后的数组
            scale: 缩放因子
            zero_point: 零点
            
        Returns:
            反量化后的浮点数组
        """
        return (quantized.astype(np.float64) - zero_point) * scale
    
    def update_error_feedback(
        self,
        name: str,
        original: np.ndarray,
        compressed: np.ndarray
    ) -> None:
        """
        更新误差反馈
        
        计算并存储压缩误差，用于下一次迭代补偿。
        
        Args:
            name: 梯度名称
            original: 原始梯度
            compressed: 压缩后的梯度（已解压缩）
        """
        if not self.config.error_feedback:
            return
        
        error = original - compressed
        
        if name in self.error_feedback:
            self.error_feedback[name] = self.error_feedback[name] + error
        else:
            self.error_feedback[name] = error
    
    def get_error_feedback(self, name: str) -> np.ndarray:
        """
        获取误差反馈
        
        Args:
            name: 梯度名称
            
        Returns:
            误差数组，如不存在则返回零数组
        """
        if name in self.error_feedback:
            return self.error_feedback[name]
        return np.array(0.0)
    
    def compress_dict(
        self,
        gradients: Dict[str, np.ndarray]
    ) -> Dict[str, CompressedGradient]:
        """
        压缩梯度字典
        
        Args:
            gradients: 参数字典
            
        Returns:
            压缩后的参数字典
        """
        compressed = {}
        for name, gradient in gradients.items():
            compressed[name] = self.compress(gradient, name)
        return compressed
    
    def decompress_dict(
        self,
        compressed: Dict[str, CompressedGradient]
    ) -> Dict[str, np.ndarray]:
        """
        解压缩梯度字典
        
        Args:
            compressed: 压缩后的参数字典
            
        Returns:
            解压缩后的参数字典
        """
        decompressed = {}
        for name, comp in compressed.items():
            decompressed[name] = self.decompress(comp)
        return decompressed


class QuantizationCompressor(GradientCompressor):
    """
    量化压缩器
    
    使用指定位数的整数量化来压缩梯度。
    
    Attributes:
        num_bits (int): 量化位数
        
    Example:
        >>> compressor = QuantizationCompressor(num_bits=8)
        >>> compressed = compressor.compress(gradient)
    """
    
    def __init__(self, num_bits: int = 8, config: Optional[CompressionConfig] = None):
        """
        初始化量化压缩器
        
        Args:
            num_bits: 量化位数
            config: 压缩配置
        """
        if config is None:
            config = CompressionConfig(
                compression_type=CompressionType.QUANTIZATION,
                num_bits=num_bits
            )
        super().__init__(config)
        self.num_bits = num_bits
    
    def compress(
        self,
        gradient: np.ndarray,
        name: Optional[str] = None
    ) -> CompressedGradient:
        """
        量化压缩梯度
        
        Args:
            gradient: 输入梯度
            name: 梯度名称
            
        Returns:
            压缩后的梯度数据
        """
        original_shape = gradient.shape
        gradient_flat = gradient.flatten()
        
        # 应用误差反馈
        if self.config.error_feedback and name is not None:
            error = self.get_error_feedback(name)
            if error.size == 1:
                error = np.broadcast_to(error, gradient_flat.shape)
            else:
                error = error.flatten()
            gradient_flat = gradient_flat + error
        
        # 量化
        quantized, scale, zero_point = self.quantize(
            gradient_flat, self.num_bits
        )
        
        compressed = CompressedGradient(
            values=quantized,
            indices=None,
            shape=original_shape,
            compression_type=CompressionType.QUANTIZATION,
            scale=scale,
            zero_point=zero_point
        )
        
        # 更新误差反馈
        if self.config.error_feedback and name is not None:
            decompressed = self.decompress(compressed)
            self.update_error_feedback(name, gradient_flat, decompressed.flatten())
        
        return compressed
    
    def decompress(self, compressed: CompressedGradient) -> np.ndarray:
        """
        反量化解压缩
        
        Args:
            compressed: 压缩后的梯度数据
            
        Returns:
            解压缩后的梯度
        """
        if compressed.scale is None or compressed.zero_point is None:
            raise ValueError("压缩数据缺少量化参数")
        
        dequantized = self.dequantize(
            compressed.values,
            compressed.scale,
            compressed.zero_point
        )
        
        return dequantized.reshape(compressed.shape)


class TopKCompressor(GradientCompressor):
    """
    Top-K稀疏化压缩器
    
    只保留梯度中绝对值最大的K个元素，其余置零。
    
    Attributes:
        compression_ratio (float): 压缩比例
        
    Example:
        >>> compressor = TopKCompressor(compression_ratio=0.01)
        >>> compressed = compressor.compress(gradient)
    """
    
    def __init__(
        self,
        compression_ratio: float = 0.01,
        config: Optional[CompressionConfig] = None
    ):
        """
        初始化Top-K压缩器
        
        Args:
            compression_ratio: 压缩比例，保留的元素比例
            config: 压缩配置
        """
        if config is None:
            config = CompressionConfig(
                compression_type=CompressionType.TOPK,
                compression_ratio=compression_ratio
            )
        super().__init__(config)
        self.compression_ratio = compression_ratio
    
    def compress(
        self,
        gradient: np.ndarray,
        name: Optional[str] = None
    ) -> CompressedGradient:
        """
        Top-K压缩
        
        Args:
            gradient: 输入梯度
            name: 梯度名称
            
        Returns:
            压缩后的梯度数据
        """
        original_shape = gradient.shape
        gradient_flat = gradient.flatten()
        
        # 应用误差反馈
        if self.config.error_feedback and name is not None:
            error = self.get_error_feedback(name)
            if error.size == 1:
                error = np.broadcast_to(error, gradient_flat.shape)
            else:
                error = error.flatten()
            gradient_flat = gradient_flat + error
        
        # 计算K值
        num_elements = gradient_flat.size
        k = max(1, int(num_elements * self.compression_ratio))
        
        # 获取Top-K索引
        abs_gradient = np.abs(gradient_flat)
        indices = np.argpartition(abs_gradient, -k)[-k:]  # 获取最大的k个元素的索引
        indices = indices[np.argsort(-abs_gradient[indices])]  # 按绝对值降序排序
        
        # 提取Top-K值
        values = gradient_flat[indices]
        
        compressed = CompressedGradient(
            values=values,
            indices=indices,
            shape=original_shape,
            compression_type=CompressionType.TOPK
        )
        
        # 更新误差反馈
        if self.config.error_feedback and name is not None:
            decompressed = self.decompress(compressed)
            self.update_error_feedback(name, gradient_flat, decompressed.flatten())
        
        return compressed
    
    def decompress(self, compressed: CompressedGradient) -> np.ndarray:
        """
        Top-K解压缩
        
        Args:
            compressed: 压缩后的梯度数据
            
        Returns:
            解压缩后的梯度
        """
        if compressed.indices is None:
            raise ValueError("Top-K压缩数据缺少索引")
        
        decompressed = np.zeros(
            np.prod(compressed.shape),
            dtype=compressed.values.dtype
        )
        decompressed[compressed.indices] = compressed.values
        
        return decompressed.reshape(compressed.shape)


class RandomKCompressor(GradientCompressor):
    """
    随机K稀疏化压缩器
    
    随机保留K个梯度元素，其余置零。
    
    Attributes:
        compression_ratio (float): 压缩比例
        
    Example:
        >>> compressor = RandomKCompressor(compression_ratio=0.01)
        >>> compressed = compressor.compress(gradient)
    """
    
    def __init__(
        self,
        compression_ratio: float = 0.01,
        config: Optional[CompressionConfig] = None
    ):
        """
        初始化随机K压缩器
        
        Args:
            compression_ratio: 压缩比例
            config: 压缩配置
        """
        if config is None:
            config = CompressionConfig(
                compression_type=CompressionType.RANDOMK,
                compression_ratio=compression_ratio
            )
        super().__init__(config)
        self.compression_ratio = compression_ratio
    
    def compress(
        self,
        gradient: np.ndarray,
        name: Optional[str] = None
    ) -> CompressedGradient:
        """
        随机K压缩
        
        Args:
            gradient: 输入梯度
            name: 梯度名称
            
        Returns:
            压缩后的梯度数据
        """
        original_shape = gradient.shape
        gradient_flat = gradient.flatten()
        
        # 应用误差反馈
        if self.config.error_feedback and name is not None:
            error = self.get_error_feedback(name)
            if error.size == 1:
                error = np.broadcast_to(error, gradient_flat.shape)
            else:
                error = error.flatten()
            gradient_flat = gradient_flat + error
        
        # 计算K值
        num_elements = gradient_flat.size
        k = max(1, int(num_elements * self.compression_ratio))
        
        # 随机选择K个索引
        indices = self.rng.choice(num_elements, size=k, replace=False)
        indices = np.sort(indices)  # 排序以便存储
        
        # 提取值
        values = gradient_flat[indices]
        
        compressed = CompressedGradient(
            values=values,
            indices=indices,
            shape=original_shape,
            compression_type=CompressionType.RANDOMK
        )
        
        # 更新误差反馈
        if self.config.error_feedback and name is not None:
            decompressed = self.decompress(compressed)
            self.update_error_feedback(name, gradient_flat, decompressed.flatten())
        
        return compressed
    
    def decompress(self, compressed: CompressedGradient) -> np.ndarray:
        """
        随机K解压缩
        
        Args:
            compressed: 压缩后的梯度数据
            
        Returns:
            解压缩后的梯度
        """
        if compressed.indices is None:
            raise ValueError("随机K压缩数据缺少索引")
        
        decompressed = np.zeros(
            np.prod(compressed.shape),
            dtype=compressed.values.dtype
        )
        decompressed[compressed.indices] = compressed.values
        
        return decompressed.reshape(compressed.shape)


class SignSGDCompressor(GradientCompressor):
    """
    SignSGD压缩器
    
    只保留梯度的符号信息，将每个梯度值压缩为1位。
    
    Example:
        >>> compressor = SignSGDCompressor()
        >>> compressed = compressor.compress(gradient)
    """
    
    def __init__(self, config: Optional[CompressionConfig] = None):
        """
        初始化SignSGD压缩器
        
        Args:
            config: 压缩配置
        """
        if config is None:
            config = CompressionConfig(
                compression_type=CompressionType.SIGNSGD,
                compression_ratio=1/32  # 1位 vs 32位浮点数
            )
        super().__init__(config)
    
    def compress(
        self,
        gradient: np.ndarray,
        name: Optional[str] = None
    ) -> CompressedGradient:
        """
        SignSGD压缩
        
        将梯度压缩为符号位（+1或-1）。
        
        Args:
            gradient: 输入梯度
            name: 梯度名称
            
        Returns:
            压缩后的梯度数据
        """
        original_shape = gradient.shape
        gradient_flat = gradient.flatten()
        
        # 应用误差反馈
        if self.config.error_feedback and name is not None:
            error = self.get_error_feedback(name)
            if error.size == 1:
                error = np.broadcast_to(error, gradient_flat.shape)
            else:
                error = error.flatten()
            gradient_flat = gradient_flat + error
        
        # 计算符号
        signs = np.sign(gradient_flat)
        signs[signs == 0] = 1  # 将0视为+1
        
        # 将符号转换为0/1表示
        values = ((signs + 1) / 2).astype(np.uint8)  # -1->0, +1->1
        
        compressed = CompressedGradient(
            values=values,
            indices=None,
            shape=original_shape,
            compression_type=CompressionType.SIGNSGD
        )
        
        # 更新误差反馈
        if self.config.error_feedback and name is not None:
            decompressed = self.decompress(compressed)
            self.update_error_feedback(name, gradient_flat, decompressed.flatten())
        
        return compressed
    
    def decompress(self, compressed: CompressedGradient) -> np.ndarray:
        """
        SignSGD解压缩
        
        Args:
            compressed: 压缩后的梯度数据
            
        Returns:
            解压缩后的梯度（符号值）
        """
        # 将0/1转换回-1/+1
        signs = compressed.values.astype(np.float64) * 2 - 1
        
        return signs.reshape(compressed.shape)


class DPAwareCompressor(GradientCompressor):
    """
    差分隐私感知压缩器
    
    在压缩过程中考虑差分隐私约束，确保压缩不会破坏隐私保护。
    可以与差分隐私模块集成使用。
    
    Attributes:
        base_compressor (GradientCompressor): 基础压缩器
        noise_multiplier (float): 噪声乘数
        
    Example:
        >>> base_comp = TopKCompressor(compression_ratio=0.1)
        >>> dp_comp = DPAwareCompressor(base_comp, noise_multiplier=1.0)
        >>> compressed = dp_comp.compress(gradient)
    """
    
    def __init__(
        self,
        base_compressor: GradientCompressor,
        noise_multiplier: float = 0.0
    ):
        """
        初始化DP感知压缩器
        
        Args:
            base_compressor: 基础压缩器
            noise_multiplier: 噪声乘数，0表示不添加噪声
        """
        super().__init__(base_compressor.config)
        self.base_compressor = base_compressor
        self.noise_multiplier = noise_multiplier
    
    def compress(
        self,
        gradient: np.ndarray,
        name: Optional[str] = None
    ) -> CompressedGradient:
        """
        DP感知压缩
        
        先应用基础压缩，然后根据需要添加噪声。
        
        Args:
            gradient: 输入梯度
            name: 梯度名称
            
        Returns:
            压缩后的梯度数据
        """
        # 基础压缩
        compressed = self.base_compressor.compress(gradient, name)
        
        # 添加噪声（如果启用）
        if self.noise_multiplier > 0:
            noise = np.random.randn(*compressed.values.shape) * self.noise_multiplier
            compressed.values = (compressed.values.astype(np.float64) + noise).astype(compressed.values.dtype)
        
        return compressed
    
    def decompress(self, compressed: CompressedGradient) -> np.ndarray:
        """
        解压缩
        
        Args:
            compressed: 压缩后的梯度数据
            
        Returns:
            解压缩后的梯度
        """
        return self.base_compressor.decompress(compressed)


def create_compressor(
    compression_type: Union[str, CompressionType],
    **kwargs
) -> GradientCompressor:
    """
    工厂函数：创建压缩器实例
    
    Args:
        compression_type: 压缩类型
        **kwargs: 额外的配置参数
        
    Returns:
        压缩器实例
        
    Raises:
        ValueError: 当压缩类型不支持时
        
    Example:
        >>> compressor = create_compressor('topk', compression_ratio=0.1)
        >>> compressor = create_compressor(CompressionType.QUANTIZATION, num_bits=8)
    """
    if isinstance(compression_type, str):
        compression_type = CompressionType(compression_type.lower())
    
    if compression_type == CompressionType.QUANTIZATION:
        return QuantizationCompressor(**kwargs)
    elif compression_type == CompressionType.TOPK:
        return TopKCompressor(**kwargs)
    elif compression_type == CompressionType.RANDOMK:
        return RandomKCompressor(**kwargs)
    elif compression_type == CompressionType.SIGNSGD:
        return SignSGDCompressor(**kwargs)
    else:
        raise ValueError(f"不支持的压缩类型: {compression_type}")


if __name__ == "__main__":
    # 测试代码
    print("测试梯度压缩模块")
    
    # 创建测试梯度
    test_gradient = np.random.randn(100, 50)
    print(f"原始梯度形状: {test_gradient.shape}")
    print(f"原始梯度大小: {test_gradient.size} 元素")
    
    # 测试TopK压缩
    print("\n--- TopK压缩测试 ---")
    topk_comp = TopKCompressor(compression_ratio=0.1)
    compressed = topk_comp.compress(test_gradient)
    decompressed = topk_comp.decompress(compressed)
    print(f"压缩比例: {compressed.get_compression_ratio():.4f}")
    print(f"压缩误差: {np.linalg.norm(test_gradient - decompressed):.4f}")
    
    # 测试量化压缩
    print("\n--- 量化压缩测试 ---")
    quant_comp = QuantizationCompressor(num_bits=8)
    compressed = quant_comp.compress(test_gradient)
    decompressed = quant_comp.decompress(compressed)
    print(f"压缩比例: {compressed.get_compression_ratio():.4f}")
    print(f"量化误差: {np.linalg.norm(test_gradient - decompressed):.4f}")
    
    # 测试SignSGD压缩
    print("\n--- SignSGD压缩测试 ---")
    sign_comp = SignSGDCompressor()
    compressed = sign_comp.compress(test_gradient)
    decompressed = sign_comp.decompress(compressed)
    print(f"压缩比例: {compressed.get_compression_ratio():.4f}")
    print(f"符号误差: {np.linalg.norm(test_gradient - decompressed):.4f}")
    
    # 测试工厂函数
    print("\n--- 工厂函数测试 ---")
    factory_comp = create_compressor('topk', compression_ratio=0.05)
    print(f"工厂创建的压缩器类型: {type(factory_comp).__name__}")
    
    # 测试字典压缩
    print("\n--- 字典压缩测试 ---")
    gradients = {
        'layer1.weight': np.random.randn(100, 50),
        'layer1.bias': np.random.randn(50),
        'layer2.weight': np.random.randn(50, 10)
    }
    compressed_dict = topk_comp.compress_dict(gradients)
    decompressed_dict = topk_comp.decompress_dict(compressed_dict)
    print(f"压缩了 {len(compressed_dict)} 个参数")
    
    print("\n所有测试通过!")
