"""
联邦学习客户端管理器模块

本模块实现了联邦学习系统的客户端管理功能，负责客户端的生命周期管理、
状态跟踪、选择策略实现以及客户端信息的维护。

作者: IP4Move Team
版本: 1.0.5
"""

import logging
import time
import random
from typing import Dict, List, Optional, Set, Tuple, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import numpy as np


class ClientStatus(Enum):
    """客户端状态枚举"""
    OFFLINE = "offline"           # 离线
    ONLINE = "online"             # 在线
    REGISTERED = "registered"     # 已注册
    TRAINING = "training"         # 训练中
    UPLOADING = "uploading"       # 上传中
    AVAILABLE = "available"       # 可用（可参与训练）
    BUSY = "busy"                 # 忙碌
    ERROR = "error"               # 错误状态
    SUSPENDED = "suspended"       # 暂停


@dataclass
class ClientCapabilities:
    """客户端能力信息数据类"""
    compute_power: str = "medium"     # 计算能力: low, medium, high
    bandwidth_mbps: float = 10.0      # 网络带宽(Mbps)
    memory_gb: float = 4.0            # 内存容量(GB)
    storage_gb: float = 10.0          # 存储容量(GB)
    gpu_available: bool = False       # 是否可用GPU
    supported_dtypes: List[str] = field(default_factory=lambda: ["float32"])


@dataclass
class ClientStatistics:
    """客户端统计信息数据类"""
    total_rounds: int = 0             # 总参与轮次
    successful_rounds: int = 0        # 成功完成的轮次
    failed_rounds: int = 0            # 失败的轮次
    total_data_samples: int = 0       # 总数据样本数
    avg_training_time: float = 0.0    # 平均训练时间
    last_participation: Optional[float] = None  # 上次参与时间
    cumulative_score: float = 0.0     # 累积评分


@dataclass
class ClientInfo:
    """客户端完整信息数据类"""
    client_id: str
    status: ClientStatus = ClientStatus.OFFLINE
    register_time: float = field(default_factory=time.time)
    last_heartbeat: float = field(default_factory=time.time)
    capabilities: ClientCapabilities = field(default_factory=ClientCapabilities)
    statistics: ClientStatistics = field(default_factory=ClientStatistics)
    metadata: Dict[str, Any] = field(default_factory=dict)
    current_task: Optional[str] = None
    task_progress: float = 0.0


class FLClientManager:
    """
    联邦学习客户端管理器类
    
    负责管理联邦学习系统中所有客户端的生命周期，包括注册、状态跟踪、
    客户端选择和性能监控。支持多种客户端选择策略。
    
    Attributes:
        clients: 客户端信息字典
        selection_strategy: 客户端选择策略
        heartbeat_timeout: 心跳超时时间（秒）
        logger: 日志记录器
    
    Example:
        >>> manager = FLClientManager(selection_strategy="random")
        >>> manager.register_client("client_1", capabilities={"compute_power": "high"})
        >>> selected = manager.select_clients(count=5)
        >>> manager.update_client_status("client_1", ClientStatus.TRAINING)
    """

    def __init__(
        self,
        selection_strategy: str = "random",
        heartbeat_timeout: float = 60.0,
        log_level: int = logging.INFO
    ) -> None:
        """
        初始化客户端管理器
        
        Args:
            selection_strategy: 客户端选择策略，支持'random', 'round_robin', 
                               'capacity_based', 'performance_based'
            heartbeat_timeout: 心跳超时时间（秒），超时后标记为离线
            log_level: 日志级别
        
        Raises:
            ValueError: 当策略不支持或参数无效时抛出
        """
        valid_strategies = ["random", "round_robin", "capacity_based", "performance_based"]
        if selection_strategy not in valid_strategies:
            raise ValueError(
                f"不支持的选择策略: {selection_strategy}，"
                f"支持的策略: {valid_strategies}"
            )
        if heartbeat_timeout <= 0:
            raise ValueError(f"heartbeat_timeout必须大于0，当前值: {heartbeat_timeout}")
        
        self.selection_strategy: str = selection_strategy
        self.heartbeat_timeout: float = heartbeat_timeout
        self._clients: Dict[str, ClientInfo] = {}
        self._round_robin_index: int = 0
        self._selection_weights: Dict[str, float] = {}
        
        # 初始化日志
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(log_level)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
        
        self.logger.info(f"FLClientManager初始化完成，策略: {selection_strategy}")

    def register_client(
        self,
        client_id: str,
        capabilities: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        注册新客户端
        
        将客户端加入管理系统，初始化其状态和能力信息。
        
        Args:
            client_id: 客户端唯一标识符
            capabilities: 客户端能力信息字典
            metadata: 客户端元数据
        
        Returns:
            bool: 注册是否成功
        
        Raises:
            ValueError: 当client_id为空或格式无效时抛出
        
        Example:
            >>> caps = {"compute_power": "high", "bandwidth_mbps": 100}
            >>> meta = {"location": "datacenter_1", "organization": "org_a"}
            >>> manager.register_client("client_001", caps, meta)
            True
        """
        if not client_id:
            raise ValueError("client_id不能为空")
        
        if not isinstance(client_id, str):
            raise ValueError("client_id必须是字符串类型")
        
        if client_id in self._clients:
            self.logger.warning(f"客户端 {client_id} 已存在，更新注册信息")
            return self._update_existing_client(client_id, capabilities, metadata)
        
        try:
            # 创建能力对象
            cap_obj = ClientCapabilities()
            if capabilities:
                for key, value in capabilities.items():
                    if hasattr(cap_obj, key):
                        setattr(cap_obj, key, value)
            
            # 创建客户端信息
            client_info = ClientInfo(
                client_id=client_id,
                status=ClientStatus.REGISTERED,
                capabilities=cap_obj,
                metadata=metadata or {}
            )
            
            self._clients[client_id] = client_info
            self._selection_weights[client_id] = 1.0
            
            self.logger.info(f"客户端 {client_id} 注册成功")
            return True
            
        except Exception as e:
            self.logger.error(f"客户端 {client_id} 注册失败: {str(e)}")
            return False

    def _update_existing_client(
        self,
        client_id: str,
        capabilities: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """更新已存在客户端的信息"""
        try:
            client = self._clients[client_id]
            
            if capabilities:
                for key, value in capabilities.items():
                    if hasattr(client.capabilities, key):
                        setattr(client.capabilities, key, value)
            
            if metadata:
                client.metadata.update(metadata)
            
            client.register_time = time.time()
            self.logger.info(f"客户端 {client_id} 信息已更新")
            return True
        except Exception as e:
            self.logger.error(f"更新客户端 {client_id} 失败: {str(e)}")
            return False

    def unregister_client(self, client_id: str) -> bool:
        """
        注销客户端
        
        从管理系统中移除客户端。
        
        Args:
            client_id: 客户端标识符
        
        Returns:
            bool: 注销是否成功
        """
        if client_id not in self._clients:
            self.logger.warning(f"客户端 {client_id} 不存在，无法注销")
            return False
        
        try:
            del self._clients[client_id]
            if client_id in self._selection_weights:
                del self._selection_weights[client_id]
            
            self.logger.info(f"客户端 {client_id} 已注销")
            return True
        except Exception as e:
            self.logger.error(f"注销客户端 {client_id} 失败: {str(e)}")
            return False

    def select_clients(
        self,
        count: int,
        available_only: bool = True,
        exclude_clients: Optional[Set[str]] = None,
        custom_weights: Optional[Dict[str, float]] = None
    ) -> List[str]:
        """
        选择参与训练的客户端
        
        根据配置的策略从可用客户端中选择指定数量的客户端。
        
        Args:
            count: 需要选择的客户端数量
            available_only: 是否只选择可用状态的客户端
            exclude_clients: 需要排除的客户端集合
            custom_weights: 自定义选择权重
        
        Returns:
            List[str]: 选中的客户端ID列表
        
        Raises:
            ValueError: 当count无效时抛出
            RuntimeError: 当可用客户端不足时抛出
        
        Example:
            >>> # 随机选择5个客户端
            >>> selected = manager.select_clients(5)
            >>> # 基于性能选择，排除特定客户端
            >>> selected = manager.select_clients(3, exclude_clients={"client_bad"})
        """
        if count < 1:
            raise ValueError(f"count必须大于0，当前值: {count}")
        
        # 筛选候选客户端
        candidates = self._get_candidate_clients(available_only, exclude_clients)
        
        if len(candidates) < count:
            raise RuntimeError(
                f"可用客户端数量 {len(candidates)} 少于请求数量 {count}"
            )
        
        # 根据策略选择
        if self.selection_strategy == "random":
            selected = self._select_random(candidates, count)
        elif self.selection_strategy == "round_robin":
            selected = self._select_round_robin(candidates, count)
        elif self.selection_strategy == "capacity_based":
            selected = self._select_capacity_based(candidates, count)
        elif self.selection_strategy == "performance_based":
            selected = self._select_performance_based(candidates, count, custom_weights)
        else:
            selected = self._select_random(candidates, count)
        
        # 更新选中客户端状态
        for client_id in selected:
            self._clients[client_id].status = ClientStatus.BUSY
        
        self.logger.info(f"已选择 {len(selected)} 个客户端: {selected}")
        return selected

    def _get_candidate_clients(
        self,
        available_only: bool,
        exclude_clients: Optional[Set[str]]
    ) -> List[str]:
        """获取候选客户端列表"""
        candidates = []
        exclude_set = exclude_clients or set()
        
        for client_id, client in self._clients.items():
            if client_id in exclude_set:
                continue
            
            if available_only:
                if client.status in [ClientStatus.AVAILABLE, ClientStatus.ONLINE]:
                    # 检查心跳超时
                    if time.time() - client.last_heartbeat <= self.heartbeat_timeout:
                        candidates.append(client_id)
            else:
                candidates.append(client_id)
        
        return candidates

    def _select_random(self, candidates: List[str], count: int) -> List[str]:
        """随机选择策略"""
        return random.sample(candidates, count)

    def _select_round_robin(self, candidates: List[str], count: int) -> List[str]:
        """轮询选择策略"""
        sorted_candidates = sorted(candidates)
        n = len(sorted_candidates)
        selected = []
        
        for i in range(count):
            idx = (self._round_robin_index + i) % n
            selected.append(sorted_candidates[idx])
        
        self._round_robin_index = (self._round_robin_index + count) % n
        return selected

    def _select_capacity_based(self, candidates: List[str], count: int) -> List[str]:
        """基于能力的选择策略"""
        # 计算每个客户端的能力分数
        scores = {}
        for client_id in candidates:
            client = self._clients[client_id]
            cap = client.capabilities
            
            # 计算能力分数
            compute_score = {"low": 1, "medium": 2, "high": 3}.get(cap.compute_power, 2)
            bandwidth_score = min(cap.bandwidth_mbps / 10, 10)
            memory_score = min(cap.memory_gb / 4, 5)
            gpu_score = 2 if cap.gpu_available else 1
            
            scores[client_id] = compute_score * bandwidth_score * memory_score * gpu_score
        
        # 按分数排序，优先选择能力强的
        sorted_clients = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [client_id for client_id, _ in sorted_clients[:count]]

    def _select_performance_based(
        self,
        candidates: List[str],
        count: int,
        custom_weights: Optional[Dict[str, float]] = None
    ) -> List[str]:
        """基于历史性能的选择策略"""
        scores = {}
        
        for client_id in candidates:
            client = self._clients[client_id]
            stats = client.statistics
            
            # 计算性能分数
            if stats.total_rounds > 0:
                success_rate = stats.successful_rounds / stats.total_rounds
                avg_time_score = 1.0 / (1 + stats.avg_training_time / 60)  # 时间越短分数越高
                participation_score = min(stats.total_rounds / 10, 1.0)
                
                base_score = (success_rate * 0.5 + avg_time_score * 0.3 + participation_score * 0.2)
            else:
                base_score = 0.5  # 新客户端默认分数
            
            # 应用自定义权重
            weight = custom_weights.get(client_id, 1.0) if custom_weights else 1.0
            scores[client_id] = base_score * weight
        
        # 使用softmax概率进行选择
        client_ids = list(scores.keys())
        score_values = np.array([scores[cid] for cid in client_ids])
        
        # 防止数值溢出
        exp_scores = np.exp(score_values - np.max(score_values))
        probabilities = exp_scores / np.sum(exp_scores)
        
        # 根据概率选择（不放回）
        selected_indices = np.random.choice(
            len(client_ids),
            size=min(count, len(client_ids)),
            replace=False,
            p=probabilities
        )
        
        return [client_ids[i] for i in selected_indices]

    def get_client_info(self, client_id: str) -> Optional[ClientInfo]:
        """
        获取客户端详细信息
        
        Args:
            client_id: 客户端标识符
        
        Returns:
            Optional[ClientInfo]: 客户端信息对象，不存在时返回None
        
        Example:
            >>> info = manager.get_client_info("client_1")
            >>> if info:
            ...     print(f"状态: {info.status.value}")
            ...     print(f"计算能力: {info.capabilities.compute_power}")
        """
        return self._clients.get(client_id)

    def get_all_clients(self) -> Dict[str, ClientInfo]:
        """
        获取所有客户端信息
        
        Returns:
            Dict[str, ClientInfo]: 所有客户端信息字典
        """
        return self._clients.copy()

    def update_client_status(
        self,
        client_id: str,
        status: ClientStatus,
        task_info: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        更新客户端状态
        
        Args:
            client_id: 客户端标识符
            status: 新状态
            task_info: 当前任务信息
        
        Returns:
            bool: 更新是否成功
        
        Raises:
            ValueError: 当客户端不存在时抛出
        """
        if client_id not in self._clients:
            raise ValueError(f"客户端 {client_id} 不存在")
        
        try:
            client = self._clients[client_id]
            old_status = client.status
            client.status = status
            
            if task_info:
                client.current_task = task_info.get("task_id")
                client.task_progress = task_info.get("progress", 0.0)
            
            self.logger.debug(f"客户端 {client_id} 状态: {old_status.value} -> {status.value}")
            return True
        except Exception as e:
            self.logger.error(f"更新客户端 {client_id} 状态失败: {str(e)}")
            return False

    def update_client_heartbeat(self, client_id: str) -> bool:
        """
        更新客户端心跳时间
        
        Args:
            client_id: 客户端标识符
        
        Returns:
            bool: 更新是否成功
        """
        if client_id not in self._clients:
            return False
        
        try:
            self._clients[client_id].last_heartbeat = time.time()
            
            # 如果之前离线，恢复为在线状态
            if self._clients[client_id].status == ClientStatus.OFFLINE:
                self._clients[client_id].status = ClientStatus.ONLINE
            
            return True
        except Exception as e:
            self.logger.error(f"更新客户端 {client_id} 心跳失败: {str(e)}")
            return False

    def update_client_statistics(
        self,
        client_id: str,
        training_time: Optional[float] = None,
        success: bool = True,
        data_samples: int = 0
    ) -> bool:
        """
        更新客户端统计信息
        
        Args:
            client_id: 客户端标识符
            training_time: 本次训练时间（秒）
            success: 训练是否成功
            data_samples: 本次使用的数据样本数
        
        Returns:
            bool: 更新是否成功
        """
        if client_id not in self._clients:
            self.logger.warning(f"客户端 {client_id} 不存在")
            return False
        
        try:
            stats = self._clients[client_id].statistics
            stats.total_rounds += 1
            stats.last_participation = time.time()
            
            if success:
                stats.successful_rounds += 1
            else:
                stats.failed_rounds += 1
            
            if training_time is not None:
                # 更新平均训练时间
                if stats.avg_training_time == 0:
                    stats.avg_training_time = training_time
                else:
                    stats.avg_training_time = (
                        stats.avg_training_time * 0.9 + training_time * 0.1
                    )
            
            stats.total_data_samples += data_samples
            
            # 更新累积评分
            if success:
                stats.cumulative_score += 1.0
            else:
                stats.cumulative_score -= 0.5
            
            return True
        except Exception as e:
            self.logger.error(f"更新客户端 {client_id} 统计失败: {str(e)}")
            return False

    def check_client_health(self) -> Dict[str, List[str]]:
        """
        检查所有客户端健康状态
        
        检测心跳超时的客户端并标记为离线。
        
        Returns:
            Dict[str, List[str]]: 健康状态分类结果
        """
        current_time = time.time()
        healthy = []
        unhealthy = []
        offline = []
        
        for client_id, client in self._clients.items():
            time_since_heartbeat = current_time - client.last_heartbeat
            
            if time_since_heartbeat > self.heartbeat_timeout:
                if client.status != ClientStatus.OFFLINE:
                    client.status = ClientStatus.OFFLINE
                    self.logger.warning(f"客户端 {client_id} 心跳超时，标记为离线")
                offline.append(client_id)
            elif client.status == ClientStatus.ERROR:
                unhealthy.append(client_id)
            else:
                healthy.append(client_id)
        
        return {
            "healthy": healthy,
            "unhealthy": unhealthy,
            "offline": offline
        }

    def get_available_clients(self) -> List[str]:
        """
        获取当前可用的客户端列表
        
        Returns:
            List[str]: 可用客户端ID列表
        """
        available = []
        current_time = time.time()
        
        for client_id, client in self._clients.items():
            if client.status in [ClientStatus.AVAILABLE, ClientStatus.ONLINE]:
                if current_time - client.last_heartbeat <= self.heartbeat_timeout:
                    available.append(client_id)
        
        return available

    def get_client_count_by_status(self) -> Dict[str, int]:
        """
        按状态统计客户端数量
        
        Returns:
            Dict[str, int]: 各状态的客户端数量
        """
        counts = {status.value: 0 for status in ClientStatus}
        
        for client in self._clients.values():
            counts[client.status.value] += 1
        
        return counts

    def set_selection_strategy(self, strategy: str) -> None:
        """
        设置客户端选择策略
        
        Args:
            strategy: 策略名称
        
        Raises:
            ValueError: 当策略不支持时抛出
        """
        valid_strategies = ["random", "round_robin", "capacity_based", "performance_based"]
        if strategy not in valid_strategies:
            raise ValueError(f"不支持的选择策略: {strategy}")
        
        self.selection_strategy = strategy
        self.logger.info(f"选择策略已更改为: {strategy}")

    def reset_client_statistics(self, client_id: Optional[str] = None) -> bool:
        """
        重置客户端统计信息
        
        Args:
            client_id: 客户端标识符，None则重置所有客户端
        
        Returns:
            bool: 重置是否成功
        """
        try:
            if client_id is not None:
                if client_id not in self._clients:
                    return False
                self._clients[client_id].statistics = ClientStatistics()
            else:
                for client in self._clients.values():
                    client.statistics = ClientStatistics()
            
            self.logger.info(f"统计信息已重置" + (f" for {client_id}" if client_id else ""))
            return True
        except Exception as e:
            self.logger.error(f"重置统计信息失败: {str(e)}")
            return False

    def get_system_overview(self) -> Dict[str, Any]:
        """
        获取系统概览信息
        
        Returns:
            Dict[str, Any]: 系统状态概览
        """
        total_clients = len(self._clients)
        status_counts = self.get_client_count_by_status()
        available = len(self.get_available_clients())
        
        # 计算平均统计信息
        if total_clients > 0:
            avg_rounds = np.mean([
                c.statistics.total_rounds for c in self._clients.values()
            ])
            avg_score = np.mean([
                c.statistics.cumulative_score for c in self._clients.values()
            ])
        else:
            avg_rounds = 0.0
            avg_score = 0.0
        
        return {
            "total_clients": total_clients,
            "available_clients": available,
            "status_distribution": status_counts,
            "selection_strategy": self.selection_strategy,
            "heartbeat_timeout": self.heartbeat_timeout,
            "average_rounds_per_client": float(avg_rounds),
            "average_client_score": float(avg_score)
        }

    def export_client_data(self) -> Dict[str, Dict[str, Any]]:
        """
        导出所有客户端数据
        
        Returns:
            Dict[str, Dict[str, Any]]: 客户端数据字典
        """
        export_data = {}
        
        for client_id, client in self._clients.items():
            export_data[client_id] = {
                "client_id": client.client_id,
                "status": client.status.value,
                "register_time": client.register_time,
                "last_heartbeat": client.last_heartbeat,
                "capabilities": {
                    "compute_power": client.capabilities.compute_power,
                    "bandwidth_mbps": client.capabilities.bandwidth_mbps,
                    "memory_gb": client.capabilities.memory_gb,
                    "storage_gb": client.capabilities.storage_gb,
                    "gpu_available": client.capabilities.gpu_available
                },
                "statistics": {
                    "total_rounds": client.statistics.total_rounds,
                    "successful_rounds": client.statistics.successful_rounds,
                    "failed_rounds": client.statistics.failed_rounds,
                    "avg_training_time": client.statistics.avg_training_time,
                    "cumulative_score": client.statistics.cumulative_score
                },
                "metadata": client.metadata
            }
        
        return export_data
