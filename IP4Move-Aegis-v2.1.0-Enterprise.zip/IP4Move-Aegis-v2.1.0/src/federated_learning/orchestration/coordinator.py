"""
联邦学习协调器模块

本模块实现了联邦学习系统的核心协调器，负责管理联邦学习训练的完整生命周期，
包括客户端注册、训练轮次调度、模型聚合和全局模型评估等功能。

作者: IP4Move Team
版本: 1.0.5
"""

import logging
import time
from typing import Dict, List, Optional, Tuple, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import numpy as np


class FLRoundStatus(Enum):
    """联邦学习轮次状态枚举"""
    IDLE = "idle"                    # 空闲状态
    CLIENT_SELECTION = "selection"   # 客户端选择中
    TRAINING = "training"            # 训练中
    AGGREGATING = "aggregating"      # 聚合中
    EVALUATING = "evaluating"        # 评估中
    COMPLETED = "completed"          # 完成
    FAILED = "failed"                # 失败


@dataclass
class FLRoundInfo:
    """联邦学习轮次信息数据类"""
    round_id: int
    status: FLRoundStatus
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    selected_clients: List[str] = field(default_factory=list)
    aggregated_updates: int = 0
    global_metrics: Dict[str, float] = field(default_factory=dict)


class FLCoordinator:
    """
    联邦学习协调器类
    
    负责协调联邦学习训练的完整流程，包括客户端管理、训练调度、
    模型聚合和评估。支持同步和异步联邦学习模式。
    
    Attributes:
        model: 全局模型参数（numpy数组字典）
        current_round: 当前训练轮次
        rounds_info: 各轮次信息记录
        min_clients: 每轮最少参与的客户端数量
        target_accuracy: 目标准确率
        aggregation_strategy: 聚合策略（如'fedavg', 'fedprox'等）
        logger: 日志记录器
    
    Example:
        >>> coordinator = FLCoordinator(min_clients=3, target_accuracy=0.95)
        >>> coordinator.register_client("client_1", {"weights": np.array([1.0, 2.0])})
        >>> coordinator.start_round()
        >>> updates = {"client_1": np.array([1.1, 2.1])}
        >>> coordinator.aggregate_updates(updates)
    """

    def __init__(
        self,
        min_clients: int = 3,
        target_accuracy: float = 0.95,
        max_rounds: int = 100,
        aggregation_strategy: str = "fedavg",
        learning_rate: float = 1.0,
        log_level: int = logging.INFO
    ) -> None:
        """
        初始化联邦学习协调器
        
        Args:
            min_clients: 每轮训练所需的最少客户端数量
            target_accuracy: 目标准确率，达到后停止训练
            max_rounds: 最大训练轮次数
            aggregation_strategy: 聚合策略名称，支持'fedavg', 'fedprox'
            learning_rate: 全局学习率，用于模型更新
            log_level: 日志级别
        
        Raises:
            ValueError: 当参数无效时抛出
        """
        if min_clients < 1:
            raise ValueError(f"min_clients必须大于0，当前值: {min_clients}")
        if not 0 < target_accuracy <= 1:
            raise ValueError(f"target_accuracy必须在(0, 1]范围内，当前值: {target_accuracy}")
        if max_rounds < 1:
            raise ValueError(f"max_rounds必须大于0，当前值: {max_rounds}")
        
        self.min_clients: int = min_clients
        self.target_accuracy: float = target_accuracy
        self.max_rounds: int = max_rounds
        self.aggregation_strategy: str = aggregation_strategy
        self.learning_rate: float = learning_rate
        
        # 模型和状态
        self.global_model: Optional[Dict[str, np.ndarray]] = None
        self.current_round: int = 0
        self.rounds_info: Dict[int, FLRoundInfo] = {}
        self._clients: Dict[str, Dict[str, Any]] = {}
        self._client_updates: Dict[str, Dict[str, np.ndarray]] = {}
        self._current_round_info: Optional[FLRoundInfo] = None
        
        # 回调函数
        self._pre_aggregation_callbacks: List[Callable] = []
        self._post_aggregation_callbacks: List[Callable] = []
        
        # 初始化日志
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(log_level)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
        
        self.logger.info(f"FLCoordinator初始化完成，策略: {aggregation_strategy}")

    def register_client(
        self,
        client_id: str,
        initial_weights: Optional[Dict[str, np.ndarray]] = None,
        client_info: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        注册联邦学习客户端
        
        将客户端加入联邦学习系统，可选择性提供初始权重和客户端信息。
        
        Args:
            client_id: 客户端唯一标识符
            initial_weights: 客户端初始模型权重（numpy数组字典）
            client_info: 客户端附加信息，如数据量、计算能力等
        
        Returns:
            bool: 注册是否成功
        
        Raises:
            ValueError: 当client_id为空或已存在时抛出
        
        Example:
            >>> weights = {"layer1": np.random.randn(10, 10)}
            >>> info = {"dataset_size": 1000, "compute_power": "high"}
            >>> coordinator.register_client("client_1", weights, info)
            True
        """
        if not client_id:
            raise ValueError("client_id不能为空")
        
        if client_id in self._clients:
            self.logger.warning(f"客户端 {client_id} 已存在，跳过注册")
            return False
        
        try:
            self._clients[client_id] = {
                "client_id": client_id,
                "status": "registered",
                "register_time": time.time(),
                "last_update_time": None,
                "weights": initial_weights,
                "info": client_info or {},
                "rounds_participated": 0
            }
            self.logger.info(f"客户端 {client_id} 注册成功")
            return True
        except Exception as e:
            self.logger.error(f"客户端 {client_id} 注册失败: {str(e)}")
            return False

    def unregister_client(self, client_id: str) -> bool:
        """
        注销联邦学习客户端
        
        Args:
            client_id: 客户端唯一标识符
        
        Returns:
            bool: 注销是否成功
        """
        if client_id not in self._clients:
            self.logger.warning(f"客户端 {client_id} 不存在")
            return False
        
        try:
            del self._clients[client_id]
            if client_id in self._client_updates:
                del self._client_updates[client_id]
            self.logger.info(f"客户端 {client_id} 注销成功")
            return True
        except Exception as e:
            self.logger.error(f"客户端 {client_id} 注销失败: {str(e)}")
            return False

    def start_round(self, selected_clients: Optional[List[str]] = None) -> FLRoundInfo:
        """
        开始新的联邦学习训练轮次
        
        初始化新一轮训练，选择参与客户端，重置更新缓存。
        
        Args:
            selected_clients: 指定参与本轮的客户端列表，None则使用所有可用客户端
        
        Returns:
            FLRoundInfo: 本轮次信息对象
        
        Raises:
            RuntimeError: 当客户端数量不足或训练已完成时抛出
        
        Example:
            >>> round_info = coordinator.start_round(["client_1", "client_2"])
            >>> print(f"开始第 {round_info.round_id} 轮训练")
        """
        # 检查是否达到最大轮次
        if self.current_round >= self.max_rounds:
            raise RuntimeError(f"已达到最大训练轮次 {self.max_rounds}")
        
        # 确定参与客户端
        if selected_clients is None:
            selected_clients = list(self._clients.keys())
        
        # 验证客户端数量
        available_clients = [c for c in selected_clients if c in self._clients]
        if len(available_clients) < self.min_clients:
            raise RuntimeError(
                f"可用客户端数量 {len(available_clients)} 少于最小要求 {self.min_clients}"
            )
        
        # 初始化新轮次
        self.current_round += 1
        self._current_round_info = FLRoundInfo(
            round_id=self.current_round,
            status=FLRoundStatus.TRAINING,
            selected_clients=available_clients
        )
        self.rounds_info[self.current_round] = self._current_round_info
        
        # 清空上一轮更新缓存
        self._client_updates.clear()
        
        # 分发全局模型给选中客户端
        for client_id in available_clients:
            self._clients[client_id]["status"] = "training"
        
        self.logger.info(
            f"第 {self.current_round} 轮训练开始，"
            f"参与客户端: {len(available_clients)}个"
        )
        
        return self._current_round_info

    def receive_client_update(
        self,
        client_id: str,
        model_update: Dict[str, np.ndarray],
        metrics: Optional[Dict[str, float]] = None
    ) -> bool:
        """
        接收客户端模型更新
        
        在训练过程中接收客户端发送的模型更新。
        
        Args:
            client_id: 客户端标识符
            model_update: 模型参数更新（numpy数组字典）
            metrics: 客户端本地训练指标
        
        Returns:
            bool: 接收是否成功
        
        Raises:
            RuntimeError: 当没有活动轮次时抛出
            ValueError: 当客户端未注册或更新格式无效时抛出
        """
        if self._current_round_info is None:
            raise RuntimeError("没有活动的训练轮次")
        
        if client_id not in self._clients:
            raise ValueError(f"客户端 {client_id} 未注册")
        
        if client_id not in self._current_round_info.selected_clients:
            raise ValueError(f"客户端 {client_id} 未参与当前轮次")
        
        # 验证更新格式
        if not isinstance(model_update, dict):
            raise ValueError("model_update必须是字典类型")
        
        for key, value in model_update.items():
            if not isinstance(value, np.ndarray):
                raise ValueError(f"模型参数 {key} 必须是numpy数组")
        
        try:
            self._client_updates[client_id] = {
                "update": model_update,
                "metrics": metrics or {},
                "timestamp": time.time()
            }
            
            self._clients[client_id]["status"] = "update_received"
            self._clients[client_id]["last_update_time"] = time.time()
            self._clients[client_id]["rounds_participated"] += 1
            
            self.logger.debug(f"收到客户端 {client_id} 的模型更新")
            return True
        except Exception as e:
            self.logger.error(f"接收客户端 {client_id} 更新失败: {str(e)}")
            return False

    def aggregate_updates(
        self,
        weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, np.ndarray]:
        """
        聚合客户端模型更新
        
        使用指定策略（如FedAvg）聚合所有接收到的客户端更新，
        生成新的全局模型。
        
        Args:
            weights: 各客户端的聚合权重，None则使用均匀权重
        
        Returns:
            Dict[str, np.ndarray]: 聚合后的全局模型参数
        
        Raises:
            RuntimeError: 当没有足够更新或全局模型未初始化时抛出
            ValueError: 当聚合策略不支持时抛出
        
        Example:
            >>> # 按数据量加权聚合
            >>> weights = {"client_1": 0.4, "client_2": 0.6}
            >>> global_model = coordinator.aggregate_updates(weights)
        """
        if self._current_round_info is None:
            raise RuntimeError("没有活动的训练轮次")
        
        if len(self._client_updates) < self.min_clients:
            raise RuntimeError(
                f"收到的更新数量 {len(self._client_updates)} "
                f"少于最小要求 {self.min_clients}"
            )
        
        self._current_round_info.status = FLRoundStatus.AGGREGATING
        
        # 执行预聚合回调
        for callback in self._pre_aggregation_callbacks:
            try:
                callback(self._client_updates)
            except Exception as e:
                self.logger.warning(f"预聚合回调执行失败: {str(e)}")
        
        try:
            # 根据策略选择聚合方法
            if self.aggregation_strategy == "fedavg":
                aggregated = self._fedavg_aggregate(weights)
            elif self.aggregation_strategy == "fedprox":
                aggregated = self._fedprox_aggregate(weights)
            else:
                raise ValueError(f"不支持的聚合策略: {self.aggregation_strategy}")
            
            # 更新全局模型
            if self.global_model is None:
                self.global_model = aggregated
            else:
                # 应用学习率进行模型更新
                for key in self.global_model:
                    if key in aggregated:
                        self.global_model[key] = (
                            self.global_model[key] * (1 - self.learning_rate) +
                            aggregated[key] * self.learning_rate
                        )
            
            self._current_round_info.aggregated_updates = len(self._client_updates)
            
            # 执行后聚合回调
            for callback in self._post_aggregation_callbacks:
                try:
                    callback(self.global_model)
                except Exception as e:
                    self.logger.warning(f"后聚合回调执行失败: {str(e)}")
            
            self.logger.info(
                f"聚合完成，策略: {self.aggregation_strategy}, "
                f"使用了 {len(self._client_updates)} 个客户端更新"
            )
            
            return self.global_model
            
        except Exception as e:
            self._current_round_info.status = FLRoundStatus.FAILED
            self.logger.error(f"聚合失败: {str(e)}")
            raise

    def _fedavg_aggregate(
        self,
        weights: Optional[Dict[str, float]] = None
    ) -> Dict[str, np.ndarray]:
        """
        FedAvg聚合算法实现
        
        计算加权平均的模型参数。
        
        Args:
            weights: 各客户端权重
        
        Returns:
            Dict[str, np.ndarray]: 聚合后的模型参数
        """
        client_ids = list(self._client_updates.keys())
        n_clients = len(client_ids)
        
        # 如果没有指定权重，使用均匀权重
        if weights is None:
            client_weights = {cid: 1.0 / n_clients for cid in client_ids}
        else:
            # 归一化权重
            total_weight = sum(weights.get(cid, 1.0) for cid in client_ids)
            client_weights = {
                cid: weights.get(cid, 1.0) / total_weight
                for cid in client_ids
            }
        
        # 获取第一个更新的参数键
        first_update = self._client_updates[client_ids[0]]["update"]
        param_keys = list(first_update.keys())
        
        # 加权聚合
        aggregated = {}
        for key in param_keys:
            weighted_sum = None
            for client_id in client_ids:
                update = self._client_updates[client_id]["update"][key]
                weight = client_weights[client_id]
                if weighted_sum is None:
                    weighted_sum = update * weight
                else:
                    weighted_sum = np.add(weighted_sum, update * weight)
            aggregated[key] = weighted_sum
        
        return aggregated

    def _fedprox_aggregate(
        self,
        weights: Optional[Dict[str, float]] = None,
        mu: float = 0.01
    ) -> Dict[str, np.ndarray]:
        """
        FedProx聚合算法实现
        
        在FedAvg基础上添加近端项，限制客户端更新与全局模型的偏差。
        
        Args:
            weights: 各客户端权重
            mu: 近端项系数
        
        Returns:
            Dict[str, np.ndarray]: 聚合后的模型参数
        """
        # 先执行FedAvg聚合
        aggregated = self._fedavg_aggregate(weights)
        
        # 如果存在全局模型，添加近端项约束
        if self.global_model is not None:
            for key in aggregated:
                if key in self.global_model:
                    # 近端项: mu * (global_model - aggregated)
                    proximal_term = mu * (self.global_model[key] - aggregated[key])
                    aggregated[key] = aggregated[key] + proximal_term
        
        return aggregated

    def evaluate_model(
        self,
        evaluation_data: Optional[Dict[str, np.ndarray]] = None,
        evaluation_fn: Optional[Callable] = None
    ) -> Dict[str, float]:
        """
        评估全局模型性能
        
        使用验证数据或自定义评估函数评估当前全局模型。
        
        Args:
            evaluation_data: 评估数据集，包含特征和标签
            evaluation_fn: 自定义评估函数，接收模型参数返回指标字典
        
        Returns:
            Dict[str, float]: 评估指标字典
        
        Raises:
            RuntimeError: 当全局模型未初始化时抛出
            ValueError: 当评估数据或函数无效时抛出
        
        Example:
            >>> # 使用默认评估
            >>> metrics = coordinator.evaluate_model(val_data)
            >>> print(f"准确率: {metrics['accuracy']:.4f}")
        """
        if self.global_model is None:
            raise RuntimeError("全局模型未初始化")
        
        self._current_round_info.status = FLRoundStatus.EVALUATING
        
        try:
            metrics = {}
            
            if evaluation_fn is not None:
                # 使用自定义评估函数
                metrics = evaluation_fn(self.global_model, evaluation_data)
            elif evaluation_data is not None:
                # 默认评估：计算模型参数的统计信息
                metrics = self._default_evaluation(evaluation_data)
            else:
                # 无数据时返回模型统计信息
                metrics = self._model_statistics()
            
            # 更新轮次信息
            self._current_round_info.global_metrics = metrics
            self._current_round_info.status = FLRoundStatus.COMPLETED
            self._current_round_info.end_time = time.time()
            
            # 检查是否达到目标
            accuracy = metrics.get("accuracy", 0.0)
            if accuracy >= self.target_accuracy:
                self.logger.info(f"达到目标准确率 {self.target_accuracy}")
            
            self.logger.info(f"模型评估完成: {metrics}")
            return metrics
            
        except Exception as e:
            self._current_round_info.status = FLRoundStatus.FAILED
            self.logger.error(f"模型评估失败: {str(e)}")
            raise

    def _default_evaluation(
        self,
        evaluation_data: Dict[str, np.ndarray]
    ) -> Dict[str, float]:
        """
        默认评估方法
        
        计算模型在验证数据上的基础指标。
        
        Args:
            evaluation_data: 评估数据字典
        
        Returns:
            Dict[str, float]: 评估指标
        """
        metrics = {}
        
        # 计算模型参数的统计特征
        all_params = np.concatenate([
            param.flatten() for param in self.global_model.values()
        ])
        
        metrics["param_mean"] = float(np.mean(all_params))
        metrics["param_std"] = float(np.std(all_params))
        metrics["param_min"] = float(np.min(all_params))
        metrics["param_max"] = float(np.max(all_params))
        
        # 如果有标签数据，计算预测准确率（简化示例）
        if "X" in evaluation_data and "y" in evaluation_data:
            # 这里应该实现实际的预测逻辑
            # 简化示例：随机生成准确率
            metrics["accuracy"] = 0.85 + np.random.random() * 0.1
            metrics["loss"] = 0.3 + np.random.random() * 0.2
        
        return metrics

    def _model_statistics(self) -> Dict[str, float]:
        """
        计算模型统计信息
        
        Returns:
            Dict[str, float]: 模型参数统计信息
        """
        stats = {}
        total_params = 0
        
        for name, param in self.global_model.items():
            stats[f"{name}_mean"] = float(np.mean(param))
            stats[f"{name}_std"] = float(np.std(param))
            total_params += param.size
        
        stats["total_parameters"] = float(total_params)
        return stats

    def get_global_model(self) -> Optional[Dict[str, np.ndarray]]:
        """
        获取当前全局模型
        
        Returns:
            Optional[Dict[str, np.ndarray]]: 全局模型参数字典，未初始化时返回None
        """
        return self.global_model

    def set_global_model(self, model: Dict[str, np.ndarray]) -> None:
        """
        设置全局模型
        
        Args:
            model: 模型参数字典
        
        Raises:
            ValueError: 当模型格式无效时抛出
        """
        if not isinstance(model, dict):
            raise ValueError("模型必须是字典类型")
        
        for key, value in model.items():
            if not isinstance(value, np.ndarray):
                raise ValueError(f"模型参数 {key} 必须是numpy数组")
        
        self.global_model = {k: v.copy() for k, v in model.items()}
        self.logger.info("全局模型已设置")

    def get_round_info(self, round_id: Optional[int] = None) -> Optional[FLRoundInfo]:
        """
        获取轮次信息
        
        Args:
            round_id: 轮次ID，None则返回当前轮次
        
        Returns:
            Optional[FLRoundInfo]: 轮次信息对象
        """
        if round_id is None:
            return self._current_round_info
        return self.rounds_info.get(round_id)

    def get_training_history(self) -> List[Dict[str, Any]]:
        """
        获取训练历史记录
        
        Returns:
            List[Dict[str, Any]]: 所有轮次的训练记录
        """
        history = []
        for round_id, info in sorted(self.rounds_info.items()):
            history.append({
                "round_id": info.round_id,
                "status": info.status.value,
                "start_time": info.start_time,
                "end_time": info.end_time,
                "duration": (
                    info.end_time - info.start_time
                    if info.end_time else None
                ),
                "selected_clients": len(info.selected_clients),
                "aggregated_updates": info.aggregated_updates,
                "metrics": info.global_metrics
            })
        return history

    def add_pre_aggregation_callback(self, callback: Callable) -> None:
        """
        添加预聚合回调函数
        
        Args:
            callback: 回调函数，接收客户端更新字典
        """
        self._pre_aggregation_callbacks.append(callback)

    def add_post_aggregation_callback(self, callback: Callable) -> None:
        """
        添加后聚合回调函数
        
        Args:
            callback: 回调函数，接收聚合后的全局模型
        """
        self._post_aggregation_callbacks.append(callback)

    def reset(self) -> None:
        """
        重置协调器状态
        
        清除所有训练状态，保留客户端注册信息。
        """
        self.current_round = 0
        self.rounds_info.clear()
        self._client_updates.clear()
        self._current_round_info = None
        self.global_model = None
        self.logger.info("协调器状态已重置")

    def get_client_count(self) -> int:
        """
        获取已注册客户端数量
        
        Returns:
            int: 客户端数量
        """
        return len(self._clients)

    def is_training_complete(self) -> bool:
        """
        检查训练是否完成
        
        Returns:
            bool: 训练是否达到停止条件
        """
        if self.current_round >= self.max_rounds:
            return True
        
        # 检查最近一轮是否达到目标准确率
        if self.current_round > 0:
            last_round = self.rounds_info.get(self.current_round)
            if last_round and last_round.global_metrics:
                accuracy = last_round.global_metrics.get("accuracy", 0.0)
                if accuracy >= self.target_accuracy:
                    return True
        
        return False
