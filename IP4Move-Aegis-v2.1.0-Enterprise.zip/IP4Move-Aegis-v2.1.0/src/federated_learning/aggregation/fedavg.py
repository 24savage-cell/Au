"""
FedAvg聚合实现

支持加权平均和异步聚合的FedAvg算法。
"""

import logging
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import dataclass
from abc import ABC, abstractmethod
import asyncio

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ClientUpdate:
    """客户端更新数据结构"""
    client_id: str
    weights: Dict[str, List[float]]  # 模型权重
    num_samples: int  # 样本数量
    timestamp: float
    version: int = 0  # 模型版本
    
    def __repr__(self) -> str:
        return f"ClientUpdate(client={self.client_id}, samples={self.num_samples})"


class BaseAggregator(ABC):
    """聚合器抽象基类"""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.global_weights: Optional[Dict[str, List[float]]] = None
        self.current_round: int = 0
    
    @abstractmethod
    def aggregate(
        self,
        client_updates: List[ClientUpdate],
        global_weights: Optional[Dict[str, List[float]]] = None
    ) -> Dict[str, List[float]]:
        """执行聚合"""
        pass
    
    def set_global_weights(self, weights: Dict[str, List[float]]) -> None:
        """设置全局权重"""
        self.global_weights = weights


class FedAvgAggregator(BaseAggregator):
    """
    FedAvg聚合器
    
    实现联邦平均算法，支持加权平均
    """
    
    def __init__(self, learning_rate: float = 1.0):
        """
        初始化FedAvg聚合器
        
        Args:
            learning_rate: 学习率
        """
        super().__init__()
        self.learning_rate = learning_rate
        self.logger.info(f"初始化FedAvg聚合器，学习率: {learning_rate}")
    
    def aggregate(
        self,
        client_updates: List[ClientUpdate],
        global_weights: Optional[Dict[str, List[float]]] = None
    ) -> Dict[str, List[float]]:
        """
        执行FedAvg聚合
        
        公式: w_global = sum(n_i * w_i) / sum(n_i)
        
        Args:
            client_updates: 客户端更新列表
            global_weights: 当前全局权重（可选）
            
        Returns:
            新的全局权重
        """
        if not client_updates:
            self.logger.warning("没有客户端更新")
            return global_weights or self.global_weights
        
        # 计算总样本数
        total_samples = sum(update.num_samples for update in client_updates)
        
        if total_samples == 0:
            self.logger.warning("总样本数为0")
            return global_weights or self.global_weights
        
        self.logger.info(f"聚合 {len(client_updates)} 个客户端更新，总样本数: {total_samples}")
        
        # 获取权重键
        weight_keys = client_updates[0].weights.keys()
        
        # 初始化新的全局权重
        new_global_weights: Dict[str, List[float]] = {}
        
        for key in weight_keys:
            # 加权平均
            aggregated = None
            
            for update in client_updates:
                weight = update.num_samples / total_samples
                client_weights = update.weights[key]
                
                if aggregated is None:
                    aggregated = [w * weight for w in client_weights]
                else:
                    aggregated = [a + w * weight for a, w in zip(aggregated, client_weights)]
            
            new_global_weights[key] = aggregated
        
        # 应用学习率
        if global_weights or self.global_weights:
            base_weights = global_weights or self.global_weights
            for key in weight_keys:
                new_global_weights[key] = [
                    base + self.learning_rate * (new - base)
                    for base, new in zip(base_weights[key], new_global_weights[key])
                ]
        
        self.global_weights = new_global_weights
        self.current_round += 1
        
        self.logger.info(f"完成第 {self.current_round} 轮聚合")
        return new_global_weights
    
    def aggregate_simple(
        self,
        client_weights: List[Dict[str, List[float]]],
        weights: Optional[List[float]] = None
    ) -> Dict[str, List[float]]:
        """
        简化版聚合（不依赖ClientUpdate）
        
        Args:
            client_weights: 客户端权重列表
            weights: 权重列表（可选，默认等权重）
            
        Returns:
            聚合后的权重
        """
        if not client_weights:
            return {}
        
        n = len(client_weights)
        if weights is None:
            weights = [1.0 / n] * n
        
        # 归一化权重
        total_weight = sum(weights)
        weights = [w / total_weight for w in weights]
        
        # 聚合
        result: Dict[str, List[float]] = {}
        for key in client_weights[0].keys():
            aggregated = None
            for client_w, weight in zip(client_weights, weights):
                if aggregated is None:
                    aggregated = [w * weight for w in client_w[key]]
                else:
                    aggregated = [a + w * weight for a, w in zip(aggregated, client_w[key])]
            result[key] = aggregated
        
        return result


class AsyncFedAvg(BaseAggregator):
    """
    异步FedAvg聚合器
    
    支持异步客户端更新的聚合
    """
    
    def __init__(
        self,
        learning_rate: float = 1.0,
        staleness_threshold: int = 10
    ):
        """
        初始化异步FedAvg
        
        Args:
            learning_rate: 学习率
            staleness_threshold: 陈旧度阈值
        """
        super().__init__()
        self.learning_rate = learning_rate
        self.staleness_threshold = staleness_threshold
        self.logger.info(f"初始化异步FedAvg，陈旧度阈值: {staleness_threshold}")
        
        # 存储历史权重
        self.weight_history: Dict[int, Dict[str, List[float]]] = {}
        self.pending_updates: List[ClientUpdate] = []
    
    def aggregate(
        self,
        client_updates: List[ClientUpdate],
        global_weights: Optional[Dict[str, List[float]]] = None
    ) -> Dict[str, List[float]]:
        """
        执行异步聚合
        
        Args:
            client_updates: 客户端更新列表
            global_weights: 当前全局权重
            
        Returns:
            新的全局权重
        """
        if global_weights:
            self.global_weights = global_weights
            self.weight_history[self.current_round] = global_weights
        
        if not client_updates:
            return self.global_weights
        
        # 处理每个更新
        for update in client_updates:
            staleness = self.current_round - update.version
            
            if staleness > self.staleness_threshold:
                self.logger.warning(f"客户端 {update.client_id} 更新过于陈旧 ({staleness} 轮)")
                continue
            
            # 计算陈旧度权重衰减
            staleness_weight = 1.0 / (1.0 + staleness)
            
            # 聚合
            self._apply_update(update, staleness_weight)
        
        self.current_round += 1
        self.weight_history[self.current_round] = self.global_weights
        
        # 清理旧历史
        self._cleanup_history()
        
        return self.global_weights
    
    def _apply_update(self, update: ClientUpdate, weight: float) -> None:
        """应用单个更新"""
        if self.global_weights is None:
            self.global_weights = update.weights
            return
        
        total_samples = sum(u.num_samples for u in [update])
        client_weight = update.num_samples / total_samples * weight
        
        for key in self.global_weights.keys():
            self.global_weights[key] = [
                global_w + self.learning_rate * client_weight * (client_w - global_w)
                for global_w, client_w in zip(self.global_weights[key], update.weights[key])
            ]
    
    def _cleanup_history(self) -> None:
        """清理旧的权重历史"""
        if len(self.weight_history) > self.staleness_threshold * 2:
            old_rounds = [
                r for r in self.weight_history.keys()
                if r < self.current_round - self.staleness_threshold
            ]
            for r in old_rounds:
                del self.weight_history[r]
    
    async def aggregate_async(
        self,
        update_queue: asyncio.Queue,
        stop_event: asyncio.Event
    ) -> None:
        """
        异步聚合循环
        
        Args:
            update_queue: 更新队列
            stop_event: 停止事件
        """
        self.logger.info("启动异步聚合循环")
        
        while not stop_event.is_set():
            try:
                # 等待更新
                update = await asyncio.wait_for(
                    update_queue.get(),
                    timeout=1.0
                )
                
                # 聚合
                self.aggregate([update])
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.logger.error(f"聚合错误: {e}")
        
        self.logger.info("异步聚合循环停止")


class WeightedFedAvg(FedAvgAggregator):
    """
    加权FedAvg
    
    支持自定义权重的FedAvg
    """
    
    def __init__(
        self,
        learning_rate: float = 1.0,
        weight_fn: Optional[callable] = None
    ):
        """
        初始化加权FedAvg
        
        Args:
            learning_rate: 学习率
            weight_fn: 权重计算函数
        """
        super().__init__(learning_rate)
        self.weight_fn = weight_fn or self._default_weight_fn
    
    def _default_weight_fn(self, update: ClientUpdate) -> float:
        """默认权重函数（基于样本数）"""
        return float(update.num_samples)
    
    def aggregate(
        self,
        client_updates: List[ClientUpdate],
        global_weights: Optional[Dict[str, List[float]]] = None
    ) -> Dict[str, List[float]]:
        """
        执行加权聚合
        
        Args:
            client_updates: 客户端更新
            global_weights: 全局权重
            
        Returns:
            新的全局权重
        """
        # 计算自定义权重
        custom_weights = [self.weight_fn(update) for update in client_updates]
        total_weight = sum(custom_weights)
        
        if total_weight == 0:
            return global_weights or self.global_weights
        
        # 归一化
        normalized_weights = [w / total_weight for w in custom_weights]
        
        # 使用样本数覆盖
        for update, weight in zip(client_updates, normalized_weights):
            update.num_samples = int(weight * 1000)  # 缩放
        
        return super().aggregate(client_updates, global_weights)


# 便捷函数
def create_fedavg_aggregator(learning_rate: float = 1.0) -> FedAvgAggregator:
    """创建FedAvg聚合器"""
    return FedAvgAggregator(learning_rate)


def create_async_fedavg(
    learning_rate: float = 1.0,
    staleness_threshold: int = 10
) -> AsyncFedAvg:
    """创建异步FedAvg聚合器"""
    return AsyncFedAvg(learning_rate, staleness_threshold)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("FedAvg聚合测试")
    print("=" * 50)
    
    # 创建测试数据
    aggregator = FedAvgAggregator(learning_rate=0.1)
    
    # 模拟客户端更新
    client_updates = [
        ClientUpdate(
            client_id="client_1",
            weights={"layer1": [0.1, 0.2, 0.3], "layer2": [0.4, 0.5]},
            num_samples=100,
            timestamp=0.0
        ),
        ClientUpdate(
            client_id="client_2",
            weights={"layer1": [0.2, 0.3, 0.4], "layer2": [0.5, 0.6]},
            num_samples=150,
            timestamp=0.0
        ),
        ClientUpdate(
            client_id="client_3",
            weights={"layer1": [0.15, 0.25, 0.35], "layer2": [0.45, 0.55]},
            num_samples=80,
            timestamp=0.0
        ),
    ]
    
    print("\n1. FedAvg聚合:")
    print(f"  客户端数量: {len(client_updates)}")
    print(f"  总样本数: {sum(u.num_samples for u in client_updates)}")
    
    # 初始全局权重
    global_weights = {
        "layer1": [0.0, 0.0, 0.0],
        "layer2": [0.0, 0.0]
    }
    
    # 执行聚合
    new_weights = aggregator.aggregate(client_updates, global_weights)
    
    print(f"\n  聚合结果:")
    for key, weights in new_weights.items():
        print(f"    {key}: {weights}")
    
    # 测试异步FedAvg
    print("\n2. 异步FedAvg:")
    async_aggregator = AsyncFedAvg(learning_rate=0.1, staleness_threshold=5)
    
    # 模拟陈旧更新
    stale_update = ClientUpdate(
        client_id="client_4",
        weights={"layer1": [0.3, 0.4, 0.5], "layer2": [0.6, 0.7]},
        num_samples=100,
        timestamp=0.0,
        version=-5  # 陈旧版本
    )
    
    async_aggregator.set_global_weights(global_weights)
    async_aggregator.current_round = 10
    
    result = async_aggregator.aggregate([stale_update])
    print(f"  处理陈旧更新（版本差: 15）")
    print(f"  聚合完成，当前轮次: {async_aggregator.current_round}")
    
    print("\n测试完成!")
