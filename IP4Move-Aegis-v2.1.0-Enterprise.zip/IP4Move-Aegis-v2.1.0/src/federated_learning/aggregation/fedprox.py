"""
FedProx聚合实现

实现带有近端项正则化的联邦学习算法。
"""

import logging
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
import math

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ClientUpdate:
    """客户端更新数据结构"""
    client_id: str
    weights: Dict[str, List[float]]
    num_samples: int
    timestamp: float
    
    def __repr__(self) -> str:
        return f"ClientUpdate(client={self.client_id}, samples={self.num_samples})"


class FedProxAggregator:
    """
    FedProx聚合器
    
    FedProx在本地目标函数中添加近端项，限制本地更新与全局模型的偏离。
    
    本地目标函数: F_k(w) + (mu/2) * ||w - w_global||^2
    """
    
    def __init__(
        self,
        learning_rate: float = 0.01,
        mu: float = 0.01,
        max_iterations: int = 100
    ):
        """
        初始化FedProx聚合器
        
        Args:
            learning_rate: 学习率
            mu: 近端项系数（正则化强度）
            max_iterations: 本地最大迭代次数
        """
        self.learning_rate = learning_rate
        self.mu = mu
        self.max_iterations = max_iterations
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.global_weights: Optional[Dict[str, List[float]]] = None
        self.current_round: int = 0
        
        self.logger.info(f"初始化FedProx，mu={mu}, lr={learning_rate}")
    
    def aggregate(
        self,
        client_updates: List[ClientUpdate],
        global_weights: Optional[Dict[str, List[float]]] = None
    ) -> Dict[str, List[float]]:
        """
        执行FedProx聚合
        
        Args:
            client_updates: 客户端更新列表
            global_weights: 当前全局权重
            
        Returns:
            新的全局权重
        """
        if global_weights:
            self.global_weights = global_weights
        
        if not client_updates:
            self.logger.warning("没有客户端更新")
            return self.global_weights or {}
        
        if self.global_weights is None:
            # 第一轮，使用第一个客户端的权重
            self.global_weights = client_updates[0].weights
            return self.global_weights
        
        # 计算总样本数
        total_samples = sum(update.num_samples for update in client_updates)
        
        self.logger.info(f"FedProx聚合 {len(client_updates)} 个客户端，mu={self.mu}")
        
        # 加权平均
        new_global_weights: Dict[str, List[float]] = {}
        
        for key in self.global_weights.keys():
            aggregated = None
            
            for update in client_updates:
                weight = update.num_samples / total_samples
                client_weights = update.weights[key]
                
                if aggregated is None:
                    aggregated = [w * weight for w in client_weights]
                else:
                    aggregated = [a + w * weight for a, w in zip(aggregated, client_weights)]
            
            new_global_weights[key] = aggregated
        
        self.global_weights = new_global_weights
        self.current_round += 1
        
        self.logger.info(f"完成第 {self.current_round} 轮FedProx聚合")
        return new_global_weights
    
    def local_update_proximal(
        self,
        local_weights: Dict[str, List[float]],
        gradients: Dict[str, List[float]],
        global_weights: Dict[str, List[float]]
    ) -> Dict[str, List[float]]:
        """
        执行带近端项的本地更新
        
        w_new = w - lr * (gradient + mu * (w - w_global))
        
        Args:
            local_weights: 本地权重
            gradients: 梯度
            global_weights: 全局权重
            
        Returns:
            更新后的本地权重
        """
        new_weights: Dict[str, List[float]] = {}
        
        for key in local_weights.keys():
            new_weights[key] = []
            
            for w_local, grad, w_global in zip(
                local_weights[key],
                gradients[key],
                global_weights[key]
            ):
                # 标准梯度下降
                standard_update = w_local - self.learning_rate * grad
                
                # 近端项: (mu/2) * ||w - w_global||^2 的梯度是 mu * (w - w_global)
                proximal_term = self.mu * (w_local - w_global)
                
                # 组合更新
                w_new = w_local - self.learning_rate * (grad + proximal_term)
                
                new_weights[key].append(w_new)
        
        return new_weights
    
    def compute_proximal_term(
        self,
        local_weights: Dict[str, List[float]],
        global_weights: Dict[str, List[float]]
    ) -> float:
        """
        计算近端项值
        
        (mu/2) * ||w_local - w_global||^2
        
        Args:
            local_weights: 本地权重
            global_weights: 全局权重
            
        Returns:
            近端项值
        """
        squared_diff_sum = 0.0
        
        for key in local_weights.keys():
            for w_local, w_global in zip(local_weights[key], global_weights[key]):
                diff = w_local - w_global
                squared_diff_sum += diff * diff
        
        proximal_term = (self.mu / 2.0) * squared_diff_sum
        return proximal_term
    
    def compute_divergence(
        self,
        local_weights: Dict[str, List[float]],
        global_weights: Dict[str, List[float]]
    ) -> float:
        """
        计算本地模型与全局模型的偏离度
        
        Args:
            local_weights: 本地权重
            global_weights: 全局权重
            
        Returns:
            偏离度（欧氏距离）
        """
        squared_diff_sum = 0.0
        count = 0
        
        for key in local_weights.keys():
            for w_local, w_global in zip(local_weights[key], global_weights[key]):
                diff = w_local - w_global
                squared_diff_sum += diff * diff
                count += 1
        
        if count == 0:
            return 0.0
        
        return math.sqrt(squared_diff_sum / count)


# 便捷函数
def create_fedprox_aggregator(
    learning_rate: float = 0.01,
    mu: float = 0.01
) -> FedProxAggregator:
    """创建FedProx聚合器"""
    return FedProxAggregator(learning_rate, mu)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("FedProx聚合测试")
    print("=" * 50)
    
    aggregator = FedProxAggregator(learning_rate=0.01, mu=0.1)
    
    # 模拟全局权重
    global_weights = {
        "layer1": [0.5, 0.5, 0.5],
        "layer2": [0.3, 0.3]
    }
    
    # 模拟客户端更新
    client_updates = [
        ClientUpdate(
            client_id="client_1",
            weights={"layer1": [0.6, 0.4, 0.5], "layer2": [0.4, 0.2]},
            num_samples=100,
            timestamp=0.0
        ),
        ClientUpdate(
            client_id="client_2",
            weights={"layer1": [0.4, 0.6, 0.4], "layer2": [0.2, 0.4]},
            num_samples=150,
            timestamp=0.0
        ),
    ]
    
    print("\n1. FedProx聚合:")
    result = aggregator.aggregate(client_updates, global_weights)
    print(f"  聚合后权重: {result}")
    
    # 测试近端项计算
    print("\n2. 近端项计算:")
    local_weights = {
        "layer1": [0.7, 0.3, 0.6],
        "layer2": [0.5, 0.1]
    }
    
    proximal_term = aggregator.compute_proximal_term(local_weights, global_weights)
    print(f"  近端项值: {proximal_term}")
    
    divergence = aggregator.compute_divergence(local_weights, global_weights)
    print(f"  偏离度: {divergence}")
    
    print("\n测试完成!")
