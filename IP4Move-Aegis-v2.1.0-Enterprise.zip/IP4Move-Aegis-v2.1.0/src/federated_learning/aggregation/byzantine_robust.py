"""
拜占庭鲁棒聚合

提供对抗拜占庭故障的鲁棒聚合算法。
"""

import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class RobustAggregationResult:
    """鲁棒聚合结果"""
    aggregated_weights: List[float]
    num_clients: int
    num_byzantine: int
    success: bool
    error_message: Optional[str] = None


class KrumAggregator:
    """
    Krum聚合器
    
    选择与其他梯度最相似的梯度作为聚合结果。
    """
    
    def __init__(self, num_byzantine: int):
        """
        初始化Krum聚合器
        
        Args:
            num_byzantine: 预期的拜占庭节点数
        """
        self.num_byzantine = num_byzantine
        logger.info(f"初始化Krum聚合器: num_byzantine={num_byzantine}")
    
    def aggregate(self, client_updates: List[List[float]]) -> RobustAggregationResult:
        """
        执行Krum聚合
        
        Args:
            client_updates: 客户端更新列表
            
        Returns:
            聚合结果
        """
        try:
            n = len(client_updates)
            if n <= 2 * self.num_byzantine:
                return RobustAggregationResult(
                    aggregated_weights=[],
                    num_clients=n,
                    num_byzantine=0,
                    success=False,
                    error_message="客户端数量不足"
                )
            
            # 计算每对梯度之间的距离
            distances = np.zeros((n, n))
            for i in range(n):
                for j in range(i + 1, n):
                    dist = np.linalg.norm(np.array(client_updates[i]) - np.array(client_updates[j]))
                    distances[i, j] = dist
                    distances[j, i] = dist
            
            # 为每个梯度计算与其他n - num_byzantine - 2个最近梯度的距离和
            scores = []
            for i in range(n):
                sorted_distances = np.sort(distances[i])
                score = np.sum(sorted_distances[1:n - self.num_byzantine - 1])
                scores.append((score, i))
            
            # 选择得分最小的梯度
            scores.sort()
            selected_idx = scores[0][1]
            selected_update = client_updates[selected_idx]
            
            logger.info(f"Krum聚合完成: 选择客户端 {selected_idx}")
            
            return RobustAggregationResult(
                aggregated_weights=selected_update,
                num_clients=n,
                num_byzantine=self.num_byzantine,
                success=True
            )
            
        except Exception as e:
            logger.error(f"Krum聚合失败: {e}")
            return RobustAggregationResult(
                aggregated_weights=[],
                num_clients=len(client_updates),
                num_byzantine=0,
                success=False,
                error_message=str(e)
            )


class TrimmedMeanAggregator:
    """
    截断均值聚合器
    
    去除最高和最低的梯度值后计算均值。
    """
    
    def __init__(self, trim_ratio: float = 0.1):
        """
        初始化截断均值聚合器
        
        Args:
            trim_ratio: 截断比例
        """
        self.trim_ratio = trim_ratio
        logger.info(f"初始化截断均值聚合器: trim_ratio={trim_ratio}")
    
    def aggregate(self, client_updates: List[List[float]]) -> RobustAggregationResult:
        """
        执行截断均值聚合
        
        Args:
            client_updates: 客户端更新列表
            
        Returns:
            聚合结果
        """
        try:
            n = len(client_updates)
            if n == 0:
                return RobustAggregationResult(
                    aggregated_weights=[],
                    num_clients=0,
                    num_byzantine=0,
                    success=False,
                    error_message="没有客户端更新"
                )
            
            # 转换为numpy数组
            updates_array = np.array(client_updates)
            
            # 计算截断数量
            trim_count = int(n * self.trim_ratio)
            
            # 对每个参数位置进行截断均值计算
            aggregated = []
            for i in range(updates_array.shape[1]):
                sorted_values = np.sort(updates_array[:, i])
                trimmed_values = sorted_values[trim_count:n - trim_count]
                aggregated.append(np.mean(trimmed_values))
            
            logger.info(f"截断均值聚合完成: 客户端={n}, 截断={trim_count}")
            
            return RobustAggregationResult(
                aggregated_weights=aggregated,
                num_clients=n,
                num_byzantine=trim_count * 2,
                success=True
            )
            
        except Exception as e:
            logger.error(f"截断均值聚合失败: {e}")
            return RobustAggregationResult(
                aggregated_weights=[],
                num_clients=len(client_updates),
                num_byzantine=0,
                success=False,
                error_message=str(e)
            )


class FoolsGoldAggregator:
    """
    FoolsGold聚合器
    
    基于梯度相似性检测和惩罚拜占庭节点。
    """
    
    def __init__(self, similarity_threshold: float = 0.5):
        """
        初始化FoolsGold聚合器
        
        Args:
            similarity_threshold: 相似度阈值
        """
        self.similarity_threshold = similarity_threshold
        self.client_reputations: Dict[int, float] = {}
        logger.info(f"初始化FoolsGold聚合器: threshold={similarity_threshold}")
    
    def aggregate(self, client_updates: List[List[float]], client_ids: Optional[List[int]] = None) -> RobustAggregationResult:
        """
        执行FoolsGold聚合
        
        Args:
            client_updates: 客户端更新列表
            client_ids: 客户端ID列表
            
        Returns:
            聚合结果
        """
        try:
            n = len(client_updates)
            if n == 0:
                return RobustAggregationResult(
                    aggregated_weights=[],
                    num_clients=0,
                    num_byzantine=0,
                    success=False,
                    error_message="没有客户端更新"
                )
            
            if client_ids is None:
                client_ids = list(range(n))
            
            # 初始化声誉
            for client_id in client_ids:
                if client_id not in self.client_reputations:
                    self.client_reputations[client_id] = 1.0
            
            # 计算余弦相似度矩阵
            updates_array = np.array(client_updates)
            similarities = np.zeros((n, n))
            
            for i in range(n):
                for j in range(n):
                    if i != j:
                        dot_product = np.dot(updates_array[i], updates_array[j])
                        norm_i = np.linalg.norm(updates_array[i])
                        norm_j = np.linalg.norm(updates_array[j])
                        if norm_i > 0 and norm_j > 0:
                            similarities[i, j] = dot_product / (norm_i * norm_j)
            
            # 检测可疑节点（相似度过高）
            suspicious_counts = np.sum(similarities > self.similarity_threshold, axis=1)
            
            # 更新声誉并计算权重
            weights = []
            for i, client_id in enumerate(client_ids):
                # 惩罚可疑节点
                if suspicious_counts[i] > n * 0.5:
                    self.client_reputations[client_id] *= 0.5
                else:
                    self.client_reputations[client_id] = min(1.0, self.client_reputations[client_id] + 0.1)
                
                weights.append(self.client_reputations[client_id])
            
            # 归一化权重
            total_weight = sum(weights)
            if total_weight > 0:
                weights = [w / total_weight for w in weights]
            else:
                weights = [1.0 / n] * n
            
            # 加权聚合
            aggregated = np.zeros(len(client_updates[0]))
            for i, update in enumerate(client_updates):
                aggregated += weights[i] * np.array(update)
            
            num_byzantine = int(sum(suspicious_counts > n * 0.5))
            logger.info(f"FoolsGold聚合完成: 客户端={n}, 可疑={num_byzantine}")
            
            return RobustAggregationResult(
                aggregated_weights=aggregated.tolist(),
                num_clients=n,
                num_byzantine=num_byzantine,
                success=True
            )
            
        except Exception as e:
            logger.error(f"FoolsGold聚合失败: {e}")
            return RobustAggregationResult(
                aggregated_weights=[],
                num_clients=len(client_updates),
                num_byzantine=0,
                success=False,
                error_message=str(e)
            )


class ByzantineRobustAggregation:
    """
    拜占庭鲁棒聚合
    
    统一的拜占庭鲁棒聚合接口。
    """
    
    AGGREGATORS = {
        'krum': KrumAggregator,
        'trimmed_mean': TrimmedMeanAggregator,
        'fools_gold': FoolsGoldAggregator,
    }
    
    def __init__(self, method: str = 'krum', **kwargs):
        """
        初始化拜占庭鲁棒聚合
        
        Args:
            method: 聚合方法
            **kwargs: 聚合器参数
        """
        if method not in self.AGGREGATORS:
            raise ValueError(f"不支持的聚合方法: {method}")
        
        self.aggregator = self.AGGREGATORS[method](**kwargs)
        self.method = method
        logger.info(f"初始化拜占庭鲁棒聚合: method={method}")
    
    def aggregate(self, client_updates: List[List[float]], **kwargs) -> RobustAggregationResult:
        """
        执行聚合
        
        Args:
            client_updates: 客户端更新列表
            **kwargs: 额外参数
            
        Returns:
            聚合结果
        """
        if self.method == 'fools_gold':
            return self.aggregator.aggregate(client_updates, **kwargs)
        else:
            return self.aggregator.aggregate(client_updates)
