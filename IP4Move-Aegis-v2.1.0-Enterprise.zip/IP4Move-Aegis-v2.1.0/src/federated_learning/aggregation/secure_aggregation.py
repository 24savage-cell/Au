"""
安全聚合

基于秘密共享的安全聚合实现。
"""

import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import random

logger = logging.getLogger(__name__)


@dataclass
class SecureAggregationResult:
    """安全聚合结果"""
    aggregated_weights: List[float]
    num_clients: int
    success: bool
    error_message: Optional[str] = None


class SecureAggregator:
    """
    安全聚合器
    
    基于秘密共享的安全聚合实现。
    """
    
    def __init__(self, num_clients: int, threshold: int):
        """
        初始化安全聚合器
        
        Args:
            num_clients: 客户端数量
            threshold: 秘密共享阈值
        """
        self.num_clients = num_clients
        self.threshold = threshold
        self.client_shares: Dict[int, List[float]] = {}
        logger.info(f"初始化安全聚合器: clients={num_clients}, threshold={threshold}")
    
    def submit_shares(self, client_id: int, shares: List[float]) -> bool:
        """
        提交秘密份额
        
        Args:
            client_id: 客户端ID
            shares: 秘密份额
            
        Returns:
            是否成功提交
        """
        if client_id < 0 or client_id >= self.num_clients:
            logger.error(f"无效的客户端ID: {client_id}")
            return False
        
        self.client_shares[client_id] = shares
        logger.debug(f"客户端 {client_id} 提交份额，长度={len(shares)}")
        return True
    
    def aggregate(self) -> SecureAggregationResult:
        """
        执行安全聚合
        
        Returns:
            聚合结果
        """
        if len(self.client_shares) < self.threshold:
            return SecureAggregationResult(
                aggregated_weights=[],
                num_clients=len(self.client_shares),
                success=False,
                error_message=f"客户端数量不足: {len(self.client_shares)} < {self.threshold}"
            )
        
        try:
            # 获取所有份额
            all_shares = list(self.client_shares.values())
            
            if not all_shares:
                return SecureAggregationResult(
                    aggregated_weights=[],
                    num_clients=0,
                    success=False,
                    error_message="没有可用的份额"
                )
            
            # 检查维度一致性
            share_length = len(all_shares[0])
            for shares in all_shares:
                if len(shares) != share_length:
                    return SecureAggregationResult(
                        aggregated_weights=[],
                        num_clients=len(all_shares),
                        success=False,
                        error_message="份额维度不一致"
                    )
            
            # 逐元素求和并平均
            aggregated = []
            for i in range(share_length):
                element_sum = sum(shares[i] for shares in all_shares)
                aggregated.append(element_sum / len(all_shares))
            
            logger.info(f"安全聚合完成: 客户端={len(all_shares)}, 维度={share_length}")
            
            return SecureAggregationResult(
                aggregated_weights=aggregated,
                num_clients=len(all_shares),
                success=True
            )
            
        except Exception as e:
            logger.error(f"安全聚合失败: {e}")
            return SecureAggregationResult(
                aggregated_weights=[],
                num_clients=len(self.client_shares),
                success=False,
                error_message=str(e)
            )
    
    def reset(self):
        """重置聚合器状态"""
        self.client_shares.clear()
        logger.info("安全聚合器状态已重置")
