"""
联邦学习安全模块

提供联邦学习中的安全聚合、隐私保护和防御机制。
"""

from .aggregation.fedavg import FedAvgAggregator, AsyncFedAvg
from .aggregation.fedprox import FedProxAggregator
from .aggregation.secure_aggregation import SecureAggregator
from .aggregation.byzantine_robust import (
    KrumAggregator,
    TrimmedMeanAggregator,
    FoolsGoldAggregator,
    ByzantineRobustAggregation
)
from .privacy.dp_federated import DPFederatedLearning
from differential_privacy.mechanisms.gaussian import GaussianMechanism
from differential_privacy.mechanisms.laplace import LaplaceMechanism
from .privacy.secure_multiparty import MPCFederatedAggregation
from .defense.gradient_compression import (
    TopKCompression,
    RandomQuantization,
    GradientSparsification
)
from .defense.poisoning_detection import (
    DataPoisoningDetector,
    ModelPoisoningDetector
)
from .defense.inference_attack_defense import (
    MembershipInferenceDefense,
    AttributeInferenceDefense
)
from .orchestration.coordinator import FLCoordinator
from .orchestration.client_manager import FLClientManager

__version__ = "1.0.0"
__all__ = [
    "FedAvgAggregator",
    "AsyncFedAvg",
    "FedProxAggregator",
    "SecureAggregator",
    "KrumAggregator",
    "TrimmedMeanAggregator",
    "FoolsGoldAggregator",
    "ByzantineRobustAggregation",
    "DPFederatedLearning",
    "GaussianMechanism",
    "LaplaceMechanism",
    "MPCFederatedAggregation",
    "TopKCompression",
    "RandomQuantization",
    "GradientSparsification",
    "DataPoisoningDetector",
    "ModelPoisoningDetector",
    "MembershipInferenceDefense",
    "AttributeInferenceDefense",
    "FLCoordinator",
    "FLClientManager",
]
