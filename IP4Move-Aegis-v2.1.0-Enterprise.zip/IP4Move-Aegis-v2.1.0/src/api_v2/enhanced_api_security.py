"""
API安全增强模块 V2 (Enhanced API Security Module V2)

本模块实现了API层面的全面安全增强，包含四个核心组件：
1. ShortLivedAPIKey - 短期API密钥管理，基于JWT的24小时有效期密钥
2. FineGrainedRBAC - 细粒度基于角色的访问控制，端点级权限定义
3. RateLimiter - API请求速率限制器，令牌桶和滑动窗口算法
4. APIAuditLogger - API请求审计日志，不可篡改的HMAC链式日志

This module implements comprehensive API-level security enhancement with four
core components: short-lived API keys, fine-grained RBAC, rate limiting,
and tamper-proof audit logging.
"""

import os
import json
import time
import hmac
import hashlib
import base64
import logging
import threading
import secrets
from typing import Optional, Dict, List, Set, Tuple, Any, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import defaultdict

# 尝试导入cryptography库，用于JWT签名和验证
try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import rsa, padding
    from cryptography.hazmat.primitives.serialization import (
        Encoding, PrivateFormat, PublicFormat, NoEncryption,
    )
    from cryptography.hazmat.backends import default_backend
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

logger = logging.getLogger(__name__)

# ============================================================================
# 安全常量定义
# ============================================================================

# API密钥相关常量
API_KEY_EXPIRY_HOURS = 24                # API密钥有效期（小时）
API_KEY_REFRESH_WINDOW_HOURS = 6         # 密钥刷新窗口期（小时）
API_KEY_MAX_LENGTH = 512                 # API密钥最大长度
JWT_ALGORITHM = "HS256"                  # JWT签名算法
JWT_ISSUER = "ip4move-aegis-v2"          # JWT签发者
JWT_ACCESS_TOKEN_TYPE = "access"         # 访问令牌类型
JWT_REFRESH_TOKEN_TYPE = "refresh"       # 刷新令牌类型

# RBAC相关常量
DEFAULT_ROLE = "viewer"                  # 默认角色
SUPER_ADMIN_ROLE = "super_admin"         # 超级管理员角色
PERMISSION_SEPARATOR = ":"               # 权限分隔符

# 速率限制相关常量
DEFAULT_RATE_LIMIT = 100                 # 默认速率限制（请求/分钟）
DEFAULT_BURST_SIZE = 20                  # 默认突发大小
RATE_LIMIT_WINDOW_SECONDS = 60           # 速率限制窗口（秒）
ADAPTIVE_THRESHOLD = 0.8                 # 自适应限制触发阈值
ADAPTIVE_MIN_FACTOR = 0.1                # 自适应限制最小因子

# 审计日志相关常量
AUDIT_LOG_MAX_ENTRIES = 100000           # 审计日志最大条目数
AUDIT_LOG_ROTATION_SIZE = 50000          # 日志轮转大小
HMAC_ALGORITHM = "sha256"                # HMAC算法
AUDIT_LOG_FILE = "api_audit.log"         # 审计日志文件名


# ============================================================================
# 辅助类和枚举
# ============================================================================

class TokenType(Enum):
    """令牌类型枚举"""
    ACCESS = "access"       # 访问令牌
    REFRESH = "refresh"     # 刷新令牌


class Permission(Enum):
    """权限枚举 - 定义所有可用的端点级权限"""
    # 读取权限
    NODE_READ = "node:read"
    NODE_LIST = "node:list"
    ROUTE_READ = "route:read"
    ROUTE_CREATE = "route:create"
    CRYPTO_READ = "crypto:read"
    CRYPTO_MANAGE = "crypto:manage"
    DHT_READ = "dht:read"
    DHT_WRITE = "dht:write"
    MIXNET_READ = "mixnet:read"
    MIXNET_MANAGE = "mixnet:manage"
    SECURITY_READ = "security:read"
    SECURITY_MANAGE = "security:manage"
    CONFIG_READ = "config:read"
    CONFIG_WRITE = "config:write"
    ADMIN_FULL = "admin:full"
    AUDIT_READ = "audit:read"


class Role(Enum):
    """角色枚举 - 预定义的角色及其权限"""
    VIEWER = "viewer"
    OPERATOR = "operator"
    ADMIN = "admin"
    SUPER_ADMIN = "super_admin"


@dataclass
class APIKeyInfo:
    """
    API密钥信息数据结构

    存储已签发的API密钥的元信息。

    Attributes:
        key_id: 密钥唯一标识符
        user_id: 关联的用户标识符
        token_type: 令牌类型（访问/刷新）
        issued_at: 签发时间戳
        expires_at: 过期时间戳
        permissions: 授予的权限列表
        is_revoked: 是否已被吊销
        revocation_reason: 吊销原因
        last_used_at: 最后使用时间戳
        usage_count: 使用次数
    """
    key_id: str
    user_id: str
    token_type: TokenType
    issued_at: float
    expires_at: float
    permissions: List[str] = field(default_factory=list)
    is_revoked: bool = False
    revocation_reason: str = ""
    last_used_at: Optional[float] = None
    usage_count: int = 0


@dataclass
class RateLimitConfig:
    """
    速率限制配置数据结构

    Attributes:
        max_requests: 时间窗口内最大请求数
        burst_size: 突发请求数（令牌桶容量）
        window_seconds: 时间窗口大小（秒）
        adaptive_enabled: 是否启用自适应限制
        adaptive_threshold: 自适应触发阈值（0.0-1.0）
    """
    max_requests: int = DEFAULT_RATE_LIMIT
    burst_size: int = DEFAULT_BURST_SIZE
    window_seconds: int = RATE_LIMIT_WINDOW_SECONDS
    adaptive_enabled: bool = True
    adaptive_threshold: float = ADAPTIVE_THRESHOLD


@dataclass
class AuditLogEntry:
    """
    审计日志条目数据结构

    Attributes:
        entry_id: 条目唯一标识符
        timestamp: 事件时间戳
        sequence: 序列号（用于HMAC链）
        client_ip: 客户端IP地址
        user_id: 用户标识符
        api_key_id: API密钥标识符
        method: HTTP方法
        endpoint: API端点路径
        status_code: HTTP响应状态码
        request_size: 请求体大小（字节）
        response_size: 响应体大小（字节）
        latency_ms: 请求延迟（毫秒）
        is_anomalous: 是否为异常行为
        anomaly_reason: 异常原因
        previous_hash: 前一条日志的HMAC哈希（链式完整性）
        entry_hash: 本条日志的HMAC哈希
    """
    entry_id: str
    timestamp: float
    sequence: int
    client_ip: str = ""
    user_id: str = ""
    api_key_id: str = ""
    method: str = ""
    endpoint: str = ""
    status_code: int = 0
    request_size: int = 0
    response_size: int = 0
    latency_ms: float = 0.0
    is_anomalous: bool = False
    anomaly_reason: str = ""
    previous_hash: str = ""
    entry_hash: str = ""


# ============================================================================
# 简易JWT实现（不依赖PyJWT）
# ============================================================================

class SimpleJWT:
    """
    轻量级JWT实现 (Lightweight JWT Implementation)

    提供JWT令牌的编码和解码功能，支持HS256签名算法。
    在cryptography库可用时使用HMAC-SHA256签名。

    注意：这是一个简化实现，用于演示目的。生产环境建议使用
    PyJWT或python-jose等成熟库。
    """

    def __init__(self, secret_key: bytes) -> None:
        """
        初始化JWT处理器。

        Args:
            secret_key: 签名密钥
        """
        self._secret_key = secret_key

    def encode(
        self,
        payload: Dict[str, Any],
        token_type: str = JWT_ACCESS_TOKEN_TYPE,
        expiry_hours: float = API_KEY_EXPIRY_HOURS,
    ) -> str:
        """
        编码JWT令牌。

        Args:
            payload: 载荷数据
            token_type: 令牌类型
            expiry_hours: 过期时间（小时）

        Returns:
            编码后的JWT字符串
        """
        now = time.time()

        # 构建JWT头部
        header = {
            "alg": JWT_ALGORITHM,
            "typ": "JWT",
        }

        # 构建JWT载荷
        jwt_payload = {
            "iss": JWT_ISSUER,
            "iat": int(now),
            "exp": int(now + expiry_hours * 3600),
            "jti": secrets.token_hex(16),  # JWT ID
            "type": token_type,
            **payload,
        }

        # Base64URL编码
        header_b64 = self._base64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
        payload_b64 = self._base64url_encode(json.dumps(jwt_payload, separators=(",", ":")).encode("utf-8"))

        # 计算签名
        signing_input = f"{header_b64}.{payload_b64}"
        signature = self._sign(signing_input.encode("utf-8"))
        signature_b64 = self._base64url_encode(signature)

        return f"{header_b64}.{payload_b64}.{signature_b64}"

    def decode(self, token: str) -> Dict[str, Any]:
        """
        解码并验证JWT令牌。

        Args:
            token: JWT字符串

        Returns:
            解码后的载荷字典

        Raises:
            ValueError: 如果令牌格式无效、签名验证失败或令牌已过期
        """
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError("无效的JWT格式：必须包含3个部分")

        header_b64, payload_b64, signature_b64 = parts

        # 验证签名
        signing_input = f"{header_b64}.{payload_b64}".encode("utf-8")
        expected_signature = self._sign(signing_input)
        actual_signature = self._base64url_decode(signature_b64)

        if not hmac.compare_digest(expected_signature, actual_signature):
            raise ValueError("JWT签名验证失败")

        # 解码载荷
        try:
            payload = json.loads(self._base64url_decode(payload_b64))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            raise ValueError(f"JWT载荷解码失败: {e}")

        # 验证过期时间
        if "exp" in payload and payload["exp"] < time.time():
            raise ValueError("JWT令牌已过期")

        # 验证签发者
        if payload.get("iss") != JWT_ISSUER:
            raise ValueError(f"无效的JWT签发者: {payload.get('iss')}")

        return payload

    def _sign(self, data: bytes) -> bytes:
        """
        使用HMAC-SHA256对数据进行签名。

        Args:
            data: 要签名的数据

        Returns:
            签名结果
        """
        return hmac.new(self._secret_key, data, hashlib.sha256).digest()

    @staticmethod
    def _base64url_encode(data: bytes) -> str:
        """
        Base64URL编码（无填充）。

        Args:
            data: 要编码的数据

        Returns:
            Base64URL字符串
        """
        return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")

    @staticmethod
    def _base64url_decode(data: str) -> bytes:
        """
        Base64URL解码（支持无填充）。

        Args:
            data: Base64URL字符串

        Returns:
            解码后的字节数据
        """
        # 添加填充
        padding_needed = 4 - len(data) % 4
        if padding_needed != 4:
            data += "=" * padding_needed
        return base64.urlsafe_b64decode(data)


# ============================================================================
# 短期API密钥管理
# ============================================================================

class ShortLivedAPIKey:
    """
    短期API密钥管理器 (Short-Lived API Key Manager)

    基于JWT的短期API密钥管理系统，支持24小时有效期、
    可刷新token机制、密钥自动过期和密钥吊销列表。

    核心特性：
    - JWT格式密钥，HS256签名，24小时有效期
    - 访问令牌 + 刷新令牌双令牌机制
    - 密钥自动过期检查
    - 密钥吊销列表（黑名单）
    - 密钥使用统计和审计

    使用示例：
        >>> key_manager = ShortLivedAPIKey(secret="my-secret-key")
        >>> access_token, refresh_token = key_manager.issue_key_pair(
        ...     user_id="user_001",
        ...     permissions=["node:read", "route:read"],
        ... )
        >>> payload = key_manager.validate_token(access_token)
        >>> key_manager.revoke_token(access_token, reason="安全原因")
    """

    def __init__(
        self,
        secret: Optional[str] = None,
        access_token_expiry_hours: float = API_KEY_EXPIRY_HOURS,
        refresh_token_expiry_hours: float = API_KEY_EXPIRY_HOURS * 7,
    ) -> None:
        """
        初始化短期API密钥管理器。

        Args:
            secret: 签名密钥。如果未提供，将自动生成随机密钥。
            access_token_expiry_hours: 访问令牌有效期（小时）
            refresh_token_expiry_hours: 刷新令牌有效期（小时）
        """
        # 初始化签名密钥
        secret_bytes = (secret or secrets.token_hex(32)).encode("utf-8")
        self._jwt = SimpleJWT(secret_bytes)
        self._secret = secret_bytes

        # 配置过期时间
        self._access_expiry = access_token_expiry_hours
        self._refresh_expiry = refresh_token_expiry_hours

        # 密钥存储（key_id -> APIKeyInfo）
        self._keys: Dict[str, APIKeyInfo] = {}

        # 吊销列表（key_id -> 吊销原因）
        self._revocation_list: Dict[str, Tuple[float, str]] = {}

        # 刷新令牌映射（refresh_jti -> access_key_id）
        self._refresh_mapping: Dict[str, str] = {}

        # 线程锁
        self._lock = threading.RLock()

        # 统计信息
        self._total_issued: int = 0
        self._total_refreshed: int = 0
        self._total_revoked: int = 0

        logger.info(
            "短期API密钥管理器已初始化 [访问令牌有效期=%.1fh, 刷新令牌有效期=%.1fh]",
            access_token_expiry_hours,
            refresh_token_expiry_hours,
        )

    def issue_key_pair(
        self,
        user_id: str,
        permissions: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Tuple[str, str]:
        """
        签发访问令牌和刷新令牌对。

        Args:
            user_id: 用户标识符
            permissions: 授予的权限列表
            metadata: 附加元数据

        Returns:
            (访问令牌, 刷新令牌) 元组

        Raises:
            ValueError: 如果user_id为空
        """
        if not user_id:
            raise ValueError("用户标识符不能为空")

        perms = permissions or []

        # 签发访问令牌
        access_key_id = secrets.token_hex(16)
        access_payload = {
            "sub": user_id,
            "kid": access_key_id,
            "permissions": perms,
            "metadata": metadata or {},
        }
        access_token = self._jwt.encode(
            access_payload,
            token_type=JWT_ACCESS_TOKEN_TYPE,
            expiry_hours=self._access_expiry,
        )

        # 签发刷新令牌
        refresh_key_id = secrets.token_hex(16)
        refresh_payload = {
            "sub": user_id,
            "kid": refresh_key_id,
            "access_kid": access_key_id,
        }
        refresh_token = self._jwt.encode(
            refresh_payload,
            token_type=JWT_REFRESH_TOKEN_TYPE,
            expiry_hours=self._refresh_expiry,
        )

        now = time.time()

        # 存储访问令牌信息
        with self._lock:
            self._keys[access_key_id] = APIKeyInfo(
                key_id=access_key_id,
                user_id=user_id,
                token_type=TokenType.ACCESS,
                issued_at=now,
                expires_at=now + self._access_expiry * 3600,
                permissions=perms,
            )

            # 存储刷新令牌映射
            self._refresh_mapping[refresh_key_id] = access_key_id

            self._total_issued += 1

        logger.info(
            "API密钥对已签发 [用户=%s, 访问密钥ID=%s, 权限数=%d]",
            user_id,
            access_key_id,
            len(perms),
        )

        return access_token, refresh_token

    def validate_token(self, token: str) -> Dict[str, Any]:
        """
        验证API令牌的有效性。

        解码并验证JWT令牌，检查签名、过期时间和吊销状态。

        Args:
            token: JWT令牌字符串

        Returns:
            解码后的载荷字典

        Raises:
            ValueError: 如果令牌无效、已过期或已被吊销
        """
        # 解码并验证JWT
        payload = self._jwt.decode(token)

        key_id = payload.get("kid", "")
        token_type = payload.get("type", "")

        with self._lock:
            # 检查吊销列表
            if key_id in self._revocation_list:
                _, reason = self._revocation_list[key_id]
                raise ValueError(f"令牌已被吊销: {reason}")

            # 更新使用统计
            if key_id in self._keys:
                key_info = self._keys[key_id]
                key_info.last_used_at = time.time()
                key_info.usage_count += 1

        logger.debug(
            "令牌验证通过 [密钥ID=%s, 类型=%s, 用户=%s]",
            key_id,
            token_type,
            payload.get("sub", ""),
        )

        return payload

    def refresh_access_token(self, refresh_token: str) -> str:
        """
        使用刷新令牌获取新的访问令牌。

        验证刷新令牌的有效性，并签发新的访问令牌对。
        旧的访问令牌将被吊销。

        Args:
            refresh_token: 刷新令牌字符串

        Returns:
            新的访问令牌

        Raises:
            ValueError: 如果刷新令牌无效或已过期
        """
        # 验证刷新令牌
        payload = self._jwt.decode(refresh_token)

        if payload.get("type") != JWT_REFRESH_TOKEN_TYPE:
            raise ValueError("无效的刷新令牌类型")

        refresh_key_id = payload.get("kid", "")
        user_id = payload.get("sub", "")
        old_access_key_id = payload.get("access_kid", "")

        with self._lock:
            # 检查刷新令牌映射
            if refresh_key_id not in self._refresh_mapping:
                raise ValueError("刷新令牌映射不存在")

            # 吊销旧的访问令牌
            if old_access_key_id in self._keys:
                self._revoke_key_internal(old_access_key_id, "令牌刷新")

            # 获取旧令牌的权限
            old_permissions = []
            if old_access_key_id in self._keys:
                old_permissions = self._keys[old_access_key_id].permissions

        # 签发新的访问令牌
        new_access_token, new_refresh_token = self.issue_key_pair(
            user_id=user_id,
            permissions=old_permissions,
        )

        with self._lock:
            self._total_refreshed += 1

        logger.info(
            "访问令牌已刷新 [用户=%s, 旧密钥=%s, 新密钥=%s]",
            user_id,
            old_access_key_id[:8],
            payload.get("kid", "")[:8],
        )

        return new_access_token

    def revoke_token(
        self,
        token: Optional[str] = None,
        key_id: Optional[str] = None,
        reason: str = "手动吊销",
    ) -> bool:
        """
        吊销API令牌。

        可以通过令牌字符串或密钥ID来吊销。

        Args:
            token: JWT令牌字符串
            key_id: 密钥标识符
            reason: 吊销原因

        Returns:
            True如果吊销成功

        Raises:
            ValueError: 如果未提供token或key_id
        """
        if key_id:
            resolved_key_id = key_id
        elif token:
            try:
                payload = self._jwt.decode(token)
                resolved_key_id = payload.get("kid", "")
            except ValueError as e:
                raise ValueError(f"无法从令牌中提取密钥ID: {e}")
        else:
            raise ValueError("必须提供token或key_id")

        with self._lock:
            return self._revoke_key_internal(resolved_key_id, reason)

    def _revoke_key_internal(self, key_id: str, reason: str) -> bool:
        """
        内部方法：吊销指定密钥。

        Args:
            key_id: 密钥标识符
            reason: 吊销原因

        Returns:
            True如果吊销成功
        """
        if key_id in self._keys:
            self._keys[key_id].is_revoked = True
            self._keys[key_id].revocation_reason = reason

        self._revocation_list[key_id] = (time.time(), reason)
        self._total_revoked += 1

        logger.info("API密钥已吊销 [密钥ID=%s, 原因=%s]", key_id, reason)
        return True

    def is_revoked(self, key_id: str) -> bool:
        """
        检查密钥是否已被吊销。

        Args:
            key_id: 密钥标识符

        Returns:
            True如果已被吊销
        """
        with self._lock:
            return key_id in self._revocation_list

    def cleanup_expired(self) -> int:
        """
        清理已过期的密钥和吊销记录。

        Returns:
            被清理的记录数量
        """
        now = time.time()
        cleaned = 0

        with self._lock:
            # 清理过期密钥
            expired_keys = [
                kid for kid, info in self._keys.items()
                if info.expires_at < now
            ]
            for kid in expired_keys:
                del self._keys[kid]
                cleaned += 1

            # 清理过期吊销记录（吊销后7天）
            revoke_expiry = now - 7 * 24 * 3600
            expired_revocations = [
                kid for kid, (ts, _) in self._revocation_list.items()
                if ts < revoke_expiry
            ]
            for kid in expired_revocations:
                del self._revocation_list[kid]
                cleaned += 1

        if cleaned > 0:
            logger.info("已清理过期记录 [数量=%d]", cleaned)

        return cleaned

    def get_stats(self) -> Dict[str, Any]:
        """
        获取密钥管理器统计信息。

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            return {
                "total_issued": self._total_issued,
                "total_refreshed": self._total_refreshed,
                "total_revoked": self._total_revoked,
                "active_keys": len(self._keys),
                "revoked_keys": len(self._revocation_list),
                "refresh_mappings": len(self._refresh_mapping),
            }


# ============================================================================
# 细粒度基于角色的访问控制
# ============================================================================

class FineGrainedRBAC:
    """
    细粒度基于角色的访问控制 (Fine-Grained Role-Based Access Control)

    提供端点级别的权限定义、角色-权限映射、动态权限检查
    和权限继承/组合功能。

    核心特性：
    - 端点级权限定义（每个API端点独立权限）
    - 角色-权限映射（预定义角色 + 自定义角色）
    - 动态权限检查（运行时实时验证）
    - 权限继承和组合（角色可以继承其他角色的权限）
    - 用户-角色多对多映射

    使用示例：
        >>> rbac = FineGrainedRBAC()
        >>> rbac.assign_role("user_001", Role.ADMIN)
        >>> rbac.check_permission("user_001", "/api/v2/nodes", "GET")
        >>> rbac.define_endpoint_permission("/api/v2/admin/config", ["admin:full"])
    """

    # 默认角色-权限映射
    DEFAULT_ROLE_PERMISSIONS: Dict[str, Set[str]] = {
        Role.VIEWER.value: {
            Permission.NODE_READ.value,
            Permission.NODE_LIST.value,
            Permission.ROUTE_READ.value,
            Permission.CRYPTO_READ.value,
            Permission.DHT_READ.value,
            Permission.MIXNET_READ.value,
            Permission.SECURITY_READ.value,
            Permission.CONFIG_READ.value,
        },
        Role.OPERATOR.value: {
            Permission.NODE_READ.value,
            Permission.NODE_LIST.value,
            Permission.ROUTE_READ.value,
            Permission.ROUTE_CREATE.value,
            Permission.CRYPTO_READ.value,
            Permission.CRYPTO_MANAGE.value,
            Permission.DHT_READ.value,
            Permission.DHT_WRITE.value,
            Permission.MIXNET_READ.value,
            Permission.MIXNET_MANAGE.value,
            Permission.SECURITY_READ.value,
            Permission.CONFIG_READ.value,
        },
        Role.ADMIN.value: {
            Permission.NODE_READ.value,
            Permission.NODE_LIST.value,
            Permission.ROUTE_READ.value,
            Permission.ROUTE_CREATE.value,
            Permission.CRYPTO_READ.value,
            Permission.CRYPTO_MANAGE.value,
            Permission.DHT_READ.value,
            Permission.DHT_WRITE.value,
            Permission.MIXNET_READ.value,
            Permission.MIXNET_MANAGE.value,
            Permission.SECURITY_READ.value,
            Permission.SECURITY_MANAGE.value,
            Permission.CONFIG_READ.value,
            Permission.CONFIG_WRITE.value,
            Permission.AUDIT_READ.value,
        },
        Role.SUPER_ADMIN.value: {
            # 超级管理员拥有所有权限
            p.value for p in Permission
        },
    }

    # 默认端点-权限映射
    DEFAULT_ENDPOINT_PERMISSIONS: Dict[str, Dict[str, List[str]]] = {
        "/api/v2/nodes": {
            "GET": [Permission.NODE_LIST.value],
            "POST": [Permission.NODE_READ.value],
        },
        "/api/v2/nodes/{node_id}": {
            "GET": [Permission.NODE_READ.value],
            "DELETE": [Permission.NODE_READ.value],
        },
        "/api/v2/routes": {
            "GET": [Permission.ROUTE_READ.value],
            "POST": [Permission.ROUTE_CREATE.value],
        },
        "/api/v2/crypto/keys": {
            "GET": [Permission.CRYPTO_READ.value],
            "POST": [Permission.CRYPTO_MANAGE.value],
        },
        "/api/v2/dht": {
            "GET": [Permission.DHT_READ.value],
            "PUT": [Permission.DHT_WRITE.value],
        },
        "/api/v2/mixnet": {
            "GET": [Permission.MIXNET_READ.value],
            "POST": [Permission.MIXNET_MANAGE.value],
        },
        "/api/v2/security": {
            "GET": [Permission.SECURITY_READ.value],
            "POST": [Permission.SECURITY_MANAGE.value],
        },
        "/api/v2/config": {
            "GET": [Permission.CONFIG_READ.value],
            "PUT": [Permission.CONFIG_WRITE.value],
        },
        "/api/v2/audit": {
            "GET": [Permission.AUDIT_READ.value],
        },
        "/api/v2/admin": {
            "GET": [Permission.ADMIN_FULL.value],
            "POST": [Permission.ADMIN_FULL.value],
            "PUT": [Permission.ADMIN_FULL.value],
            "DELETE": [Permission.ADMIN_FULL.value],
        },
    }

    def __init__(self) -> None:
        """
        初始化细粒度RBAC系统。

        加载默认角色权限映射和端点权限映射。
        """
        # 角色-权限映射（角色名 -> 权限集合）
        self._role_permissions: Dict[str, Set[str]] = {
            k: set(v) for k, v in self.DEFAULT_ROLE_PERMISSIONS.items()
        }

        # 角色-角色继承映射（子角色 -> 父角色集合）
        self._role_inheritance: Dict[str, Set[str]] = {
            Role.SUPER_ADMIN.value: {Role.ADMIN.value},
            Role.ADMIN.value: {Role.OPERATOR.value},
            Role.OPERATOR.value: {Role.VIEWER.value},
        }

        # 用户-角色映射（用户ID -> 角色集合）
        self._user_roles: Dict[str, Set[str]] = defaultdict(set)

        # 端点-权限映射
        self._endpoint_permissions: Dict[str, Dict[str, List[str]]] = {
            k: {m: list(p) for m, p in v.items()}
            for k, v in self.DEFAULT_ENDPOINT_PERMISSIONS.items()
        }

        # 线程锁
        self._lock = threading.RLock()

        logger.info("细粒度RBAC系统已初始化 [角色数=%d, 端点数=%d]",
                     len(self._role_permissions), len(self._endpoint_permissions))

    def assign_role(self, user_id: str, role: str) -> None:
        """
        为用户分配角色。

        Args:
            user_id: 用户标识符
            role: 角色名称

        Raises:
            ValueError: 如果角色不存在
        """
        if role not in self._role_permissions:
            raise ValueError(f"未知角色: {role}")

        with self._lock:
            self._user_roles[user_id].add(role)

        logger.info("角色已分配 [用户=%s, 角色=%s]", user_id, role)

    def revoke_role(self, user_id: str, role: str) -> None:
        """
        撤销用户的角色。

        Args:
            user_id: 用户标识符
            role: 角色名称
        """
        with self._lock:
            if user_id in self._user_roles:
                self._user_roles[user_id].discard(role)
                if not self._user_roles[user_id]:
                    del self._user_roles[user_id]

        logger.info("角色已撤销 [用户=%s, 角色=%s]", user_id, role)

    def get_user_roles(self, user_id: str) -> Set[str]:
        """
        获取用户的所有角色（包括继承的角色）。

        Args:
            user_id: 用户标识符

        Returns:
            角色名称集合
        """
        with self._lock:
            direct_roles = set(self._user_roles.get(user_id, set()))
            # 解析继承关系，获取所有有效角色
            all_roles = set()
            for role in direct_roles:
                all_roles.add(role)
                all_roles.update(self._resolve_role_inheritance(role))
            return all_roles

    def get_user_permissions(self, user_id: str) -> Set[str]:
        """
        获取用户的所有有效权限（包括继承的权限）。

        Args:
            user_id: 用户标识符

        Returns:
            权限字符串集合
        """
        roles = self.get_user_roles(user_id)
        permissions: Set[str] = set()

        with self._lock:
            for role in roles:
                if role in self._role_permissions:
                    permissions.update(self._role_permissions[role])

        return permissions

    def check_permission(
        self,
        user_id: str,
        endpoint: str,
        method: str = "GET",
    ) -> bool:
        """
        检查用户是否有权限访问指定端点。

        根据端点和HTTP方法确定所需权限，然后检查用户是否拥有
        该权限（包括通过角色继承获得的权限）。

        Args:
            user_id: 用户标识符
            endpoint: API端点路径
            method: HTTP方法

        Returns:
            True如果用户有权限访问
        """
        # 获取端点所需的权限
        required_permissions = self._get_endpoint_permissions(endpoint, method)

        if not required_permissions:
            # 未定义权限的端点默认允许访问
            logger.debug(
                "端点未定义权限要求，默认允许 [端点=%s, 方法=%s]",
                endpoint,
                method,
            )
            return True

        # 获取用户的所有权限
        user_permissions = self.get_user_permissions(user_id)

        # 检查是否满足任一所需权限
        has_permission = bool(
            user_permissions.intersection(required_permissions)
        )

        if not has_permission:
            logger.warning(
                "权限检查失败 [用户=%s, 端点=%s, 方法=%s, 所需权限=%s, 用户权限=%s]",
                user_id,
                endpoint,
                method,
                required_permissions,
                user_permissions,
            )

        return has_permission

    def define_endpoint_permission(
        self,
        endpoint: str,
        permissions: List[str],
        methods: Optional[List[str]] = None,
    ) -> None:
        """
        定义端点的权限要求。

        Args:
            endpoint: API端点路径
            permissions: 所需权限列表
            methods: 适用的HTTP方法列表，如果为None则适用于所有方法
        """
        methods = methods or ["GET", "POST", "PUT", "DELETE", "PATCH"]

        with self._lock:
            if endpoint not in self._endpoint_permissions:
                self._endpoint_permissions[endpoint] = {}

            for method in methods:
                self._endpoint_permissions[endpoint][method] = list(permissions)

        logger.info(
            "端点权限已定义 [端点=%s, 方法=%s, 权限=%s]",
            endpoint,
            methods,
            permissions,
        )

    def create_role(
        self,
        role_name: str,
        permissions: List[str],
        inherit_from: Optional[List[str]] = None,
    ) -> None:
        """
        创建自定义角色。

        Args:
            role_name: 角色名称
            permissions: 角色权限列表
            inherit_from: 要继承的父角色列表

        Raises:
            ValueError: 如果角色已存在
        """
        with self._lock:
            if role_name in self._role_permissions:
                raise ValueError(f"角色已存在: {role_name}")

            # 创建角色权限（基础权限 + 继承权限）
            base_permissions = set(permissions)

            if inherit_from:
                self._role_inheritance[role_name] = set(inherit_from)
                for parent_role in inherit_from:
                    if parent_role in self._role_permissions:
                        base_permissions.update(
                            self._role_permissions[parent_role]
                        )

            self._role_permissions[role_name] = base_permissions

        logger.info(
            "自定义角色已创建 [角色=%s, 权限数=%d, 继承自=%s]",
            role_name,
            len(base_permissions),
            inherit_from or [],
        )

    def delete_role(self, role_name: str) -> None:
        """
        删除自定义角色。

        不能删除预定义角色。

        Args:
            role_name: 角色名称

        Raises:
            ValueError: 如果角色是预定义角色或不存在
        """
        predefined_roles = {r.value for r in Role}
        if role_name in predefined_roles:
            raise ValueError(f"不能删除预定义角色: {role_name}")

        with self._lock:
            if role_name not in self._role_permissions:
                raise ValueError(f"角色不存在: {role_name}")

            del self._role_permissions[role_name]
            self._role_inheritance.pop(role_name, None)

            # 从所有用户中移除该角色
            for user_id in list(self._user_roles.keys()):
                self._user_roles[user_id].discard(role_name)

        logger.info("自定义角色已删除 [角色=%s]", role_name)

    def _resolve_role_inheritance(self, role: str) -> Set[str]:
        """
        解析角色的继承链，返回所有父角色。

        Args:
            role: 角色名称

        Returns:
            所有父角色名称集合
        """
        inherited: Set[str] = set()
        visited: Set[str] = set()
        queue = [role]

        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)

            if current in self._role_inheritance:
                parents = self._role_inheritance[current]
                inherited.update(parents)
                queue.extend(parents)

        return inherited

    def _get_endpoint_permissions(
        self, endpoint: str, method: str
    ) -> Set[str]:
        """
        获取端点所需的权限集合。

        支持精确匹配和前缀匹配。

        Args:
            endpoint: API端点路径
            method: HTTP方法

        Returns:
            所需权限集合
        """
        permissions: Set[str] = set()

        with self._lock:
            # 精确匹配
            if endpoint in self._endpoint_permissions:
                method_perms = self._endpoint_permissions[endpoint].get(method, [])
                permissions.update(method_perms)

            # 如果精确匹配无结果，尝试前缀匹配
            if not permissions:
                for ep, methods in self._endpoint_permissions.items():
                    if endpoint.startswith(ep):
                        method_perms = methods.get(method, [])
                        permissions.update(method_perms)

        return permissions

    def get_stats(self) -> Dict[str, Any]:
        """
        获取RBAC系统统计信息。

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            return {
                "total_roles": len(self._role_permissions),
                "total_users_with_roles": len(self._user_roles),
                "total_endpoints_protected": len(self._endpoint_permissions),
                "role_inheritance_rules": len(self._role_inheritance),
            }


# ============================================================================
# API请求速率限制器
# ============================================================================

class RateLimiter:
    """
    API请求速率限制器 (API Request Rate Limiter)

    提供多种速率限制算法，支持每用户/每IP/每端点独立限制
    和自适应限制（异常行为自动收紧）。

    核心特性：
    - 令牌桶算法：平滑的速率控制，允许突发流量
    - 滑动窗口计数器：精确的时间窗口计数
    - 每用户/每IP/每端点独立限制
    - 自适应限制：检测异常行为自动收紧限制
    - 可配置的全局和个体限制

    使用示例：
        >>> limiter = RateLimiter()
        >>> limiter.set_limit("user_001", "/api/v2/nodes", RateLimitConfig(max_requests=60))
        >>> allowed = limiter.check_rate_limit(
        ...     identifier="user_001",
        ...     endpoint="/api/v2/nodes",
        ...     client_ip="192.168.1.1",
        ... )
        >>> if not allowed:
        ...     retry_after = limiter.get_retry_after("user_001", "/api/v2/nodes")
    """

    def __init__(
        self,
        default_config: Optional[RateLimitConfig] = None,
    ) -> None:
        """
        初始化速率限制器。

        Args:
            default_config: 默认速率限制配置
        """
        self._default_config = default_config or RateLimitConfig()

        # 令牌桶存储 (identifier -> {tokens, last_refill, config})
        self._token_buckets: Dict[str, Dict[str, Any]] = {}

        # 滑动窗口计数器 (identifier -> [(timestamp, count)])
        self._sliding_windows: Dict[str, List[Tuple[float, int]]] = {}

        # 自适应限制因子 (identifier -> factor)
        self._adaptive_factors: Dict[str, float] = {}

        # 违规记录 (identifier -> violation_count)
        self._violations: Dict[str, int] = defaultdict(int)

        # 线程锁
        self._lock = threading.RLock()

        # 统计信息
        self._total_requests: int = 0
        self._total_rejected: int = 0

        logger.info(
            "速率限制器已初始化 [默认限制=%d请求/%ds, 突发=%d]",
            self._default_config.max_requests,
            self._default_config.window_seconds,
            self._default_config.burst_size,
        )

    def check_rate_limit(
        self,
        identifier: str,
        endpoint: str,
        client_ip: str = "",
        method: str = "GET",
    ) -> bool:
        """
        检查请求是否在速率限制内。

        综合使用令牌桶和滑动窗口算法进行判断。
        如果启用了自适应限制，会根据历史行为调整限制。

        Args:
            identifier: 请求标识符（通常是用户ID或API密钥ID）
            endpoint: API端点路径
            client_ip: 客户端IP地址
            method: HTTP方法

        Returns:
            True如果请求被允许
        """
        with self._lock:
            self._total_requests += 1

            # 构建复合键（用户+端点）
            bucket_key = f"{identifier}:{endpoint}"

            # 获取配置（可能包含自适应调整）
            config = self._get_effective_config(bucket_key)

            # 令牌桶检查
            if not self._token_bucket_check(bucket_key, config):
                self._total_rejected += 1
                self._record_violation(identifier, endpoint, client_ip)
                logger.warning(
                    "速率限制拒绝（令牌桶） [标识符=%s, 端点=%s, IP=%s]",
                    identifier,
                    endpoint,
                    client_ip,
                )
                return False

            # 滑动窗口检查
            if not self._sliding_window_check(bucket_key, config):
                self._total_rejected += 1
                self._record_violation(identifier, endpoint, client_ip)
                logger.warning(
                    "速率限制拒绝（滑动窗口） [标识符=%s, 端点=%s, IP=%s]",
                    identifier,
                    endpoint,
                    client_ip,
                )
                return False

            # 请求通过，更新自适应因子
            if config.adaptive_enabled:
                self._update_adaptive_factor(bucket_key, violated=False)

            return True

    def set_limit(
        self,
        identifier: str,
        endpoint: str,
        config: RateLimitConfig,
    ) -> None:
        """
        为特定用户和端点设置自定义速率限制。

        Args:
            identifier: 用户标识符
            endpoint: API端点路径
            config: 速率限制配置
        """
        bucket_key = f"{identifier}:{endpoint}"

        with self._lock:
            self._token_buckets[bucket_key] = {
                "tokens": float(config.burst_size),
                "last_refill": time.time(),
                "config": config,
            }

        logger.info(
            "自定义速率限制已设置 [标识符=%s, 端点=%s, 限制=%d/%ds]",
            identifier,
            endpoint,
            config.max_requests,
            config.window_seconds,
        )

    def get_retry_after(
        self,
        identifier: str,
        endpoint: str,
    ) -> float:
        """
        获取距离下次允许请求的等待时间。

        Args:
            identifier: 用户标识符
            endpoint: API端点路径

        Returns:
            等待时间（秒），如果当前允许请求则返回0
        """
        bucket_key = f"{identifier}:{endpoint}"

        with self._lock:
            if bucket_key not in self._token_buckets:
                return 0.0

            bucket = self._token_buckets[bucket_key]
            config = bucket.get("config", self._default_config)

            if bucket["tokens"] >= 1.0:
                return 0.0

            # 计算令牌恢复时间
            tokens_needed = 1.0 - bucket["tokens"]
            refill_rate = config.max_requests / config.window_seconds
            retry_after = tokens_needed / refill_rate if refill_rate > 0 else 0.0

            return max(0.0, retry_after)

    def reset_limits(self, identifier: Optional[str] = None) -> None:
        """
        重置速率限制计数器。

        Args:
            identifier: 用户标识符。如果为None，重置所有限制。
        """
        with self._lock:
            if identifier:
                keys_to_remove = [
                    k for k in self._token_buckets if k.startswith(identifier + ":")
                ]
                for key in keys_to_remove:
                    del self._token_buckets[key]
                    self._sliding_windows.pop(key, None)
                    self._adaptive_factors.pop(key, None)
            else:
                self._token_buckets.clear()
                self._sliding_windows.clear()
                self._adaptive_factors.clear()

        logger.info("速率限制已重置 [标识符=%s]", identifier or "全部")

    def get_stats(self) -> Dict[str, Any]:
        """
        获取速率限制器统计信息。

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            return {
                "total_requests": self._total_requests,
                "total_rejected": self._total_rejected,
                "rejection_rate": (
                    self._total_rejected / self._total_requests
                    if self._total_requests > 0
                    else 0.0
                ),
                "active_buckets": len(self._token_buckets),
                "adaptive_entries": len(self._adaptive_factors),
                "total_violations": sum(self._violations.values()),
            }

    def _token_bucket_check(
        self, bucket_key: str, config: RateLimitConfig
    ) -> bool:
        """
        令牌桶算法检查。

        Args:
            bucket_key: 令牌桶标识键
            config: 速率限制配置

        Returns:
            True如果令牌可用
        """
        now = time.time()

        if bucket_key not in self._token_buckets:
            # 初始化新桶
            self._token_buckets[bucket_key] = {
                "tokens": float(config.burst_size),
                "last_refill": now,
                "config": config,
            }

        bucket = self._token_buckets[bucket_key]

        # 计算应补充的令牌数
        elapsed = now - bucket["last_refill"]
        refill_rate = config.max_requests / config.window_seconds
        tokens_to_add = elapsed * refill_rate

        # 补充令牌（不超过桶容量）
        bucket["tokens"] = min(
            config.burst_size,
            bucket["tokens"] + tokens_to_add,
        )
        bucket["last_refill"] = now

        # 尝试消费一个令牌
        if bucket["tokens"] >= 1.0:
            bucket["tokens"] -= 1.0
            return True

        return False

    def _sliding_window_check(
        self, bucket_key: str, config: RateLimitConfig
    ) -> bool:
        """
        滑动窗口计数器检查。

        Args:
            bucket_key: 窗口标识键
            config: 速率限制配置

        Returns:
            True如果未超过窗口限制
        """
        now = time.time()
        window_start = now - config.window_seconds

        if bucket_key not in self._sliding_windows:
            self._sliding_windows[bucket_key] = []

        window = self._sliding_windows[bucket_key]

        # 移除窗口外的旧记录
        self._sliding_windows[bucket_key] = [
            (ts, count) for ts, count in window if ts > window_start
        ]
        window = self._sliding_windows[bucket_key]

        # 计算窗口内的总请求数
        total_requests = sum(count for _, count in window)

        if total_requests >= config.max_requests:
            return False

        # 记录当前请求
        window.append((now, 1))
        return True

    def _get_effective_config(self, bucket_key: str) -> RateLimitConfig:
        """
        获取有效的速率限制配置（考虑自适应调整）。

        Args:
            bucket_key: 令牌桶标识键

        Returns:
            调整后的速率限制配置
        """
        config = self._default_config

        if bucket_key in self._token_buckets:
            stored_config = self._token_buckets[bucket_key].get("config")
            if stored_config:
                config = stored_config

        # 应用自适应因子
        if config.adaptive_enabled and bucket_key in self._adaptive_factors:
            factor = self._adaptive_factors[bucket_key]
            adjusted_max = max(
                int(config.max_requests * factor),
                int(config.max_requests * ADAPTIVE_MIN_FACTOR),
            )
            adjusted_burst = max(
                int(config.burst_size * factor),
                1,
            )
            return RateLimitConfig(
                max_requests=adjusted_max,
                burst_size=adjusted_burst,
                window_seconds=config.window_seconds,
                adaptive_enabled=config.adaptive_enabled,
                adaptive_threshold=config.adaptive_threshold,
            )

        return config

    def _record_violation(
        self, identifier: str, endpoint: str, client_ip: str
    ) -> None:
        """
        记录速率限制违规。

        Args:
            identifier: 用户标识符
            endpoint: API端点路径
            client_ip: 客户端IP地址
        """
        violation_key = f"{identifier}:{endpoint}"
        self._violations[violation_key] += 1

        # 更新自适应因子
        bucket_key = f"{identifier}:{endpoint}"
        if self._default_config.adaptive_enabled:
            self._update_adaptive_factor(bucket_key, violated=True)

    def _update_adaptive_factor(
        self, bucket_key: str, violated: bool
    ) -> None:
        """
        更新自适应限制因子。

        当检测到违规时降低因子（收紧限制），
        当请求正常时缓慢恢复因子。

        Args:
            bucket_key: 令牌桶标识键
            violated: 是否发生了违规
        """
        current_factor = self._adaptive_factors.get(bucket_key, 1.0)

        if violated:
            # 违规时快速收紧
            new_factor = max(current_factor * 0.7, ADAPTIVE_MIN_FACTOR)
        else:
            # 正常时缓慢恢复
            new_factor = min(current_factor * 1.05, 1.0)

        self._adaptive_factors[bucket_key] = new_factor


# ============================================================================
# API请求审计日志
# ============================================================================

class APIAuditLogger:
    """
    API请求审计日志 (API Request Audit Logger)

    提供不可篡改的API请求审计日志记录功能，使用HMAC链确保
    日志完整性。支持异常行为检测、日志导出和分析。

    核心特性：
    - 记录所有API请求的详细信息
    - 请求/响应详情记录（大小、状态码、延迟）
    - 异常行为自动检测
    - 审计日志不可篡改（HMAC链式哈希）
    - 日志导出（JSON格式）和基本分析

    使用示例：
        >>> audit_logger = APIAuditLogger(secret="audit-secret")
        >>> audit_logger.log_request(
        ...     client_ip="192.168.1.1",
        ...     user_id="user_001",
        ...     method="GET",
        ...     endpoint="/api/v2/nodes",
        ...     status_code=200,
        ...     latency_ms=45.2,
        ... )
        >>> entries = audit_logger.get_entries(limit=10)
        >>> is_valid = audit_logger.verify_chain_integrity()
    """

    def __init__(
        self,
        secret: Optional[str] = None,
        max_entries: int = AUDIT_LOG_MAX_ENTRIES,
        auto_rotate: bool = True,
    ) -> None:
        """
        初始化审计日志记录器。

        Args:
            secret: HMAC签名密钥。如果未提供，将自动生成。
            max_entries: 最大日志条目数
            auto_rotate: 是否自动轮转日志
        """
        self._hmac_key = (secret or secrets.token_hex(32)).encode("utf-8")
        self._max_entries = max_entries
        self._auto_rotate = auto_rotate

        # 日志条目存储（按序列号索引）
        self._entries: List[AuditLogEntry] = []

        # 序列号计数器
        self._sequence: int = 0

        # 前一条日志的HMAC哈希（链式完整性）
        self._previous_hash: str = ""

        # 异常行为检测器
        self._anomaly_detector = _AnomalyDetector()

        # 线程锁
        self._lock = threading.RLock()

        # 统计信息
        self._total_logged: int = 0
        self._total_anomalies: int = 0

        logger.info(
            "API审计日志已初始化 [最大条目=%d, 自动轮转=%s]",
            max_entries,
            auto_rotate,
        )

    def log_request(
        self,
        client_ip: str,
        method: str,
        endpoint: str,
        status_code: int,
        latency_ms: float = 0.0,
        user_id: str = "",
        api_key_id: str = "",
        request_size: int = 0,
        response_size: int = 0,
    ) -> AuditLogEntry:
        """
        记录API请求到审计日志。

        创建审计日志条目，计算HMAC链哈希，并检测异常行为。

        Args:
            client_ip: 客户端IP地址
            method: HTTP方法
            endpoint: API端点路径
            status_code: HTTP响应状态码
            latency_ms: 请求延迟（毫秒）
            user_id: 用户标识符
            api_key_id: API密钥标识符
            request_size: 请求体大小（字节）
            response_size: 响应体大小（字节）

        Returns:
            创建的审计日志条目
        """
        with self._lock:
            self._sequence += 1
            entry_id = secrets.token_hex(16)
            timestamp = time.time()

            # 检测异常行为
            is_anomalous, anomaly_reason = self._anomaly_detector.check(
                client_ip=client_ip,
                endpoint=endpoint,
                method=method,
                status_code=status_code,
                latency_ms=latency_ms,
                user_id=user_id,
            )

            if is_anomalous:
                self._total_anomalies += 1
                logger.warning(
                    "检测到异常API行为 [IP=%s, 端点=%s, 原因=%s]",
                    client_ip,
                    endpoint,
                    anomaly_reason,
                )

            # 创建日志条目
            entry = AuditLogEntry(
                entry_id=entry_id,
                timestamp=timestamp,
                sequence=self._sequence,
                client_ip=client_ip,
                user_id=user_id,
                api_key_id=api_key_id,
                method=method,
                endpoint=endpoint,
                status_code=status_code,
                request_size=request_size,
                response_size=response_size,
                latency_ms=latency_ms,
                is_anomalous=is_anomalous,
                anomaly_reason=anomaly_reason,
                previous_hash=self._previous_hash,
            )

            # 计算HMAC链哈希
            entry.entry_hash = self._compute_entry_hash(entry)
            self._previous_hash = entry.entry_hash

            # 存储条目
            self._entries.append(entry)
            self._total_logged += 1

            # 自动轮转
            if self._auto_rotate and len(self._entries) > self._max_entries:
                self._rotate_log()

        return entry

    def get_entries(
        self,
        limit: int = 100,
        offset: int = 0,
        user_id: Optional[str] = None,
        endpoint: Optional[str] = None,
        anomalous_only: bool = False,
    ) -> List[AuditLogEntry]:
        """
        查询审计日志条目。

        支持按用户、端点过滤和仅查看异常记录。

        Args:
            limit: 返回条目数量限制
            offset: 跳过的条目数量
            user_id: 按用户ID过滤
            endpoint: 按端点过滤
            anomalous_only: 是否仅返回异常记录

        Returns:
            审计日志条目列表
        """
        with self._lock:
            entries = list(self._entries)

        # 应用过滤条件
        if user_id:
            entries = [e for e in entries if e.user_id == user_id]
        if endpoint:
            entries = [e for e in entries if e.endpoint == endpoint]
        if anomalous_only:
            entries = [e for e in entries if e.is_anomalous]

        # 应用分页
        return entries[offset:offset + limit]

    def verify_chain_integrity(self) -> Tuple[bool, Optional[int]]:
        """
        验证审计日志链的完整性。

        逐条验证HMAC链哈希，确保日志未被篡改。

        Returns:
            (是否完整, 被篡改的条目序列号) 元组。
            如果完整，第二个元素为None。
        """
        with self._lock:
            if not self._entries:
                return True, None

            previous_hash = ""
            for entry in self._entries:
                # 验证前一条哈希链接
                if entry.previous_hash != previous_hash:
                    logger.critical(
                        "审计日志链断裂 [序列号=%d, 预期前哈希=%s, 实际前哈希=%s]",
                        entry.sequence,
                        previous_hash[:16] + "...",
                        entry.previous_hash[:16] + "...",
                    )
                    return False, entry.sequence

                # 验证条目哈希
                expected_hash = self._compute_entry_hash_with_previous(
                    entry, previous_hash
                )
                if entry.entry_hash != expected_hash:
                    logger.critical(
                        "审计日志条目被篡改 [序列号=%d]",
                        entry.sequence,
                    )
                    return False, entry.sequence

                previous_hash = entry.entry_hash

            return True, None

    def export_logs(self, format: str = "json") -> str:
        """
        导出审计日志。

        Args:
            format: 导出格式，目前仅支持"json"

        Returns:
            格式化的日志字符串

        Raises:
            ValueError: 如果格式不支持
        """
        if format != "json":
            raise ValueError(f"不支持的导出格式: {format}")

        with self._lock:
            entries_data = []
            for entry in self._entries:
                entries_data.append({
                    "entry_id": entry.entry_id,
                    "timestamp": entry.timestamp,
                    "sequence": entry.sequence,
                    "client_ip": entry.client_ip,
                    "user_id": entry.user_id,
                    "api_key_id": entry.api_key_id,
                    "method": entry.method,
                    "endpoint": entry.endpoint,
                    "status_code": entry.status_code,
                    "request_size": entry.request_size,
                    "response_size": entry.response_size,
                    "latency_ms": entry.latency_ms,
                    "is_anomalous": entry.is_anomalous,
                    "anomaly_reason": entry.anomaly_reason,
                    "previous_hash": entry.previous_hash,
                    "entry_hash": entry.entry_hash,
                })

        return json.dumps(entries_data, indent=2, ensure_ascii=False)

    def get_anomaly_summary(self) -> Dict[str, Any]:
        """
        获取异常行为摘要。

        Returns:
            包含异常统计信息的字典
        """
        with self._lock:
            anomalous_entries = [e for e in self._entries if e.is_anomalous]

            # 按类型统计异常
            anomaly_by_reason: Dict[str, int] = defaultdict(int)
            for entry in anomalous_entries:
                if entry.anomaly_reason:
                    anomaly_by_reason[entry.anomaly_reason] += 1

            # 按IP统计异常
            anomaly_by_ip: Dict[str, int] = defaultdict(int)
            for entry in anomalous_entries:
                if entry.client_ip:
                    anomaly_by_ip[entry.client_ip] += 1

            return {
                "total_anomalies": len(anomalous_entries),
                "anomaly_rate": (
                    len(anomalous_entries) / len(self._entries)
                    if self._entries
                    else 0.0
                ),
                "anomalies_by_reason": dict(anomaly_by_reason),
                "top_anomalous_ips": dict(
                    sorted(anomaly_by_ip.items(), key=lambda x: -x[1])[:10]
                ),
            }

    def get_stats(self) -> Dict[str, Any]:
        """
        获取审计日志统计信息。

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            # 计算平均延迟
            latencies = [e.latency_ms for e in self._entries if e.latency_ms > 0]
            avg_latency = sum(latencies) / len(latencies) if latencies else 0.0

            # 状态码分布
            status_distribution: Dict[int, int] = defaultdict(int)
            for entry in self._entries:
                status_distribution[entry.status_code] += 1

            return {
                "total_entries": len(self._entries),
                "total_logged": self._total_logged,
                "total_anomalies": self._total_anomalies,
                "average_latency_ms": round(avg_latency, 2),
                "status_distribution": dict(status_distribution),
                "chain_integrity": self.verify_chain_integrity()[0],
                "max_entries": self._max_entries,
            }

    def _compute_entry_hash(self, entry: AuditLogEntry) -> str:
        """
        计算审计日志条目的HMAC哈希。

        Args:
            entry: 审计日志条目

        Returns:
            十六进制HMAC哈希字符串
        """
        hash_input = (
            f"{entry.entry_id}|{entry.timestamp}|{entry.sequence}|"
            f"{entry.client_ip}|{entry.user_id}|{entry.api_key_id}|"
            f"{entry.method}|{entry.endpoint}|{entry.status_code}|"
            f"{entry.request_size}|{entry.response_size}|{entry.latency_ms}|"
            f"{entry.previous_hash}"
        ).encode("utf-8")

        return hmac.new(
            self._hmac_key, hash_input, hashlib.sha256
        ).hexdigest()

    def _compute_entry_hash_with_previous(
        self, entry: AuditLogEntry, previous_hash: str
    ) -> str:
        """
        使用指定的前一条哈希计算条目哈希（用于验证）。

        Args:
            entry: 审计日志条目
            previous_hash: 前一条日志的哈希

        Returns:
            十六进制HMAC哈希字符串
        """
        hash_input = (
            f"{entry.entry_id}|{entry.timestamp}|{entry.sequence}|"
            f"{entry.client_ip}|{entry.user_id}|{entry.api_key_id}|"
            f"{entry.method}|{entry.endpoint}|{entry.status_code}|"
            f"{entry.request_size}|{entry.response_size}|{entry.latency_ms}|"
            f"{previous_hash}"
        ).encode("utf-8")

        return hmac.new(
            self._hmac_key, hash_input, hashlib.sha256
        ).hexdigest()

    def _rotate_log(self) -> None:
        """
        执行日志轮转。

        保留最近的条目，删除旧条目。
        """
        if len(self._entries) > self._max_entries:
            # 保留最新的条目
            keep_count = self._max_entries // 2
            removed = self._entries[:-keep_count]
            self._entries = self._entries[-keep_count:]

            logger.info(
                "审计日志已轮转 [删除=%d条, 保留=%d条]",
                len(removed),
                keep_count,
            )


# ============================================================================
# 异常行为检测器（内部类）
# ============================================================================

class _AnomalyDetector:
    """
    异常行为检测器 (Anomaly Behavior Detector)

    内部使用的异常行为检测组件，基于简单规则检测可疑的API请求模式。

    检测规则：
    - 高错误率：同一IP短时间内大量4xx/5xx响应
    - 请求频率异常：同一IP请求频率远高于正常值
    - 端点扫描：同一IP访问大量不同端点
    - 可疑端点访问：访问敏感管理端点
    - 高延迟异常：响应延迟异常高
    """

    def __init__(
        self,
        high_error_threshold: int = 20,
        scan_threshold: int = 50,
        frequency_threshold: int = 100,
        frequency_window: float = 60.0,
    ) -> None:
        """
        初始化异常检测器。

        Args:
            high_error_threshold: 高错误率阈值（窗口内错误数）
            scan_threshold: 端点扫描阈值（窗口内不同端点数）
            frequency_threshold: 请求频率阈值（窗口内请求数）
            frequency_window: 频率检测窗口（秒）
        """
        self._high_error_threshold = high_error_threshold
        self._scan_threshold = scan_threshold
        self._frequency_threshold = frequency_threshold
        self._frequency_window = frequency_window

        # IP请求历史 (ip -> [(timestamp, endpoint, status_code)])
        self._ip_history: Dict[str, List[Tuple[float, str, int]]] = defaultdict(list)

    def check(
        self,
        client_ip: str,
        endpoint: str,
        method: str,
        status_code: int,
        latency_ms: float,
        user_id: str = "",
    ) -> Tuple[bool, str]:
        """
        检查请求是否为异常行为。

        Args:
            client_ip: 客户端IP
            endpoint: API端点
            method: HTTP方法
            status_code: 响应状态码
            latency_ms: 请求延迟
            user_id: 用户ID

        Returns:
            (是否异常, 异常原因) 元组
        """
        now = time.time()
        window_start = now - self._frequency_window

        # 记录请求
        self._ip_history[client_ip].append((now, endpoint, status_code))

        # 清理过期记录
        self._ip_history[client_ip] = [
            (ts, ep, sc) for ts, ep, sc in self._ip_history[client_ip]
            if ts > window_start
        ]

        history = self._ip_history[client_ip]

        # 检测1: 高错误率
        error_count = sum(1 for _, _, sc in history if sc >= 400)
        if error_count > self._high_error_threshold:
            return True, f"高错误率: {error_count}个错误请求"

        # 检测2: 请求频率异常
        if len(history) > self._frequency_threshold:
            return True, f"请求频率异常: {len(history)}请求/{self._frequency_window}秒"

        # 检测3: 端点扫描
        unique_endpoints = set(ep for _, ep, _ in history)
        if len(unique_endpoints) > self._scan_threshold:
            return True, f"端点扫描: {len(unique_endpoints)}个不同端点"

        # 检测4: 可疑端点访问
        sensitive_endpoints = ["/admin", "/config", "/security", "/audit"]
        for sensitive in sensitive_endpoints:
            if sensitive in endpoint.lower():
                # 管理端点访问本身不一定异常，但需要记录
                pass

        # 检测5: 高延迟异常（超过10秒）
        if latency_ms > 10000:
            return True, f"高延迟异常: {latency_ms:.0f}ms"

        return False, ""
