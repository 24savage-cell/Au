"""
API安全增强模块 V2 (Enhanced API Security Module V2)

本模块提供了API层面的安全增强功能，包括：
- 短期API密钥管理：基于JWT的24小时有效期密钥，支持刷新和吊销
- 细粒度基于角色的访问控制：端点级权限定义和动态权限检查
- API请求速率限制：令牌桶和滑动窗口算法，支持自适应限制
- API请求审计日志：不可篡改的HMAC链式审计日志

This module provides API-level security enhancement features, including
short-lived API key management, fine-grained RBAC, rate limiting, and
tamper-proof audit logging.
"""

from src.api_v2.enhanced_api_security import (
    ShortLivedAPIKey,
    FineGrainedRBAC,
    RateLimiter,
    APIAuditLogger,
)

__all__ = [
    "ShortLivedAPIKey",
    "FineGrainedRBAC",
    "RateLimiter",
    "APIAuditLogger",
]

__version__ = "1.0.0"
__author__ = "IP4Move-Aegis Security Team"
