"""
节点监控模块

监控节点运行状态和性能指标。
"""

import time
import asyncio
import logging
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class Metric:
    """性能指标"""
    name: str
    value: float
    timestamp: float = field(default_factory=time.time)
    tags: Dict[str, str] = field(default_factory=dict)


@dataclass
class EventLog:
    """事件日志"""
    event_type: str
    data: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    level: str = "info"


class NodeMonitor:
    """
    节点监控器

    监控节点状态:
    - 性能指标收集
    - 事件日志
    - 资源使用监控
    - 健康检查
    """

    def __init__(self, node_id: str):
        self._node_id = node_id
        self._start_time = time.time()
        self._metrics: Dict[str, List[Metric]] = {}
        self._events: List[EventLog] = []
        self._max_events = 10000
        self._max_metrics = 1000
        self._is_running = False
        self._collect_task: Optional[asyncio.Task] = None

    @property
    def uptime(self) -> float:
        return time.time() - self._start_time

    def record_metric(self, name: str, value: float, tags: Optional[Dict] = None) -> None:
        """记录指标"""
        metric = Metric(name=name, value=value, tags=tags or {})
        if name not in self._metrics:
            self._metrics[name] = []
        self._metrics[name].append(metric)
        # 限制存储
        if len(self._metrics[name]) > self._max_metrics:
            self._metrics[name] = self._metrics[name][-self._max_metrics:]

    def record_event(self, event_type: str, data: Dict[str, Any], level: str = "info") -> None:
        """记录事件"""
        event = EventLog(event_type=event_type, data=data, level=level)
        self._events.append(event)
        if len(self._events) > self._max_events:
            self._events = self._events[-self._max_events:]

        log_fn = {
            "info": logger.info,
            "warning": logger.warning,
            "error": logger.error,
            "debug": logger.debug,
        }.get(level, logger.info)
        log_fn(f"[{self._node_id}] {event_type}: {data}")

    def get_metric(self, name: str, limit: int = 100) -> List[Metric]:
        """获取指标"""
        metrics = self._metrics.get(name, [])
        return metrics[-limit:]

    def get_latest_metric(self, name: str) -> Optional[float]:
        """获取最新指标值"""
        metrics = self._metrics.get(name, [])
        return metrics[-1].value if metrics else None

    def get_events(self, event_type: Optional[str] = None, limit: int = 100) -> List[EventLog]:
        """获取事件日志"""
        events = self._events
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        return events[-limit:]

    def get_system_metrics(self) -> Dict[str, float]:
        """获取系统指标"""
        metrics = {}
        try:
            import psutil
            process = psutil.Process()
            metrics["cpu_percent"] = process.cpu_percent()
            metrics["memory_mb"] = process.memory_info().rss / 1024 / 1024
            metrics["num_threads"] = process.num_threads()
            metrics["num_fds"] = process.num_fds() if hasattr(process, 'num_fds') else 0
        except ImportError:
            pass
        metrics["uptime"] = self.uptime
        return metrics

    async def _collect_loop(self) -> None:
        """定期收集指标"""
        while self._is_running:
            try:
                sys_metrics = self.get_system_metrics()
                for key, value in sys_metrics.items():
                    self.record_metric(f"system.{key}", value)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"指标收集错误: {e}")
            await asyncio.sleep(10)

    async def start(self) -> None:
        """启动监控"""
        self._is_running = True
        self._collect_task = asyncio.create_task(self._collect_loop())
        self.record_event("monitor_start", {})

    async def stop(self) -> None:
        """停止监控"""
        self._is_running = False
        if self._collect_task:
            self._collect_task.cancel()
            try:
                await self._collect_task
            except asyncio.CancelledError:
                pass
        self.record_event("monitor_stop", {"uptime": self.uptime})

    def get_stats(self) -> Dict:
        """获取监控统计"""
        return {
            "node_id": self._node_id,
            "uptime": self.uptime,
            "metrics_count": sum(len(m) for m in self._metrics.values()),
            "events_count": len(self._events),
            "system": self.get_system_metrics(),
        }
