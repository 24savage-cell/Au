"""
节点核心模块

IP.4/Move 节点的核心实现。
"""

import os
import asyncio
import logging
from typing import Optional, Dict, List, Callable

from src.node.role_manager import RoleManager, NodeRole
from src.node.node_monitor import NodeMonitor

logger = logging.getLogger(__name__)


class NodeCore:
    """
    IP.4/Move 节点核心

    整合所有模块，提供统一的节点管理接口:
    - 角色管理 (Mix/Relay/Exit)
    - 节点监控
    - 生命周期管理
    """

    def __init__(
        self,
        node_id: Optional[str] = None,
        address: str = "0.0.0.0",
        port: int = 9050,
        roles: Optional[List[NodeRole]] = None,
    ):
        self._node_id = node_id or os.urandom(16).hex()
        self._address = address
        self._port = port
        self._role_manager = RoleManager(roles)
        self._monitor = NodeMonitor(self._node_id)
        self._is_running = False
        self._components: Dict[str, object] = {}
        self._startup_hooks: List[Callable] = []
        self._shutdown_hooks: List[Callable] = []

    @property
    def node_id(self) -> str:
        return self._node_id

    @property
    def address(self) -> str:
        return self._address

    @property
    def port(self) -> int:
        return self._port

    @property
    def is_running(self) -> bool:
        return self._is_running

    @property
    def role_manager(self) -> RoleManager:
        return self._role_manager

    @property
    def monitor(self) -> NodeMonitor:
        return self._monitor

    def register_component(self, name: str, component: object) -> None:
        """注册组件"""
        self._components[name] = component

    def get_component(self, name: str) -> Optional[object]:
        """获取组件"""
        return self._components.get(name)

    def on_startup(self, hook: Callable) -> None:
        """注册启动钩子"""
        self._startup_hooks.append(hook)

    def on_shutdown(self, hook: Callable) -> None:
        """注册关闭钩子"""
        self._shutdown_hooks.append(hook)

    async def start(self) -> None:
        """启动节点"""
        if self._is_running:
            logger.warning("节点已在运行")
            return

        logger.info(f"正在启动节点 {self._node_id} ({self._address}:{self._port})")
        self._monitor.record_event("node_start", {"roles": [r.value for r in self._role_manager.active_roles]})

        # 执行启动钩子
        for hook in self._startup_hooks:
            try:
                result = hook()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.error(f"启动钩子执行失败: {e}")

        # 启动监控
        await self._monitor.start()

        self._is_running = True
        logger.info(f"节点 {self._node_id} 已启动, 角色: {[r.value for r in self._role_manager.active_roles]}")

    async def stop(self) -> None:
        """停止节点"""
        if not self._is_running:
            return

        logger.info(f"正在停止节点 {self._node_id}")
        self._monitor.record_event("node_stop", {})

        # 执行关闭钩子
        for hook in self._shutdown_hooks:
            try:
                result = hook()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.error(f"关闭钩子执行失败: {e}")

        # 停止监控
        await self._monitor.stop()

        self._is_running = False
        logger.info(f"节点 {self._node_id} 已停止")

    def get_info(self) -> Dict:
        """获取节点信息"""
        return {
            "node_id": self._node_id,
            "address": self._address,
            "port": self._port,
            "is_running": self._is_running,
            "roles": [r.value for r in self._role_manager.active_roles],
            "components": list(self._components.keys()),
            "uptime": self._monitor.uptime,
        }
