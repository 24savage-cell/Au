"""
角色管理模块

管理节点的多种角色 (Mix/Relay/Exit)。
"""

import logging
from typing import Optional, List, Set, Dict
from enum import Enum
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class NodeRole(Enum):
    """节点角色"""
    MIX = "mix"          # Mix 节点
    RELAY = "relay"      # 中继节点
    EXIT = "exit"        # 出口节点
    SEED = "seed"        # 种子节点
    DHT = "dht"          # DHT 节点
    MONITOR = "monitor"  # 监控节点


@dataclass
class RoleConfig:
    """角色配置"""
    role: NodeRole
    enabled: bool = True
    priority: int = 0
    max_connections: int = 100
    bandwidth_limit: int = 0  # 0 = 无限制 (bytes/s)
    metadata: dict = field(default_factory=dict)


class RoleManager:
    """
    角色管理器

    管理节点的多种角色:
    - 动态启用/禁用角色
    - 角色优先级
    - 资源限制
    """

    def __init__(self, initial_roles: Optional[List[NodeRole]] = None):
        self._roles: Dict[NodeRole, RoleConfig] = {}
        if initial_roles:
            for role in initial_roles:
                self._roles[role] = RoleConfig(role=role)

    @property
    def active_roles(self) -> List[NodeRole]:
        return [r for r, c in self._roles.items() if c.enabled]

    @property
    def all_roles(self) -> List[NodeRole]:
        return list(self._roles.keys())

    def enable_role(self, role: NodeRole, **kwargs) -> None:
        """启用角色"""
        if role in self._roles:
            self._roles[role].enabled = True
            self._roles[role].metadata.update(kwargs)
        else:
            self._roles[role] = RoleConfig(role=role, **kwargs)
        logger.info(f"角色已启用: {role.value}")

    def disable_role(self, role: NodeRole) -> None:
        """禁用角色"""
        if role in self._roles:
            self._roles[role].enabled = False
            logger.info(f"角色已禁用: {role.value}")

    def has_role(self, role: NodeRole) -> bool:
        """检查是否拥有角色"""
        config = self._roles.get(role)
        return config is not None and config.enabled

    def get_config(self, role: NodeRole) -> Optional[RoleConfig]:
        """获取角色配置"""
        return self._roles.get(role)

    def set_priority(self, role: NodeRole, priority: int) -> None:
        """设置角色优先级"""
        if role in self._roles:
            self._roles[role].priority = priority

    def get_sorted_roles(self) -> List[NodeRole]:
        """按优先级排序获取角色"""
        active = self.active_roles
        return sorted(active, key=lambda r: self._roles[r].priority, reverse=True)

    def get_role_summary(self) -> Dict[str, dict]:
        """获取角色摘要"""
        return {
            role.value: {
                "enabled": config.enabled,
                "priority": config.priority,
                "max_connections": config.max_connections,
            }
            for role, config in self._roles.items()
        }
