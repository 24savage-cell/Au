"""
流量劫持模块

透明拦截和重定向网络流量。
"""

import os
import random
import logging
from typing import Optional, List, Dict, Callable, Tuple
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class HijackRule:
    """劫持规则"""
    def __init__(
        self,
        target_host: str,
        target_port: int,
        action: str = "redirect",  # redirect | block | allow
        redirect_host: Optional[str] = None,
        redirect_port: Optional[int] = None,
        protocol: str = "tcp",
        enabled: bool = True,
        priority: int = 0,
    ):
        self.target_host = target_host
        self.target_port = target_port
        self.action = action
        self.redirect_host = redirect_host
        self.redirect_port = redirect_port
        self.protocol = protocol
        self.enabled = enabled
        self.priority = priority

    def matches(self, host: str, port: int, protocol: str = "tcp") -> bool:
        """检查是否匹配规则"""
        if not self.enabled:
            return False
        if self.protocol != protocol:
            return False
        if self.target_host != "*" and self.target_host != host:
            return False
        if self.target_port != 0 and self.target_port != port:
            return False
        return True


class TrafficHijacker:
    """
    流量劫持器

    功能:
    - 基于规则的流量拦截
    - 透明重定向到匿名网络
    - 白名单/黑名单管理
    - 流量统计
    """

    def __init__(self, listen_port: int = 9080):
        self._listen_port = listen_port
        self._rules: List[HijackRule] = []
        self._stats = {
            "total_intercepted": 0,
            "total_redirected": 0,
            "total_blocked": 0,
            "total_allowed": 0,
        }
        self._intercept_callback: Optional[Callable] = None
        self._is_running = False

    def add_rule(self, rule: HijackRule) -> None:
        """添加劫持规则"""
        self._rules.append(rule)
        self._rules.sort(key=lambda r: r.priority, reverse=True)

    def remove_rule(self, index: int) -> bool:
        """移除规则"""
        if 0 <= index < len(self._rules):
            self._rules.pop(index)
            return True
        return False

    def set_intercept_callback(self, callback: Callable) -> None:
        """设置拦截回调"""
        self._intercept_callback = callback

    def evaluate(self, host: str, port: int, protocol: str = "tcp") -> Optional[HijackRule]:
        """
        评估流量匹配规则

        Returns:
            匹配的规则，无匹配时返回 None
        """
        for rule in self._rules:
            if rule.matches(host, port, protocol):
                return rule
        return None

    async def intercept(
        self,
        host: str,
        port: int,
        data: bytes,
        protocol: str = "tcp",
    ) -> Tuple[str, int, bytes]:
        """
        拦截并处理流量

        Returns:
            (target_host, target_port, data)
        """
        self._stats["total_intercepted"] += 1
        rule = self.evaluate(host, port, protocol)

        if rule is None:
            self._stats["total_allowed"] += 1
            return host, port, data

        if rule.action == "redirect":
            self._stats["total_redirected"] += 1
            target_host = rule.redirect_host or "127.0.0.1"
            target_port = rule.redirect_port or self._listen_port
            logger.debug(f"流量重定向: {host}:{port} -> {target_host}:{target_port}")
            if self._intercept_callback:
                await self._intercept_callback(host, port, data, target_host, target_port)
            return target_host, target_port, data

        elif rule.action == "block":
            self._stats["total_blocked"] += 1
            logger.debug(f"流量阻止: {host}:{port}")
            return "", 0, b""

        else:  # allow
            self._stats["total_allowed"] += 1
            return host, port, data

    def add_default_rules(self) -> None:
        """添加默认劫持规则"""
        # 重定向所有 HTTP/HTTPS 流量
        self._rules.extend([
            HijackRule("*", 80, "redirect", redirect_port=self._listen_port, priority=10),
            HijackRule("*", 443, "redirect", redirect_port=self._listen_port, priority=10),
            HijackRule("localhost", 0, "allow", priority=100),
            HijackRule("127.0.0.1", 0, "allow", priority=100),
        ])
        self._rules.sort(key=lambda r: r.priority, reverse=True)

    def get_stats(self) -> dict:
        return dict(self._stats)

    def perturb_traffic_features(self, data: bytes) -> bytes:
        """
        流量特征随机化扰动

        对拦截的流量进行微小的随机修改，
        使AI分类器无法通过精确匹配识别流量来源。

        修改策略:
        1. 随机修改 TTL (±1-3)
        2. 随机修改窗口大小 (±1000)
        3. 随机添加/移除 TCP 选项
        4. 随机修改 IP ID 字段
        """
        if len(data) < 20:
            return data

        data = bytearray(data)
        # 随机修改 IP TTL (offset 8)
        if len(data) > 8:
            ttl = data[8]
            perturbation = random.choice([-1, -2, -3, 1, 2, 3])
            data[8] = max(1, min(255, ttl + perturbation))
        # 随机修改 IP ID (offset 4-5)
        if len(data) > 6:
            ip_id = int.from_bytes(data[4:6], "big")
            ip_id = (ip_id + random.randint(1, 100)) & 0xFFFF
            data[4:6] = ip_id.to_bytes(2, "big")
        # 随机修改 TCP 窗口大小 (offset 16-17 in TCP header, IP header is 20 bytes)
        if len(data) > 37:
            window = int.from_bytes(data[34:36], "big")
            perturbation = random.randint(-1000, 1000)
            window = max(1, window + perturbation)
            data[34:36] = (window & 0xFFFF).to_bytes(2, "big")

        return bytes(data)

    async def intercept_with_perturbation(
        self,
        host: str,
        port: int,
        data: bytes,
        protocol: str = "tcp",
    ) -> Tuple[str, int, bytes]:
        """
        带特征扰动的流量拦截

        在拦截的同时对流量进行随机化扰动。
        """
        perturbed = self.perturb_traffic_features(data)
        return await self.intercept(host, port, perturbed, protocol)

    def list_rules(self) -> List[Dict]:
        """列出所有规则"""
        return [
            {
                "target": f"{r.target_host}:{r.target_port}",
                "action": r.action,
                "redirect": f"{r.redirect_host}:{r.redirect_port}" if r.redirect_host else "",
                "enabled": r.enabled,
                "priority": r.priority,
            }
            for r in self._rules
        ]
