"""
预封装引擎模块

在数据发送前预先进行多层加密封装。
"""

import os
import time
import logging
from typing import List, Optional, Dict, Tuple

from src.crypto.symmetric import SymmetricCipher, create_cipher
from src.crypto.key_derivation import KeyChain

logger = logging.getLogger(__name__)


class PrepackEngine:
    """
    预封装引擎

    在数据发送前预先进行多层加密封装:
    - 为每跳预计算加密层
    - 支持批量预封装
    - 减少发送时的计算延迟
    - 支持预封装缓存
    """

    def __init__(
        self,
        algorithm: str = "aes-256-gcm",
        key_chain: Optional[KeyChain] = None,
        cache_size: int = 100,
    ):
        self._algorithm = algorithm
        self._key_chain = key_chain or KeyChain()
        self._cache: Dict[str, bytes] = {}
        self._cache_size = cache_size
        self._stats = {
            "prepack_count": 0,
            "cache_hits": 0,
            "cache_misses": 0,
        }

    def prepack(
        self,
        plaintext: bytes,
        path_keys: List[bytes],
        destinations: List[str],
    ) -> List[bytes]:
        """
        预封装数据

        从内到外逐层加密，生成每跳的预封装包。

        Args:
            plaintext: 原始数据
            path_keys: 各跳密钥列表
            destinations: 各跳目标地址列表

        Returns:
            预封装包列表 (从外到内)
        """
        if len(path_keys) != len(destinations):
            raise ValueError("密钥数量与目标数量不匹配")

        layers = []
        current_data = plaintext

        # 从最后一跳开始，由内向外加密
        for i in range(len(path_keys) - 1, -1, -1):
            cipher = create_cipher(self._algorithm, path_keys[i])
            # 添加下一跳信息作为关联数据
            next_hop = destinations[i + 1] if i + 1 < len(destinations) else "exit"
            encrypted = cipher.encrypt(current_data, associated_data=next_hop.encode())
            layers.append(encrypted)
            current_data = encrypted

        # 反转: 最外层在前
        layers.reverse()
        self._stats["prepack_count"] += 1
        return layers

    def prepack_batch(
        self,
        messages: List[bytes],
        path_keys: List[bytes],
        destinations: List[str],
    ) -> List[List[bytes]]:
        """
        批量预封装

        Args:
            messages: 消息列表
            path_keys: 各跳密钥
            destinations: 各跳目标

        Returns:
            预封装包列表
        """
        return [
            self.prepack(msg, path_keys, destinations)
            for msg in messages
        ]

    def cache_prepack(
        self,
        cache_key: str,
        plaintext: bytes,
        path_keys: List[bytes],
        destinations: List[str],
    ) -> List[bytes]:
        """
        带缓存的预封装

        如果缓存中有结果则直接返回。
        """
        if cache_key in self._cache:
            self._stats["cache_hits"] += 1
            return list(self._cache[cache_key])

        self._stats["cache_misses"] += 1
        layers = self.prepack(plaintext, path_keys, destinations)

        # 缓存管理
        if len(self._cache) >= self._cache_size:
            # 移除最旧的缓存
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]
        self._cache[cache_key] = tuple(layers)

        return layers

    def invalidate_cache(self, cache_key: Optional[str] = None) -> None:
        """使缓存失效"""
        if cache_key:
            self._cache.pop(cache_key, None)
        else:
            self._cache.clear()

    def get_stats(self) -> dict:
        """获取统计信息"""
        total = self._stats["cache_hits"] + self._stats["cache_misses"]
        hit_rate = self._stats["cache_hits"] / total if total > 0 else 0
        return {
            **self._stats,
            "cache_size": len(self._cache),
            "hit_rate": hit_rate,
        }

    def prepack_with_format_randomization(
        self,
        plaintext: bytes,
        path_keys: List[bytes],
        destinations: List[str],
    ) -> List[bytes]:
        """
        带格式随机化的预封装

        在标准预封装基础上，对每层加密包进行格式随机化，
        使AI无法通过包格式模式识别预封装流量。

        随机化策略:
        1. 随机插入虚假层
        2. 随机打乱层顺序标记
        3. 随机添加元数据填充
        4. 随机选择加密算法
        """
        import random as rng
        import struct

        if len(path_keys) != len(destinations):
            raise ValueError("密钥数量与目标数量不匹配")

        layers = []
        current_data = plaintext

        # 从最后一跳开始，由内向外加密
        for i in range(len(path_keys) - 1, -1, -1):
            # 随机选择加密算法
            algo = rng.choice(["aes-256-gcm", "chacha20-poly1305"])
            cipher = create_cipher(algo, path_keys[i])

            next_hop = destinations[i + 1] if i + 1 < len(destinations) else "exit"

            # 随机添加元数据填充 (防AI包大小分析)
            metadata = os.urandom(rng.randint(0, 32))
            augmented_data = struct.pack("!I", len(metadata)) + metadata + current_data

            encrypted = cipher.encrypt(augmented_data, associated_data=next_hop.encode())

            # 随机添加虚假填充层 (概率20%)
            if rng.random() < 0.2:
                fake_layer = os.urandom(rng.randint(64, 256))
                encrypted = struct.pack("!I", len(fake_layer)) + fake_layer + encrypted

            layers.append(encrypted)
            current_data = encrypted

        # 反转: 最外层在前
        layers.reverse()

        # 随机打乱层大小标记 (使AI无法通过层大小模式识别)
        if layers and rng.random() < 0.3:
            # 在随机位置插入大小一致的虚假层
            insert_pos = rng.randint(0, len(layers))
            fake = os.urandom(len(layers[0]) if layers else 64)
            layers.insert(insert_pos, fake)

        self._stats["prepack_count"] += 1
        return layers
