"""
指纹随机化模块

随机化网络流量指纹，防止基于指纹的去匿名化。
"""

import os
import random
import time
import hashlib
import logging
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class FingerprintProfile:
    """指纹配置"""
    packet_size_mean: float = 800
    packet_size_std: float = 200
    timing_mean_ms: float = 100
    timing_std_ms: float = 50
    header_order: Optional[List[str]] = None
    tls_version: str = "TLS 1.3"
    window_size: int = 65535
    ttl: int = 64
    df_flag: bool = True  # Don't Fragment


class FingerprintRandomizer:
    """
    指纹随机化器

    随机化网络流量指纹:
    - 包大小随机化
    - 时序随机化
    - TCP/IP 头字段随机化
    - TLS 指纹随机化
    - 窗口大小随机化
    """

    # 常见窗口大小
    COMMON_WINDOW_SIZES = [
        29200, 64240, 65535, 65536, 128000, 256000,
        65520, 16384, 32768, 8192, 4096,
    ]

    # 常见 TTL 值
    COMMON_TTLS = [32, 48, 60, 61, 62, 63, 64, 128, 255]

    def __init__(self, seed: Optional[int] = None):
        self._rng = random.Random(seed)
        self._profiles: List[FingerprintProfile] = []
        self._current_profile: Optional[FingerprintProfile] = None
        self._profile_rotation_interval = 10  # 10秒动态漂移
        self._last_rotation = time.time()

    @property
    def current_profile(self) -> Optional[FingerprintProfile]:
        self._check_rotation()
        return self._current_profile

    def generate_profile(self) -> FingerprintProfile:
        """生成随机指纹配置"""
        profile = FingerprintProfile(
            packet_size_mean=self._rng.uniform(400, 1400),
            packet_size_std=self._rng.uniform(50, 500),
            timing_mean_ms=self._rng.uniform(20, 500),
            timing_std_ms=self._rng.uniform(10, 200),
            window_size=self._rng.choice(self.COMMON_WINDOW_SIZES),
            ttl=self._rng.choice(self.COMMON_TTLS),
            df_flag=self._rng.choice([True, True, True, False]),  # 75% DF
        )
        return profile

    def randomize_packet_size(self, data: bytes) -> bytes:
        """
        随机化包大小

        添加随机填充使包大小不可预测。
        """
        if not self._current_profile:
            self._current_profile = self.generate_profile()

        profile = self._current_profile
        # 生成目标大小
        target_size = int(self._rng.gauss(profile.packet_size_mean, profile.packet_size_std))
        target_size = max(64, min(1400, target_size))

        current_size = len(data)
        if current_size < target_size:
            padding_size = target_size - current_size
            padding = os.urandom(padding_size)
            return data + padding
        return data

    def randomize_timing(self) -> float:
        """
        随机化发送时序

        Returns:
            延迟时间(毫秒)
        """
        if not self._current_profile:
            self._current_profile = self.generate_profile()

        profile = self._current_profile
        delay = self._rng.gauss(profile.timing_mean_ms, profile.timing_std_ms)
        return max(0, delay)

    def randomize_ip_header(self, ttl: Optional[int] = None, window: Optional[int] = None) -> Dict:
        """
        随机化 IP/TCP 头字段

        Returns:
            随机化的头字段
        """
        return {
            "ttl": ttl or self._rng.choice(self.COMMON_TTLS),
            "window_size": window or self._rng.choice(self.COMMON_WINDOW_SIZES),
            "df": self._rng.choice([True, True, True, False]),
            "id": self._rng.randint(0, 65535),
        }

    def randomize_tcp_options(self) -> List[Tuple[int, bytes]]:
        """
        随机化 TCP 选项

        Returns:
            TCP 选项列表 [(kind, data), ...]
        """
        options = []
        # MSS (kind=2)
        mss = self._rng.choice([1460, 1440, 1400, 1360, 536])
        options.append((2, mss.to_bytes(2, "big")))
        # Window Scale (kind=3)
        ws = self._rng.randint(2, 10)
        options.append((3, bytes([ws])))
        # SACK Permitted (kind=4)
        if self._rng.random() < 0.8:
            options.append((4, b""))
        # Timestamps (kind=8)
        if self._rng.random() < 0.7:
            ts_val = self._rng.randint(0, 2**32 - 1)
            ts_ecr = self._rng.randint(0, 2**32 - 1)
            options.append((8, ts_val.to_bytes(4, "big") + ts_ecr.to_bytes(4, "big")))
        # NOP (kind=1) padding
        if self._rng.random() < 0.5:
            options.append((1, b""))
        # End of Options (kind=0)
        options.append((0, b""))
        return options

    def generate_fingerprint_pool(self, size: int = 10) -> List[FingerprintProfile]:
        """生成指纹池"""
        self._profiles = [self.generate_profile() for _ in range(size)]
        if not self._current_profile:
            self._current_profile = self._profiles[0]
        return self._profiles

    def rotate_profile(self) -> FingerprintProfile:
        """轮换当前指纹配置"""
        if self._profiles:
            self._current_profile = self._rng.choice(self._profiles)
        else:
            self._current_profile = self.generate_profile()
        self._last_rotation = time.time()
        return self._current_profile

    def _check_rotation(self) -> None:
        """检查是否需要轮换"""
        if time.time() - self._last_rotation > self._profile_rotation_interval:
            self.rotate_profile()

    def get_stats(self) -> dict:
        return {
            "profiles_count": len(self._profiles),
            "current_profile": {
                "packet_size_mean": self._current_profile.packet_size_mean if self._current_profile else 0,
                "window_size": self._current_profile.window_size if self._current_profile else 0,
                "ttl": self._current_profile.ttl if self._current_profile else 0,
            },
            "time_since_rotation": time.time() - self._last_rotation,
        }

    def drift_all_features(self) -> FingerprintProfile:
        """
        全特征漂移刷新

        同时刷新所有指纹特征，使AI无法通过特征稳定性识别用户。
        每10秒调用一次，确保特征完全不可预测。
        """
        # 重新生成所有参数，使用更大的随机范围
        profile = FingerprintProfile(
            packet_size_mean=self._rng.uniform(200, 1500),
            packet_size_std=self._rng.uniform(100, 800),
            timing_mean_ms=self._rng.uniform(5, 1000),
            timing_std_ms=self._rng.uniform(5, 500),
            window_size=self._rng.choice(self.COMMON_WINDOW_SIZES + [128000, 256000, 512000]),
            ttl=self._rng.choice(self.COMMON_TTLS + [64, 65, 66, 67, 128, 129]),
            df_flag=self._rng.choice([True, False]),
        )
        self._current_profile = profile
        self._last_rotation = time.time()
        # 同时清空配置池，强制下次生成全新配置
        self._profiles.clear()
        return profile

    def get_entropy_score(self) -> float:
        """
        计算当前指纹的熵值

        熵值越高，AI越难识别。
        """
        if not self._current_profile:
            return 0.0
        import math
        p = self._current_profile
        # 估算各维度的熵
        size_entropy = math.log2(max(1, p.packet_size_std / 10))
        timing_entropy = math.log2(max(1, p.timing_std_ms / 5))
        window_entropy = math.log2(len(self.COMMON_WINDOW_SIZES))
        ttl_entropy = math.log2(len(self.COMMON_TTLS))
        return size_entropy + timing_entropy + window_entropy + ttl_entropy
