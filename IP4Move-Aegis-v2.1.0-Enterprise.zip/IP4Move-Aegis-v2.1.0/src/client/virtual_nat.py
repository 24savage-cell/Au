"""
虚拟NAT层模块 (v1.0.5 真实实现 - 类型注解完善版)

实现内容:
1. 使用 scapy 解析 IP/TCP/UDP 包，修改源/目的地址和端口
2. 正确重新计算 IP 校验和、TCP/UDP 校验和
3. 当 scapy 不可用时，使用 struct 手动解析 IP/TCP/UDP 头
4. 支持 TCP 和 UDP 协议的 NAT 重写
5. 手动计算校验和（16位反码求和，带伪头）
"""

import os
import time
import random
import struct
import socket
import logging
from typing import Optional, Dict, Tuple, List, Callable
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# 尝试导入 scapy，不可用时使用 struct 回退
try:
    from scapy.all import IP, TCP, UDP, Raw
    from scapy.packet import Packet as ScapyPacket
    _SCAPY_AVAILABLE = True
    logger.info("scapy 已加载，使用 scapy 进行 NAT 包重写")
except ImportError:
    _SCAPY_AVAILABLE = False
    logger.info("scapy 不可用，使用 struct 手动解析进行 NAT 包重写")


@dataclass
class NATEntry:
    """NAT 映射条目"""
    internal_addr: str
    internal_port: int
    external_addr: str
    external_port: int
    protocol: str  # tcp, udp
    created_at: float = field(default_factory=time.time)
    last_used: float = field(default_factory=time.time)
    timeout: float = 300  # 秒

    @property
    def is_expired(self) -> bool:
        """检查映射是否已过期"""
        return time.time() - self.last_used > self.timeout

    @property
    def mapping(self) -> str:
        """返回映射字符串表示"""
        return f"{self.internal_addr}:{self.internal_port} -> {self.external_addr}:{self.external_port}"


# ==================== 校验和计算工具 ====================

def _ip_to_int(addr: str) -> int:
    """将 IP 地址字符串转换为 32 位整数"""
    try:
        return struct.unpack("!I", socket.inet_aton(addr))[0]
    except (socket.error, struct.error):
        return 0


def _int_to_ip(val: int) -> str:
    """将 32 位整数转换为 IP 地址字符串"""
    try:
        return socket.inet_ntoa(struct.pack("!I", val & 0xFFFFFFFF))
    except (socket.error, struct.error):
        return "0.0.0.0"


def _checksum(data: bytes) -> int:
    """
    计算互联网校验和（RFC 1071）

    16位反码求和，将进位折叠回低位。
    """
    if len(data) % 2 == 1:
        # 奇数长度，末尾补零
        data = data + b'\x00'

    total = 0
    for i in range(0, len(data), 2):
        word = (data[i] << 8) + data[i + 1]
        total += word

    # 折叠进位
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)

    return ~total & 0xFFFF


def _make_pseudo_header(
    src_addr: str,
    dst_addr: str,
    protocol: int,
    transport_len: int,
) -> bytes:
    """
    构造 TCP/UDP 校验和的伪头

    格式 (RFC 768 / RFC 793):
      [4字节: 源IP] [4字节: 目的IP] [1字节: 0] [1字节: 协议] [2字节: 传输层长度]
    """
    src = struct.pack("!I", _ip_to_int(src_addr))
    dst = struct.pack("!I", _ip_to_int(dst_addr))
    zero = b'\x00'
    proto = struct.pack("!B", protocol)
    length = struct.pack("!H", transport_len)
    return src + dst + zero + proto + length


# ==================== struct 回退实现 ====================

def _rewrite_packet_struct(
    data: bytes,
    new_src_addr: str,
    new_src_port: int,
    protocol: str,
) -> bytes:
    """
    使用 struct 手动解析和重写 IP 包（出站方向）

    修改源 IP 地址和源端口，重新计算校验和。

    Args:
        data: 原始 IP 包
        new_src_addr: 新的源 IP 地址
        new_src_port: 新的源端口
        protocol: "tcp" 或 "udp"

    Returns:
        重写后的 IP 包
    """
    if len(data) < 20:
        logger.warning("IP 包过短，无法解析")
        return data

    # 解析 IP 头
    version_ihl = data[0]
    ihl = (version_ihl & 0x0F) * 4  # IP 头长度（字节）
    if ihl < 20 or len(data) < ihl:
        logger.warning(f"无效的 IP 头长度: {ihl}")
        return data

    ip_header = bytearray(data[:ihl])

    # 修改源 IP 地址（字节 12-15）
    new_src_ip_bytes = socket.inet_aton(new_src_addr)
    ip_header[12:16] = new_src_ip_bytes

    # 清零 IP 校验和（字节 10-11），然后重新计算
    ip_header[10] = 0
    ip_header[11] = 0
    ip_checksum = _checksum(bytes(ip_header))
    ip_header[10] = (ip_checksum >> 8) & 0xFF
    ip_header[11] = ip_checksum & 0xFF

    # 处理传输层头
    transport_data = bytearray(data[ihl:])
    proto_num = data[9]  # IP 头中的协议字段

    if protocol.lower() == "tcp" and len(transport_data) >= 20:
        # TCP: 修改源端口（字节 0-1）
        struct.pack_into("!H", transport_data, 0, new_src_port)

        # 重新计算 TCP 校验和
        # TCP 校验和覆盖: 伪头 + TCP 头 + TCP 数据
        dst_addr_bytes = data[16:20]
        dst_addr_str = socket.inet_ntoa(dst_addr_bytes)

        # 清零 TCP 校验和（字节 16-17）
        transport_data[16] = 0
        transport_data[17] = 0

        # 构造伪头
        pseudo = _make_pseudo_header(new_src_addr, dst_addr_str, proto_num, len(transport_data))
        tcp_checksum = _checksum(pseudo + bytes(transport_data))
        transport_data[16] = (tcp_checksum >> 8) & 0xFF
        transport_data[17] = tcp_checksum & 0xFF

    elif protocol.lower() == "udp" and len(transport_data) >= 8:
        # UDP: 修改源端口（字节 0-1）
        struct.pack_into("!H", transport_data, 0, new_src_port)

        # 重新计算 UDP 校验和
        dst_addr_bytes = data[16:20]
        dst_addr_str = socket.inet_ntoa(dst_addr_bytes)

        # 清零 UDP 校验和（字节 6-7）
        transport_data[6] = 0
        transport_data[7] = 0

        # 构造伪头
        pseudo = _make_pseudo_header(new_src_addr, dst_addr_str, proto_num, len(transport_data))
        udp_checksum = _checksum(pseudo + bytes(transport_data))
        transport_data[6] = (udp_checksum >> 8) & 0xFF
        transport_data[7] = udp_checksum & 0xFF

    return bytes(ip_header) + bytes(transport_data)


def _rewrite_packet_reverse_struct(
    data: bytes,
    new_dst_addr: str,
    new_dst_port: int,
    protocol: str,
) -> bytes:
    """
    使用 struct 手动解析和重写 IP 包（入站方向）

    修改目的 IP 地址和目的端口，重新计算校验和。

    Args:
        data: 原始 IP 包
        new_dst_addr: 新的目的 IP 地址
        new_dst_port: 新的目的端口
        protocol: "tcp" 或 "udp"

    Returns:
        重写后的 IP 包
    """
    if len(data) < 20:
        logger.warning("IP 包过短，无法解析")
        return data

    # 解析 IP 头
    version_ihl = data[0]
    ihl = (version_ihl & 0x0F) * 4
    if ihl < 20 or len(data) < ihl:
        logger.warning(f"无效的 IP 头长度: {ihl}")
        return data

    ip_header = bytearray(data[:ihl])

    # 修改目的 IP 地址（字节 16-19）
    new_dst_ip_bytes = socket.inet_aton(new_dst_addr)
    ip_header[16:20] = new_dst_ip_bytes

    # 清零 IP 校验并重新计算
    ip_header[10] = 0
    ip_header[11] = 0
    ip_checksum = _checksum(bytes(ip_header))
    ip_header[10] = (ip_checksum >> 8) & 0xFF
    ip_header[11] = ip_checksum & 0xFF

    # 处理传输层头
    transport_data = bytearray(data[ihl:])
    proto_num = data[9]

    if protocol.lower() == "tcp" and len(transport_data) >= 20:
        # TCP: 修改目的端口（字节 2-3）
        struct.pack_into("!H", transport_data, 2, new_dst_port)

        # 重新计算 TCP 校验和
        src_addr_bytes = data[12:16]
        src_addr_str = socket.inet_ntoa(src_addr_bytes)

        transport_data[16] = 0
        transport_data[17] = 0

        pseudo = _make_pseudo_header(src_addr_str, new_dst_addr, proto_num, len(transport_data))
        tcp_checksum = _checksum(pseudo + bytes(transport_data))
        transport_data[16] = (tcp_checksum >> 8) & 0xFF
        transport_data[17] = tcp_checksum & 0xFF

    elif protocol.lower() == "udp" and len(transport_data) >= 8:
        # UDP: 修改目的端口（字节 2-3）
        struct.pack_into("!H", transport_data, 2, new_dst_port)

        # 重新计算 UDP 校验和
        src_addr_bytes = data[12:16]
        src_addr_str = socket.inet_ntoa(src_addr_bytes)

        transport_data[6] = 0
        transport_data[7] = 0

        pseudo = _make_pseudo_header(src_addr_str, new_dst_addr, proto_num, len(transport_data))
        udp_checksum = _checksum(pseudo + bytes(transport_data))
        transport_data[6] = (udp_checksum >> 8) & 0xFF
        transport_data[7] = udp_checksum & 0xFF

    return bytes(ip_header) + bytes(transport_data)


# ==================== scapy 实现 ====================

def _rewrite_packet_scapy(
    data: bytes,
    new_src_addr: str,
    new_src_port: int,
    protocol: str,
) -> bytes:
    """
    使用 scapy 解析和重写 IP 包（出站方向）

    修改源 IP 地址和源端口，scapy 自动重新计算校验和。
    """
    try:
        pkt = IP(data)
    except Exception:
        logger.warning("scapy 无法解析数据包，回退到 struct 实现")
        return _rewrite_packet_struct(data, new_src_addr, new_src_port, protocol)

    # 修改源 IP 地址
    pkt.src = new_src_addr

    # 修改传输层源端口
    if protocol.lower() == "tcp" and TCP in pkt:
        pkt[TCP].sport = new_src_port
    elif protocol.lower() == "udp" and UDP in pkt:
        pkt[UDP].sport = new_src_port

    # scapy 在序列化时自动删除并重新计算校验和
    # 但为了确保正确性，手动删除校验和让 scapy 重新计算
    del pkt.chksum
    if TCP in pkt:
        del pkt[TCP].chksum
    elif UDP in pkt:
        del pkt[UDP].chksum

    return bytes(pkt)


def _rewrite_packet_reverse_scapy(
    data: bytes,
    new_dst_addr: str,
    new_dst_port: int,
    protocol: str,
) -> bytes:
    """
    使用 scapy 解析和重写 IP 包（入站方向）

    修改目的 IP 地址和目的端口，scapy 自动重新计算校验和。
    """
    try:
        pkt = IP(data)
    except Exception:
        logger.warning("scapy 无法解析数据包，回退到 struct 实现")
        return _rewrite_packet_reverse_struct(data, new_dst_addr, new_dst_port, protocol)

    # 修改目的 IP 地址
    pkt.dst = new_dst_addr

    # 修改传输层目的端口
    if protocol.lower() == "tcp" and TCP in pkt:
        pkt[TCP].dport = new_dst_port
    elif protocol.lower() == "udp" and UDP in pkt:
        pkt[UDP].dport = new_dst_port

    # 删除校验和让 scapy 重新计算
    del pkt.chksum
    if TCP in pkt:
        del pkt[TCP].chksum
    elif UDP in pkt:
        del pkt[UDP].chksum

    return bytes(pkt)


# ==================== VirtualNAT 主类 ====================

class VirtualNAT:
    """
    虚拟 NAT 层 (v1.0.5 真实实现)

    功能:
    - 端口映射 (内部 -> 外部)
    - 随机化外部地址
    - NAT 类型模拟 (Full Cone, Restricted, Port-Restricted)
    - 连接跟踪
    - 真实的 IP/TCP/UDP 包重写（scapy 或 struct 回退）
    - 正确的校验和重新计算
    """

    def __init__(
        self,
        external_address: str = "10.0.0.1",
        port_range: Tuple[int, int] = (10000, 60000),
        nat_type: str = "port_restricted",
        entry_timeout: float = 300,
    ):
        self._external_address = external_address
        self._port_range = port_range
        self._nat_type = nat_type
        self._entry_timeout = entry_timeout
        self._entries: Dict[str, NATEntry] = {}
        self._used_ports: set = set()
        self._port_counter = 0
        self._use_scapy = _SCAPY_AVAILABLE

    @property
    def entry_count(self) -> int:
        """返回当前 NAT 映射条目数"""
        return len(self._entries)

    def create_mapping(
        self,
        internal_addr: str,
        internal_port: int,
        protocol: str = "tcp",
    ) -> NATEntry:
        """
        创建 NAT 映射

        Args:
            internal_addr: 内部地址
            internal_port: 内部端口
            protocol: 协议

        Returns:
            NAT 映射条目
        """
        # 检查是否已有映射
        key = f"{internal_addr}:{internal_port}:{protocol}"
        if key in self._entries:
            entry = self._entries[key]
            entry.last_used = time.time()
            return entry

        # 分配外部端口
        external_port = self._allocate_port()

        # 根据NAT类型确定外部地址
        if self._nat_type == "full_cone":
            ext_addr = self._external_address
        elif self._nat_type == "restricted":
            ext_addr = self._external_address
        elif self._nat_type == "port_restricted":
            ext_addr = self._external_address
        else:
            ext_addr = self._external_address

        entry = NATEntry(
            internal_addr=internal_addr,
            internal_port=internal_port,
            external_addr=ext_addr,
            external_port=external_port,
            protocol=protocol,
            timeout=self._entry_timeout,
        )
        self._entries[key] = entry
        logger.debug(f"NAT 映射: {entry.mapping}")
        return entry

    def translate_outbound(
        self,
        internal_addr: str,
        internal_port: int,
        data: bytes,
        protocol: str = "tcp",
    ) -> Tuple[str, int, bytes]:
        """
        出站地址转换

        解析 IP 包，修改源地址和源端口，重新计算校验和。

        Returns:
            (external_addr, external_port, translated_data)
        """
        entry = self.create_mapping(internal_addr, internal_port, protocol)
        translated = self._rewrite_packet(data, internal_addr, internal_port, entry)
        return entry.external_addr, entry.external_port, translated

    def translate_inbound(
        self,
        external_addr: str,
        external_port: int,
        data: bytes,
    ) -> Optional[Tuple[str, int, bytes]]:
        """
        入站地址转换

        解析 IP 包，修改目的地址和目的端口，重新计算校验和。

        Returns:
            (internal_addr, internal_port, translated_data) 或 None
        """
        # 查找映射
        for key, entry in self._entries.items():
            if entry.external_addr == external_addr and entry.external_port == external_port:
                entry.last_used = time.time()
                translated = self._rewrite_packet_reverse(data, entry)
                return entry.internal_addr, entry.internal_port, translated
        return None

    def _allocate_port(self) -> int:
        """分配外部端口"""
        start, end = self._port_range
        for _ in range(100):
            port = random.randint(start, end)
            if port not in self._used_ports:
                self._used_ports.add(port)
                return port
        # 回退: 顺序分配
        self._port_counter = (self._port_counter % (end - start)) + start
        port = self._port_counter
        self._used_ports.add(port)
        self._port_counter += 1
        return port

    def _rewrite_packet(
        self,
        data: bytes,
        src_addr: str,
        src_port: int,
        entry: NATEntry,
    ) -> bytes:
        """
        重写数据包地址（出站方向）

        修改源 IP 地址和源端口，重新计算校验和。
        优先使用 scapy，不可用时回退到 struct 手动解析。
        """
        if len(data) < 20:
            # 数据包太短，不是有效的 IP 包，直接返回
            return data

        try:
            if self._use_scapy:
                return _rewrite_packet_scapy(
                    data,
                    entry.external_addr,
                    entry.external_port,
                    entry.protocol,
                )
            else:
                return _rewrite_packet_struct(
                    data,
                    entry.external_addr,
                    entry.external_port,
                    entry.protocol,
                )
        except Exception as e:
            logger.error(f"NAT 出站重写失败: {e}")
            return data

    def _rewrite_packet_reverse(self, data: bytes, entry: NATEntry) -> bytes:
        """
        反向重写数据包地址（入站方向）

        修改目的 IP 地址和目的端口，重新计算校验和。
        优先使用 scapy，不可用时回退到 struct 手动解析。
        """
        if len(data) < 20:
            return data

        try:
            if self._use_scapy:
                return _rewrite_packet_reverse_scapy(
                    data,
                    entry.internal_addr,
                    entry.internal_port,
                    entry.protocol,
                )
            else:
                return _rewrite_packet_reverse_struct(
                    data,
                    entry.internal_addr,
                    entry.internal_port,
                    entry.protocol,
                )
        except Exception as e:
            logger.error(f"NAT 入站重写失败: {e}")
            return data

    def remove_mapping(self, internal_addr: str, internal_port: int, protocol: str = "tcp") -> bool:
        """移除映射"""
        key = f"{internal_addr}:{internal_port}:{protocol}"
        if key in self._entries:
            entry = self._entries.pop(key)
            self._used_ports.discard(entry.external_port)
            return True
        return False

    def cleanup_expired(self) -> int:
        """清理过期映射"""
        now = time.time()
        expired = [
            key for key, entry in self._entries.items()
            if now - entry.last_used > entry.timeout
        ]
        for key in expired:
            entry = self._entries.pop(key)
            self._used_ports.discard(entry.external_port)
        return len(expired)

    def get_stats(self) -> Dict[str, any]:
        """获取统计信息"""
        return {
            "total_entries": len(self._entries),
            "used_ports": len(self._used_ports),
            "nat_type": self._nat_type,
            "use_scapy": self._use_scapy,
        }

    def refresh_mappings_periodically(self) -> int:
        """
        周期性刷新NAT映射

        每30秒刷新所有活跃映射的外部端口和地址，
        使AI无法通过NAT映射的稳定性关联链路。

        Returns:
            刷新的映射数量
        """
        refreshed = 0
        now = time.time()
        for key, entry in self._entries.items():
            # 每次调用只刷新超过30秒未刷新的映射
            if now - entry.last_used > 30:
                # 释放旧端口
                self._used_ports.discard(entry.external_port)
                # 分配新的外部端口
                new_port = self._allocate_port()
                # 随机化外部地址（在虚拟地址范围内）
                octets = self._external_address.split(".")
                if len(octets) == 4:
                    last_octet = str(random.randint(1, 254))
                    entry.external_addr = ".".join(octets[:3] + [last_octet])
                entry.external_port = new_port
                entry.last_used = now
                refreshed += 1

        if refreshed:
            logger.debug(f"NAT映射刷新: {refreshed} 个映射已更新")
        return refreshed

    def auto_refresh_loop(self) -> int:
        """
        自动刷新检查

        应在定时任务中调用，检查并刷新需要更新的映射。
        """
        return self.refresh_mappings_periodically()
