"""
贡献证明模块

记录和验证节点对网络的贡献。
"""

import time
import hashlib
import logging
from typing import Optional, Dict, List
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class ContributionRecord:
    """贡献记录"""
    node_id: str
    contribution_type: str  # relay, mix, exit, seed
    amount: float
    timestamp: float = field(default_factory=time.time)
    proof: bytes = b""
    block_hash: str = ""


class ContributionProver:
    """
    贡献证明器

    记录和验证节点贡献:
    - 中继流量
    - Mix 处理
    - 出口带宽
    - 种子节点服务
    """

    def __init__(self, window_size: int = 86400):
        self._window_size = window_size
        self._records: Dict[str, List[ContributionRecord]] = {}
        self._total_contributions: Dict[str, float] = {}

    def record_contribution(
        self,
        node_id: str,
        contribution_type: str,
        amount: float,
        proof: Optional[bytes] = None,
    ) -> ContributionRecord:
        """
        记录贡献

        Args:
            node_id: 节点ID
            contribution_type: 贡献类型
            amount: 贡献量
            proof: 证明数据

        Returns:
            贡献记录
        """
        # 生成证明哈希
        proof_data = f"{node_id}:{contribution_type}:{amount}:{time.time()}".encode()
        block_hash = hashlib.sha256(proof_data).hexdigest()

        record = ContributionRecord(
            node_id=node_id,
            contribution_type=contribution_type,
            amount=amount,
            proof=proof or proof_data,
            block_hash=block_hash,
        )

        if node_id not in self._records:
            self._records[node_id] = []
        self._records[node_id].append(record)

        # 更新总贡献
        self._total_contributions[node_id] = (
            self._total_contributions.get(node_id, 0) + amount
        )

        return record

    def verify_contribution(self, record: ContributionRecord) -> bool:
        """验证贡献记录"""
        # 验证哈希
        expected_hash = hashlib.sha256(record.proof).hexdigest()
        if expected_hash != record.block_hash:
            return False

        # 验证时间窗口
        if time.time() - record.timestamp > self._window_size:
            return False

        return True

    def get_contributions(
        self,
        node_id: str,
        since: Optional[float] = None,
    ) -> List[ContributionRecord]:
        """获取节点的贡献记录"""
        records = self._records.get(node_id, [])
        if since:
            records = [r for r in records if r.timestamp >= since]
        return records

    def get_total_contribution(self, node_id: str) -> float:
        """获取节点总贡献"""
        return self._total_contributions.get(node_id, 0)

    def get_leaderboard(self, limit: int = 10) -> List[tuple]:
        """获取贡献排行榜"""
        sorted_nodes = sorted(
            self._total_contributions.items(),
            key=lambda x: x[1],
            reverse=True,
        )
        return sorted_nodes[:limit]

    def cleanup_expired(self) -> int:
        """清理过期记录"""
        cutoff = time.time() - self._window_size
        total_removed = 0
        for node_id in list(self._records.keys()):
            original = len(self._records[node_id])
            self._records[node_id] = [
                r for r in self._records[node_id] if r.timestamp >= cutoff
            ]
            removed = original - len(self._records[node_id])
            total_removed += removed
            # 重新计算总贡献
            self._total_contributions[node_id] = sum(
                r.amount for r in self._records[node_id]
            )
        return total_removed

    def get_stats(self) -> dict:
        return {
            "total_nodes": len(self._records),
            "total_records": sum(len(r) for r in self._records.values()),
            "window_size": self._window_size,
        }

    def sign_contribution_pqc(self, record: ContributionRecord, signing_key: bytes) -> bytes:
        """
        使用后量子签名签署贡献记录

        防止贡献证明被伪造。
        """
        record_data = (
            f"{record.node_id}:{record.contribution_type}:{record.amount}:{record.timestamp}"
        ).encode()
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PrivateKey,
            )
            private_key = MLDSA65PrivateKey.from_private_bytes(signing_key)
            return private_key.sign(record_data)
        except ImportError:
            import hmac as hmac_mod
            return hmac_mod.new(signing_key, record_data, hashlib.sha512).digest()

    def verify_contribution_pqc(self, record: ContributionRecord, signature: bytes, verify_key: bytes) -> bool:
        """
        验证贡献记录的后量子签名
        """
        record_data = (
            f"{record.node_id}:{record.contribution_type}:{record.amount}:{record.timestamp}"
        ).encode()
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PublicKey,
            )
            public_key = MLDSA65PublicKey.from_public_bytes(verify_key)
            public_key.verify(signature, record_data)
            return True
        except Exception:
            return False

    def generate_pqc_proof(self, node_id: str, contribution_type: str, amount: float, signing_key: bytes) -> ContributionRecord:
        """
        生成带后量子签名的贡献记录
        """
        record = self.record_contribution(node_id, contribution_type, amount)
        record.proof = self.sign_contribution_pqc(record, signing_key)
        return record
