"""
积分系统模块

管理节点的积分奖励和惩罚。
"""

import time
import hashlib
import logging
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class Transaction:
    """积分交易"""
    tx_id: str
    node_id: str
    amount: float
    balance_after: float
    reason: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class CreditConfig:
    """积分配置"""
    initial_credits: float = 100
    credit_per_relay: float = 1
    credit_per_mix: float = 2
    credit_per_exit: float = 3
    credit_penalty: float = -10
    max_credits: float = 10000
    min_credits: float = 0
    decay_rate: float = 0.01  # 每小时衰减率


class CreditSystem:
    """
    积分系统

    管理节点积分:
    - 中继奖励
    - Mix 处理奖励
    - 出口带宽奖励
    - 恶意行为惩罚
    - 积分衰减
    """

    def __init__(self, config: Optional[CreditConfig] = None):
        self._config = config or CreditConfig()
        self._balances: Dict[str, float] = {}
        self._transactions: Dict[str, List[Transaction]] = {}
        self._tx_counter = 0
        self._last_decay = time.time()

    def create_account(self, node_id: str) -> float:
        """创建账户并发放初始积分"""
        if node_id in self._balances:
            return self._balances[node_id]
        self._balances[node_id] = self._config.initial_credits
        self._transactions[node_id] = []
        logger.info(f"创建积分账户: {node_id}, 初始积分: {self._config.initial_credits}")
        return self._config.initial_credits

    def get_balance(self, node_id: str) -> float:
        """获取余额"""
        return self._balances.get(node_id, 0)

    def reward_relay(self, node_id: str, bytes_relayed: int = 0) -> float:
        """奖励中继贡献"""
        amount = self._config.credit_per_relay
        if bytes_relayed > 0:
            amount += bytes_relayed / 1024 * 0.1  # 每 KB 额外 0.1 积分
        return self._add_credits(node_id, amount, "relay")

    def reward_mix(self, node_id: str, packets_processed: int = 0) -> float:
        """奖励 Mix 处理"""
        amount = self._config.credit_per_mix
        if packets_processed > 0:
            amount += packets_processed * 0.05
        return self._add_credits(node_id, amount, "mix")

    def reward_exit(self, node_id: str, bytes_exited: int = 0) -> float:
        """奖励出口带宽"""
        amount = self._config.credit_per_exit
        if bytes_exited > 0:
            amount += bytes_exited / 1024 * 0.2
        return self._add_credits(node_id, amount, "exit")

    def penalize(self, node_id: str, reason: str = "misbehavior") -> float:
        """惩罚恶意行为"""
        return self._add_credits(node_id, self._config.credit_penalty, reason)

    def _add_credits(self, node_id: str, amount: float, reason: str) -> float:
        """添加积分"""
        if node_id not in self._balances:
            self.create_account(node_id)

        new_balance = self._balances[node_id] + amount
        new_balance = max(self._config.min_credits, min(self._config.max_credits, new_balance))
        self._balances[node_id] = new_balance

        # 记录交易
        self._tx_counter += 1
        tx = Transaction(
            tx_id=hashlib.sha256(f"{self._tx_counter}:{time.time()}".encode()).hexdigest()[:16],
            node_id=node_id,
            amount=amount,
            balance_after=new_balance,
            reason=reason,
        )
        self._transactions.setdefault(node_id, []).append(tx)

        return new_balance

    def apply_decay(self) -> Dict[str, float]:
        """应用积分衰减"""
        now = time.time()
        elapsed_hours = (now - self._last_decay) / 3600
        decayed = {}
        for node_id in list(self._balances.keys()):
            decay = self._balances[node_id] * self._config.decay_rate * elapsed_hours
            self._balances[node_id] = max(0, self._balances[node_id] - decay)
            decayed[node_id] = decay
        self._last_decay = now
        return decayed

    def get_transactions(self, node_id: str, limit: int = 50) -> List[Transaction]:
        """获取交易记录"""
        txs = self._transactions.get(node_id, [])
        return txs[-limit:]

    def get_top_nodes(self, limit: int = 10) -> List[tuple]:
        """获取积分排行"""
        sorted_nodes = sorted(
            self._balances.items(),
            key=lambda x: x[1],
            reverse=True,
        )
        return sorted_nodes[:limit]

    def get_stats(self) -> dict:
        return {
            "total_accounts": len(self._balances),
            "total_credits": sum(self._balances.values()),
            "total_transactions": sum(len(t) for t in self._transactions.values()),
            "avg_balance": sum(self._balances.values()) / max(1, len(self._balances)),
        }

    def sign_transaction_pqc(self, tx: Transaction, signing_key: bytes) -> bytes:
        """
        使用后量子签名签署积分交易

        防止积分交易被伪造或篡改。
        """
        tx_data = f"{tx.tx_id}:{tx.node_id}:{tx.amount}:{tx.balance_after}:{tx.reason}:{tx.timestamp}".encode()
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PrivateKey,
            )
            private_key = MLDSA65PrivateKey.from_private_bytes(signing_key)
            return private_key.sign(tx_data)
        except ImportError:
            import hmac as hmac_mod
            return hmac_mod.new(signing_key, tx_data, hashlib.sha512).digest()

    def verify_transaction_pqc(self, tx: Transaction, signature: bytes, verify_key: bytes) -> bool:
        """
        验证积分交易的后量子签名
        """
        tx_data = f"{tx.tx_id}:{tx.node_id}:{tx.amount}:{tx.balance_after}:{tx.reason}:{tx.timestamp}".encode()
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PublicKey,
            )
            public_key = MLDSA65PublicKey.from_public_bytes(verify_key)
            public_key.verify(signature, tx_data)
            return True
        except Exception:
            return False

    def create_signed_transaction(self, node_id: str, amount: float, reason: str, signing_key: bytes) -> Tuple[Transaction, bytes]:
        """
        创建带后量子签名的积分交易

        Returns:
            (transaction, signature)
        """
        balance = self._add_credits(node_id, amount, reason)
        tx = self._transactions[node_id][-1]
        signature = self.sign_transaction_pqc(tx, signing_key)
        return tx, signature
