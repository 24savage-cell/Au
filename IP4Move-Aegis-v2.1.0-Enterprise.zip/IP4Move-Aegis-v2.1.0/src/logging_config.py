"""
IP.4/Move-Aegis 结构化日志配置

使用 structlog 提供企业级结构化日志:
- JSON 格式输出 (生产环境)
- 彩色控制台输出 (开发环境)
- 请求ID追踪
- 性能指标日志
"""

import logging
import logging.config
import sys
from typing import Any, Dict, Optional

import structlog


def setup_logging(
    log_level: str = "INFO",
    json_output: bool = False,
    service_name: str = "ip4move-aegis",
) -> None:
    """
    配置结构化日志系统

    Args:
        log_level: 日志级别 (DEBUG/INFO/WARNING/ERROR/CRITICAL)
        json_output: 是否使用JSON格式输出 (生产环境建议开启)
        service_name: 服务名称标识
    """
    shared_processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.ExtraAdder(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
    ]

    # 日志脱敏处理器
    def _sanitize_processor(logger, method_name, event_dict):
        """
        脱敏处理器: 移除日志中的敏感信息
        
        安全依据:
        - NIST SP 800-92: 日志应不包含敏感信息
        - OWASP Logging Cheat Sheet: 敏感数据应在记录前脱敏
        """
        import re
        
        # 敏感字段列表 (扩展版)
        SENSITIVE_KEYS = {
            # 密码和密钥
            "password", "passwd", "pwd",
            "secret", "secret_key", "secret_key_id",
            "token", "access_token", "refresh_token", "auth_token",
            "api_key", "apikey", "api_secret",
            "private_key", "private_bytes", "priv_key",
            "signing_key", "verify_key", "signature_key",
            "master_key", "hmac_key", "session_key",
            "shared_secret", "shared_key",
            "encryption_key", "decryption_key",
            # 证书和身份
            "certificate", "cert", "private_cert",
            "node_id", "node_key", "identity_key",
            # 连接信息
            "connection_string", "conn_string", "dsn",
            "database_url", "db_password",
            # 其他敏感信息
            "credential", "credentials",
            "authorization", "auth_header",
            "cookie", "session_id",
        }
        
        # 递归脱敏函数
        def sanitize_value(key: str, value: Any, depth: int = 0) -> Any:
            """递归处理字典和列表中的敏感值"""
            if depth > 10:  # 防止无限递归
                return "[MAX_DEPTH]"
            
            key_lower = key.lower().replace("-", "_")
            
            # 检查是否为敏感字段
            if key_lower in SENSITIVE_KEYS:
                return "[REDACTED]"
            
            # 检查 key 中是否包含敏感词
            for sensitive in SENSITIVE_KEYS:
                if sensitive in key_lower:
                    return "[REDACTED]"
            
            if isinstance(value, dict):
                return {k: sanitize_value(k, v, depth + 1) for k, v in value.items()}
            elif isinstance(value, list):
                return [sanitize_value(f"item_{i}", v, depth + 1) for i, v in enumerate(value)]
            elif isinstance(value, str):
                # 脱敏 hex 格式密钥 (32-128 字符)
                if re.match(r'^[0-9a-fA-F]{32,128}$', value):
                    return "[REDACTED_KEY]"
                # 脱敏 base64 格式密钥
                if re.match(r'^[A-Za-z0-9+/]{40,}={0,2}$', value):
                    return "[REDACTED_B64]"
                # 脱敏可能的 IP 地址 (部分)
                if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', value):
                    parts = value.split('.')
                    return f"{parts[0]}.{parts[1]}.x.x"
            return value
        
        # 处理 event_dict 中的所有字段
        for key in list(event_dict.keys()):
            if key == "event":  # event 字段单独处理
                continue
            event_dict[key] = sanitize_value(key, event_dict[key])
        
        # 处理 event 消息中的 hex 密钥
        msg = str(event_dict.get("event", ""))
        msg = re.sub(r'\b[0-9a-fA-F]{32,128}\b', '[REDACTED_KEY]', msg)
        msg = re.sub(r'\b[A-Za-z0-9+/]{40,}={0,2}\b', '[REDACTED_B64]', msg)
        event_dict["event"] = msg
        
        return event_dict

    shared_processors.append(_sanitize_processor)

    if json_output:
        # 生产环境: JSON 格式
        renderer = structlog.processors.JSONRenderer()
    else:
        # 开发环境: 彩色控制台
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
        foreign_pre_chain=shared_processors,
    )

    logging.config.dictConfig({
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "structlog": {
                "()": structlog.stdlib.ProcessorFormatter,
                "processor": renderer,
                "foreign_pre_chain": shared_processors,
            },
        },
        "handlers": {
            "default": {
                "level": log_level,
                "class": "logging.StreamHandler",
                "stream": sys.stdout,
                "formatter": "structlog",
            },
        },
        "loggers": {
            "": {
                "handlers": ["default"],
                "level": log_level,
                "propagate": True,
            },
            service_name: {
                "handlers": ["default"],
                "level": log_level,
                "propagate": False,
            },
        },
    })


def get_logger(name: Optional[str] = None) -> structlog.stdlib.BoundLogger:
    """
    获取结构化日志记录器

    Args:
        name: 日志记录器名称

    Returns:
        structlog BoundLogger 实例
    """
    return structlog.get_logger(name)


class LogContext:
    """日志上下文管理器，用于添加请求级别的上下文信息"""

    def __init__(self, **kwargs: Any) -> None:
        self._context = kwargs

    def __enter__(self) -> "LogContext":
        structlog.contextvars.bind_contextvars(**self._context)
        return self

    def __exit__(self, *args: Any) -> None:
        structlog.contextvars.unbind_contextvars(*self._context.keys())
