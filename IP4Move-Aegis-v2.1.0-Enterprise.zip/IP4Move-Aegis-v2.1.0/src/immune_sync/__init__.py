"""
免疫同步模块 - 全网攻击特征广播与永久免疫

实现 "同类攻击一次捕获、全网永久免疫" 核心能力:
1. AttackFingerprint - 攻击指纹提取与结构化表示
2. ImmuneSyncProtocol - 基于 DHT 的攻击特征同步协议
3. ImmunityDatabase - 本地免疫数据库 (持久化存储)
4. GlobalImmunityCoordinator - 全网免疫协调器 (统一调度)
"""

from src.immune_sync.attack_fingerprint import AttackFingerprint, FingerprintType
from src.immune_sync.immune_sync_protocol import ImmuneSyncProtocol
from src.immune_sync.immunity_database import ImmunityDatabase
from src.immune_sync.global_immunity_coordinator import GlobalImmunityCoordinator

__all__ = [
    "AttackFingerprint",
    "FingerprintType",
    "ImmuneSyncProtocol",
    "ImmunityDatabase",
    "GlobalImmunityCoordinator",
]
