"""
免疫数据库 - 本地持久化存储攻击指纹

功能:
  1. 存储接收到的攻击指纹
  2. 查询匹配的攻击指纹
  3. 过期清理
  4. 统计报告
  5. 持久化到磁盘
"""

import os
import json
import time
import logging
import sqlite3
import threading
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import asdict
from pathlib import Path

from src.immune_sync.attack_fingerprint import AttackFingerprint, FingerprintType

logger = logging.getLogger(__name__)


class ImmunityDatabase:
    """
    免疫数据库

    使用 SQLite 作为后端存储, 提供高效的查询和索引能力。
    """

    # 默认数据库路径
    DEFAULT_DB_PATH = ".aegis_immunity.db"

    # 指纹过期时间 (秒)
    DEFAULT_TTL = 7 * 24 * 3600  # 7天

    def __init__(
        self,
        db_path: Optional[str] = None,
        ttl_seconds: int = DEFAULT_TTL,
        auto_cleanup: bool = True,
    ):
        """
        初始化免疫数据库

        Args:
            db_path: 数据库文件路径, None=使用默认路径
            ttl_seconds: 指纹过期时间
            auto_cleanup: 是否自动清理过期指纹
        """
        if db_path is None:
            db_path = self.DEFAULT_DB_PATH

        self._db_path = db_path
        self._ttl = ttl_seconds
        self._auto_cleanup = auto_cleanup

        # 内存缓存 (用于快速查询)
        self._cache: Dict[str, AttackFingerprint] = {}
        self._ip_index: Dict[str, Set[str]] = {}  # IP -> fingerprint_ids
        self._type_index: Dict[str, Set[str]] = {}  # type -> fingerprint_ids

        # 线程锁
        self._lock = threading.RLock()

        # 初始化数据库
        self._init_db()

        # 加载缓存 (内存数据库无需加载)
        if db_path != ':memory:':
            self._load_cache()

        logger.info(f"ImmunityDatabase 初始化完成 (path={db_path})")

    def _init_db(self) -> None:
        """初始化数据库表结构"""
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS fingerprints (
                    fingerprint_id TEXT PRIMARY KEY,
                    fingerprint_type TEXT NOT NULL,
                    source_ip TEXT NOT NULL,
                    source_port INTEGER,
                    target_ip TEXT,
                    target_port INTEGER,
                    node_id TEXT,
                    confidence REAL NOT NULL,
                    first_seen REAL NOT NULL,
                    last_seen REAL NOT NULL,
                    detection_count INTEGER NOT NULL,
                    source_node TEXT,
                    signature TEXT,
                    version INTEGER NOT NULL,
                    data TEXT NOT NULL
                )
            """)

            # 创建索引
            conn.execute("CREATE INDEX IF NOT EXISTS idx_source_ip ON fingerprints(source_ip)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_type ON fingerprints(fingerprint_type)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_last_seen ON fingerprints(last_seen)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_source_node ON fingerprints(source_node)")

            conn.commit()

    def _load_cache(self) -> None:
        """从数据库加载到内存缓存"""
        with self._lock:
            with sqlite3.connect(self._db_path) as conn:
                cursor = conn.execute(
                    "SELECT data FROM fingerprints WHERE last_seen > ?",
                    (time.time() - self._ttl,)
                )

                for row in cursor:
                    try:
                        data = json.loads(row[0])
                        fp = AttackFingerprint.from_dict(data)
                        self._add_to_cache(fp)
                    except Exception as e:
                        logger.warning(f"加载指纹缓存失败: {e}")

            logger.info(f"已加载 {len(self._cache)} 个指纹到缓存")

    def _add_to_cache(self, fp: AttackFingerprint) -> None:
        """添加指纹到缓存"""
        self._cache[fp.fingerprint_id] = fp

        # 更新索引
        if fp.source_ip not in self._ip_index:
            self._ip_index[fp.source_ip] = set()
        self._ip_index[fp.source_ip].add(fp.fingerprint_id)

        type_key = fp.fingerprint_type.value
        if type_key not in self._type_index:
            self._type_index[type_key] = set()
        self._type_index[type_key].add(fp.fingerprint_id)

    def _remove_from_cache(self, fp_id: str) -> None:
        """从缓存移除指纹"""
        if fp_id not in self._cache:
            return

        fp = self._cache[fp_id]

        # 更新索引
        if fp.source_ip in self._ip_index:
            self._ip_index[fp.source_ip].discard(fp_id)
            if not self._ip_index[fp.source_ip]:
                del self._ip_index[fp.source_ip]

        type_key = fp.fingerprint_type.value
        if type_key in self._type_index:
            self._type_index[type_key].discard(fp_id)
            if not self._type_index[type_key]:
                del self._type_index[type_key]

        del self._cache[fp_id]

    def store(self, fingerprint: AttackFingerprint) -> bool:
        """
        存储攻击指纹

        如果指纹已存在, 则更新。

        Returns:
            True if stored successfully
        """
        with self._lock:
            try:
                # 检查是否已存在相似指纹
                existing = self._find_similar(fingerprint)
                if existing:
                    existing.update(fingerprint)
                    fingerprint = existing

                # 签名
                fingerprint.sign()

                # 保存到数据库
                with sqlite3.connect(self._db_path) as conn:
                    conn.execute(
                        """
                        INSERT OR REPLACE INTO fingerprints
                        (fingerprint_id, fingerprint_type, source_ip, source_port,
                         target_ip, target_port, node_id, confidence, first_seen,
                         last_seen, detection_count, source_node, signature, version, data)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            fingerprint.fingerprint_id,
                            fingerprint.fingerprint_type.value,
                            fingerprint.source_ip,
                            fingerprint.source_port,
                            fingerprint.target_ip,
                            fingerprint.target_port,
                            fingerprint.node_id,
                            fingerprint.confidence,
                            fingerprint.first_seen,
                            fingerprint.last_seen,
                            fingerprint.detection_count,
                            fingerprint.source_node,
                            fingerprint.signature,
                            fingerprint.version,
                            fingerprint.to_json(),
                        )
                    )
                    conn.commit()

                # 更新缓存
                if fingerprint.fingerprint_id in self._cache:
                    self._remove_from_cache(fingerprint.fingerprint_id)
                self._add_to_cache(fingerprint)

                logger.debug(f"指纹已存储: {fingerprint.fingerprint_id}")
                return True

            except Exception as e:
                logger.error(f"存储指纹失败: {e}")
                return False

    def _find_similar(self, fingerprint: AttackFingerprint) -> Optional[AttackFingerprint]:
        """查找相似的已存在指纹"""
        # 使用 IP 索引快速筛选
        if fingerprint.source_ip in self._ip_index:
            for fp_id in self._ip_index[fingerprint.source_ip]:
                existing = self._cache.get(fp_id)
                if existing and existing.matches(fingerprint):
                    return existing
        return None

    def get(self, fingerprint_id: str) -> Optional[AttackFingerprint]:
        """根据 ID 获取指纹"""
        with self._lock:
            # 先查缓存
            if fingerprint_id in self._cache:
                return self._cache[fingerprint_id]

            # 查数据库
            try:
                with sqlite3.connect(self._db_path) as conn:
                    cursor = conn.execute(
                        "SELECT data FROM fingerprints WHERE fingerprint_id = ?",
                        (fingerprint_id,)
                    )
                    row = cursor.fetchone()
                    if row:
                        data = json.loads(row[0])
                        fp = AttackFingerprint.from_dict(data)
                        self._add_to_cache(fp)
                        return fp
            except Exception as e:
                logger.error(f"获取指纹失败: {e}")

            return None

    def query_by_ip(self, ip: str) -> List[AttackFingerprint]:
        """根据 IP 查询指纹"""
        with self._lock:
            result = []
            if ip in self._ip_index:
                for fp_id in self._ip_index[ip]:
                    fp = self._cache.get(fp_id)
                    if fp:
                        result.append(fp)
            return result

    def query_by_type(self, fp_type: FingerprintType) -> List[AttackFingerprint]:
        """根据类型查询指纹"""
        with self._lock:
            result = []
            type_key = fp_type.value
            if type_key in self._type_index:
                for fp_id in self._type_index[type_key]:
                    fp = self._cache.get(fp_id)
                    if fp:
                        result.append(fp)
            return result

    def is_known_attacker(self, ip: str, min_confidence: float = 0.5) -> bool:
        """
        检查 IP 是否为已知攻击者

        用于快速查询是否应拦截某 IP。
        """
        with self._lock:
            if ip not in self._ip_index:
                return False

            for fp_id in self._ip_index[ip]:
                fp = self._cache.get(fp_id)
                if fp and fp.confidence >= min_confidence:
                    return True
            return False

    def get_all_fingerprints(self, limit: int = 1000) -> List[AttackFingerprint]:
        """获取所有指纹"""
        with self._lock:
            return list(self._cache.values())[:limit]

    def cleanup_expired(self) -> int:
        """
        清理过期指纹

        Returns:
            清理的指纹数量
        """
        with self._lock:
            expired_ids = []
            cutoff = time.time() - self._ttl

            for fp_id, fp in self._cache.items():
                if fp.last_seen < cutoff:
                    expired_ids.append(fp_id)

            # 从缓存移除
            for fp_id in expired_ids:
                self._remove_from_cache(fp_id)

            # 从数据库删除
            try:
                with sqlite3.connect(self._db_path) as conn:
                    conn.execute(
                        "DELETE FROM fingerprints WHERE last_seen < ?",
                        (cutoff,)
                    )
                    conn.commit()
            except Exception as e:
                logger.error(f"清理过期指纹失败: {e}")

            if expired_ids:
                logger.info(f"已清理 {len(expired_ids)} 个过期指纹")

            return len(expired_ids)

    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self._lock:
            stats = {
                "total_fingerprints": len(self._cache),
                "by_type": {},
                "by_source_ip": len(self._ip_index),
                "avg_confidence": 0.0,
            }

            if self._cache:
                type_counts = {}
                total_confidence = 0.0

                for fp in self._cache.values():
                    type_key = fp.fingerprint_type.value
                    type_counts[type_key] = type_counts.get(type_key, 0) + 1
                    total_confidence += fp.confidence

                stats["by_type"] = type_counts
                stats["avg_confidence"] = round(total_confidence / len(self._cache), 4)

            return stats

    def export_to_file(self, filepath: str) -> bool:
        """导出所有指纹到 JSON 文件"""
        try:
            fingerprints = [fp.to_dict() for fp in self._cache.values()]
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(fingerprints, f, ensure_ascii=False, indent=2)
            logger.info(f"已导出 {len(fingerprints)} 个指纹到 {filepath}")
            return True
        except Exception as e:
            logger.error(f"导出指纹失败: {e}")
            return False

    def import_from_file(self, filepath: str) -> int:
        """从 JSON 文件导入指纹"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)

            count = 0
            for fp_data in data:
                try:
                    fp = AttackFingerprint.from_dict(fp_data)
                    if self.store(fp):
                        count += 1
                except Exception as e:
                    logger.warning(f"导入单个指纹失败: {e}")

            logger.info(f"已从 {filepath} 导入 {count} 个指纹")
            return count
        except Exception as e:
            logger.error(f"导入指纹失败: {e}")
            return 0

    def close(self) -> None:
        """关闭数据库"""
        with self._lock:
            if self._auto_cleanup:
                self.cleanup_expired()
            logger.info("ImmunityDatabase 已关闭")
