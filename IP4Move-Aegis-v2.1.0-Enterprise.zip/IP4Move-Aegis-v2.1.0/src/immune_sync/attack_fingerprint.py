"""
攻击指纹提取与结构化表示

攻击指纹是用于识别和分类攻击的特征集合, 包含:
- 攻击类型 (flood/tagging/replay/timing/traffic 等)
- 源标识 (IP/端口/节点ID)
- 目标标识
- 包特征 (大小/协议/哈希)
- 行为模式 (速率/时序)
- 时间戳和置信度
"""

import hashlib
import time
import json
from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from datetime import datetime


class FingerprintType(Enum):
    """指纹类型"""
    FLOOD = "flooding"           # 洪水攻击
    TAGGING = "tagging"          # 标记攻击
    REPLAY = "replay"            # 重放攻击
    TIMING = "timing"            # 时序攻击
    TRAFFIC = "traffic"          # 流量分析攻击
    STATISTICAL_ANOMALY = "statistical_anomaly"  # 统计异常
    ML_ANOMALY = "ml_anomaly"    # ML 检测异常
    UNKNOWN = "unknown"


@dataclass
class PacketFeatures:
    """数据包特征"""
    size: int
    protocol: int  # IPPROTO_TCP/UDP/ICMP
    src_port: Optional[int] = None
    dst_port: Optional[int] = None
    ttl: Optional[int] = None
    checksum: Optional[int] = None
    payload_hash: Optional[str] = None  # 前 N 字节的哈希


@dataclass
class BehaviorPattern:
    """行为模式特征"""
    packets_per_second: float
    bytes_per_second: float
    inter_arrival_variance: float
    size_variance: float
    duration_seconds: float


@dataclass
class AttackFingerprint:
    """
    攻击指纹 - 用于全网同步和免疫

    Attributes:
        fingerprint_id: 唯一指纹ID (UUID)
        fingerprint_type: 攻击类型
        source_ip: 攻击源IP
        source_port: 攻击源端口 (可选)
        target_ip: 目标IP
        target_port: 目标端口 (可选)
        node_id: 攻击源节点ID (如果是网络内部节点)
        packet_features: 包特征
        behavior_pattern: 行为模式
        confidence: 置信度 (0.0-1.0)
        first_seen: 首次发现时间戳
        last_seen: 最后发现时间戳
        detection_count: 检测次数
        source_node: 发现此指纹的节点ID
        signature: 指纹签名 (用于验证完整性)
        metadata: 额外元数据
    """

    # 核心标识
    fingerprint_id: str
    fingerprint_type: FingerprintType

    # 源/目标标识
    source_ip: str
    source_port: Optional[int] = None
    target_ip: Optional[str] = None
    target_port: Optional[int] = None
    node_id: Optional[str] = None

    # 特征
    packet_features: Optional[PacketFeatures] = None
    behavior_pattern: Optional[BehaviorPattern] = None

    # 元数据
    confidence: float = 0.8
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    detection_count: int = 1
    source_node: Optional[str] = None
    signature: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    # 版本控制
    version: int = 1

    def __post_init__(self):
        """初始化后处理"""
        if isinstance(self.fingerprint_type, str):
            self.fingerprint_type = FingerprintType(self.fingerprint_type)

    def update(self, new_detection: 'AttackFingerprint') -> None:
        """更新指纹 (合并新检测结果)"""
        self.last_seen = time.time()
        self.detection_count += 1

        # 更新置信度 (贝叶斯更新简化版)
        self.confidence = min(1.0, self.confidence + 0.05)

        # 合并行为模式 (取平均值)
        if new_detection.behavior_pattern and self.behavior_pattern:
            old = self.behavior_pattern
            new = new_detection.behavior_pattern
            n = self.detection_count

            self.behavior_pattern = BehaviorPattern(
                packets_per_second=(old.packets_per_second * (n-1) + new.packets_per_second) / n,
                bytes_per_second=(old.bytes_per_second * (n-1) + new.bytes_per_second) / n,
                inter_arrival_variance=(old.inter_arrival_variance * (n-1) + new.inter_arrival_variance) / n,
                size_variance=(old.size_variance * (n-1) + new.size_variance) / n,
                duration_seconds=max(old.duration_seconds, new.duration_seconds),
            )

    def is_expired(self, ttl_seconds: int = 86400) -> bool:
        """检查指纹是否过期"""
        return time.time() - self.last_seen > ttl_seconds

    def compute_hash(self) -> str:
        """计算指纹内容的哈希 (用于签名验证)"""
        data = f"{self.fingerprint_type.value}:{self.source_ip}:{self.source_port or 0}"
        if self.packet_features and self.packet_features.payload_hash:
            data += f":{self.packet_features.payload_hash}"
        return hashlib.sha256(data.encode()).hexdigest()[:32]

    def sign(self, private_key: Optional[str] = None) -> None:
        """签名指纹 (简化版, 实际应使用非对称加密)"""
        content_hash = self.compute_hash()
        timestamp = int(time.time())
        self.signature = f"{content_hash}:{timestamp}"

    def verify(self) -> bool:
        """验证指纹签名"""
        if not self.signature:
            return False
        expected = self.compute_hash()
        return self.signature.startswith(expected)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典 (用于序列化)"""
        result = asdict(self)
        result['fingerprint_type'] = self.fingerprint_type.value

        # 处理嵌套 dataclass
        if self.packet_features:
            result['packet_features'] = asdict(self.packet_features)
        if self.behavior_pattern:
            result['behavior_pattern'] = asdict(self.behavior_pattern)

        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AttackFingerprint':
        """从字典创建指纹"""
        # 处理枚举
        if 'fingerprint_type' in data:
            data['fingerprint_type'] = FingerprintType(data['fingerprint_type'])

        # 处理嵌套对象
        if 'packet_features' in data and data['packet_features']:
            data['packet_features'] = PacketFeatures(**data['packet_features'])
        if 'behavior_pattern' in data and data['behavior_pattern']:
            data['behavior_pattern'] = BehaviorPattern(**data['behavior_pattern'])

        return cls(**data)

    def to_json(self) -> str:
        """序列化为 JSON"""
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_json(cls, json_str: str) -> 'AttackFingerprint':
        """从 JSON 反序列化"""
        return cls.from_dict(json.loads(json_str))

    def matches(self, other: 'AttackFingerprint', threshold: float = 0.8) -> bool:
        """
        计算与另一个指纹的相似度

        用于去重和聚合相似攻击。
        """
        score = 0.0
        weights = 0.0

        # IP 匹配 (权重 0.4)
        if self.source_ip == other.source_ip:
            score += 0.4
        weights += 0.4

        # 类型匹配 (权重 0.3)
        if self.fingerprint_type == other.fingerprint_type:
            score += 0.3
        weights += 0.3

        # 端口匹配 (权重 0.2)
        if self.source_port and other.source_port:
            if self.source_port == other.source_port:
                score += 0.2
            weights += 0.2

        # 包特征匹配 (权重 0.1)
        if self.packet_features and other.packet_features:
            if self.packet_features.size == other.packet_features.size:
                score += 0.05
            if self.packet_features.protocol == other.packet_features.protocol:
                score += 0.05
            weights += 0.1

        return (score / weights) >= threshold if weights > 0 else False

    def __hash__(self) -> int:
        """用于集合操作"""
        return hash((self.fingerprint_id, self.source_ip))

    def __eq__(self, other: object) -> bool:
        """相等性判断"""
        if not isinstance(other, AttackFingerprint):
            return NotImplemented
        return self.fingerprint_id == other.fingerprint_id


class FingerprintExtractor:
    """攻击指纹提取器"""

    @staticmethod
    def from_xdp_event(event: Dict[str, Any], source_node: str) -> AttackFingerprint:
        """从 XDP 事件提取指纹"""
        import uuid

        fp_type = FingerprintType(event.get('type', 'unknown'))

        packet_features = PacketFeatures(
            size=event.get('pkt_size', 0),
            protocol=event.get('protocol', 0),
            src_port=event.get('src_port'),
            dst_port=event.get('dst_port'),
            payload_hash=str(event.get('feature_hash', '')) if event.get('feature_hash') else None,
        )

        return AttackFingerprint(
            fingerprint_id=str(uuid.uuid4()),
            fingerprint_type=fp_type,
            source_ip=event.get('src_ip', '0.0.0.0'),
            source_port=event.get('src_port'),
            target_ip=event.get('dst_ip'),
            target_port=event.get('dst_port'),
            packet_features=packet_features,
            confidence=0.9 if fp_type != FingerprintType.UNKNOWN else 0.5,
            first_seen=event.get('timestamp', time.time()),
            last_seen=event.get('timestamp', time.time()),
            source_node=source_node,
        )

    @staticmethod
    def from_attack_alert(alert: Any, source_node: str) -> AttackFingerprint:
        """从 AttackAlert 提取指纹"""
        import uuid
        from src.security.attack_detector import AttackType

        # 映射 AttackType 到 FingerprintType
        type_map = {
            AttackType.FLOODING: FingerprintType.FLOOD,
            AttackType.TAGGING: FingerprintType.TAGGING,
            AttackType.REPLAY: FingerprintType.REPLAY,
            AttackType.TIMING: FingerprintType.TIMING,
            AttackType.TRAFFIC: FingerprintType.TRAFFIC,
            AttackType.STATISTICAL_ANOMALY: FingerprintType.STATISTICAL_ANOMALY,
            AttackType.ML_ANOMALY: FingerprintType.ML_ANOMALY,
        }

        fp_type = type_map.get(alert.attack_type, FingerprintType.UNKNOWN)

        return AttackFingerprint(
            fingerprint_id=str(uuid.uuid4()),
            fingerprint_type=fp_type,
            source_ip=alert.source,
            confidence=alert.severity,
            first_seen=alert.timestamp,
            last_seen=alert.timestamp,
            source_node=source_node,
            metadata=alert.metadata if hasattr(alert, 'metadata') else {},
        )
