"""
全网免疫协调器 - 统一调度免疫同步和 XDP 拦截

实现完整的 "同类攻击一次捕获、全网永久免疫" 流程:
1. 接收攻击检测事件 (来自 XDP/attack_detector)
2. 提取攻击指纹
3. 存储到本地免疫数据库
4. 通过 DHT 同步到全网
5. 接收全网指纹, 更新 XDP 拦截规则
6. 统计和监控
"""

import time
import asyncio
import logging
from typing import Optional, Dict, List, Callable, Any
from dataclasses import dataclass, field

from src.immune_sync.attack_fingerprint import (
    AttackFingerprint,
    FingerprintType,
    FingerprintExtractor,
)
from src.immune_sync.immunity_database import ImmunityDatabase
from src.immune_sync.immune_sync_protocol import ImmuneSyncProtocol
from src.xdp_engine.xdp_controller import XDPController
from src.security.attack_detector import AttackDetector, AttackAlert

logger = logging.getLogger(__name__)


@dataclass
class ImmunityStats:
    """免疫统计"""
    local_fingerprints: int = 0
    synced_fingerprints: int = 0
    blocked_ips: int = 0
    last_update: float = 0.0


class GlobalImmunityCoordinator:
    """
    全网免疫协调器

    协调 XDP 拦截引擎、免疫数据库和 DHT 同步协议,
    实现完整的攻击检测-免疫闭环。
    """

    # 自动拦截阈值 (置信度)
    AUTO_BLOCK_THRESHOLD = 0.7

    # 定期同步间隔 (秒)
    SYNC_INTERVAL = 300  # 5分钟

    # 数据库清理间隔 (秒)
    CLEANUP_INTERVAL = 3600  # 1小时

    def __init__(
        self,
        node_id: str,
        xdp_controller: Optional[XDPController] = None,
        attack_detector: Optional[AttackDetector] = None,
        immunity_db: Optional[ImmunityDatabase] = None,
        sync_protocol: Optional[ImmuneSyncProtocol] = None,
        enable_auto_block: bool = True,
    ):
        """
        初始化协调器

        Args:
            node_id: 本节点ID
            xdp_controller: XDP 控制器 (用于内核态拦截)
            attack_detector: 攻击检测器 (用于用户态检测)
            immunity_db: 免疫数据库 (本地存储)
            sync_protocol: 同步协议 (DHT 网络)
            enable_auto_block: 是否自动封禁检测到的攻击源
        """
        self._node_id = node_id
        self._xdp = xdp_controller
        self._detector = attack_detector
        self._db = immunity_db or ImmunityDatabase()
        self._sync = sync_protocol
        self._enable_auto_block = enable_auto_block

        # 统计
        self._stats = ImmunityStats()

        # 运行状态
        self._running = False
        self._tasks: List[asyncio.Task] = []

        # 注册回调
        self._setup_callbacks()

        logger.info(f"GlobalImmunityCoordinator 初始化完成 (node={node_id})")

    def _setup_callbacks(self) -> None:
        """设置回调函数"""
        # 注册到 XDP 事件处理器 (如果存在)
        if self._xdp:
            # XDP 事件会通过 xdp_event_handler 传递
            pass

        # 注册到 attack_detector
        if self._detector:
            self._detector.on_alert(self._on_attack_alert)

        # 注册到同步协议
        if self._sync:
            self._sync.register_fingerprint_callback(self._on_remote_fingerprint)

    async def start(self) -> None:
        """启动协调器"""
        if self._running:
            return

        self._running = True

        # 启动同步协议
        if self._sync:
            await self._sync.start()

        # 启动后台任务
        self._tasks.append(asyncio.create_task(self._sync_loop()))
        self._tasks.append(asyncio.create_task(self._cleanup_loop()))

        logger.info("GlobalImmunityCoordinator 已启动")

    async def stop(self) -> None:
        """停止协调器"""
        if not self._running:
            return

        self._running = False

        # 取消后台任务
        for task in self._tasks:
            task.cancel()

        for task in self._tasks:
            try:
                await task
            except asyncio.CancelledError:
                pass

        # 停止同步协议
        if self._sync:
            await self._sync.stop()

        # 关闭数据库
        self._db.close()

        logger.info("GlobalImmunityCoordinator 已停止")

    # ============================================================
    # 攻击检测处理
    # ============================================================

    def _on_attack_alert(self, alert: AttackAlert) -> None:
        """
        处理 attack_detector 的警报

        这是 "一次捕获" 的入口点。
        """
        logger.info(f"收到攻击警报: {alert.attack_type.value} from {alert.source}")

        # 1. 提取指纹
        fingerprint = FingerprintExtractor.from_attack_alert(alert, self._node_id)

        # 2. 存储到本地数据库
        if self._db.store(fingerprint):
            self._stats.local_fingerprints += 1
            logger.info(f"攻击指纹已存储: {fingerprint.fingerprint_id}")

        # 3. 同步到全网
        if self._sync:
            asyncio.create_task(self._sync.announce_fingerprint(fingerprint))

        # 4. 自动封禁 (如果启用)
        if self._enable_auto_block and fingerprint.confidence >= self.AUTO_BLOCK_THRESHOLD:
            self._block_attacker(fingerprint)

    def _on_remote_fingerprint(self, fingerprint: AttackFingerprint) -> None:
        """
        处理从网络收到的攻击指纹

        这是 "全网永久免疫" 的实现。
        """
        logger.info(f"收到远程指纹: {fingerprint.fingerprint_id} from {fingerprint.source_node}")

        # 1. 存储到本地数据库
        if self._db.store(fingerprint):
            self._stats.synced_fingerprints += 1

        # 2. 更新 XDP 拦截规则 (自动获得免疫)
        if self._enable_auto_block and fingerprint.confidence >= self.AUTO_BLOCK_THRESHOLD:
            self._block_attacker(fingerprint)

    def _block_attacker(self, fingerprint: AttackFingerprint) -> None:
        """封禁攻击者"""
        if not self._xdp:
            return

        try:
            # 计算封禁时长 (基于置信度和攻击类型)
            base_duration = {
                FingerprintType.FLOOD: 3600,
                FingerprintType.TAGGING: 7200,
                FingerprintType.REPLAY: 1800,
                FingerprintType.TIMING: 3600,
                FingerprintType.TRAFFIC: 3600,
            }.get(fingerprint.fingerprint_type, 3600)

            # 根据置信度调整时长
            duration = int(base_duration * fingerprint.confidence)

            # 封禁 IP
            self._xdp.ban_ip(fingerprint.source_ip, duration=duration)
            self._stats.blocked_ips += 1

            logger.info(f"已封禁攻击者: {fingerprint.source_ip} (时长: {duration}s)")

        except Exception as e:
            logger.error(f"封禁攻击者失败: {e}")

    # ============================================================
    # 后台任务
    # ============================================================

    async def _sync_loop(self) -> None:
        """定期同步循环"""
        while self._running:
            try:
                await asyncio.sleep(self.SYNC_INTERVAL)

                if self._sync:
                    await self._sync.full_sync()

                self._stats.last_update = time.time()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"同步循环错误: {e}")

    async def _cleanup_loop(self) -> None:
        """定期清理循环"""
        while self._running:
            try:
                await asyncio.sleep(self.CLEANUP_INTERVAL)

                # 清理过期指纹
                cleaned = self._db.cleanup_expired()
                if cleaned > 0:
                    logger.info(f"已清理 {cleaned} 个过期指纹")

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"清理循环错误: {e}")

    # ============================================================
    # 公共 API
    # ============================================================

    def is_immune_to(self, ip: str) -> bool:
        """
        检查是否对某 IP 免疫

        用于快速决策是否接受来自某 IP 的连接。
        """
        return self._db.is_known_attacker(ip)

    def get_immunity_list(self) -> List[AttackFingerprint]:
        """获取当前免疫列表"""
        return self._db.get_all_fingerprints()

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        db_stats = self._db.get_statistics()
        sync_stats = self._sync.stats if self._sync else None

        return {
            "coordinator": {
                "local_fingerprints": self._stats.local_fingerprints,
                "synced_fingerprints": self._stats.synced_fingerprints,
                "blocked_ips": self._stats.blocked_ips,
                "last_update": self._stats.last_update,
            },
            "database": db_stats,
            "sync": {
                "fingerprints_sent": sync_stats.fingerprints_sent if sync_stats else 0,
                "fingerprints_received": sync_stats.fingerprints_received if sync_stats else 0,
            } if sync_stats else None,
        }

    async def manual_sync(self) -> int:
        """手动触发全网同步"""
        if self._sync:
            return await self._sync.full_sync()
        return 0

    def export_immunity_data(self, filepath: str) -> bool:
        """导出免疫数据"""
        return self._db.export_to_file(filepath)

    def import_immunity_data(self, filepath: str) -> int:
        """导入免疫数据"""
        return self._db.import_from_file(filepath)
