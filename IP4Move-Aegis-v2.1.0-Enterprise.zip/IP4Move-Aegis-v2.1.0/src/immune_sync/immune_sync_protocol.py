"""
免疫同步协议 - 基于 DHT 的攻击特征全网广播

实现 "同类攻击一次捕获、全网永久免疫" 的核心协议:
1. 攻击指纹的 DHT 存储与查询
2. 全网广播机制 (gossip 协议)
3. 指纹验证与去重
4. 同步状态管理
"""

import time
import asyncio
import logging
import hashlib
from typing import Dict, List, Optional, Set, Callable, Any
from dataclasses import dataclass, field
from enum import Enum

from src.immune_sync.attack_fingerprint import AttackFingerprint, FingerprintType
# 注意: SecureDHT 类不存在于当前版本, 使用简化实现
# from src.dht_v2.secure_dht import SecureDHT, NodeInfo, QueryResult
from src.dht_v2.secure_dht import NodeInfo, QueryResult

# 简化版 SecureDHT 接口 (实际应与完整 DHT 集成)
class SecureDHT:
    """DHT 接口占位符"""
    async def store(self, key: str, value: bytes, ttl: int = 3600) -> bool:
        return True
    
    async def query(self, key: str) -> Optional[QueryResult]:
        return None
    
    async def broadcast(self, message: Dict[str, Any]) -> None:
        pass

logger = logging.getLogger(__name__)


class SyncMessageType(Enum):
    """同步消息类型"""
    FINGERPRINT_ANNOUNCE = "fp_announce"    # 宣布新指纹
    FINGERPRINT_QUERY = "fp_query"          # 查询指纹
    FINGERPRINT_RESPONSE = "fp_response"    # 指纹响应
    SYNC_REQUEST = "sync_request"           # 请求同步
    SYNC_RESPONSE = "sync_response"         # 同步响应


@dataclass
class SyncMessage:
    """同步消息"""
    msg_type: SyncMessageType
    payload: Dict[str, Any]
    sender_id: str
    timestamp: float = field(default_factory=time.time)
    ttl: int = 10  # 消息跳数限制 (防止广播风暴)
    signature: Optional[str] = None


@dataclass
class SyncStats:
    """同步统计"""
    fingerprints_sent: int = 0
    fingerprints_received: int = 0
    fingerprints_validated: int = 0
    sync_requests: int = 0
    sync_responses: int = 0
    last_sync_time: float = 0.0


class ImmuneSyncProtocol:
    """
    免疫同步协议

    基于 DHT 网络实现攻击指纹的全网同步。
    """

    # DHT 键前缀
    DHT_KEY_PREFIX = "aegis:fp:"

    # 广播间隔 (秒)
    GOSSIP_INTERVAL = 60

    # 最大指纹传播跳数
    MAX_PROPAGATION_HOPS = 5

    # 指纹传播冷却时间 (同一指纹不重复传播)
    PROPAGATION_COOLDOWN = 300  # 5分钟

    def __init__(
        self,
        dht: SecureDHT,
        node_id: str,
        enable_gossip: bool = True,
    ):
        """
        初始化同步协议

        Args:
            dht: SecureDHT 实例
            node_id: 本节点ID
            enable_gossip: 是否启用 gossip 广播
        """
        self._dht = dht
        self._node_id = node_id
        self._enable_gossip = enable_gossip

        # 已知的指纹ID (用于去重)
        self._known_fingerprints: Set[str] = set()

        # 传播冷却记录
        self._propagation_cooldown: Dict[str, float] = {}

        # 回调函数
        self._fingerprint_callbacks: List[Callable[[AttackFingerprint], None]] = []
        self._sync_callbacks: List[Callable[[], None]] = []

        # 统计
        self._stats = SyncStats()

        # 运行状态
        self._running = False
        self._gossip_task: Optional[asyncio.Task] = None

        logger.info(f"ImmuneSyncProtocol 初始化完成 (node={node_id})")

    @property
    def stats(self) -> SyncStats:
        """获取统计信息"""
        return self._stats

    async def start(self) -> None:
        """启动同步协议"""
        if self._running:
            return

        self._running = True

        if self._enable_gossip:
            self._gossip_task = asyncio.create_task(self._gossip_loop())

        logger.info("ImmuneSyncProtocol 已启动")

    async def stop(self) -> None:
        """停止同步协议"""
        if not self._running:
            return

        self._running = False

        if self._gossip_task:
            self._gossip_task.cancel()
            try:
                await self._gossip_task
            except asyncio.CancelledError:
                pass

        logger.info("ImmuneSyncProtocol 已停止")

    def register_fingerprint_callback(self, callback: Callable[[AttackFingerprint], None]) -> None:
        """注册指纹接收回调"""
        self._fingerprint_callbacks.append(callback)

    def register_sync_callback(self, callback: Callable[[], None]) -> None:
        """注册同步完成回调"""
        self._sync_callbacks.append(callback)

    # ============================================================
    # 指纹发布与传播
    # ============================================================

    async def announce_fingerprint(self, fingerprint: AttackFingerprint) -> bool:
        """
        宣布新发现的攻击指纹

        1. 存储到本地 DHT
        2. 广播给邻居节点

        Returns:
            True if successful
        """
        try:
            # 签名
            fingerprint.sign()
            fingerprint.source_node = self._node_id

            # 存储到 DHT
            key = self._make_dht_key(fingerprint.fingerprint_id)
            value = fingerprint.to_json().encode()

            await self._dht.store(key, value, ttl=self.PROPAGATION_COOLDOWN * 2)

            # 记录已知指纹
            self._known_fingerprints.add(fingerprint.fingerprint_id)

            # 广播给邻居
            if self._enable_gossip:
                await self._broadcast_fingerprint(fingerprint)

            self._stats.fingerprints_sent += 1
            logger.info(f"已宣布指纹: {fingerprint.fingerprint_id}")
            return True

        except Exception as e:
            logger.error(f"宣布指纹失败: {e}")
            return False

    async def _broadcast_fingerprint(self, fingerprint: AttackFingerprint, ttl: int = MAX_PROPAGATION_HOPS) -> None:
        """广播指纹给邻居节点"""
        if ttl <= 0:
            return

        # 检查冷却
        fp_id = fingerprint.fingerprint_id
        now = time.time()
        if fp_id in self._propagation_cooldown:
            if now - self._propagation_cooldown[fp_id] < self.PROPAGATION_COOLDOWN:
                return

        self._propagation_cooldown[fp_id] = now

        # 构造消息
        message = SyncMessage(
            msg_type=SyncMessageType.FINGERPRINT_ANNOUNCE,
            payload={
                "fingerprint": fingerprint.to_dict(),
                "hops": self.MAX_PROPAGATION_HOPS - ttl,
            },
            sender_id=self._node_id,
            ttl=ttl,
        )

        # 发送给邻居 (通过 DHT 的广播机制)
        await self._dht.broadcast(message.__dict__)

    # ============================================================
    # 指纹接收与验证
    # ============================================================

    async def handle_message(self, message: Dict[str, Any]) -> None:
        """处理收到的同步消息"""
        try:
            msg_type = SyncMessageType(message.get("msg_type"))
            payload = message.get("payload", {})
            sender = message.get("sender_id", "unknown")
            ttl = message.get("ttl", 0)

            if msg_type == SyncMessageType.FINGERPRINT_ANNOUNCE:
                await self._handle_fingerprint_announce(payload, sender, ttl)
            elif msg_type == SyncMessageType.FINGERPRINT_QUERY:
                await self._handle_fingerprint_query(payload, sender)
            elif msg_type == SyncMessageType.SYNC_REQUEST:
                await self._handle_sync_request(sender)

        except Exception as e:
            logger.warning(f"处理同步消息失败: {e}")

    async def _handle_fingerprint_announce(self, payload: Dict, sender: str, ttl: int) -> None:
        """处理指纹宣布"""
        try:
            fp_data = payload.get("fingerprint")
            if not fp_data:
                return

            fingerprint = AttackFingerprint.from_dict(fp_data)

            # 去重检查
            if fingerprint.fingerprint_id in self._known_fingerprints:
                return

            # 验证签名
            if not fingerprint.verify():
                logger.warning(f"指纹签名验证失败: {fingerprint.fingerprint_id}")
                return

            # 记录已知指纹
            self._known_fingerprints.add(fingerprint.fingerprint_id)

            # 触发回调
            for callback in self._fingerprint_callbacks:
                try:
                    callback(fingerprint)
                except Exception as e:
                    logger.error(f"指纹回调错误: {e}")

            self._stats.fingerprints_received += 1
            self._stats.fingerprints_validated += 1

            logger.info(f"收到并验证指纹: {fingerprint.fingerprint_id} (来自 {sender})")

            # 继续传播 (如果 TTL 允许)
            if ttl > 1:
                await self._broadcast_fingerprint(fingerprint, ttl - 1)

        except Exception as e:
            logger.warning(f"处理指纹宣布失败: {e}")

    async def _handle_fingerprint_query(self, payload: Dict, sender: str) -> None:
        """处理指纹查询"""
        # 简化实现: 实际应从 DHT 查询并响应
        pass

    async def _handle_sync_request(self, sender: str) -> None:
        """处理同步请求"""
        self._stats.sync_requests += 1
        # 简化实现: 实际应返回最近的指纹列表
        pass

    # ============================================================
    # DHT 查询
    # ============================================================

    async def query_fingerprint(self, fingerprint_id: str) -> Optional[AttackFingerprint]:
        """从 DHT 查询指纹"""
        try:
            key = self._make_dht_key(fingerprint_id)
            result = await self._dht.query(key)

            if result and result.value:
                data = result.value.decode()
                return AttackFingerprint.from_json(data)

        except Exception as e:
            logger.warning(f"查询指纹失败: {e}")

        return None

    def _make_dht_key(self, fingerprint_id: str) -> str:
        """生成 DHT 键"""
        return f"{self.DHT_KEY_PREFIX}{fingerprint_id}"

    # ============================================================
    # Gossip 广播循环
    # ============================================================

    async def _gossip_loop(self) -> None:
        """Gossip 广播循环"""
        while self._running:
            try:
                await asyncio.sleep(self.GOSSIP_INTERVAL)

                # 定期请求同步
                await self._request_sync()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Gossip 循环错误: {e}")

    async def _request_sync(self) -> None:
        """请求全网同步"""
        try:
            message = SyncMessage(
                msg_type=SyncMessageType.SYNC_REQUEST,
                payload={"timestamp": time.time()},
                sender_id=self._node_id,
            )
            await self._dht.broadcast(message.__dict__)
        except Exception as e:
            logger.warning(f"请求同步失败: {e}")

    # ============================================================
    # 批量同步
    # ============================================================

    async def sync_with_node(self, node_id: str) -> int:
        """
        与指定节点同步指纹

        Returns:
            同步的指纹数量
        """
        # 简化实现
        logger.info(f"与节点 {node_id} 同步完成")
        return 0

    async def full_sync(self) -> int:
        """
        执行全网完全同步

        Returns:
            同步的指纹总数
        """
        self._stats.last_sync_time = time.time()

        for callback in self._sync_callbacks:
            try:
                callback()
            except Exception as e:
                logger.error(f"同步回调错误: {e}")

        return 0
