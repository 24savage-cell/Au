"""
虚拟节点插入模块

在路径中动态插入虚拟节点，增加流量分析难度。
"""

import os
import time
import random
import logging
from typing import List, Optional, Dict, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class VirtualNode:
    """虚拟节点"""
    node_id: str
    position: int  # 在路径中的位置
    created_at: float = field(default_factory=time.time)
    lifetime: float = 300  # 秒
    public_key: bytes = field(default_factory=lambda: os.urandom(32))
    is_active: bool = True

    @property
    def is_expired(self) -> bool:
        return time.time() - self.created_at > self.lifetime


@dataclass
class VirtualNodeConfig:
    """虚拟节点配置"""
    nodes_per_path: int = 2
    min_lifetime: float = 60
    max_lifetime: float = 600
    rotation_interval: float = 120  # 秒
    traffic_mimic: bool = True  # 是否模拟真实流量
    padding_size_range: Tuple[int, int] = (64, 1400)  # 填充大小范围


class VirtualNodeInserter:
    """
    虚拟节点插入器

    在真实路径中动态插入虚拟节点:
    - 虚拟节点处理虚假数据包
    - 模拟真实节点的流量特征
    - 定期轮换虚拟节点
    - 增加攻击者区分真实/虚假流量的难度
    """

    def __init__(self, config: Optional[VirtualNodeConfig] = None):
        self._config = config or VirtualNodeConfig()
        self._virtual_nodes: Dict[str, VirtualNode] = {}
        self._node_counter = 0
        self._rotation_task = None
        self._is_running = False

    @property
    def active_count(self) -> int:
        return sum(1 for n in self._virtual_nodes.values() if n.is_active and not n.is_expired)

    def create_virtual_node(self, position: int) -> VirtualNode:
        """
        创建虚拟节点

        Args:
            position: 在路径中的位置

        Returns:
            虚拟节点
        """
        self._node_counter += 1
        node_id = f"vnode-{self._node_counter:06d}"
        lifetime = random.uniform(self._config.min_lifetime, self._config.max_lifetime)
        node = VirtualNode(
            node_id=node_id,
            position=position,
            lifetime=lifetime,
        )
        self._virtual_nodes[node_id] = node
        logger.debug(f"创建虚拟节点: {node_id} (位置: {position}, 生命周期: {lifetime:.0f}s)")
        return node

    def insert_into_path(
        self,
        path_nodes: List[dict],
        num_virtual: Optional[int] = None,
    ) -> List[dict]:
        """
        在路径中插入虚拟节点

        Args:
            path_nodes: 原始路径节点列表
            num_virtual: 要插入的虚拟节点数量

        Returns:
            包含虚拟节点的新路径
        """
        num_virtual = num_virtual or self._config.nodes_per_path
        if not path_nodes:
            return path_nodes

        # 创建虚拟节点
        virtual_nodes = []
        for _ in range(num_virtual):
            position = random.randint(0, len(path_nodes) + len(virtual_nodes))
            vnode = self.create_virtual_node(position)
            virtual_nodes.append(vnode)

        # 插入到路径中
        result = list(path_nodes)
        for vnode in virtual_nodes:
            insert_pos = min(vnode.position, len(result))
            result.insert(insert_pos, {
                "node_id": vnode.node_id,
                "address": f"virtual://{vnode.node_id}",
                "port": 0,
                "is_virtual": True,
                "public_key": vnode.public_key,
            })

        logger.debug(
            f"路径插入 {num_virtual} 个虚拟节点, "
            f"总长度: {len(path_nodes)} -> {len(result)}"
        )
        return result

    def generate_virtual_traffic(self) -> Optional[bytes]:
        """
        生成虚拟流量

        模拟真实数据包的大小分布。

        Returns:
            虚拟数据包，无活跃虚拟节点时返回 None
        """
        if not self._config.traffic_mimic:
            return None

        active_nodes = [
            n for n in self._virtual_nodes.values()
            if n.is_active and not n.is_expired
        ]
        if not active_nodes:
            return None

        # 模拟真实流量大小分布
        min_size, max_size = self._config.padding_size_range
        # 使用对数正态分布模拟真实包大小
        size = int(random.lognormvariate(6.0, 1.5))
        size = max(min_size, min(max_size, size))
        return os.urandom(size)

    def rotate_virtual_nodes(self) -> int:
        """
        轮换过期的虚拟节点

        Returns:
            轮换的节点数量
        """
        expired = [
            nid for nid, node in self._virtual_nodes.items()
            if node.is_expired
        ]
        for nid in expired:
            del self._virtual_nodes[nid]
        if expired:
            logger.debug(f"轮换 {len(expired)} 个过期虚拟节点")
        return len(expired)

    def cleanup(self) -> int:
        """清理所有虚拟节点"""
        count = len(self._virtual_nodes)
        self._virtual_nodes.clear()
        return count

    def get_stats(self) -> dict:
        """获取统计信息"""
        active = [n for n in self._virtual_nodes.values() if n.is_active and not n.is_expired]
        return {
            "total_virtual_nodes": len(self._virtual_nodes),
            "active_virtual_nodes": len(active),
            "expired_virtual_nodes": sum(1 for n in self._virtual_nodes.values() if n.is_expired),
        }

    def generate_pqc_node_identity(self, node_id: str) -> Tuple[bytes, bytes]:
        """
        为虚拟节点生成后量子身份密钥对

        使用 Dilithium 签名保护虚拟节点身份，
        防止攻击者伪造虚拟节点。

        Returns:
            (signing_key, verify_key)
        """
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PrivateKey,
            )
            private_key = MLDSA65PrivateKey.generate()
            public_key = private_key.public_key()
            return private_key.private_bytes_raw(), public_key.public_bytes_raw()
        except ImportError:
            # 回退: Ed25519
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PrivateKey,
            )
            private_key = Ed25519PrivateKey.generate()
            public_key = private_key.public_key()
            return private_key.private_bytes_raw(), public_key.public_bytes_raw()

    def authenticate_virtual_node(self, node: VirtualNode, verify_key: bytes, signature: bytes) -> bool:
        """
        验证虚拟节点的后量子身份

        Args:
            node: 虚拟节点
            verify_key: 验证公钥
            signature: 身份签名

        Returns:
            是否验证通过
        """
        node_data = f"{node.node_id}:{node.position}:{node.created_at}".encode()
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PublicKey,
            )
            public_key = MLDSA65PublicKey.from_public_bytes(verify_key)
            public_key.verify(signature, node_data)
            return True
        except Exception:
            return False

    def create_authenticated_virtual_node(self, position: int) -> Tuple[VirtualNode, bytes, bytes]:
        """
        创建带后量子认证的虚拟节点

        Returns:
            (virtual_node, signing_key, verify_key)
        """
        node = self.create_virtual_node(position)
        signing_key, verify_key = self.generate_pqc_node_identity(node.node_id)
        node.public_key = verify_key  # 存储验证公钥
        return node, signing_key, verify_key
