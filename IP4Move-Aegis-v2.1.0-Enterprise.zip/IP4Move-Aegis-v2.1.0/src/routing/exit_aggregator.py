"""
出口聚合模块 (安全修复版)

修复内容:
1. 添加分片认证防止伪造
2. 添加分片完整性验证
3. 防止重放攻击
4. 添加时间戳验证
"""

import os
import math
import random
import time
import hmac
import hashlib
import logging
from typing import List, Optional, Tuple, Dict
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# 安全常量
MAX_SHARD_SIZE = 1024 * 1024  # 最大分片大小 1MB
MAX_TOTAL_SHARDS = 100       # 最大分片总数
SHARD_EXPIRY = 300           # 分片有效期(秒)
HMAC_KEY_SIZE = 32           # HMAC密钥大小


@dataclass
class Shard:
    """数据分片 (带认证)"""
    shard_id: int
    data: bytes
    total_shards: int
    parity_shards: int = 0
    # 安全字段
    timestamp: float = 0.0
    message_id: bytes = b""
    hmac: bytes = b""

    def __post_init__(self):
        if self.timestamp == 0.0:
            self.timestamp = time.time()
        if not self.message_id:
            self.message_id = os.urandom(16)

    def serialize(self) -> bytes:
        """序列化分片"""
        header = self.shard_id.to_bytes(2, "big")
        header += self.total_shards.to_bytes(2, "big")
        header += self.parity_shards.to_bytes(2, "big")
        header += len(self.data).to_bytes(4, "big")
        header += int(self.timestamp).to_bytes(8, "big")
        header += self.message_id[:16]
        header += self.hmac[:32] if self.hmac else b"\x00" * 32
        return header + self.data

    @classmethod
    def deserialize(cls, data: bytes) -> "Shard":
        """反序列化分片"""
        if len(data) < 66:  # 最小头部大小
            raise ValueError("Shard data too small")
        
        shard_id = int.from_bytes(data[:2], "big")
        total_shards = int.from_bytes(data[2:4], "big")
        parity_shards = int.from_bytes(data[4:6], "big")
        data_len = int.from_bytes(data[6:10], "big")
        timestamp = float(int.from_bytes(data[10:18], "big"))
        message_id = data[18:34]
        hmac_sig = data[34:66]
        shard_data = data[66:66 + data_len]
        
        return cls(
            shard_id=shard_id,
            data=shard_data,
            total_shards=total_shards,
            parity_shards=parity_shards,
            timestamp=timestamp,
            message_id=message_id,
            hmac=hmac_sig,
        )


class SecureExitAggregator:
    """
    安全出口聚合器
    
    安全增强:
    - 分片HMAC认证
    - 时间戳验证
    - 重放保护
    - 大小限制
    """

    def __init__(
        self,
        num_shards: int = 4,
        parity_shards: int = 2,
        hmac_key: Optional[bytes] = None,
        enable_replay_check: bool = True,
    ):
        if num_shards > MAX_TOTAL_SHARDS:
            raise ValueError(f"Too many shards: {num_shards} > {MAX_TOTAL_SHARDS}")
        
        self._num_shards = num_shards
        self._parity_shards = parity_shards
        self._hmac_key = hmac_key or os.urandom(HMAC_KEY_SIZE)
        self._processed_shards: Dict[bytes, float] = {}  # message_id -> timestamp
        self._enable_replay_check = enable_replay_check

    @property
    def total_shards(self) -> int:
        return self._num_shards + self._parity_shards

    def _compute_hmac(self, shard: Shard) -> bytes:
        """计算分片HMAC"""
        data = (
            shard.shard_id.to_bytes(2, "big") +
            shard.total_shards.to_bytes(2, "big") +
            shard.parity_shards.to_bytes(2, "big") +
            shard.data +
            int(shard.timestamp).to_bytes(8, "big") +
            shard.message_id
        )
        return hmac.new(self._hmac_key, data, hashlib.sha256).digest()[:32]

    def _verify_hmac(self, shard: Shard) -> bool:
        """验证分片HMAC"""
        # 兼容没有HMAC的旧分片
        if not shard.hmac or len(shard.hmac) == 0:
            return True  # 旧格式分片，跳过HMAC验证
        if len(shard.hmac) != 32:
            return False
        expected = self._compute_hmac(shard)
        return hmac.compare_digest(shard.hmac, expected)

    def _check_replay(self, message_id: bytes, shard_id: int = 0) -> bool:
        """检查重放"""
        if not message_id:
            return True  # 旧格式分片，跳过重放检查
        replay_key = message_id + shard_id.to_bytes(4, "big")
        now = time.time()
        # 清理过期记录
        expired = [k for k, t in self._processed_shards.items() if now - t > SHARD_EXPIRY]
        for k in expired:
            del self._processed_shards[k]

        if replay_key in self._processed_shards:
            return False  # 重放

        self._processed_shards[replay_key] = now
        return True

    def _validate_timestamp(self, shard: Shard) -> bool:
        """验证时间戳"""
        now = time.time()
        return abs(now - shard.timestamp) < SHARD_EXPIRY

    def split(self, data: bytes, message_id: Optional[bytes] = None) -> List[Shard]:
        """
        将数据分成多个带认证的分片
        
        安全增强:
        - 大小限制
        - HMAC签名
        """
        if not data:
            return []
        
        if len(data) > MAX_SHARD_SIZE * self._num_shards:
            raise ValueError(f"Data too large: {len(data)} bytes")
        
        message_id = message_id or os.urandom(16)
        shard_size = math.ceil(len(data) / self._num_shards)

        # 分割数据
        data_shards = []
        for i in range(self._num_shards):
            start = i * shard_size
            end = min(start + shard_size, len(data))
            shard_data = data[start:end]
            if len(shard_data) < shard_size:
                shard_data += b"\x00" * (shard_size - len(shard_data))
            data_shards.append(shard_data)

        # 生成 XOR 奇偶校验分片
        parity_shards = []
        for p in range(self._parity_shards):
            parity = bytearray(shard_size)
            for i, ds in enumerate(data_shards):
                if (i + p) % self._num_shards == 0:
                    parity = bytearray(a ^ b for a, b in zip(parity, ds))
                else:
                    coeff = (i + 1) * (p + 1)
                    for j in range(shard_size):
                        parity[j] ^= (ds[j] * coeff) & 0xFF
            parity_shards.append(bytes(parity))

        # 创建带认证的分片
        shards = []
        timestamp = time.time()
        
        for i, ds in enumerate(data_shards):
            shard = Shard(
                shard_id=i,
                data=ds,
                total_shards=self.total_shards,
                parity_shards=self._parity_shards,
                timestamp=timestamp,
                message_id=message_id,
            )
            shard.hmac = self._compute_hmac(shard)
            shards.append(shard)
            
        for i, ps in enumerate(parity_shards):
            shard = Shard(
                shard_id=self._num_shards + i,
                data=ps,
                total_shards=self.total_shards,
                parity_shards=self._parity_shards,
                timestamp=timestamp,
                message_id=message_id,
            )
            shard.hmac = self._compute_hmac(shard)
            shards.append(shard)

        # 随机打乱分片顺序
        random.shuffle(shards)

        logger.debug(f"数据分片完成: {len(shards)} 个带认证分片")
        return shards

    def reassemble(self, shards: List[Shard]) -> bytes:
        """
        从带认证的分片重建数据
        
        安全增强:
        - HMAC验证
        - 时间戳验证
        - 重放保护
        """
        if not shards:
            return b""

        # 验证所有分片
        for shard in shards:
            # 验证大小
            if len(shard.data) > MAX_SHARD_SIZE:
                raise ValueError(f"Shard {shard.shard_id} too large")
            
            # 验证时间戳
            if not self._validate_timestamp(shard):
                raise ValueError(f"Shard {shard.shard_id} timestamp invalid")
            
            # 验证HMAC
            if not self._verify_hmac(shard):
                raise ValueError(f"Shard {shard.shard_id} HMAC verification failed")
            
            # 验证重放 (仅在启用时)
            if self._enable_replay_check and not self._check_replay(shard.message_id, shard.shard_id):
                raise ValueError(f"Shard {shard.shard_id} replay detected")

        # 按 shard_id 排序
        sorted_shards = sorted(shards, key=lambda s: s.shard_id)

        # 提取数据分片
        data_shards = []
        for shard in sorted_shards:
            if shard.shard_id < self._num_shards:
                data_shards.append(shard.data)

        if len(data_shards) < self._num_shards:
            data_shards = self._recover_with_parity(sorted_shards)

        if len(data_shards) < self._num_shards:
            raise ValueError(
                f"无法重建数据: 需要 {self._num_shards} 个分片, "
                f"只有 {len(data_shards)} 个"
            )

        # 拼接数据
        result = b"".join(data_shards)
        result = result.rstrip(b"\x00")
        return result

    def _recover_with_parity(self, shards: List[Shard]) -> List[bytes]:
        """使用奇偶校验分片恢复缺失的数据分片"""
        available = {s.shard_id: s.data for s in shards}
        recovered = []

        for i in range(self._num_shards):
            if i in available:
                recovered.append(available[i])

        missing = [i for i in range(self._num_shards) if i not in available]
        if missing and self._parity_shards > 0:
            all_data = list(available.values())
            if len(all_data) >= self._num_shards:
                for idx in missing:
                    recovered_data = bytearray(len(all_data[0]))
                    for i, shard_id in enumerate(sorted(available.keys())):
                        if shard_id != idx:
                            for j in range(len(recovered_data)):
                                recovered_data[j] ^= available[shard_id][j]
                    recovered.insert(idx, bytes(recovered_data))

        return recovered

    def assign_to_exits(
        self, shards: List[Shard], exit_nodes: List[str]
    ) -> dict:
        """将分片分配到出口节点"""
        if len(exit_nodes) < self._num_shards:
            raise ValueError(
                f"出口节点不足: 需要 {self._num_shards} 个, "
                f"只有 {len(exit_nodes)} 个"
            )

        assignment = {}
        for i, shard in enumerate(shards):
            exit_node = exit_nodes[i % len(exit_nodes)]
            assignment[exit_node] = shard

        return assignment

    def verify_shard(self, shard: Shard) -> bool:
        """公开验证分片方法"""
        return self._verify_hmac(shard) and self._validate_timestamp(shard)


# 向后兼容
ExitAggregator = SecureExitAggregator
