"""
路径构建模块

实现 3真7假路径构建策略，提高匿名性。
"""

import random
import time
import logging
from typing import List, Optional, Dict, Set
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class PathNode:
    """路径节点"""
    node_id: str
    address: str
    port: int
    is_decoy: bool = False
    public_key: Optional[bytes] = None
    latency_ms: float = 0.0
    weight: float = 1.0


@dataclass
class Path:
    """通信路径"""
    path_id: str
    nodes: List[PathNode]
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0
    is_active: bool = True
    bytes_sent: int = 0
    bytes_received: int = 0

    @property
    def real_nodes(self) -> List[PathNode]:
        return [n for n in self.nodes if not n.is_decoy]

    @property
    def decoy_nodes(self) -> List[PathNode]:
        return [n for n in self.nodes if n.is_decoy]

    @property
    def length(self) -> int:
        return len(self.nodes)


@dataclass
class PathBuilderConfig:
    """路径构建配置"""
    real_hops: int = 3
    decoy_hops: int = 7
    total_paths: int = 5
    path_refresh_interval: float = 300  # 秒
    virtual_nodes_per_path: int = 2
    max_path_age: float = 1800  # 秒
    avoid_reuse_window: float = 3600  # 秒


class PathBuilder:
    """
    路径构建器

    实现 3真7假路径构建策略:
    - 每条路径包含 3 个真实中继节点和 7 个诱饵节点
    - 同时构建多条并行路径
    - 诱饵节点发送虚假流量，增加流量分析难度
    - 避免短时间内重复使用同一节点
    """

    def __init__(self, config: Optional[PathBuilderConfig] = None):
        self._config = config or PathBuilderConfig()
        self._active_paths: Dict[str, Path] = {}
        self._node_history: Dict[str, float] = {}  # node_id -> last_used_time
        self._path_counter = 0
        self._lock = __import__("asyncio").Lock()

    @property
    def active_path_count(self) -> int:
        return len(self._active_paths)

    async def build_path(
        self,
        available_nodes: List[PathNode],
        exclude_nodes: Optional[Set[str]] = None,
    ) -> Path:
        """
        构建一条路径

        Args:
            available_nodes: 可用节点列表
            exclude_nodes: 排除的节点ID集合

        Returns:
            构建的路径
        """
        exclude = exclude_nodes or set()
        # 添加最近使用过的节点到排除列表
        now = time.time()
        recent_excludes = {
            nid for nid, last_used in self._node_history.items()
            if now - last_used < self._config.avoid_reuse_window
        }
        exclude = exclude | recent_excludes

        candidates = [n for n in available_nodes if n.node_id not in exclude]
        if len(candidates) < self._config.real_hops:
            raise ValueError(
                f"可用节点不足: 需要 {self._config.real_hops} 个, "
                f"实际 {len(candidates)} 个"
            )

        # 选择真实节点 (加权随机)
        real_nodes = self._select_nodes(
            candidates, self._config.real_hops, allow_decoy=False
        )

        # 选择诱饵节点 (排除真实节点)
        real_ids = {n.node_id for n in real_nodes}
        decoy_candidates = [n for n in available_nodes if n.node_id not in exclude and n.node_id not in real_ids]
        decoy_nodes = self._select_nodes(
            decoy_candidates, self._config.decoy_hops, allow_decoy=True
        )

        # 构建路径: 真实节点和诱饵节点交错排列
        all_nodes = self._interleave_nodes(real_nodes, decoy_nodes)

        # 创建路径
        self._path_counter += 1
        path_id = f"path-{self._path_counter:06d}"
        path = Path(
            path_id=path_id,
            nodes=all_nodes,
            created_at=now,
            expires_at=now + self._config.max_path_age,
        )

        # 记录节点使用历史
        for node in real_nodes:
            self._node_history[node.node_id] = now

        async with self._lock:
            self._active_paths[path_id] = path

        logger.info(
            f"路径 {path_id} 构建: {len(real_nodes)} 真实 + "
            f"{len(decoy_nodes)} 诱饵 = {len(all_nodes)} 总跳数"
        )
        return path

    async def build_multiple_paths(
        self,
        available_nodes: List[PathNode],
    ) -> List[Path]:
        """构建多条并行路径"""
        paths = []
        used_nodes: Set[str] = set()
        for _ in range(self._config.total_paths):
            try:
                path = await self.build_path(available_nodes, used_nodes)
                paths.append(path)
                # 路径间共享诱饵节点，但不共享真实节点
                for node in path.real_nodes:
                    used_nodes.add(node.node_id)
            except ValueError as e:
                logger.warning(f"路径构建失败: {e}")
                break
        return paths

    def _select_nodes(
        self,
        candidates: List[PathNode],
        count: int,
        allow_decoy: bool = False,
    ) -> List[PathNode]:
        """加权随机选择节点"""
        if len(candidates) <= count:
            selected = list(candidates)
        else:
            # 使用 random.sample 确保不重复
            selected = random.sample(candidates, count)

        # 标记诱饵节点
        if allow_decoy:
            for node in selected:
                node.is_decoy = True

        return selected[:count]

    def _interleave_nodes(
        self, real_nodes: List[PathNode], decoy_nodes: List[PathNode]
    ) -> List[PathNode]:
        """
        交错排列真实节点和诱饵节点

        确保真实节点均匀分布在路径中，不连续。
        """
        result = []
        real_idx = 0
        decoy_idx = 0
        total = len(real_nodes) + len(decoy_nodes)

        for i in range(total):
            # 每隔一定间隔插入一个真实节点
            interval = max(1, total // len(real_nodes))
            if real_idx < len(real_nodes) and (i % interval == 0 or decoy_idx >= len(decoy_nodes)):
                result.append(real_nodes[real_idx])
                real_idx += 1
            elif decoy_idx < len(decoy_nodes):
                result.append(decoy_nodes[decoy_idx])
                decoy_idx += 1
            else:
                result.append(real_nodes[real_idx])
                real_idx += 1

        return result

    async def refresh_path(self, path_id: str, available_nodes: List[PathNode]) -> Optional[Path]:
        """刷新指定路径"""
        async with self._lock:
            if path_id in self._active_paths:
                del self._active_paths[path_id]
        try:
            return await self.build_path(available_nodes)
        except ValueError:
            return None

    async def cleanup_expired(self) -> int:
        """清理过期路径"""
        now = time.time()
        expired = [
            pid for pid, path in self._active_paths.items()
            if path.expires_at <= now
        ]
        async with self._lock:
            for pid in expired:
                del self._active_paths[pid]
        if expired:
            logger.info(f"清理 {len(expired)} 条过期路径")
        return len(expired)

    def get_path(self, path_id: str) -> Optional[Path]:
        """获取路径"""
        return self._active_paths.get(path_id)

    def get_all_paths(self) -> List[Path]:
        """获取所有活跃路径"""
        return list(self._active_paths.values())

    async def build_entropy_independent_paths(
        self,
        available_nodes: List[PathNode],
    ) -> List[Path]:
        """
        构建熵独立的路径集

        真实路径和诱饵路径使用完全独立的随机熵源，
        使AI无法通过统计关联区分真实和诱饵流量。

        策略:
        1. 真实路径使用密码学安全随机数 (secrets)
        2. 诱饵路径使用独立的高质量随机数
        3. 路径间节点完全不重叠
        4. 诱饵路径的流量特征与真实路径统计不可区分
        """
        import secrets

        paths = []
        used_nodes: set = set()

        # 构建真实路径 (使用 secrets 模块)
        real_paths = []
        for _ in range(self._config.total_paths):
            try:
                # 使用密码学安全随机数选择节点
                available = [n for n in available_nodes if n.node_id not in used_nodes]
                if len(available) < self._config.real_hops:
                    break
                # secrets.choice 提供密码学安全随机性
                real_nodes = []
                temp_available = list(available)
                for _ in range(self._config.real_hops):
                    idx = secrets.randbelow(len(temp_available))
                    node = temp_available.pop(idx)
                    real_nodes.append(node)
                    used_nodes.add(node.node_id)

                # 构建诱饵路径 (独立熵源)
                decoy_available = [n for n in available_nodes if n.node_id not in used_nodes]
                decoy_nodes = []
                temp_decoy = list(decoy_available)
                for _ in range(self._config.decoy_hops):
                    if not temp_decoy:
                        # 如果不够，从所有可用节点中选（允许与真实重叠）
                        temp_decoy = [n for n in available_nodes if n.node_id not in {dn.node_id for dn in decoy_nodes}]
                    if not temp_decoy:
                        break
                    idx = secrets.randbelow(len(temp_decoy))
                    node = temp_decoy.pop(idx)
                    node.is_decoy = True
                    decoy_nodes.append(node)

                # 交错排列
                all_nodes = self._interleave_nodes(real_nodes, decoy_nodes)

                self._path_counter += 1
                path_id = f"path-ei-{self._path_counter:06d}"
                path = Path(
                    path_id=path_id,
                    nodes=all_nodes,
                    created_at=time.time(),
                    expires_at=time.time() + self._config.max_path_age,
                )
                real_paths.append(path)
                paths.append(path)

                for node in real_nodes:
                    self._node_history[node.node_id] = time.time()

                async with self._lock:
                    self._active_paths[path_id] = path

            except (ValueError, IndexError):
                break

        logger.info(f"构建 {len(paths)} 条熵独立路径")
        return paths

    def get_path_entropy_score(self, path: Path) -> float:
        """
        计算路径的熵独立分数

        分数越高，AI越难通过统计特征关联路径。
        """
        import math
        if not path.nodes:
            return 0.0

        # 节点多样性熵
        node_ids = [n.node_id for n in path.nodes]
        unique_ids = set(node_ids)
        diversity_entropy = math.log2(max(1, len(unique_ids)))

        # 地址多样性熵
        addresses = [n.address for n in path.nodes]
        unique_addrs = set(addresses)
        address_entropy = math.log2(max(1, len(unique_addrs)))

        # 真实/诱饵比例熵
        real_count = len(path.real_nodes)
        decoy_count = len(path.decoy_nodes)
        total = real_count + decoy_count
        if total > 0:
            ratio_entropy = 0
            for count in [real_count, decoy_count]:
                if count > 0:
                    p = count / total
                    ratio_entropy -= p * math.log2(p)
        else:
            ratio_entropy = 0

        return diversity_entropy + address_entropy + ratio_entropy
