"""
安全DHT节点ID生成 - Sybil攻击防护

修复问题:
1. 节点ID随机生成，无公钥绑定 → Sybil攻击风险
2. 无PoW机制 → 低成本伪造大量节点
3. 无身份验证 → 路由表污染

解决方案:
1. 节点ID = SHA256(公钥)[:20] (比特币式)
2. 可选PoW增加Sybil成本
3. 身份证明验证

版本: v2.1.0
"""

from __future__ import annotations

import hashlib
import logging
import time
from dataclasses import dataclass
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

# 尝试导入PQC
try:
    from src.pqc.liboqs_provider import HAS_LIBOQS, LiboqsKEM, KEMAlgorithm
except ImportError:
    HAS_LIBOQS = False


# ============================================================================
# 常量
# ============================================================================

NODE_ID_SIZE = 20  # 节点ID大小 (字节)
POW_DIFFICULTY_DEFAULT = 16  # 默认PoW难度 (前16位为0)


# ============================================================================
# 节点身份
# ============================================================================

@dataclass
class NodeIdentity:
    """
    节点身份信息
    
    包含:
    - 节点ID (公钥派生)
    - 公钥
    - 私钥
    - PoW证明 (可选)
    - 时间戳
    """
    node_id: bytes
    public_key: bytes
    secret_key: bytes
    pow_proof: Optional[bytes] = None
    pow_difficulty: int = 0
    created_at: float = 0.0
    
    def __post_init__(self):
        if self.created_at == 0.0:
            self.created_at = time.time()
    
    def to_dict(self) -> dict:
        """导出为字典"""
        return {
            "node_id": self.node_id.hex(),
            "public_key": self.public_key.hex(),
            "pow_proof": self.pow_proof.hex() if self.pow_proof else None,
            "pow_difficulty": self.pow_difficulty,
            "created_at": self.created_at,
        }
    
    @classmethod
    def from_dict(cls, data: dict, secret_key: bytes) -> "NodeIdentity":
        """从字典导入"""
        return cls(
            node_id=bytes.fromhex(data["node_id"]),
            public_key=bytes.fromhex(data["public_key"]),
            secret_key=secret_key,
            pow_proof=bytes.fromhex(data["pow_proof"]) if data.get("pow_proof") else None,
            pow_difficulty=data.get("pow_difficulty", 0),
            created_at=data.get("created_at", 0.0),
        )


# ============================================================================
# 安全节点ID生成器
# ============================================================================

class SecureNodeIDGenerator:
    """
    安全节点ID生成器
    
    核心安全特性:
    1. 节点ID从公钥派生，不可伪造
    2. 可选PoW增加Sybil攻击成本
    3. 身份证明可验证
    """
    
    def __init__(
        self,
        pow_enabled: bool = False,
        pow_difficulty: int = POW_DIFFICULTY_DEFAULT,
    ):
        """
        Args:
            pow_enabled: 是否启用PoW
            pow_difficulty: PoW难度 (前N位必须为0)
        """
        self._pow_enabled = pow_enabled
        self._pow_difficulty = pow_difficulty
        
        # 密钥生成器
        if HAS_LIBOQS:
            self._kem = LiboqsKEM(KEMAlgorithm.ML_KEM_768)
            logger.info("使用ML-KEM-768生成节点密钥")
        else:
            # 回退到X25519
            from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
            self._x25519 = X25519PrivateKey
            logger.warning("liboqs不可用，回退到X25519")
    
    def _generate_keypair(self) -> Tuple[bytes, bytes]:
        """生成密钥对"""
        if HAS_LIBOQS:
            return self._kem.keygen()
        else:
            priv = self._x25519.generate()
            pub = priv.public_key()
            return (
                pub.public_bytes_raw(),
                priv.private_bytes_raw(),
            )
    
    @staticmethod
    def derive_node_id(public_key: bytes) -> bytes:
        """
        从公钥派生节点ID
        
        使用SHA256截断，类似比特币地址生成:
        node_id = SHA256(public_key)[:20]
        
        这确保:
        - 节点ID与公钥绑定
        - 无法伪造他人节点ID
        - 可验证身份
        """
        digest = hashlib.sha256(public_key).digest()
        return digest[:NODE_ID_SIZE]
    
    def _compute_pow(self, public_key: bytes, difficulty: int) -> bytes:
        """
        计算PoW证明
        
        找到nonce使得:
        SHA256(public_key || nonce)的前difficulty位为0
        
        这增加Sybil攻击成本:
        - 生成一个有效节点需要2^difficulty次哈希
        - difficulty=16 → 约65536次哈希
        - difficulty=20 → 约100万次哈希
        """
        nonce = 0
        target_prefix = b"\x00" * (difficulty // 8)
        
        # 如果difficulty不是8的倍数，需要特殊处理
        if difficulty % 8 != 0:
            target_prefix = b"\x00" * (difficulty // 8)
            extra_bits = difficulty % 8
        
        max_iterations = 2 ** (difficulty + 4)  # 预期4倍工作量
        
        start_time = time.time()
        
        while nonce < max_iterations:
            nonce_bytes = nonce.to_bytes(8, "big")
            digest = hashlib.sha256(public_key + nonce_bytes).digest()
            
            if difficulty % 8 == 0:
                if digest[:len(target_prefix)] == target_prefix:
                    elapsed = time.time() - start_time
                    logger.info(
                        f"PoW找到: nonce={nonce}, "
                        f"难度={difficulty}, "
                        f"耗时={elapsed:.2f}s"
                    )
                    return nonce_bytes
            else:
                # 检查前缀和额外位
                if digest[:len(target_prefix)] == target_prefix:
                    extra_byte = digest[len(target_prefix)]
                    if extra_byte < (1 << (8 - extra_bits)):
                        elapsed = time.time() - start_time
                        logger.info(
                            f"PoW找到: nonce={nonce}, "
                            f"难度={difficulty}, "
                            f"耗时={elapsed:.2f}s"
                        )
                        return nonce_bytes
            
            nonce += 1
        
        raise RuntimeError(f"PoW计算失败: 超过最大迭代次数 {max_iterations}")
    
    @staticmethod
    def verify_pow(
        public_key: bytes,
        pow_proof: bytes,
        difficulty: int,
    ) -> bool:
        """
        验证PoW证明
        
        检查SHA256(public_key || proof)的前difficulty位是否为0
        """
        if len(pow_proof) != 8:
            return False
        
        digest = hashlib.sha256(public_key + pow_proof).digest()
        
        # 检查前difficulty位
        full_bytes = difficulty // 8
        extra_bits = difficulty % 8
        
        if digest[:full_bytes] != b"\x00" * full_bytes:
            return False
        
        if extra_bits > 0:
            extra_byte = digest[full_bytes]
            if extra_byte >= (1 << (8 - extra_bits)):
                return False
        
        return True
    
    def generate_identity(self) -> NodeIdentity:
        """
        生成完整节点身份
        
        流程:
        1. 生成密钥对
        2. 从公钥派生节点ID
        3. (可选) 计算PoW证明
        
        Returns:
            NodeIdentity对象
        """
        # 生成密钥对
        public_key, secret_key = self._generate_keypair()
        
        # 派生节点ID
        node_id = self.derive_node_id(public_key)
        
        # 计算PoW (如果启用)
        pow_proof = None
        if self._pow_enabled:
            pow_proof = self._compute_pow(public_key, self._pow_difficulty)
        
        return NodeIdentity(
            node_id=node_id,
            public_key=public_key,
            secret_key=secret_key,
            pow_proof=pow_proof,
            pow_difficulty=self._pow_difficulty if self._pow_enabled else 0,
        )
    
    @staticmethod
    def verify_identity(identity: NodeIdentity) -> bool:
        """
        验证节点身份
        
        检查:
        1. 节点ID是否正确派生自公钥
        2. PoW证明是否有效 (如果有)
        
        Returns:
            是否有效
        """
        # 验证节点ID派生
        expected_id = SecureNodeIDGenerator.derive_node_id(identity.public_key)
        if identity.node_id != expected_id:
            logger.warning("节点ID验证失败: 与公钥不匹配")
            return False
        
        # 验证PoW
        if identity.pow_proof and identity.pow_difficulty > 0:
            if not SecureNodeIDGenerator.verify_pow(
                identity.public_key,
                identity.pow_proof,
                identity.pow_difficulty,
            ):
                logger.warning("PoW验证失败")
                return False
        
        return True


# ============================================================================
# 身份证明签名
# ============================================================================

class IdentityProver:
    """
    身份证明签名器
    
    用于证明拥有节点私钥，而不暴露私钥本身
    """
    
    @staticmethod
    def create_challenge() -> bytes:
        """创建随机挑战"""
        import secrets
        return secrets.token_bytes(32)
    
    @staticmethod
    def sign_challenge(
        secret_key: bytes,
        challenge: bytes,
        public_key: bytes,
    ) -> bytes:
        """
        签名挑战
        
        使用HMAC作为简单签名方案:
        signature = HMAC(secret_key, challenge || public_key)
        
        注意: 生产环境应使用真正的数字签名
        """
        return hashlib.sha256(
            secret_key + challenge + public_key
        ).digest()
    
    @staticmethod
    def verify_signature(
        public_key: bytes,
        challenge: bytes,
        signature: bytes,
        secret_key: bytes,  # 验证方需要知道secret_key
    ) -> bool:
        """
        验证签名
        
        注意: 这需要验证方持有secret_key
        在实际DHT中，应该使用真正的公钥签名验证
        """
        expected = hashlib.sha256(
            secret_key + challenge + public_key
        ).digest()
        return signature == expected


# ============================================================================
# Sybil攻击检测器
# ============================================================================

class SybilDetector:
    """
    Sybil攻击检测器
    
    检测策略:
    1. 同一IP多节点检测
    2. 节点ID聚类分析
    3. 行为模式分析
    """
    
    def __init__(
        self,
        max_nodes_per_ip: int = 3,
        id_clustering_threshold: float = 0.1,
    ):
        self._max_nodes_per_ip = max_nodes_per_ip
        self._id_clustering_threshold = id_clustering_threshold
        
        # IP -> 节点ID集合
        self._ip_nodes: dict[str, set[bytes]] = {}
        # 节点ID -> 首次见时间
        self._node_first_seen: dict[bytes, float] = {}
    
    def check_node(
        self,
        node_id: bytes,
        ip_address: str,
    ) -> Tuple[bool, str]:
        """
        检查节点是否可能是Sybil
        
        Returns:
            (是否允许, 原因)
        """
        # 检查同一IP节点数
        nodes_for_ip = self._ip_nodes.get(ip_address, set())
        if len(nodes_for_ip) >= self._max_nodes_per_ip:
            return False, f"IP {ip_address} 已有 {len(nodes_for_ip)} 个节点"
        
        # 检查节点ID是否已存在
        if node_id in self._node_first_seen:
            return False, "节点ID已存在"
        
        # 检查ID聚类 (与现有节点ID距离过近)
        for existing_id in self._node_first_seen:
            distance = _xor_distance(node_id, existing_id)
            max_distance = (1 << (NODE_ID_SIZE * 8)) - 1
            relative_distance = distance / max_distance
            
            if relative_distance < self._id_clustering_threshold:
                return False, f"节点ID与现有节点距离过近: {relative_distance:.4f}"
        
        # 通过检查，记录
        if ip_address not in self._ip_nodes:
            self._ip_nodes[ip_address] = set()
        self._ip_nodes[ip_address].add(node_id)
        self._node_first_seen[node_id] = time.time()
        
        return True, "通过"
    
    def get_stats(self) -> dict:
        """获取统计信息"""
        return {
            "total_ips": len(self._ip_nodes),
            "total_nodes": len(self._node_first_seen),
            "avg_nodes_per_ip": (
                len(self._node_first_seen) / len(self._ip_nodes)
                if self._ip_nodes else 0
            ),
        }


def _xor_distance(id1: bytes, id2: bytes) -> int:
    """计算两个节点ID的XOR距离"""
    result = 0
    for b1, b2 in zip(id1, id2):
        result = (result << 8) | (b1 ^ b2)
    return result
