"""
DHT网络安全增强模块 - 核心实现
(DHT Network Security Enhancement Module - Core Implementation)

本模块实现了DHT网络的四项核心安全增强功能：
1. PoWRegistration - 基于工作量证明的节点注册，防止Sybil攻击
2. NodeReputationSystem - 节点信誉系统，基于多维度因子评估节点可信度
3. MultiPathDHTQuery - 多路径DHT查询，通过冗余查询和多数投票保证数据一致性
4. RoutingTableRandomizer - 路由表随机化器，定期替换路由条目防止Eclipse攻击

This module implements four core security enhancements for DHT networks:
1. PoWRegistration - Proof-of-Work based node registration to prevent Sybil attacks
2. NodeReputationSystem - Node reputation system with multi-factor trust evaluation
3. MultiPathDHTQuery - Multi-path DHT queries with majority voting for data consistency
4. RoutingTableRandomizer - Routing table randomizer to prevent Eclipse attacks
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
import random
import struct
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

# 配置日志记录器
logger = logging.getLogger(__name__)


# ============================================================
# 辅助数据结构和枚举类型
# ============================================================

class NodeStatus(Enum):
    """节点状态枚举 (Node status enumeration)"""
    ACTIVE = "active"           # 活跃状态
    SUSPENDED = "suspended"     # 暂停状态
    BLACKLISTED = "blacklisted" # 黑名单状态
    UNKNOWN = "unknown"         # 未知状态


@dataclass
class NodeInfo:
    """节点信息数据类 (Node information data class)

    存储DHT网络中节点的完整信息，包括标识、地址、信誉分数等。

    Attributes:
        node_id: 节点的唯一标识符（通常是哈希值）
        ip_address: 节点的IP地址
        port: 节点的监听端口
        public_key: 节点的公钥（用于验证）
        reputation_score: 当前信誉分数 (0.0 ~ 1.0)
        status: 节点当前状态
        first_seen: 节点首次被发现的Unix时间戳
        last_active: 节点最后一次活跃的Unix时间戳
        pow_nonce: 工作量证明的随机数
        metadata: 节点的附加元数据
    """
    node_id: str
    ip_address: str
    port: int
    public_key: str = ""
    reputation_score: float = 0.5
    status: NodeStatus = NodeStatus.UNKNOWN
    first_seen: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)
    pow_nonce: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __hash__(self) -> int:
        """基于node_id计算哈希值，使NodeInfo可用于集合操作"""
        return hash(self.node_id)

    def __eq__(self, other: object) -> bool:
        """基于node_id判断两个节点是否相等"""
        if not isinstance(other, NodeInfo):
            return NotImplemented
        return self.node_id == other.node_id


@dataclass
class QueryResult:
    """DHT查询结果 (DHT query result)

    Attributes:
        key: 查询的键
        value: 查询返回的值
        source_node_id: 返回结果的节点ID
        timestamp: 结果的时间戳
        ttl: 生存时间（秒）
        signature: 结果的数字签名（用于验证）
    """
    key: str
    value: bytes
    source_node_id: str
    timestamp: float = field(default_factory=time.time)
    ttl: int = 3600
    signature: bytes = b""


# ============================================================
# PoWRegistration - 基于工作量证明的节点注册
# ============================================================

class PoWRegistration:
    """基于工作量证明的节点注册 (Proof-of-Work based Node Registration)

    通过要求新节点在注册时完成计算密集型任务来防止Sybil攻击。
    使用可调节难度的哈希计算（基于SHA-256），难度根据网络负载自适应调整。

    Features:
        - 可调节难度的PoW（基于哈希计算）
        - 难度自适应（根据网络负载动态调整）
        - PoW验证（验证节点提交的工作量证明）
        - 防止Sybil攻击（通过计算成本限制恶意节点注册）

    Example:
        >>> reg = PoWRegistration(difficulty=4)
        >>> nonce = reg.compute_pow("node_id_123", "challenge_string")
        >>> is_valid = reg.verify_pow("node_id_123", "challenge_string", nonce)
    """

    # 默认难度参数：目标哈希前缀需要多少个零字节
    DEFAULT_DIFFICULTY: int = 4
    # 最大难度上限（防止过高导致正常节点无法注册）
    MAX_DIFFICULTY: int = 8
    # 最小难度下限
    MIN_DIFFICULTY: int = 1
    # PoW挑战有效期（秒）
    CHALLENGE_EXPIRY: int = 600
    # 难度调整间隔（秒）
    DIFFICULTY_ADJUST_INTERVAL: int = 300
    # 注册速率目标（每分钟注册数）
    TARGET_REGISTRATION_RATE: int = 10

    def __init__(self, difficulty: int = DEFAULT_DIFFICULTY) -> None:
        """初始化PoW注册器

        Args:
            difficulty: 初始难度值，表示目标哈希前缀需要的零字节数。
                       难度越高，计算量越大。
        """
        # 当前难度
        self._difficulty: int = max(
            self.MIN_DIFFICULTY,
            min(difficulty, self.MAX_DIFFICULTY)
        )
        # 已注册节点的PoW记录: node_id -> (nonce, challenge, timestamp)
        self._registered_nodes: Dict[str, Tuple[int, str, float]] = {}
        # 活跃挑战: challenge_hash -> (node_id, timestamp)
        self._active_challenges: Dict[str, Tuple[str, float]] = {}
        # 注册历史（用于难度调整）: timestamp -> count
        self._registration_history: List[float] = []
        # 线程锁，保证并发安全
        self._lock: threading.Lock = threading.Lock()
        # 随机数生成器
        self._rng: random.Random = random.Random()

        logger.info(
            "PoWRegistration 初始化完成, 当前难度: %d", self._difficulty
        )

    @property
    def difficulty(self) -> int:
        """获取当前PoW难度 (Get current PoW difficulty)"""
        return self._difficulty

    def generate_challenge(self, node_id: str) -> str:
        """为指定节点生成PoW挑战 (Generate PoW challenge for a node)

        生成一个随机的挑战字符串，节点需要找到一个nonce使得
        hash(node_id + challenge + nonce) 满足难度要求。

        Args:
            node_id: 请求注册的节点ID

        Returns:
            挑战字符串（十六进制编码）

        Raises:
            ValueError: 如果node_id为空
        """
        if not node_id:
            raise ValueError("节点ID不能为空 (node_id cannot be empty)")

        # 生成随机挑战
        challenge_bytes = os.urandom(32)
        challenge_hex = challenge_bytes.hex()

        with self._lock:
            # 记录挑战，设置过期时间
            self._active_challenges[challenge_hex] = (
                node_id, time.time()
            )
            # 清理过期挑战
            self._cleanup_expired_challenges()

        logger.debug("为节点 %s 生成挑战: %s...", node_id, challenge_hex[:16])
        return challenge_hex

    def compute_pow(
        self,
        node_id: str,
        challenge: str,
        max_iterations: int = 10_000_000
    ) -> Optional[int]:
        """计算工作量证明 (Compute Proof-of-Work)

        寻找一个nonce值，使得 hash(node_id + challenge + nonce) 的结果
        前缀包含足够数量的零字节。

        Args:
            node_id: 节点ID
            challenge: 挑战字符串
            max_iterations: 最大尝试次数，防止无限循环

        Returns:
            找到的nonce值，如果超过最大尝试次数则返回None
        """
        logger.info(
            "开始计算PoW, 节点: %s, 难度: %d, 最大迭代: %d",
            node_id, self._difficulty, max_iterations
        )

        target_prefix = b"\x00" * self._difficulty

        for nonce in range(max_iterations):
            # 构造待哈希的数据: node_id + challenge + nonce
            data = f"{node_id}{challenge}{nonce}".encode("utf-8")
            hash_result = hashlib.sha256(data).digest()

            # 检查哈希结果前缀是否满足难度要求
            if hash_result[:self._difficulty] == target_prefix:
                logger.info(
                    "PoW计算成功, 节点: %s, nonce: %d, 迭代次数: %d",
                    node_id, nonce, nonce + 1
                )
                return nonce

        logger.warning(
            "PoW计算失败, 节点: %s, 超过最大迭代次数 %d",
            node_id, max_iterations
        )
        return None

    def verify_pow(
        self,
        node_id: str,
        challenge: str,
        nonce: int
    ) -> bool:
        """验证工作量证明 (Verify Proof-of-Work)

        验证节点提交的nonce是否确实满足难度要求。

        Args:
            node_id: 节点ID
            challenge: 挑战字符串
            nonce: 节点提交的nonce值

        Returns:
            True如果PoW验证通过，False otherwise
        """
        if nonce < 0:
            logger.warning("无效的nonce值: %d", nonce)
            return False

        if not challenge:
            logger.warning("挑战字符串为空")
            return False

        # 验证挑战是否有效且未过期
        with self._lock:
            if challenge not in self._active_challenges:
                logger.warning("挑战不存在或已过期: %s...", challenge[:16])
                return False

            stored_node_id, challenge_time = self._active_challenges[challenge]
            if stored_node_id != node_id:
                logger.warning(
                    "挑战节点不匹配, 期望: %s, 实际: %s",
                    stored_node_id, node_id
                )
                return False

            if time.time() - challenge_time > self.CHALLENGE_EXPIRY:
                logger.warning("挑战已过期")
                del self._active_challenges[challenge]
                return False

        # 重新计算哈希并验证
        data = f"{node_id}{challenge}{nonce}".encode("utf-8")
        hash_result = hashlib.sha256(data).digest()
        target_prefix = b"\x00" * self._difficulty

        is_valid = hash_result[:self._difficulty] == target_prefix

        if is_valid:
            with self._lock:
                # 记录注册信息
                self._registered_nodes[node_id] = (nonce, challenge, time.time())
                # 记录注册时间
                self._registration_history.append(time.time())
                # 清理已使用的挑战
                if challenge in self._active_challenges:
                    del self._active_challenges[challenge]
            logger.info("节点 %s PoW验证通过", node_id)
        else:
            logger.warning("节点 %s PoW验证失败", node_id)

        return is_valid

    def adjust_difficulty(self) -> int:
        """根据网络负载自适应调整难度 (Adaptively adjust difficulty based on network load)

        分析最近的注册速率，如果注册过快则增加难度，
        如果注册过慢则降低难度。

        Returns:
            调整后的新难度值
        """
        with self._lock:
            now = time.time()
            cutoff = now - self.DIFFICULTY_ADJUST_INTERVAL

            # 统计最近一段时间内的注册数量
            recent_registrations = sum(
                1 for t in self._registration_history if t > cutoff
            )

            # 计算每分钟注册速率
            elapsed_minutes = self.DIFFICULTY_ADJUST_INTERVAL / 60.0
            rate = recent_registrations / max(elapsed_minutes, 0.1)

            old_difficulty = self._difficulty

            # 根据速率调整难度
            if rate > self.TARGET_REGISTRATION_RATE * 1.5:
                # 注册速率过高，增加难度
                self._difficulty = min(self._difficulty + 1, self.MAX_DIFFICULTY)
            elif rate < self.TARGET_REGISTRATION_RATE * 0.5:
                # 注册速率过低，降低难度
                self._difficulty = max(self._difficulty - 1, self.MIN_DIFFICULTY)

            # 清理旧的注册历史记录（保留最近1小时）
            history_cutoff = now - 3600
            self._registration_history = [
                t for t in self._registration_history if t > history_cutoff
            ]

        if old_difficulty != self._difficulty:
            logger.info(
                "PoW难度调整: %d -> %d (注册速率: %.1f/分钟)",
                old_difficulty, self._difficulty, rate
            )
        else:
            logger.debug(
                "PoW难度保持不变: %d (注册速率: %.1f/分钟)",
                self._difficulty, rate
            )

        return self._difficulty

    def is_node_registered(self, node_id: str) -> bool:
        """检查节点是否已通过PoW注册 (Check if a node is registered via PoW)

        Args:
            node_id: 要检查的节点ID

        Returns:
            True如果节点已注册，False otherwise
        """
        with self._lock:
            return node_id in self._registered_nodes

    def revoke_registration(self, node_id: str) -> bool:
        """撤销节点的注册 (Revoke a node's registration)

        当节点被发现有恶意行为时，可以撤销其注册。

        Args:
            node_id: 要撤销的节点ID

        Returns:
            True如果撤销成功，False如果节点未注册
        """
        with self._lock:
            if node_id in self._registered_nodes:
                del self._registered_nodes[node_id]
                logger.info("已撤销节点 %s 的PoW注册", node_id)
                return True
            logger.warning("无法撤销: 节点 %s 未注册", node_id)
            return False

    def _cleanup_expired_challenges(self) -> None:
        """清理过期的挑战 (Clean up expired challenges)

        移除所有超过有效期的挑战记录，释放内存。
        必须在持有锁的情况下调用。
        """
        now = time.time()
        expired = [
            ch for ch, (_, t) in self._active_challenges.items()
            if now - t > self.CHALLENGE_EXPIRY
        ]
        for ch in expired:
            del self._active_challenges[ch]

        if expired:
            logger.debug("清理了 %d 个过期挑战", len(expired))

    def get_statistics(self) -> Dict[str, Any]:
        """获取PoW注册系统的统计信息 (Get PoW registration statistics)

        Returns:
            包含统计信息的字典，包括注册节点数、当前难度、活跃挑战数等
        """
        with self._lock:
            return {
                "difficulty": self._difficulty,
                "registered_nodes": len(self._registered_nodes),
                "active_challenges": len(self._active_challenges),
                "recent_registrations": len(self._registration_history),
                "max_difficulty": self.MAX_DIFFICULTY,
                "min_difficulty": self.MIN_DIFFICULTY,
            }


# ============================================================
# NodeReputationSystem - 节点信誉系统
# ============================================================

class NodeReputationSystem:
    """节点信誉系统 (Node Reputation System)

    基于节点的历史行为计算和维护信誉分数。信誉因子包括：
    - 在线时间 (uptime): 节点保持在线的时间比例
    - 响应延迟 (latency): 节点响应请求的速度
    - 数据完整性 (data_integrity): 节点返回数据的正确性
    - 转发正确性 (forwarding_accuracy): 节点转发消息的准确性

    信誉分数范围: 0.0（完全不可信）到 1.0（完全可信）
    新节点初始分数: 0.5

    Features:
        - 基于历史行为的信誉计算
        - 多维度信誉因子
        - 信誉衰减机制（长期不活跃的节点信誉会逐渐降低）
        - 低信誉节点自动隔离

    Example:
        >>> rep = NodeReputationSystem()
        >>> rep.record_response("node_1", latency_ms=50, success=True)
        >>> score = rep.get_reputation("node_1")
    """

    # 信誉因子权重
    WEIGHT_UPTIME: float = 0.25          # 在线时间权重
    WEIGHT_LATENCY: float = 0.20         # 响应延迟权重
    WEIGHT_DATA_INTEGRITY: float = 0.30  # 数据完整性权重
    WEIGHT_FORWARDING: float = 0.25      # 转发正确性权重

    # 信誉衰减参数
    DECAY_FACTOR: float = 0.95           # 每小时衰减因子
    DECAY_INTERVAL: int = 3600           # 衰减检查间隔（秒）

    # 自动隔离阈值
    ISOLATION_THRESHOLD: float = 0.2     # 低于此分数自动隔离
    BLACKLIST_THRESHOLD: float = 0.1     # 低于此分数加入黑名单

    # 延迟评分参数
    LATENCY_EXCELLENT_MS: int = 50       # 优秀延迟阈值（毫秒）
    LATENCY_GOOD_MS: int = 200           # 良好延迟阈值
    LATENCY_ACCEPTABLE_MS: int = 1000    # 可接受延迟阈值
    LATENCY_POOR_MS: int = 5000          # 较差延迟阈值

    def __init__(self) -> None:
        """初始化节点信誉系统"""
        # 节点信誉数据: node_id -> ReputationData
        self._reputation_data: Dict[str, _ReputationData] = {}
        # 被隔离的节点集合
        self._isolated_nodes: Set[str] = set()
        # 被加入黑名单的节点集合
        self._blacklisted_nodes: Set[str] = set()
        # 线程锁
        self._lock: threading.Lock = threading.Lock()
        # 上次衰减检查时间
        self._last_decay_check: float = time.time()

        logger.info("NodeReputationSystem 初始化完成")

    def record_response(
        self,
        node_id: str,
        latency_ms: float,
        success: bool,
        data_correct: bool = True,
        forwarded_correctly: bool = True
    ) -> None:
        """记录节点的响应行为 (Record a node's response behavior)

        每次与节点交互后调用此方法，更新该节点的信誉数据。

        Args:
            node_id: 节点ID
            latency_ms: 响应延迟（毫秒）
            success: 请求是否成功完成
            data_correct: 返回的数据是否正确
            forwarded_correctly: 转发是否正确（如果涉及转发）
        """
        with self._lock:
            data = self._get_or_create(node_id)

            # 更新在线时间记录
            data.total_interactions += 1
            data.successful_interactions += 1 if success else 0

            # 更新延迟记录
            data.latency_samples.append(latency_ms)
            # 只保留最近100个样本
            if len(data.latency_samples) > 100:
                data.latency_samples = data.latency_samples[-100:]

            # 更新数据完整性记录
            data.total_data_checks += 1
            data.correct_data_count += 1 if data_correct else 0

            # 更新转发正确性记录
            data.total_forwards += 1
            data.correct_forwards += 1 if forwarded_correctly else 0

            # 更新最后活跃时间
            data.last_active = time.time()

            # 重新计算信誉分数
            self._update_reputation_score(data)

            # 检查是否需要隔离
            self._check_isolation(node_id, data)

        logger.debug(
            "记录节点 %s 响应: 延迟=%.1fms, 成功=%s, 数据正确=%s",
            node_id, latency_ms, success, data_correct
        )

    def record_offline(self, node_id: str) -> None:
        """记录节点离线 (Record node going offline)

        Args:
            node_id: 离线的节点ID
        """
        with self._lock:
            data = self._get_or_create(node_id)
            data.total_interactions += 1
            # 离线不计入成功交互
            data.last_active = time.time()
            self._update_reputation_score(data)

        logger.debug("记录节点 %s 离线", node_id)

    def get_reputation(self, node_id: str) -> float:
        """获取节点的信誉分数 (Get a node's reputation score)

        Args:
            node_id: 节点ID

        Returns:
            信誉分数 (0.0 ~ 1.0)，如果节点未知则返回默认值0.5
        """
        with self._lock:
            # 检查黑名单
            if node_id in self._blacklisted_nodes:
                return 0.0
            # 检查隔离列表
            if node_id in self._isolated_nodes:
                return self.ISOLATION_THRESHOLD * 0.5

            if node_id in self._reputation_data:
                return self._reputation_data[node_id].reputation_score
            return 0.5  # 未知节点默认分数

    def is_isolated(self, node_id: str) -> bool:
        """检查节点是否被隔离 (Check if a node is isolated)

        Args:
            node_id: 节点ID

        Returns:
            True如果节点被隔离
        """
        with self._lock:
            return node_id in self._isolated_nodes

    def is_blacklisted(self, node_id: str) -> bool:
        """检查节点是否在黑名单中 (Check if a node is blacklisted)

        Args:
            node_id: 节点ID

        Returns:
            True如果节点在黑名单中
        """
        with self._lock:
            return node_id in self._blacklisted_nodes

    def apply_decay(self) -> int:
        """应用信誉衰减 (Apply reputation decay)

        对所有节点的信誉分数应用时间衰减，长期不活跃的节点
        信誉会逐渐降低。同时检查是否需要隔离低信誉节点。

        Returns:
            受影响的节点数量
        """
        affected_count = 0

        with self._lock:
            now = time.time()
            self._last_decay_check = now

            for node_id, data in self._reputation_data.items():
                # 计算不活跃时间（小时）
                inactive_hours = (now - data.last_active) / 3600.0

                if inactive_hours > 1.0:
                    # 应用衰减: score *= decay_factor ^ inactive_hours
                    decay_multiplier = self.DECAY_FACTOR ** inactive_hours
                    data.reputation_score *= decay_multiplier
                    # 确保分数不低于0
                    data.reputation_score = max(0.0, data.reputation_score)
                    affected_count += 1

                    # 检查是否需要隔离
                    self._check_isolation(node_id, data)

        if affected_count > 0:
            logger.info("信誉衰减已应用, 影响了 %d 个节点", affected_count)

        return affected_count

    def get_top_nodes(self, n: int = 10) -> List[Tuple[str, float]]:
        """获取信誉最高的N个节点 (Get top N nodes by reputation)

        Args:
            n: 要返回的节点数量

        Returns:
            按信誉分数降序排列的 (node_id, score) 列表
        """
        with self._lock:
            nodes = [
                (nid, data.reputation_score)
                for nid, data in self._reputation_data.items()
                if nid not in self._blacklisted_nodes
                and nid not in self._isolated_nodes
            ]
            nodes.sort(key=lambda x: x[1], reverse=True)
            return nodes[:n]

    def get_statistics(self) -> Dict[str, Any]:
        """获取信誉系统统计信息 (Get reputation system statistics)

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            scores = [
                d.reputation_score
                for d in self._reputation_data.values()
            ]
            avg_score = sum(scores) / len(scores) if scores else 0.0

            return {
                "total_nodes": len(self._reputation_data),
                "isolated_nodes": len(self._isolated_nodes),
                "blacklisted_nodes": len(self._blacklisted_nodes),
                "average_reputation": round(avg_score, 4),
                "max_reputation": round(max(scores, default=0), 4),
                "min_reputation": round(min(scores, default=0), 4),
            }

    def _get_or_create(self, node_id: str) -> _ReputationData:
        """获取或创建节点的信誉数据 (Get or create reputation data for a node)

        必须在持有锁的情况下调用。

        Args:
            node_id: 节点ID

        Returns:
            节点的信誉数据对象
        """
        if node_id not in self._reputation_data:
            self._reputation_data[node_id] = _ReputationData(
                node_id=node_id,
                first_seen=time.time(),
            )
        return self._reputation_data[node_id]

    def _update_reputation_score(self, data: _ReputationData) -> None:
        """更新节点的综合信誉分数 (Update node's composite reputation score)

        基于四个维度的加权平均计算综合信誉分数。

        必须在持有锁的情况下调用。

        Args:
            data: 节点的信誉数据
        """
        # 1. 在线时间评分
        if data.total_interactions > 0:
            uptime_score = (
                data.successful_interactions / data.total_interactions
            )
        else:
            uptime_score = 0.5

        # 2. 延迟评分
        latency_score = self._calculate_latency_score(data.latency_samples)

        # 3. 数据完整性评分
        if data.total_data_checks > 0:
            integrity_score = (
                data.correct_data_count / data.total_data_checks
            )
        else:
            integrity_score = 0.5

        # 4. 转发正确性评分
        if data.total_forwards > 0:
            forwarding_score = (
                data.correct_forwards / data.total_forwards
            )
        else:
            forwarding_score = 0.5

        # 加权平均
        composite_score = (
            self.WEIGHT_UPTIME * uptime_score
            + self.WEIGHT_LATENCY * latency_score
            + self.WEIGHT_DATA_INTEGRITY * integrity_score
            + self.WEIGHT_FORWARDING * forwarding_score
        )

        # 使用指数移动平均平滑更新（避免剧烈波动）
        alpha = 0.3  # 新数据的权重
        data.reputation_score = (
            alpha * composite_score
            + (1 - alpha) * data.reputation_score
        )
        # 确保分数在有效范围内
        data.reputation_score = max(0.0, min(1.0, data.reputation_score))

    def _calculate_latency_score(self, samples: List[float]) -> float:
        """根据延迟样本计算延迟评分 (Calculate latency score from samples)

        评分标准:
        - < 50ms:   1.0 (优秀)
        - < 200ms:  0.8 (良好)
        - < 1000ms: 0.6 (可接受)
        - < 5000ms: 0.3 (较差)
        - >= 5000ms: 0.1 (极差)

        Args:
            samples: 延迟样本列表（毫秒）

        Returns:
            延迟评分 (0.0 ~ 1.0)
        """
        if not samples:
            return 0.5  # 无数据时返回中等分数

        avg_latency = sum(samples) / len(samples)

        if avg_latency < self.LATENCY_EXCELLENT_MS:
            return 1.0
        elif avg_latency < self.LATENCY_GOOD_MS:
            return 0.8
        elif avg_latency < self.LATENCY_ACCEPTABLE_MS:
            return 0.6
        elif avg_latency < self.LATENCY_POOR_MS:
            return 0.3
        else:
            return 0.1

    def _check_isolation(self, node_id: str, data: _ReputationData) -> None:
        """检查节点是否需要隔离或加入黑名单 (Check if node needs isolation)

        必须在持有锁的情况下调用。

        Args:
            node_id: 节点ID
            data: 节点的信誉数据
        """
        if data.reputation_score < self.BLACKLIST_THRESHOLD:
            self._blacklisted_nodes.add(node_id)
            self._isolated_nodes.discard(node_id)
            logger.warning(
                "节点 %s 已加入黑名单, 信誉分数: %.4f",
                node_id, data.reputation_score
            )
        elif data.reputation_score < self.ISOLATION_THRESHOLD:
            self._isolated_nodes.add(node_id)
            logger.info(
                "节点 %s 已被隔离, 信誉分数: %.4f",
                node_id, data.reputation_score
            )
        else:
            # 如果分数恢复，从隔离中移除
            if node_id in self._isolated_nodes:
                self._isolated_nodes.discard(node_id)
                logger.info("节点 %s 已从隔离中恢复", node_id)


class _ReputationData:
    """节点信誉内部数据类 (Internal reputation data class)

    存储单个节点的所有信誉相关数据。

    Attributes:
        node_id: 节点ID
        first_seen: 首次发现时间
        last_active: 最后活跃时间
        reputation_score: 当前综合信誉分数
        total_interactions: 总交互次数
        successful_interactions: 成功交互次数
        latency_samples: 延迟样本列表
        total_data_checks: 数据完整性检查总数
        correct_data_count: 数据正确次数
        total_forwards: 转发总数
        correct_forwards: 正确转发次数
    """

    __slots__ = (
        "node_id", "first_seen", "last_active", "reputation_score",
        "total_interactions", "successful_interactions",
        "latency_samples", "total_data_checks", "correct_data_count",
        "total_forwards", "correct_forwards",
    )

    def __init__(
        self,
        node_id: str,
        first_seen: float,
    ) -> None:
        self.node_id: str = node_id
        self.first_seen: float = first_seen
        self.last_active: float = first_seen
        self.reputation_score: float = 0.5  # 初始分数
        self.total_interactions: int = 0
        self.successful_interactions: int = 0
        self.latency_samples: List[float] = []
        self.total_data_checks: int = 0
        self.correct_data_count: int = 0
        self.total_forwards: int = 0
        self.correct_forwards: int = 0


# ============================================================
# MultiPathDHTQuery - 多路径DHT查询
# ============================================================

class MultiPathDHTQuery:
    """多路径DHT查询 (Multi-Path DHT Query)

    通过同时向多个不相交的节点子集发起查询，并使用多数投票机制
    来验证查询结果的一致性，从而提高DHT查询的可靠性。

    Features:
        - 同时向多个不相交节点子集查询
        - 多数投票机制确定正确结果
        - 查询结果一致性验证
        - 超时和重试策略

    Example:
        >>> query = MultiPathDHTQuery(num_paths=3, timeout=5.0)
        >>> result = query.query("my_key", lookup_func=my_lookup)
    """

    # 默认查询路径数
    DEFAULT_NUM_PATHS: int = 3
    # 默认查询超时（秒）
    DEFAULT_TIMEOUT: float = 5.0
    # 默认重试次数
    DEFAULT_RETRIES: int = 2
    # 多数投票所需的最小一致结果数
    MIN_CONSENSUS: int = 2
    # 每条路径的节点数
    NODES_PER_PATH: int = 3

    def __init__(
        self,
        num_paths: int = DEFAULT_NUM_PATHS,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
    ) -> None:
        """初始化多路径DHT查询器

        Args:
            num_paths: 并行查询路径数量（至少为2）
            timeout: 每条路径的查询超时时间（秒）
            retries: 查询失败时的重试次数
        """
        if num_paths < 2:
            raise ValueError(
                f"查询路径数至少为2, 当前值: {num_paths}"
            )

        self._num_paths: int = num_paths
        self._timeout: float = timeout
        self._retries: int = retries
        # 查询历史记录
        self._query_history: List[Dict[str, Any]] = []
        # 线程锁
        self._lock: threading.Lock = threading.Lock()
        # 线程池执行器（延迟导入以避免启动时的开销）
        self._executor: Optional[Any] = None

        logger.info(
            "MultiPathDHTQuery 初始化完成, 路径数: %d, 超时: %.1fs",
            num_paths, timeout
        )

    def query(
        self,
        key: str,
        lookup_func: Any,
        routing_table: Optional[List[NodeInfo]] = None,
    ) -> Optional[QueryResult]:
        """执行多路径DHT查询 (Execute multi-path DHT query)

        同时通过多条不相交路径查询指定的键，使用多数投票机制
        确定最终结果。

        Args:
            key: 要查询的键
            lookup_func: 查询函数，签名为:
                        lookup_func(key: str, node: NodeInfo) -> Optional[QueryResult]
            routing_table: 可用的路由表节点列表。如果为None，使用空列表。

        Returns:
            通过一致性验证的查询结果，如果无法达成一致则返回None
        """
        nodes = routing_table or []

        if len(nodes) < self.NODES_PER_PATH * self._num_paths:
            logger.warning(
                "路由表节点不足: 需要至少 %d 个, 实际 %d 个",
                self.NODES_PER_PATH * self._num_paths,
                len(nodes)
            )

        # 尝试查询（包含重试）
        for attempt in range(1, self._retries + 1):
            logger.info(
                "多路径查询 '%s', 第 %d/%d 次尝试",
                key, attempt, self._retries
            )

            result = self._execute_query(key, lookup_func, nodes)

            if result is not None:
                # 记录成功的查询
                self._record_query(key, True, attempt)
                return result

            logger.warning(
                "多路径查询 '%s' 第 %d 次尝试未达成一致",
                key, attempt
            )

        # 所有重试都失败
        self._record_query(key, False, self._retries)
        logger.error("多路径查询 '%s' 最终失败", key)
        return None

    def _execute_query(
        self,
        key: str,
        lookup_func: Any,
        available_nodes: List[NodeInfo],
    ) -> Optional[QueryResult]:
        """执行单次多路径查询 (Execute a single multi-path query round)

        将可用节点分成多个不相交的子集，通过每条路径并行查询，
        然后使用多数投票确定结果。

        Args:
            key: 查询键
            lookup_func: 查询函数
            available_nodes: 可用节点列表

        Returns:
            通过投票验证的结果，或None
        """
        # 将节点分成不相交的子集
        node_subsets = self._partition_nodes(available_nodes)

        if not node_subsets:
            logger.warning("没有可用的节点子集进行查询")
            return None

        # 通过每条路径收集结果
        path_results: List[List[QueryResult]] = []

        for path_idx, subset in enumerate(node_subsets):
            path_result = self._query_path(
                key, lookup_func, subset, path_idx
            )
            path_results.append(path_result)

        # 使用多数投票确定最终结果
        return self._majority_vote(path_results, key)

    def _partition_nodes(
        self,
        nodes: List[NodeInfo],
    ) -> List[List[NodeInfo]]:
        """将节点分成不相交的子集 (Partition nodes into disjoint subsets)

        使用随机打乱和分组的方式将节点分成多个不相交的子集，
        每个子集包含 NODES_PER_PATH 个节点。

        Args:
            nodes: 可用节点列表

        Returns:
            节点子集列表
        """
        if not nodes:
            return []

        # 随机打乱节点顺序
        shuffled = list(nodes)
        random.shuffle(shuffled)

        subsets: List[List[NodeInfo]] = []
        for i in range(0, len(shuffled), self.NODES_PER_PATH):
            subset = shuffled[i:i + self.NODES_PER_PATH]
            if len(subset) >= 1:  # 至少需要1个节点
                subsets.append(subset)
            if len(subsets) >= self._num_paths:
                break

        return subsets

    def _query_path(
        self,
        key: str,
        lookup_func: Any,
        nodes: List[NodeInfo],
        path_index: int,
    ) -> List[QueryResult]:
        """通过单条路径查询 (Query through a single path)

        依次尝试路径中的每个节点，直到获得结果或所有节点都失败。

        Args:
            key: 查询键
            lookup_func: 查询函数
            nodes: 此路径的节点列表
            path_index: 路径索引（用于日志）

        Returns:
            此路径收集到的所有结果列表
        """
        results: List[QueryResult] = []

        for node in nodes:
            try:
                # 模拟超时控制的查询
                result = self._query_with_timeout(
                    lookup_func, key, node
                )
                if result is not None:
                    results.append(result)
                    logger.debug(
                        "路径 %d: 从节点 %s 获取到结果",
                        path_index, node.node_id
                    )
                    break  # 此路径已获得结果，不需要继续
            except Exception as e:
                logger.warning(
                    "路径 %d: 查询节点 %s 失败: %s",
                    path_index, node.node_id, str(e)
                )

        if not results:
            logger.debug("路径 %d: 未能获取到结果", path_index)

        return results

    def _query_with_timeout(
        self,
        lookup_func: Any,
        key: str,
        node: NodeInfo,
    ) -> Optional[QueryResult]:
        """带超时控制的查询 (Query with timeout control)

        使用线程在指定时间内执行查询，超时则返回None。

        Args:
            lookup_func: 查询函数
            key: 查询键
            node: 目标节点

        Returns:
            查询结果或None（超时或出错时）
        """
        result_holder: List[Optional[QueryResult]] = [None]
        error_holder: List[Optional[Exception]] = [None]

        def _worker() -> None:
            try:
                result_holder[0] = lookup_func(key, node)
            except Exception as exc:
                error_holder[0] = exc

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()
        thread.join(timeout=self._timeout)

        if thread.is_alive():
            logger.warning(
                "查询节点 %s 超时 (%.1fs)", node.node_id, self._timeout
            )
            return None

        if error_holder[0] is not None:
            logger.warning(
                "查询节点 %s 出错: %s",
                node.node_id, str(error_holder[0])
            )
            return None

        return result_holder[0]

    def _majority_vote(
        self,
        path_results: List[List[QueryResult]],
        key: str,
    ) -> Optional[QueryResult]:
        """多数投票机制 (Majority voting mechanism)

        对所有路径返回的结果进行比较，选择出现次数最多的结果。
        只有当一致结果数量达到 MIN_CONSENSUS 时才认为查询成功。

        Args:
            path_results: 各路径的结果列表
            key: 查询键

        Returns:
            通过投票的结果，或None
        """
        # 收集所有非空结果
        all_results: List[QueryResult] = []
        for results in path_results:
            all_results.extend(results)

        if not all_results:
            logger.debug("多数投票: 没有任何结果")
            return None

        # 按值的哈希进行分组（比较值内容而非对象引用）
        value_groups: Dict[str, List[QueryResult]] = {}
        for result in all_results:
            # 使用值的哈希作为分组键
            value_hash = hashlib.sha256(result.value).hexdigest()
            if value_hash not in value_groups:
                value_groups[value_hash] = []
            value_groups[value_hash].append(result)

        # 找到最大的组
        max_group_key = max(
            value_groups, key=lambda k: len(value_groups[k])
        )
        max_group = value_groups[max_group_key]
        consensus_count = len(max_group)

        logger.debug(
            "多数投票: 共 %d 个结果, %d 个不同值, 最大组大小: %d",
            len(all_results), len(value_groups), consensus_count
        )

        if consensus_count >= self.MIN_CONSENSUS:
            # 选择TTL最长的结果
            best_result = max(max_group, key=lambda r: r.ttl)
            logger.info(
                "多数投票通过: %d/%d 路径一致 (key='%s')",
                consensus_count, len(path_results), key
            )
            return best_result

        logger.warning(
            "多数投票未通过: 最大一致数 %d < 最小要求 %d",
            consensus_count, self.MIN_CONSENSUS
        )
        return None

    def _record_query(
        self,
        key: str,
        success: bool,
        attempt: int,
    ) -> None:
        """记录查询历史 (Record query history)

        Args:
            key: 查询键
            success: 查询是否成功
            attempt: 使用的尝试次数
        """
        with self._lock:
            self._query_history.append({
                "key": key,
                "success": success,
                "attempt": attempt,
                "timestamp": time.time(),
            })
            # 只保留最近1000条记录
            if len(self._query_history) > 1000:
                self._query_history = self._query_history[-1000:]

    def get_statistics(self) -> Dict[str, Any]:
        """获取查询统计信息 (Get query statistics)

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            total = len(self._query_history)
            successful = sum(
                1 for q in self._query_history if q["success"]
            )
            success_rate = (
                successful / total if total > 0 else 0.0
            )

            return {
                "total_queries": total,
                "successful_queries": successful,
                "failed_queries": total - successful,
                "success_rate": round(success_rate, 4),
                "num_paths": self._num_paths,
                "timeout": self._timeout,
                "retries": self._retries,
            }


# ============================================================
# RoutingTableRandomizer - 路由表随机化器
# ============================================================

class RoutingTableRandomizer:
    """路由表随机化器 (Routing Table Randomizer)

    定期随机替换路由表中的一部分节点，以防止Eclipse攻击。
    攻击者通过控制路由表中大量节点来隔离目标节点，随机化
    可以有效降低这种攻击的成功率。

    Features:
        - 每小时随机替换20%路由表节点
        - 防止Eclipse攻击
        - 替换策略（保留高信誉节点）
        - 路由表健康检查

    Example:
        >>> randomizer = RoutingTableRandomizer()
        >>> randomizer.add_node(NodeInfo("id1", "1.2.3.4", 8080))
        >>> randomizer.add_candidate(NodeInfo("id2", "5.6.7.8", 8080))
        >>> stats = randomizer.randomize()
    """

    # 默认随机化间隔（秒）- 每小时
    DEFAULT_RANDOMIZE_INTERVAL: int = 3600
    # 默认替换比例（20%）
    DEFAULT_REPLACE_RATIO: float = 0.20
    # 最小路由表大小（低于此值不执行随机化）
    MIN_TABLE_SIZE: int = 5
    # 最大路由表大小
    MAX_TABLE_SIZE: int = 500
    # 候选节点池最大大小
    MAX_CANDIDATE_POOL: int = 1000
    # 健康检查超时（秒）
    HEALTH_CHECK_TIMEOUT: float = 5.0
    # 低信誉阈值（低于此值的节点优先被替换）
    LOW_REPUTATION_THRESHOLD: float = 0.3

    def __init__(
        self,
        replace_ratio: float = DEFAULT_REPLACE_RATIO,
        randomize_interval: int = DEFAULT_RANDOMIZE_INTERVAL,
        reputation_system: Optional[NodeReputationSystem] = None,
    ) -> None:
        """初始化路由表随机化器

        Args:
            replace_ratio: 每次随机化替换的节点比例 (0.0 ~ 1.0)
            randomize_interval: 随机化间隔（秒）
            reputation_system: 可选的信誉系统引用，用于评估节点
        """
        if not 0.0 < replace_ratio <= 1.0:
            raise ValueError(
                f"替换比例必须在 (0, 1] 范围内, 当前值: {replace_ratio}"
            )

        self._replace_ratio: float = replace_ratio
        self._randomize_interval: int = randomize_interval
        self._reputation_system: Optional[NodeReputationSystem] = (
            reputation_system
        )

        # 当前路由表
        self._routing_table: Dict[str, NodeInfo] = {}
        # 候选节点池（用于替换的新节点来源）
        self._candidate_pool: Dict[str, NodeInfo] = {}
        # 随机化历史记录
        self._randomization_history: List[Dict[str, Any]] = []
        # 上次随机化时间
        self._last_randomize: float = time.time()
        # 线程锁
        self._lock: threading.Lock = threading.Lock()

        logger.info(
            "RoutingTableRandomizer 初始化完成, 替换比例: %.0f%%, "
            "间隔: %ds",
            replace_ratio * 100, randomize_interval
        )

    def add_node(self, node: NodeInfo) -> None:
        """添加节点到路由表 (Add a node to the routing table)

        Args:
            node: 要添加的节点信息

        Raises:
            ValueError: 如果路由表已满
        """
        with self._lock:
            if len(self._routing_table) >= self.MAX_TABLE_SIZE:
                raise ValueError(
                    f"路由表已满 (最大 {self.MAX_TABLE_SIZE} 个节点)"
                )
            self._routing_table[node.node_id] = node
            # 如果节点在候选池中，移除
            self._candidate_pool.pop(node.node_id, None)

        logger.debug(
            "节点 %s 已添加到路由表 (%s:%d)",
            node.node_id, node.ip_address, node.port
        )

    def remove_node(self, node_id: str) -> bool:
        """从路由表中移除节点 (Remove a node from the routing table)

        Args:
            node_id: 要移除的节点ID

        Returns:
            True如果移除成功，False如果节点不存在
        """
        with self._lock:
            if node_id in self._routing_table:
                node = self._routing_table.pop(node_id)
                logger.debug(
                    "节点 %s 已从路由表移除", node_id
                )
                return True
            return False

    def add_candidate(self, node: NodeInfo) -> None:
        """添加候选节点到候选池 (Add a candidate node to the pool)

        候选节点用于在随机化时替换被移除的节点。

        Args:
            Raises:
                ValueError: 如果候选池已满
        """
        with self._lock:
            if len(self._candidate_pool) >= self.MAX_CANDIDATE_POOL:
                raise ValueError(
                    f"候选池已满 (最大 {self.MAX_CANDIDATE_POOL} 个节点)"
                )
            # 不添加已在路由表中的节点
            if node.node_id not in self._routing_table:
                self._candidate_pool[node.node_id] = node

        logger.debug(
            "候选节点 %s 已添加到候选池", node.node_id
        )

    def randomize(self) -> Dict[str, Any]:
        """执行路由表随机化 (Execute routing table randomization)

        随机选择一部分路由表节点进行替换。替换策略：
        1. 优先替换低信誉节点
        2. 保留高信誉节点
        3. 从候选池中选择替代节点
        4. 如果候选池不足，仅移除不替换

        Returns:
            随机化结果统计，包括替换数量、保留数量等
        """
        with self._lock:
            table_size = len(self._routing_table)

            # 检查是否满足随机化条件
            if table_size < self.MIN_TABLE_SIZE:
                logger.info(
                    "路由表太小 (%d), 跳过随机化", table_size
                )
                return {
                    "action": "skipped",
                    "reason": "table_too_small",
                    "table_size": table_size,
                }

            # 计算要替换的节点数量
            num_to_replace = max(1, int(table_size * self._replace_ratio))

            # 按信誉分数排序节点（低信誉优先替换）
            sorted_nodes = sorted(
                self._routing_table.values(),
                key=lambda n: self._get_node_score(n)
            )

            # 选择要替换的节点（信誉最低的）
            nodes_to_replace = sorted_nodes[:num_to_replace]
            replace_ids = {n.node_id for n in nodes_to_replace}

            # 从候选池中选择替代节点
            candidates = list(self._candidate_pool.values())
            random.shuffle(candidates)

            replaced_count = 0
            removed_count = 0

            for node in nodes_to_replace:
                # 从路由表中移除
                del self._routing_table[node.node_id]

                # 尝试用候选节点替换
                if candidates:
                    replacement = candidates.pop(0)
                    self._routing_table[replacement.node_id] = replacement
                    # 从候选池中移除已使用的候选
                    self._candidate_pool.pop(replacement.node_id, None)
                    replaced_count += 1
                    logger.debug(
                        "替换节点: %s -> %s",
                        node.node_id, replacement.node_id
                    )
                else:
                    removed_count += 1
                    logger.debug(
                        "移除节点（无候选替换）: %s", node.node_id
                    )

            # 更新随机化时间
            self._last_randomize = time.time()

            # 记录历史
            result = {
                "timestamp": self._last_randomize,
                "table_size_before": table_size,
                "table_size_after": len(self._routing_table),
                "num_to_replace": num_to_replace,
                "replaced": replaced_count,
                "removed": removed_count,
                "candidate_pool_size": len(self._candidate_pool),
            }
            self._randomization_history.append(result)

            logger.info(
                "路由表随机化完成: 替换 %d, 移除 %d, "
                "表大小 %d -> %d",
                replaced_count, removed_count,
                table_size, len(self._routing_table)
            )

            return result

    def should_randomize(self) -> bool:
        """检查是否应该执行随机化 (Check if randomization should be performed)

        Returns:
            True如果距离上次随机化已超过间隔时间
        """
        with self._lock:
            elapsed = time.time() - self._last_randomize
            return elapsed >= self._randomize_interval

    def health_check(self) -> Dict[str, Any]:
        """执行路由表健康检查 (Execute routing table health check)

        检查路由表中每个节点的状态，标记不健康的节点。

        Returns:
            健康检查结果，包括健康/不健康节点数量
        """
        with self._lock:
            healthy_nodes: List[str] = []
            unhealthy_nodes: List[str] = []

            now = time.time()

            for node_id, node in self._routing_table.items():
                is_healthy = True

                # 检查1: 节点是否长时间不活跃（超过24小时）
                if now - node.last_active > 86400:
                    is_healthy = False
                    logger.debug(
                        "节点 %s 不活跃超过24小时", node_id
                    )

                # 检查2: 节点信誉是否过低
                if self._reputation_system is not None:
                    rep = self._reputation_system.get_reputation(node_id)
                    if rep < self.LOW_REPUTATION_THRESHOLD:
                        is_healthy = False
                        logger.debug(
                            "节点 %s 信誉过低: %.4f", node_id, rep
                        )

                # 检查3: 节点状态
                if node.status == NodeStatus.BLACKLISTED:
                    is_healthy = False

                if is_healthy:
                    healthy_nodes.append(node_id)
                else:
                    unhealthy_nodes.append(node_id)

            result = {
                "total_nodes": len(self._routing_table),
                "healthy_nodes": len(healthy_nodes),
                "unhealthy_nodes": len(unhealthy_nodes),
                "unhealthy_node_ids": unhealthy_nodes,
                "health_rate": (
                    len(healthy_nodes) / len(self._routing_table)
                    if self._routing_table else 0.0
                ),
                "timestamp": now,
            }

            logger.info(
                "路由表健康检查: %d/%d 节点健康 (%.1f%%)",
                len(healthy_nodes), len(self._routing_table),
                result["health_rate"] * 100
            )

            return result

    def get_routing_table(self) -> List[NodeInfo]:
        """获取当前路由表的副本 (Get a copy of the current routing table)

        Returns:
            路由表中所有节点的列表
        """
        with self._lock:
            return list(self._routing_table.values())

    def get_statistics(self) -> Dict[str, Any]:
        """获取随机化器统计信息 (Get randomizer statistics)

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            total_randomizations = len(self._randomization_history)
            total_replaced = sum(
                r["replaced"] for r in self._randomization_history
            )
            total_removed = sum(
                r["removed"] for r in self._randomization_history
            )

            return {
                "table_size": len(self._routing_table),
                "candidate_pool_size": len(self._candidate_pool),
                "replace_ratio": self._replace_ratio,
                "randomize_interval": self._randomize_interval,
                "total_randomizations": total_randomizations,
                "total_nodes_replaced": total_replaced,
                "total_nodes_removed": total_removed,
                "last_randomize": self._last_randomize,
                "time_since_last_randomize": (
                    time.time() - self._last_randomize
                ),
            }

    def _get_node_score(self, node: NodeInfo) -> float:
        """获取节点的综合评分（用于排序替换优先级）
        (Get node's composite score for replacement priority)

        分数越低，越优先被替换。

        Args:
            node: 节点信息

        Returns:
            综合评分
        """
        # 基础分数: 信誉分数
        score = node.reputation_score

        # 如果有信誉系统，使用其评分
        if self._reputation_system is not None:
            score = self._reputation_system.get_reputation(node.node_id)

        # 活跃度加成: 最近活跃的节点分数更高
        now = time.time()
        inactive_hours = (now - node.last_active) / 3600.0
        activity_bonus = max(0.0, 1.0 - inactive_hours / 24.0)
        score = score * 0.7 + activity_bonus * 0.3

        return score


# ============================================================
# 模块自测试
# ============================================================

def _run_self_tests() -> None:
    """运行模块自测试 (Run module self-tests)"""
    logging.basicConfig(level=logging.DEBUG)
    print("=" * 60)
    print("DHT网络安全增强模块 - 自测试")
    print("=" * 60)

    # 测试 PoWRegistration
    print("\n--- 测试 PoWRegistration ---")
    pow_reg = PoWRegistration(difficulty=2)
    node_id = "test_node_001"
    challenge = pow_reg.generate_challenge(node_id)
    print(f"  生成挑战: {challenge[:32]}...")
    nonce = pow_reg.compute_pow(node_id, challenge, max_iterations=100000)
    if nonce is not None:
        is_valid = pow_reg.verify_pow(node_id, challenge, nonce)
        print(f"  PoW验证结果: {is_valid}")
        print(f"  节点已注册: {pow_reg.is_node_registered(node_id)}")
    else:
        print("  PoW计算未在限制内完成（正常，难度可能过高）")
    stats = pow_reg.get_statistics()
    print(f"  统计信息: {stats}")

    # 测试 NodeReputationSystem
    print("\n--- 测试 NodeReputationSystem ---")
    rep_sys = NodeReputationSystem()
    for i in range(10):
        rep_sys.record_response(
            f"node_{i}", latency_ms=50 + i * 30,
            success=(i % 4 != 0), data_correct=(i % 5 != 0)
        )
    top = rep_sys.get_top_nodes(3)
    print(f"  信誉最高的3个节点: {top}")
    rep_sys.apply_decay()
    stats = rep_sys.get_statistics()
    print(f"  统计信息: {stats}")

    # 测试 MultiPathDHTQuery
    print("\n--- 测试 MultiPathDHTQuery ---")
    query = MultiPathDHTQuery(num_paths=3, timeout=2.0)

    # 创建模拟路由表
    nodes = [
        NodeInfo(f"n{i}", f"10.0.0.{i}", 8000 + i)
        for i in range(10)
    ]

    # 模拟查询函数
    def mock_lookup(key: str, node: NodeInfo) -> Optional[QueryResult]:
        if int(node.node_id[1:]) % 3 == 0:
            return None  # 模拟部分节点失败
        return QueryResult(
            key=key,
            value=f"value_for_{key}".encode(),
            source_node_id=node.node_id,
        )

    result = query.query("test_key", mock_lookup, nodes)
    print(f"  查询结果: {'成功' if result else '失败'}")
    stats = query.get_statistics()
    print(f"  统计信息: {stats}")

    # 测试 RoutingTableRandomizer
    print("\n--- 测试 RoutingTableRandomizer ---")
    randomizer = RoutingTableRandomizer(
        replace_ratio=0.2, reputation_system=rep_sys
    )
    for i in range(20):
        randomizer.add_node(
            NodeInfo(f"rnode_{i}", f"192.168.1.{i}", 9000 + i)
        )
    for i in range(10):
        randomizer.add_candidate(
            NodeInfo(f"cnode_{i}", f"172.16.0.{i}", 7000 + i)
        )
    rand_result = randomizer.randomize()
    print(f"  随机化结果: {rand_result}")
    health = randomizer.health_check()
    print(f"  健康检查: 健康率 {health['health_rate']:.1%}")
    stats = randomizer.get_statistics()
    print(f"  统计信息: {stats}")

    print("\n" + "=" * 60)
    print("所有自测试完成!")
    print("=" * 60)


if __name__ == "__main__":
    _run_self_tests()
