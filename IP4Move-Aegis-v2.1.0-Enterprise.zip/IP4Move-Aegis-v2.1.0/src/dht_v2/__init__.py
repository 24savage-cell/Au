"""
DHT网络安全增强模块 (DHT Network Security Enhancement Module)

本模块提供了DHT（分布式哈希表）网络的安全增强功能，包括：
- 基于工作量证明(PoW)的节点注册，防止Sybil攻击
- 节点信誉系统，基于历史行为评估节点可信度
- 多路径DHT查询，提高查询可靠性和数据一致性
- 定期路由表随机化，防止Eclipse攻击

This module provides security enhancements for DHT (Distributed Hash Table) networks,
including PoW-based node registration, node reputation system, multi-path DHT queries,
and periodic routing table randomization.
"""

from src.dht_v2.secure_dht import (
    PoWRegistration,
    NodeReputationSystem,
    MultiPathDHTQuery,
    RoutingTableRandomizer,
)

__all__ = [
    "PoWRegistration",
    "NodeReputationSystem",
    "MultiPathDHTQuery",
    "RoutingTableRandomizer",
]

__version__ = "1.0.0"
__author__ = "IP4Move-Aegis Security Team"
