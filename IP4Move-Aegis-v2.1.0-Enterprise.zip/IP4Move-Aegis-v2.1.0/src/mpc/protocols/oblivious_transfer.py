"""
茫然传输 (Oblivious Transfer) 实现

支持1-out-of-2 OT、1-out-of-n OT和随机OT协议。
"""

import hashlib
import secrets
import logging
from typing import List, Tuple, Optional, Dict, Any
from dataclasses import dataclass
from abc import ABC, abstractmethod

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class OTMessage:
    """OT消息结构"""
    ciphertexts: List[bytes]  # 加密后的消息列表
    public_value: Optional[bytes] = None  # 公共值（用于某些OT变体）
    proof: Optional[bytes] = None  # 零知识证明（可选）


@dataclass
class OTChoice:
    """OT选择结构"""
    choice: int  # 选择索引
    blinded_choice: Optional[bytes] = None  # 盲化后的选择
    response: Optional[bytes] = None  # 响应值


class BaseOT(ABC):
    """茫然传输抽象基类"""
    
    def __init__(self, security_param: int = 128):
        """
        初始化OT协议
        
        Args:
            security_param: 安全参数（位）
        """
        self.security_param = security_param
        self.logger = logging.getLogger(self.__class__.__name__)
    
    @abstractmethod
    def sender(self, messages: List[bytes]) -> OTMessage:
        """发送者操作"""
        pass
    
    @abstractmethod
    def receiver(self, choice: int, message: OTMessage) -> bytes:
        """接收者操作"""
        pass


class ObliviousTransfer(BaseOT):
    """
    1-out-of-2 茫然传输实现
    
    基于Diffie-Hellman的OT协议，接收者选择获取m0或m1中的一个，
    发送者不知道接收者选择了哪个消息。
    """
    
    def __init__(self, security_param: int = 128):
        super().__init__(security_param)
        # 使用大素数模数
        self.p = 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF
        self.g = 2
        self.logger.info("初始化1-out-of-2 OT协议")
    
    def _mod_exp(self, base: int, exp: int, mod: int) -> int:
        """模幂运算"""
        return pow(base, exp, mod)
    
    def _hash_to_key(self, value: int) -> bytes:
        """将数值哈希为对称密钥"""
        value_bytes = value.to_bytes((value.bit_length() + 7) // 8, 'big')
        return hashlib.sha256(value_bytes).digest()
    
    def _encrypt(self, key: bytes, message: bytes) -> bytes:
        """使用XOR加密消息"""
        # 扩展密钥以匹配消息长度
        extended_key = hashlib.sha256(key).digest()
        while len(extended_key) < len(message):
            extended_key += hashlib.sha256(extended_key).digest()
        extended_key = extended_key[:len(message)]
        return bytes(m ^ k for m, k in zip(message, extended_key))
    
    def sender_round1(self) -> Tuple[int, int]:
        """
        发送者第一轮：生成公钥对
        
        Returns:
            (A, B) 公钥对
        """
        # 生成私钥
        self.a = secrets.randbelow(self.p - 1) + 1
        self.b = secrets.randbelow(self.p - 1) + 1
        
        # 计算公钥
        A = self._mod_exp(self.g, self.a, self.p)
        B = self._mod_exp(self.g, self.b, self.p)
        
        self.logger.debug("发送者生成公钥对")
        return A, B
    
    def receiver_round1(self, choice: int, A: int, B: int) -> int:
        """
        接收者第一轮：根据选择生成响应
        
        Args:
            choice: 选择 (0 或 1)
            A, B: 发送者的公钥
            
        Returns:
            R: 盲化后的响应
        """
        if choice not in [0, 1]:
            raise ValueError("选择必须是0或1")
        
        self.choice = choice
        
        # 生成随机数
        k = secrets.randbelow(self.p - 1) + 1
        self.k = k
        
        # 计算 R = g^k * B^choice
        g_k = self._mod_exp(self.g, k, self.p)
        
        if choice == 0:
            R = g_k
        else:
            B_inv = pow(B, self.p - 2, self.p)  # 模逆
            R = (g_k * B_inv) % self.p
        
        self.logger.debug(f"接收者选择: {choice}")
        return R
    
    def sender_round2(self, R: int, m0: bytes, m1: bytes) -> Tuple[bytes, bytes]:
        """
        发送者第二轮：加密消息
        
        Args:
            R: 接收者的响应
            m0, m1: 两条消息
            
        Returns:
            (c0, c1): 加密后的消息
        """
        # 计算密钥
        key0 = self._hash_to_key(self._mod_exp(R, self.a, self.p))
        
        # 对于m1: R * B = g^k (当choice=1) 或 g^k * B (当choice=0)
        R_prime = (R * self._mod_exp(self.g, self.b, self.p)) % self.p
        key1 = self._hash_to_key(self._mod_exp(R_prime, self.a, self.p))
        
        # 加密消息
        c0 = self._encrypt(key0, m0)
        c1 = self._encrypt(key1, m1)
        
        self.logger.debug("发送者加密消息")
        return c0, c1
    
    def receiver_round2(self, c0: bytes, c1: bytes) -> bytes:
        """
        接收者第二轮：解密选择的消息
        
        Args:
            c0, c1: 加密消息
            
        Returns:
            解密后的消息
        """
        # 计算解密密钥
        key = self._hash_to_key(self._mod_exp(self.A, self.k, self.p))
        
        # 解密对应的消息
        if self.choice == 0:
            message = self._encrypt(key, c0)
        else:
            message = self._encrypt(key, c1)
        
        self.logger.debug("接收者解密消息")
        return message
    
    def execute(self, m0: bytes, m1: bytes, choice: int) -> bytes:
        """
        执行完整的OT协议
        
        Args:
            m0, m1: 两条消息
            choice: 接收者的选择 (0 或 1)
            
        Returns:
            接收者获得的消息
        """
        # 发送者第一轮
        A, B = self.sender_round1()
        self.A = A
        self.B = B
        
        # 接收者第一轮
        R = self.receiver_round1(choice, A, B)
        
        # 发送者第二轮
        c0, c1 = self.sender_round2(R, m0, m1)
        
        # 接收者第二轮
        result = self.receiver_round2(c0, c1)
        
        return result


class OT1OutOfN(BaseOT):
    """
    1-out-of-n 茫然传输
    
    接收者从n条消息中选择一条，发送者不知道选择了哪条。
    """
    
    def __init__(self, n: int = 10, security_param: int = 128):
        super().__init__(security_param)
        self.n = n
        self.logger.info(f"初始化1-out-of-{n} OT协议")
    
    def execute(self, messages: List[bytes], choice: int) -> bytes:
        """
        执行1-out-of-n OT
        
        使用多次1-out-of-2 OT实现
        
        Args:
            messages: n条消息列表
            choice: 选择索引
            
        Returns:
            选中的消息
        """
        if len(messages) != self.n:
            raise ValueError(f"消息数量必须是{self.n}")
        if choice < 0 or choice >= self.n:
            raise ValueError(f"选择必须在[0, {self.n})范围内")
        
        # 使用二进制编码选择
        # 将选择转换为log2(n)位
        num_bits = (self.n - 1).bit_length()
        
        # 使用1-out-of-2 OT逐位选择
        current_messages = messages[:]
        
        for bit_pos in range(num_bits):
            bit = (choice >> bit_pos) & 1
            
            # 将消息分成两组
            group0 = []
            group1 = []
            
            for i, msg in enumerate(current_messages):
                if ((i >> bit_pos) & 1) == 0:
                    group0.append(msg)
                else:
                    group1.append(msg)
            
            # 填充使两组大小相同
            while len(group0) < len(group1):
                group0.append(b'')
            while len(group1) < len(group0):
                group1.append(b'')
            
            # 执行1-out-of-2 OT
            ot = ObliviousTransfer(self.security_param)
            
            # 合并组内消息
            m0 = b'\x00'.join(group0)
            m1 = b'\x00'.join(group1)
            
            selected = ot.execute(m0, m1, bit)
            
            # 分割选中的组
            if bit == 0:
                current_messages = group0
            else:
                current_messages = group1
        
        return current_messages[0] if current_messages else b''


class RandomOT(BaseOT):
    """
    随机茫然传输 (Random OT)
    
    接收者获得随机值r，发送者获得两个随机值(r0, r1)，
    其中r = r_choice。比标准OT更高效。
    """
    
    def __init__(self, security_param: int = 128):
        super().__init__(security_param)
        self.logger.info("初始化随机OT协议")
    
    def execute_sender(self) -> Tuple[bytes, bytes]:
        """
        发送者执行随机OT
        
        Returns:
            (r0, r1): 两个随机值
        """
        # 生成两个随机值
        r0 = secrets.token_bytes(self.security_param // 8)
        r1 = secrets.token_bytes(self.security_param // 8)
        
        self.r0 = r0
        self.r1 = r1
        
        return r0, r1
    
    def execute_receiver(self, choice: int) -> Tuple[bytes, bytes]:
        """
        接收者执行随机OT
        
        Args:
            choice: 选择 (0 或 1)
            
        Returns:
            (r, seed): 随机值和种子
        """
        if choice not in [0, 1]:
            raise ValueError("选择必须是0或1")
        
        # 生成随机种子
        seed = secrets.token_bytes(32)
        
        # 基于种子和选择派生随机值
        hash_input = seed + bytes([choice])
        r = hashlib.sha256(hash_input).digest()
        
        self.choice = choice
        self.seed = seed
        
        return r, seed
    
    def verify(self, r: bytes, seed: bytes, r0: bytes, r1: bytes) -> bool:
        """
        验证随机OT结果
        
        Args:
            r: 接收者获得的值
            seed: 种子
            r0, r1: 发送者的值
            
        Returns:
            验证是否通过
        """
        # 重新计算
        hash0 = hashlib.sha256(seed + b'\x00').digest()
        hash1 = hashlib.sha256(seed + b'\x01').digest()
        
        return (hash0 == r0 and hash1 == r1 and 
                (r == r0 or r == r1))


class OTExtension:
    """
    OT扩展协议
    
    使用少量基础OT和伪随机生成器扩展为大量OT
    """
    
    def __init__(self, base_ot_count: int = 128, security_param: int = 128):
        """
        初始化OT扩展
        
        Args:
            base_ot_count: 基础OT数量
            security_param: 安全参数
        """
        self.base_ot_count = base_ot_count
        self.security_param = security_param
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"初始化OT扩展，基础OT数: {base_ot_count}")
    
    def _prg(self, seed: bytes, length: int) -> bytes:
        """伪随机生成器"""
        # 使用SHA256作为PRG
        result = b''
        counter = 0
        while len(result) < length:
            counter_bytes = counter.to_bytes(4, 'big')
            result += hashlib.sha256(seed + counter_bytes).digest()
            counter += 1
        return result[:length]
    
    def extend(self, num_ot: int, base_ot: ObliviousTransfer) -> List[Tuple[bytes, bytes]]:
        """
        扩展OT
        
        Args:
            num_ot: 需要的OT数量
            base_ot: 基础OT实例
            
        Returns:
            OT结果列表
        """
        results = []
        
        # 执行基础OT
        for i in range(min(num_ot, self.base_ot_count)):
            # 生成随机消息对
            m0 = secrets.token_bytes(32)
            m1 = secrets.token_bytes(32)
            
            # 随机选择
            choice = secrets.randbelow(2)
            
            # 执行OT
            result = base_ot.execute(m0, m1, choice)
            results.append((result, m0 if choice == 0 else m1))
        
        # 使用PRG扩展
        if num_ot > self.base_ot_count:
            # 基于基础OT结果扩展
            for i in range(self.base_ot_count, num_ot):
                seed = results[i % self.base_ot_count][0]
                extended = self._prg(seed, 64)
                r0 = extended[:32]
                r1 = extended[32:]
                results.append((r0, r1))
        
        self.logger.info(f"OT扩展完成，生成{len(results)}个OT")
        return results


class AsyncObliviousTransfer:
    """
    异步茫然传输
    
    支持异步操作的OT协议实现
    """
    
    def __init__(self, security_param: int = 128):
        self.security_param = security_param
        self.logger = logging.getLogger(self.__class__.__name__)
        self.pending_operations: Dict[str, Any] = {}
    
    async def sender_send(self, operation_id: str, m0: bytes, m1: bytes) -> Dict:
        """
        异步发送者发送消息
        
        Args:
            operation_id: 操作ID
            m0, m1: 两条消息
            
        Returns:
            发送者状态
        """
        ot = ObliviousTransfer(self.security_param)
        A, B = ot.sender_round1()
        
        state = {
            'ot': ot,
            'A': A,
            'B': B,
            'm0': m0,
            'm1': m1
        }
        
        self.pending_operations[operation_id] = state
        
        return {
            'operation_id': operation_id,
            'A': A,
            'B': B
        }
    
    async def receiver_choose(self, operation_id: str, choice: int, sender_msg: Dict) -> Dict:
        """
        异步接收者选择
        
        Args:
            operation_id: 操作ID
            choice: 选择
            sender_msg: 发送者消息
            
        Returns:
            接收者响应
        """
        ot = ObliviousTransfer(self.security_param)
        
        A = sender_msg['A']
        B = sender_msg['B']
        
        R = ot.receiver_round1(choice, A, B)
        
        state = {
            'ot': ot,
            'choice': choice,
            'A': A
        }
        
        self.pending_operations[operation_id] = state
        
        return {
            'operation_id': operation_id,
            'R': R
        }
    
    async def sender_finalize(self, operation_id: str, receiver_response: Dict) -> Dict:
        """
        异步发送者完成
        
        Args:
            operation_id: 操作ID
            receiver_response: 接收者响应
            
        Returns:
            加密消息
        """
        state = self.pending_operations.get(operation_id)
        if not state:
            raise ValueError(f"未知操作: {operation_id}")
        
        ot = state['ot']
        R = receiver_response['R']
        
        c0, c1 = ot.sender_round2(R, state['m0'], state['m1'])
        
        return {
            'c0': c0,
            'c1': c1
        }
    
    async def receiver_receive(self, operation_id: str, ciphertexts: Dict) -> bytes:
        """
        异步接收者接收消息
        
        Args:
            operation_id: 操作ID
            ciphertexts: 密文字典
            
        Returns:
            解密后的消息
        """
        state = self.pending_operations.get(operation_id)
        if not state:
            raise ValueError(f"未知操作: {operation_id}")
        
        ot = state['ot']
        c0 = ciphertexts['c0']
        c1 = ciphertexts['c1']
        
        message = ot.receiver_round2(c0, c1)
        
        # 清理状态
        del self.pending_operations[operation_id]
        
        return message


# 便捷函数
def create_ot_1of2(security_param: int = 128) -> ObliviousTransfer:
    """创建1-out-of-2 OT实例"""
    return ObliviousTransfer(security_param)


def create_ot_1ofN(n: int = 10, security_param: int = 128) -> OT1OutOfN:
    """创建1-out-of-n OT实例"""
    return OT1OutOfN(n, security_param)


def create_random_ot(security_param: int = 128) -> RandomOT:
    """创建随机OT实例"""
    return RandomOT(security_param)


def create_ot_extension(base_ot_count: int = 128, security_param: int = 128) -> OTExtension:
    """创建OT扩展实例"""
    return OTExtension(base_ot_count, security_param)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("茫然传输测试")
    print("=" * 50)
    
    # 测试1-out-of-2 OT
    print("\n1. 测试1-out-of-2 OT:")
    ot = ObliviousTransfer()
    
    m0 = b"Message 0: Secret A"
    m1 = b"Message 1: Secret B"
    
    for choice in [0, 1]:
        result = ot.execute(m0, m1, choice)
        print(f"  选择 {choice}: {result.decode()}")
    
    # 测试1-out-of-n OT
    print("\n2. 测试1-out-of-n OT:")
    messages = [f"Message {i}".encode() for i in range(8)]
    ot_n = OT1OutOfN(n=8)
    
    for choice in [0, 3, 7]:
        result = ot_n.execute(messages, choice)
        print(f"  选择 {choice}: {result.decode()}")
    
    # 测试随机OT
    print("\n3. 测试随机OT:")
    rot = RandomOT()
    r0, r1 = rot.execute_sender()
    
    for choice in [0, 1]:
        r, seed = rot.execute_receiver(choice)
        print(f"  选择 {choice}: r = {r.hex()[:16]}...")
    
    print("\n测试完成!")
