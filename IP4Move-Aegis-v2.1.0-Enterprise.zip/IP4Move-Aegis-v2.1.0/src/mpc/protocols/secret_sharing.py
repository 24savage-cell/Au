"""
Shamir秘密共享实现

基于Shamir的(t,n)阈值秘密共享方案，支持可验证秘密共享(VSS)。
"""

import random
import hashlib
import logging
from typing import List, Tuple, Dict, Optional, Set
from dataclasses import dataclass
from abc import ABC, abstractmethod

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Share:
    """秘密份额数据结构"""
    index: int          # 份额索引 (x坐标)
    value: int          # 份额值 (y坐标)
    
    def __repr__(self) -> str:
        return f"Share(index={self.index}, value={self.value})"


@dataclass  
class VSSProof:
    """VSS证明数据结构"""
    commitments: List[int]  # 承诺值列表
    challenge: int          # 挑战值
    response: int           # 响应值
    
    def verify(self) -> bool:
        """验证VSS证明"""
        # 简化的验证逻辑
        return len(self.commitments) > 0


class SecretSharing(ABC):
    """秘密共享抽象基类"""
    
    def __init__(self, prime: int = None):
        """
        初始化秘密共享方案
        
        Args:
            prime: 有限域素数，默认使用大素数
        """
        # 使用一个足够大的素数 (2^127 - 1)
        self.prime = prime or (2**127 - 1)
        self.logger = logging.getLogger(self.__class__.__name__)
    
    @abstractmethod
    def split(self, secret: int, n: int, t: int) -> List[Share]:
        """分割秘密"""
        pass
    
    @abstractmethod
    def reconstruct(self, shares: List[Share]) -> int:
        """重构秘密"""
        pass


class ShamirSecretSharing(SecretSharing):
    """
    Shamir (t,n) 阈值秘密共享
    
    将秘密分割为n个份额，任意t个份额可重构秘密，少于t个份额无法获得任何信息。
    """
    
    def __init__(self, prime: int = None):
        super().__init__(prime)
        self.logger.info(f"初始化Shamir秘密共享，素数域: {self.prime}")
    
    def _mod(self, x: int) -> int:
        """模运算"""
        return ((x % self.prime) + self.prime) % self.prime
    
    def _generate_polynomial(self, secret: int, t: int) -> List[int]:
        """
        生成随机多项式
        
        f(x) = a_0 + a_1*x + a_2*x^2 + ... + a_{t-1}*x^{t-1}
        其中 a_0 = secret
        
        Args:
            secret: 要共享的秘密
            t: 阈值
            
        Returns:
            多项式系数列表 [a_0, a_1, ..., a_{t-1}]
        """
        # a_0 = secret
        coefficients = [secret]
        
        # 随机生成其他系数
        for _ in range(t - 1):
            coeff = random.randint(1, self.prime - 1)
            coefficients.append(coeff)
        
        self.logger.debug(f"生成多项式系数: {coefficients[:2]}... (共{len(coefficients)}个)")
        return coefficients
    
    def _evaluate_polynomial(self, coefficients: List[int], x: int) -> int:
        """
        计算多项式在x处的值
        
        Args:
            coefficients: 多项式系数
            x: 输入值
            
        Returns:
            f(x) mod prime
        """
        result = 0
        power = 1
        
        for coeff in coefficients:
            result = self._mod(result + coeff * power)
            power = self._mod(power * x)
        
        return result
    
    def split(self, secret: int, n: int, t: int) -> List[Share]:
        """
        将秘密分割为n个份额
        
        Args:
            secret: 要共享的秘密值
            n: 总份额数
            t: 重构阈值 (t <= n)
            
        Returns:
            n个Share对象列表
            
        Raises:
            ValueError: 如果参数无效
        """
        if t > n:
            raise ValueError(f"阈值t({t})不能大于份额数n({n})")
        if t < 2:
            raise ValueError(f"阈值t({t})必须至少为2")
        if secret < 0 or secret >= self.prime:
            raise ValueError(f"秘密值必须在[0, {self.prime})范围内")
        
        self.logger.info(f"分割秘密: n={n}, t={t}")
        
        # 生成随机多项式
        coefficients = self._generate_polynomial(secret, t)
        
        # 生成n个份额 (使用1到n作为x坐标)
        shares = []
        for i in range(1, n + 1):
            value = self._evaluate_polynomial(coefficients, i)
            shares.append(Share(index=i, value=value))
        
        self.logger.info(f"成功生成{n}个秘密份额")
        return shares
    
    def _lagrange_interpolation(self, shares: List[Share], x: int = 0) -> int:
        """
        拉格朗日插值
        
        计算f(x)的值，默认计算f(0)即秘密值
        
        Args:
            shares: 份额列表
            x: 插值点，默认为0
            
        Returns:
            插值结果
        """
        result = 0
        k = len(shares)
        
        for i in range(k):
            # 计算拉格朗日基多项式在x处的值
            numerator = 1
            denominator = 1
            
            for j in range(k):
                if i != j:
                    numerator = self._mod(numerator * (x - shares[j].index))
                    denominator = self._mod(denominator * (shares[i].index - shares[j].index))
            
            # 计算模逆元
            denominator_inv = pow(denominator, self.prime - 2, self.prime)
            lagrange_coeff = self._mod(numerator * denominator_inv)
            
            result = self._mod(result + shares[i].value * lagrange_coeff)
        
        return result
    
    def reconstruct(self, shares: List[Share]) -> int:
        """
        从份额重构秘密
        
        Args:
            shares: 至少t个份额的列表
            
        Returns:
            重构的秘密值
            
        Raises:
            ValueError: 如果份额不足
        """
        if len(shares) < 2:
            raise ValueError("至少需要2个份额才能重构秘密")
        
        self.logger.info(f"使用{len(shares)}个份额重构秘密")
        
        # 去重并验证份额
        seen_indices: Set[int] = set()
        unique_shares = []
        
        for share in shares:
            if share.index not in seen_indices:
                seen_indices.add(share.index)
                unique_shares.append(share)
        
        secret = self._lagrange_interpolation(unique_shares, x=0)
        
        self.logger.info("秘密重构成功")
        return secret
    
    def add_shares(self, share1: Share, share2: Share) -> Share:
        """
        同态加法：份额相加
        
        本地操作，无需交互
        
        Args:
            share1: 第一个份额
            share2: 第二个份额
            
        Returns:
            相加后的新份额
        """
        if share1.index != share2.index:
            raise ValueError("只有相同索引的份额才能相加")
        
        new_value = self._mod(share1.value + share2.value)
        return Share(index=share1.index, value=new_value)
    
    def multiply_by_constant(self, share: Share, constant: int) -> Share:
        """
        份额乘以常数
        
        Args:
            share: 份额
            constant: 常数
            
        Returns:
            乘积份额
        """
        new_value = self._mod(share.value * constant)
        return Share(index=share.index, value=new_value)


class VSSScheme(ShamirSecretSharing):
    """
    可验证秘密共享 (Verifiable Secret Sharing)
    
    基于Feldman VSS方案，允许验证份额的正确性
    """
    
    def __init__(self, prime: int = None, generator: int = None):
        super().__init__(prime)
        # 使用生成元
        self.generator = generator or self._find_generator()
        self.logger.info("初始化VSS方案")
    
    def _find_generator(self) -> int:
        """寻找乘法群的生成元"""
        # 简化的生成元选择
        return 2
    
    def _hash_to_field(self, data: bytes) -> int:
        """将数据哈希到有限域"""
        hash_bytes = hashlib.sha256(data).digest()
        return int.from_bytes(hash_bytes, 'big') % self.prime
    
    def split_with_proof(self, secret: int, n: int, t: int) -> Tuple[List[Share], VSSProof]:
        """
        分割秘密并生成VSS证明
        
        Args:
            secret: 要共享的秘密
            n: 份额数
            t: 阈值
            
        Returns:
            (份额列表, VSS证明)
        """
        # 生成份额
        shares = self.split(secret, n, t)
        
        # 生成多项式系数承诺
        coefficients = self._generate_polynomial(secret, t)
        commitments = []
        
        for coeff in coefficients:
            # g^coeff mod prime
            commitment = pow(self.generator, coeff, self.prime)
            commitments.append(commitment)
        
        # 生成挑战和响应 (简化的Fiat-Shamir)
        challenge_data = str(commitments).encode()
        challenge = self._hash_to_field(challenge_data)
        response = self._mod(coefficients[0] + challenge * coefficients[1])
        
        proof = VSSProof(
            commitments=commitments,
            challenge=challenge,
            response=response
        )
        
        self.logger.info("生成VSS证明完成")
        return shares, proof
    
    def verify_share(self, share: Share, proof: VSSProof) -> bool:
        """
        验证单个份额的有效性
        
        Args:
            share: 要验证的份额
            proof: VSS证明
            
        Returns:
            验证是否通过
        """
        if not proof.commitments:
            return False
        
        # 验证承诺
        # g^share_value ?= product of (commitment_i)^(share_index^i)
        left_side = pow(self.generator, share.value, self.prime)
        
        right_side = 1
        power = 1
        for commitment in proof.commitments:
            right_side = (right_side * pow(commitment, power, self.prime)) % self.prime
            power = (power * share.index) % self.prime
        
        return left_side == right_side
    
    def batch_verify(self, shares: List[Share], proof: VSSProof) -> Dict[int, bool]:
        """
        批量验证多个份额
        
        Args:
            shares: 份额列表
            proof: VSS证明
            
        Returns:
            每个份额的验证结果字典
        """
        results = {}
        for share in shares:
            results[share.index] = self.verify_share(share, proof)
        
        return results


# 便捷函数
def create_shamir_sharing(prime: int = None) -> ShamirSecretSharing:
    """
    创建Shamir秘密共享实例
    
    Args:
        prime: 可选的素数
        
    Returns:
        ShamirSecretSharing实例
    """
    return ShamirSecretSharing(prime)


def create_vss_scheme(prime: int = None, generator: int = None) -> VSSScheme:
    """
    创建VSS方案实例
    
    Args:
        prime: 可选的素数
        generator: 可选的生成元
        
    Returns:
        VSSScheme实例
    """
    return VSSScheme(prime, generator)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("Shamir秘密共享测试")
    print("=" * 50)
    
    # 测试基本Shamir方案
    sss = ShamirSecretSharing()
    secret = 123456789
    n, t = 5, 3
    
    print(f"\n原始秘密: {secret}")
    print(f"参数: n={n}, t={t}")
    
    # 分割
    shares = sss.split(secret, n, t)
    print(f"\n生成{n}个份额:")
    for share in shares:
        print(f"  份额 {share.index}: {share.value}")
    
    # 使用不同数量的份额重构
    print(f"\n使用全部{n}个份额重构:")
    reconstructed = sss.reconstruct(shares)
    print(f"  重构结果: {reconstructed}")
    print(f"  验证: {'通过' if reconstructed == secret else '失败'}")
    
    print(f"\n使用{t}个份额重构:")
    subset = shares[:t]
    reconstructed = sss.reconstruct(subset)
    print(f"  重构结果: {reconstructed}")
    print(f"  验证: {'通过' if reconstructed == secret else '失败'}")
    
    # 测试VSS
    print("\n" + "=" * 50)
    print("VSS可验证秘密共享测试")
    print("=" * 50)
    
    vss = VSSScheme()
    shares_vss, proof = vss.split_with_proof(secret, n, t)
    
    print(f"\n验证各份额:")
    results = vss.batch_verify(shares_vss, proof)
    for idx, valid in results.items():
        print(f"  份额 {idx}: {'有效' if valid else '无效'}")
    
    print("\n测试完成!")
