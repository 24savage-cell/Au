"""
Yao混淆电路实现

支持安全两方计算，包括电路生成、混淆表构建和不经意传输评估。
"""

import hashlib
import secrets
import logging
from typing import Dict, List, Tuple, Optional, Set, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GateType(Enum):
    """逻辑门类型"""
    AND = "AND"
    OR = "OR"
    XOR = "XOR"
    NOT = "NOT"
    NAND = "NAND"
    NOR = "NOR"
    XNOR = "XNOR"


@dataclass
class Wire:
    """电路连线"""
    id: str
    value: Optional[bool] = None
    label_0: Optional[bytes] = None  # 表示0的密钥标签
    label_1: Optional[bytes] = None  # 表示1的密钥标签
    
    def __hash__(self) -> int:
        return hash(self.id)


@dataclass
class Gate:
    """逻辑门"""
    id: str
    gate_type: GateType
    input_wires: List[str]  # 输入连线ID列表
    output_wire: str        # 输出连线ID
    
    def evaluate(self, inputs: List[bool]) -> bool:
        """评估逻辑门"""
        if self.gate_type == GateType.AND:
            return inputs[0] and inputs[1]
        elif self.gate_type == GateType.OR:
            return inputs[0] or inputs[1]
        elif self.gate_type == GateType.XOR:
            return inputs[0] ^ inputs[1]
        elif self.gate_type == GateType.NOT:
            return not inputs[0]
        elif self.gate_type == GateType.NAND:
            return not (inputs[0] and inputs[1])
        elif self.gate_type == GateType.NOR:
            return not (inputs[0] or inputs[1])
        elif self.gate_type == GateType.XNOR:
            return not (inputs[0] ^ inputs[1])
        else:
            raise ValueError(f"未知的门类型: {self.gate_type}")


@dataclass
class GarbledTable:
    """混淆表条目"""
    encrypted_entries: List[bytes]  # 加密后的表项
    gate_id: str
    
    def __len__(self) -> int:
        return len(self.encrypted_entries)


@dataclass
class Circuit:
    """布尔电路"""
    gates: Dict[str, Gate] = field(default_factory=dict)
    wires: Dict[str, Wire] = field(default_factory=dict)
    input_wires: List[str] = field(default_factory=list)
    output_wires: List[str] = field(default_factory=list)
    
    def add_gate(self, gate: Gate) -> None:
        """添加逻辑门"""
        self.gates[gate.id] = gate
    
    def add_wire(self, wire: Wire) -> None:
        """添加连线"""
        self.wires[wire.id] = wire
    
    def get_wire(self, wire_id: str) -> Optional[Wire]:
        """获取连线"""
        return self.wires.get(wire_id)
    
    def evaluate(self, inputs: Dict[str, bool]) -> Dict[str, bool]:
        """
        明文评估电路
        
        Args:
            inputs: 输入值字典 {wire_id: value}
            
        Returns:
            输出值字典
        """
        # 设置输入值
        for wire_id, value in inputs.items():
            if wire_id in self.wires:
                self.wires[wire_id].value = value
        
        # 拓扑排序并评估
        evaluated = set()
        wire_values = dict(inputs)
        
        # 简化的评估：按添加顺序评估
        for gate_id, gate in self.gates.items():
            input_values = [wire_values[w] for w in gate.input_wires]
            output_value = gate.evaluate(input_values)
            wire_values[gate.output_wire] = output_value
            evaluated.add(gate_id)
        
        # 返回输出
        return {w: wire_values.get(w) for w in self.output_wires}


class CircuitGenerator:
    """
    电路生成器
    
    用于构建各种功能的布尔电路
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self._wire_counter = 0
        self._gate_counter = 0
    
    def _new_wire_id(self) -> str:
        """生成新的连线ID"""
        self._wire_counter += 1
        return f"w{self._wire_counter}"
    
    def _new_gate_id(self) -> str:
        """生成新的门ID"""
        self._gate_counter += 1
        return f"g{self._gate_counter}"
    
    def create_adder_circuit(self, n_bits: int = 8) -> Circuit:
        """
        创建n位加法器电路
        
        Args:
            n_bits: 位数
            
        Returns:
            加法器电路
        """
        circuit = Circuit()
        
        # 创建输入连线
        a_wires = []
        b_wires = []
        for i in range(n_bits):
            a_wire = Wire(id=f"a{i}")
            b_wire = Wire(id=f"b{i}")
            a_wires.append(a_wire.id)
            b_wires.append(b_wire.id)
            circuit.add_wire(a_wire)
            circuit.add_wire(b_wire)
            circuit.input_wires.extend([a_wire.id, b_wire.id])
        
        # 进位输入
        carry_wire = self._new_wire_id()
        circuit.add_wire(Wire(id=carry_wire, value=False))
        
        # 构建全加器链
        for i in range(n_bits):
            # 当前位
            a = a_wires[i]
            b = b_wires[i]
            
            # XOR gate for sum: a XOR b XOR carry
            xor1_wire = self._new_wire_id()
            circuit.add_wire(Wire(id=xor1_wire))
            
            xor1 = Gate(
                id=self._new_gate_id(),
                gate_type=GateType.XOR,
                input_wires=[a, b],
                output_wire=xor1_wire
            )
            circuit.add_gate(xor1)
            
            # 最终和位
            sum_wire = f"s{i}"
            circuit.add_wire(Wire(id=sum_wire))
            
            sum_gate = Gate(
                id=self._new_gate_id(),
                gate_type=GateType.XOR,
                input_wires=[xor1_wire, carry_wire],
                output_wire=sum_wire
            )
            circuit.add_gate(sum_gate)
            circuit.output_wires.append(sum_wire)
            
            # 计算进位
            # carry_out = (a AND b) OR (carry AND (a XOR b))
            and1_wire = self._new_wire_id()
            circuit.add_wire(Wire(id=and1_wire))
            
            and1 = Gate(
                id=self._new_gate_id(),
                gate_type=GateType.AND,
                input_wires=[a, b],
                output_wire=and1_wire
            )
            circuit.add_gate(and1)
            
            and2_wire = self._new_wire_id()
            circuit.add_wire(Wire(id=and2_wire))
            
            and2 = Gate(
                id=self._new_gate_id(),
                gate_type=GateType.AND,
                input_wires=[carry_wire, xor1_wire],
                output_wire=and2_wire
            )
            circuit.add_gate(and2)
            
            new_carry = self._new_wire_id()
            circuit.add_wire(Wire(id=new_carry))
            
            or_gate = Gate(
                id=self._new_gate_id(),
                gate_type=GateType.OR,
                input_wires=[and1_wire, and2_wire],
                output_wire=new_carry
            )
            circuit.add_gate(or_gate)
            
            carry_wire = new_carry
        
        # 最终进位输出
        circuit.output_wires.append(carry_wire)
        
        self.logger.info(f"创建{n_bits}位加法器电路，共{len(circuit.gates)}个门")
        return circuit
    
    def create_comparison_circuit(self, n_bits: int = 8) -> Circuit:
        """
        创建比较器电路 (a > b)
        
        Args:
            n_bits: 位数
            
        Returns:
            比较器电路
        """
        circuit = Circuit()
        
        # 输入连线
        for i in range(n_bits):
            circuit.add_wire(Wire(id=f"a{i}"))
            circuit.add_wire(Wire(id=f"b{i}"))
            circuit.input_wires.extend([f"a{i}", f"b{i}"])
        
        # 从高位到低位比较
        result_wire = None
        
        for i in range(n_bits - 1, -1, -1):
            a, b = f"a{i}", f"b{i}"
            
            # NOT b
            not_b = self._new_wire_id()
            circuit.add_wire(Wire(id=not_b))
            not_gate = Gate(
                id=self._new_gate_id(),
                gate_type=GateType.NOT,
                input_wires=[b],
                output_wire=not_b
            )
            circuit.add_gate(not_gate)
            
            # a AND (NOT b) -> a > b at this bit
            gt_bit = self._new_wire_id()
            circuit.add_wire(Wire(id=gt_bit))
            and_gate = Gate(
                id=self._new_gate_id(),
                gate_type=GateType.AND,
                input_wires=[a, not_b],
                output_wire=gt_bit
            )
            circuit.add_gate(and_gate)
            
            if result_wire is None:
                result_wire = gt_bit
            else:
                # OR with previous result
                new_result = self._new_wire_id()
                circuit.add_wire(Wire(id=new_result))
                or_gate = Gate(
                    id=self._new_gate_id(),
                    gate_type=GateType.OR,
                    input_wires=[result_wire, gt_bit],
                    output_wire=new_result
                )
                circuit.add_gate(or_gate)
                result_wire = new_result
        
        circuit.output_wires.append(result_wire)
        
        self.logger.info(f"创建{n_bits}位比较器电路")
        return circuit


class GarbledCircuit:
    """
    混淆电路实现
    
    实现Yao的混淆电路协议，支持安全两方计算
    """
    
    def __init__(self, key_size: int = 128):
        """
        初始化混淆电路
        
        Args:
            key_size: 密钥长度（位）
        """
        self.key_size = key_size // 8  # 转换为字节
        self.logger = logging.getLogger(self.__class__.__name__)
        self.garbled_tables: Dict[str, GarbledTable] = {}
        self.wire_labels: Dict[str, Tuple[bytes, bytes]] = {}
    
    def _generate_label(self) -> bytes:
        """生成随机密钥标签"""
        return secrets.token_bytes(self.key_size)
    
    def _encrypt(self, key: bytes, plaintext: bytes) -> bytes:
        """
        使用密钥加密
        
        使用简单的XOR加密（实际应用应使用AES等）
        """
        # 扩展密钥
        extended_key = hashlib.sha256(key).digest()
        # XOR加密
        return bytes(p ^ k for p, k in zip(plaintext, extended_key))
    
    def _decrypt(self, key: bytes, ciphertext: bytes) -> bytes:
        """解密"""
        # XOR解密（与加密相同）
        return self._encrypt(key, ciphertext)
    
    def _hash_labels(self, labels: List[bytes]) -> bytes:
        """哈希多个标签生成加密密钥"""
        combined = b"".join(labels)
        return hashlib.sha256(combined).digest()[:self.key_size]
    
    def garble_circuit(self, circuit: Circuit) -> Dict[str, GarbledTable]:
        """
        混淆整个电路
        
        Args:
            circuit: 要混淆的电路
            
        Returns:
            混淆表字典
        """
        self.logger.info("开始混淆电路...")
        
        # 为每个连线生成标签
        for wire_id, wire in circuit.wires.items():
            label_0 = self._generate_label()
            label_1 = self._generate_label()
            wire.label_0 = label_0
            wire.label_1 = label_1
            self.wire_labels[wire_id] = (label_0, label_1)
        
        # 混淆每个门
        for gate_id, gate in circuit.gates.items():
            garbled_table = self._garble_gate(gate, circuit)
            self.garbled_tables[gate_id] = garbled_table
        
        self.logger.info(f"混淆完成，共{len(self.garbled_tables)}个混淆表")
        return self.garbled_tables
    
    def _garble_gate(self, gate: Gate, circuit: Circuit) -> GarbledTable:
        """
        混淆单个逻辑门
        
        Args:
            gate: 逻辑门
            circuit: 电路
            
        Returns:
            混淆表
        """
        # 获取输入输出连线
        input_wires = [circuit.get_wire(wid) for wid in gate.input_wires]
        output_wire = circuit.get_wire(gate.output_wire)
        
        if gate.gate_type == GateType.NOT:
            # NOT门只需要一个输入
            encrypted_entries = self._garble_not_gate(
                input_wires[0], output_wire
            )
        else:
            # 双输入门
            encrypted_entries = self._garble_two_input_gate(
                gate, input_wires[0], input_wires[1], output_wire
            )
        
        return GarbledTable(
            encrypted_entries=encrypted_entries,
            gate_id=gate.id
        )
    
    def _garble_two_input_gate(
        self,
        gate: Gate,
        wire_a: Wire,
        wire_b: Wire,
        wire_out: Wire
    ) -> List[bytes]:
        """
        混淆双输入门
        
        创建2x2混淆表，使用点置换技术
        """
        entries = []
        
        # 真值表 (0,0), (0,1), (1,0), (1,1)
        for a_val in [False, True]:
            for b_val in [False, True]:
                # 获取输入标签
                a_label = wire_a.label_1 if a_val else wire_a.label_0
                b_label = wire_b.label_1 if b_val else wire_b.label_0
                
                # 计算输出
                output_val = gate.evaluate([a_val, b_val])
                output_label = wire_out.label_1 if output_val else wire_out.label_0
                
                # 加密：使用两个输入标签的哈希作为密钥
                encryption_key = self._hash_labels([a_label, b_label])
                encrypted = self._encrypt(encryption_key, output_label)
                
                entries.append(encrypted)
        
        # 随机打乱表项顺序（点置换）
        import random
        random.shuffle(entries)
        
        return entries
    
    def _garble_not_gate(
        self,
        wire_in: Wire,
        wire_out: Wire
    ) -> List[bytes]:
        """混淆NOT门"""
        entries = []
        
        for in_val in [False, True]:
            in_label = wire_in.label_1 if in_val else wire_in.label_0
            out_val = not in_val
            out_label = wire_out.label_1 if out_val else wire_out.label_0
            
            encryption_key = self._hash_labels([in_label])
            encrypted = self._encrypt(encryption_key, out_label)
            entries.append(encrypted)
        
        return entries
    
    def evaluate_garbled_gate(
        self,
        garbled_table: GarbledTable,
        input_labels: List[bytes]
    ) -> Optional[bytes]:
        """
        评估混淆门
        
        Args:
            garbled_table: 混淆表
            input_labels: 输入标签列表
            
        Returns:
            输出标签或None
        """
        # 生成解密密钥
        decryption_key = self._hash_labels(input_labels)
        
        # 尝试解密每个表项
        for entry in garbled_table.encrypted_entries:
            try:
                decrypted = self._decrypt(decryption_key, entry)
                # 验证解密结果（检查长度）
                if len(decrypted) == self.key_size:
                    return decrypted
            except Exception:
                continue
        
        return None
    
    def get_input_labels(self, wire_ids: List[str], values: List[bool]) -> Dict[str, bytes]:
        """
        获取输入标签
        
        Args:
            wire_ids: 连线ID列表
            values: 对应的布尔值
            
        Returns:
            标签字典
        """
        labels = {}
        for wire_id, value in zip(wire_ids, values):
            if wire_id in self.wire_labels:
                label_0, label_1 = self.wire_labels[wire_id]
                labels[wire_id] = label_1 if value else label_0
        return labels
    
    def decode_output(self, wire_id: str, label: bytes) -> Optional[bool]:
        """
        解码输出标签
        
        Args:
            wire_id: 连线ID
            label: 输出标签
            
        Returns:
            解码后的布尔值
        """
        if wire_id not in self.wire_labels:
            return None
        
        label_0, label_1 = self.wire_labels[wire_id]
        
        if label == label_0:
            return False
        elif label == label_1:
            return True
        else:
            return None


class GCProtocol:
    """
    混淆电路协议协调器
    
    管理混淆电路协议的执行流程
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.generator = CircuitGenerator()
        self.garbler: Optional[GarbledCircuit] = None
        self.evaluator: Optional[GarbledCircuit] = None
    
    def setup_computation(self, circuit: Circuit, party: str):
        """
        设置计算
        
        Args:
            circuit: 电路
            party: 角色 ("garbler" 或 "evaluator")
        """
        gc = GarbledCircuit()
        
        if party == "garbler":
            # 混淆者：混淆电路并发送混淆表
            gc.garble_circuit(circuit)
            self.garbler = gc
            self.logger.info("Garbler准备完成")
        else:
            # 评估者：接收混淆表并评估
            self.evaluator = gc
            self.logger.info("Evaluator准备完成")
    
    def execute_computation(
        self,
        garbler_inputs: List[bool],
        evaluator_inputs: List[bool],
        circuit: Circuit
    ) -> Dict[str, bool]:
        """
        执行安全计算
        
        这是一个简化的同步实现，实际应用需要网络通信
        
        Args:
            garbler_inputs: 混淆者输入
            evaluator_inputs: 评估者输入
            circuit: 电路
            
        Returns:
            计算结果
        """
        if not self.garbler:
            raise ValueError("Garbler未初始化")
        
        # 获取输入标签
        garbler_input_wires = circuit.input_wires[:len(garbler_inputs)]
        evaluator_input_wires = circuit.input_wires[len(garbler_inputs):]
        
        garbler_labels = self.garbler.get_input_labels(
            garbler_input_wires, garbler_inputs
        )
        
        # 评估者输入通过OT协议获取标签（简化实现）
        evaluator_labels = self.garbler.get_input_labels(
            evaluator_input_wires, evaluator_inputs
        )
        
        # 合并所有标签
        all_labels = {**garbler_labels, **evaluator_labels}
        
        # 评估电路
        output_labels = self._evaluate_circuit(circuit, all_labels)
        
        # 解码输出
        results = {}
        for wire_id in circuit.output_wires:
            if wire_id in output_labels:
                value = self.garbler.decode_output(wire_id, output_labels[wire_id])
                results[wire_id] = value
        
        return results
    
    def _evaluate_circuit(
        self,
        circuit: Circuit,
        input_labels: Dict[str, bytes]
    ) -> Dict[str, bytes]:
        """
        评估混淆电路
        
        Args:
            circuit: 电路
            input_labels: 输入标签
            
        Returns:
            输出标签
        """
        wire_labels = dict(input_labels)
        
        for gate_id, gate in circuit.gates.items():
            if gate_id not in self.garbler.garbled_tables:
                continue
            
            # 获取输入标签
            input_labels_list = [wire_labels.get(wid) for wid in gate.input_wires]
            
            if None in input_labels_list:
                continue
            
            # 评估混淆门
            garbled_table = self.garbler.garbled_tables[gate_id]
            output_label = self.garbler.evaluate_garbled_gate(
                garbled_table, input_labels_list
            )
            
            if output_label:
                wire_labels[gate.output_wire] = output_label
        
        return {wid: wire_labels.get(wid) for wid in circuit.output_wires}


# 便捷函数
def create_circuit_generator() -> CircuitGenerator:
    """创建电路生成器"""
    return CircuitGenerator()


def create_garbled_circuit(key_size: int = 128) -> GarbledCircuit:
    """创建混淆电路实例"""
    return GarbledCircuit(key_size)


def create_gc_protocol() -> GCProtocol:
    """创建GC协议实例"""
    return GCProtocol()


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("混淆电路测试")
    print("=" * 50)
    
    # 创建加法器电路
    generator = CircuitGenerator()
    circuit = generator.create_adder_circuit(n_bits=4)
    
    print(f"\n电路信息:")
    print(f"  输入连线: {len(circuit.input_wires)}")
    print(f"  输出连线: {len(circuit.output_wires)}")
    print(f"  逻辑门: {len(circuit.gates)}")
    
    # 明文测试
    print("\n明文评估测试:")
    inputs = {
        "a0": True, "a1": False, "a2": True, "a3": False,  # 5
        "b0": True, "b1": True, "b2": False, "b3": False,  # 3
    }
    result = circuit.evaluate(inputs)
    print(f"  输入: a=5, b=3")
    print(f"  输出: {result}")
    
    # 混淆电路测试
    print("\n混淆电路测试:")
    gc = GarbledCircuit()
    gc.garble_circuit(circuit)
    
    print(f"  生成混淆表: {len(gc.garbled_tables)}个")
    print(f"  生成连线标签: {len(gc.wire_labels)}个")
    
    print("\n测试完成!")
