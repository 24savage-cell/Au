"""
基于同态加密的MPC协议

实现支持同态运算的安全多方计算协议。
"""

import random
import hashlib
import logging
from typing import List, Tuple, Dict, Optional, Union, Any
from dataclasses import dataclass
from abc import ABC, abstractmethod

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Ciphertext:
    """同态密文结构"""
    value: int
    scheme: str
    
    def __repr__(self) -> str:
        return f"Ciphertext({self.value % (2**32)}..., scheme={self.scheme})"


class HomomorphicScheme(ABC):
    """同态加密方案抽象基类"""
    
    def __init__(self, security_param: int = 128):
        self.security_param = security_param
        self.logger = logging.getLogger(self.__class__.__name__)
    
    @abstractmethod
    def keygen(self) -> Tuple[Any, Any]:
        """生成密钥对"""
        pass
    
    @abstractmethod
    def encrypt(self, plaintext: int, public_key: Any) -> Ciphertext:
        """加密"""
        pass
    
    @abstractmethod
    def decrypt(self, ciphertext: Ciphertext, private_key: Any) -> int:
        """解密"""
        pass
    
    @abstractmethod
    def add(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """同态加法"""
        pass
    
    @abstractmethod
    def multiply(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """同态乘法"""
        pass
    
    @abstractmethod
    def scalar_multiply(self, ct: Ciphertext, scalar: int) -> Ciphertext:
        """标量乘法"""
        pass


class PaillierScheme(HomomorphicScheme):
    """
    Paillier同态加密方案
    
    支持加法同态和部分乘法同态
    """
    
    def __init__(self, key_size: int = 2048):
        super().__init__(key_size)
        self.key_size = key_size
        self.logger.info(f"初始化Paillier方案，密钥长度: {key_size}")
    
    def _generate_prime(self, bits: int) -> int:
        """生成大素数（简化实现）"""
        # 实际应用应使用更严格的素数测试
        while True:
            n = random.getrandbits(bits)
            n |= (1 << bits - 1) | 1  # 确保是奇数且有正确位数
            # 简化的素性测试
            if self._is_prime(n):
                return n
    
    def _is_prime(self, n: int, k: int = 10) -> bool:
        """Miller-Rabin素性测试"""
        if n < 2:
            return False
        if n == 2 or n == 3:
            return True
        if n % 2 == 0:
            return False
        
        # 写成 n-1 = 2^r * d
        r, d = 0, n - 1
        while d % 2 == 0:
            r += 1
            d //= 2
        
        # 测试轮数
        for _ in range(k):
            a = random.randrange(2, n - 1)
            x = pow(a, d, n)
            
            if x == 1 or x == n - 1:
                continue
            
            for _ in range(r - 1):
                x = pow(x, 2, n)
                if x == n - 1:
                    break
            else:
                return False
        
        return True
    
    def _lcm(self, a: int, b: int) -> int:
        """最小公倍数"""
        from math import gcd
        return abs(a * b) // gcd(a, b)
    
    def _L(self, u: int, n: int) -> int:
        """Paillier L函数"""
        return (u - 1) // n
    
    def keygen(self) -> Tuple[Dict, Dict]:
        """
        生成Paillier密钥对
        
        Returns:
            (public_key, private_key)
        """
        self.logger.info("生成Paillier密钥对...")
        
        # 生成两个大素数
        p = self._generate_prime(self.key_size // 2)
        q = self._generate_prime(self.key_size // 2)
        
        # 计算n和n^2
        n = p * q
        n_squared = n * n
        
        # 计算lambda = lcm(p-1, q-1)
        lam = self._lcm(p - 1, q - 1)
        
        # 选择g
        g = n + 1  # 简化的选择
        
        # 计算mu
        u = pow(g, lam, n_squared)
        L_u = self._L(u, n)
        mu = pow(L_u, -1, n)
        
        public_key = {
            'n': n,
            'n_squared': n_squared,
            'g': g
        }
        
        private_key = {
            'lam': lam,
            'mu': mu,
            'n': n,
            'n_squared': n_squared
        }
        
        self.logger.info("密钥对生成完成")
        return public_key, private_key
    
    def encrypt(self, plaintext: int, public_key: Dict) -> Ciphertext:
        """
        Paillier加密
        
        c = g^m * r^n mod n^2
        
        Args:
            plaintext: 明文 (m < n)
            public_key: 公钥
            
        Returns:
            密文
        """
        n = public_key['n']
        n_squared = public_key['n_squared']
        g = public_key['g']
        
        if plaintext < 0 or plaintext >= n:
            raise ValueError(f"明文必须在[0, {n})范围内")
        
        # 生成随机数r
        r = random.randrange(1, n)
        while self._gcd(r, n) != 1:
            r = random.randrange(1, n)
        
        # 计算密文
        g_m = pow(g, plaintext, n_squared)
        r_n = pow(r, n, n_squared)
        c = (g_m * r_n) % n_squared
        
        return Ciphertext(value=c, scheme="Paillier")
    
    def _gcd(self, a: int, b: int) -> int:
        """最大公约数"""
        while b:
            a, b = b, a % b
        return a
    
    def decrypt(self, ciphertext: Ciphertext, private_key: Dict) -> int:
        """
        Paillier解密
        
        m = L(c^lambda mod n^2) * mu mod n
        
        Args:
            ciphertext: 密文
            private_key: 私钥
            
        Returns:
            明文
        """
        if ciphertext.scheme != "Paillier":
            raise ValueError("密文方案不匹配")
        
        c = ciphertext.value
        lam = private_key['lam']
        mu = private_key['mu']
        n = private_key['n']
        n_squared = private_key['n_squared']
        
        # 计算c^lambda mod n^2
        c_lam = pow(c, lam, n_squared)
        
        # 计算L函数
        L_c = self._L(c_lam, n)
        
        # 计算明文
        m = (L_c * mu) % n
        
        return m
    
    def add(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """
        同态加法
        
        E(m1) * E(m2) = E(m1 + m2)
        
        Args:
            ct1, ct2: 两个密文
            
        Returns:
            加法结果密文
        """
        if ct1.scheme != ct2.scheme:
            raise ValueError("密文方案不匹配")
        
        # 从密文中提取n^2（简化处理，实际应从上下文获取）
        result = (ct1.value * ct2.value)  # 这里需要模n^2
        
        return Ciphertext(value=result, scheme="Paillier")
    
    def multiply(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """
        Paillier不支持两个密文相乘
        
        Raises:
            NotImplementedError: Paillier不支持此操作
        """
        raise NotImplementedError("Paillier不支持两个密文相乘")
    
    def scalar_multiply(self, ct: Ciphertext, scalar: int) -> Ciphertext:
        """
        标量乘法（密文乘以明文）
        
        E(m)^k = E(m * k)
        
        Args:
            ct: 密文
            scalar: 标量
            
        Returns:
            乘法结果密文
        """
        result = pow(ct.value, scalar)  # 需要模n^2
        return Ciphertext(value=result, scheme="Paillier")
    
    def negate(self, ct: Ciphertext, public_key: Dict) -> Ciphertext:
        """
        同态取反
        
        E(-m) = E(m)^(-1) mod n^2
        
        Args:
            ct: 密文
            public_key: 公钥
            
        Returns:
            取反后的密文
        """
        n_squared = public_key['n_squared']
        # 计算模逆
        inv = pow(ct.value, -1, n_squared)
        return Ciphertext(value=inv, scheme="Paillier")


class BFVScheme(HomomorphicScheme):
    """
    BFV (Brakerski-Fan-Vercauteren) 同态加密方案
    
    支持有限次加法和乘法同态运算
    """
    
    def __init__(self, poly_degree: int = 4096, plain_modulus: int = 65537):
        super().__init__(poly_degree)
        self.poly_degree = poly_degree
        self.plain_modulus = plain_modulus
        self.cipher_modulus = self._generate_cipher_modulus()
        self.logger.info(f"初始化BFV方案，多项式次数: {poly_degree}")
    
    def _generate_cipher_modulus(self) -> int:
        """生成密文模数"""
        # 简化的实现，实际应使用更大的模数
        return (1 << 60) - 1
    
    def keygen(self) -> Tuple[Dict, Dict]:
        """
        生成BFV密钥对
        
        Returns:
            (public_key, private_key)
        """
        self.logger.info("生成BFV密钥对...")
        
        # 生成私钥（多项式）
        # 简化为随机系数
        sk_coeffs = [random.randint(0, 1) for _ in range(self.poly_degree)]
        
        # 生成公钥
        # pk = ([-(a*sk + e)]_q, a)
        a_coeffs = [random.randint(0, self.cipher_modulus - 1) 
                    for _ in range(self.poly_degree)]
        e_coeffs = [random.randint(-1, 1) for _ in range(self.poly_degree)]
        
        # 简化的公钥计算
        pk0 = [(a * s + e) % self.cipher_modulus 
               for a, s, e in zip(a_coeffs, sk_coeffs, e_coeffs)]
        pk1 = a_coeffs
        
        public_key = {
            'pk0': pk0,
            'pk1': pk1,
            'cipher_modulus': self.cipher_modulus,
            'plain_modulus': self.plain_modulus
        }
        
        private_key = {
            'sk': sk_coeffs,
            'cipher_modulus': self.cipher_modulus,
            'plain_modulus': self.plain_modulus
        }
        
        self.logger.info("BFV密钥对生成完成")
        return public_key, private_key
    
    def encrypt(self, plaintext: int, public_key: Dict) -> Ciphertext:
        """
        BFV加密（简化实现）
        
        Args:
            plaintext: 明文
            public_key: 公钥
            
        Returns:
            密文
        """
        # 简化的加密：将明文编码为多项式
        cipher_modulus = public_key['cipher_modulus']
        
        # 生成随机多项式u和误差e1, e2
        u = random.randint(1, cipher_modulus - 1)
        e1 = random.randint(-1, 1)
        e2 = random.randint(-1, 1)
        
        # 简化的密文计算
        ct0 = (plaintext + u * sum(public_key['pk0']) + e1) % cipher_modulus
        ct1 = (u * sum(public_key['pk1']) + e2) % cipher_modulus
        
        # 组合密文
        combined = (ct0 << 64) | ct1
        
        return Ciphertext(value=combined, scheme="BFV")
    
    def decrypt(self, ciphertext: Ciphertext, private_key: Dict) -> int:
        """
        BFV解密（简化实现）
        
        Args:
            ciphertext: 密文
            private_key: 私钥
            
        Returns:
            明文
        """
        if ciphertext.scheme != "BFV":
            raise ValueError("密文方案不匹配")
        
        # 解包密文
        ct0 = ciphertext.value >> 64
        ct1 = ciphertext.value & ((1 << 64) - 1)
        
        # 简化解密
        plain_modulus = private_key['plain_modulus']
        sk_sum = sum(private_key['sk'])
        
        # m = [ct0 + ct1 * sk]_t
        m = (ct0 + ct1 * sk_sum) % plain_modulus
        
        return m
    
    def add(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """
        BFV同态加法
        
        Args:
            ct1, ct2: 两个密文
            
        Returns:
            加法结果密文
        """
        if ct1.scheme != ct2.scheme:
            raise ValueError("密文方案不匹配")
        
        result = ct1.value + ct2.value
        return Ciphertext(value=result, scheme="BFV")
    
    def multiply(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """
        BFV同态乘法（需要重线性化）
        
        Args:
            ct1, ct2: 两个密文
            
        Returns:
            乘法结果密文
        """
        if ct1.scheme != ct2.scheme:
            raise ValueError("密文方案不匹配")
        
        # 简化的乘法实现
        result = ct1.value * ct2.value
        return Ciphertext(value=result, scheme="BFV")
    
    def scalar_multiply(self, ct: Ciphertext, scalar: int) -> Ciphertext:
        """
        标量乘法
        
        Args:
            ct: 密文
            scalar: 标量
            
        Returns:
            乘法结果密文
        """
        result = ct.value * scalar
        return Ciphertext(value=result, scheme="BFV")


class HomomorphicMPC:
    """
    基于同态加密的MPC协议协调器
    
    管理多方计算中的加密运算和密钥共享
    """
    
    def __init__(self, scheme: str = "Paillier"):
        """
        初始化MPC协调器
        
        Args:
            scheme: 同态加密方案 ("Paillier" 或 "BFV")
        """
        self.scheme_name = scheme
        self.logger = logging.getLogger(self.__class__.__name__)
        
        if scheme == "Paillier":
            self.scheme = PaillierScheme()
        elif scheme == "BFV":
            self.scheme = BFVScheme()
        else:
            raise ValueError(f"不支持的方案: {scheme}")
        
        self.public_key = None
        self.private_key = None
        self.parties: List[Dict] = []
        
        self.logger.info(f"初始化同态MPC，使用{scheme}方案")
    
    def setup(self, num_parties: int = 2) -> None:
        """
        设置MPC系统
        
        Args:
            num_parties: 参与方数量
        """
        self.logger.info(f"设置{num_parties}方MPC系统...")
        
        # 生成密钥
        self.public_key, self.private_key = self.scheme.keygen()
        
        # 初始化参与方
        self.parties = [
            {
                'id': i,
                'public_key': self.public_key,
                'share': None  # 密钥分片（如果使用阈值加密）
            }
            for i in range(num_parties)
        ]
        
        self.logger.info("MPC设置完成")
    
    def encrypt_input(self, party_id: int, value: int) -> Ciphertext:
        """
        参与方加密输入
        
        Args:
            party_id: 参与方ID
            value: 输入值
            
        Returns:
            加密后的输入
        """
        if party_id >= len(self.parties):
            raise ValueError("无效的参与方ID")
        
        return self.scheme.encrypt(value, self.public_key)
    
    def secure_add(self, encrypted_values: List[Ciphertext]) -> Ciphertext:
        """
        安全加法：计算加密值的和
        
        Args:
            encrypted_values: 加密值列表
            
        Returns:
            加密后的和
        """
        if not encrypted_values:
            raise ValueError("输入列表不能为空")
        
        result = encrypted_values[0]
        for ct in encrypted_values[1:]:
            result = self.scheme.add(result, ct)
        
        self.logger.debug(f"完成{len(encrypted_values)}个值的同态加法")
        return result
    
    def secure_multiply(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """
        安全乘法
        
        Args:
            ct1, ct2: 两个加密值
            
        Returns:
            加密后的乘积
        """
        return self.scheme.multiply(ct1, ct2)
    
    def secure_average(self, encrypted_values: List[Ciphertext]) -> Ciphertext:
        """
        安全平均值
        
        Args:
            encrypted_values: 加密值列表
            
        Returns:
            加密后的平均值
        """
        total = self.secure_add(encrypted_values)
        n = len(encrypted_values)
        
        # 除以n（乘以n的模逆）
        return self.scheme.scalar_multiply(total, pow(n, -1, self.public_key.get('n', 2**32)))
    
    def decrypt_result(self, ciphertext: Ciphertext) -> int:
        """
        解密最终结果
        
        Args:
            ciphertext: 加密结果
            
        Returns:
            明文结果
        """
        return self.scheme.decrypt(ciphertext, self.private_key)
    
    def inner_product(
        self,
        encrypted_vector1: List[Ciphertext],
        encrypted_vector2: List[Ciphertext]
    ) -> Ciphertext:
        """
        安全内积计算
        
        Args:
            encrypted_vector1: 第一个加密向量
            encrypted_vector2: 第二个加密向量
            
        Returns:
            加密后的内积
        """
        if len(encrypted_vector1) != len(encrypted_vector2):
            raise ValueError("向量长度不匹配")
        
        # 逐元素相乘
        products = []
        for ct1, ct2 in zip(encrypted_vector1, encrypted_vector2):
            product = self.secure_multiply(ct1, ct2)
            products.append(product)
        
        # 求和
        return self.secure_add(products)
    
    def polynomial_evaluation(
        self,
        encrypted_x: Ciphertext,
        coefficients: List[int]
    ) -> Ciphertext:
        """
        安全多项式求值
        
        计算 P(x) = c0 + c1*x + c2*x^2 + ... + cn*x^n
        
        Args:
            encrypted_x: 加密输入
            coefficients: 多项式系数 [c0, c1, ..., cn]
            
        Returns:
            加密后的多项式值
        """
        if not coefficients:
            raise ValueError("系数列表不能为空")
        
        # 常数项
        result = self.scheme.encrypt(coefficients[0], self.public_key)
        
        # 计算各项
        x_power = encrypted_x
        for i, coeff in enumerate(coefficients[1:], 1):
            # coeff * x^i
            term = self.scheme.scalar_multiply(x_power, coeff)
            result = self.scheme.add(result, term)
            
            # x^(i+1) = x^i * x
            if i < len(coefficients) - 1:
                x_power = self.secure_multiply(x_power, encrypted_x)
        
        return result


# 便捷函数
def create_paillier_mpc(key_size: int = 2048) -> HomomorphicMPC:
    """创建基于Paillier的MPC实例"""
    return HomomorphicMPC("Paillier")


def create_bfv_mpc(poly_degree: int = 4096) -> HomomorphicMPC:
    """创建基于BFV的MPC实例"""
    return HomomorphicMPC("BFV")


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("同态加密MPC测试")
    print("=" * 50)
    
    # 测试Paillier方案
    print("\n1. Paillier同态加密测试:")
    paillier = PaillierScheme(key_size=512)  # 测试使用小密钥
    
    pk, sk = paillier.keygen()
    
    # 加密两个数
    m1, m2 = 42, 58
    ct1 = paillier.encrypt(m1, pk)
    ct2 = paillier.encrypt(m2, pk)
    
    print(f"  明文: m1={m1}, m2={m2}")
    print(f"  密文: {ct1}")
    print(f"        {ct2}")
    
    # 同态加法
    ct_sum = paillier.add(ct1, ct2)
    print(f"  同态加法结果密文: {ct_sum}")
    
    # 解密
    decrypted_sum = paillier.decrypt(ct_sum, sk)
    print(f"  解密结果: {decrypted_sum}")
    print(f"  验证: {decrypted_sum} == {m1 + m2} ? {decrypted_sum == m1 + m2}")
    
    # 测试MPC协议
    print("\n2. 同态MPC协议测试:")
    mpc = create_paillier_mpc()
    mpc.setup(num_parties=3)
    
    # 多方输入
    inputs = [10, 20, 30]
    encrypted_inputs = [mpc.encrypt_input(i, val) for i, val in enumerate(inputs)]
    
    print(f"  各方输入: {inputs}")
    
    # 安全求和
    encrypted_sum = mpc.secure_add(encrypted_inputs)
    decrypted_sum = mpc.decrypt_result(encrypted_sum)
    
    print(f"  安全求和结果: {decrypted_sum}")
    print(f"  验证: {decrypted_sum} == {sum(inputs)} ? {decrypted_sum == sum(inputs)}")
    
    print("\n测试完成!")
