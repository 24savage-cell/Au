"""
安全加法原语

实现基于秘密共享和同态加密的安全加法运算。
"""

import logging
from typing import List, Tuple, Optional, Union
from dataclasses import dataclass

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Share:
    """秘密份额"""
    value: int
    index: int
    
    def __repr__(self) -> str:
        return f"Share(value={self.value}, index={self.index})"


class SecureAddition:
    """
    安全加法实现
    
    支持多种安全加法方案：秘密共享加法、同态加法
    """
    
    def __init__(self, prime: int = None, scheme: str = "shamir"):
        """
        初始化安全加法
        
        Args:
            prime: 有限域素数
            scheme: 方案类型 ("shamir" 或 "homomorphic")
        """
        self.prime = prime or (2**61 - 1)  # 默认真梅素数
        self.scheme = scheme
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"初始化安全加法，方案: {scheme}")
    
    def _mod(self, x: int) -> int:
        """模运算"""
        return ((x % self.prime) + self.prime) % self.prime
    
    # ==================== 秘密共享加法 ====================
    
    def shamir_add(self, share1: Share, share2: Share) -> Share:
        """
        Shamir秘密共享加法
        
        本地操作：份额直接相加
        
        Args:
            share1: 第一个份额
            share2: 第二个份额
            
        Returns:
            相加后的份额
        """
        if share1.index != share2.index:
            raise ValueError("只有相同索引的份额才能相加")
        
        result_value = self._mod(share1.value + share2.value)
        return Share(value=result_value, index=share1.index)
    
    def shamir_add_batch(
        self,
        shares_list1: List[Share],
        shares_list2: List[Share]
    ) -> List[Share]:
        """
        批量Shamir秘密共享加法
        
        Args:
            shares_list1: 第一组份额列表
            shares_list2: 第二组份额列表
            
        Returns:
            相加后的份额列表
        """
        if len(shares_list1) != len(shares_list2):
            raise ValueError("份额列表长度不匹配")
        
        results = []
        for s1, s2 in zip(shares_list1, shares_list2):
            result = self.shamir_add(s1, s2)
            results.append(result)
        
        self.logger.debug(f"完成{len(results)}对份额的加法")
        return results
    
    def shamir_add_constant(self, share: Share, constant: int) -> Share:
        """
        份额加常数
        
        只有份额0加上常数，其他份额保持不变
        
        Args:
            share: 份额
            constant: 常数
            
        Returns:
            相加后的份额
        """
        if share.index == 0:
            result_value = self._mod(share.value + constant)
            return Share(value=result_value, index=share.index)
        else:
            return share
    
    # ==================== 同态加法 ====================
    
    def homomorphic_add(self, ct1: int, ct2: int, modulus: int) -> int:
        """
        同态加法
        
        对于加法同态加密：E(m1) * E(m2) = E(m1 + m2)
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            modulus: 模数
            
        Returns:
            加法结果密文
        """
        return (ct1 * ct2) % modulus
    
    def homomorphic_add_batch(
        self,
        ciphertexts: List[int],
        modulus: int
    ) -> int:
        """
        批量同态加法
        
        Args:
            ciphertexts: 密文列表
            modulus: 模数
            
        Returns:
            求和结果密文
        """
        if not ciphertexts:
            return 1  # 乘法单位元
        
        result = ciphertexts[0]
        for ct in ciphertexts[1:]:
            result = self.homomorphic_add(result, ct, modulus)
        
        return result
    
    def homomorphic_scalar_add(self, ct: int, scalar: int, modulus: int) -> int:
        """
        同态标量加法（密文加明文）
        
        某些方案支持此操作
        
        Args:
            ct: 密文
            scalar: 明文标量
            modulus: 模数
            
        Returns:
            结果密文
        """
        # 这需要特定的同态加密方案支持
        # 简化实现：假设可以将标量编码为密文
        scalar_ct = pow(scalar + 1, 1, modulus)  # 简化的编码
        return self.homomorphic_add(ct, scalar_ct, modulus)
    
    # ==================== 通用接口 ====================
    
    def add(self, a: Union[Share, int], b: Union[Share, int], **kwargs) -> Union[Share, int]:
        """
        通用加法接口
        
        Args:
            a, b: 要相加的值（份额或密文）
            **kwargs: 额外参数
            
        Returns:
            加法结果
        """
        if self.scheme == "shamir":
            if isinstance(a, Share) and isinstance(b, Share):
                return self.shamir_add(a, b)
            elif isinstance(a, Share) and isinstance(b, int):
                return self.shamir_add_constant(a, b)
            else:
                raise ValueError("Shamir方案不支持的操作数类型")
        
        elif self.scheme == "homomorphic":
            modulus = kwargs.get('modulus', self.prime)
            if isinstance(a, int) and isinstance(b, int):
                return self.homomorphic_add(a, b, modulus)
            else:
                raise ValueError("同态方案只支持整数密文")
        
        else:
            raise ValueError(f"未知的方案: {self.scheme}")
    
    def sum_shares(self, shares: List[Share]) -> Share:
        """
        求多个份额的和
        
        Args:
            shares: 份额列表（同一索引）
            
        Returns:
            求和结果份额
        """
        if not shares:
            raise ValueError("份额列表不能为空")
        
        # 验证所有份额索引相同
        index = shares[0].index
        if not all(s.index == index for s in shares):
            raise ValueError("所有份额必须具有相同的索引")
        
        total = 0
        for share in shares:
            total = self._mod(total + share.value)
        
        return Share(value=total, index=index)
    
    def sum_ciphertexts(self, ciphertexts: List[int], modulus: int) -> int:
        """
        求多个密文的和
        
        Args:
            ciphertexts: 密文列表
            modulus: 模数
            
        Returns:
            求和结果密文
        """
        return self.homomorphic_add_batch(ciphertexts, modulus)


class SecureSubtraction:
    """
    安全减法实现
    
    基于安全加法的减法实现
    """
    
    def __init__(self, prime: int = None, scheme: str = "shamir"):
        self.prime = prime or (2**61 - 1)
        self.scheme = scheme
        self.adder = SecureAddition(prime, scheme)
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def _mod(self, x: int) -> int:
        """模运算"""
        return ((x % self.prime) + self.prime) % self.prime
    
    def shamir_subtract(self, share1: Share, share2: Share) -> Share:
        """
        Shamir秘密共享减法
        
        share1 - share2 = share1 + (-share2)
        
        Args:
            share1: 被减数份额
            share2: 减数份额
            
        Returns:
            减法结果份额
        """
        # 计算-share2
        neg_share2 = Share(
            value=self._mod(-share2.value),
            index=share2.index
        )
        
        # 相加
        return self.adder.shamir_add(share1, neg_share2)
    
    def shamir_subtract_constant(self, share: Share, constant: int) -> Share:
        """
        份额减常数
        
        Args:
            share: 份额
            constant: 常数
            
        Returns:
            减法结果份额
        """
        return self.adder.shamir_add_constant(share, self._mod(-constant))
    
    def homomorphic_subtract(self, ct1: int, ct2: int, modulus: int) -> int:
        """
        同态减法
        
        E(m1) / E(m2) = E(m1 - m2)
        
        Args:
            ct1: 被减数密文
            ct2: 减数密文
            modulus: 模数
            
        Returns:
            减法结果密文
        """
        # 计算ct2的模逆
        ct2_inv = pow(ct2, -1, modulus)
        return (ct1 * ct2_inv) % modulus


class SecureAggregation:
    """
    安全聚合
    
    支持大规模数据的安全聚合操作
    """
    
    def __init__(self, prime: int = None, scheme: str = "shamir"):
        self.prime = prime or (2**61 - 1)
        self.scheme = scheme
        self.adder = SecureAddition(prime, scheme)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"初始化安全聚合，方案: {scheme}")
    
    def aggregate_shares(
        self,
        share_groups: List[List[Share]],
        indices: List[int]
    ) -> List[Share]:
        """
        聚合多组份额
        
        Args:
            share_groups: 份额组列表，每组包含多个参与方的份额
            indices: 要聚合的索引列表
            
        Returns:
            聚合后的份额列表
        """
        results = []
        
        for idx in indices:
            # 收集该索引的所有份额
            idx_shares = []
            for group in share_groups:
                for share in group:
                    if share.index == idx:
                        idx_shares.append(share)
                        break
            
            if idx_shares:
                aggregated = self.adder.sum_shares(idx_shares)
                results.append(aggregated)
        
        self.logger.info(f"完成{len(results)}个索引的聚合")
        return results
    
    def weighted_sum(
        self,
        shares: List[Share],
        weights: List[int]
    ) -> Share:
        """
        加权求和
        
        Args:
            shares: 份额列表
            weights: 权重列表
            
        Returns:
            加权求和结果
        """
        if len(shares) != len(weights):
            raise ValueError("份额和权重数量不匹配")
        
        if not shares:
            raise ValueError("输入不能为空")
        
        # 验证所有份额索引相同
        index = shares[0].index
        
        weighted_shares = []
        for share, weight in zip(shares, weights):
            # 份额乘以权重
            weighted_value = ((share.value * weight) % self.prime + self.prime) % self.prime
            weighted_shares.append(Share(value=weighted_value, index=index))
        
        return self.adder.sum_shares(weighted_shares)


# 便捷函数
def create_secure_addition(prime: int = None, scheme: str = "shamir") -> SecureAddition:
    """创建安全加法实例"""
    return SecureAddition(prime, scheme)


def create_secure_subtraction(prime: int = None, scheme: str = "shamir") -> SecureSubtraction:
    """创建安全减法实例"""
    return SecureSubtraction(prime, scheme)


def create_secure_aggregation(prime: int = None, scheme: str = "shamir") -> SecureAggregation:
    """创建安全聚合实例"""
    return SecureAggregation(prime, scheme)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("安全加法测试")
    print("=" * 50)
    
    # 测试Shamir加法
    print("\n1. Shamir秘密共享加法:")
    adder = SecureAddition(scheme="shamir")
    
    # 创建测试份额
    shares_a = [
        Share(value=10, index=0),
        Share(value=20, index=1),
        Share(value=30, index=2),
    ]
    
    shares_b = [
        Share(value=5, index=0),
        Share(value=15, index=1),
        Share(value=25, index=2),
    ]
    
    print(f"  份额A: {shares_a}")
    print(f"  份额B: {shares_b}")
    
    results = adder.shamir_add_batch(shares_a, shares_b)
    print(f"  加法结果: {results}")
    
    # 测试同态加法
    print("\n2. 同态加法:")
    adder_homo = SecureAddition(scheme="homomorphic")
    
    # 模拟Paillier密文（简化）
    modulus = 1000000007
    ct1 = 12345
    ct2 = 67890
    
    result = adder_homo.homomorphic_add(ct1, ct2, modulus)
    print(f"  密文1: {ct1}")
    print(f"  密文2: {ct2}")
    print(f"  加法结果: {result}")
    
    # 测试安全聚合
    print("\n3. 安全聚合:")
    aggregator = SecureAggregation()
    
    share_groups = [
        [Share(value=100, index=0), Share(value=200, index=1)],
        [Share(value=50, index=0), Share(value=150, index=1)],
        [Share(value=25, index=0), Share(value=75, index=1)],
    ]
    
    aggregated = aggregator.aggregate_shares(share_groups, [0, 1])
    print(f"  输入组数: {len(share_groups)}")
    print(f"  聚合结果: {aggregated}")
    
    # 测试加权求和
    print("\n4. 加权求和:")
    shares = [Share(value=10, index=0), Share(value=20, index=0), Share(value=30, index=0)]
    weights = [1, 2, 3]
    
    weighted = aggregator.weighted_sum(shares, weights)
    print(f"  份额: {[s.value for s in shares]}")
    print(f"  权重: {weights}")
    print(f"  加权结果: {weighted}")
    
    print("\n测试完成!")
