"""
安全乘法原语

实现基于Beaver三元组和同态加密的安全乘法运算。
"""

import random
import logging
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Share:
    """秘密份额"""
    value: int
    index: int
    
    def __repr__(self) -> str:
        return f"Share(value={self.value}, index={self.index})"


@dataclass
class BeaverTriplet:
    """
    Beaver乘法三元组
    
    用于安全乘法的预计算材料
    a * b = c (mod prime)
    """
    a_shares: List[Share]  # a的份额
    b_shares: List[Share]  # b的份额
    c_shares: List[Share]  # c = a * b 的份额
    
    def __repr__(self) -> str:
        return f"BeaverTriplet(a={len(self.a_shares)}, b={len(self.b_shares)}, c={len(self.c_shares)})"


class SecureMultiplication:
    """
    安全乘法实现
    
    支持Beaver三元组方法和同态乘法
    """
    
    def __init__(self, prime: int = None, scheme: str = "beaver"):
        """
        初始化安全乘法
        
        Args:
            prime: 有限域素数
            scheme: 方案类型 ("beaver" 或 "homomorphic")
        """
        self.prime = prime or (2**61 - 1)
        self.scheme = scheme
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"初始化安全乘法，方案: {scheme}")
        
        # 缓存的三元组
        self._triplet_cache: List[BeaverTriplet] = []
    
    def _mod(self, x: int) -> int:
        """模运算"""
        return ((x % self.prime) + self.prime) % self.prime
    
    # ==================== Beaver三元组方法 ====================
    
    def generate_beaver_triplet(self, n: int, t: int) -> BeaverTriplet:
        """
        生成Beaver乘法三元组
        
        生成随机a, b，计算c = a * b，然后分别共享
        
        Args:
            n: 份额数量
            t: 阈值
            
        Returns:
            Beaver三元组
        """
        # 生成随机a和b
        a = random.randint(0, self.prime - 1)
        b = random.randint(0, self.prime - 1)
        c = self._mod(a * b)
        
        # 分割成份额（简化实现，使用加法共享）
        a_shares = self._additive_share(a, n)
        b_shares = self._additive_share(b, n)
        c_shares = self._additive_share(c, n)
        
        triplet = BeaverTriplet(
            a_shares=a_shares,
            b_shares=b_shares,
            c_shares=c_shares
        )
        
        self.logger.debug(f"生成Beaver三元组: a={a}, b={b}, c={c}")
        return triplet
    
    def _additive_share(self, secret: int, n: int) -> List[Share]:
        """
        加法秘密共享
        
        将秘密分割为n个份额，使得秘密 = 份额之和 mod prime
        
        Args:
            secret: 要共享的秘密
            n: 份额数量
            
        Returns:
            份额列表
        """
        shares = []
        total = 0
        
        # 生成n-1个随机份额
        for i in range(n - 1):
            share_value = random.randint(0, self.prime - 1)
            shares.append(Share(value=share_value, index=i))
            total = self._mod(total + share_value)
        
        # 最后一个份额使得总和等于秘密
        last_share = self._mod(secret - total)
        shares.append(Share(value=last_share, index=n - 1))
        
        return shares
    
    def beaver_multiply(
        self,
        x_shares: List[Share],
        y_shares: List[Share],
        triplet: BeaverTriplet
    ) -> List[Share]:
        """
        使用Beaver三元组进行安全乘法
        
        计算 x * y 而不暴露x和y
        
        协议：
        1. 计算 [d] = [x] - [a]
        2. 计算 [e] = [y] - [b]
        3. 重构d和e
        4. 计算 [z] = [c] + d*[b] + e*[a] + d*e
        
        Args:
            x_shares: x的份额
            y_shares: y的份额
            triplet: Beaver三元组
            
        Returns:
            z = x * y 的份额
        """
        if len(x_shares) != len(y_shares) or len(x_shares) != len(triplet.a_shares):
            raise ValueError("份额数量不匹配")
        
        n = len(x_shares)
        
        # 步骤1: 计算 [d] = [x] - [a]
        d_shares = []
        for i in range(n):
            d_val = self._mod(x_shares[i].value - triplet.a_shares[i].value)
            d_shares.append(Share(value=d_val, index=i))
        
        # 步骤2: 计算 [e] = [y] - [b]
        e_shares = []
        for i in range(n):
            e_val = self._mod(y_shares[i].value - triplet.b_shares[i].value)
            e_shares.append(Share(value=e_val, index=i))
        
        # 步骤3: 重构d和e（这里简化处理，实际应使用安全重构协议）
        d = self._reconstruct_additive(d_shares)
        e = self._reconstruct_additive(e_shares)
        
        # 步骤4: 计算 [z] = [c] + d*[b] + e*[a] + d*e
        z_shares = []
        for i in range(n):
            # [c]
            z_val = triplet.c_shares[i].value
            
            # + d*[b]
            z_val = self._mod(z_val + self._mod(d * triplet.b_shares[i].value))
            
            # + e*[a]
            z_val = self._mod(z_val + self._mod(e * triplet.a_shares[i].value))
            
            # + d*e (只有份额0加上这个值)
            if i == 0:
                z_val = self._mod(z_val + self._mod(d * e))
            
            z_shares.append(Share(value=z_val, index=i))
        
        self.logger.debug(f"完成Beaver乘法: d={d}, e={e}")
        return z_shares
    
    def _reconstruct_additive(self, shares: List[Share]) -> int:
        """从加法份额重构秘密"""
        total = 0
        for share in shares:
            total = self._mod(total + share.value)
        return total
    
    def precompute_triplets(self, count: int, n: int, t: int) -> None:
        """
        预计算Beaver三元组
        
        Args:
            count: 三元组数量
            n: 份额数量
            t: 阈值
        """
        self._triplet_cache = []
        for _ in range(count):
            triplet = self.generate_beaver_triplet(n, t)
            self._triplet_cache.append(triplet)
        
        self.logger.info(f"预计算了{count}个Beaver三元组")
    
    def get_triplet(self) -> Optional[BeaverTriplet]:
        """获取一个预计算的三元组"""
        if self._triplet_cache:
            return self._triplet_cache.pop()
        return None
    
    # ==================== 同态乘法 ====================
    
    def homomorphic_multiply(self, ct1: int, ct2: int, modulus: int) -> int:
        """
        同态乘法
        
        对于乘法同态加密：E(m1) ^ E(m2) = E(m1 * m2)
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            modulus: 模数
            
        Returns:
            乘法结果密文
        """
        # 对于支持乘法的同态加密（如BFV）
        return pow(ct1, 1, modulus) * pow(ct2, 1, modulus) % modulus
    
    def homomorphic_scalar_multiply(self, ct: int, scalar: int, modulus: int) -> int:
        """
        同态标量乘法（密文乘以明文）
        
        E(m) ^ k = E(m * k)
        
        Args:
            ct: 密文
            scalar: 标量
            modulus: 模数
            
        Returns:
            乘法结果密文
        """
        return pow(ct, scalar, modulus)
    
    def homomorphic_multiply_batch(
        self,
        ciphertexts: List[int],
        modulus: int
    ) -> int:
        """
        批量同态乘法
        
        Args:
            ciphertexts: 密文列表
            modulus: 模数
            
        Returns:
            乘积结果密文
        """
        if not ciphertexts:
            return 1
        
        result = ciphertexts[0]
        for ct in ciphertexts[1:]:
            result = self.homomorphic_multiply(result, ct, modulus)
        
        return result
    
    # ==================== 通用接口 ====================
    
    def multiply(
        self,
        x: List[Share],
        y: List[Share],
        **kwargs
    ) -> List[Share]:
        """
        通用乘法接口
        
        Args:
            x, y: 要相乘的份额
            **kwargs: 额外参数
            
        Returns:
            乘法结果份额
        """
        if self.scheme == "beaver":
            triplet = kwargs.get('triplet') or self.get_triplet()
            if triplet is None:
                raise ValueError("Beaver方案需要三元组")
            return self.beaver_multiply(x, y, triplet)
        
        elif self.scheme == "homomorphic":
            raise ValueError("同态乘法不支持份额输入")
        
        else:
            raise ValueError(f"未知的方案: {self.scheme}")


class MatrixMultiplication:
    """
    安全矩阵乘法
    
    支持安全矩阵乘法运算
    """
    
    def __init__(self, prime: int = None):
        self.prime = prime or (2**61 - 1)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.multiplier = SecureMultiplication(prime, "beaver")
    
    def _mod(self, x: int) -> int:
        """模运算"""
        return ((x % self.prime) + self.prime) % self.prime
    
    def secure_matrix_multiply(
        self,
        A_shares: List[List[List[Share]]],  # [party][row][col]
        B_shares: List[List[List[Share]]],  # [party][row][col]
        n_parties: int
    ) -> List[List[Share]]:
        """
        安全矩阵乘法
        
        计算 C = A * B
        
        Args:
            A_shares: A矩阵的份额 (每个参与方的份额)
            B_shares: B矩阵的份额
            n_parties: 参与方数量
            
        Returns:
            C矩阵的份额
        """
        # 获取矩阵维度
        rows_A = len(A_shares[0])
        cols_A = len(A_shares[0][0])
        rows_B = len(B_shares[0])
        cols_B = len(B_shares[0][0])
        
        if cols_A != rows_B:
            raise ValueError("矩阵维度不匹配")
        
        # 结果矩阵
        C_shares = [[[] for _ in range(cols_B)] for _ in range(rows_A)]
        
        # 对每个元素计算点积
        for i in range(rows_A):
            for j in range(cols_B):
                # 计算 C[i][j] = sum_k A[i][k] * B[k][j]
                
                # 收集所有参与方对(i,k)和(k,j)的份额
                products = []
                for k in range(cols_A):
                    # 获取A[i][k]和B[k][j]的份额
                    a_shares = [A_shares[p][i][k] for p in range(n_parties)]
                    b_shares = [B_shares[p][k][j] for p in range(n_parties)]
                    
                    # 安全乘法
                    triplet = self.multiplier.generate_beaver_triplet(n_parties, n_parties // 2)
                    product_shares = self.multiplier.beaver_multiply(a_shares, b_shares, triplet)
                    products.append(product_shares)
                
                # 求和
                C_shares[i][j] = self._sum_shares_list(products)
        
        self.logger.info(f"完成矩阵乘法: {rows_A}x{cols_A} * {rows_B}x{cols_B}")
        return C_shares
    
    def _sum_shares_list(self, shares_list: List[List[Share]]) -> List[Share]:
        """对多组份额逐元素求和"""
        if not shares_list:
            return []
        
        n = len(shares_list[0])
        result = []
        
        for i in range(n):
            total = 0
            for shares in shares_list:
                total = self._mod(total + shares[i].value)
            result.append(Share(value=total, index=i))
        
        return result


# 便捷函数
def create_secure_multiplication(prime: int = None, scheme: str = "beaver") -> SecureMultiplication:
    """创建安全乘法实例"""
    return SecureMultiplication(prime, scheme)


def create_matrix_multiplication(prime: int = None) -> MatrixMultiplication:
    """创建安全矩阵乘法实例"""
    return MatrixMultiplication(prime)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("安全乘法测试")
    print("=" * 50)
    
    # 测试Beaver乘法
    print("\n1. Beaver三元组乘法:")
    multiplier = SecureMultiplication(scheme="beaver")
    
    # 生成测试数据
    x = 7
    y = 3
    expected = x * y
    
    # 分割为份额
    x_shares = multiplier._additive_share(x, 3)
    y_shares = multiplier._additive_share(y, 3)
    
    print(f"  秘密x={x}, 份额: {[s.value for s in x_shares]}")
    print(f"  秘密y={y}, 份额: {[s.value for s in y_shares]}")
    
    # 生成Beaver三元组
    triplet = multiplier.generate_beaver_triplet(3, 2)
    print(f"  生成三元组: a={multiplier._reconstruct_additive(triplet.a_shares)}, "
          f"b={multiplier._reconstruct_additive(triplet.b_shares)}, "
          f"c={multiplier._reconstruct_additive(triplet.c_shares)}")
    
    # 执行乘法
    z_shares = multiplier.beaver_multiply(x_shares, y_shares, triplet)
    z = multiplier._reconstruct_additive(z_shares)
    
    print(f"  乘法结果份额: {[s.value for s in z_shares]}")
    print(f"  重构结果: {z}")
    print(f"  验证: {z} == {expected} ? {z == expected}")
    
    # 测试预计算
    print("\n2. 预计算三元组:")
    multiplier.precompute_triplets(5, 3, 2)
    print(f"  缓存三元组数量: 5")
    
    # 测试矩阵乘法
    print("\n3. 安全矩阵乘法:")
    matrix_mult = MatrixMultiplication()
    
    # 2x2矩阵
    A = [[1, 2], [3, 4]]
    B = [[5, 6], [7, 8]]
    
    # 分割为份额（简化：每个参与方一个份额）
    n_parties = 2
    A_shares = [[[Share(value=A[i][j] if p == 0 else 0, index=p) 
                  for j in range(2)] for i in range(2)] for p in range(n_parties)]
    B_shares = [[[Share(value=B[i][j] if p == 0 else 0, index=p)
                  for j in range(2)] for i in range(2)] for p in range(n_parties)]
    
    print(f"  矩阵A: {A}")
    print(f"  矩阵B: {B}")
    
    # 执行矩阵乘法
    C_shares = matrix_mult.secure_matrix_multiply(A_shares, B_shares, n_parties)
    
    # 重构结果
    C = [[matrix_mult._reconstruct_additive([C_shares[i][j][p] for p in range(n_parties)])
          for j in range(2)] for i in range(2)]
    
    print(f"  结果矩阵C: {C}")
    print(f"  期望结果: [[19, 22], [43, 50]]")
    
    print("\n测试完成!")
