"""
安全排序原语

实现安全排序算法，包括Bitonic Sort和Odd-Even Sort。
"""

import logging
from typing import List, Tuple, Optional, Callable
from dataclasses import dataclass

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Share:
    """秘密份额"""
    value: int
    index: int
    
    def __repr__(self) -> str:
        return f"Share(value={self.value}, index={self.index})"


class SecureSorting:
    """
    安全排序实现
    
    支持Bitonic Sort和Odd-Even Sort两种安全排序算法
    """
    
    def __init__(self, prime: int = None, comparison_fn: Callable = None):
        """
        初始化安全排序
        
        Args:
            prime: 有限域素数
            comparison_fn: 自定义比较函数
        """
        self.prime = prime or (2**61 - 1)
        self.comparison_fn = comparison_fn or self._default_compare
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info("初始化安全排序")
    
    def _mod(self, x: int) -> int:
        """模运算"""
        return ((x % self.prime) + self.prime) % self.prime
    
    def _default_compare(self, a: Share, b: Share) -> bool:
        """默认比较函数"""
        return a.value < b.value
    
    def _secure_compare(self, a: Share, b: Share) -> bool:
        """
        安全比较
        
        返回 a < b 的结果
        """
        return self.comparison_fn(a, b)
    
    def _secure_swap(
        self,
        arr: List[Share],
        i: int,
        j: int,
        ascending: bool = True
    ) -> None:
        """
        安全交换
        
        如果顺序不正确则交换元素
        
        Args:
            arr: 数组
            i, j: 要比较的索引
            ascending: 是否升序
        """
        should_swap = False
        
        if ascending:
            should_swap = not self._secure_compare(arr[i], arr[j])
        else:
            should_swap = self._secure_compare(arr[i], arr[j])
        
        if should_swap:
            arr[i], arr[j] = arr[j], arr[i]
    
    # ==================== Bitonic Sort ====================
    
    def bitonic_sort(
        self,
        arr: List[Share],
        ascending: bool = True
    ) -> List[Share]:
        """
        Bitonic排序
        
        时间复杂度: O(n log^2 n)
        适合并行化，常用于硬件实现
        
        Args:
            arr: 要排序的数组（份额列表）
            ascending: 是否升序
            
        Returns:
            排序后的数组
        """
        n = len(arr)
        
        # 确保长度是2的幂
        if n & (n - 1) != 0:
            # 填充到最近的2的幂
            next_power = 1
            while next_power < n:
                next_power *= 2
            
            # 填充最大值（简化处理）
            max_value = max(s.value for s in arr) if arr else 0
            while len(arr) < next_power:
                arr.append(Share(value=max_value + 1, index=len(arr)))
        
        self._bitonic_sort_recursive(arr, 0, len(arr), ascending)
        
        # 移除填充元素
        return arr[:n]
    
    def _bitonic_sort_recursive(
        self,
        arr: List[Share],
        low: int,
        count: int,
        ascending: bool
    ) -> None:
        """
        递归Bitonic排序
        
        Args:
            arr: 数组
            low: 起始索引
            count: 元素数量
            ascending: 是否升序
        """
        if count > 1:
            k = count // 2
            
            # 前半部分升序
            self._bitonic_sort_recursive(arr, low, k, True)
            
            # 后半部分降序
            self._bitonic_sort_recursive(arr, low + k, k, False)
            
            # 合并
            self._bitonic_merge(arr, low, count, ascending)
    
    def _bitonic_merge(
        self,
        arr: List[Share],
        low: int,
        count: int,
        ascending: bool
    ) -> None:
        """
        Bitonic合并
        
        Args:
            arr: 数组
            low: 起始索引
            count: 元素数量
            ascending: 是否升序
        """
        if count > 1:
            k = count // 2
            
            # 比较并交换
            for i in range(low, low + k):
                self._secure_swap(arr, i, i + k, ascending)
            
            # 递归合并
            self._bitonic_merge(arr, low, k, ascending)
            self._bitonic_merge(arr, low + k, k, ascending)
    
    # ==================== Odd-Even Sort ====================
    
    def odd_even_sort(
        self,
        arr: List[Share],
        ascending: bool = True
    ) -> List[Share]:
        """
        Odd-Even排序（奇偶排序）
        
        也称为Brick Sort，适合并行化
        时间复杂度: O(n^2)，但并行效率高
        
        Args:
            arr: 要排序的数组
            ascending: 是否升序
            
        Returns:
            排序后的数组
        """
        n = len(arr)
        is_sorted = False
        
        iteration = 0
        while not is_sorted:
            is_sorted = True
            
            # 奇数阶段
            for i in range(1, n - 1, 2):
                if ascending:
                    if not self._secure_compare(arr[i], arr[i + 1]):
                        arr[i], arr[i + 1] = arr[i + 1], arr[i]
                        is_sorted = False
                else:
                    if self._secure_compare(arr[i], arr[i + 1]):
                        arr[i], arr[i + 1] = arr[i + 1], arr[i]
                        is_sorted = False
            
            # 偶数阶段
            for i in range(0, n - 1, 2):
                if ascending:
                    if not self._secure_compare(arr[i], arr[i + 1]):
                        arr[i], arr[i + 1] = arr[i + 1], arr[i]
                        is_sorted = False
                else:
                    if self._secure_compare(arr[i], arr[i + 1]):
                        arr[i], arr[i + 1] = arr[i + 1], arr[i]
                        is_sorted = False
            
            iteration += 1
            if iteration > n * n:  # 防止无限循环
                break
        
        self.logger.debug(f"Odd-Even排序完成，迭代次数: {iteration}")
        return arr
    
    def odd_even_transposition_sort(
        self,
        arr: List[Share],
        ascending: bool = True
    ) -> List[Share]:
        """
        Odd-Even转置排序
        
        另一种实现方式
        
        Args:
            arr: 要排序的数组
            ascending: 是否升序
            
        Returns:
            排序后的数组
        """
        n = len(arr)
        
        for _ in range(n):
            # 奇数索引比较
            for i in range(1, n - 1, 2):
                self._secure_swap(arr, i, i + 1, ascending)
            
            # 偶数索引比较
            for i in range(0, n - 1, 2):
                self._secure_swap(arr, i, i + 1, ascending)
        
        return arr
    
    # ==================== 其他排序算法 ====================
    
    def bubble_sort(
        self,
        arr: List[Share],
        ascending: bool = True
    ) -> List[Share]:
        """
        冒泡排序（用于小规模数据）
        
        Args:
            arr: 要排序的数组
            ascending: 是否升序
            
        Returns:
            排序后的数组
        """
        n = len(arr)
        
        for i in range(n):
            for j in range(0, n - i - 1):
                self._secure_swap(arr, j, j + 1, ascending)
        
        return arr
    
    def selection_sort(
        self,
        arr: List[Share],
        ascending: bool = True
    ) -> List[Share]:
        """
        选择排序（用于小规模数据）
        
        Args:
            arr: 要排序的数组
            ascending: 是否升序
            
        Returns:
            排序后的数组
        """
        n = len(arr)
        
        for i in range(n):
            # 找到最小/最大值的位置
            target_idx = i
            for j in range(i + 1, n):
                if ascending:
                    if self._secure_compare(arr[j], arr[target_idx]):
                        target_idx = j
                else:
                    if not self._secure_compare(arr[j], arr[target_idx]):
                        target_idx = j
            
            # 交换
            if target_idx != i:
                arr[i], arr[target_idx] = arr[target_idx], arr[i]
        
        return arr
    
    # ==================== 高级操作 ====================
    
    def secure_median(self, arr: List[Share]) -> Share:
        """
        安全中位数
        
        Args:
            arr: 数组
            
        Returns:
            中位数
        """
        sorted_arr = self.bitonic_sort(arr[:], ascending=True)
        n = len(sorted_arr)
        
        if n % 2 == 1:
            return sorted_arr[n // 2]
        else:
            # 偶数个元素，返回中间两个的平均值（简化处理）
            return sorted_arr[n // 2 - 1]
    
    def secure_kth_element(
        self,
        arr: List[Share],
        k: int,
        ascending: bool = True
    ) -> Share:
        """
        安全第k小/大元素
        
        Args:
            arr: 数组
            k: 排名（从1开始）
            ascending: 是否找第k小
            
        Returns:
            第k个元素
        """
        sorted_arr = self.bitonic_sort(arr[:], ascending=ascending)
        
        if ascending:
            return sorted_arr[k - 1]
        else:
            return sorted_arr[k - 1]
    
    def secure_top_k(
        self,
        arr: List[Share],
        k: int,
        ascending: bool = False
    ) -> List[Share]:
        """
        安全Top-K
        
        Args:
            arr: 数组
            k: 数量
            ascending: False为Top-K最大，True为Top-K最小
            
        Returns:
            Top-K元素列表
        """
        sorted_arr = self.bitonic_sort(arr[:], ascending=ascending)
        return sorted_arr[:k]
    
    def secure_partition(
        self,
        arr: List[Share],
        pivot: Share
    ) -> Tuple[List[Share], List[Share]]:
        """
        安全分区
        
        将数组分为小于pivot和大于等于pivot两部分
        
        Args:
            arr: 数组
            pivot: 枢轴值
            
        Returns:
            (小于pivot的部分, 大于等于pivot的部分)
        """
        less = []
        greater_equal = []
        
        for elem in arr:
            if self._secure_compare(elem, pivot):
                less.append(elem)
            else:
                greater_equal.append(elem)
        
        return less, greater_equal


class ParallelSecureSorting(SecureSorting):
    """
    并行安全排序
    
    支持并行执行的安全排序
    """
    
    def __init__(self, prime: int = None, num_workers: int = 4):
        super().__init__(prime)
        self.num_workers = num_workers
        self.logger.info(f"初始化并行安全排序，工作线程: {num_workers}")
    
    def parallel_bitonic_sort(
        self,
        arr: List[Share],
        ascending: bool = True
    ) -> List[Share]:
        """
        并行Bitonic排序
        
        Args:
            arr: 要排序的数组
            ascending: 是否升序
            
        Returns:
            排序后的数组
        """
        # 简化的并行实现
        # 实际应使用多线程/多进程
        return self.bitonic_sort(arr, ascending)


# 便捷函数
def create_secure_sorting(prime: int = None, comparison_fn: Callable = None) -> SecureSorting:
    """创建安全排序实例"""
    return SecureSorting(prime, comparison_fn)


def create_parallel_sorting(prime: int = None, num_workers: int = 4) -> ParallelSecureSorting:
    """创建并行安全排序实例"""
    return ParallelSecureSorting(prime, num_workers)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("安全排序测试")
    print("=" * 50)
    
    # 创建测试数据
    test_values = [64, 34, 25, 12, 22, 11, 90, 5]
    test_shares = [Share(value=v, index=i) for i, v in enumerate(test_values)]
    
    print(f"\n原始数据: {test_values}")
    
    # 测试Bitonic Sort
    print("\n1. Bitonic Sort:")
    sorter = SecureSorting()
    
    bitonic_result = sorter.bitonic_sort(test_shares[:], ascending=True)
    bitonic_values = [s.value for s in bitonic_result]
    print(f"  升序结果: {bitonic_values}")
    
    bitonic_desc = sorter.bitonic_sort(test_shares[:], ascending=False)
    bitonic_desc_values = [s.value for s in bitonic_desc]
    print(f"  降序结果: {bitonic_desc_values}")
    
    # 测试Odd-Even Sort
    print("\n2. Odd-Even Sort:")
    
    odd_even_result = sorter.odd_even_sort(test_shares[:], ascending=True)
    odd_even_values = [s.value for s in odd_even_result]
    print(f"  升序结果: {odd_even_values}")
    
    # 测试中位数
    print("\n3. 安全中位数:")
    median = sorter.secure_median(test_shares[:])
    print(f"  中位数: {median.value}")
    
    # 测试Top-K
    print("\n4. 安全Top-K:")
    top3 = sorter.secure_top_k(test_shares[:], k=3, ascending=False)
    top3_values = [s.value for s in top3]
    print(f"  Top-3: {top3_values}")
    
    # 测试选择排序（小规模）
    print("\n5. 选择排序（小规模）:")
    small_test = [Share(value=v, index=i) for i, v in enumerate([3, 1, 4, 1, 5])]
    selection_result = sorter.selection_sort(small_test, ascending=True)
    selection_values = [s.value for s in selection_result]
    print(f"  结果: {selection_values}")
    
    print("\n测试完成!")
