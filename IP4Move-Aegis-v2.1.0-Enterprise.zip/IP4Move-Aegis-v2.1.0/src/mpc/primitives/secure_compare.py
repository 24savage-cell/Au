"""
安全比较原语

实现安全比较协议和位分解操作。
"""

import random
import logging
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Share:
    """秘密份额"""
    value: int
    index: int
    
    def __repr__(self) -> str:
        return f"Share(value={self.value}, index={self.index})"


@dataclass
class BitDecomposition:
    """位分解结果"""
    bits: List[Share]  # 从低位到高位的位份额
    bit_length: int
    
    def __repr__(self) -> str:
        return f"BitDecomposition(bits={self.bit_length})"


class SecureComparison:
    """
    安全比较实现
    
    支持多种安全比较协议
    """
    
    def __init__(self, prime: int = None, bit_length: int = 32):
        """
        初始化安全比较
        
        Args:
            prime: 有限域素数
            bit_length: 比较的位长度
        """
        self.prime = prime or (2**61 - 1)
        self.bit_length = bit_length
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"初始化安全比较，位长度: {bit_length}")
    
    def _mod(self, x: int) -> int:
        """模运算"""
        return ((x % self.prime) + self.prime) % self.prime
    
    # ==================== 位分解 ====================
    
    def bit_decompose(self, value: int, n: int) -> BitDecomposition:
        """
        将整数分解为位并进行秘密共享
        
        Args:
            value: 要分解的整数
            n: 份额数量
            
        Returns:
            位分解结果
        """
        bits = []
        
        for i in range(self.bit_length):
            # 获取第i位
            bit = (value >> i) & 1
            
            # 对位进行秘密共享
            bit_shares = self._share_bit(bit, n)
            
            # 取第一个参与方的份额作为代表
            bits.append(bit_shares[0])
        
        return BitDecomposition(bits=bits, bit_length=self.bit_length)
    
    def _share_bit(self, bit: int, n: int) -> List[Share]:
        """
        对单个位进行加法秘密共享
        
        Args:
            bit: 位值 (0 或 1)
            n: 份额数量
            
        Returns:
            份额列表
        """
        shares = []
        total = 0
        
        # 生成n-1个随机份额
        for i in range(n - 1):
            share_value = random.randint(0, 1)
            shares.append(Share(value=share_value, index=i))
            total = (total + share_value) % 2
        
        # 最后一个份额
        last_share = (bit - total) % 2
        shares.append(Share(value=last_share, index=n - 1))
        
        return shares
    
    def bit_decompose_shares(self, shares: List[Share]) -> List[BitDecomposition]:
        """
        对份额进行位分解
        
        Args:
            shares: 份额列表
            
        Returns:
            每个份额的位分解列表
        """
        results = []
        
        for share in shares:
            bit_decomp = self.bit_decompose(share.value, len(shares))
            results.append(bit_decomp)
        
        return results
    
    # ==================== 安全比较协议 ====================
    
    def greater_than(
        self,
        x_shares: List[Share],
        y_shares: List[Share]
    ) -> Share:
        """
        安全大于比较 (x > y)
        
        使用位比较协议
        
        Args:
            x_shares: x的份额
            y_shares: y的份额
            
        Returns:
            比较结果的份额 (1表示x>y，0表示x<=y)
        """
        # 重构值（简化实现，实际应使用MPC协议）
        x = self._reconstruct(x_shares)
        y = self._reconstruct(y_shares)
        
        # 执行比较
        result = 1 if x > y else 0
        
        # 返回结果份额
        return Share(value=result, index=0)
    
    def less_than(
        self,
        x_shares: List[Share],
        y_shares: List[Share]
    ) -> Share:
        """
        安全小于比较 (x < y)
        
        Args:
            x_shares: x的份额
            y_shares: y的份额
            
        Returns:
            比较结果的份额
        """
        # x < y 等价于 y > x
        return self.greater_than(y_shares, x_shares)
    
    def equal(
        self,
        x_shares: List[Share],
        y_shares: List[Share]
    ) -> Share:
        """
        安全等于比较 (x == y)
        
        Args:
            x_shares: x的份额
            y_shares: y的份额
            
        Returns:
            比较结果的份额
        """
        # 重构值
        x = self._reconstruct(x_shares)
        y = self._reconstruct(y_shares)
        
        result = 1 if x == y else 0
        return Share(value=result, index=0)
    
    def compare_bits(
        self,
        x_bits: BitDecomposition,
        y_bits: BitDecomposition
    ) -> Share:
        """
        基于位的安全比较
        
        从最高位开始比较
        
        Args:
            x_bits: x的位分解
            y_bits: y的位分解
            
        Returns:
            比较结果份额
        """
        # 从最高位开始比较
        for i in range(self.bit_length - 1, -1, -1):
            x_bit = x_bits.bits[i].value
            y_bit = y_bits.bits[i].value
            
            if x_bit > y_bit:
                return Share(value=1, index=0)
            elif x_bit < y_bit:
                return Share(value=0, index=0)
        
        # 所有位相等
        return Share(value=0, index=0)
    
    def _reconstruct(self, shares: List[Share]) -> int:
        """从份额重构秘密（加法共享）"""
        total = 0
        for share in shares:
            total = self._mod(total + share.value)
        return total
    
    # ==================== 区间比较 ====================
    
    def in_range(
        self,
        x_shares: List[Share],
        lower: int,
        upper: int
    ) -> Share:
        """
        安全区间检查 (lower <= x <= upper)
        
        Args:
            x_shares: x的份额
            lower: 下界
            upper: 上界
            
        Returns:
            比较结果份额
        """
        x = self._reconstruct(x_shares)
        
        result = 1 if lower <= x <= upper else 0
        return Share(value=result, index=0)
    
    def max_of_two(
        self,
        x_shares: List[Share],
        y_shares: List[Share]
    ) -> List[Share]:
        """
        安全求最大值
        
        max(x, y) = x * (x > y) + y * (x <= y)
        
        Args:
            x_shares: x的份额
            y_shares: y的份额
            
        Returns:
            最大值的份额
        """
        # 比较
        gt = self.greater_than(x_shares, y_shares)
        
        # 计算 max = x * gt + y * (1 - gt)
        # 简化实现
        x = self._reconstruct(x_shares)
        y = self._reconstruct(y_shares)
        
        max_val = max(x, y)
        
        # 返回份额
        return [Share(value=max_val, index=i) for i in range(len(x_shares))]
    
    def min_of_two(
        self,
        x_shares: List[Share],
        y_shares: List[Share]
    ) -> List[Share]:
        """
        安全求最小值
        
        Args:
            x_shares: x的份额
            y_shares: y的份额
            
        Returns:
            最小值的份额
        """
        x = self._reconstruct(x_shares)
        y = self._reconstruct(y_shares)
        
        min_val = min(x, y)
        
        return [Share(value=min_val, index=i) for i in range(len(x_shares))]


class SecureBitwiseOperations:
    """
    安全位运算
    
    支持AND、OR、XOR等位运算
    """
    
    def __init__(self, prime: int = None):
        self.prime = prime or (2**61 - 1)
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def _mod(self, x: int) -> int:
        """模运算"""
        return ((x % self.prime) + self.prime) % self.prime
    
    def bitwise_and(self, a: Share, b: Share) -> Share:
        """
        安全位与
        
        Args:
            a, b: 位份额
            
        Returns:
            a & b 的份额
        """
        # 简化实现：直接计算
        result = a.value & b.value
        return Share(value=result, index=a.index)
    
    def bitwise_or(self, a: Share, b: Share) -> Share:
        """
        安全位或
        
        Args:
            a, b: 位份额
            
        Returns:
            a | b 的份额
        """
        result = a.value | b.value
        return Share(value=result, index=a.index)
    
    def bitwise_xor(self, a: Share, b: Share) -> Share:
        """
        安全位异或
        
        Args:
            a, b: 位份额
            
        Returns:
            a ^ b 的份额
        """
        result = a.value ^ b.value
        return Share(value=result, index=a.index)
    
    def bitwise_not(self, a: Share) -> Share:
        """
        安全位非
        
        Args:
            a: 位份额
            
        Returns:
            ~a 的份额
        """
        result = 1 - a.value  # 对1位取反
        return Share(value=result, index=a.index)


class SecureComparisonProtocol:
    """
    安全比较协议
    
    实现完整的比较协议流程
    """
    
    def __init__(self, prime: int = None, bit_length: int = 32):
        self.prime = prime or (2**61 - 1)
        self.bit_length = bit_length
        self.comparator = SecureComparison(prime, bit_length)
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def compare_encrypted_values(
        self,
        encrypted_x: int,
        encrypted_y: int,
        comparison_type: str = "gt"
    ) -> int:
        """
        比较加密值（使用同态加密）
        
        Args:
            encrypted_x: 加密的x值
            encrypted_y: 加密的y值
            comparison_type: 比较类型 ("gt", "lt", "eq")
            
        Returns:
            比较结果
        """
        # 简化实现：假设可以解密比较
        # 实际应使用同态比较协议
        
        if comparison_type == "gt":
            return 1 if encrypted_x > encrypted_y else 0
        elif comparison_type == "lt":
            return 1 if encrypted_x < encrypted_y else 0
        elif comparison_type == "eq":
            return 1 if encrypted_x == encrypted_y else 0
        else:
            raise ValueError(f"未知的比较类型: {comparison_type}")


# 便捷函数
def create_secure_comparison(prime: int = None, bit_length: int = 32) -> SecureComparison:
    """创建安全比较实例"""
    return SecureComparison(prime, bit_length)


def create_bitwise_operations(prime: int = None) -> SecureBitwiseOperations:
    """创建安全位运算实例"""
    return SecureBitwiseOperations(prime)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("安全比较测试")
    print("=" * 50)
    
    # 测试位分解
    print("\n1. 位分解测试:")
    comparator = SecureComparison(bit_length=8)
    
    value = 42  # 00101010
    bit_decomp = comparator.bit_decompose(value, 3)
    
    print(f"  值: {value} (二进制: {bin(value)})")
    print(f"  位分解: {[b.value for b in bit_decomp.bits]}")
    
    # 重构验证
    reconstructed = sum(b.value << i for i, b in enumerate(bit_decomp.bits))
    print(f"  重构值: {reconstructed % 256}")
    
    # 测试比较
    print("\n2. 安全比较测试:")
    
    x, y = 100, 50
    x_shares = [Share(value=x, index=0), Share(value=0, index=1), Share(value=0, index=2)]
    y_shares = [Share(value=y, index=0), Share(value=0, index=1), Share(value=0, index=2)]
    
    print(f"  x={x}, y={y}")
    
    gt = comparator.greater_than(x_shares, y_shares)
    print(f"  x > y: {gt.value}")
    
    lt = comparator.less_than(x_shares, y_shares)
    print(f"  x < y: {lt.value}")
    
    eq = comparator.equal(x_shares, y_shares)
    print(f"  x == y: {eq.value}")
    
    # 测试区间检查
    print("\n3. 区间检查测试:")
    in_range = comparator.in_range(x_shares, 50, 150)
    print(f"  50 <= {x} <= 150: {in_range.value}")
    
    # 测试位运算
    print("\n4. 安全位运算测试:")
    bitwise = SecureBitwiseOperations()
    
    a = Share(value=1, index=0)
    b = Share(value=0, index=0)
    
    print(f"  a={a.value}, b={b.value}")
    print(f"  a AND b: {bitwise.bitwise_and(a, b).value}")
    print(f"  a OR b: {bitwise.bitwise_or(a, b).value}")
    print(f"  a XOR b: {bitwise.bitwise_xor(a, b).value}")
    print(f"  NOT a: {bitwise.bitwise_not(a).value}")
    
    print("\n测试完成!")
