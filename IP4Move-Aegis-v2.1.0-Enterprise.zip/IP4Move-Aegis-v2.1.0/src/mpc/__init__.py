"""
安全多方计算 (MPC) 模块

提供安全的多方计算协议和原语，支持隐私保护计算场景。
"""

from .protocols.secret_sharing import ShamirSecretSharing, VSSScheme
from .protocols.garbled_circuits import GarbledCircuit, CircuitGenerator
from .protocols.oblivious_transfer import ObliviousTransfer, RandomOT
from .protocols.homomorphic_mpc import HomomorphicMPC
from .primitives.secure_add import SecureAddition
from .primitives.secure_multiply import SecureMultiplication, BeaverTriplet
from .primitives.secure_compare import SecureComparison
from .primitives.secure_sort import SecureSorting
from .applications.private_auction import PrivateAuction, VickreyAuction
from .applications.secure_aggregation import SecureAggregation
from .applications.private_set_intersection import PrivateSetIntersection
from .coordination.mpc_coordinator import MPCCoordinator
from .coordination.party_manager import PartyManager

__version__ = "1.0.0"
__all__ = [
    "ShamirSecretSharing",
    "VSSScheme", 
    "GarbledCircuit",
    "CircuitGenerator",
    "ObliviousTransfer",
    "RandomOT",
    "HomomorphicMPC",
    "SecureAddition",
    "SecureMultiplication",
    "BeaverTriplet",
    "SecureComparison",
    "SecureSorting",
    "PrivateAuction",
    "VickreyAuction",
    "SecureAggregation",
    "PrivateSetIntersection",
    "MPCCoordinator",
    "PartyManager",
]
