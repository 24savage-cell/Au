"""
隐私拍卖实现

支持密封出价拍卖和Vickrey拍卖（第二价格密封拍卖）。
"""

import random
import hashlib
import logging
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AuctionType(Enum):
    """拍卖类型"""
    SEALED_BID = "sealed_bid"  # 密封出价
    VICKREY = "vickrey"        # Vickrey拍卖（第二价格）
    ENGLISH = "english"        # 英式拍卖
    DUTCH = "dutch"            # 荷兰式拍卖


@dataclass
class Bid:
    """出价数据结构"""
    bidder_id: str
    amount: int
    timestamp: datetime
    commitment: Optional[str] = None  # 出价承诺
    revealed: bool = False
    
    def __repr__(self) -> str:
        return f"Bid(bidder={self.bidder_id}, amount={self.amount}, revealed={self.revealed})"


@dataclass
class BidCommitment:
    """出价承诺"""
    bidder_id: str
    commitment: str
    timestamp: datetime
    
    def verify(self, bid: Bid, nonce: str) -> bool:
        """验证承诺"""
        expected = self._create_commitment(bid.bidder_id, bid.amount, nonce)
        return expected == self.commitment
    
    @staticmethod
    def _create_commitment(bidder_id: str, amount: int, nonce: str) -> str:
        """创建承诺"""
        data = f"{bidder_id}:{amount}:{nonce}"
        return hashlib.sha256(data.encode()).hexdigest()


@dataclass
class AuctionResult:
    """拍卖结果"""
    winner_id: Optional[str]
    winning_bid: Optional[int]
    second_highest_bid: Optional[int]
    final_price: Optional[int]
    all_bids: List[Bid] = field(default_factory=list)
    
    def __repr__(self) -> str:
        return (f"AuctionResult(winner={self.winner_id}, "
                f"price={self.final_price})")


class PrivateAuction:
    """
    隐私拍卖基类
    
    实现密封出价拍卖的基本功能
    """
    
    def __init__(
        self,
        auction_id: str,
        auction_type: AuctionType = AuctionType.SEALED_BID,
        min_bid: int = 0,
        max_bid: int = 1000000
    ):
        """
        初始化隐私拍卖
        
        Args:
            auction_id: 拍卖ID
            auction_type: 拍卖类型
            min_bid: 最低出价
            max_bid: 最高出价
        """
        self.auction_id = auction_id
        self.auction_type = auction_type
        self.min_bid = min_bid
        self.max_bid = max_bid
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.bids: Dict[str, Bid] = {}
        self.commitments: Dict[str, BidCommitment] = {}
        self.is_open = True
        self.result: Optional[AuctionResult] = None
        
        self.logger.info(f"创建拍卖 {auction_id}, 类型: {auction_type.value}")
    
    def submit_commitment(self, bidder_id: str, commitment: str) -> bool:
        """
        提交出价承诺
        
        Args:
            bidder_id: 出价者ID
            commitment: 承诺值
            
        Returns:
            提交是否成功
        """
        if not self.is_open:
            self.logger.warning(f"拍卖 {self.auction_id} 已关闭")
            return False
        
        if bidder_id in self.commitments:
            self.logger.warning(f"出价者 {bidder_id} 已提交承诺")
            return False
        
        self.commitments[bidder_id] = BidCommitment(
            bidder_id=bidder_id,
            commitment=commitment,
            timestamp=datetime.now()
        )
        
        self.logger.info(f"出价者 {bidder_id} 提交承诺")
        return True
    
    def reveal_bid(self, bidder_id: str, amount: int, nonce: str) -> bool:
        """
        揭示出价
        
        Args:
            bidder_id: 出价者ID
            amount: 出价金额
            nonce: 随机数
            
        Returns:
            揭示是否成功
        """
        if bidder_id not in self.commitments:
            self.logger.warning(f"出价者 {bidder_id} 未提交承诺")
            return False
        
        commitment = self.commitments[bidder_id]
        
        # 验证承诺
        bid = Bid(
            bidder_id=bidder_id,
            amount=amount,
            timestamp=datetime.now()
        )
        
        if not commitment.verify(bid, nonce):
            self.logger.warning(f"出价者 {bidder_id} 承诺验证失败")
            return False
        
        # 验证出价范围
        if amount < self.min_bid or amount > self.max_bid:
            self.logger.warning(f"出价 {amount} 超出范围 [{self.min_bid}, {self.max_bid}]")
            return False
        
        bid.revealed = True
        bid.commitment = commitment.commitment
        self.bids[bidder_id] = bid
        
        self.logger.info(f"出价者 {bidder_id} 揭示出价: {amount}")
        return True
    
    def close_auction(self) -> AuctionResult:
        """
        关闭拍卖并计算结果
        
        Returns:
            拍卖结果
        """
        self.is_open = False
        
        if not self.bids:
            self.result = AuctionResult(
                winner_id=None,
                winning_bid=None,
                second_highest_bid=None,
                final_price=None,
                all_bids=[]
            )
            return self.result
        
        # 排序出价
        sorted_bids = sorted(self.bids.values(), key=lambda b: b.amount, reverse=True)
        
        winner = sorted_bids[0]
        second_highest = sorted_bids[1].amount if len(sorted_bids) > 1 else self.min_bid
        
        self.result = AuctionResult(
            winner_id=winner.bidder_id,
            winning_bid=winner.amount,
            second_highest_bid=second_highest,
            final_price=winner.amount,  # 第一价格
            all_bids=sorted_bids
        )
        
        self.logger.info(f"拍卖 {self.auction_id} 结束，赢家: {winner.bidder_id}")
        return self.result
    
    def get_winner(self) -> Optional[str]:
        """获取赢家"""
        if self.result:
            return self.result.winner_id
        return None
    
    def get_final_price(self) -> Optional[int]:
        """获取最终价格"""
        if self.result:
            return self.result.final_price
        return None


class VickreyAuction(PrivateAuction):
    """
    Vickrey拍卖（第二价格密封拍卖）
    
    赢家支付第二高的出价
    """
    
    def __init__(
        self,
        auction_id: str,
        min_bid: int = 0,
        max_bid: int = 1000000
    ):
        super().__init__(
            auction_id=auction_id,
            auction_type=AuctionType.VICKREY,
            min_bid=min_bid,
            max_bid=max_bid
        )
        self.logger.info("初始化Vickrey拍卖")
    
    def close_auction(self) -> AuctionResult:
        """
        关闭Vickrey拍卖
        
        赢家支付第二高的价格
        
        Returns:
            拍卖结果
        """
        self.is_open = False
        
        if not self.bids:
            self.result = AuctionResult(
                winner_id=None,
                winning_bid=None,
                second_highest_bid=None,
                final_price=None,
                all_bids=[]
            )
            return self.result
        
        # 排序出价
        sorted_bids = sorted(self.bids.values(), key=lambda b: b.amount, reverse=True)
        
        winner = sorted_bids[0]
        second_highest = sorted_bids[1].amount if len(sorted_bids) > 1 else self.min_bid
        
        self.result = AuctionResult(
            winner_id=winner.bidder_id,
            winning_bid=winner.amount,
            second_highest_bid=second_highest,
            final_price=second_highest,  # Vickrey: 支付第二高价
            all_bids=sorted_bids
        )
        
        self.logger.info(
            f"Vickrey拍卖 {self.auction_id} 结束，"
            f"赢家: {winner.bidder_id}, "
            f"出价: {winner.amount}, "
            f"支付: {second_highest}"
        )
        return self.result


class SecureAuctionProtocol:
    """
    安全拍卖协议
    
    使用MPC技术保护出价隐私
    """
    
    def __init__(self, auction_id: str, num_parties: int = 3):
        """
        初始化安全拍卖协议
        
        Args:
            auction_id: 拍卖ID
            num_parties: 参与方数量
        """
        self.auction_id = auction_id
        self.num_parties = num_parties
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.encrypted_bids: Dict[str, List[int]] = {}  # 加密出价份额
        self.bidder_ids: List[str] = []
        
        self.logger.info(f"初始化安全拍卖协议，参与方: {num_parties}")
    
    def submit_encrypted_bid(self, bidder_id: str, encrypted_shares: List[int]) -> bool:
        """
        提交加密出价
        
        Args:
            bidder_id: 出价者ID
            encrypted_shares: 加密份额列表
            
        Returns:
            提交是否成功
        """
        if len(encrypted_shares) != self.num_parties:
            self.logger.warning("份额数量不匹配")
            return False
        
        self.encrypted_bids[bidder_id] = encrypted_shares
        self.bidder_ids.append(bidder_id)
        
        self.logger.info(f"出价者 {bidder_id} 提交加密出价")
        return True
    
    def secure_comparison(self, bid1_shares: List[int], bid2_shares: List[int]) -> bool:
        """
        安全比较两个加密出价
        
        Args:
            bid1_shares: 第一个出价的份额
            bid2_shares: 第二个出价的份额
            
        Returns:
            bid1 > bid2
        """
        # 简化的实现：重构后比较
        # 实际应使用MPC比较协议
        bid1 = sum(bid1_shares)
        bid2 = sum(bid2_shares)
        return bid1 > bid2
    
    def find_winner_secure(self) -> Tuple[Optional[str], Optional[int]]:
        """
        安全找出赢家
        
        Returns:
            (赢家ID, 出价)
        """
        if not self.encrypted_bids:
            return None, None
        
        # 简化实现：线性扫描找最大
        winner_id = None
        winner_shares = None
        
        for bidder_id, shares in self.encrypted_bids.items():
            if winner_shares is None:
                winner_id = bidder_id
                winner_shares = shares
            else:
                if self.secure_comparison(shares, winner_shares):
                    winner_id = bidder_id
                    winner_shares = shares
        
        winning_bid = sum(winner_shares) if winner_shares else 0
        
        return winner_id, winning_bid
    
    def find_second_highest_secure(self, winner_id: str) -> int:
        """
        安全找出第二高出价
        
        Args:
            winner_id: 赢家ID
            
        Returns:
            第二高出价
        """
        second_highest = 0
        
        for bidder_id, shares in self.encrypted_bids.items():
            if bidder_id != winner_id:
                bid = sum(shares)
                if bid > second_highest:
                    second_highest = bid
        
        return second_highest


class AuctionManager:
    """
    拍卖管理器
    
    管理多个拍卖活动
    """
    
    def __init__(self):
        self.auctions: Dict[str, PrivateAuction] = {}
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def create_auction(
        self,
        auction_id: str,
        auction_type: AuctionType = AuctionType.SEALED_BID,
        min_bid: int = 0,
        max_bid: int = 1000000
    ) -> PrivateAuction:
        """
        创建拍卖
        
        Args:
            auction_id: 拍卖ID
            auction_type: 拍卖类型
            min_bid: 最低出价
            max_bid: 最高出价
            
        Returns:
            拍卖实例
        """
        if auction_type == AuctionType.VICKREY:
            auction = VickreyAuction(auction_id, min_bid, max_bid)
        else:
            auction = PrivateAuction(auction_id, auction_type, min_bid, max_bid)
        
        self.auctions[auction_id] = auction
        self.logger.info(f"创建拍卖 {auction_id}")
        
        return auction
    
    def get_auction(self, auction_id: str) -> Optional[PrivateAuction]:
        """获取拍卖"""
        return self.auctions.get(auction_id)
    
    def list_auctions(self) -> List[str]:
        """列出所有拍卖"""
        return list(self.auctions.keys())
    
    def close_all_auctions(self) -> Dict[str, AuctionResult]:
        """关闭所有拍卖"""
        results = {}
        for auction_id, auction in self.auctions.items():
            if auction.is_open:
                results[auction_id] = auction.close_auction()
        return results


# 便捷函数
def create_sealed_bid_auction(
    auction_id: str,
    min_bid: int = 0,
    max_bid: int = 1000000
) -> PrivateAuction:
    """创建密封出价拍卖"""
    return PrivateAuction(auction_id, AuctionType.SEALED_BID, min_bid, max_bid)


def create_vickrey_auction(
    auction_id: str,
    min_bid: int = 0,
    max_bid: int = 1000000
) -> VickreyAuction:
    """创建Vickrey拍卖"""
    return VickreyAuction(auction_id, min_bid, max_bid)


def create_auction_manager() -> AuctionManager:
    """创建拍卖管理器"""
    return AuctionManager()


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("隐私拍卖测试")
    print("=" * 50)
    
    # 测试密封出价拍卖
    print("\n1. 密封出价拍卖:")
    auction1 = create_sealed_bid_auction("auction_001", min_bid=100, max_bid=10000)
    
    # 模拟出价
    bidders = [
        ("Alice", 500, "nonce1"),
        ("Bob", 700, "nonce2"),
        ("Charlie", 600, "nonce3"),
    ]
    
    for bidder_id, amount, nonce in bidders:
        # 创建承诺
        commitment_data = f"{bidder_id}:{amount}:{nonce}"
        commitment = hashlib.sha256(commitment_data.encode()).hexdigest()
        
        # 提交承诺
        auction1.submit_commitment(bidder_id, commitment)
        
        # 揭示出价
        auction1.reveal_bid(bidder_id, amount, nonce)
    
    # 关闭拍卖
    result1 = auction1.close_auction()
    print(f"  赢家: {result1.winner_id}")
    print(f"  最高出价: {result1.winning_bid}")
    print(f"  最终价格: {result1.final_price}")
    
    # 测试Vickrey拍卖
    print("\n2. Vickrey拍卖（第二价格）:")
    auction2 = create_vickrey_auction("auction_002", min_bid=100, max_bid=10000)
    
    for bidder_id, amount, nonce in bidders:
        commitment_data = f"{bidder_id}:{amount}:{nonce}"
        commitment = hashlib.sha256(commitment_data.encode()).hexdigest()
        
        auction2.submit_commitment(bidder_id, commitment)
        auction2.reveal_bid(bidder_id, amount, nonce)
    
    result2 = auction2.close_auction()
    print(f"  赢家: {result2.winner_id}")
    print(f"  最高出价: {result2.winning_bid}")
    print(f"  第二高价: {result2.second_highest_bid}")
    print(f"  最终价格（支付）: {result2.final_price}")
    
    # 测试拍卖管理器
    print("\n3. 拍卖管理器:")
    manager = create_auction_manager()
    
    auction3 = manager.create_auction("auction_003", AuctionType.SEALED_BID)
    auction4 = manager.create_auction("auction_004", AuctionType.VICKREY)
    
    print(f"  创建的拍卖: {manager.list_auctions()}")
    
    print("\n测试完成!")
