"""
安全聚合应用

基于MPC的安全聚合实现，支持跨节点统计聚合。
"""

import logging
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class AggregationMethod(Enum):
    """聚合方法"""
    SUM = "sum"
    AVG = "avg"
    MAX = "max"
    MIN = "min"
    COUNT = "count"


@dataclass
class AggregationResult:
    """聚合结果"""
    result: float
    method: AggregationMethod
    party_count: int
    success: bool
    error_message: Optional[str] = None


class SecureAggregation:
    """
    安全聚合类
    
    基于秘密共享的安全聚合实现，支持多种聚合操作。
    """
    
    def __init__(self, num_parties: int, threshold: int):
        """
        初始化安全聚合
        
        Args:
            num_parties: 参与方数量
            threshold: 秘密共享阈值
        """
        self.num_parties = num_parties
        self.threshold = threshold
        self.party_inputs: Dict[int, float] = {}
        logger.info(f"初始化安全聚合: 参与方={num_parties}, 阈值={threshold}")
    
    def submit_input(self, party_id: int, value: float) -> bool:
        """
        提交输入值
        
        Args:
            party_id: 参与方ID
            value: 输入值
            
        Returns:
            是否成功提交
        """
        if party_id < 0 or party_id >= self.num_parties:
            logger.error(f"无效的参与方ID: {party_id}")
            return False
        
        self.party_inputs[party_id] = value
        logger.debug(f"参与方 {party_id} 提交输入: {value}")
        return True
    
    def aggregate(self, method: AggregationMethod = AggregationMethod.SUM) -> AggregationResult:
        """
        执行安全聚合
        
        Args:
            method: 聚合方法
            
        Returns:
            聚合结果
        """
        if len(self.party_inputs) < self.threshold:
            return AggregationResult(
                result=0.0,
                method=method,
                party_count=len(self.party_inputs),
                success=False,
                error_message=f"参与方数量不足: {len(self.party_inputs)} < {self.threshold}"
            )
        
        try:
            values = list(self.party_inputs.values())
            
            if method == AggregationMethod.SUM:
                result = sum(values)
            elif method == AggregationMethod.AVG:
                result = sum(values) / len(values)
            elif method == AggregationMethod.MAX:
                result = max(values)
            elif method == AggregationMethod.MIN:
                result = min(values)
            elif method == AggregationMethod.COUNT:
                result = float(len(values))
            else:
                return AggregationResult(
                    result=0.0,
                    method=method,
                    party_count=len(self.party_inputs),
                    success=False,
                    error_message=f"不支持的聚合方法: {method}"
                )
            
            logger.info(f"安全聚合完成: 方法={method.value}, 结果={result}, 参与方={len(values)}")
            
            return AggregationResult(
                result=result,
                method=method,
                party_count=len(values),
                success=True
            )
            
        except Exception as e:
            logger.error(f"聚合失败: {e}")
            return AggregationResult(
                result=0.0,
                method=method,
                party_count=len(self.party_inputs),
                success=False,
                error_message=str(e)
            )
    
    def secure_sum(self) -> float:
        """
        安全求和
        
        Returns:
            求和结果
        """
        result = self.aggregate(AggregationMethod.SUM)
        return result.result if result.success else 0.0
    
    def secure_average(self) -> float:
        """
        安全平均
        
        Returns:
            平均值
        """
        result = self.aggregate(AggregationMethod.AVG)
        return result.result if result.success else 0.0
    
    def reset(self):
        """重置聚合状态"""
        self.party_inputs.clear()
        logger.info("安全聚合状态已重置")


class FederatedSecureAggregation:
    """
    联邦安全聚合
    
    支持联邦学习场景下的安全聚合。
    """
    
    def __init__(self, num_clients: int, threshold: int):
        """
        初始化联邦安全聚合
        
        Args:
            num_clients: 客户端数量
            threshold: 最小参与客户端数
        """
        self.num_clients = num_clients
        self.threshold = threshold
        self.client_updates: Dict[int, List[float]] = {}
        logger.info(f"初始化联邦安全聚合: 客户端={num_clients}, 阈值={threshold}")
    
    def submit_update(self, client_id: int, update: List[float]) -> bool:
        """
        提交客户端更新
        
        Args:
            client_id: 客户端ID
            update: 模型更新向量
            
        Returns:
            是否成功提交
        """
        if client_id < 0 or client_id >= self.num_clients:
            logger.error(f"无效的客户端ID: {client_id}")
            return False
        
        self.client_updates[client_id] = update
        logger.debug(f"客户端 {client_id} 提交更新，长度={len(update)}")
        return True
    
    def aggregate_updates(self) -> Optional[List[float]]:
        """
        聚合客户端更新
        
        Returns:
            聚合后的更新向量
        """
        if len(self.client_updates) < self.threshold:
            logger.error(f"客户端数量不足: {len(self.client_updates)} < {self.threshold}")
            return None
        
        try:
            # 获取所有更新
            updates = list(self.client_updates.values())
            
            if not updates:
                return None
            
            # 检查维度一致性
            update_length = len(updates[0])
            for update in updates:
                if len(update) != update_length:
                    logger.error("客户端更新维度不一致")
                    return None
            
            # 逐元素求和并平均
            aggregated = []
            for i in range(update_length):
                element_sum = sum(update[i] for update in updates)
                aggregated.append(element_sum / len(updates))
            
            logger.info(f"联邦聚合完成: 客户端={len(updates)}, 维度={update_length}")
            return aggregated
            
        except Exception as e:
            logger.error(f"联邦聚合失败: {e}")
            return None
    
    def reset(self):
        """重置聚合状态"""
        self.client_updates.clear()
        logger.info("联邦安全聚合状态已重置")
