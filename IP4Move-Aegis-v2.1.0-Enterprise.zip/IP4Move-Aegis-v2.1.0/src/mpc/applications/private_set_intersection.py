"""
隐私集合求交 (PSI)

支持多方的隐私集合求交协议实现。
"""

import logging
import hashlib
from typing import List, Set, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class PSIMethod(Enum):
    """PSI方法"""
    HASH_BASED = "hash_based"
    OT_BASED = "ot_based"
    DH_BASED = "dh_based"


@dataclass
class PSIResult:
    """PSI结果"""
    intersection: Set[str]
    party_count: int
    success: bool
    error_message: Optional[str] = None


class PrivateSetIntersection:
    """
    隐私集合求交类
    
    支持多种PSI协议实现。
    """
    
    def __init__(self, method: PSIMethod = PSIMethod.HASH_BASED):
        """
        初始化PSI
        
        Args:
            method: PSI方法
        """
        self.method = method
        self.party_sets: Dict[int, Set[str]] = {}
        logger.info(f"初始化PSI: 方法={method.value}")
    
    def submit_set(self, party_id: int, data_set: Set[str]) -> bool:
        """
        提交参与方集合
        
        Args:
            party_id: 参与方ID
            data_set: 数据集合
            
        Returns:
            是否成功提交
        """
        self.party_sets[party_id] = data_set
        logger.debug(f"参与方 {party_id} 提交集合，大小={len(data_set)}")
        return True
    
    def compute_intersection(self) -> PSIResult:
        """
        计算交集
        
        Returns:
            PSI结果
        """
        if len(self.party_sets) < 2:
            return PSIResult(
                intersection=set(),
                party_count=len(self.party_sets),
                success=False,
                error_message="至少需要2个参与方"
            )
        
        try:
            if self.method == PSIMethod.HASH_BASED:
                intersection = self._hash_based_psi()
            elif self.method == PSIMethod.OT_BASED:
                intersection = self._ot_based_psi()
            elif self.method == PSIMethod.DH_BASED:
                intersection = self._dh_based_psi()
            else:
                return PSIResult(
                    intersection=set(),
                    party_count=len(self.party_sets),
                    success=False,
                    error_message=f"不支持的PSI方法: {self.method}"
                )
            
            logger.info(f"PSI计算完成: 交集大小={len(intersection)}, 参与方={len(self.party_sets)}")
            
            return PSIResult(
                intersection=intersection,
                party_count=len(self.party_sets),
                success=True
            )
            
        except Exception as e:
            logger.error(f"PSI计算失败: {e}")
            return PSIResult(
                intersection=set(),
                party_count=len(self.party_sets),
                success=False,
                error_message=str(e)
            )
    
    def _hash_based_psi(self) -> Set[str]:
        """
        基于哈希的PSI
        
        Returns:
            交集
        """
        # 简单的哈希PSI实现
        hashed_sets = []
        for party_id, data_set in self.party_sets.items():
            hashed = {hashlib.sha256(item.encode()).hexdigest() for item in data_set}
            hashed_sets.append(hashed)
        
        # 计算交集
        intersection = hashed_sets[0]
        for hashed_set in hashed_sets[1:]:
            intersection = intersection.intersection(hashed_set)
        
        # 将哈希值映射回原始值
        result = set()
        for party_id, data_set in self.party_sets.items():
            for item in data_set:
                item_hash = hashlib.sha256(item.encode()).hexdigest()
                if item_hash in intersection:
                    result.add(item)
        
        return result
    
    def _ot_based_psi(self) -> Set[str]:
        """
        基于OT的PSI
        
        Returns:
            交集
        """
        # 简化实现，实际应使用OT协议
        logger.debug("使用OT-based PSI")
        return self._hash_based_psi()
    
    def _dh_based_psi(self) -> Set[str]:
        """
        基于DH的PSI
        
        Returns:
            交集
        """
        # 简化实现，实际应使用DH密钥交换
        logger.debug("使用DH-based PSI")
        return self._hash_based_psi()
    
    def compute_cardinality(self) -> int:
        """
        计算交集大小（不泄露具体元素）
        
        Returns:
            交集大小
        """
        result = self.compute_intersection()
        return len(result.intersection) if result.success else 0
    
    def reset(self):
        """重置PSI状态"""
        self.party_sets.clear()
        logger.info("PSI状态已重置")


class MultiPartyPSI:
    """
    多方PSI
    
    支持多方的隐私集合求交。
    """
    
    def __init__(self, num_parties: int):
        """
        初始化多方PSI
        
        Args:
            num_parties: 参与方数量
        """
        self.num_parties = num_parties
        self.psi = PrivateSetIntersection()
        logger.info(f"初始化多方PSI: 参与方={num_parties}")
    
    def add_party_set(self, party_id: int, data_set: Set[str]) -> bool:
        """
        添加参与方集合
        
        Args:
            party_id: 参与方ID
            data_set: 数据集合
            
        Returns:
            是否成功添加
        """
        return self.psi.submit_set(party_id, data_set)
    
    def compute(self) -> Set[str]:
        """
        计算多方交集
        
        Returns:
            交集
        """
        result = self.psi.compute_intersection()
        return result.intersection if result.success else set()
