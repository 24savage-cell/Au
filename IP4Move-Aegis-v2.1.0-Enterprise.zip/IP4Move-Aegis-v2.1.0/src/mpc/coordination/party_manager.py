"""
参与方管理器

管理MPC协议中的参与方。
"""

import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

logger = logging.getLogger(__name__)


class PartyStatus(Enum):
    """参与方状态"""
    OFFLINE = "offline"
    ONLINE = "online"
    COMPUTING = "computing"
    ERROR = "error"


@dataclass
class PartyInfo:
    """参与方信息"""
    party_id: int
    name: str
    address: str
    status: PartyStatus
    public_key: Optional[str] = None
    last_heartbeat: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class PartyManager:
    """
    参与方管理器
    
    管理MPC协议中的所有参与方。
    """
    
    def __init__(self):
        """初始化参与方管理器"""
        self.parties: Dict[int, PartyInfo] = {}
        self.online_parties: set = set()
        logger.info("初始化参与方管理器")
    
    def register_party(self, party_id: int, name: str, address: str, 
                      public_key: Optional[str] = None) -> bool:
        """
        注册参与方
        
        Args:
            party_id: 参与方ID
            name: 参与方名称
            address: 网络地址
            public_key: 公钥
            
        Returns:
            是否成功注册
        """
        if party_id in self.parties:
            logger.warning(f"参与方已存在: {party_id}")
            return False
        
        party = PartyInfo(
            party_id=party_id,
            name=name,
            address=address,
            status=PartyStatus.OFFLINE,
            public_key=public_key,
            last_heartbeat=datetime.now()
        )
        
        self.parties[party_id] = party
        logger.info(f"注册参与方: {party_id} - {name}")
        return True
    
    def unregister_party(self, party_id: int) -> bool:
        """
        注销参与方
        
        Args:
            party_id: 参与方ID
            
        Returns:
            是否成功注销
        """
        if party_id not in self.parties:
            logger.warning(f"参与方不存在: {party_id}")
            return False
        
        del self.parties[party_id]
        self.online_parties.discard(party_id)
        
        logger.info(f"注销参与方: {party_id}")
        return True
    
    def set_party_online(self, party_id: int) -> bool:
        """
        设置参与方为在线状态
        
        Args:
            party_id: 参与方ID
            
        Returns:
            是否成功设置
        """
        if party_id not in self.parties:
            logger.error(f"参与方不存在: {party_id}")
            return False
        
        self.parties[party_id].status = PartyStatus.ONLINE
        self.parties[party_id].last_heartbeat = datetime.now()
        self.online_parties.add(party_id)
        
        logger.debug(f"参与方上线: {party_id}")
        return True
    
    def set_party_offline(self, party_id: int) -> bool:
        """
        设置参与方为离线状态
        
        Args:
            party_id: 参与方ID
            
        Returns:
            是否成功设置
        """
        if party_id not in self.parties:
            logger.error(f"参与方不存在: {party_id}")
            return False
        
        self.parties[party_id].status = PartyStatus.OFFLINE
        self.online_parties.discard(party_id)
        
        logger.debug(f"参与方离线: {party_id}")
        return True
    
    def set_party_computing(self, party_id: int) -> bool:
        """
        设置参与方为计算中状态
        
        Args:
            party_id: 参与方ID
            
        Returns:
            是否成功设置
        """
        if party_id not in self.parties:
            logger.error(f"参与方不存在: {party_id}")
            return False
        
        self.parties[party_id].status = PartyStatus.COMPUTING
        logger.debug(f"参与方计算中: {party_id}")
        return True
    
    def set_party_error(self, party_id: int, error_message: str) -> bool:
        """
        设置参与方为错误状态
        
        Args:
            party_id: 参与方ID
            error_message: 错误信息
            
        Returns:
            是否成功设置
        """
        if party_id not in self.parties:
            logger.error(f"参与方不存在: {party_id}")
            return False
        
        self.parties[party_id].status = PartyStatus.ERROR
        self.parties[party_id].metadata['error'] = error_message
        self.online_parties.discard(party_id)
        
        logger.error(f"参与方错误: {party_id}, 错误={error_message}")
        return True
    
    def get_party(self, party_id: int) -> Optional[PartyInfo]:
        """
        获取参与方信息
        
        Args:
            party_id: 参与方ID
            
        Returns:
            参与方信息
        """
        return self.parties.get(party_id)
    
    def get_all_parties(self) -> List[PartyInfo]:
        """
        获取所有参与方
        
        Returns:
            参与方列表
        """
        return list(self.parties.values())
    
    def get_online_parties(self) -> List[PartyInfo]:
        """
        获取在线参与方
        
        Returns:
            在线参与方列表
        """
        return [self.parties[pid] for pid in self.online_parties if pid in self.parties]
    
    def get_party_count(self) -> int:
        """
        获取参与方数量
        
        Returns:
            参与方数量
        """
        return len(self.parties)
    
    def get_online_count(self) -> int:
        """
        获取在线参与方数量
        
        Returns:
            在线参与方数量
        """
        return len(self.online_parties)
    
    def update_heartbeat(self, party_id: int) -> bool:
        """
        更新心跳
        
        Args:
            party_id: 参与方ID
            
        Returns:
            是否成功更新
        """
        if party_id not in self.parties:
            return False
        
        self.parties[party_id].last_heartbeat = datetime.now()
        return True
    
    def check_offline_parties(self, timeout_seconds: int = 300) -> List[int]:
        """
        检查离线参与方
        
        Args:
            timeout_seconds: 超时时间（秒）
            
        Returns:
            离线参与方ID列表
        """
        offline_parties = []
        now = datetime.now()
        
        for party_id, party in self.parties.items():
            if party.last_heartbeat:
                elapsed = (now - party.last_heartbeat).total_seconds()
                if elapsed > timeout_seconds:
                    offline_parties.append(party_id)
                    self.set_party_offline(party_id)
        
        return offline_parties
