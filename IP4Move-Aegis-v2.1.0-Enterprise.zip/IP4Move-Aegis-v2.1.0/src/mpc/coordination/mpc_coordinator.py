"""
MPC协调器

提供MPC协议的协调和调度功能。
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

logger = logging.getLogger(__name__)


class ProtocolPhase(Enum):
    """协议阶段"""
    INITIALIZATION = "initialization"
    INPUT_COLLECTION = "input_collection"
    COMPUTATION = "computation"
    OUTPUT_DISTRIBUTION = "output_distribution"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ProtocolStep:
    """协议步骤"""
    step_id: str
    name: str
    description: str
    timeout_seconds: int = 60
    dependencies: List[str] = field(default_factory=list)
    completed: bool = False
    result: Any = None
    error_message: Optional[str] = None


@dataclass
class ProtocolState:
    """协议状态"""
    protocol_id: str
    phase: ProtocolPhase
    steps: Dict[str, ProtocolStep]
    start_time: datetime
    end_time: Optional[datetime] = None
    progress_percentage: float = 0.0


class MPCCoordinator:
    """
    MPC协调器
    
    协调MPC协议的执行，管理协议生命周期。
    """
    
    def __init__(self, protocol_id: str):
        """
        初始化MPC协调器
        
        Args:
            protocol_id: 协议ID
        """
        self.protocol_id = protocol_id
        self.state = ProtocolState(
            protocol_id=protocol_id,
            phase=ProtocolPhase.INITIALIZATION,
            steps={},
            start_time=datetime.now()
        )
        self.callbacks: Dict[str, List[Callable]] = {
            'phase_change': [],
            'step_complete': [],
            'error': []
        }
        logger.info(f"初始化MPC协调器: protocol_id={protocol_id}")
    
    def register_step(self, step: ProtocolStep):
        """
        注册协议步骤
        
        Args:
            step: 协议步骤
        """
        self.state.steps[step.step_id] = step
        logger.debug(f"注册步骤: {step.step_id} - {step.name}")
    
    def execute_step(self, step_id: str, execution_func: Callable[[], Any]) -> bool:
        """
        执行协议步骤
        
        Args:
            step_id: 步骤ID
            execution_func: 执行函数
            
        Returns:
            是否成功执行
        """
        if step_id not in self.state.steps:
            logger.error(f"步骤不存在: {step_id}")
            return False
        
        step = self.state.steps[step_id]
        
        try:
            logger.info(f"执行步骤: {step_id} - {step.name}")
            
            # 检查依赖
            for dep_id in step.dependencies:
                if dep_id in self.state.steps:
                    if not self.state.steps[dep_id].completed:
                        logger.error(f"依赖步骤未完成: {dep_id}")
                        return False
            
            # 执行步骤
            result = execution_func()
            step.result = result
            step.completed = True
            
            # 触发回调
            self._trigger_callback('step_complete', step_id, result)
            
            logger.info(f"步骤完成: {step_id}")
            return True
            
        except Exception as e:
            logger.error(f"步骤执行失败: {step_id}, 错误={e}")
            step.error_message = str(e)
            self._trigger_callback('error', step_id, str(e))
            return False
    
    async def execute_step_async(self, step_id: str, execution_func: Callable[[], Any]) -> bool:
        """
        异步执行协议步骤
        
        Args:
            step_id: 步骤ID
            execution_func: 执行函数
            
        Returns:
            是否成功执行
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.execute_step, step_id, execution_func)
    
    def set_phase(self, phase: ProtocolPhase):
        """
        设置协议阶段
        
        Args:
            phase: 新阶段
        """
        old_phase = self.state.phase
        self.state.phase = phase
        
        if phase == ProtocolPhase.COMPLETED or phase == ProtocolPhase.FAILED:
            self.state.end_time = datetime.now()
        
        self._update_progress()
        self._trigger_callback('phase_change', old_phase, phase)
        
        logger.info(f"协议阶段变更: {old_phase.value} -> {phase.value}")
    
    def get_progress(self) -> float:
        """
        获取协议进度
        
        Returns:
            进度百分比
        """
        return self.state.progress_percentage
    
    def _update_progress(self):
        """更新进度"""
        if not self.state.steps:
            self.state.progress_percentage = 0.0
            return
        
        completed = sum(1 for step in self.state.steps.values() if step.completed)
        total = len(self.state.steps)
        self.state.progress_percentage = (completed / total) * 100
    
    def register_callback(self, event: str, callback: Callable):
        """
        注册回调函数
        
        Args:
            event: 事件类型
            callback: 回调函数
        """
        if event in self.callbacks:
            self.callbacks[event].append(callback)
    
    def _trigger_callback(self, event: str, *args):
        """
        触发回调
        
        Args:
            event: 事件类型
            *args: 回调参数
        """
        if event in self.callbacks:
            for callback in self.callbacks[event]:
                try:
                    callback(*args)
                except Exception as e:
                    logger.error(f"回调执行失败: {e}")
    
    def get_state(self) -> ProtocolState:
        """
        获取协议状态
        
        Returns:
            协议状态
        """
        return self.state
    
    def is_completed(self) -> bool:
        """
        检查是否完成
        
        Returns:
            是否完成
        """
        return self.state.phase == ProtocolPhase.COMPLETED
    
    def is_failed(self) -> bool:
        """
        检查是否失败
        
        Returns:
            是否失败
        """
        return self.state.phase == ProtocolPhase.FAILED
