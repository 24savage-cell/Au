"""
威胁狩猎模块

提供威胁狩猎能力，包括查询模板、IOC批量搜索和行为分析。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict
import json
import re
import hashlib

# 配置日志
logger = logging.getLogger(__name__)


class HuntType(Enum):
    """狩猎类型"""
    IOC_SEARCH = "ioc_search"
    BEHAVIOR_ANALYSIS = "behavior_analysis"
    ANOMALY_DETECTION = "anomaly_detection"
    PATTERN_MATCH = "pattern_match"


@dataclass
class HuntQuery:
    """狩猎查询"""
    id: str
    name: str
    description: str
    query_template: str
    hunt_type: HuntType
    parameters: Dict[str, Any] = field(default_factory=dict)
    ioc_fields: List[str] = field(default_factory=list)
    time_range: int = 86400  # 默认时间范围（秒）
    severity: str = "medium"
    tags: List[str] = field(default_factory=list)
    enabled: bool = True


@dataclass
class HuntResult:
    """狩猎结果"""
    query_id: str
    query_name: str
    timestamp: datetime
    findings: List[Dict[str, Any]]
    ioc_matches: List[Dict[str, Any]]
    statistics: Dict[str, Any]


class ThreatHuntingEngine:
    """
    威胁狩猎引擎
    
    提供威胁狩猎能力，支持IOC批量搜索和行为分析。
    
    Example:
        >>> engine = ThreatHuntingEngine()
        >>> 
        >>> # 添加查询模板
        >>> query = HuntQuery(
        ...     id="hunt-001",
        ...     name="Suspicious PowerShell",
        ...     query_template="process.name:powershell.exe AND process.command_line:*-enc*",
        ...     hunt_type=HuntType.PATTERN_MATCH,
        ... )
        >>> engine.add_query(query)
        >>> 
        >>> # 执行狩猎
        >>> results = await engine.execute_hunt("hunt-001", data_source)
    """
    
    def __init__(self):
        """初始化威胁狩猎引擎"""
        self._queries: Dict[str, HuntQuery] = {}
        self._ioc_lists: Dict[str, List[str]] = defaultdict(list)
        self._data_source_handlers: Dict[str, Callable] = {}
        self._hunt_history: List[HuntResult] = []
    
    def add_query(self, query: HuntQuery) -> None:
        """
        添加狩猎查询
        
        Args:
            query: 狩猎查询
        """
        self._queries[query.id] = query
        logger.info(f"Hunt query added: {query.name} ({query.id})")
    
    def remove_query(self, query_id: str) -> bool:
        """
        移除狩猎查询
        
        Args:
            query_id: 查询ID
            
        Returns:
            是否成功
        """
        if query_id in self._queries:
            del self._queries[query_id]
            logger.info(f"Hunt query removed: {query_id}")
            return True
        return False
    
    def add_ioc_list(self, list_name: str, iocs: List[str]) -> None:
        """
        添加IOC列表
        
        Args:
            list_name: 列表名称
            iocs: IOC列表
        """
        self._ioc_lists[list_name] = iocs
        logger.info(f"IOC list added: {list_name} ({len(iocs)} items)")
    
    def register_data_source(
        self,
        source_name: str,
        handler: Callable[[str, Dict[str, Any]], List[Dict[str, Any]]]
    ) -> None:
        """
        注册数据源处理器
        
        Args:
            source_name: 数据源名称
            handler: 数据查询处理器
        """
        self._data_source_handlers[source_name] = handler
    
    async def execute_hunt(
        self,
        query_id: str,
        data_source: str,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> Optional[HuntResult]:
        """
        执行狩猎查询
        
        Args:
            query_id: 查询ID
            data_source: 数据源名称
            parameters: 查询参数
            
        Returns:
            狩猎结果或None
        """
        query = self._queries.get(query_id)
        if not query or not query.enabled:
            logger.error(f"Query not found or disabled: {query_id}")
            return None
        
        handler = self._data_source_handlers.get(data_source)
        if not handler:
            logger.error(f"Data source not registered: {data_source}")
            return None
        
        # 构建查询
        hunt_query = self._build_query(query, parameters)
        
        # 执行查询
        try:
            raw_results = handler(hunt_query, query.parameters)
        except Exception as e:
            logger.error(f"Hunt query execution failed: {e}")
            return None
        
        # 分析结果
        findings = self._analyze_results(query, raw_results)
        
        # IOC匹配
        ioc_matches = self._match_iocs(query, raw_results)
        
        # 统计信息
        statistics = self._calculate_statistics(raw_results)
        
        result = HuntResult(
            query_id=query.id,
            query_name=query.name,
            timestamp=datetime.utcnow(),
            findings=findings,
            ioc_matches=ioc_matches,
            statistics=statistics,
        )
        
        self._hunt_history.append(result)
        
        logger.info(f"Hunt completed: {query.name} - {len(findings)} findings")
        
        return result
    
    def _build_query(
        self,
        query: HuntQuery,
        parameters: Optional[Dict[str, Any]]
    ) -> str:
        """构建查询字符串"""
        params = {**query.parameters, **(parameters or {})}
        
        # 添加时间范围
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(seconds=query.time_range)
        params["start_time"] = start_time.isoformat()
        params["end_time"] = end_time.isoformat()
        
        # 格式化查询模板
        try:
            return query.query_template.format(**params)
        except KeyError as e:
            logger.warning(f"Missing parameter in query template: {e}")
            return query.query_template
    
    def _analyze_results(
        self,
        query: HuntQuery,
        results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """分析查询结果"""
        findings = []
        
        for result in results:
            finding = {
                "timestamp": result.get("timestamp"),
                "source": result.get("source"),
                "description": self._generate_finding_description(query, result),
                "severity": query.severity,
                "raw_data": result,
            }
            findings.append(finding)
        
        return findings
    
    def _generate_finding_description(
        self,
        query: HuntQuery,
        result: Dict[str, Any]
    ) -> str:
        """生成发现描述"""
        descriptions = {
            HuntType.IOC_SEARCH: f"IOC match found: {result.get('ioc_value', 'unknown')}",
            HuntType.BEHAVIOR_ANALYSIS: f"Suspicious behavior detected: {query.name}",
            HuntType.ANOMALY_DETECTION: f"Anomaly detected: {result.get('anomaly_score', 'N/A')}",
            HuntType.PATTERN_MATCH: f"Pattern match: {query.name}",
        }
        return descriptions.get(query.hunt_type, f"Finding: {query.name}")
    
    def _match_iocs(
        self,
        query: HuntQuery,
        results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """匹配IOC"""
        matches = []
        
        if not query.ioc_fields:
            return matches
        
        for result in results:
            for field in query.ioc_fields:
                value = self._get_field_value(result, field)
                if not value:
                    continue
                
                # 检查所有IOC列表
                for list_name, iocs in self._ioc_lists.items():
                    if str(value) in iocs:
                        matches.append({
                            "field": field,
                            "value": value,
                            "ioc_list": list_name,
                            "event": result,
                        })
        
        return matches
    
    def _calculate_statistics(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """计算统计信息"""
        return {
            "total_events": len(results),
            "unique_sources": len(set(r.get("source") for r in results if "source" in r)),
            "time_range": {
                "earliest": min((r.get("timestamp") for r in results if "timestamp" in r), default=None),
                "latest": max((r.get("timestamp") for r in results if "timestamp" in r), default=None),
            },
        }
    
    def _get_field_value(self, event: Dict[str, Any], field: str) -> Any:
        """获取嵌套字段值"""
        parts = field.split(".")
        current = event
        
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        
        return current
    
    async def batch_ioc_search(
        self,
        iocs: List[str],
        data_source: str,
        ioc_type: str = "ip",
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        批量IOC搜索
        
        Args:
            iocs: IOC列表
            data_source: 数据源名称
            ioc_type: IOC类型（ip, domain, hash, url）
            
        Returns:
            匹配结果字典
        """
        results = {}
        
        for ioc in iocs:
            # 构建IOC搜索查询
            query_template = self._get_ioc_query_template(ioc_type)
            query = HuntQuery(
                id=f"ioc-search-{hashlib.md5(ioc.encode()).hexdigest()[:8]}",
                name=f"IOC Search: {ioc}",
                description=f"Search for IOC: {ioc}",
                query_template=query_template,
                hunt_type=HuntType.IOC_SEARCH,
                parameters={"ioc_value": ioc},
                ioc_fields=[ioc_type],
            )
            
            result = await self.execute_hunt(query.id, data_source, {"ioc_value": ioc})
            
            if result and result.findings:
                results[ioc] = result.findings
        
        return results
    
    def _get_ioc_query_template(self, ioc_type: str) -> str:
        """获取IOC查询模板"""
        templates = {
            "ip": "source.ip:{ioc_value} OR destination.ip:{ioc_value}",
            "domain": "dns.question.name:{ioc_value} OR url.domain:{ioc_value}",
            "hash": "file.hash.md5:{ioc_value} OR file.hash.sha1:{ioc_value} OR file.hash.sha256:{ioc_value}",
            "url": "url.full:{ioc_value}",
        }
        return templates.get(ioc_type, "{ioc_value}")
    
    async def behavior_analysis(
        self,
        entity_type: str,
        entity_value: str,
        data_source: str,
        time_range: int = 86400,
    ) -> Dict[str, Any]:
        """
        行为分析
        
        Args:
            entity_type: 实体类型（user, host, ip）
            entity_value: 实体值
            data_source: 数据源名称
            time_range: 时间范围（秒）
            
        Returns:
            行为分析结果
        """
        # 构建行为分析查询
        field_mapping = {
            "user": "user.name",
            "host": "host.hostname",
            "ip": "source.ip",
        }
        
        field = field_mapping.get(entity_type, entity_type)
        
        query = HuntQuery(
            id=f"behavior-{entity_type}-{hashlib.md5(entity_value.encode()).hexdigest()[:8]}",
            name=f"Behavior Analysis: {entity_value}",
            description=f"Analyze behavior of {entity_type}: {entity_value}",
            query_template=f"{field}:{entity_value}",
            hunt_type=HuntType.BEHAVIOR_ANALYSIS,
            time_range=time_range,
        )
        
        result = await self.execute_hunt(query.id, data_source, {"entity_value": entity_value})
        
        if not result:
            return {}
        
        # 分析行为模式
        behavior_profile = self._analyze_behavior_pattern(result.findings)
        
        return {
            "entity_type": entity_type,
            "entity_value": entity_value,
            "time_range": time_range,
            "total_events": result.statistics["total_events"],
            "behavior_profile": behavior_profile,
            "findings": result.findings,
        }
    
    def _analyze_behavior_pattern(self, findings: List[Dict[str, Any]]) -> Dict[str, Any]:
        """分析行为模式"""
        # 统计事件类型分布
        event_types = defaultdict(int)
        time_distribution = defaultdict(int)
        
        for finding in findings:
            raw_data = finding.get("raw_data", {})
            event_type = raw_data.get("event.type", "unknown")
            event_types[event_type] += 1
            
            # 时间分布（按小时）
            timestamp = raw_data.get("timestamp")
            if timestamp:
                try:
                    hour = datetime.fromisoformat(timestamp).hour
                    time_distribution[hour] += 1
                except:
                    pass
        
        return {
            "event_type_distribution": dict(event_types),
            "time_distribution": dict(time_distribution),
            "peak_activity_hour": max(time_distribution, key=time_distribution.get) if time_distribution else None,
        }
    
    def get_hunt_history(
        self,
        query_id: Optional[str] = None,
        start_time: Optional[datetime] = None,
    ) -> List[HuntResult]:
        """
        获取狩猎历史
        
        Args:
            query_id: 查询ID过滤
            start_time: 开始时间过滤
            
        Returns:
            狩猎结果列表
        """
        results = self._hunt_history
        
        if query_id:
            results = [r for r in results if r.query_id == query_id]
        
        if start_time:
            results = [r for r in results if r.timestamp >= start_time]
        
        return results


# 便捷函数
def create_threat_hunting_engine() -> ThreatHuntingEngine:
    """
    创建威胁狩猎引擎的工厂函数
    
    Returns:
        威胁狩猎引擎实例
    """
    return ThreatHuntingEngine()
