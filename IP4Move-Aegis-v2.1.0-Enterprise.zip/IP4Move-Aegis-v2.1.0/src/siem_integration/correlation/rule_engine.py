"""
关联规则引擎模块

实现安全事件的关联规则引擎，支持规则定义、条件匹配和动作执行。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import json
import re
from collections import defaultdict

# 配置日志
logger = logging.getLogger(__name__)


class RuleConditionType(Enum):
    """规则条件类型"""
    EQUALS = "equals"
    NOT_EQUALS = "not_equals"
    CONTAINS = "contains"
    REGEX = "regex"
    GREATER_THAN = "greater_than"
    LESS_THAN = "less_than"
    IN = "in"
    EXISTS = "exists"
    AND = "and"
    OR = "or"


class RuleActionType(Enum):
    """规则动作类型"""
    ALERT = "alert"
    BLOCK = "block"
    NOTIFY = "notify"
    ENRICH = "enrich"
    CUSTOM = "custom"


@dataclass
class RuleCondition:
    """规则条件"""
    type: RuleConditionType
    field_name: Optional[str] = None
    value: Any = None
    conditions: List["RuleCondition"] = field(default_factory=list)
    
    def evaluate(self, event: Dict[str, Any]) -> bool:
        """评估条件"""
        if self.type == RuleConditionType.AND:
            return all(c.evaluate(event) for c in self.conditions)
        elif self.type == RuleConditionType.OR:
            return any(c.evaluate(event) for c in self.conditions)
        
        # 获取字段值
        field_value = self._get_field_value(event, self.field_name) if self.field_name else None
        
        if self.type == RuleConditionType.EQUALS:
            return field_value == self.value
        elif self.type == RuleConditionType.NOT_EQUALS:
            return field_value != self.value
        elif self.type == RuleConditionType.CONTAINS:
            return self.value in str(field_value) if field_value else False
        elif self.type == RuleConditionType.REGEX:
            if field_value and self.value:
                return bool(re.search(self.value, str(field_value)))
            return False
        elif self.type == RuleConditionType.GREATER_THAN:
            try:
                return float(field_value) > float(self.value) if field_value else False
            except (ValueError, TypeError):
                return False
        elif self.type == RuleConditionType.LESS_THAN:
            try:
                return float(field_value) < float(self.value) if field_value else False
            except (ValueError, TypeError):
                return False
        elif self.type == RuleConditionType.IN:
            return field_value in self.value if self.value else False
        elif self.type == RuleConditionType.EXISTS:
            return self.field_name in event if self.field_name else False
        
        return False
    
    def _get_field_value(self, event: Dict[str, Any], field: str) -> Any:
        """获取嵌套字段值"""
        parts = field.split(".")
        current = event
        
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        
        return current


@dataclass
class RuleAction:
    """规则动作"""
    type: RuleActionType
    params: Dict[str, Any] = field(default_factory=dict)
    custom_handler: Optional[Callable[[Dict[str, Any]], None]] = None


@dataclass
class CorrelationRule:
    """关联规则"""
    id: str
    name: str
    description: str
    enabled: bool = True
    condition: Optional[RuleCondition] = None
    actions: List[RuleAction] = field(default_factory=list)
    severity: str = "medium"  # low, medium, high, critical
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    # 关联配置
    correlation_window: int = 300  # 关联时间窗口（秒）
    correlation_key: Optional[str] = None  # 关联键（如source.ip）
    min_occurrences: int = 1  # 最小触发次数


class CorrelationRuleEngine:
    """
    关联规则引擎
    
    实现安全事件的关联分析，支持规则定义、条件匹配和动作执行。
    
    Example:
        >>> engine = CorrelationRuleEngine()
        >>> 
        >>> # 定义规则
        >>> rule = CorrelationRule(
        ...     id="rule-001",
        ...     name="Brute Force Login",
        ...     condition=RuleCondition(
        ...         type=RuleConditionType.AND,
        ...         conditions=[
        ...             RuleCondition(RuleConditionType.EQUALS, "event.category", "authentication"),
        ...             RuleCondition(RuleConditionType.EQUALS, "event.outcome", "failure"),
        ...         ]
        ...     ),
        ...     actions=[RuleAction(RuleActionType.ALERT, {"severity": "high"})],
        ...     correlation_key="source.ip",
        ...     min_occurrences=5,
        ...     correlation_window=300,
        ... )
        >>> 
        >>> engine.add_rule(rule)
        >>> engine.process_event(event)
    """
    
    def __init__(self):
        """初始化关联规则引擎"""
        self._rules: Dict[str, CorrelationRule] = {}
        self._event_history: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._action_handlers: Dict[RuleActionType, Callable] = {}
        self._running = False
        
        # 注册默认动作处理器
        self._register_default_handlers()
    
    def _register_default_handlers(self) -> None:
        """注册默认动作处理器"""
        self._action_handlers[RuleActionType.ALERT] = self._handle_alert
        self._action_handlers[RuleActionType.NOTIFY] = self._handle_notify
        self._action_handlers[RuleActionType.ENRICH] = self._handle_enrich
    
    def add_rule(self, rule: CorrelationRule) -> None:
        """
        添加规则
        
        Args:
            rule: 关联规则
        """
        self._rules[rule.id] = rule
        logger.info(f"Rule added: {rule.name} ({rule.id})")
    
    def remove_rule(self, rule_id: str) -> bool:
        """
        移除规则
        
        Args:
            rule_id: 规则ID
            
        Returns:
            是否成功
        """
        if rule_id in self._rules:
            del self._rules[rule_id]
            logger.info(f"Rule removed: {rule_id}")
            return True
        return False
    
    def get_rule(self, rule_id: str) -> Optional[CorrelationRule]:
        """
        获取规则
        
        Args:
            rule_id: 规则ID
            
        Returns:
            规则对象或None
        """
        return self._rules.get(rule_id)
    
    def list_rules(self) -> List[CorrelationRule]:
        """
        列出所有规则
        
        Returns:
            规则列表
        """
        return list(self._rules.values())
    
    def process_event(self, event: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        处理事件
        
        Args:
            event: 安全事件
            
        Returns:
            触发的告警列表
        """
        triggered_alerts = []
        
        for rule in self._rules.values():
            if not rule.enabled:
                continue
            
            # 检查条件
            if rule.condition and not rule.condition.evaluate(event):
                continue
            
            # 检查关联条件
            if rule.correlation_key:
                if not self._check_correlation(rule, event):
                    continue
            
            # 执行动作
            alert = self._execute_actions(rule, event)
            if alert:
                triggered_alerts.append(alert)
        
        return triggered_alerts
    
    def _check_correlation(self, rule: CorrelationRule, event: Dict[str, Any]) -> bool:
        """检查关联条件"""
        if not rule.correlation_key:
            return True
        
        # 获取关联键值
        correlation_value = self._get_field_value(event, rule.correlation_key)
        if not correlation_value:
            return False
        
        # 构建关联键
        correlation_id = f"{rule.id}:{correlation_value}"
        
        # 清理过期事件
        self._cleanup_expired_events(correlation_id, rule.correlation_window)
        
        # 添加当前事件
        self._event_history[correlation_id].append({
            "event": event,
            "timestamp": datetime.utcnow(),
        })
        
        # 检查触发次数
        return len(self._event_history[correlation_id]) >= rule.min_occurrences
    
    def _cleanup_expired_events(self, correlation_id: str, window: int) -> None:
        """清理过期事件"""
        cutoff = datetime.utcnow() - timedelta(seconds=window)
        self._event_history[correlation_id] = [
            e for e in self._event_history[correlation_id]
            if e["timestamp"] > cutoff
        ]
    
    def _execute_actions(
        self,
        rule: CorrelationRule,
        event: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """执行规则动作"""
        alert = {
            "rule_id": rule.id,
            "rule_name": rule.name,
            "severity": rule.severity,
            "timestamp": datetime.utcnow().isoformat(),
            "event": event,
            "actions_executed": [],
        }
        
        for action in rule.actions:
            try:
                handler = self._action_handlers.get(action.type)
                if handler:
                    handler(event, action.params)
                    alert["actions_executed"].append(action.type.value)
                elif action.custom_handler:
                    action.custom_handler(event)
                    alert["actions_executed"].append("custom")
            except Exception as e:
                logger.error(f"Action execution failed: {e}")
        
        logger.info(f"Rule triggered: {rule.name}")
        return alert
    
    def _handle_alert(self, event: Dict[str, Any], params: Dict[str, Any]) -> None:
        """处理告警动作"""
        logger.info(f"Alert generated: {params.get('message', 'No message')}")
    
    def _handle_notify(self, event: Dict[str, Any], params: Dict[str, Any]) -> None:
        """处理通知动作"""
        logger.info(f"Notification sent: {params.get('channel', 'unknown')}")
    
    def _handle_enrich(self, event: Dict[str, Any], params: Dict[str, Any]) -> None:
        """处理富化动作"""
        enrichments = params.get("enrichments", {})
        event.update(enrichments)
        logger.debug(f"Event enriched with: {enrichments}")
    
    def register_action_handler(
        self,
        action_type: RuleActionType,
        handler: Callable[[Dict[str, Any], Dict[str, Any]], None]
    ) -> None:
        """
        注册动作处理器
        
        Args:
            action_type: 动作类型
            handler: 处理器函数
        """
        self._action_handlers[action_type] = handler
    
    def create_rule_from_dict(self, rule_dict: Dict[str, Any]) -> CorrelationRule:
        """
        从字典创建规则
        
        Args:
            rule_dict: 规则字典
            
        Returns:
            关联规则对象
        """
        # 解析条件
        condition = self._parse_condition(rule_dict.get("condition", {}))
        
        # 解析动作
        actions = [
            RuleAction(
                type=RuleActionType(a["type"]),
                params=a.get("params", {})
            )
            for a in rule_dict.get("actions", [])
        ]
        
        return CorrelationRule(
            id=rule_dict["id"],
            name=rule_dict["name"],
            description=rule_dict.get("description", ""),
            enabled=rule_dict.get("enabled", True),
            condition=condition,
            actions=actions,
            severity=rule_dict.get("severity", "medium"),
            tags=rule_dict.get("tags", []),
            correlation_window=rule_dict.get("correlation_window", 300),
            correlation_key=rule_dict.get("correlation_key"),
            min_occurrences=rule_dict.get("min_occurrences", 1),
        )
    
    def _parse_condition(self, condition_dict: Dict[str, Any]) -> RuleCondition:
        """解析条件字典"""
        condition_type = RuleConditionType(condition_dict.get("type", "equals"))
        
        if condition_type in [RuleConditionType.AND, RuleConditionType.OR]:
            sub_conditions = [
                self._parse_condition(c)
                for c in condition_dict.get("conditions", [])
            ]
            return RuleCondition(
                type=condition_type,
                conditions=sub_conditions
            )
        
        return RuleCondition(
            type=condition_type,
            field_name=condition_dict.get("field"),
            value=condition_dict.get("value"),
        )
    
    def _get_field_value(self, event: Dict[str, Any], field: str) -> Any:
        """获取嵌套字段值"""
        parts = field.split(".")
        current = event
        
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        
        return current


# 便捷函数
def create_rule_engine() -> CorrelationRuleEngine:
    """
    创建关联规则引擎的工厂函数
    
    Returns:
        关联规则引擎实例
    """
    return CorrelationRuleEngine()


def create_simple_rule(
    rule_id: str,
    name: str,
    field_name: str,
    value: Any,
    action: str = "alert",
) -> CorrelationRule:
    """
    创建简单规则的便捷函数
    
    Args:
        rule_id: 规则ID
        name: 规则名称
        field_name: 字段名
        value: 字段值
        action: 动作类型
        
    Returns:
        关联规则对象
    """
    condition = RuleCondition(
        type=RuleConditionType.EQUALS,
        field=field_name,
        value=value,
    )
    
    actions = [RuleAction(type=RuleActionType(action), params={})]
    
    return CorrelationRule(
        id=rule_id,
        name=name,
        description=f"Detect when {field_name} equals {value}",
        condition=condition,
        actions=actions,
    )
