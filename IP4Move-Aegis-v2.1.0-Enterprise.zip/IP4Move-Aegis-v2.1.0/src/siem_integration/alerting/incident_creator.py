"""
事件创建模块

实现安全事件创建功能，支持事件生命周期管理、关联告警和时间线。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict
import uuid

# 配置日志
logger = logging.getLogger(__name__)


class IncidentStatus(Enum):
    """事件状态"""
    NEW = "new"
    IN_PROGRESS = "in_progress"
    ON_HOLD = "on_hold"
    RESOLVED = "resolved"
    CLOSED = "closed"


class IncidentSeverity(Enum):
    """事件严重级别"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class TimelineEntry:
    """时间线条目"""
    timestamp: datetime
    type: str  # alert, action, note, status_change
    description: str
    actor: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Incident:
    """安全事件"""
    id: str
    title: str
    description: str
    status: IncidentStatus
    severity: IncidentSeverity
    created_at: datetime
    updated_at: datetime
    assigned_to: Optional[str] = None
    related_alerts: List[str] = field(default_factory=list)
    timeline: List[TimelineEntry] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class IncidentCreator:
    """
    事件创建器

    实现安全事件的全生命周期管理，支持关联告警和时间线。

    Example:
        >>> creator = IncidentCreator()
        >>>
        >>> # 创建事件
        >>> incident = creator.create_incident(
        ...     title="Suspicious Login Activity",
        ...     description="Multiple failed login attempts detected",
        ...     severity=IncidentSeverity.HIGH,
        ... )
        >>>
        >>> # 关联告警
        >>> creator.link_alert(incident.id, alert_id)
        >>>
        >>> # 更新状态
        >>> creator.update_status(incident.id, IncidentStatus.IN_PROGRESS)
    """

    def __init__(self):
        """初始化事件创建器"""
        self._incidents: Dict[str, Incident] = {}
        self._alert_to_incident: Dict[str, str] = {}  # alert_id -> incident_id
        self._status_handlers: Dict[IncidentStatus, List[Callable]] = defaultdict(list)

    def create_incident(
        self,
        title: str,
        description: str,
        severity: IncidentSeverity = IncidentSeverity.MEDIUM,
        assigned_to: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Incident:
        """
        创建新事件

        Args:
            title: 事件标题
            description: 事件描述
            severity: 严重级别
            assigned_to: 分配给
            tags: 标签列表
            metadata: 元数据

        Returns:
            创建的事件对象
        """
        incident_id = f"INC-{uuid.uuid4().hex[:12].upper()}"
        now = datetime.utcnow()

        incident = Incident(
            id=incident_id,
            title=title,
            description=description,
            status=IncidentStatus.NEW,
            severity=severity,
            created_at=now,
            updated_at=now,
            assigned_to=assigned_to,
            related_alerts=[],
            timeline=[
                TimelineEntry(
                    timestamp=now,
                    type="created",
                    description=f"Incident created: {title}",
                    data={"severity": severity.value}
                )
            ],
            tags=tags or [],
            metadata=metadata or {},
        )

        self._incidents[incident_id] = incident
        logger.info(f"Incident created: {incident_id} - {title}")

        return incident

    def get_incident(self, incident_id: str) -> Optional[Incident]:
        """
        获取事件

        Args:
            incident_id: 事件ID

        Returns:
            事件对象或None
        """
        return self._incidents.get(incident_id)

    def update_incident(
        self,
        incident_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        severity: Optional[IncidentSeverity] = None,
    ) -> bool:
        """
        更新事件信息

        Args:
            incident_id: 事件ID
            title: 新标题
            description: 新描述
            severity: 新严重级别

        Returns:
            是否成功
        """
        incident = self._incidents.get(incident_id)
        if not incident:
            return False

        if title:
            incident.title = title
        if description:
            incident.description = description
        if severity:
            old_severity = incident.severity
            incident.severity = severity
            self._add_timeline_entry(
                incident,
                "severity_change",
                f"Severity changed from {old_severity.value} to {severity.value}",
                {"old_severity": old_severity.value, "new_severity": severity.value}
            )

        incident.updated_at = datetime.utcnow()
        logger.info(f"Incident updated: {incident_id}")
        return True

    def update_status(
        self,
        incident_id: str,
        new_status: IncidentStatus,
        actor: Optional[str] = None,
        note: Optional[str] = None,
    ) -> bool:
        """
        更新事件状态

        Args:
            incident_id: 事件ID
            new_status: 新状态
            actor: 操作者
            note: 备注

        Returns:
            是否成功
        """
        incident = self._incidents.get(incident_id)
        if not incident:
            return False

        old_status = incident.status
        incident.status = new_status
        incident.updated_at = datetime.utcnow()

        description = f"Status changed from {old_status.value} to {new_status.value}"
        if note:
            description += f": {note}"

        self._add_timeline_entry(
            incident,
            "status_change",
            description,
            actor,
            {"old_status": old_status.value, "new_status": new_status.value}
        )

        # 触发状态处理器
        self._trigger_status_handlers(incident, old_status, new_status)

        logger.info(f"Incident {incident_id} status changed to {new_status.value}")
        return True

    def assign_incident(
        self,
        incident_id: str,
        assignee: str,
        actor: Optional[str] = None,
    ) -> bool:
        """
        分配事件

        Args:
            incident_id: 事件ID
            assignee: 被分配者
            actor: 操作者

        Returns:
            是否成功
        """
        incident = self._incidents.get(incident_id)
        if not incident:
            return False

        old_assignee = incident.assigned_to
        incident.assigned_to = assignee
        incident.updated_at = datetime.utcnow()

        description = f"Assigned to {assignee}"
        if old_assignee:
            description = f"Reassigned from {old_assignee} to {assignee}"

        self._add_timeline_entry(
            incident,
            "assignment",
            description,
            actor,
            {"assignee": assignee, "previous_assignee": old_assignee}
        )

        logger.info(f"Incident {incident_id} assigned to {assignee}")
        return True

    def link_alert(
        self,
        incident_id: str,
        alert_id: str,
        alert_data: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        关联告警到事件

        Args:
            incident_id: 事件ID
            alert_id: 告警ID
            alert_data: 告警数据

        Returns:
            是否成功
        """
        incident = self._incidents.get(incident_id)
        if not incident:
            return False

        if alert_id not in incident.related_alerts:
            incident.related_alerts.append(alert_id)
            self._alert_to_incident[alert_id] = incident_id

            self._add_timeline_entry(
                incident,
                "alert_linked",
                f"Alert linked: {alert_id}",
                data={"alert_id": alert_id, "alert_data": alert_data or {}}
            )

            incident.updated_at = datetime.utcnow()
            logger.info(f"Alert {alert_id} linked to incident {incident_id}")

        return True

    def unlink_alert(
        self,
        incident_id: str,
        alert_id: str,
    ) -> bool:
        """
        解除告警关联

        Args:
            incident_id: 事件ID
            alert_id: 告警ID

        Returns:
            是否成功
        """
        incident = self._incidents.get(incident_id)
        if not incident:
            return False

        if alert_id in incident.related_alerts:
            incident.related_alerts.remove(alert_id)
            if alert_id in self._alert_to_incident:
                del self._alert_to_incident[alert_id]

            self._add_timeline_entry(
                incident,
                "alert_unlinked",
                f"Alert unlinked: {alert_id}",
                data={"alert_id": alert_id}
            )

            incident.updated_at = datetime.utcnow()
            logger.info(f"Alert {alert_id} unlinked from incident {incident_id}")

        return True

    def add_timeline_entry(
        self,
        incident_id: str,
        entry_type: str,
        description: str,
        actor: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        添加时间线条目

        Args:
            incident_id: 事件ID
            entry_type: 条目类型
            description: 描述
            actor: 操作者
            data: 附加数据

        Returns:
            是否成功
        """
        incident = self._incidents.get(incident_id)
        if not incident:
            return False

        self._add_timeline_entry(incident, entry_type, description, actor, data)
        incident.updated_at = datetime.utcnow()
        return True

    def _add_timeline_entry(
        self,
        incident: Incident,
        entry_type: str,
        description: str,
        actor: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """内部方法：添加时间线条目"""
        entry = TimelineEntry(
            timestamp=datetime.utcnow(),
            type=entry_type,
            description=description,
            actor=actor,
            data=data or {},
        )
        incident.timeline.append(entry)

    def add_note(
        self,
        incident_id: str,
        note: str,
        author: str,
    ) -> bool:
        """
        添加备注

        Args:
            incident_id: 事件ID
            note: 备注内容
            author: 作者

        Returns:
            是否成功
        """
        return self.add_timeline_entry(
            incident_id,
            "note",
            note,
            author,
        )

    def get_incident_by_alert(self, alert_id: str) -> Optional[Incident]:
        """
        通过告警ID获取关联事件

        Args:
            alert_id: 告警ID

        Returns:
            事件对象或None
        """
        incident_id = self._alert_to_incident.get(alert_id)
        if incident_id:
            return self._incidents.get(incident_id)
        return None

    def list_incidents(
        self,
        status: Optional[IncidentStatus] = None,
        severity: Optional[IncidentSeverity] = None,
        assigned_to: Optional[str] = None,
    ) -> List[Incident]:
        """
        列出事件

        Args:
            status: 状态过滤
            severity: 严重级别过滤
            assigned_to: 分配人过滤

        Returns:
            事件列表
        """
        incidents = list(self._incidents.values())

        if status:
            incidents = [i for i in incidents if i.status == status]
        if severity:
            incidents = [i for i in incidents if i.severity == severity]
        if assigned_to:
            incidents = [i for i in incidents if i.assigned_to == assigned_to]

        # 按更新时间倒序
        incidents.sort(key=lambda i: i.updated_at, reverse=True)

        return incidents

    def register_status_handler(
        self,
        status: IncidentStatus,
        handler: Callable[[Incident, IncidentStatus, IncidentStatus], None]
    ) -> None:
        """
        注册状态变更处理器

        Args:
            status: 目标状态
            handler: 处理器函数
        """
        self._status_handlers[status].append(handler)

    def _trigger_status_handlers(
        self,
        incident: Incident,
        old_status: IncidentStatus,
        new_status: IncidentStatus,
    ) -> None:
        """触发状态处理器"""
        handlers = self._status_handlers.get(new_status, [])
        for handler in handlers:
            try:
                handler(incident, old_status, new_status)
            except Exception as e:
                logger.error(f"Status handler failed: {e}")

    def get_incident_statistics(self) -> Dict[str, Any]:
        """
        获取事件统计

        Returns:
            统计信息
        """
        total = len(self._incidents)
        by_status = defaultdict(int)
        by_severity = defaultdict(int)

        for incident in self._incidents.values():
            by_status[incident.status.value] += 1
            by_severity[incident.severity.value] += 1

        # 计算平均解决时间
        resolved_incidents = [
            i for i in self._incidents.values()
            if i.status == IncidentStatus.RESOLVED
        ]

        avg_resolution_time = None
        if resolved_incidents:
            resolution_times = [
                (i.updated_at - i.created_at).total_seconds() / 3600
                for i in resolved_incidents
            ]
            avg_resolution_time = sum(resolution_times) / len(resolution_times)

        return {
            "total": total,
            "by_status": dict(by_status),
            "by_severity": dict(by_severity),
            "avg_resolution_time_hours": avg_resolution_time,
            "open_incidents": by_status.get(IncidentStatus.NEW.value, 0) +
                             by_status.get(IncidentStatus.IN_PROGRESS.value, 0),
        }

    def merge_incidents(
        self,
        primary_id: str,
        secondary_ids: List[str],
    ) -> bool:
        """
        合并事件

        Args:
            primary_id: 主事件ID
            secondary_ids: 次要事件ID列表

        Returns:
            是否成功
        """
        primary = self._incidents.get(primary_id)
        if not primary:
            return False

        for secondary_id in secondary_ids:
            secondary = self._incidents.get(secondary_id)
            if not secondary:
                continue

            # 合并关联告警
            for alert_id in secondary.related_alerts:
                if alert_id not in primary.related_alerts:
                    primary.related_alerts.append(alert_id)
                    self._alert_to_incident[alert_id] = primary_id

            # 合并时间线
            primary.timeline.extend(secondary.timeline)

            # 排序时间线
            primary.timeline.sort(key=lambda e: e.timestamp)

            # 关闭次要事件
            secondary.status = IncidentStatus.CLOSED
            self._add_timeline_entry(
                secondary,
                "merged",
                f"Merged into incident {primary_id}",
                data={"target_incident": primary_id}
            )

            self._add_timeline_entry(
                primary,
                "merge",
                f"Merged incident {secondary_id}",
                data={"source_incident": secondary_id}
            )

        primary.updated_at = datetime.utcnow()
        logger.info(f"Incidents merged into {primary_id}: {secondary_ids}")
        return True


# 便捷函数
def create_incident_creator() -> IncidentCreator:
    """
    创建事件创建器的工厂函数

    Returns:
        事件创建器实例
    """
    return IncidentCreator()
