"""
告警路由模块

实现告警路由功能，支持基于规则的路由、升级策略和去重。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional, Callable, Set
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict
import hashlib
import json

# 配置日志
logger = logging.getLogger(__name__)


class RoutingTarget(Enum):
    """路由目标"""
    EMAIL = "email"
    SMS = "sms"
    WEBHOOK = "webhook"
    SIEM = "siem"
    TICKET = "ticket"
    PAGERDUTY = "pagerduty"
    SLACK = "slack"
    TEAMS = "teams"


class SeverityLevel(Enum):
    """严重级别"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class AlertRoutingRule:
    """告警路由规则"""
    id: str
    name: str
    condition: Dict[str, Any]  # 路由条件
    targets: List[RoutingTarget]
    target_config: Dict[str, Any]  # 目标配置
    enabled: bool = True
    priority: int = 0  # 优先级，数字越小优先级越高
    dedup_window: int = 300  # 去重窗口（秒）
    escalation_policy: Optional[str] = None  # 升级策略ID


@dataclass
class Alert:
    """告警"""
    id: str
    title: str
    description: str
    severity: SeverityLevel
    source: str
    timestamp: datetime
    context: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    assigned_to: Optional[str] = None
    status: str = "new"  # new, acknowledged, resolved


@dataclass
class EscalationPolicy:
    """升级策略"""
    id: str
    name: str
    levels: List[Dict[str, Any]]  # 升级级别配置
    enabled: bool = True


class AlertRouter:
    """
    告警路由器
    
    实现告警的智能路由，支持基于规则的路由、升级策略和去重。
    
    Example:
        >>> router = AlertRouter()
        >>> 
        >>> # 添加路由规则
        >>> rule = AlertRoutingRule(
        ...     id="rule-001",
        ...     name="Critical to PagerDuty",
        ...     condition={"severity": ["critical", "high"]},
        ...     targets=[RoutingTarget.PAGERDUTY],
        ...     target_config={"service_key": "your-key"},
        ... )
        >>> router.add_routing_rule(rule)
        >>> 
        >>> # 路由告警
        >>> router.route_alert(alert)
    """
    
    def __init__(self):
        """初始化告警路由器"""
        self._routing_rules: List[AlertRoutingRule] = []
        self._escalation_policies: Dict[str, EscalationPolicy] = {}
        self._dedup_cache: Dict[str, datetime] = {}
        self._target_handlers: Dict[RoutingTarget, Callable] = {}
        self._alert_history: List[Alert] = []
        
        # 注册默认目标处理器
        self._register_default_handlers()
    
    def _register_default_handlers(self) -> None:
        """注册默认目标处理器"""
        self._target_handlers[RoutingTarget.EMAIL] = self._send_email
        self._target_handlers[RoutingTarget.SLACK] = self._send_slack
        self._target_handlers[RoutingTarget.WEBHOOK] = self._send_webhook
        self._target_handlers[RoutingTarget.SIEM] = self._send_to_siem
    
    def add_routing_rule(self, rule: AlertRoutingRule) -> None:
        """
        添加路由规则
        
        Args:
            rule: 路由规则
        """
        self._routing_rules.append(rule)
        # 按优先级排序
        self._routing_rules.sort(key=lambda r: r.priority)
        logger.info(f"Routing rule added: {rule.name} ({rule.id})")
    
    def remove_routing_rule(self, rule_id: str) -> bool:
        """
        移除路由规则
        
        Args:
            rule_id: 规则ID
            
        Returns:
            是否成功
        """
        for i, rule in enumerate(self._routing_rules):
            if rule.id == rule_id:
                del self._routing_rules[i]
                logger.info(f"Routing rule removed: {rule_id}")
                return True
        return False
    
    def add_escalation_policy(self, policy: EscalationPolicy) -> None:
        """
        添加升级策略
        
        Args:
            policy: 升级策略
        """
        self._escalation_policies[policy.id] = policy
        logger.info(f"Escalation policy added: {policy.name} ({policy.id})")
    
    def route_alert(self, alert: Alert) -> Dict[str, Any]:
        """
        路由告警
        
        Args:
            alert: 告警对象
            
        Returns:
            路由结果
        """
        result = {
            "alert_id": alert.id,
            "routed_to": [],
            "deduplicated": False,
            "errors": [],
        }
        
        # 检查去重
        if self._is_duplicate(alert):
            result["deduplicated"] = True
            logger.debug(f"Alert deduplicated: {alert.id}")
            return result
        
        # 保存告警历史
        self._alert_history.append(alert)
        
        # 匹配路由规则
        matched_rules = self._match_rules(alert)
        
        if not matched_rules:
            logger.warning(f"No routing rules matched for alert: {alert.id}")
            return result
        
        # 执行路由
        for rule in matched_rules:
            for target in rule.targets:
                try:
                    self._route_to_target(alert, target, rule.target_config)
                    result["routed_to"].append(target.value)
                except Exception as e:
                    error_msg = f"Failed to route to {target.value}: {e}"
                    logger.error(error_msg)
                    result["errors"].append(error_msg)
        
        # 启动升级计时器（如果需要）
        for rule in matched_rules:
            if rule.escalation_policy:
                asyncio.create_task(
                    self._start_escalation_timer(alert, rule.escalation_policy)
                )
        
        return result
    
    def _match_rules(self, alert: Alert) -> List[AlertRoutingRule]:
        """匹配路由规则"""
        matched = []
        
        for rule in self._routing_rules:
            if not rule.enabled:
                continue
            
            if self._evaluate_condition(rule.condition, alert):
                matched.append(rule)
        
        return matched
    
    def _evaluate_condition(self, condition: Dict[str, Any], alert: Alert) -> bool:
        """评估路由条件"""
        for key, expected_values in condition.items():
            actual_value = self._get_alert_attribute(alert, key)
            
            if isinstance(expected_values, list):
                if actual_value not in expected_values:
                    return False
            else:
                if actual_value != expected_values:
                    return False
        
        return True
    
    def _get_alert_attribute(self, alert: Alert, key: str) -> Any:
        """获取告警属性"""
        if hasattr(alert, key):
            return getattr(alert, key)
        return alert.context.get(key)
    
    def _is_duplicate(self, alert: Alert) -> bool:
        """检查是否重复告警"""
        # 生成去重键
        dedup_key = self._generate_dedup_key(alert)
        
        now = datetime.utcnow()
        
        # 清理过期缓存
        self._cleanup_dedup_cache()
        
        # 检查是否重复
        if dedup_key in self._dedup_cache:
            return True
        
        # 添加到缓存
        self._dedup_cache[dedup_key] = now
        return False
    
    def _generate_dedup_key(self, alert: Alert) -> str:
        """生成去重键"""
        # 基于告警标题、严重级别和关键上下文生成去重键
        key_data = {
            "title": alert.title,
            "severity": alert.severity.value,
            "source": alert.source,
        }
        
        # 添加关键上下文字段
        for key in ["rule_id", "event_type", "source_ip"]:
            if key in alert.context:
                key_data[key] = alert.context[key]
        
        key_string = json.dumps(key_data, sort_keys=True)
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def _cleanup_dedup_cache(self) -> None:
        """清理去重缓存"""
        now = datetime.utcnow()
        # 获取最大去重窗口
        max_window = max(
            (rule.dedup_window for rule in self._routing_rules),
            default=300
        )
        
        cutoff = now - timedelta(seconds=max_window)
        
        self._dedup_cache = {
            k: v for k, v in self._dedup_cache.items()
            if v > cutoff
        }
    
    def _route_to_target(
        self,
        alert: Alert,
        target: RoutingTarget,
        config: Dict[str, Any]
    ) -> None:
        """路由到目标"""
        handler = self._target_handlers.get(target)
        if handler:
            handler(alert, config)
        else:
            logger.warning(f"No handler for target: {target}")
    
    async def _start_escalation_timer(
        self,
        alert: Alert,
        policy_id: str
    ) -> None:
        """启动升级计时器"""
        policy = self._escalation_policies.get(policy_id)
        if not policy:
            return
        
        for level in policy.levels:
            wait_minutes = level.get("wait_minutes", 15)
            await asyncio.sleep(wait_minutes * 60)
            
            # 检查告警状态
            if alert.status == "resolved":
                return
            
            # 执行升级
            self._escalate_alert(alert, level)
    
    def _escalate_alert(self, alert: Alert, level: Dict[str, Any]) -> None:
        """升级告警"""
        targets = level.get("targets", [])
        message = level.get("message", f"Alert escalated: {alert.title}")
        
        logger.info(f"Escalating alert {alert.id} to level: {level.get('name', 'unknown')}")
        
        for target_str in targets:
            try:
                target = RoutingTarget(target_str)
                # 使用默认配置或级别配置
                config = level.get("config", {})
                self._route_to_target(alert, target, config)
            except ValueError:
                logger.error(f"Invalid escalation target: {target_str}")
    
    def _send_email(self, alert: Alert, config: Dict[str, Any]) -> None:
        """发送邮件"""
        recipients = config.get("recipients", [])
        logger.info(f"Sending email alert to: {recipients}")
    
    def _send_slack(self, alert: Alert, config: Dict[str, Any]) -> None:
        """发送Slack消息"""
        webhook_url = config.get("webhook_url")
        channel = config.get("channel")
        logger.info(f"Sending Slack alert to channel: {channel}")
    
    def _send_webhook(self, alert: Alert, config: Dict[str, Any]) -> None:
        """发送Webhook"""
        url = config.get("url")
        logger.info(f"Sending webhook to: {url}")
    
    def _send_to_siem(self, alert: Alert, config: Dict[str, Any]) -> None:
        """发送到SIEM"""
        siem_type = config.get("type", "generic")
        logger.info(f"Sending alert to SIEM: {siem_type}")
    
    def register_target_handler(
        self,
        target: RoutingTarget,
        handler: Callable[[Alert, Dict[str, Any]], None]
    ) -> None:
        """
        注册目标处理器
        
        Args:
            target: 路由目标
            handler: 处理器函数
        """
        self._target_handlers[target] = handler
    
    def get_alert_statistics(
        self,
        start_time: Optional[datetime] = None,
    ) -> Dict[str, Any]:
        """
        获取告警统计
        
        Args:
            start_time: 开始时间
            
        Returns:
            统计信息
        """
        alerts = self._alert_history
        
        if start_time:
            alerts = [a for a in alerts if a.timestamp >= start_time]
        
        severity_counts = defaultdict(int)
        status_counts = defaultdict(int)
        
        for alert in alerts:
            severity_counts[alert.severity.value] += 1
            status_counts[alert.status] += 1
        
        return {
            "total_alerts": len(alerts),
            "by_severity": dict(severity_counts),
            "by_status": dict(status_counts),
        }


# 便捷函数
def create_alert_router() -> AlertRouter:
    """
    创建告警路由器的工厂函数
    
    Returns:
        告警路由器实例
    """
    return AlertRouter()
