"""
SIEM集成模块

提供与安全信息和事件管理(SIEM)系统的集成功能，包括：
- Splunk/Elastic/QRadar/Azure Sentinel连接器
- ECS/CEF标准化和格式化
- 关联规则引擎和威胁狩猎
- 告警路由和事件创建
"""

from .connectors.splunk_connector import SplunkConnector
from .connectors.elastic_siem import ElasticSIEMConnector
from .connectors.qradar_connector import QRadarConnector
from .connectors.sentinel_connector import AzureSentinelConnector
from .normalization.ecs_normalizer import ECSNormalizer
from .normalization.cef_formatter import CEFFormatter
from .correlation.rule_engine import CorrelationRuleEngine, CorrelationRule
from .correlation.threat_hunting import ThreatHuntingEngine, HuntQuery
from .alerting.alert_router import AlertRouter, AlertRoutingRule
from .alerting.incident_creator import IncidentCreator, Incident

__version__ = "1.0.0"
__all__ = [
    # Connectors
    "SplunkConnector",
    "ElasticSIEMConnector",
    "QRadarConnector",
    "AzureSentinelConnector",
    # Normalization
    "ECSNormalizer",
    "CEFFormatter",
    # Correlation
    "CorrelationRuleEngine",
    "CorrelationRule",
    "ThreatHuntingEngine",
    "HuntQuery",
    # Alerting
    "AlertRouter",
    "AlertRoutingRule",
    "IncidentCreator",
    "Incident",
]