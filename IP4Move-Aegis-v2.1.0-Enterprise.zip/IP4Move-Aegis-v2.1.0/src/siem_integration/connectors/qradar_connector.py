"""
QRadar连接器模块

提供与IBM QRadar SIEM的集成功能，支持REST API和AQL查询。
"""

import json
import asyncio
import logging
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass
from datetime import datetime
from urllib.parse import urljoin

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class QRadarEvent:
    """QRadar事件"""
    log_source_id: int
    event_category: str
    event_name: str
    timestamp: int
    payload: Dict[str, Any]
    source_ip: Optional[str] = None
    destination_ip: Optional[str] = None
    username: Optional[str] = None


class QRadarConnector:
    """
    QRadar连接器
    
    提供与IBM QRadar SIEM的集成，支持REST API和AQL查询。
    
    Example:
        >>> connector = QRadarConnector(
        ...     base_url="https://qradar.example.com",
        ...     api_key="your-api-key"
        ... )
        >>> await connector.start()
        >>> await connector.send_event(event)
        >>> results = await connector.aql_search("SELECT * FROM events")
        >>> await connector.stop()
    """
    
    def __init__(
        self,
        base_url: str,
        api_key: str,
        verify_ssl: bool = True,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        """
        初始化QRadar连接器
        
        Args:
            base_url: QRadar基础URL
            api_key: API密钥
            verify_ssl: 是否验证SSL证书
            timeout: 请求超时时间
            max_retries: 最大重试次数
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.max_retries = max_retries
        
        self._http_session: Optional[Any] = None
        self._running = False
    
    async def start(self) -> None:
        """启动连接器"""
        self._running = True
        
        try:
            import aiohttp
            self._http_session = aiohttp.ClientSession(
                headers={
                    "SEC": self.api_key,
                    "Content-Type": "application/json",
                    "Version": "14.0"
                },
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )
        except ImportError:
            logger.error("aiohttp is required for QRadar connector")
            raise
        
        logger.info("QRadar connector started")
    
    async def stop(self) -> None:
        """停止连接器"""
        self._running = False
        
        if self._http_session:
            await self._http_session.close()
        
        logger.info("QRadar connector stopped")
    
    async def send_event(
        self,
        event: Union[QRadarEvent, Dict[str, Any]],
        log_source_id: int = 0,
    ) -> bool:
        """
        发送事件到QRadar
        
        Args:
            event: 事件数据
            log_source_id: 日志源ID
            
        Returns:
            是否成功
        """
        if not self._http_session:
            return False
        
        if isinstance(event, dict):
            event_data = event
        else:
            event_data = {
                "log_source_id": event.log_source_id,
                "event_category": event.event_category,
                "event_name": event.event_name,
                "timestamp": event.timestamp,
                "payload": event.payload,
                "source_ip": event.source_ip,
                "destination_ip": event.destination_ip,
                "username": event.username,
            }
        
        url = f"{self.base_url}/api/events"
        
        try:
            async with self._http_session.post(
                url,
                json=event_data,
                ssl=self.verify_ssl
            ) as response:
                if response.status in [200, 201]:
                    logger.debug("Event sent to QRadar")
                    return True
                else:
                    response_text = await response.text()
                    logger.error(f"Failed to send event: {response.status} - {response_text}")
                    return False
        except Exception as e:
            logger.error(f"Failed to send event: {e}")
            return False
    
    async def aql_search(
        self,
        query: str,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        执行AQL查询
        
        Args:
            query: AQL查询语句
            start_time: 开始时间
            end_time: 结束时间
            
        Returns:
            查询结果列表
        """
        if not self._http_session:
            return []
        
        # 首先创建搜索任务
        search_url = f"{self.base_url}/api/ariel/searches"
        
        params = {"query_expression": query}
        if start_time:
            params["start_time"] = start_time
        if end_time:
            params["end_time"] = end_time
        
        try:
            async with self._http_session.post(
                search_url,
                params=params,
                ssl=self.verify_ssl
            ) as response:
                if response.status == 201:
                    result = await response.json()
                    search_id = result.get("search_id")
                    
                    # 等待搜索完成并获取结果
                    return await self._get_search_results(search_id)
                else:
                    response_text = await response.text()
                    logger.error(f"AQL search failed: {response.status} - {response_text}")
                    return []
        except Exception as e:
            logger.error(f"AQL search failed: {e}")
            return []
    
    async def _get_search_results(self, search_id: str) -> List[Dict[str, Any]]:
        """获取搜索结果"""
        if not self._http_session:
            return []
        
        # 等待搜索完成
        status_url = f"{self.base_url}/api/ariel/searches/{search_id}"
        
        for _ in range(30):  # 最多等待30次
            try:
                async with self._http_session.get(
                    status_url,
                    ssl=self.verify_ssl
                ) as response:
                    if response.status == 200:
                        status = await response.json()
                        if status.get("status") == "COMPLETED":
                            break
                        elif status.get("status") == "ERROR":
                            logger.error(f"Search error: {status}")
                            return []
            except Exception as e:
                logger.error(f"Failed to get search status: {e}")
                return []
            
            await asyncio.sleep(1)
        
        # 获取结果
        results_url = f"{self.base_url}/api/ariel/searches/{search_id}/results"
        
        try:
            async with self._http_session.get(
                results_url,
                ssl=self.verify_ssl
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    return result.get("events", [])
                else:
                    response_text = await response.text()
                    logger.error(f"Failed to get results: {response.status} - {response_text}")
                    return []
        except Exception as e:
            logger.error(f"Failed to get results: {e}")
            return []
    
    async def get_offenses(
        self,
        status: Optional[str] = None,
        start_time: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        获取 offenses
        
        Args:
            status: 状态过滤（OPEN, CLOSED等）
            start_time: 开始时间过滤
            
        Returns:
            Offenses列表
        """
        if not self._http_session:
            return []
        
        url = f"{self.base_url}/api/siem/offenses"
        
        params = {}
        if status:
            params["filter"] = f"status={status}"
        if start_time:
            params["start_time"] = start_time
        
        try:
            async with self._http_session.get(
                url,
                params=params,
                ssl=self.verify_ssl
            ) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    response_text = await response.text()
                    logger.error(f"Failed to get offenses: {response.status} - {response_text}")
                    return []
        except Exception as e:
            logger.error(f"Failed to get offenses: {e}")
            return []
    
    async def update_offense(
        self,
        offense_id: int,
        status: Optional[str] = None,
        assigned_to: Optional[str] = None,
        protected: Optional[bool] = None,
    ) -> bool:
        """
        更新 offense
        
        Args:
            offense_id: Offense ID
            status: 新状态
            assigned_to: 分配给
            protected: 是否保护
            
        Returns:
            是否成功
        """
        if not self._http_session:
            return False
        
        url = f"{self.base_url}/api/siem/offenses/{offense_id}"
        
        data = {}
        if status:
            data["status"] = status
        if assigned_to:
            data["assigned_to"] = assigned_to
        if protected is not None:
            data["protected"] = protected
        
        try:
            async with self._http_session.post(
                url,
                json=data,
                ssl=self.verify_ssl
            ) as response:
                if response.status == 200:
                    logger.info(f"Offense {offense_id} updated")
                    return True
                else:
                    response_text = await response.text()
                    logger.error(f"Failed to update offense: {response.status} - {response_text}")
                    return False
        except Exception as e:
            logger.error(f"Failed to update offense: {e}")
            return False
    
    async def get_reference_sets(self) -> List[Dict[str, Any]]:
        """
        获取参考集列表
        
        Returns:
            参考集列表
        """
        if not self._http_session:
            return []
        
        url = f"{self.base_url}/api/reference_data/sets"
        
        try:
            async with self._http_session.get(url, ssl=self.verify_ssl) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    logger.error(f"Failed to get reference sets: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Failed to get reference sets: {e}")
            return []
    
    async def add_to_reference_set(
        self,
        set_name: str,
        value: str,
        source: str = "IP4Move-Aegis",
    ) -> bool:
        """
        添加值到参考集
        
        Args:
            set_name: 参考集名称
            value: 值
            source: 来源
            
        Returns:
            是否成功
        """
        if not self._http_session:
            return False
        
        url = f"{self.base_url}/api/reference_data/sets/{set_name}"
        
        params = {
            "value": value,
            "source": source,
        }
        
        try:
            async with self._http_session.post(
                url,
                params=params,
                ssl=self.verify_ssl
            ) as response:
                if response.status == 200:
                    logger.debug(f"Added {value} to reference set {set_name}")
                    return True
                else:
                    response_text = await response.text()
                    logger.error(f"Failed to add to reference set: {response.status} - {response_text}")
                    return False
        except Exception as e:
            logger.error(f"Failed to add to reference set: {e}")
            return False
    
    async def health_check(self) -> bool:
        """
        健康检查
        
        Returns:
            是否健康
        """
        if not self._http_session:
            return False
        
        try:
            url = f"{self.base_url}/api/system/about"
            async with self._http_session.get(url, ssl=self.verify_ssl) as response:
                return response.status == 200
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False


# 便捷函数
def create_qradar_connector(
    base_url: str,
    api_key: str,
) -> QRadarConnector:
    """
    创建QRadar连接器的工厂函数
    
    Args:
        base_url: QRadar基础URL
        api_key: API密钥
        
    Returns:
        QRadar连接器实例
    """
    return QRadarConnector(base_url=base_url, api_key=api_key)
