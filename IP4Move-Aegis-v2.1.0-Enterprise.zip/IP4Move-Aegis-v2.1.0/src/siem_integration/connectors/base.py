"""
SIEM连接器基类模块

提供统一的SIEM连接器接口和基础功能
"""

import asyncio
import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from uuid import UUID, uuid4

import aiohttp

logger = logging.getLogger(__name__)


class SIEMSeverity(Enum):
    """SIEM告警严重级别"""
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class SIEMEventType(Enum):
    """SIEM事件类型"""
    ALERT = "alert"
    INCIDENT = "incident"
    AUDIT = "audit"
    THREAT = "threat"
    ANOMALY = "anomaly"


@dataclass
class SIEMEvent:
    """SIEM事件数据类"""
    id: UUID
    timestamp: datetime
    event_type: SIEMEventType
    severity: SIEMSeverity
    source: str
    title: str
    description: str
    raw_data: Dict[str, Any] = field(default_factory=dict)
    normalized_data: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    mitre_techniques: List[str] = field(default_factory=list)


@dataclass
class SIEMQueryResult:
    """SIEM查询结果"""
    query_id: UUID
    total_results: int
    events: List[SIEMEvent]
    execution_time_ms: float
    query_string: str


@dataclass
class ConnectionStatus:
    """连接状态"""
    connected: bool
    latency_ms: Optional[float] = None
    last_error: Optional[str] = None
    last_check: Optional[datetime] = None
    version: Optional[str] = None


class BaseSIEMConnector(ABC):
    """
    SIEM连接器基类
    
    所有SIEM连接器的抽象基类，定义统一接口
    """
    
    def __init__(
        self,
        host: str,
        port: int,
        api_key: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        use_ssl: bool = True,
        verify_ssl: bool = True,
        timeout: int = 30
    ):
        """
        初始化连接器
        
        Args:
            host: SIEM服务器主机
            port: SIEM服务器端口
            api_key: API密钥
            username: 用户名
            password: 密码
            use_ssl: 是否使用SSL
            verify_ssl: 是否验证SSL证书
            timeout: 超时时间(秒)
        """
        self.host = host
        self.port = port
        self.api_key = api_key
        self.username = username
        self.password = password
        self.use_ssl = use_ssl
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        
        self._session: Optional[aiohttp.ClientSession] = None
        self._connected = False
        self._connection_status = ConnectionStatus(connected=False)
        
        # 构建基础URL
        protocol = "https" if use_ssl else "http"
        self.base_url = f"{protocol}://{host}:{port}"
        
        logger.info(f"SIEM连接器初始化: {self.__class__.__name__} ({host}:{port})")
    
    async def __aenter__(self):
        """异步上下文管理器入口"""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        await self.disconnect()
    
    async def connect(self) -> bool:
        """
        连接到SIEM系统
        
        Returns:
            是否连接成功
        """
        try:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                headers=self._get_auth_headers()
            )
            
            self._connected = await self._test_connection()
            self._connection_status = ConnectionStatus(
                connected=self._connected,
                last_check=datetime.utcnow()
            )
            
            if self._connected:
                logger.info(f"成功连接到SIEM: {self.host}")
            else:
                logger.warning(f"连接SIEM失败: {self.host}")
            
            return self._connected
            
        except Exception as e:
            logger.error(f"连接SIEM时出错: {e}")
            self._connection_status = ConnectionStatus(
                connected=False,
                last_error=str(e),
                last_check=datetime.utcnow()
            )
            return False
    
    async def disconnect(self) -> None:
        """断开与SIEM系统的连接"""
        if self._session:
            await self._session.close()
            self._session = None
        
        self._connected = False
        self._connection_status.connected = False
        logger.info(f"已断开与SIEM的连接: {self.host}")
    
    @abstractmethod
    def _get_auth_headers(self) -> Dict[str, str]:
        """
        获取认证头
        
        Returns:
            HTTP头字典
        """
        pass
    
    @abstractmethod
    async def _test_connection(self) -> bool:
        """
        测试连接
        
        Returns:
            连接是否可用
        """
        pass
    
    @abstractmethod
    async def send_event(self, event: SIEMEvent) -> bool:
        """
        发送事件到SIEM
        
        Args:
            event: SIEM事件
            
        Returns:
            是否发送成功
        """
        pass
    
    @abstractmethod
    async def send_events_batch(self, events: List[SIEMEvent]) -> Dict[str, Any]:
        """
        批量发送事件
        
        Args:
            events: SIEM事件列表
            
        Returns:
            发送结果统计
        """
        pass
    
    @abstractmethod
    async def query_events(
        self,
        query: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: int = 100
    ) -> SIEMQueryResult:
        """
        查询事件
        
        Args:
            query: 查询语句
            start_time: 开始时间
            end_time: 结束时间
            limit: 返回数量限制
            
        Returns:
            查询结果
        """
        pass
    
    @abstractmethod
    async def create_incident(
        self,
        title: str,
        description: str,
        severity: SIEMSeverity,
        events: List[SIEMEvent],
        assignee: Optional[str] = None
    ) -> Optional[UUID]:
        """
        创建安全事件
        
        Args:
            title: 事件标题
            description: 事件描述
            severity: 严重级别
            events: 关联事件列表
            assignee: 负责人
            
        Returns:
            事件ID
        """
        pass
    
    def is_connected(self) -> bool:
        """
        检查连接状态
        
        Returns:
            是否已连接
        """
        return self._connected
    
    def get_connection_status(self) -> ConnectionStatus:
        """
        获取连接状态
        
        Returns:
            连接状态信息
        """
        return self._connection_status
    
    def _normalize_severity(self, severity: Union[str, SIEMSeverity]) -> SIEMSeverity:
        """
        标准化严重级别
        
        Args:
            severity: 严重级别
            
        Returns:
            标准化的严重级别
        """
        if isinstance(severity, SIEMSeverity):
            return severity
        
        severity_map = {
            "info": SIEMSeverity.INFO,
            "low": SIEMSeverity.LOW,
            "medium": SIEMSeverity.MEDIUM,
            "high": SIEMSeverity.HIGH,
            "critical": SIEMSeverity.CRITICAL,
            "1": SIEMSeverity.LOW,
            "2": SIEMSeverity.MEDIUM,
            "3": SIEMSeverity.HIGH,
            "4": SIEMSeverity.CRITICAL,
        }
        
        return severity_map.get(severity.lower(), SIEMSeverity.MEDIUM)
    
    def _create_event_from_raw(
        self,
        raw_event: Dict[str, Any],
        source: str
    ) -> SIEMEvent:
        """
        从原始数据创建事件
        
        Args:
            raw_event: 原始事件数据
            source: 事件来源
            
        Returns:
            SIEM事件
        """
        return SIEMEvent(
            id=uuid4(),
            timestamp=datetime.utcnow(),
            event_type=SIEMEventType.ALERT,
            severity=SIEMSeverity.MEDIUM,
            source=source,
            title=raw_event.get("title", "Unknown Event"),
            description=raw_event.get("description", ""),
            raw_data=raw_event,
            normalized_data={},
            tags=[],
            mitre_techniques=[]
        )
