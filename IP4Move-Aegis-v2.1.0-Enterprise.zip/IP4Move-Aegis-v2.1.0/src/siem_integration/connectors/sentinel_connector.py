"""
Azure Sentinel连接器模块

提供与Azure Sentinel的集成功能，支持Log Analytics和KQL查询。
"""

import json
import asyncio
import logging
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass
from datetime import datetime, timedelta
from urllib.parse import urljoin, quote
import base64
import hmac
import hashlib

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class SentinelAlert:
    """Azure Sentinel告警"""
    title: str
    description: str
    severity: str  # High, Medium, Low, Informational
    status: str  # New, InProgress, Resolved
    timestamp: datetime
    entities: List[Dict[str, Any]]
    custom_details: Optional[Dict[str, Any]] = None


class AzureSentinelConnector:
    """
    Azure Sentinel连接器
    
    提供与Azure Sentinel的集成，支持Log Analytics数据收集和KQL查询。
    
    Example:
        >>> connector = AzureSentinelConnector(
        ...     workspace_id="your-workspace-id",
        ...     shared_key="your-shared-key"
        ... )
        >>> await connector.start()
        >>> await connector.send_log(log_entry)
        >>> results = await connector.kql_query("SecurityEvent | take 10")
        >>> await connector.stop()
    """
    
    # Log Analytics API常量
    LOG_ANALYTICS_API_VERSION = "2016-04-01"
    CONTENT_TYPE = "application/json"
    
    def __init__(
        self,
        workspace_id: str,
        shared_key: str,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        """
        初始化Azure Sentinel连接器
        
        Args:
            workspace_id: Log Analytics工作区ID
            shared_key: 共享密钥
            timeout: 请求超时时间
            max_retries: 最大重试次数
        """
        self.workspace_id = workspace_id
        self.shared_key = shared_key
        self.timeout = timeout
        self.max_retries = max_retries
        
        self._http_session: Optional[Any] = None
        self._running = False
        
        # 构建Log Analytics URL
        self._log_analytics_url = f"https://{workspace_id}.ods.opinsights.azure.com/api/logs?api-version={self.LOG_ANALYTICS_API_VERSION}"
        self._query_url = f"https://api.loganalytics.io/v1/workspaces/{workspace_id}/query"
    
    async def start(self) -> None:
        """启动连接器"""
        self._running = True
        
        try:
            import aiohttp
            self._http_session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )
        except ImportError:
            logger.error("aiohttp is required for Azure Sentinel connector")
            raise
        
        logger.info("Azure Sentinel connector started")
    
    async def stop(self) -> None:
        """停止连接器"""
        self._running = False
        
        if self._http_session:
            await self._http_session.close()
        
        logger.info("Azure Sentinel connector stopped")
    
    async def send_log(
        self,
        log_entry: Dict[str, Any],
        log_type: str = "IP4MoveAegis",
        time_generated: Optional[datetime] = None,
    ) -> bool:
        """
        发送日志到Log Analytics
        
        Args:
            log_entry: 日志条目
            log_type: 日志类型
            time_generated: 生成时间
            
        Returns:
            是否成功
        """
        if not self._http_session:
            return False
        
        # 添加时间戳
        if time_generated:
            log_entry["TimeGenerated"] = time_generated.isoformat()
        
        body = json.dumps([log_entry])
        
        # 构建授权头
        headers = self._build_signature(body, log_type)
        
        try:
            async with self._http_session.post(
                self._log_analytics_url,
                data=body,
                headers=headers,
            ) as response:
                if response.status == 200:
                    logger.debug("Log sent to Azure Sentinel")
                    return True
                else:
                    response_text = await response.text()
                    logger.error(f"Failed to send log: {response.status} - {response_text}")
                    return False
        except Exception as e:
            logger.error(f"Failed to send log: {e}")
            return False
    
    async def send_logs(
        self,
        log_entries: List[Dict[str, Any]],
        log_type: str = "IP4MoveAegis",
    ) -> bool:
        """
        批量发送日志
        
        Args:
            log_entries: 日志条目列表
            log_type: 日志类型
            
        Returns:
            是否成功
        """
        if not self._http_session or not log_entries:
            return False
        
        # Log Analytics限制单次请求30MB
        # 分批发送
        batch_size = 1000
        for i in range(0, len(log_entries), batch_size):
            batch = log_entries[i:i + batch_size]
            
            for entry in batch:
                entry["TimeGenerated"] = datetime.utcnow().isoformat()
            
            body = json.dumps(batch)
            headers = self._build_signature(body, log_type)
            
            try:
                async with self._http_session.post(
                    self._log_analytics_url,
                    data=body,
                    headers=headers,
                ) as response:
                    if response.status != 200:
                        response_text = await response.text()
                        logger.error(f"Failed to send batch: {response.status} - {response_text}")
                        return False
            except Exception as e:
                logger.error(f"Failed to send batch: {e}")
                return False
        
        logger.debug(f"Sent {len(log_entries)} logs to Azure Sentinel")
        return True
    
    def _build_signature(self, body: str, log_type: str) -> Dict[str, str]:
        """
        构建Log Analytics授权签名
        
        Args:
            body: 请求体
            log_type: 日志类型
            
        Returns:
            请求头字典
        """
        date_string = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
        
        # 构建签名字符串
        string_to_hash = f"POST\n{len(body)}\napplication/json\nx-ms-date:{date_string}\n/api/logs"
        
        # 解码共享密钥
        decoded_key = base64.b64decode(self.shared_key)
        
        # 计算HMAC
        encoded_hash = base64.b64encode(
            hmac.new(decoded_key, string_to_hash.encode('utf-8'), hashlib.sha256).digest()
        ).decode('utf-8')
        
        # 构建授权头
        authorization = f"SharedKey {self.workspace_id}:{encoded_hash}"
        
        return {
            "Content-Type": "application/json",
            "Authorization": authorization,
            "Log-Type": log_type,
            "x-ms-date": date_string,
        }
    
    async def kql_query(
        self,
        query: str,
        timespan: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        执行KQL查询
        
        Args:
            query: KQL查询语句
            timespan: 时间范围（如 "PT1H"表示过去1小时）
            
        Returns:
            查询结果列表
        """
        if not self._http_session:
            return []
        
        # 注意：KQL查询需要Azure AD认证
        # 这里简化实现，实际需要获取访问令牌
        logger.warning("KQL query requires Azure AD authentication, simplified implementation")
        return []
    
    async def create_alert(
        self,
        alert: Union[SentinelAlert, Dict[str, Any]],
    ) -> bool:
        """
        创建Sentinel告警
        
        Args:
            alert: 告警数据
            
        Returns:
            是否成功
        """
        if not self._http_session:
            return False
        
        # 注意：创建告警需要Azure REST API
        # 这里简化实现
        logger.warning("Creating Sentinel alert requires Azure REST API, simplified implementation")
        return True
    
    async def get_incidents(
        self,
        status: Optional[str] = None,
        severity: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        获取Sentinel事件
        
        Args:
            status: 状态过滤
            severity: 严重级别过滤
            
        Returns:
            事件列表
        """
        # 注意：需要Azure REST API
        logger.warning("Getting incidents requires Azure REST API, simplified implementation")
        return []
    
    async def update_incident(
        self,
        incident_id: str,
        status: Optional[str] = None,
        owner: Optional[str] = None,
        classification: Optional[str] = None,
    ) -> bool:
        """
        更新Sentinel事件
        
        Args:
            incident_id: 事件ID
            status: 新状态
            owner: 负责人
            classification: 分类
            
        Returns:
            是否成功
        """
        # 注意：需要Azure REST API
        logger.warning("Updating incident requires Azure REST API, simplified implementation")
        return True
    
    async def get_watchlists(self) -> List[Dict[str, Any]]:
        """
        获取监视列表
        
        Returns:
            监视列表
        """
        # 注意：需要Azure REST API
        logger.warning("Getting watchlists requires Azure REST API, simplified implementation")
        return []
    
    async def add_to_watchlist(
        self,
        watchlist_name: str,
        items: List[Dict[str, Any]],
    ) -> bool:
        """
        添加项到监视列表
        
        Args:
            watchlist_name: 监视列表名称
            items: 项目列表
            
        Returns:
            是否成功
        """
        # 注意：需要Azure REST API
        logger.warning("Adding to watchlist requires Azure REST API, simplified implementation")
        return True
    
    async def health_check(self) -> bool:
        """
        健康检查
        
        Returns:
            是否健康
        """
        if not self._http_session:
            return False
        
        try:
            # 发送一个测试日志
            test_log = {"Message": "Health check", "Type": "Test"}
            return await self.send_log(test_log)
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False


# 便捷函数
def create_sentinel_connector(
    workspace_id: str,
    shared_key: str,
) -> AzureSentinelConnector:
    """
    创建Azure Sentinel连接器的工厂函数
    
    Args:
        workspace_id: Log Analytics工作区ID
        shared_key: 共享密钥
        
    Returns:
        Azure Sentinel连接器实例
    """
    return AzureSentinelConnector(
        workspace_id=workspace_id,
        shared_key=shared_key
    )
