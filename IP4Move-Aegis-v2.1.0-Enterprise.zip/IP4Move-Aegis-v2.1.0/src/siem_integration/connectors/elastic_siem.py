"""
Elastic SIEM连接器模块

提供与Elastic SIEM的集成功能，支持Elasticsearch查询和Kibana集成。
"""

import json
import asyncio
import logging
from typing import Optional, Dict, Any, List, Union, AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from urllib.parse import urljoin

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class ElasticDocument:
    """Elastic文档"""
    index: str
    document: Dict[str, Any]
    doc_id: Optional[str] = None
    timestamp: Optional[str] = None


class ElasticSIEMConnector:
    """
    Elastic SIEM连接器
    
    提供与Elastic SIEM的集成，支持Elasticsearch API和Kibana集成。
    
    Example:
        >>> connector = ElasticSIEMConnector(
        ...     hosts=["https://elastic.example.com:9200"],
        ...     username="elastic",
        ...     password="your-password"
        ... )
        >>> await connector.start()
        >>> await connector.index_document(doc)
        >>> results = await connector.search("security-*", {"match": {"event.action": "login"}})
        >>> await connector.stop()
    """
    
    def __init__(
        self,
        hosts: List[str],
        username: Optional[str] = None,
        password: Optional[str] = None,
        api_key: Optional[str] = None,
        verify_ssl: bool = True,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        """
        初始化Elastic SIEM连接器
        
        Args:
            hosts: Elasticsearch主机列表
            username: 用户名
            password: 密码
            api_key: API密钥（优先于用户名/密码）
            verify_ssl: 是否验证SSL证书
            timeout: 请求超时时间
            max_retries: 最大重试次数
        """
        self.hosts = hosts
        self.username = username
        self.password = password
        self.api_key = api_key
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.max_retries = max_retries
        
        self._http_session: Optional[Any] = None
        self._base_url = hosts[0].rstrip("/") if hosts else ""
        self._running = False
    
    async def start(self) -> None:
        """启动连接器"""
        self._running = True
        
        try:
            import aiohttp
            
            headers = {"Content-Type": "application/json"}
            
            if self.api_key:
                headers["Authorization"] = f"ApiKey {self.api_key}"
            
            self._http_session = aiohttp.ClientSession(
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                auth=aiohttp.BasicAuth(self.username, self.password) if self.username and self.password else None
            )
        except ImportError:
            logger.error("aiohttp is required for Elastic connector")
            raise
        
        logger.info("Elastic SIEM connector started")
    
    async def stop(self) -> None:
        """停止连接器"""
        self._running = False
        
        if self._http_session:
            await self._http_session.close()
        
        logger.info("Elastic SIEM connector stopped")
    
    async def index_document(
        self,
        document: Union[ElasticDocument, Dict[str, Any]],
        index: str = "security-events",
        doc_id: Optional[str] = None,
    ) -> bool:
        """
        索引文档到Elasticsearch
        
        Args:
            document: 文档数据
            index: 索引名称
            doc_id: 文档ID
            
        Returns:
            是否成功
        """
        if not self._http_session:
            return False
        
        if isinstance(document, dict):
            doc = document
        else:
            doc = document.document
            index = document.index
            doc_id = document.doc_id
        
        # 添加时间戳
        if "@timestamp" not in doc:
            doc["@timestamp"] = datetime.utcnow().isoformat()
        
        url = f"{self._base_url}/{index}/_doc"
        if doc_id:
            url = f"{self._base_url}/{index}/_doc/{doc_id}"
        
        try:
            async with self._http_session.post(
                url,
                json=doc,
                ssl=self.verify_ssl
            ) as response:
                if response.status in [200, 201]:
                    logger.debug(f"Document indexed to {index}")
                    return True
                else:
                    response_text = await response.text()
                    logger.error(f"Failed to index document: {response.status} - {response_text}")
                    return False
        except Exception as e:
            logger.error(f"Failed to index document: {e}")
            return False
    
    async def bulk_index(
        self,
        documents: List[Union[ElasticDocument, Dict[str, Any]]],
        index: str = "security-events",
    ) -> bool:
        """
        批量索引文档
        
        Args:
            documents: 文档列表
            index: 索引名称
            
        Returns:
            是否成功
        """
        if not self._http_session or not documents:
            return False
        
        # 构建bulk请求
        bulk_data = []
        for doc in documents:
            if isinstance(doc, ElasticDocument):
                doc_body = doc.document
                target_index = doc.index
                doc_id = doc.doc_id
            else:
                doc_body = doc
                target_index = index
                doc_id = None
            
            # 添加时间戳
            if "@timestamp" not in doc_body:
                doc_body["@timestamp"] = datetime.utcnow().isoformat()
            
            # 索引操作元数据
            action = {"index": {"_index": target_index}}
            if doc_id:
                action["index"]["_id"] = doc_id
            
            bulk_data.append(json.dumps(action))
            bulk_data.append(json.dumps(doc_body))
        
        bulk_body = "\n".join(bulk_data) + "\n"
        
        url = f"{self._base_url}/_bulk"
        
        try:
            async with self._http_session.post(
                url,
                data=bulk_body,
                headers={"Content-Type": "application/x-ndjson"},
                ssl=self.verify_ssl
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    if result.get("errors"):
                        logger.warning(f"Bulk index completed with errors: {result}")
                    else:
                        logger.debug(f"Bulk indexed {len(documents)} documents")
                    return True
                else:
                    response_text = await response.text()
                    logger.error(f"Bulk index failed: {response.status} - {response_text}")
                    return False
        except Exception as e:
            logger.error(f"Bulk index failed: {e}")
            return False
    
    async def search(
        self,
        index: str,
        query: Dict[str, Any],
        size: int = 10,
        sort: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        """
        搜索文档
        
        Args:
            index: 索引名称
            query: Elasticsearch查询DSL
            size: 返回数量
            sort: 排序规则
            
        Returns:
            搜索结果列表
        """
        if not self._http_session:
            return []
        
        url = f"{self._base_url}/{index}/_search"
        
        body = {
            "query": query,
            "size": size
        }
        
        if sort:
            body["sort"] = sort
        
        try:
            async with self._http_session.post(
                url,
                json=body,
                ssl=self.verify_ssl
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    hits = result.get("hits", {}).get("hits", [])
                    return [hit["_source"] for hit in hits]
                else:
                    response_text = await response.text()
                    logger.error(f"Search failed: {response.status} - {response_text}")
                    return []
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return []
    
    async def get_detection_rules(self) -> List[Dict[str, Any]]:
        """
        获取Elastic Security检测规则
        
        Returns:
            检测规则列表
        """
        if not self._http_session:
            return []
        
        url = f"{self._base_url}/.kibana/_search"
        
        query = {
            "query": {
                "bool": {
                    "filter": [
                        {"term": {"type": "alert"}},
                        {"term": {"alert.alertTypeId": "siem.signals"}}
                    ]
                }
            },
            "size": 100
        }
        
        try:
            async with self._http_session.post(
                url,
                json=query,
                ssl=self.verify_ssl
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    hits = result.get("hits", {}).get("hits", [])
                    return [hit["_source"] for hit in hits]
                else:
                    logger.error(f"Failed to get detection rules: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Failed to get detection rules: {e}")
            return []
    
    async def create_detection_rule(self, rule: Dict[str, Any]) -> bool:
        """
        创建检测规则
        
        Args:
            rule: 规则配置
            
        Returns:
            是否成功
        """
        if not self._http_session:
            return False
        
        url = f"{self._base_url}/api/detection_engine/rules"
        
        try:
            async with self._http_session.post(
                url,
                json=rule,
                ssl=self.verify_ssl
            ) as response:
                if response.status in [200, 201]:
                    logger.info("Detection rule created successfully")
                    return True
                else:
                    response_text = await response.text()
                    logger.error(f"Failed to create rule: {response.status} - {response_text}")
                    return False
        except Exception as e:
            logger.error(f"Failed to create rule: {e}")
            return False
    
    async def health_check(self) -> bool:
        """
        健康检查
        
        Returns:
            是否健康
        """
        if not self._http_session:
            return False
        
        try:
            url = f"{self._base_url}/_cluster/health"
            async with self._http_session.get(url, ssl=self.verify_ssl) as response:
                return response.status == 200
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False


# 便捷函数
def create_elastic_connector(
    hosts: List[str],
    username: Optional[str] = None,
    password: Optional[str] = None,
    api_key: Optional[str] = None,
) -> ElasticSIEMConnector:
    """
    创建Elastic SIEM连接器的工厂函数
    
    Args:
        hosts: Elasticsearch主机列表
        username: 用户名
        password: 密码
        api_key: API密钥
        
    Returns:
        Elastic SIEM连接器实例
    """
    return ElasticSIEMConnector(
        hosts=hosts,
        username=username,
        password=password,
        api_key=api_key
    )
