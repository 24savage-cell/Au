"""
Splunk连接器模块

提供与Splunk SIEM的集成功能，支持HEC接口和SPL查询。
"""

import json
import asyncio
import logging
from typing import Optional, Dict, Any, List, Union, AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from urllib.parse import urljoin

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class SplunkEvent:
    """Splunk事件"""
    time: float
    source: str
    sourcetype: str
    host: str
    index: str
    event: Dict[str, Any]
    fields: Optional[Dict[str, Any]] = None


class SplunkConnector:
    """
    Splunk连接器
    
    提供与Splunk的集成，支持HTTP Event Collector (HEC)发送事件
    和SPL查询检索数据。
    
    Example:
        >>> connector = SplunkConnector(
        ...     base_url="https://splunk.example.com:8088",
        ...     hec_token="your-hec-token"
        ... )
        >>> await connector.start()
        >>> await connector.send_event(event)
        >>> results = await connector.search("search index=main | head 10")
        >>> await connector.stop()
    """
    
    def __init__(
        self,
        base_url: str,
        hec_token: str,
        verify_ssl: bool = True,
        timeout: float = 30.0,
        max_retries: int = 3,
        batch_size: int = 100,
        flush_interval: float = 5.0,
    ):
        """
        初始化Splunk连接器
        
        Args:
            base_url: Splunk HEC基础URL
            hec_token: HEC令牌
            verify_ssl: 是否验证SSL证书
            timeout: 请求超时时间
            max_retries: 最大重试次数
            batch_size: 批量发送大小
            flush_interval: 自动刷新间隔（秒）
        """
        self.base_url = base_url.rstrip("/")
        self.hec_token = hec_token
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.max_retries = max_retries
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        
        self._http_session: Optional[Any] = None
        self._event_queue: List[SplunkEvent] = []
        self._lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None
        self._running = False
    
    async def start(self) -> None:
        """启动连接器"""
        self._running = True
        
        try:
            import aiohttp
            self._http_session = aiohttp.ClientSession(
                headers={
                    "Authorization": f"Splunk {self.hec_token}",
                    "Content-Type": "application/json"
                },
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )
        except ImportError:
            logger.error("aiohttp is required for Splunk connector")
            raise
        
        # 启动定时刷新任务
        self._flush_task = asyncio.create_task(self._periodic_flush())
        
        logger.info("Splunk connector started")
    
    async def stop(self) -> None:
        """停止连接器"""
        self._running = False
        
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        
        # 刷新剩余事件
        await self._flush()
        
        if self._http_session:
            await self._http_session.close()
        
        logger.info("Splunk connector stopped")
    
    async def send_event(
        self,
        event: Union[SplunkEvent, Dict[str, Any]],
        index: str = "main",
        sourcetype: str = "_json",
        source: str = "ip4move-aegis",
    ) -> bool:
        """
        发送单个事件到Splunk
        
        Args:
            event: 事件数据
            index: Splunk索引
            sourcetype: 源类型
            source: 源名称
            
        Returns:
            是否成功
        """
        if isinstance(event, dict):
            splunk_event = SplunkEvent(
                time=datetime.now().timestamp(),
                source=source,
                sourcetype=sourcetype,
                host="ip4move-aegis",
                index=index,
                event=event
            )
        else:
            splunk_event = event
        
        async with self._lock:
            self._event_queue.append(splunk_event)
            
            if len(self._event_queue) >= self.batch_size:
                asyncio.create_task(self._flush())
        
        return True
    
    async def send_events(
        self,
        events: List[Union[SplunkEvent, Dict[str, Any]]],
        index: str = "main",
        sourcetype: str = "_json",
    ) -> bool:
        """
        批量发送事件到Splunk
        
        Args:
            events: 事件列表
            index: Splunk索引
            sourcetype: 源类型
            
        Returns:
            是否成功
        """
        for event in events:
            await self.send_event(event, index, sourcetype)
        return True
    
    async def _periodic_flush(self) -> None:
        """定时刷新队列"""
        while self._running:
            try:
                await asyncio.sleep(self.flush_interval)
                await self._flush()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic flush: {e}")
    
    async def _flush(self) -> None:
        """刷新队列中的所有事件"""
        events_to_send: List[SplunkEvent] = []
        
        async with self._lock:
            if self._event_queue:
                events_to_send = self._event_queue.copy()
                self._event_queue.clear()
        
        if not events_to_send:
            return
        
        try:
            await self._send_hec_batch(events_to_send)
        except Exception as e:
            logger.error(f"Failed to send events to Splunk: {e}")
    
    async def _send_hec_batch(self, events: List[SplunkEvent]) -> None:
        """通过HEC批量发送事件"""
        if not self._http_session:
            return
        
        hec_url = urljoin(self.base_url, "/services/collector/event")
        
        # 构建批量请求数据
        data_lines = []
        for event in events:
            payload = {
                "time": event.time,
                "source": event.source,
                "sourcetype": event.sourcetype,
                "host": event.host,
                "index": event.index,
                "event": event.event,
            }
            if event.fields:
                payload["fields"] = event.fields
            data_lines.append(json.dumps(payload))
        
        data = "\n".join(data_lines)
        
        for attempt in range(self.max_retries):
            try:
                async with self._http_session.post(
                    hec_url,
                    data=data,
                    ssl=self.verify_ssl
                ) as response:
                    if response.status == 200:
                        result = await response.json()
                        if result.get("code") == 0:
                            logger.debug(f"Sent {len(events)} events to Splunk")
                            return
                        else:
                            logger.error(f"Splunk HEC error: {result}")
                    else:
                        response_text = await response.text()
                        logger.error(f"Splunk HEC HTTP error: {response.status} - {response_text}")
            except Exception as e:
                logger.error(f"Attempt {attempt + 1} failed: {e}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2 ** attempt)  # 指数退避
                else:
                    raise
    
    async def search(
        self,
        query: str,
        earliest: Optional[str] = None,
        latest: Optional[str] = None,
        max_results: int = 100,
    ) -> List[Dict[str, Any]]:
        """
        执行SPL查询
        
        Args:
            query: SPL查询语句
            earliest: 最早时间（如 "-1h", "2024-01-01T00:00:00"）
            latest: 最晚时间
            max_results: 最大结果数
            
        Returns:
            查询结果列表
        """
        # 注意：SPL查询需要REST API访问，不是HEC
        # 这里简化实现，实际应该使用Splunk SDK
        logger.warning("SPL search requires Splunk REST API access, not implemented in HEC connector")
        return []
    
    async def health_check(self) -> bool:
        """
        健康检查
        
        Returns:
            是否健康
        """
        if not self._http_session:
            return False
        
        try:
            hec_url = urljoin(self.base_url, "/services/collector/health")
            async with self._http_session.get(hec_url, ssl=self.verify_ssl) as response:
                return response.status == 200
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False


# 便捷函数
def create_splunk_connector(
    base_url: str,
    hec_token: str,
) -> SplunkConnector:
    """
    创建Splunk连接器的工厂函数
    
    Args:
        base_url: Splunk HEC基础URL
        hec_token: HEC令牌
        
    Returns:
        Splunk连接器实例
    """
    return SplunkConnector(base_url=base_url, hec_token=hec_token)
