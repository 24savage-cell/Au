"""
ECS标准化模块

实现Elastic Common Schema (ECS)映射，将安全事件标准化为ECS格式。
"""

from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass
from datetime import datetime
import logging

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class ECSFieldMapping:
    """ECS字段映射定义"""
    source_field: str
    ecs_field: str
    transform: Optional[Callable[[Any], Any]] = None


class ECSNormalizer:
    """
    ECS标准化器
    
    将各种安全事件格式转换为Elastic Common Schema (ECS)标准格式。
    
    ECS版本: 8.x
    
    Example:
        >>> normalizer = ECSNormalizer()
        >>> ecs_event = normalizer.normalize(event, event_type="network")
    """
    
    # ECS版本
    ECS_VERSION = "8.11.0"
    
    # ECS核心字段集
    CORE_FIELDS = [
        "@timestamp",
        "message",
        "ecs.version",
        "event.kind",
        "event.category",
        "event.type",
        "event.action",
        "event.outcome",
    ]
    
    def __init__(self):
        """初始化ECS标准化器"""
        self._custom_mappings: Dict[str, List[ECSFieldMapping]] = {}
        self._field_mappings = self._build_default_mappings()
    
    def _build_default_mappings(self) -> Dict[str, Dict[str, str]]:
        """构建默认字段映射"""
        return {
            # 通用字段映射
            "timestamp": "@timestamp",
            "time": "@timestamp",
            "msg": "message",
            "log": "message",
            "src_ip": "source.ip",
            "source_ip": "source.ip",
            "dst_ip": "destination.ip",
            "dest_ip": "destination.ip",
            "target_ip": "destination.ip",
            "src_port": "source.port",
            "source_port": "source.port",
            "dst_port": "destination.port",
            "dest_port": "destination.port",
            "target_port": "destination.port",
            "src_host": "source.hostname",
            "dst_host": "destination.hostname",
            "user": "user.name",
            "username": "user.name",
            "user_id": "user.id",
            "hostname": "host.hostname",
            "host_name": "host.hostname",
            "host_ip": "host.ip",
            "process_name": "process.name",
            "process_id": "process.pid",
            "pid": "process.pid",
            "file_path": "file.path",
            "file_name": "file.name",
            "hash_md5": "file.hash.md5",
            "hash_sha1": "file.hash.sha1",
            "hash_sha256": "file.hash.sha256",
            "url": "url.full",
            "domain": "url.domain",
            "threat_type": "threat.indicator.type",
            "threat_value": "threat.indicator.ip",
            "severity": "event.severity",
            "level": "event.severity",
            "action": "event.action",
            "outcome": "event.outcome",
            "result": "event.outcome",
            "status": "event.outcome",
        }
    
    def normalize(
        self,
        event: Dict[str, Any],
        event_type: str = "event",
        event_category: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        标准化事件为ECS格式
        
        Args:
            event: 原始事件
            event_type: 事件类型
            event_category: 事件类别
            
        Returns:
            ECS格式的事件
        """
        ecs_event = {
            "ecs": {"version": self.ECS_VERSION}
        }
        
        # 处理时间戳
        if "@timestamp" not in event:
            ecs_event["@timestamp"] = datetime.utcnow().isoformat()
        
        # 应用字段映射
        for source_field, value in event.items():
            ecs_field = self._field_mappings.get(source_field, source_field)
            
            # 处理嵌套字段
            self._set_nested_field(ecs_event, ecs_field, value)
        
        # 设置事件元数据
        ecs_event["event"] = ecs_event.get("event", {})
        ecs_event["event"]["kind"] = event_type
        
        if event_category:
            ecs_event["event"]["category"] = event_category
        
        # 应用自定义映射
        if event_type in self._custom_mappings:
            for mapping in self._custom_mappings[event_type]:
                if mapping.source_field in event:
                    value = event[mapping.source_field]
                    if mapping.transform:
                        value = mapping.transform(value)
                    self._set_nested_field(ecs_event, mapping.ecs_field, value)
        
        return ecs_event
    
    def _set_nested_field(self, obj: Dict[str, Any], field: str, value: Any) -> None:
        """设置嵌套字段值"""
        parts = field.split(".")
        current = obj
        
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
        
        current[parts[-1]] = value
    
    def _get_nested_field(self, obj: Dict[str, Any], field: str) -> Any:
        """获取嵌套字段值"""
        parts = field.split(".")
        current = obj
        
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        
        return current
    
    def add_custom_mapping(
        self,
        event_type: str,
        source_field: str,
        ecs_field: str,
        transform: Optional[Callable[[Any], Any]] = None
    ) -> None:
        """
        添加自定义字段映射
        
        Args:
            event_type: 事件类型
            source_field: 源字段名
            ecs_field: ECS字段名
            transform: 可选的转换函数
        """
        if event_type not in self._custom_mappings:
            self._custom_mappings[event_type] = []
        
        self._custom_mappings[event_type].append(
            ECSFieldMapping(source_field, ecs_field, transform)
        )
    
    def normalize_network_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        标准化网络事件
        
        Args:
            event: 原始网络事件
            
        Returns:
            ECS格式的网络事件
        """
        ecs_event = self.normalize(event, "event", "network")
        
        # 确保网络字段存在
        if "network" not in ecs_event:
            ecs_event["network"] = {}
        
        # 推断网络协议
        if "destination.port" in event:
            port = event["destination.port"]
            ecs_event["network"]["protocol"] = self._infer_protocol(port)
        
        return ecs_event
    
    def normalize_authentication_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        标准化认证事件
        
        Args:
            event: 原始认证事件
            
        Returns:
            ECS格式的认证事件
        """
        ecs_event = self.normalize(event, "event", "authentication")
        
        # 设置认证相关字段
        ecs_event["event"]["category"] = "authentication"
        
        if "action" in event:
            action = event["action"].lower()
            if action in ["login", "logon", "signin"]:
                ecs_event["event"]["type"] = "start"
            elif action in ["logout", "logoff", "signout"]:
                ecs_event["event"]["type"] = "end"
        
        return ecs_event
    
    def normalize_file_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        标准化文件事件
        
        Args:
            event: 原始文件事件
            
        Returns:
            ECS格式的文件事件
        """
        ecs_event = self.normalize(event, "event", "file")
        
        # 设置文件相关字段
        ecs_event["event"]["category"] = "file"
        
        if "action" in event:
            action = event["action"].lower()
            if action in ["created", "create", "new"]:
                ecs_event["event"]["type"] = "creation"
            elif action in ["deleted", "delete", "removed"]:
                ecs_event["event"]["type"] = "deletion"
            elif action in ["modified", "modify", "changed"]:
                ecs_event["event"]["type"] = "change"
            elif action in ["accessed", "access", "read"]:
                ecs_event["event"]["type"] = "access"
        
        return ecs_event
    
    def normalize_process_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        标准化进程事件
        
        Args:
            event: 原始进程事件
            
        Returns:
            ECS格式的进程事件
        """
        ecs_event = self.normalize(event, "event", "process")
        
        # 设置进程相关字段
        ecs_event["event"]["category"] = "process"
        
        if "action" in event:
            action = event["action"].lower()
            if action in ["started", "start", "created", "create"]:
                ecs_event["event"]["type"] = "start"
            elif action in ["stopped", "stop", "terminated", "end"]:
                ecs_event["event"]["type"] = "end"
        
        return ecs_event
    
    def normalize_threat_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        标准化威胁事件
        
        Args:
            event: 原始威胁事件
            
        Returns:
            ECS格式的威胁事件
        """
        ecs_event = self.normalize(event, "alert", "threat")
        
        # 设置威胁相关字段
        ecs_event["event"]["kind"] = "alert"
        ecs_event["event"]["category"] = "threat"
        
        # 设置威胁级别
        if "severity" in event:
            severity = event["severity"]
            if isinstance(severity, str):
                severity_map = {
                    "critical": 1,
                    "high": 2,
                    "medium": 3,
                    "low": 4,
                    "informational": 5,
                }
                ecs_event["event"]["severity"] = severity_map.get(severity.lower(), 3)
            else:
                ecs_event["event"]["severity"] = severity
        
        return ecs_event
    
    def _infer_protocol(self, port: int) -> str:
        """根据端口推断协议"""
        protocol_map = {
            20: "ftp",
            21: "ftp",
            22: "ssh",
            23: "telnet",
            25: "smtp",
            53: "dns",
            80: "http",
            110: "pop3",
            143: "imap",
            443: "https",
            445: "smb",
            3306: "mysql",
            3389: "rdp",
            5432: "postgresql",
            6379: "redis",
            8080: "http",
            8443: "https",
            9200: "elasticsearch",
            27017: "mongodb",
        }
        return protocol_map.get(port, "unknown")
    
    def validate(self, event: Dict[str, Any]) -> List[str]:
        """
        验证ECS事件
        
        Args:
            event: ECS事件
            
        Returns:
            验证错误列表
        """
        errors = []
        
        # 检查必需字段
        if "@timestamp" not in event:
            errors.append("Missing required field: @timestamp")
        
        if "ecs" not in event or "version" not in event.get("ecs", {}):
            errors.append("Missing required field: ecs.version")
        
        if "event" not in event:
            errors.append("Missing required field: event")
        else:
            event_obj = event["event"]
            if "kind" not in event_obj:
                errors.append("Missing required field: event.kind")
        
        return errors


# 便捷函数
def create_ecs_normalizer() -> ECSNormalizer:
    """
    创建ECS标准化器的工厂函数
    
    Returns:
        ECS标准化器实例
    """
    return ECSNormalizer()


def normalize_to_ecs(event: Dict[str, Any], event_type: str = "event") -> Dict[str, Any]:
    """
    便捷函数：标准化事件为ECS格式
    
    Args:
        event: 原始事件
        event_type: 事件类型
        
    Returns:
        ECS格式的事件
    """
    normalizer = ECSNormalizer()
    return normalizer.normalize(event, event_type)
