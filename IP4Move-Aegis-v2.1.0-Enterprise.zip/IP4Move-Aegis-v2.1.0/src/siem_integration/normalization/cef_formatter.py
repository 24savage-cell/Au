"""
CEF格式化模块

实现Common Event Format (CEF)格式化，将安全事件转换为CEF格式。
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from datetime import datetime
import logging
import re

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class CEFEvent:
    """CEF事件"""
    device_vendor: str
    device_product: str
    device_version: str
    signature_id: str
    name: str
    severity: str  # Unknown, Low, Medium, High, Very-High
    extensions: Dict[str, Any]


class CEFFormatter:
    """
    CEF格式化器
    
    将安全事件转换为Common Event Format (CEF)标准格式。
    
    CEF格式: CEF:Version|Device Vendor|Device Product|Device Version|
             Signature ID|Name|Severity|Extension
    
    Example:
        >>> formatter = CEFFormatter()
        >>> cef_string = formatter.format(event)
    """
    
    # CEF版本
    CEF_VERSION = "0"
    
    # 需要转义的字符
    ESCAPE_CHARS = {
        "\\": "\\\\",
        "|": "\\|",
        "\n": "\\n",
        "\r": "\\r",
        "=": "\\=",
    }
    
    # 扩展字段名映射
    EXTENSION_MAPPINGS = {
        "src_ip": "src",
        "source_ip": "src",
        "dst_ip": "dst",
        "destination_ip": "dst",
        "src_port": "spt",
        "source_port": "spt",
        "dst_port": "dpt",
        "destination_port": "dpt",
        "source_host": "shost",
        "destination_host": "dhost",
        "user": "suser",
        "username": "suser",
        "target_user": "tuser",
        "file_path": "filePath",
        "file_name": "fname",
        "file_hash": "fileHash",
        "url": "request",
        "request_url": "request",
        "http_method": "requestMethod",
        "user_agent": "requestClientApplication",
        "status_code": "deviceEventCategory",
        "bytes_in": "in",
        "bytes_out": "out",
        "protocol": "proto",
        "process_name": "act",
        "process_id": "pid",
        "message": "msg",
        "device_action": "act",
        "device_event_class_id": "deviceEventClassId",
        "device_direction": "deviceDirection",
        "external_id": "externalId",
        "reason": "reason",
        "start_time": "start",
        "end_time": "end",
        "duration": "duration",
    }
    
    def __init__(
        self,
        device_vendor: str = "IP4Move",
        device_product: str = "Aegis",
        device_version: str = "1.0.0",
    ):
        """
        初始化CEF格式化器
        
        Args:
            device_vendor: 设备厂商
            device_product: 设备产品
            device_version: 设备版本
        """
        self.device_vendor = device_vendor
        self.device_product = device_product
        self.device_version = device_version
    
    def format(
        self,
        event: Dict[str, Any],
        signature_id: Optional[str] = None,
        name: Optional[str] = None,
        severity: Optional[str] = None,
    ) -> str:
        """
        格式化事件为CEF字符串
        
        Args:
            event: 原始事件
            signature_id: 签名ID
            name: 事件名称
            severity: 严重级别
            
        Returns:
            CEF格式字符串
        """
        # 提取或生成必需字段
        sig_id = signature_id or event.get("signature_id", "0")
        event_name = name or event.get("name", event.get("event_name", "Unknown"))
        sev = severity or self._map_severity(event.get("severity", "Medium"))
        
        # 构建CEF头部
        header = self._build_header(sig_id, event_name, sev)
        
        # 构建扩展字段
        extensions = self._build_extensions(event)
        
        # 组合CEF字符串
        cef = f"{header}|{extensions}"
        
        return cef
    
    def _build_header(self, signature_id: str, name: str, severity: str) -> str:
        """构建CEF头部"""
        parts = [
            f"CEF:{self.CEF_VERSION}",
            self._escape(self.device_vendor),
            self._escape(self.device_product),
            self._escape(self.device_version),
            self._escape(str(signature_id)),
            self._escape(name),
            self._escape(severity),
        ]
        return "|".join(parts)
    
    def _build_extensions(self, event: Dict[str, Any]) -> str:
        """构建CEF扩展字段"""
        extensions = []
        
        # 添加时间戳
        if "timestamp" in event:
            timestamp = event["timestamp"]
            if isinstance(timestamp, datetime):
                timestamp = int(timestamp.timestamp() * 1000)
            extensions.append(f"rt={timestamp}")
        
        # 映射其他字段
        for key, value in event.items():
            if key in ["signature_id", "name", "event_name", "severity", "timestamp"]:
                continue
            
            # 查找CEF扩展字段名
            cef_key = self.EXTENSION_MAPPINGS.get(key, key)
            
            # 格式化值
            formatted_value = self._format_extension_value(value)
            if formatted_value is not None:
                extensions.append(f"{cef_key}={formatted_value}")
        
        return " ".join(extensions)
    
    def _format_extension_value(self, value: Any) -> Optional[str]:
        """格式化扩展字段值"""
        if value is None:
            return None
        
        if isinstance(value, str):
            return self._escape(value)
        elif isinstance(value, (int, float)):
            return str(value)
        elif isinstance(value, datetime):
            return str(int(value.timestamp() * 1000))
        elif isinstance(value, bool):
            return "true" if value else "false"
        else:
            return self._escape(str(value))
    
    def _escape(self, value: str) -> str:
        """转义CEF特殊字符"""
        for char, escaped in self.ESCAPE_CHARS.items():
            value = value.replace(char, escaped)
        return value
    
    def _map_severity(self, severity: Any) -> str:
        """映射严重级别到CEF标准"""
        if isinstance(severity, str):
            severity_map = {
                "unknown": "Unknown",
                "low": "Low",
                "medium": "Medium",
                "high": "High",
                "critical": "Very-High",
                "very-high": "Very-High",
                "informational": "Unknown",
            }
            return severity_map.get(severity.lower(), "Medium")
        elif isinstance(severity, int):
            if severity <= 2:
                return "Low"
            elif severity <= 5:
                return "Medium"
            elif severity <= 8:
                return "High"
            else:
                return "Very-High"
        else:
            return "Medium"
    
    def format_batch(
        self,
        events: List[Dict[str, Any]],
        signature_id_prefix: str = "",
    ) -> List[str]:
        """
        批量格式化事件
        
        Args:
            events: 事件列表
            signature_id_prefix: 签名ID前缀
            
        Returns:
            CEF字符串列表
        """
        cef_events = []
        for i, event in enumerate(events):
            sig_id = f"{signature_id_prefix}{i}" if signature_id_prefix else str(i)
            cef = self.format(event, signature_id=sig_id)
            cef_events.append(cef)
        return cef_events
    
    def parse(self, cef_string: str) -> Optional[CEFEvent]:
        """
        解析CEF字符串
        
        Args:
            cef_string: CEF格式字符串
            
        Returns:
            CEFEvent对象或None
        """
        try:
            # 解析头部
            # CEF:Version|Device Vendor|Device Product|Device Version|Signature ID|Name|Severity|Extension
            
            if not cef_string.startswith("CEF:"):
                logger.error("Invalid CEF format: missing CEF prefix")
                return None
            
            # 找到扩展部分的分隔位置
            # 扩展部分在Severity之后，以空格分隔
            parts = cef_string[4:].split("|")  # 移除"CEF:"前缀
            
            if len(parts) < 7:
                logger.error(f"Invalid CEF format: expected 7+ parts, got {len(parts)}")
                return None
            
            version = parts[0]
            device_vendor = self._unescape(parts[1])
            device_product = self._unescape(parts[2])
            device_version = self._unescape(parts[3])
            signature_id = self._unescape(parts[4])
            name = self._unescape(parts[5])
            severity = self._unescape(parts[6])
            
            # 解析扩展字段
            extensions = {}
            if len(parts) > 7:
                extension_str = "|".join(parts[7:])
                extensions = self._parse_extensions(extension_str)
            
            return CEFEvent(
                device_vendor=device_vendor,
                device_product=device_product,
                device_version=device_version,
                signature_id=signature_id,
                name=name,
                severity=severity,
                extensions=extensions
            )
            
        except Exception as e:
            logger.error(f"Failed to parse CEF string: {e}")
            return None
    
    def _parse_extensions(self, extension_str: str) -> Dict[str, Any]:
        """解析扩展字段"""
        extensions = {}
        
        # 扩展字段格式: key=value key=value ...
        # 值可能包含空格，需要特殊处理
        pattern = r'(\w+)=([^=]+)(?=\s+\w+=|$)'
        matches = re.findall(pattern, extension_str)
        
        for key, value in matches:
            value = value.strip()
            value = self._unescape(value)
            extensions[key] = value
        
        return extensions
    
    def _unescape(self, value: str) -> str:
        """反转义CEF特殊字符"""
        # 按反向顺序反转义
        reverse_escape = {
            "\\n": "\n",
            "\\r": "\r",
            "\\=": "=",
            "\\|": "|",
            "\\\\": "\\",
        }
        for escaped, char in reverse_escape.items():
            value = value.replace(escaped, char)
        return value
    
    def add_extension_mapping(self, source_field: str, cef_field: str) -> None:
        """
        添加扩展字段映射
        
        Args:
            source_field: 源字段名
            cef_field: CEF扩展字段名
        """
        self.EXTENSION_MAPPINGS[source_field] = cef_field


# 便捷函数
def create_cef_formatter(
    device_vendor: str = "IP4Move",
    device_product: str = "Aegis",
) -> CEFFormatter:
    """
    创建CEF格式化器的工厂函数
    
    Args:
        device_vendor: 设备厂商
        device_product: 设备产品
        
    Returns:
        CEF格式化器实例
    """
    return CEFFormatter(
        device_vendor=device_vendor,
        device_product=device_product
    )


def format_to_cef(event: Dict[str, Any], **kwargs) -> str:
    """
    便捷函数：格式化事件为CEF字符串
    
    Args:
        event: 原始事件
        **kwargs: 其他格式化参数
        
    Returns:
        CEF格式字符串
    """
    formatter = CEFFormatter()
    return formatter.format(event, **kwargs)
