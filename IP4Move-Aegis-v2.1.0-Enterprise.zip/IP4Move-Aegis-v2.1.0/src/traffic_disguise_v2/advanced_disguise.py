"""
流量伪装技术全面升级模块 - 核心实现
====================================

Advanced Traffic Disguise Module - Core Implementation

本模块实现了四种高级流量伪装技术:
1. ProtocolStackSimulator - 真实协议栈模拟器
2. WebRTCDisguiser - WebRTC流量伪装器
3. DomainGeneratorDGA - 动态域名生成器
4. CDNRelayManager - CDN中转管理器

所有类均支持异步操作，使用type hints，包含完整的错误处理和日志记录。
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import random
import re
import struct
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Set, Tuple

# ============================================================================
# 日志配置 / Logging Configuration
# ============================================================================

logger = logging.getLogger(__name__)


# ============================================================================
# 数据类与枚举 / Data Classes and Enums
# ============================================================================

class ProtocolType(Enum):
    """支持的协议类型枚举"""
    DOH = auto()          # DNS over HTTPS
    TLS_13 = auto()       # TLS 1.3
    HTTP2 = auto()        # HTTP/2
    QUIC = auto()         # QUIC协议
    WEBRTC = auto()       # WebRTC


class DNSRecordType(Enum):
    """DNS记录类型枚举"""
    A = "A"
    AAAA = "AAAA"
    CNAME = "CNAME"
    MX = "MX"
    TXT = "TXT"
    NS = "NS"


class CDNProvider(Enum):
    """CDN提供商枚举"""
    CLOUDFLARE = "cloudflare"
    AKAMAI = "akamai"
    FASTLY = "fastly"
    CUSTOM = "custom"


@dataclass
class DNSCacheEntry:
    """DNS缓存条目

    Attributes:
        domain: 查询的域名
        record_type: DNS记录类型
        answer: DNS响应答案
        ttl: 生存时间(秒)
        created_at: 缓存创建时间戳
        query_count: 该条目被查询的次数
    """
    domain: str
    record_type: DNSRecordType
    answer: str
    ttl: int = 300
    created_at: float = field(default_factory=time.time)
    query_count: int = 0

    @property
    def is_expired(self) -> bool:
        """检查缓存是否已过期"""
        return (time.time() - self.created_at) > self.ttl


@dataclass
class TLSHandshakeState:
    """TLS 1.3握手状态

    Attributes:
        client_random: 客户端随机数
        server_random: 服务端随机数
        session_id: 会话ID
        cipher_suite: 选择的密码套件
        handshake_complete: 握手是否完成
        key_material: 密钥材料
    """
    client_random: bytes = b""
    server_random: bytes = b""
    session_id: bytes = b""
    cipher_suite: str = "TLS_AES_256_GCM_SHA384"
    handshake_complete: bool = False
    key_material: bytes = b""


@dataclass
class HTTP2Stream:
    """HTTP/2流状态

    Attributes:
        stream_id: 流标识符
        state: 流状态(open/closed/half_closed)
        weight: 流优先级权重
        dependency: 依赖的流ID
        send_buffer: 发送缓冲区
    """
    stream_id: int
    state: str = "idle"
    weight: int = 16
    dependency: int = 0
    send_buffer: bytes = b""


@dataclass
class QUICConnectionState:
    """QUIC连接状态

    Attributes:
        connection_id: 连接ID
        version: QUIC版本号
        packet_number: 当前包序号
        peer_address: 对端地址
        handshake_complete: 握手是否完成
    """
    connection_id: bytes = b""
    version: int = 1
    packet_number: int = 0
    peer_address: str = ""
    handshake_complete: bool = False


@dataclass
class WebRTCSession:
    """WebRTC会话状态

    Attributes:
        session_id: 会话唯一标识
        ice_ufrag: ICE用户名片段
    ice_password: ICE密码
    dtls_fingerprint: DTLS证书指纹
    sctp_port: SCTP端口
    channels: 数据通道列表
    """
    session_id: str = ""
    ice_ufrag: str = ""
    ice_password: str = ""
    dtls_fingerprint: str = ""
    sctp_port: int = 5000
    channels: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class GeneratedDomain:
    """生成的域名信息

    Attributes:
        domain: 生成的完整域名
        sld: 二级域名
        tld: 顶级域名
        generated_at: 生成时间戳
        expires_at: 过期时间戳
        is_active: 是否活跃
    """
    domain: str
    sld: str
    tld: str
    generated_at: float = field(default_factory=time.time)
    expires_at: float = 0.0
    is_active: bool = True

    def __post_init__(self) -> None:
        """后初始化：设置默认过期时间为生成后24小时"""
        if self.expires_at == 0.0:
            self.expires_at = self.generated_at + 86400


@dataclass
class CDNRelayConfig:
    """CDN中转配置

    Attributes:
        provider: CDN提供商
        edge_nodes: 边缘节点列表
        api_token: API访问令牌
        region: 部署区域
        max_connections: 最大连接数
    """
    provider: CDNProvider = CDNProvider.CLOUDFLARE
    edge_nodes: List[str] = field(default_factory=list)
    api_token: str = ""
    region: str = "auto"
    max_connections: int = 100


# ============================================================================
# 协议栈模拟器 / Protocol Stack Simulator
# ============================================================================

class ProtocolStackSimulator:
    """真实协议栈模拟器

    完整模拟真实网络协议的交互流程，包括DoH查询响应、TLS 1.3握手、
    HTTP/2多路复用和QUIC连接，使伪装流量与真实流量在统计特征上不可区分。

    Features:
        - DoH完整模拟（查询、响应、缓存、重传）
        - TLS 1.3完整握手模拟
        - HTTP/2多路复用模拟
        - QUIC连接模拟

    Example:
        >>> simulator = ProtocolStackSimulator()
        >>> packet = await simulator.disguise_packet(b"secret data", ProtocolType.DOH)
    """

    # 真实DoH服务端点列表
    DOH_ENDPOINTS: List[str] = [
        "https://dns.google/dns-query",
        "https://cloudflare-dns.com/dns-query",
        "https://dns.quad9.net/dns-query",
        "https://dns.adguard.com/dns-query",
        "https://doh.opendns.com/dns-query",
    ]

    # TLS 1.3支持的密码套件（按优先级排序）
    TLS_13_CIPHER_SUITES: List[str] = [
        "TLS_AES_256_GCM_SHA384",
        "TLS_CHACHA20_POLY1305_SHA256",
        "TLS_AES_128_GCM_SHA256",
    ]

    # TLS 1.3支持的签名算法
    TLS_13_SIGNATURE_ALGORITHMS: List[str] = [
        "ecdsa_secp256r1_sha256",
        "ecdsa_secp384r1_sha384",
        "rsa_pss_rsae_sha256",
        "rsa_pss_rsae_sha384",
    ]

    # HTTP/2 SETTINGS帧的默认参数
    HTTP2_DEFAULT_SETTINGS: Dict[int, int] = {
        0x1: 4096,    # HEADER_TABLE_SIZE
        0x2: 1,       # ENABLE_PUSH (disabled)
        0x3: 100,     # MAX_CONCURRENT_STREAMS
        0x4: 65535,   # INITIAL_WINDOW_SIZE
        0x5: 16384,   # MAX_FRAME_SIZE
    }

    # QUIC支持的版本号
    QUIC_VERSIONS: List[int] = [1, 0]

    def __init__(
        self,
        enable_doh: bool = True,
        enable_tls: bool = True,
        enable_http2: bool = True,
        enable_quic: bool = True,
        cache_ttl: int = 300,
        max_cache_size: int = 1000,
    ) -> None:
        """初始化协议栈模拟器

        Args:
            enable_doh: 是否启用DoH模拟
            enable_tls: 是否启用TLS 1.3模拟
            enable_http2: 是否启用HTTP/2模拟
            enable_quic: 是否启用QUIC模拟
            cache_ttl: DNS缓存默认TTL(秒)
            max_cache_size: DNS缓存最大条目数
        """
        self.enable_doh = enable_doh
        self.enable_tls = enable_tls
        self.enable_http2 = enable_http2
        self.enable_quic = enable_quic
        self.cache_ttl = cache_ttl
        self.max_cache_size = max_cache_size

        # DNS缓存: domain -> list of DNSCacheEntry
        self._dns_cache: Dict[str, List[DNSCacheEntry]] = {}

        # TLS握手状态
        self._tls_states: Dict[str, TLSHandshakeState] = {}

        # HTTP/2流管理
        self._http2_streams: Dict[int, HTTP2Stream] = {}
        self._next_stream_id: int = 1

        # QUIC连接管理
        self._quic_connections: Dict[str, QUICConnectionState] = {}

        # 统计信息
        self._stats: Dict[str, int] = {
            "doh_queries": 0,
            "doh_cached_responses": 0,
            "tls_handshakes": 0,
            "http2_streams_opened": 0,
            "quic_connections": 0,
        }

        logger.info(
            "ProtocolStackSimulator initialized: DoH=%s, TLS=%s, HTTP/2=%s, QUIC=%s",
            enable_doh, enable_tls, enable_http2, enable_quic
        )

    # ------------------------------------------------------------------
    # DoH模拟 / DoH Simulation
    # ------------------------------------------------------------------

    def _generate_doh_query(
        self,
        domain: str,
        record_type: DNSRecordType = DNSRecordType.A,
    ) -> bytes:
        """生成DoH查询报文

        模拟真实的DoH查询格式，包含HTTP/2头部和DNS wire format。

        Args:
            domain: 要查询的域名
            record_type: DNS记录类型

        Returns:
            编码后的DoH查询报文
        """
        # 构造DNS查询报文（wire format）
        transaction_id = random.randint(0, 65535)
        flags = 0x0100  # 标准查询，递归期望
        questions = 1

        # DNS Header: ID(2) + Flags(2) + QDCOUNT(2) + ANCOUNT(2) + NSCOUNT(2) + ARCOUNT(2)
        dns_header = struct.pack(
            "!HHHHHH",
            transaction_id, flags, questions, 0, 0, 0
        )

        # 编码域名（标签格式）
        qname = b""
        for label in domain.split("."):
            encoded_label = label.encode("ascii")
            qname += struct.pack("B", len(encoded_label)) + encoded_label
        qname += b"\x00"  # 根标签

        # 查询类型和类
        qtype = {
            DNSRecordType.A: 1,
            DNSRecordType.AAAA: 28,
            DNSRecordType.CNAME: 5,
            DNSRecordType.MX: 15,
            DNSRecordType.TXT: 16,
            DNSRecordType.NS: 2,
        }[record_type]
        qclass = 1  # IN (Internet)

        dns_question = qname + struct.pack("!HH", qtype, qclass)
        dns_payload = dns_header + dns_question

        # 构造DoH HTTP/2请求（POST方法，application/dns-message）
        doh_request = json.dumps({
            "method": "POST",
            "path": "/dns-query",
            "headers": {
                ":method": "POST",
                ":path": "/dns-query",
                "content-type": "application/dns-message",
                "accept": "application/dns-message",
            },
            "body": base64.b64encode(dns_payload).decode("ascii"),
            "dns": {
                "transaction_id": transaction_id,
                "domain": domain,
                "type": record_type.value,
            },
        }).encode("utf-8")

        return doh_request

    def _generate_doh_response(
        self,
        domain: str,
        record_type: DNSRecordType = DNSRecordType.A,
        transaction_id: Optional[int] = None,
    ) -> bytes:
        """生成DoH响应报文

        模拟真实的DoH响应格式，包含DNS响应和HTTP/2头部。

        Args:
            domain: 查询的域名
            record_type: DNS记录类型
            transaction_id: 事务ID（与查询匹配）

        Returns:
            编码后的DoH响应报文
        """
        if transaction_id is None:
            transaction_id = random.randint(0, 65535)

        flags = 0x8180  # 响应，递归可用，递归期望
        questions = 1
        answers = 1

        # DNS Header
        dns_header = struct.pack(
            "!HHHHHH",
            transaction_id, flags, questions, answers, 0, 0
        )

        # 编码域名
        qname = b""
        for label in domain.split("."):
            encoded_label = label.encode("ascii")
            qname += struct.pack("B", len(encoded_label)) + encoded_label
        qname += b"\x00"

        qtype = {
            DNSRecordType.A: 1,
            DNSRecordType.AAAA: 28,
            DNSRecordType.CNAME: 5,
            DNSRecordType.MX: 15,
            DNSRecordType.TXT: 16,
            DNSRecordType.NS: 2,
        }[record_type]
        qclass = 1

        dns_question = qname + struct.pack("!HH", qtype, qclass)

        # 生成模拟的DNS答案
        if record_type == DNSRecordType.A:
            rdata = bytes([
                random.randint(1, 223) for _ in range(4)
            ])
        elif record_type == DNSRecordType.AAAA:
            rdata = bytes([random.randint(0, 255) for _ in range(16)])
        elif record_type == DNSRecordType.CNAME:
            cname = f"cdn-{random.randint(1,9999)}.example.com"
            rdata = b""
            for label in cname.split("."):
                encoded_label = label.encode("ascii")
                rdata += struct.pack("B", len(encoded_label)) + encoded_label
            rdata += b"\x00"
        else:
            rdata = b"simulated-record"

        # Answer section: NAME(pointer) + TYPE(2) + CLASS(2) + TTL(4) + RDLENGTH(2) + RDATA
        # 使用指针压缩: 0xC00C 指向问题部分的域名
        dns_answer = (
            struct.pack("!H", 0xC00C)  # 名称指针
            + struct.pack("!HH", qtype, qclass)
            + struct.pack("!I", self.cache_ttl)  # TTL
            + struct.pack("!H", len(rdata))  # RDLENGTH
            + rdata  # RDATA
        )

        dns_payload = dns_header + dns_question + dns_answer

        # 构造DoH HTTP/2响应
        doh_response = json.dumps({
            "status": 200,
            "headers": {
                "content-type": "application/dns-message",
                "cache-control": f"max-age={self.cache_ttl}",
            },
            "body": base64.b64encode(dns_payload).decode("ascii"),
        }).encode("utf-8")

        return doh_response

    def _check_dns_cache(
        self, domain: str, record_type: DNSRecordType
    ) -> Optional[DNSCacheEntry]:
        """检查DNS缓存

        Args:
            domain: 要查询的域名
            record_type: DNS记录类型

        Returns:
            缓存命中时返回缓存条目，否则返回None
        """
        entries = self._dns_cache.get(domain, [])
        for entry in entries:
            if entry.record_type == record_type and not entry.is_expired:
                entry.query_count += 1
                self._stats["doh_cached_responses"] += 1
                logger.debug("DNS cache hit: %s (%s)", domain, record_type.value)
                return entry
        return None

    def _add_to_dns_cache(self, entry: DNSCacheEntry) -> None:
        """添加条目到DNS缓存

        Args:
            entry: 要缓存的DNS条目
        """
        if entry.domain not in self._dns_cache:
            self._dns_cache[entry.domain] = []

        # 如果缓存已满，先清理过期条目
        if len(self._dns_cache) >= self.max_cache_size:
            self._cleanup_dns_cache()

        self._dns_cache[entry.domain].append(entry)
        logger.debug("DNS cache added: %s (%s)", entry.domain, entry.record_type.value)

    def _cleanup_dns_cache(self) -> None:
        """清理过期的DNS缓存条目"""
        expired_domains: List[str] = []
        for domain, entries in self._dns_cache.items():
            # 过滤掉过期条目
            valid_entries = [e for e in entries if not e.is_expired]
            if not valid_entries:
                expired_domains.append(domain)
            else:
                self._dns_cache[domain] = valid_entries

        for domain in expired_domains:
            del self._dns_cache[domain]

        logger.debug(
            "DNS cache cleanup: removed %d domains, %d remaining",
            len(expired_domains), len(self._dns_cache)
        )

    async def simulate_doh_query(
        self,
        domain: str,
        record_type: DNSRecordType = DNSRecordType.A,
    ) -> Dict[str, Any]:
        """模拟完整的DoH查询流程

        包含缓存检查、查询生成、响应模拟和缓存更新。

        Args:
            domain: 要查询的域名
            record_type: DNS记录类型

        Returns:
            包含查询和响应信息的字典

        Raises:
            ValueError: 如果域名格式无效
        """
        # 验证域名格式
        if not self._validate_domain(domain):
            raise ValueError(f"Invalid domain format: {domain}")

        self._stats["doh_queries"] += 1

        # 步骤1: 检查缓存
        cached = self._check_dns_cache(domain, record_type)
        if cached is not None:
            # 模拟缓存响应延迟（通常更快）
            await asyncio.sleep(random.uniform(0.001, 0.01))
            return {
                "source": "cache",
                "domain": domain,
                "record_type": record_type.value,
                "answer": cached.answer,
                "ttl": cached.ttl - int(time.time() - cached.created_at),
                "query_count": cached.query_count,
            }

        # 步骤2: 生成查询报文
        query = self._generate_doh_query(domain, record_type)

        # 步骤3: 模拟网络延迟（真实DoH延迟通常在10-200ms）
        await asyncio.sleep(random.uniform(0.01, 0.2))

        # 步骤4: 模拟重传概率（约1%的概率需要重传）
        if random.random() < 0.01:
            logger.debug("DoH query timeout, simulating retransmission for %s", domain)
            await asyncio.sleep(random.uniform(0.5, 2.0))
            self._stats["doh_queries"] += 1

        # 步骤5: 生成响应
        response = self._generate_doh_response(domain, record_type)

        # 步骤6: 更新缓存
        answer = "simulated-answer"
        if record_type == DNSRecordType.A:
            answer = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
        elif record_type == DNSRecordType.AAAA:
            answer = ":".join(f"{random.randint(0, 0xffff):04x}" for _ in range(8))

        cache_entry = DNSCacheEntry(
            domain=domain,
            record_type=record_type,
            answer=answer,
            ttl=self.cache_ttl,
        )
        self._add_to_dns_cache(cache_entry)

        return {
            "source": "network",
            "domain": domain,
            "record_type": record_type.value,
            "answer": answer,
            "ttl": self.cache_ttl,
            "query_size": len(query),
            "response_size": len(response),
            "endpoint": random.choice(self.DOH_ENDPOINTS),
        }

    # ------------------------------------------------------------------
    # TLS 1.3模拟 / TLS 1.3 Simulation
    # ------------------------------------------------------------------

    def _generate_client_hello(self) -> Dict[str, Any]:
        """生成TLS 1.3 ClientHello消息

        Returns:
            包含ClientHello详细信息的字典
        """
        # 客户端随机数（32字节）
        client_random = os.urandom(32)

        # 会话ID（用于兼容性，TLS 1.3实际使用PSK）
        session_id = os.urandom(32)

        # 密码套件列表
        cipher_suites = self.TLS_13_CIPHER_SUITES.copy()
        random.shuffle(cipher_suites)

        # 签名算法列表
        sig_algs = self.TLS_13_SIGNATURE_ALGORITHMS.copy()
        random.shuffle(sig_algs)

        # 支持的组（用于密钥交换）
        supported_groups = [
            "x25519", "secp256r1", "secp384r1"
        ]
        random.shuffle(supported_groups)

        # 模拟SNI扩展
        sni = random.choice([
            "www.google.com",
            "cloudflare.com",
            "www.amazon.com",
            "github.com",
            "stackoverflow.com",
        ])

        # 模拟ALPN扩展
        alpn = ["h2", "http/1.1"]

        client_hello = {
            "version": "TLS 1.3",
            "random": base64.b64encode(client_random).decode("ascii"),
            "session_id": base64.b64encode(session_id).decode("ascii"),
            "cipher_suites": cipher_suites,
            "signature_algorithms": sig_algs,
            "supported_groups": supported_groups,
            "extensions": {
                "sni": sni,
                "alpn": alpn,
                "supported_versions": ["TLS 1.3", "TLS 1.2"],
                "key_share": supported_groups[0],
                "psk_key_exchange_modes": ["psk_dhe_ke"],
            },
        }

        return client_hello

    def _generate_server_hello(
        self, client_hello: Dict[str, Any]
    ) -> Dict[str, Any]:
        """生成TLS 1.3 ServerHello消息

        Args:
            client_hello: 对应的ClientHello消息

        Returns:
            包含ServerHello详细信息的字典
        """
        # 服务端随机数
        server_random = os.urandom(32)

        # 选择密码套件（从客户端提供的列表中选择第一个）
        selected_cipher = client_hello["cipher_suites"][0]

        # 选择密钥交换组
        selected_group = client_hello["supported_groups"][0]

        server_hello = {
            "version": "TLS 1.3",
            "random": base64.b64encode(server_random).decode("ascii"),
            "session_id": client_hello["session_id"],
            "cipher_suite": selected_cipher,
            "key_exchange_group": selected_group,
            "extensions": {
                "supported_versions": "TLS 1.3",
                "key_share": selected_group,
            },
        }

        return server_hello

    async def simulate_tls_handshake(
        self, session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """模拟完整的TLS 1.3握手流程

        包含ClientHello、ServerHello、EncryptedExtensions、
        Certificate、CertificateVerify和Finished消息。

        Args:
            session_id: 可选的会话标识符

        Returns:
            包含握手详细信息的字典
        """
        if session_id is None:
            session_id = base64.b64encode(os.urandom(16)).decode("ascii")[:24]

        self._stats["tls_handshakes"] += 1
        start_time = time.time()

        # 步骤1: 生成ClientHello
        client_hello = self._generate_client_hello()
        await asyncio.sleep(random.uniform(0.005, 0.02))  # 模拟本地处理延迟

        # 步骤2: 模拟网络传输延迟
        await asyncio.sleep(random.uniform(0.02, 0.15))

        # 步骤3: 生成ServerHello
        server_hello = self._generate_server_hello(client_hello)
        await asyncio.sleep(random.uniform(0.005, 0.02))

        # 步骤4: 模拟EncryptedExtensions
        encrypted_extensions = {
            "server_name": client_hello["extensions"]["sni"],
            "alpn": client_hello["extensions"]["alpn"][0],
        }
        await asyncio.sleep(random.uniform(0.01, 0.05))

        # 步骤5: 模拟Certificate消息
        certificate = {
            "certificate_chain": [
                {
                    "subject": f"CN={client_hello['extensions']['sni']}",
                    "issuer": "CN=Let's Encrypt Authority X3",
                    "valid_from": "2025-01-01",
                    "valid_to": "2026-01-01",
                    "public_key_algorithm": "ECDSA",
                    "public_key_size": 256,
                }
            ]
        }
        await asyncio.sleep(random.uniform(0.01, 0.05))

        # 步骤6: 模拟CertificateVerify
        signature_algorithm = client_hello["signature_algorithms"][0]
        certificate_verify = {
            "algorithm": signature_algorithm,
            "signature": base64.b64encode(os.urandom(64)).decode("ascii"),
        }
        await asyncio.sleep(random.uniform(0.005, 0.02))

        # 步骤7: 模拟Finished消息
        finished = {
            "verify_data": base64.b64encode(os.urandom(32)).decode("ascii"),
        }

        # 保存握手状态
        state = TLSHandshakeState(
            client_random=base64.b64decode(client_hello["random"]),
            server_random=base64.b64decode(server_hello["random"]),
            session_id=base64.b64decode(client_hello["session_id"]),
            cipher_suite=server_hello["cipher_suite"],
            handshake_complete=True,
            key_material=os.urandom(48),  # 模拟密钥材料
        )
        self._tls_states[session_id] = state

        elapsed = time.time() - start_time

        logger.info(
            "TLS 1.3 handshake completed for session %s in %.3fms, cipher: %s",
            session_id, elapsed * 1000, state.cipher_suite
        )

        return {
            "session_id": session_id,
            "cipher_suite": state.cipher_suite,
            "server_name": client_hello["extensions"]["sni"],
            "alpn": encrypted_extensions["alpn"],
            "handshake_time_ms": round(elapsed * 1000, 2),
            "client_hello": client_hello,
            "server_hello": server_hello,
            "certificate": certificate,
        }

    # ------------------------------------------------------------------
    # HTTP/2模拟 / HTTP/2 Simulation
    # ------------------------------------------------------------------

    def _create_http2_stream(
        self,
        weight: int = 16,
        dependency: int = 0,
    ) -> HTTP2Stream:
        """创建HTTP/2流

        Args:
            weight: 流优先级权重(1-256)
            dependency: 依赖的流ID

        Returns:
            创建的HTTP/2流对象
        """
        stream = HTTP2Stream(
            stream_id=self._next_stream_id,
            state="open",
            weight=max(1, min(256, weight)),
            dependency=dependency,
        )
        self._http2_streams[stream.stream_id] = stream
        self._next_stream_id += 2  # 客户端发起的流ID为奇数

        self._stats["http2_streams_opened"] += 1
        logger.debug("HTTP/2 stream %d created (weight=%d, dep=%d)",
                      stream.stream_id, stream.weight, stream.dependency)
        return stream

    def _generate_http2_headers_frame(
        self,
        stream_id: int,
        headers: Dict[str, str],
        end_stream: bool = False,
    ) -> Dict[str, Any]:
        """生成HTTP/2 HEADERS帧

        Args:
            stream_id: 流ID
            headers: 头部字典
            end_stream: 是否结束流

        Returns:
            HEADERS帧的字典表示
        """
        # 模拟HPACK编码后的头部大小
        encoded_size = sum(len(k) + len(v) for k, v in headers.items()) + len(headers) * 2

        frame = {
            "frame_type": "HEADERS",
            "stream_id": stream_id,
            "flags": ["END_HEADERS"],
            "payload": {
                "headers": headers,
                "encoded_size": encoded_size,
            },
        }
        if end_stream:
            frame["flags"].append("END_STREAM")

        return frame

    def _generate_http2_data_frame(
        self,
        stream_id: int,
        data: bytes,
        end_stream: bool = False,
    ) -> Dict[str, Any]:
        """生成HTTP/2 DATA帧

        Args:
            stream_id: 流ID
            data: 负载数据
            end_stream: 是否结束流

        Returns:
            DATA帧的字典表示
        """
        frame = {
            "frame_type": "DATA",
            "stream_id": stream_id,
            "flags": [],
            "payload": {
                "data_length": len(data),
                "data_base64": base64.b64encode(data).decode("ascii"),
            },
        }
        if end_stream:
            frame["flags"].append("END_STREAM")

        return frame

    async def simulate_http2_request(
        self,
        method: str = "GET",
        path: str = "/",
        headers: Optional[Dict[str, str]] = None,
        body: Optional[bytes] = None,
    ) -> Dict[str, Any]:
        """模拟HTTP/2请求的多路复用传输

        包含SETTINGS交换、流创建、HEADERS帧和DATA帧的发送。

        Args:
            method: HTTP方法
            path: 请求路径
            headers: 自定义头部
            body: 请求体

        Returns:
            包含HTTP/2传输详细信息的字典
        """
        if headers is None:
            headers = {}

        # 步骤1: 模拟SETTINGS帧交换
        client_settings = self.HTTP2_DEFAULT_SETTINGS.copy()
        server_settings = self.HTTP2_DEFAULT_SETTINGS.copy()
        server_settings[0x3] = 200  # 服务器允许更多并发流

        await asyncio.sleep(random.uniform(0.005, 0.015))

        # 步骤2: 创建流
        stream = self._create_http2_stream(
            weight=random.randint(1, 256),
            dependency=0,
        )

        # 步骤3: 构造请求头
        default_headers = {
            ":method": method,
            ":path": path,
            ":scheme": "https",
            ":authority": random.choice([
                "www.google.com",
                "api.github.com",
                "cdn.cloudflare.com",
            ]),
            "user-agent": random.choice([
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            ]),
            "accept": "*/*",
            "accept-encoding": "gzip, deflate, br",
            "accept-language": "en-US,en;q=0.9",
        }
        default_headers.update(headers)

        # 步骤4: 发送HEADERS帧
        headers_frame = self._generate_http2_headers_frame(
            stream.stream_id, default_headers, end_stream=(body is None)
        )
        await asyncio.sleep(random.uniform(0.002, 0.01))

        # 步骤5: 发送DATA帧（如果有请求体）
        data_frames: List[Dict[str, Any]] = []
        if body is not None:
            # 将数据分片为多个DATA帧（模拟真实行为）
            max_frame_size = server_settings.get(0x5, 16384)
            offset = 0
            while offset < len(body):
                chunk = body[offset:offset + max_frame_size]
                is_last = (offset + len(chunk)) >= len(body)
                data_frame = self._generate_http2_data_frame(
                    stream.stream_id, chunk, end_stream=is_last
                )
                data_frames.append(data_frame)
                offset += len(chunk)
                await asyncio.sleep(random.uniform(0.001, 0.005))

        # 步骤6: 模拟WINDOW_UPDATE帧
        window_update = {
            "frame_type": "WINDOW_UPDATE",
            "stream_id": 0,  # 连接级别
            "increment": random.randint(65535, 1048576),
        }

        # 关闭流
        stream.state = "half_closed(local)"

        return {
            "stream_id": stream.stream_id,
            "method": method,
            "path": path,
            "client_settings": client_settings,
            "server_settings": server_settings,
            "headers_frame": headers_frame,
            "data_frames": data_frames,
            "window_update": window_update,
            "total_frames": 1 + len(data_frames) + 1,
        }

    # ------------------------------------------------------------------
    # QUIC模拟 / QUIC Simulation
    # ------------------------------------------------------------------

    def _generate_quic_initial_packet(
        self,
        connection_id: bytes,
    ) -> Dict[str, Any]:
        """生成QUIC Initial包

        Args:
            connection_id: 连接ID

        Returns:
            QUIC Initial包的字典表示
        """
        # QUIC Long Header格式
        packet = {
            "header_form": 1,  # Long Header
            "fixed_bit": 1,
            "long_packet_type": 0,  # Initial
            "reserved_bits": 0,
            "packet_number_length": 2,
            "version": 1,  # QUIC v1
            "destination_connection_id": base64.b64encode(connection_id).decode("ascii"),
            "source_connection_id": base64.b64encode(os.urandom(8)).decode("ascii"),
            "token_length": 0,
            "length": random.randint(1000, 1200),
            "packet_number": 0,
            "payload": {
                "crypto_frame": {
                    "offset": 0,
                    "length": random.randint(200, 600),
                    "data": base64.b64encode(os.urandom(256)).decode("ascii"),
                },
            },
        }
        return packet

    async def simulate_quic_connection(
        self,
        server_name: str = "www.google.com",
    ) -> Dict[str, Any]:
        """模拟完整的QUIC连接建立过程

        包含Initial、Handshake和1-RTT阶段的模拟。

        Args:
            server_name: 服务器名称（用于SNI）

        Returns:
            包含QUIC连接详细信息的字典
        """
        self._stats["quic_connections"] += 1
        start_time = time.time()

        # 生成连接ID
        connection_id = os.urandom(8)
        conn_id_str = base64.b64encode(connection_id).decode("ascii")[:12]

        # 步骤1: 客户端发送Initial包
        initial_packet = self._generate_quic_initial_packet(connection_id)
        await asyncio.sleep(random.uniform(0.01, 0.05))

        # 步骤2: 服务端响应Initial + Handshake
        server_initial = {
            "header_form": 1,
            "long_packet_type": 0,
            "version": 1,
            "destination_connection_id": initial_packet["source_connection_id"],
            "source_connection_id": initial_packet["destination_connection_id"],
            "packet_number": 0,
        }
        await asyncio.sleep(random.uniform(0.01, 0.05))

        server_handshake = {
            "header_form": 1,
            "long_packet_type": 2,  # Handshake
            "version": 1,
            "packet_number": 0,
        }
        await asyncio.sleep(random.uniform(0.01, 0.03))

        # 步骤3: 客户端发送Handshake完成
        client_handshake = {
            "header_form": 1,
            "long_packet_type": 2,
            "version": 1,
            "packet_number": 1,
        }
        await asyncio.sleep(random.uniform(0.005, 0.02))

        # 步骤4: 1-RTT数据传输
        one_rtt_packet = {
            "header_form": 0,  # Short Header
            "fixed_bit": 1,
            "spin_bit": random.randint(0, 1),
            "reserved_bits": 0,
            "key_phase": 0,
            "packet_number": 0,
            "payload_length": random.randint(500, 1400),
        }

        # 保存连接状态
        state = QUICConnectionState(
            connection_id=connection_id,
            version=1,
            packet_number=2,
            peer_address=server_name,
            handshake_complete=True,
        )
        self._quic_connections[conn_id_str] = state

        elapsed = time.time() - start_time

        logger.info(
            "QUIC connection established to %s in %.3fms (conn_id=%s)",
            server_name, elapsed * 1000, conn_id_str
        )

        return {
            "connection_id": conn_id_str,
            "server_name": server_name,
            "version": "QUIC v1",
            "handshake_time_ms": round(elapsed * 1000, 2),
            "initial_packet": initial_packet,
            "server_initial": server_initial,
            "server_handshake": server_handshake,
            "client_handshake": client_handshake,
            "one_rtt_packet": one_rtt_packet,
        }

    # ------------------------------------------------------------------
    # 统一伪装接口 / Unified Disguise Interface
    # ------------------------------------------------------------------

    async def disguise_packet(
        self,
        data: bytes,
        protocol: ProtocolType = ProtocolType.DOH,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """将原始数据伪装为指定协议的流量

        这是模块的主入口方法，根据指定的协议类型对数据进行伪装。

        Args:
            data: 要伪装的原始数据
            protocol: 目标协议类型
            **kwargs: 协议特定的参数

        Returns:
            包含伪装后数据和元信息的字典

        Raises:
            ValueError: 如果协议类型不支持
            RuntimeError: 如果协议模拟未启用
        """
        logger.debug(
            "Disguising %d bytes using protocol %s", len(data), protocol.name
        )

        if protocol == ProtocolType.DOH:
            if not self.enable_doh:
                raise RuntimeError("DoH simulation is not enabled")
            # 将数据编码为DNS响应中的TXT记录
            domain = kwargs.get("domain", f"query-{random.randint(1000,9999)}.example.com")
            result = await self.simulate_doh_query(domain, DNSRecordType.TXT)
            result["disguised_data"] = base64.b64encode(data).decode("ascii")
            return result

        elif protocol == ProtocolType.TLS_13:
            if not self.enable_tls:
                raise RuntimeError("TLS simulation is not enabled")
            session_id = kwargs.get("session_id")
            result = await self.simulate_tls_handshake(session_id)
            # 将数据嵌入TLS应用数据记录
            result["disguised_data"] = base64.b64encode(data).decode("ascii")
            return result

        elif protocol == ProtocolType.HTTP2:
            if not self.enable_http2:
                raise RuntimeError("HTTP/2 simulation is not enabled")
            result = await self.simulate_http2_request(
                method=kwargs.get("method", "POST"),
                path=kwargs.get("path", "/api/data"),
                body=data,
            )
            return result

        elif protocol == ProtocolType.QUIC:
            if not self.enable_quic:
                raise RuntimeError("QUIC simulation is not enabled")
            result = await self.simulate_quic_connection(
                server_name=kwargs.get("server_name", "www.google.com")
            )
            result["disguised_data"] = base64.b64encode(data).decode("ascii")
            return result

        else:
            raise ValueError(f"Unsupported protocol type: {protocol}")

    def get_stats(self) -> Dict[str, int]:
        """获取协议栈模拟器的统计信息

        Returns:
            包含各项统计计数的字典
        """
        return self._stats.copy()

    @staticmethod
    def _validate_domain(domain: str) -> bool:
        """验证域名格式是否合法

        Args:
            domain: 要验证的域名

        Returns:
            域名格式是否合法
        """
        if not domain or len(domain) > 253:
            return False
        pattern = r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
        return bool(re.match(pattern, domain))


# ============================================================================
# WebRTC流量伪装器 / WebRTC Traffic Disguiser
# ============================================================================

class WebRTCDisguiser:
    """WebRTC流量伪装器

    模拟WebRTC协议栈的完整交互流程，包括DTLS握手、SCTP数据通道、
    ICE候选交换和SRTP媒体流，使通信流量伪装为正常的WebRTC视频/音频通话。

    Features:
        - DTLS握手模拟
        - SCTP数据通道模拟
        - ICE候选交换模拟
        - SRTP媒体流模拟

    Example:
        >>> disguiser = WebRTCDisguiser()
        >>> session = await disguiser.create_session()
        >>> disguised = await disguiser.disguise_data(session.session_id, b"secret")
    """

    # 真实WebRTC使用的DTLS密码套件
    DTLS_CIPHER_SUITES: List[str] = [
        "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256",
        "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384",
    ]

    # ICE候选类型
    ICE_CANDIDATE_TYPES: List[str] = ["host", "srflx", "relay"]

    # SRTP加密套件
    SRTP_PROFILES: List[str] = [
        "SRTP_AES128_CM_HMAC_SHA1_80",
        "SRTP_AES128_CM_HMAC_SHA1_32",
        "SRTP_AEAD_AES_128_GCM",
    ]

    def __init__(
        self,
        enable_dtls: bool = True,
        enable_sctp: bool = True,
        enable_ice: bool = True,
        enable_srtp: bool = True,
        max_sessions: int = 100,
    ) -> None:
        """初始化WebRTC流量伪装器

        Args:
            enable_dtls: 是否启用DTLS握手模拟
            enable_sctp: 是否启用SCTP数据通道模拟
            enable_ice: 是否启用ICE候选交换模拟
            enable_srtp: 是否启用SRTP媒体流模拟
            max_sessions: 最大同时会话数
        """
        self.enable_dtls = enable_dtls
        self.enable_sctp = enable_sctp
        self.enable_ice = enable_ice
        self.enable_srtp = enable_srtp
        self.max_sessions = max_sessions

        # 活跃会话管理
        self._sessions: Dict[str, WebRTCSession] = {}

        # 统计信息
        self._stats: Dict[str, int] = {
            "sessions_created": 0,
            "dtls_handshakes": 0,
            "sctp_channels_opened": 0,
            "ice_candidates_exchanged": 0,
            "srtp_packets_sent": 0,
        }

        logger.info("WebRTCDisguiser initialized (max_sessions=%d)", max_sessions)

    async def create_session(
        self,
        session_id: Optional[str] = None,
    ) -> WebRTCSession:
        """创建新的WebRTC会话

        生成会话ID、ICE凭证和DTLS指纹。

        Args:
            session_id: 可选的自定义会话ID

        Returns:
            创建的WebRTC会话对象

        Raises:
            RuntimeError: 如果已达到最大会话数
        """
        if len(self._sessions) >= self.max_sessions:
            raise RuntimeError(
                f"Maximum number of sessions ({self.max_sessions}) reached"
            )

        if session_id is None:
            session_id = base64.b64encode(os.urandom(12)).decode("ascii")[:16]

        session = WebRTCSession(
            session_id=session_id,
            ice_ufrag=self._generate_ice_credential(8),
            ice_password=self._generate_ice_credential(24),
            dtls_fingerprint=self._generate_dtls_fingerprint(),
            sctp_port=random.randint(49152, 65535),
        )

        self._sessions[session_id] = session
        self._stats["sessions_created"] += 1

        logger.info("WebRTC session created: %s", session_id)
        return session

    async def simulate_dtls_handshake(
        self, session_id: str
    ) -> Dict[str, Any]:
        """模拟DTLS握手过程

        包含ClientHello、HelloVerifyRequest、ServerHello、
        Certificate和Finished消息的完整交换。

        Args:
            session_id: 会话ID

        Returns:
            包含DTLS握手详细信息的字典

        Raises:
            KeyError: 如果会话ID不存在
        """
        session = self._sessions.get(session_id)
        if session is None:
            raise KeyError(f"Session not found: {session_id}")

        if not self.enable_dtls:
            raise RuntimeError("DTLS simulation is not enabled")

        self._stats["dtls_handshakes"] += 1
        start_time = time.time()

        # 步骤1: ClientHello
        client_hello = {
            "version": "DTLS 1.2",
            "random": base64.b64encode(os.urandom(32)).decode("ascii"),
            "cookie_length": 0,
            "cipher_suites": self.DTLS_CIPHER_SUITES.copy(),
            "extensions": {
                "use_srtp": self.SRTP_PROFILES,
                "supported_groups": ["x25519", "secp256r1"],
                "signature_algorithms": [
                    "ecdsa_secp256r1_sha256",
                    "ecdsa_secp384r1_sha384",
                ],
            },
        }
        await asyncio.sleep(random.uniform(0.01, 0.05))

        # 步骤2: HelloVerifyRequest（DTLS特有的cookie交换）
        hello_verify = {
            "version": "DTLS 1.2",
            "cookie": base64.b64encode(os.urandom(32)).decode("ascii"),
            "message_seq": 1,
        }
        await asyncio.sleep(random.uniform(0.005, 0.02))

        # 步骤3: ClientHello with cookie
        client_hello["cookie"] = hello_verify["cookie"]
        client_hello["cookie_length"] = 32
        await asyncio.sleep(random.uniform(0.005, 0.02))

        # 步骤4: ServerHello
        server_hello = {
            "version": "DTLS 1.2",
            "random": base64.b64encode(os.urandom(32)).decode("ascii"),
            "cipher_suite": self.DTLS_CIPHER_SUITES[0],
            "srtp_profile": self.SRTP_PROFILES[0],
        }
        await asyncio.sleep(random.uniform(0.01, 0.05))

        # 步骤5: Certificate
        certificate = {
            "fingerprint_algorithm": "sha-256",
            "fingerprint": session.dtls_fingerprint,
        }
        await asyncio.sleep(random.uniform(0.005, 0.02))

        # 步骤6: ServerKeyExchange + ServerHelloDone
        server_key_exchange = {
            "curve": "x25519",
            "public_key": base64.b64encode(os.urandom(32)).decode("ascii"),
        }
        await asyncio.sleep(random.uniform(0.005, 0.02))

        elapsed = time.time() - start_time

        logger.info(
            "DTLS handshake completed for session %s in %.3fms",
            session_id, elapsed * 1000
        )

        return {
            "session_id": session_id,
            "cipher_suite": server_hello["cipher_suite"],
            "srtp_profile": server_hello["srtp_profile"],
            "handshake_time_ms": round(elapsed * 1000, 2),
            "client_hello": client_hello,
            "server_hello": server_hello,
            "certificate": certificate,
        }

    async def simulate_ice_exchange(
        self,
        session_id: str,
        num_candidates: int = 4,
    ) -> Dict[str, Any]:
        """模拟ICE候选交换过程

        生成并交换ICE候选，模拟STUN绑定请求和连通性检查。

        Args:
            session_id: 会话ID
            num_candidates: 要生成的候选数量

        Returns:
            包含ICE交换详细信息的字典

        Raises:
            KeyError: 如果会话ID不存在
        """
        session = self._sessions.get(session_id)
        if session is None:
            raise KeyError(f"Session not found: {session_id}")

        if not self.enable_ice:
            raise RuntimeError("ICE simulation is not enabled")

        self._stats["ice_candidates_exchanged"] += num_candidates * 2
        start_time = time.time()

        # 生成ICE候选
        candidates: List[Dict[str, Any]] = []
        for i in range(num_candidates):
            cand_type = self.ICE_CANDIDATE_TYPES[i % len(self.ICE_CANDIDATE_TYPES)]
            candidate = {
                "foundation": f"{cand_type[0]}{i}",
                "component_id": 1,
                "transport": "UDP",
                "priority": random.randint(1000000000, 2147483647),
                "type": cand_type,
            }

            if cand_type == "host":
                candidate["address"] = f"192.168.{random.randint(0,255)}.{random.randint(1,254)}"
                candidate["port"] = random.randint(49152, 65535)
            elif cand_type == "srflx":
                candidate["address"] = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
                candidate["port"] = random.randint(49152, 65535)
                candidate["related_address"] = f"192.168.1.{random.randint(1,254)}"
                candidate["related_port"] = random.randint(49152, 65535)
            else:  # relay
                candidate["address"] = f"turn-{random.randint(1,99)}.example.com"
                candidate["port"] = 443
                candidate["related_address"] = f"192.168.1.{random.randint(1,254)}"
                candidate["related_port"] = random.randint(49152, 65535)

            candidates.append(candidate)
            await asyncio.sleep(random.uniform(0.01, 0.05))

        # 模拟STUN绑定请求
        stun_binding = {
            "method": "Binding Request",
            "class": "Request",
            "transaction_id": base64.b64encode(os.urandom(12)).decode("ascii"),
            "attributes": {
                "ICE-CONTROLLING": base64.b64encode(os.urandom(8)).decode("ascii"),
                "PRIORITY": random.randint(1000000000, 2147483647),
            },
        }
        await asyncio.sleep(random.uniform(0.02, 0.1))

        # 模拟连通性检查
        connectivity_checks = []
        for cand in candidates[:2]:  # 对前两个候选进行连通性检查
            check = {
                "candidate": cand["foundation"],
                "state": "succeeded" if random.random() > 0.1 else "failed",
                "rtt_ms": round(random.uniform(5, 100), 2),
            }
            connectivity_checks.append(check)
            await asyncio.sleep(random.uniform(0.01, 0.05))

        # 选择最佳候选对
        best_pair = candidates[0]

        elapsed = time.time() - start_time

        logger.info(
            "ICE exchange completed for session %s: %d candidates in %.3fms",
            session_id, len(candidates), elapsed * 1000
        )

        return {
            "session_id": session_id,
            "ice_ufrag": session.ice_ufrag,
            "candidates": candidates,
            "stun_binding": stun_binding,
            "connectivity_checks": connectivity_checks,
            "selected_pair": best_pair,
            "gathering_time_ms": round(elapsed * 1000, 2),
        }

    async def simulate_sctp_channel(
        self,
        session_id: str,
        channel_label: str = "data",
        channel_id: int = 0,
    ) -> Dict[str, Any]:
        """模拟SCTP数据通道的建立

        包含DATA_CHANNEL_OPEN消息和ACK响应。

        Args:
            session_id: 会话ID
            channel_label: 通道标签
            channel_id: 通道ID

        Returns:
            包含SCTP通道详细信息的字典

        Raises:
            KeyError: 如果会话ID不存在
        """
        session = self._sessions.get(session_id)
        if session is None:
            raise KeyError(f"Session not found: {session_id}")

        if not self.enable_sctp:
            raise RuntimeError("SCTP simulation is not enabled")

        self._stats["sctp_channels_opened"] += 1

        # DATA_CHANNEL_OPEN消息
        channel_open = {
            "message_type": "DATA_CHANNEL_OPEN",
            "channel_type": "reliable",  # 或 "unreliable", "unreliable_unordered"
            "priority": random.randint(0, 255),
            "reliability_parameter": 0,
            "label": channel_label,
            "protocol": "",
        }
        await asyncio.sleep(random.uniform(0.005, 0.02))

        # DATA_CHANNEL_ACK消息
        channel_ack = {
            "message_type": "DATA_CHANNEL_ACK",
            "channel_id": channel_id,
        }
        await asyncio.sleep(random.uniform(0.002, 0.01))

        # 保存通道信息
        channel_info = {
            "channel_id": channel_id,
            "label": channel_label,
            "state": "open",
            "stream_id": random.randint(0, 65535),
            "ordered": True,
        }
        session.channels.append(channel_info)

        logger.info(
            "SCTP channel '%s' (id=%d) opened for session %s",
            channel_label, channel_id, session_id
        )

        return {
            "session_id": session_id,
            "channel_open": channel_open,
            "channel_ack": channel_ack,
            "channel_info": channel_info,
        }

    async def simulate_srtp_stream(
        self,
        session_id: str,
        duration_seconds: float = 1.0,
        packets_per_second: int = 50,
    ) -> Dict[str, Any]:
        """模拟SRTP媒体流传输

        生成模拟的音频/视频RTP包，包含序列号、时间戳和负载。

        Args:
            session_id: 会话ID
            duration_seconds: 模拟持续时间(秒)
            packets_per_second: 每秒包数

        Returns:
            包含SRTP流详细信息的字典

        Raises:
            KeyError: 如果会话ID不存在
        """
        session = self._sessions.get(session_id)
        if session is None:
            raise KeyError(f"Session not found: {session_id}")

        if not self.enable_srtp:
            raise RuntimeError("SRTP simulation is not enabled")

        total_packets = int(duration_seconds * packets_per_second)
        self._stats["srtp_packets_sent"] += total_packets

        # 模拟RTP包序列
        packets: List[Dict[str, Any]] = []
        sequence_number = random.randint(0, 65535)
        timestamp = random.randint(0, 2**32 - 1)
        ssrc = random.randint(0, 2**32 - 1)

        # 模拟音频流（Opus编码）
        payload_type = 111  # Opus
        clock_rate = 48000

        for i in range(min(total_packets, 10)):  # 只记录前10个包的详情
            packet = {
                "sequence_number": sequence_number & 0xFFFF,
                "timestamp": timestamp & 0xFFFFFFFF,
                "ssrc": ssrc,
                "payload_type": payload_type,
                "marker": 0,
                "payload_size": random.randint(20, 120),  # Opus帧大小
                "csrc_count": 0,
            }
            packets.append(packet)

            sequence_number += 1
            timestamp += clock_rate // packets_per_second  # 每包时间增量

        # 模拟传输延迟
        await asyncio.sleep(min(duration_seconds, 0.5))

        # 模拟RTCP发送者报告
        rtcp_sender_report = {
            "packet_type": 203,  # Sender Report
            "ssrc": ssrc,
            "ntp_timestamp": int(time.time() * 1000),
            "rtp_timestamp": timestamp,
            "sender_packet_count": total_packets,
            "sender_octet_count": total_packets * 60,  # 平均每包60字节
        }

        logger.info(
            "SRTP stream simulated: %d packets for session %s",
            total_packets, session_id
        )

        return {
            "session_id": session_id,
            "ssrc": ssrc,
            "payload_type": payload_type,
            "total_packets": total_packets,
            "packets_per_second": packets_per_second,
            "sample_packets": packets,
            "rtcp_sender_report": rtcp_sender_report,
        }

    async def disguise_data(
        self,
        session_id: str,
        data: bytes,
    ) -> Dict[str, Any]:
        """将数据伪装为WebRTC流量

        将原始数据编码为SCTP数据通道消息格式。

        Args:
            session_id: 会话ID
            data: 要伪装的原始数据

        Returns:
            包含伪装后数据的字典

        Raises:
            KeyError: 如果会话ID不存在
        """
        session = self._sessions.get(session_id)
        if session is None:
            raise KeyError(f"Session not found: {session_id}")

        # 将数据分片为SCTP消息
        max_message_size = 16384  # SCTP最大消息大小
        fragments: List[Dict[str, Any]] = []
        offset = 0
        fragment_index = 0

        while offset < len(data):
            chunk = data[offset:offset + max_message_size]
            is_last = (offset + len(chunk)) >= len(data)

            fragment = {
                "channel_id": session.channels[0]["channel_id"] if session.channels else 0,
                "message_type": "DATA",
                "fragment_index": fragment_index,
                "is_last": is_last,
                "data_length": len(chunk),
                "data_base64": base64.b64encode(chunk).decode("ascii"),
            }
            fragments.append(fragment)

            offset += len(chunk)
            fragment_index += 1

        return {
            "session_id": session_id,
            "total_fragments": len(fragments),
            "total_data_size": len(data),
            "fragments": fragments,
        }

    def get_stats(self) -> Dict[str, int]:
        """获取WebRTC伪装器的统计信息

        Returns:
            包含各项统计计数的字典
        """
        return self._stats.copy()

    @staticmethod
    def _generate_ice_credential(length: int) -> str:
        """生成ICE凭证（用户名片段或密码）

        Args:
            length: 凭证长度

        Returns:
            随机生成的ICE凭证字符串
        """
        chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        return "".join(random.choice(chars) for _ in range(length))

    @staticmethod
    def _generate_dtls_fingerprint() -> str:
        """生成DTLS证书指纹

        Returns:
            格式化的SHA-256指纹字符串
        """
        fingerprint_bytes = os.urandom(32)
        hex_parts = [
            f"{b:02X}" for b in fingerprint_bytes
        ]
        return ":".join(hex_parts)


# ============================================================================
# 动态域名生成器 / Domain Generator DGA
# ============================================================================

class DomainGeneratorDGA:
    """动态域名生成器

    基于日期的确定性域名生成算法(DGA)，生成与真实域名统计特征
    一致的伪装域名，并支持自动轮换和DNS记录管理。

    Features:
        - 基于日期的确定性域名生成
        - 域名特征与真实域名一致（长度分布、字符分布）
        - 自动DNS记录注册
        - 域名轮换管理

    Example:
        >>> dga = DomainGeneratorDGA(seed="my-secret-seed")
        >>> domains = dga.generate_daily_domains(count=10)
    """

    # 常见顶级域名（按真实使用频率排序）
    COMMON_TLDS: List[str] = [
        ".com", ".net", ".org", ".io", ".co", ".app",
        ".dev", ".cloud", ".online", ".site", ".xyz",
        ".info", ".biz", ".me", ".cc", ".tech",
    ]

    # 真实域名字符频率分布（基于Alexa Top 1M统计）
    CHAR_FREQUENCY: Dict[str, float] = {
        "a": 0.082, "b": 0.015, "c": 0.028, "d": 0.043,
        "e": 0.127, "f": 0.022, "g": 0.020, "h": 0.061,
        "i": 0.070, "j": 0.002, "k": 0.008, "l": 0.040,
        "m": 0.024, "n": 0.067, "o": 0.075, "p": 0.019,
        "q": 0.001, "r": 0.060, "s": 0.063, "t": 0.091,
        "u": 0.028, "v": 0.010, "w": 0.024, "x": 0.002,
        "y": 0.020, "z": 0.001,
        "0": 0.020, "1": 0.020, "2": 0.020, "3": 0.020,
        "4": 0.020, "5": 0.020, "6": 0.020, "7": 0.020,
        "8": 0.020, "9": 0.020,
        "-": 0.030,
    }

    # 真实域名长度分布（近似高斯分布: mu=10, sigma=4）
    DOMAIN_LENGTH_MU: float = 10.0
    DOMAIN_LENGTH_SIGMA: float = 4.0

    # 常见域名前缀和后缀模式
    COMMON_PREFIXES: List[str] = [
        "my", "the", "get", "go", "app", "web", "net", "cloud",
        "data", "api", "dev", "pro", "new", "fast", "smart",
    ]
    COMMON_SUFFIXES: List[str] = [
        "hub", "ly", "ify", "io", "er", "lab", "box", "zone",
        "ware", "link", "gate", "base", "core", "stack", "flow",
    ]

    def __init__(
        self,
        seed: str = "ip4move-aegis-dga",
        domains_per_minute: int = 5,
        rotation_interval: int = 60,
        max_active_domains: int = 500,
        tlds: Optional[List[str]] = None,
    ) -> None:
        """初始化域名生成器

        Args:
            seed: DGA种子密钥（用于确定性生成）
            domains_per_minute: 每分钟生成的域名数量
            rotation_interval: 域名轮换间隔（秒）
            max_active_domains: 最大活跃域名数
            tlds: 自定义TLD列表
        """
        self.seed = seed
        self.domains_per_minute = domains_per_minute
        self.rotation_interval = rotation_interval
        self.max_active_domains = max_active_domains
        self.tlds = tlds or self.COMMON_TLDS.copy()

        # 活跃域名管理
        self._active_domains: Dict[str, GeneratedDomain] = {}
        self._domain_history: List[GeneratedDomain] = []

        # DNS记录管理
        self._dns_records: Dict[str, Dict[str, str]] = {}

        # 轮换任务
        self._rotation_task: Optional[asyncio.Task[None]] = None
        self._is_running: bool = False

        # 构建字符累积分布（用于加权随机选择）
        self._char_cumulative: List[Tuple[str, float]] = []
        cumulative = 0.0
        for char, freq in sorted(self.CHAR_FREQUENCY.items()):
            cumulative += freq
            self._char_cumulative.append((char, cumulative))
        # 归一化
        total = self._char_cumulative[-1][1]
        self._char_cumulative = [
            (c, v / total) for c, v in self._char_cumulative
        ]

        logger.info(
            "DomainGeneratorDGA initialized (seed=%s, domains_per_min=%d)",
            seed[:8] + "...", domains_per_minute
        )

    def _weighted_random_char(self, rng: random.Random) -> str:
        """根据字符频率分布加权随机选择一个字符

        Args:
            rng: 随机数生成器实例

        Returns:
            随机选择的字符
        """
        r = rng.random()
        for char, cumulative in self._char_cumulative:
            if r <= cumulative:
                return char
        return self._char_cumulative[-1][0]

    def _generate_domain_length(self, rng: random.Random) -> int:
        """生成符合真实分布的域名长度

        使用高斯分布生成域名长度，限制在3-30之间。

        Args:
            rng: 随机数生成器实例

        Returns:
            生成的域名长度
        """
        length = int(rng.gauss(self.DOMAIN_LENGTH_MU, self.DOMAIN_LENGTH_SIGMA))
        return max(3, min(30, length))

    def _generate_sld(
        self,
        rng: random.Random,
        length: Optional[int] = None,
    ) -> str:
        """生成二级域名(SLD)

        生成符合真实域名统计特征的二级域名。

        Args:
            rng: 随机数生成器实例
            length: 指定长度（None则随机生成）

        Returns:
            生成的二级域名
        """
        if length is None:
            length = self._generate_domain_length(rng)

        # 30%概率使用常见前缀+后缀模式
        if rng.random() < 0.3:
            prefix = rng.choice(self.COMMON_PREFIXES)
            suffix = rng.choice(self.COMMON_SUFFIXES)
            middle_length = max(0, length - len(prefix) - len(suffix))
            middle = "".join(
                self._weighted_random_char(rng)
                for _ in range(middle_length)
            )
            return prefix + middle + suffix

        # 70%概率使用纯随机字符
        sld = "".join(
            self._weighted_random_char(rng) for _ in range(length)
        )

        # 确保不以连字符开头或结尾
        sld = sld.strip("-")
        # 确保不包含连续的连字符
        while "--" in sld:
            sld = sld.replace("--", "-")

        return sld if sld else "domain"

    def generate_daily_domains(
        self,
        count: int = 10,
        date: Optional[datetime] = None,
    ) -> List[GeneratedDomain]:
        """生成基于日期的确定性域名列表

        使用种子+日期作为随机源，确保同一天生成相同的域名。

        Args:
            count: 要生成的域名数量
            date: 指定日期（默认为当天）

        Returns:
            生成的域名列表
        """
        if date is None:
            date = datetime.now(timezone.utc)

        # 基于种子和日期创建确定性随机源
        date_seed = f"{self.seed}-{date.strftime('%Y-%m-%d')}"
        seed_hash = hashlib.sha256(date_seed.encode("utf-8")).digest()
        rng = random.Random(seed_hash)

        domains: List[GeneratedDomain] = []
        for _ in range(count):
            sld = self._generate_sld(rng)
            tld = rng.choice(self.tlds)
            domain_str = sld + tld

            domain = GeneratedDomain(
                domain=domain_str,
                sld=sld,
                tld=tld,
                generated_at=time.time(),
            )
            domains.append(domain)

        logger.info(
            "Generated %d daily domains for %s", count,
            date.strftime("%Y-%m-%d")
        )
        return domains

    def generate_domain_for_minute(
        self,
        minute_offset: int = 0,
    ) -> GeneratedDomain:
        """为指定分钟生成域名

        每分钟生成不同的域名，用于域名轮换。

        Args:
            minute_offset: 分钟偏移量（0=当前分钟）

        Returns:
            生成的域名对象
        """
        now = datetime.now(timezone.utc)
        target_minute = now - timedelta(minutes=minute_offset)

        # 基于种子和分钟创建确定性随机源
        minute_seed = f"{self.seed}-min-{target_minute.strftime('%Y%m%d%H%M')}"
        seed_hash = hashlib.sha256(minute_seed.encode("utf-8")).digest()
        rng = random.Random(seed_hash)

        sld = self._generate_sld(rng)
        tld = rng.choice(self.tlds)
        domain_str = sld + tld

        domain = GeneratedDomain(
            domain=domain_str,
            sld=sld,
            tld=tld,
            generated_at=time.time(),
        )

        return domain

    def register_dns_record(
        self,
        domain: str,
        record_type: DNSRecordType = DNSRecordType.A,
        value: Optional[str] = None,
        ttl: int = 300,
    ) -> Dict[str, str]:
        """注册DNS记录

        为生成的域名注册DNS记录。

        Args:
            domain: 域名
            record_type: 记录类型
            value: 记录值（自动生成如果为None）
            ttl: TTL值

        Returns:
            包含DNS记录信息的字典
        """
        if value is None:
            if record_type == DNSRecordType.A:
                value = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
            elif record_type == DNSRecordType.AAAA:
                value = ":".join(
                    f"{random.randint(0, 0xffff):04x}" for _ in range(8)
                )
            elif record_type == DNSRecordType.CNAME:
                value = f"cdn-{random.randint(1,9999)}.cloudfront.net"
            else:
                value = f"auto-generated-{random.randint(1000,9999)}"

        record_key = f"{domain}:{record_type.value}"
        self._dns_records[record_key] = {
            "domain": domain,
            "type": record_type.value,
            "value": value,
            "ttl": ttl,
            "registered_at": datetime.now(timezone.utc).isoformat(),
        }

        logger.debug("DNS record registered: %s -> %s (%s)",
                      domain, value, record_type.value)

        return self._dns_records[record_key]

    async def start_rotation(self) -> None:
        """启动域名自动轮换

        每隔rotation_interval秒生成新域名并清理过期域名。
        """
        if self._is_running:
            logger.warning("Domain rotation is already running")
            return

        self._is_running = True
        logger.info("Starting domain rotation (interval=%ds)", self.rotation_interval)

        while self._is_running:
            try:
                # 生成新域名
                new_domains = []
                for i in range(self.domains_per_minute):
                    domain = self.generate_domain_for_minute(minute_offset=i)
                    new_domains.append(domain)

                    # 注册DNS记录
                    self.register_dns_record(domain.domain, DNSRecordType.A)
                    self.register_dns_record(domain.domain, DNSRecordType.AAAA)

                    # 添加到活跃域名
                    self._active_domains[domain.domain] = domain

                # 清理过期域名
                self._cleanup_expired_domains()

                # 清理超出限制的域名
                while len(self._active_domains) > self.max_active_domains:
                    oldest_domain = min(
                        self._active_domains.values(),
                        key=lambda d: d.generated_at
                    )
                    oldest_domain.is_active = False
                    self._domain_history.append(oldest_domain)
                    del self._active_domains[oldest_domain.domain]

                logger.debug(
                    "Rotation: generated %d new domains, %d active",
                    len(new_domains), len(self._active_domains)
                )

                await asyncio.sleep(self.rotation_interval)

            except asyncio.CancelledError:
                logger.info("Domain rotation cancelled")
                break
            except Exception as e:
                logger.error("Error in domain rotation: %s", e)
                await asyncio.sleep(self.rotation_interval)

    async def stop_rotation(self) -> None:
        """停止域名自动轮换"""
        self._is_running = False
        if self._rotation_task is not None:
            self._rotation_task.cancel()
            try:
                await self._rotation_task
            except asyncio.CancelledError:
                pass
            self._rotation_task = None
        logger.info("Domain rotation stopped")

    def _cleanup_expired_domains(self) -> None:
        """清理过期的活跃域名"""
        now = time.time()
        expired: List[str] = []

        for domain_str, domain in self._active_domains.items():
            if now > domain.expires_at:
                domain.is_active = False
                self._domain_history.append(domain)
                expired.append(domain_str)

        for domain_str in expired:
            del self._active_domains[domain_str]

        if expired:
            logger.debug("Cleaned up %d expired domains", len(expired))

    def get_active_domains(self) -> List[GeneratedDomain]:
        """获取当前活跃的域名列表

        Returns:
            活跃域名列表
        """
        return list(self._active_domains.values())

    def get_dns_records(self) -> Dict[str, Dict[str, str]]:
        """获取所有DNS记录

        Returns:
            DNS记录字典
        """
        return self._dns_records.copy()


# ============================================================================
# CDN中转管理器 / CDN Relay Manager
# ============================================================================

class CDNRelayManager:
    """CDN中转管理器

    管理通过CDN边缘节点的流量中转，支持Cloudflare Workers、
    Akamai EdgeCompute等平台，实现流量分散和抗封锁。

    Features:
        - Cloudflare Workers中转
        - Akamai EdgeCompute中转
        - CDN节点选择策略
        - 流量分散算法

    Example:
        >>> manager = CDNRelayManager(CDNProvider.CLOUDFLARE)
        >>> await manager.initialize()
        >>> relay_info = await manager.select_relay_node()
    """

    # Cloudflare边缘节点位置
    CLOUDFLARE_POPS: List[str] = [
        "SJC", "LAX", "SEA", "DFW", "ORD", "IAD", "ATL", "MIA",
        "YYZ", "YVR", "LHR", "FRA", "AMS", "CDG", "SIN", "NRT",
        "ICN", "SYD", "BOM", "GRU", "JNB", "DXB",
    ]

    # Akamai边缘节点位置
    AKAMAI_POPS: List[str] = [
        "us-east-1", "us-west-1", "us-west-2",
        "eu-west-1", "eu-central-1", "eu-north-1",
        "ap-southeast-1", "ap-northeast-1", "ap-south-1",
        "sa-east-1", "me-south-1", "af-south-1",
    ]

    # CDN提供商的默认配置
    PROVIDER_DEFAULTS: Dict[CDNProvider, Dict[str, Any]] = {
        CDNProvider.CLOUDFLARE: {
            "worker_script_size_limit": 1048576,  # 1MB
            "request_timeout": 30,
            "subrequest_limit": 50,
            "cpu_time_limit": 50,  # ms
        },
        CDNProvider.AKAMAI: {
            "edge_worker_size_limit": 1048576,
            "request_timeout": 60,
            "subrequest_limit": 100,
            "cpu_time_limit": 100,
        },
        CDNProvider.FASTLY: {
            "compute_size_limit": 524288,  # 512KB
            "request_timeout": 30,
            "subrequest_limit": 50,
            "cpu_time_limit": 100,
        },
        CDNProvider.CUSTOM: {
            "request_timeout": 30,
            "subrequest_limit": 20,
        },
    }

    def __init__(
        self,
        provider: CDNProvider = CDNProvider.CLOUDFLARE,
        config: Optional[CDNRelayConfig] = None,
        load_balance_strategy: str = "weighted_latency",
    ) -> None:
        """初始化CDN中转管理器

        Args:
            provider: CDN提供商
            config: 中转配置
            load_balance_strategy: 负载均衡策略
                - "weighted_latency": 加权延迟（优先选择低延迟节点）
                - "round_robin": 轮询
                - "random": 随机选择
                - "least_connections": 最少连接
        """
        self.provider = provider
        self.config = config or CDNRelayConfig(provider=provider)
        self.load_balance_strategy = load_balance_strategy

        # 节点管理
        self._nodes: Dict[str, Dict[str, Any]] = {}
        self._node_health: Dict[str, bool] = {}
        self._node_latency: Dict[str, float] = {}
        self._node_connections: Dict[str, int] = {}
        self._round_robin_index: int = 0

        # 统计信息
        self._stats: Dict[str, int] = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "bytes_relayed": 0,
            "active_connections": 0,
        }

        # 提供商默认配置
        self._provider_config = self.PROVIDER_DEFAULTS.get(
            provider, self.PROVIDER_DEFAULTS[CDNProvider.CUSTOM]
        )

        logger.info(
            "CDNRelayManager initialized: provider=%s, strategy=%s",
            provider.value, load_balance_strategy
        )

    async def initialize(self) -> None:
        """初始化CDN中转管理器

        发现可用的边缘节点并测量延迟。
        """
        logger.info("Initializing CDN relay manager...")

        # 根据提供商选择节点
        if self.provider == CDNProvider.CLOUDFLARE:
            pops = self.CLOUDFLARE_POPS
        elif self.provider == CDNProvider.AKAMAI:
            pops = self.AKAMAI_POPS
        else:
            pops = self.config.edge_nodes if self.config.edge_nodes else [
                "node-1", "node-2", "node-3"
            ]

        # 初始化节点
        for pop in pops:
            node_id = f"{self.provider.value}-{pop.lower()}"
            self._nodes[node_id] = {
                "id": node_id,
                "pop": pop,
                "provider": self.provider.value,
                "address": self._generate_node_address(pop),
                "health": True,
                "capacity": random.randint(50, 200),
                "current_load": 0,
            }
            self._node_health[node_id] = True
            self._node_latency[node_id] = random.uniform(10, 200)
            self._node_connections[node_id] = 0

        logger.info(
            "CDN relay manager initialized: %d nodes discovered",
            len(self._nodes)
        )

    def _generate_node_address(self, pop: str) -> str:
        """生成节点地址

        Args:
            pop: 节点位置代码

        Returns:
            模拟的节点地址
        """
        if self.provider == CDNProvider.CLOUDFLARE:
            return f"https://{pop.lower()}.workers.dev"
        elif self.provider == CDNProvider.AKAMAI:
            return f"https://edge.{pop.lower()}.akamai.net"
        else:
            return f"https://{pop.lower()}.cdn.example.com"

    async def measure_latency(self, node_id: str) -> float:
        """测量到指定节点的延迟

        Args:
            node_id: 节点ID

        Returns:
            测量的延迟（毫秒）

        Raises:
            KeyError: 如果节点ID不存在
        """
        if node_id not in self._nodes:
            raise KeyError(f"Node not found: {node_id}")

        # 模拟延迟测量（真实实现中会实际发送探测包）
        base_latency = self._node_latency.get(node_id, 50.0)
        measured = base_latency + random.gauss(0, 5)  # 添加少量噪声
        measured = max(1.0, measured)

        self._node_latency[node_id] = measured
        return measured

    async def select_relay_node(self) -> Dict[str, Any]:
        """选择最佳中转节点

        根据配置的负载均衡策略选择节点。

        Returns:
            选中的节点信息

        Raises:
            RuntimeError: 如果没有可用的健康节点
        """
        # 获取健康节点
        healthy_nodes = [
            nid for nid in self._nodes
            if self._node_health.get(nid, False)
        ]

        if not healthy_nodes:
            raise RuntimeError("No healthy relay nodes available")

        selected_id: str = ""

        if self.load_balance_strategy == "weighted_latency":
            # 加权延迟：延迟越低权重越高
            weights: List[float] = []
            for nid in healthy_nodes:
                latency = self._node_latency.get(nid, 100.0)
                # 权重与延迟成反比
                weights.append(1.0 / max(latency, 1.0))

            total_weight = sum(weights)
            r = random.uniform(0, total_weight)
            cumulative = 0.0
            for nid, w in zip(healthy_nodes, weights):
                cumulative += w
                if r <= cumulative:
                    selected_id = nid
                    break
            if not selected_id:
                selected_id = healthy_nodes[-1]

        elif self.load_balance_strategy == "round_robin":
            selected_id = healthy_nodes[
                self._round_robin_index % len(healthy_nodes)
            ]
            self._round_robin_index += 1

        elif self.load_balance_strategy == "least_connections":
            selected_id = min(
                healthy_nodes,
                key=lambda nid: self._node_connections.get(nid, 0)
            )

        else:  # random
            selected_id = random.choice(healthy_nodes)

        # 更新连接计数
        self._node_connections[selected_id] = (
            self._node_connections.get(selected_id, 0) + 1
        )
        self._stats["active_connections"] += 1

        node_info = self._nodes[selected_id].copy()
        node_info["latency_ms"] = round(self._node_latency.get(selected_id, 0), 2)
        node_info["connections"] = self._node_connections.get(selected_id, 0)

        logger.debug("Selected relay node: %s (latency=%.1fms)",
                      selected_id, node_info["latency_ms"])

        return node_info

    async def relay_request(
        self,
        data: bytes,
        target_host: str,
        target_port: int = 443,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """通过CDN中继请求

        将数据通过选定的CDN节点中转到目标服务器。

        Args:
            data: 要中继的数据
            target_host: 目标主机
            target_port: 目标端口
            headers: 自定义请求头

        Returns:
            包含中继结果的字典

        Raises:
            RuntimeError: 如果中继失败
        """
        self._stats["total_requests"] += 1

        try:
            # 选择中转节点
            node = await self.select_relay_node()

            # 构造中继请求
            if headers is None:
                headers = {}

            relay_headers = {
                "x-relay-target": target_host,
                "x-relay-port": str(target_port),
                "x-relay-provider": self.provider.value,
                "x-relay-node": node["id"],
                "content-type": "application/octet-stream",
                **headers,
            }

            # 模拟中继延迟（CDN中转通常增加20-100ms延迟）
            relay_latency = self._node_latency.get(node["id"], 50.0)
            await asyncio.sleep(relay_latency / 1000.0)

            # 模拟请求处理
            processing_time = random.uniform(0.005, 0.05)
            await asyncio.sleep(processing_time)

            # 模拟响应
            response_size = random.randint(len(data), len(data) * 2)

            self._stats["successful_requests"] += 1
            self._stats["bytes_relayed"] += len(data) + response_size

            # 释放连接计数
            self._node_connections[node["id"]] = max(
                0, self._node_connections.get(node["id"], 1) - 1
            )
            self._stats["active_connections"] = max(
                0, self._stats["active_connections"] - 1
            )

            return {
                "success": True,
                "node_id": node["id"],
                "node_pop": node["pop"],
                "target_host": target_host,
                "target_port": target_port,
                "request_size": len(data),
                "response_size": response_size,
                "relay_latency_ms": round(relay_latency, 2),
                "processing_time_ms": round(processing_time * 1000, 2),
                "total_time_ms": round((relay_latency + processing_time * 1000), 2),
                "headers": relay_headers,
            }

        except Exception as e:
            self._stats["failed_requests"] += 1
            logger.error("CDN relay failed: %s", e)
            raise RuntimeError(f"CDN relay failed: {e}") from e

    async def health_check(self) -> Dict[str, Any]:
        """执行所有节点的健康检查

        Returns:
            包含健康检查结果的字典
        """
        results: Dict[str, Dict[str, Any]] = {}

        for node_id in self._nodes:
            try:
                latency = await self.measure_latency(node_id)
                is_healthy = latency < 500  # 超过500ms视为不健康
                self._node_health[node_id] = is_healthy

                results[node_id] = {
                    "healthy": is_healthy,
                    "latency_ms": round(latency, 2),
                    "connections": self._node_connections.get(node_id, 0),
                }
            except Exception as e:
                self._node_health[node_id] = False
                results[node_id] = {
                    "healthy": False,
                    "error": str(e),
                    "connections": self._node_connections.get(node_id, 0),
                }

        healthy_count = sum(1 for r in results.values() if r.get("healthy", False))
        logger.info(
            "Health check completed: %d/%d nodes healthy",
            healthy_count, len(results)
        )

        return {
            "total_nodes": len(results),
            "healthy_nodes": healthy_count,
            "unhealthy_nodes": len(results) - healthy_count,
            "details": results,
        }

    def get_stats(self) -> Dict[str, int]:
        """获取CDN中转管理器的统计信息

        Returns:
            包含各项统计计数的字典
        """
        return self._stats.copy()

    def get_nodes(self) -> List[Dict[str, Any]]:
        """获取所有节点信息

        Returns:
            节点信息列表
        """
        nodes = []
        for node_id, node_info in self._nodes.items():
            info = node_info.copy()
            info["latency_ms"] = round(
                self._node_latency.get(node_id, 0), 2
            )
            info["healthy"] = self._node_health.get(node_id, False)
            info["connections"] = self._node_connections.get(node_id, 0)
            nodes.append(info)
        return nodes


# ============================================================================
# 模块入口测试 / Module Entry Point Test
# ============================================================================

async def _demo() -> None:
    """演示所有组件的基本功能"""
    logging.basicConfig(level=logging.INFO)

    print("=" * 60)
    print("Traffic Disguise V2 - Demo")
    print("=" * 60)

    # 1. ProtocolStackSimulator
    print("\n[1] ProtocolStackSimulator")
    simulator = ProtocolStackSimulator()
    result = await simulator.disguise_packet(b"Hello World", ProtocolType.DOH)
    print(f"  DoH query: {result['domain']} -> {result.get('answer', 'N/A')}")

    result = await simulator.disguise_packet(b"Secret data", ProtocolType.TLS_13)
    print(f"  TLS handshake: cipher={result['cipher_suite']}")

    result = await simulator.disguise_packet(b"POST data", ProtocolType.HTTP2)
    print(f"  HTTP/2 stream: id={result['stream_id']}, frames={result['total_frames']}")

    result = await simulator.disguise_packet(b"QUIC payload", ProtocolType.QUIC)
    print(f"  QUIC connection: {result['server_name']} in {result['handshake_time_ms']}ms")

    # 2. WebRTCDisguiser
    print("\n[2] WebRTCDisguiser")
    disguiser = WebRTCDisguiser()
    session = await disguiser.create_session()
    print(f"  Session: {session.session_id}")
    dtls = await disguiser.simulate_dtls_handshake(session.session_id)
    print(f"  DTLS: {dtls['cipher_suite']}")
    ice = await disguiser.simulate_ice_exchange(session.session_id)
    print(f"  ICE: {len(ice['candidates'])} candidates")
    sctp = await disguiser.simulate_sctp_channel(session.session_id, "chat")
    print(f"  SCTP: channel '{sctp['channel_info']['label']}'")

    # 3. DomainGeneratorDGA
    print("\n[3] DomainGeneratorDGA")
    dga = DomainGeneratorDGA(seed="demo-seed")
    domains = dga.generate_daily_domains(count=5)
    for d in domains:
        print(f"  {d.domain}")

    # 4. CDNRelayManager
    print("\n[4] CDNRelayManager")
    cdn = CDNRelayManager(CDNProvider.CLOUDFLARE)
    await cdn.initialize()
    node = await cdn.select_relay_node()
    print(f"  Selected node: {node['id']} ({node['latency_ms']}ms)")
    relay = await cdn.relay_request(b"test data", "target.example.com")
    print(f"  Relay: {relay['total_time_ms']}ms, {relay['request_size']}B sent")

    print("\n" + "=" * 60)
    print("Demo completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(_demo())
