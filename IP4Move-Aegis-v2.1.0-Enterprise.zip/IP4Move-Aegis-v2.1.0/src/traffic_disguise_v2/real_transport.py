"""
真实DoH/WebRTC传输实现

修复问题:
- 原simulate_doh_query是模拟，不是真实传输
- 伪装流量没有对应TCP连接会被深度检测识别
- 需要真的用DoH传数据，而不是伪装成DoH

版本: v2.1.0
"""

from __future__ import annotations

import asyncio
import base64
import logging
import random
import struct
import time
import zlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)

# 尝试导入httpx
try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False
    logger.warning("httpx未安装，真实DoH不可用。pip install httpx")


# ============================================================================
# DoH服务端点
# ============================================================================

DOH_ENDPOINTS = {
    "cloudflare": {
        "url": "https://cloudflare-dns.com/dns-query",
        "ip": "1.1.1.1",
        "bootstrap_ip": "1.1.1.1",
    },
    "google": {
        "url": "https://dns.google/dns-query",
        "ip": "8.8.8.8",
        "bootstrap_ip": "8.8.8.8",
    },
    "quad9": {
        "url": "https://dns.quad9.net/dns-query",
        "ip": "9.9.9.9",
        "bootstrap_ip": "9.9.9.9",
    },
}


# ============================================================================
# DNS协议编解码
# ============================================================================

class DNSPacketBuilder:
    """
    DNS数据包构建器
    
    将任意数据编码为合法的DNS查询格式
    """
    
    @staticmethod
    def build_query(
        domain: str,
        query_type: int = 16,  # TXT记录
        query_class: int = 1,   # IN
        recursion_desired: bool = True,
    ) -> bytes:
        """
        构建DNS查询包
        
        Args:
            domain: 查询域名
            query_type: 查询类型 (16=TXT)
            query_class: 查询类 (1=IN)
            recursion_desired: 是否递归查询
        
        Returns:
            DNS查询包字节
        """
        # 生成随机事务ID
        transaction_id = random.randint(0, 65535)
        
        # 标志位
        flags = 0x0100 if recursion_desired else 0x0000  # 标准查询, 递归
        
        # 问题数=1, 其他=0
        header = struct.pack(
            ">HHHHHH",
            transaction_id,  # Transaction ID
            flags,           # Flags
            1,               # Questions
            0,               # Answer RRs
            0,               # Authority RRs
            0,               # Additional RRs
        )
        
        # 编码域名
        question = DNSPacketBuilder._encode_domain(domain)
        
        # 查询类型和类
        question += struct.pack(">HH", query_type, query_class)
        
        return header + question
    
    @staticmethod
    def _encode_domain(domain: str) -> bytes:
        """编码域名为DNS格式"""
        result = b""
        for label in domain.split("."):
            if label:
                result += bytes([len(label)]) + label.encode("ascii")
        result += b"\x00"  # 终止符
        return result
    
    @staticmethod
    def parse_response(response: bytes) -> Tuple[int, List[bytes]]:
        """
        解析DNS响应
        
        Returns:
            (transaction_id, answers)
        """
        if len(response) < 12:
            return 0, []
        
        # 解析头部
        transaction_id, flags, qdcount, ancount, nscount, arcount = struct.unpack(
            ">HHHHHH", response[:12]
        )
        
        # 跳过问题部分
        offset = 12
        for _ in range(qdcount):
            while offset < len(response) and response[offset] != 0:
                offset += response[offset] + 1
            offset += 5  # 终止符 + type + class
        
        # 解析回答
        answers = []
        for _ in range(ancount):
            if offset >= len(response):
                break
            
            # 跳过域名 (可能是压缩指针)
            if response[offset] >= 0xC0:
                offset += 2
            else:
                while offset < len(response) and response[offset] != 0:
                    offset += response[offset] + 1
                offset += 1
            
            if offset + 10 > len(response):
                break
            
            # 解析资源记录
            rtype, rclass, ttl, rdlength = struct.unpack(
                ">HHIH", response[offset:offset+10]
            )
            offset += 10
            
            if offset + rdlength > len(response):
                break
            
            rdata = response[offset:offset+rdlength]
            offset += rdlength
            
            # TXT记录特殊处理
            if rtype == 16:  # TXT
                # TXT记录格式: 长度字节 + 数据
                txt_data = b""
                txt_offset = 0
                while txt_offset < len(rdata):
                    txt_len = rdata[txt_offset]
                    txt_data += rdata[txt_offset+1:txt_offset+1+txt_len]
                    txt_offset += 1 + txt_len
                answers.append(txt_data)
            else:
                answers.append(rdata)
        
        return transaction_id, answers


# ============================================================================
# 数据编码为DNS查询
# ============================================================================

class DataEncoder:
    """
    将任意数据编码为DNS查询域名
    
    策略:
    - 数据分块，每块编码为子域名标签
    - 使用合法字符 (a-z, 0-9, hyphen)
    - 添加校验和
    """
    
    # 每个DNS标签最大63字节
    MAX_LABEL_SIZE = 63
    # 每次查询最大数据量
    MAX_DATA_PER_QUERY = 252  # 4 * 63
    
    @staticmethod
    def encode_data(data: bytes, base_domain: str) -> Tuple[str, bytes]:
        """
        将数据编码为域名
        
        Args:
            data: 要编码的数据 (最大252字节)
            base_domain: 基础域名 (如 "example.com")
        
        Returns:
            (完整域名, 原始DNS查询包)
        """
        # 添加校验和
        checksum = zlib.crc32(data) & 0xFFFFFFFF
        data_with_checksum = struct.pack(">I", checksum) + data
        
        # Base32编码 (使用小写字母和数字)
        encoded = base64.b32encode(data_with_checksum).decode("ascii").lower()
        # 移除padding
        encoded = encoded.rstrip("=")
        
        # 分割为标签
        labels = []
        for i in range(0, len(encoded), DataEncoder.MAX_LABEL_SIZE):
            label = encoded[i:i+DataEncoder.MAX_LABEL_SIZE]
            labels.append(label)
        
        # 构建完整域名
        domain = ".".join(labels) + "." + base_domain
        
        # 构建DNS查询包
        query_packet = DNSPacketBuilder.build_query(domain, query_type=16)  # TXT
        
        return domain, query_packet
    
    @staticmethod
    def decode_data(answers: List[bytes]) -> Optional[bytes]:
        """
        从DNS回答中解码数据
        
        Args:
            answers: DNS回答列表
        
        Returns:
            解码后的数据，失败返回None
        """
        for answer in answers:
            try:
                # 尝试Base32解码
                # 补齐padding
                padding = (8 - len(answer) % 8) % 8
                encoded = answer + b"=" * padding
                data_with_checksum = base64.b32decode(encoded.upper())
                
                if len(data_with_checksum) < 4:
                    continue
                
                # 验证校验和
                checksum = struct.unpack(">I", data_with_checksum[:4])[0]
                data = data_with_checksum[4:]
                
                if zlib.crc32(data) & 0xFFFFFFFF == checksum:
                    return data
            except Exception:
                continue
        
        return None


# ============================================================================
# 真实DoH传输
# ============================================================================

class RealDoHTransport:
    """
    真实DoH传输实现
    
    不是模拟，而是真的通过DoH服务器传输数据！
    
    工作原理:
    1. 将数据编码为DNS查询域名
    2. 发送真实HTTPS请求到DoH服务器
    3. 从响应中解码数据
    
    优势:
    - 完全合法的HTTPS流量
    - 无法与正常DNS查询区分
    - 真实的TCP/TLS连接
    """
    
    def __init__(
        self,
        provider: str = "cloudflare",
        timeout: float = 5.0,
        max_retries: int = 3,
    ):
        if not HAS_HTTPX:
            raise RuntimeError("需要httpx: pip install httpx")
        
        self._provider = DOH_ENDPOINTS.get(provider, DOH_ENDPOINTS["cloudflare"])
        self._timeout = timeout
        self._max_retries = max_retries
        
        # HTTP客户端
        self._client: Optional[httpx.AsyncClient] = None
        
        # 统计
        self._stats = {
            "queries_sent": 0,
            "queries_success": 0,
            "bytes_sent": 0,
            "bytes_received": 0,
        }
    
    async def _get_client(self) -> httpx.AsyncClient:
        """获取HTTP客户端"""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=self._timeout,
                headers={
                    "Accept": "application/dns-message",
                    "Content-Type": "application/dns-message",
                },
            )
        return self._client
    
    async def send_query(self, query_packet: bytes) -> Optional[bytes]:
        """
        发送真实DNS查询到DoH服务器
        
        Args:
            query_packet: DNS查询包
        
        Returns:
            DNS响应包，失败返回None
        """
        client = await self._get_client()
        
        for attempt in range(self._max_retries):
            try:
                # 发送POST请求 (DoH标准)
                response = await client.post(
                    self._provider["url"],
                    content=query_packet,
                )
                
                if response.status_code == 200:
                    self._stats["queries_success"] += 1
                    return response.content
                
                logger.debug(f"DoH查询失败: HTTP {response.status_code}")
                
            except httpx.TimeoutException:
                logger.debug(f"DoH超时 (尝试 {attempt+1}/{self._max_retries})")
            except Exception as e:
                logger.debug(f"DoH错误: {e}")
            
            await asyncio.sleep(0.5 * (attempt + 1))
        
        return None
    
    async def send_data(
        self,
        data: bytes,
        base_domain: str = "dns.google",
    ) -> Optional[bytes]:
        """
        通过DoH发送数据
        
        Args:
            data: 要发送的数据 (最大252字节)
            base_domain: 基础域名
        
        Returns:
            响应数据，失败返回None
        """
        if len(data) > DataEncoder.MAX_DATA_PER_QUERY:
            # 分块发送
            return await self._send_large_data(data, base_domain)
        
        # 编码为DNS查询
        domain, query_packet = DataEncoder.encode_data(data, base_domain)
        
        self._stats["queries_sent"] += 1
        self._stats["bytes_sent"] += len(data)
        
        # 发送真实DoH查询
        response_packet = await self.send_query(query_packet)
        
        if response_packet is None:
            return None
        
        # 解析响应
        _, answers = DNSPacketBuilder.parse_response(response_packet)
        
        # 解码数据
        result = DataEncoder.decode_data(answers)
        
        if result:
            self._stats["bytes_received"] += len(result)
        
        return result
    
    async def _send_large_data(
        self,
        data: bytes,
        base_domain: str,
    ) -> Optional[bytes]:
        """发送大数据 (分块)"""
        chunk_size = DataEncoder.MAX_DATA_PER_QUERY
        chunks = [
            data[i:i+chunk_size]
            for i in range(0, len(data), chunk_size)
        ]
        
        results = []
        for i, chunk in enumerate(chunks):
            # 添加块序号
            chunk_with_seq = struct.pack(">H", i) + chunk
            result = await self.send_data(chunk_with_seq, base_domain)
            if result:
                results.append(result)
        
        if results:
            return b"".join(results)
        return None
    
    async def close(self):
        """关闭客户端"""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return self._stats.copy()


# ============================================================================
# WebRTC传输 (需要aiortc)
# ============================================================================

try:
    from aiortc import RTCPeerConnection, RTCDataChannel
    from aiortc.contrib.media import MediaPlayer
    HAS_AIORTC = True
except ImportError:
    HAS_AIORTC = False


class WebRTCTransport:
    """
    WebRTC数据通道传输
    
    使用真实的WebRTC连接传输数据:
    - 真实的ICE/DTLS握手
    - SRTP加密
    - 与正常WebRTC流量不可区分
    """
    
    def __init__(self):
        if not HAS_AIORTC:
            raise RuntimeError("需要aiortc: pip install aiortc")
        
        self._pc: Optional[RTCPeerConnection] = None
        self._channel: Optional[RTCDataChannel] = None
        self._receive_queue: asyncio.Queue = asyncio.Queue()
    
    async def create_offer(self) -> Tuple[str, str]:
        """创建WebRTC offer"""
        self._pc = RTCPeerConnection()
        
        # 创建数据通道
        self._channel = self._pc.createDataChannel("data")
        self._channel.on("message", self._on_message)
        
        # 创建offer
        offer = await self._pc.createOffer()
        await self._pc.setLocalDescription(offer)
        
        return self._pc.localDescription.sdp, self._pc.localDescription.type
    
    async def set_answer(self, sdp: str, sdp_type: str):
        """设置远程answer"""
        await self._pc.setRemoteDescription(
            type=sdp_type,
            sdp=sdp
        )
    
    async def handle_offer(self, sdp: str, sdp_type: str) -> Tuple[str, str]:
        """处理远程offer并创建answer"""
        self._pc = RTCPeerConnection()
        
        await self._pc.setRemoteDescription(
            type=sdp_type,
            sdp=sdp
        )
        
        # 监听数据通道
        @self._pc.on("datachannel")
        def on_datachannel(channel: RTCDataChannel):
            self._channel = channel
            channel.on("message", self._on_message)
        
        # 创建answer
        answer = await self._pc.createAnswer()
        await self._pc.setLocalDescription(answer)
        
        return self._pc.localDescription.sdp, self._pc.localDescription.type
    
    def _on_message(self, message: str):
        """处理接收的消息"""
        self._receive_queue.put_nowait(message.encode() if isinstance(message, str) else message)
    
    async def send(self, data: bytes):
        """发送数据"""
        if self._channel and self._channel.readyState == "open":
            self._channel.send(data)
        else:
            raise RuntimeError("数据通道未就绪")
    
    async def receive(self) -> bytes:
        """接收数据"""
        return await self._receive_queue.get()
    
    async def close(self):
        """关闭连接"""
        if self._pc:
            await self._pc.close()


# ============================================================================
# 传输管理器
# ============================================================================

class TransportManager:
    """
    传输管理器
    
    管理多种传输方式:
    - DoH传输
    - WebRTC传输
    - 自动选择最优方式
    """
    
    def __init__(self, enable_doh: bool = True, enable_webrtc: bool = True):
        self._doh: Optional[RealDoHTransport] = None
        self._webrtc: Optional[WebRTCTransport] = None
        
        if enable_doh and HAS_HTTPX:
            self._doh = RealDoHTransport()
        
        if enable_webrtc and HAS_AIORTC:
            self._webrtc = WebRTCTransport()
    
    async def send_data(self, data: bytes, method: str = "auto") -> Optional[bytes]:
        """
        发送数据
        
        Args:
            data: 要发送的数据
            method: 传输方式 (auto/doh/webrtc)
        
        Returns:
            响应数据
        """
        if method == "auto":
            # 自动选择: 小数据用DoH，大数据用WebRTC
            if len(data) < 200 and self._doh:
                method = "doh"
            elif self._webrtc:
                method = "webrtc"
            elif self._doh:
                method = "doh"
            else:
                raise RuntimeError("无可用传输方式")
        
        if method == "doh":
            if not self._doh:
                raise RuntimeError("DoH传输未启用")
            return await self._doh.send_data(data)
        
        elif method == "webrtc":
            if not self._webrtc:
                raise RuntimeError("WebRTC传输未启用")
            await self._webrtc.send(data)
            return await self._webrtc.receive()
        
        else:
            raise ValueError(f"未知传输方式: {method}")
    
    async def close(self):
        """关闭所有传输"""
        if self._doh:
            await self._doh.close()
        if self._webrtc:
            await self._webrtc.close()
