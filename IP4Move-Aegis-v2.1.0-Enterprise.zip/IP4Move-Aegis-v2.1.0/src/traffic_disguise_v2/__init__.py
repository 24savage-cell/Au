"""
流量伪装技术全面升级模块 (Traffic Disguise V2)
============================================

本模块实现了高级流量伪装技术，旨在使加密通信流量在深度包检测(DPI)下
与正常HTTPS/WebRTC流量不可区分。

主要组件:
    - ProtocolStackSimulator: 真实协议栈模拟器，完整模拟DoH/TLS 1.3/HTTP/2/QUIC
    - WebRTCDisguiser: WebRTC流量伪装器，模拟DTLS/SCTP/ICE/SRTP
    - DomainGeneratorDGA: 动态域名生成器，基于日期的确定性DGA算法
    - CDNRelayManager: CDN中转管理器，支持Cloudflare/Akamai等CDN中转

使用示例:
    >>> from traffic_disguise_v2 import ProtocolStackSimulator, WebRTCDisguiser
    >>> simulator = ProtocolStackSimulator()
    >>> disguised_packet = simulator.disguise_packet(b"secret data")

版本: 2.0.0
作者: IP4Move Aegis Team
许可: MIT License
"""

from traffic_disguise_v2.advanced_disguise import (
    ProtocolStackSimulator,
    WebRTCDisguiser,
    DomainGeneratorDGA,
    CDNRelayManager,
)

__all__ = [
    "ProtocolStackSimulator",
    "WebRTCDisguiser",
    "DomainGeneratorDGA",
    "CDNRelayManager",
]

__version__ = "2.0.0"
