"""
GDPR合规管理模块

提供完整的GDPR合规功能，包括：
- 数据映射与分类
- 同意管理
- 数据主体权利请求(DSAR)处理
- 数据保留策略
- 合规报告生成

Author: IP4Move Security Team
Version: 1.0.0
"""

from .data_mapping.inventory import DataInventory, DataAsset
from .data_mapping.classifier import DataClassifier, ClassificationLevel
from .consent_management.manager import ConsentManager, ConsentRecord
from .consent_management.preferences import PreferenceManager, UserPreferences
from .dsar_handler.request_processor import DSARProcessor, DSARRequest
from .dsar_handler.response_generator import ResponseGenerator
from .data_retention.policies import RetentionPolicy, RetentionManager
from .data_retention.scheduler import RetentionScheduler
from .reporting.compliance_report import ComplianceReportGenerator
from .reporting.audit_trail import AuditTrail

__version__ = "1.0.0"
__all__ = [
    # 数据映射
    "DataInventory",
    "DataAsset",
    "DataClassifier",
    "ClassificationLevel",
    # 同意管理
    "ConsentManager",
    "ConsentRecord",
    "PreferenceManager",
    "UserPreferences",
    # DSAR处理
    "DSARProcessor",
    "DSARRequest",
    "ResponseGenerator",
    # 数据保留
    "RetentionPolicy",
    "RetentionManager",
    "RetentionScheduler",
    # 报告
    "ComplianceReportGenerator",
    "AuditTrail",
]
