"""
DSAR请求处理器

处理数据主体访问请求
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class DSARType(Enum):
    """DSAR请求类型"""
    ACCESS = "access"  # 访问请求
    DELETION = "deletion"  # 删除请求
    PORTABILITY = "portability"  # 可携带性请求
    RECTIFICATION = "rectification"  # 更正请求
    RESTRICTION = "restriction"  # 限制处理请求
    OBJECTION = "objection"  # 反对处理请求


class DSARStatus(Enum):
    """DSAR状态"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    REJECTED = "rejected"
    CANCELLED = "cancelled"


@dataclass
class DSARRequest:
    """DSAR请求记录"""
    id: UUID
    user_id: str
    request_type: DSARType
    status: DSARStatus
    created_at: datetime
    deadline_at: datetime
    completed_at: Optional[datetime] = None
    description: str = ""
    identity_verified: bool = False
    data_categories: List[str] = field(default_factory=list)
    response_data: Dict[str, Any] = field(default_factory=dict)
    rejection_reason: Optional[str] = None


class DSARProcessor:
    """
    DSAR处理器
    
    处理数据主体的GDPR权利请求
    """
    
    # GDPR规定的响应期限(天)
    RESPONSE_DEADLINE_DAYS = 30
    
    def __init__(self):
        """初始化DSAR处理器"""
        self._requests: Dict[UUID, DSARRequest] = {}
        self._user_requests: Dict[str, List[UUID]] = {}
        self._lock = asyncio.Lock()
        logger.info("DSAR处理器初始化完成")
    
    async def submit_request(
        self,
        user_id: str,
        request_type: DSARType,
        description: str = "",
        data_categories: Optional[List[str]] = None
    ) -> DSARRequest:
        """
        提交DSAR请求
        
        Args:
            user_id: 用户ID
            request_type: 请求类型
            description: 请求描述
            data_categories: 数据类别列表
            
        Returns:
            DSAR请求记录
        """
        created_at = datetime.utcnow()
        deadline_at = created_at + timedelta(days=self.RESPONSE_DEADLINE_DAYS)
        
        request = DSARRequest(
            id=uuid4(),
            user_id=user_id,
            request_type=request_type,
            status=DSARStatus.PENDING,
            created_at=created_at,
            deadline_at=deadline_at,
            description=description,
            data_categories=data_categories or []
        )
        
        async with self._lock:
            self._requests[request.id] = request
            if user_id not in self._user_requests:
                self._user_requests[user_id] = []
            self._user_requests[user_id].append(request.id)
        
        logger.info(f"DSAR请求已提交: {user_id} - {request_type.value}")
        return request
    
    async def verify_identity(self, request_id: UUID) -> bool:
        """
        验证请求者身份
        
        Args:
            request_id: 请求ID
            
        Returns:
            是否验证成功
        """
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            request.identity_verified = True
            request.status = DSARStatus.IN_PROGRESS
            
            logger.info(f"身份已验证: {request_id}")
            return True
    
    async def process_request(
        self,
        request_id: UUID,
        response_data: Dict[str, Any]
    ) -> bool:
        """
        处理请求
        
        Args:
            request_id: 请求ID
            response_data: 响应数据
            
        Returns:
            是否处理成功
        """
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            request.status = DSARStatus.COMPLETED
            request.completed_at = datetime.utcnow()
            request.response_data = response_data
            
            logger.info(f"DSAR请求已处理: {request_id}")
            return True
    
    async def reject_request(
        self,
        request_id: UUID,
        reason: str
    ) -> bool:
        """
        拒绝请求
        
        Args:
            request_id: 请求ID
            reason: 拒绝原因
            
        Returns:
            是否拒绝成功
        """
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            request.status = DSARStatus.REJECTED
            request.rejection_reason = reason
            request.completed_at = datetime.utcnow()
            
            logger.info(f"DSAR请求已拒绝: {request_id} - {reason}")
            return True
    
    async def get_request(self, request_id: UUID) -> Optional[DSARRequest]:
        """
        获取请求
        
        Args:
            request_id: 请求ID
            
        Returns:
            DSAR请求
        """
        async with self._lock:
            return self._requests.get(request_id)
    
    async def get_user_requests(self, user_id: str) -> List[DSARRequest]:
        """
        获取用户的所有请求
        
        Args:
            user_id: 用户ID
            
        Returns:
            请求列表
        """
        async with self._lock:
            request_ids = self._user_requests.get(user_id, [])
            return [self._requests[rid] for rid in request_ids if rid in self._requests]
    
    async def get_pending_requests(self) -> List[DSARRequest]:
        """
        获取待处理请求
        
        Returns:
            待处理请求列表
        """
        async with self._lock:
            return [
                req for req in self._requests.values()
                if req.status in [DSARStatus.PENDING, DSARStatus.IN_PROGRESS]
            ]
    
    async def get_overdue_requests(self) -> List[DSARRequest]:
        """
        获取逾期请求
        
        Returns:
            逾期请求列表
        """
        now = datetime.utcnow()
        async with self._lock:
            return [
                req for req in self._requests.values()
                if req.status in [DSARStatus.PENDING, DSARStatus.IN_PROGRESS]
                and req.deadline_at < now
            ]
