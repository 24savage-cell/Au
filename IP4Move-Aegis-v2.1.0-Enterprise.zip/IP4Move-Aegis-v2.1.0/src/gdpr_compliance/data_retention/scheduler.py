"""
保留调度器

自动执行数据保留策略
"""

import asyncio
import logging
from datetime import datetime
from typing import Callable, List, Optional

from .policies import RetentionManager, RetentionRecord, RetentionAction

logger = logging.getLogger(__name__)


class RetentionScheduler:
    """
    保留调度器
    
    定期检查和执行数据保留策略
    """
    
    def __init__(
        self,
        retention_manager: RetentionManager,
        check_interval_hours: int = 24
    ):
        """
        初始化调度器
        
        Args:
            retention_manager: 保留管理器
            check_interval_hours: 检查间隔(小时)
        """
        self.retention_manager = retention_manager
        self.check_interval_hours = check_interval_hours
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._handlers: dict = {}
        
        logger.info("保留调度器初始化完成")
    
    def register_handler(
        self,
        action: RetentionAction,
        handler: Callable[[RetentionRecord], asyncio.coroutine]
    ):
        """
        注册操作处理器
        
        Args:
            action: 保留操作
            handler: 处理函数
        """
        self._handlers[action] = handler
        logger.info(f"处理器已注册: {action.value}")
    
    async def start(self):
        """启动调度器"""
        if self._running:
            return
        
        self._running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info("保留调度器已启动")
    
    async def stop(self):
        """停止调度器"""
        if not self._running:
            return
        
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        
        logger.info("保留调度器已停止")
    
    async def _run_loop(self):
        """运行循环"""
        while self._running:
            try:
                await self._check_and_execute()
                await asyncio.sleep(self.check_interval_hours * 3600)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"保留检查出错: {e}")
                await asyncio.sleep(3600)  # 出错后1小时重试
    
    async def _check_and_execute(self):
        """检查并执行保留策略"""
        logger.info("开始保留策略检查")
        
        expired_records = await self.retention_manager.get_expired_records()
        
        if not expired_records:
            logger.info("没有过期数据")
            return
        
        logger.info(f"发现 {len(expired_records)} 条过期记录")
        
        for record in expired_records:
            await self._process_record(record)
    
    async def _process_record(self, record: RetentionRecord):
        """
        处理单条记录
        
        Args:
            record: 保留记录
        """
        policy = await self.retention_manager.get_policy(record.policy_id)
        
        if not policy:
            logger.warning(f"策略不存在: {record.policy_id}")
            return
        
        action = policy.action
        handler = self._handlers.get(action)
        
        if handler:
            try:
                await handler(record)
                await self.retention_manager.mark_deleted(record.id)
                logger.info(f"记录已处理: {record.id} - {action.value}")
            except Exception as e:
                logger.error(f"处理记录失败: {record.id} - {e}")
        else:
            logger.warning(f"未找到处理器: {action.value}")
    
    async def run_once(self):
        """运行一次检查"""
        await self._check_and_execute()
