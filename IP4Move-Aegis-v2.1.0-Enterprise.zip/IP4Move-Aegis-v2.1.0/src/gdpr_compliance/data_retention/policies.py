"""
数据保留策略模块

管理数据保留和删除策略
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class RetentionAction(Enum):
    """保留期满后的操作"""
    DELETE = "delete"
    ARCHIVE = "archive"
    ANONYMIZE = "anonymize"
    NOTIFY = "notify"


@dataclass
class RetentionPolicy:
    """保留策略"""
    id: UUID
    name: str
    data_category: str
    retention_days: int
    action: RetentionAction
    legal_basis: str
    description: str = ""
    exceptions: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    active: bool = True


@dataclass
class RetentionRecord:
    """保留记录"""
    id: UUID
    data_id: str
    data_category: str
    created_at: datetime
    retention_until: datetime
    policy_id: UUID
    deleted: bool = False
    deleted_at: Optional[datetime] = None


class RetentionManager:
    """
    保留管理器
    
    管理数据保留策略和执行
    """
    
    def __init__(self):
        """初始化保留管理器"""
        self._policies: Dict[UUID, RetentionPolicy] = {}
        self._records: Dict[UUID, RetentionRecord] = {}
        self._lock = asyncio.Lock()
        logger.info("保留管理器初始化完成")
    
    async def create_policy(
        self,
        name: str,
        data_category: str,
        retention_days: int,
        action: RetentionAction,
        legal_basis: str,
        description: str = "",
        exceptions: Optional[List[str]] = None
    ) -> RetentionPolicy:
        """
        创建保留策略
        
        Args:
            name: 策略名称
            data_category: 数据类别
            retention_days: 保留天数
            action: 期满操作
            legal_basis: 法律依据
            description: 描述
            exceptions: 例外情况
            
        Returns:
            保留策略
        """
        policy = RetentionPolicy(
            id=uuid4(),
            name=name,
            data_category=data_category,
            retention_days=retention_days,
            action=action,
            legal_basis=legal_basis,
            description=description,
            exceptions=exceptions or []
        )
        
        async with self._lock:
            self._policies[policy.id] = policy
        
        logger.info(f"保留策略已创建: {name}")
        return policy
    
    async def get_policy(self, policy_id: UUID) -> Optional[RetentionPolicy]:
        """
        获取保留策略
        
        Args:
            policy_id: 策略ID
            
        Returns:
            保留策略
        """
        async with self._lock:
            return self._policies.get(policy_id)
    
    async def get_policy_for_category(self, data_category: str) -> Optional[RetentionPolicy]:
        """
        获取数据类别的保留策略
        
        Args:
            data_category: 数据类别
            
        Returns:
            保留策略
        """
        async with self._lock:
            for policy in self._policies.values():
                if policy.data_category == data_category and policy.active:
                    return policy
            return None
    
    async def register_data(
        self,
        data_id: str,
        data_category: str,
        policy_id: Optional[UUID] = None
    ) -> Optional[RetentionRecord]:
        """
        注册数据以进行保留管理
        
        Args:
            data_id: 数据ID
            data_category: 数据类别
            policy_id: 策略ID(如为None则自动匹配)
            
        Returns:
            保留记录
        """
        async with self._lock:
            if policy_id is None:
                policy = await self.get_policy_for_category(data_category)
            else:
                policy = self._policies.get(policy_id)
            
            if not policy:
                logger.warning(f"未找到数据类别的保留策略: {data_category}")
                return None
            
            created_at = datetime.utcnow()
            retention_until = created_at + timedelta(days=policy.retention_days)
            
            record = RetentionRecord(
                id=uuid4(),
                data_id=data_id,
                data_category=data_category,
                created_at=created_at,
                retention_until=retention_until,
                policy_id=policy.id
            )
            
            self._records[record.id] = record
            logger.info(f"数据已注册保留管理: {data_id}")
            return record
    
    async def get_expired_records(self) -> List[RetentionRecord]:
        """
        获取已过期记录
        
        Returns:
            过期记录列表
        """
        now = datetime.utcnow()
        async with self._lock:
            return [
                record for record in self._records.values()
                if not record.deleted and record.retention_until < now
            ]
    
    async def mark_deleted(self, record_id: UUID) -> bool:
        """
        标记记录为已删除
        
        Args:
            record_id: 记录ID
            
        Returns:
            是否标记成功
        """
        async with self._lock:
            if record_id not in self._records:
                return False
            
            record = self._records[record_id]
            record.deleted = True
            record.deleted_at = datetime.utcnow()
            
            logger.info(f"记录已标记删除: {record_id}")
            return True
    
    async def get_retention_report(self) -> Dict[str, Any]:
        """
        获取保留报告
        
        Returns:
            保留统计
        """
        async with self._lock:
            total_records = len(self._records)
            active_records = sum(1 for r in self._records.values() if not r.deleted)
            deleted_records = sum(1 for r in self._records.values() if r.deleted)
            expired_records = len(await self.get_expired_records())
            
            return {
                "total_records": total_records,
                "active_records": active_records,
                "deleted_records": deleted_records,
                "expired_pending": expired_records,
                "policies_count": len(self._policies),
                "generated_at": datetime.utcnow().isoformat()
            }
