"""
合规报告生成器

生成GDPR合规报告
"""

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


@dataclass
class ComplianceMetric:
    """合规指标"""
    name: str
    value: float
    target: float
    status: str  # "pass", "fail", "warning"
    description: str


class ComplianceReportGenerator:
    """
    合规报告生成器
    
    生成GDPR合规性评估报告
    """
    
    def __init__(self):
        """初始化报告生成器"""
        logger.info("合规报告生成器初始化完成")
    
    def generate_comprehensive_report(
        self,
        data_inventory_stats: Dict[str, Any],
        consent_stats: Dict[str, Any],
        dsar_stats: Dict[str, Any],
        retention_stats: Dict[str, Any],
        security_measures: List[str]
    ) -> Dict[str, Any]:
        """
        生成综合合规报告
        
        Args:
            data_inventory_stats: 数据清单统计
            consent_stats: 同意统计
            dsar_stats: DSAR统计
            retention_stats: 保留统计
            security_measures: 安全措施列表
            
        Returns:
            合规报告
        """
        # 计算合规指标
        metrics = self._calculate_metrics(
            data_inventory_stats,
            consent_stats,
            dsar_stats,
            retention_stats
        )
        
        # 评估整体合规状态
        overall_status = self._assess_overall_status(metrics)
        
        # 生成建议
        recommendations = self._generate_recommendations(metrics)
        
        return {
            "report_id": str(uuid4()),
            "generated_at": datetime.utcnow().isoformat(),
            "report_period": {
                "start": (datetime.utcnow() - timedelta(days=90)).isoformat(),
                "end": datetime.utcnow().isoformat()
            },
            "overall_compliance_status": overall_status,
            "metrics": [
                {
                    "name": m.name,
                    "value": m.value,
                    "target": m.target,
                    "status": m.status,
                    "description": m.description
                }
                for m in metrics
            ],
            "data_governance": {
                "inventory": data_inventory_stats,
                "retention": retention_stats
            },
            "privacy_operations": {
                "consent_management": consent_stats,
                "dsar_handling": dsar_stats
            },
            "security_measures": security_measures,
            "recommendations": recommendations,
            "next_review_date": (datetime.utcnow() + timedelta(days=90)).isoformat()
        }
    
    def _calculate_metrics(
        self,
        data_inventory_stats: Dict[str, Any],
        consent_stats: Dict[str, Any],
        dsar_stats: Dict[str, Any],
        retention_stats: Dict[str, Any]
    ) -> List[ComplianceMetric]:
        """
        计算合规指标
        
        Args:
            data_inventory_stats: 数据清单统计
            consent_stats: 同意统计
            dsar_stats: DSAR统计
            retention_stats: 保留统计
            
        Returns:
            指标列表
        """
        metrics = []
        
        # 数据加密覆盖率
        encryption_coverage = data_inventory_stats.get("encryption_coverage", 0)
        metrics.append(ComplianceMetric(
            name="数据加密覆盖率",
            value=encryption_coverage * 100,
            target=100.0,
            status="pass" if encryption_coverage >= 0.95 else "warning" if encryption_coverage >= 0.8 else "fail",
            description="已加密数据资产的比例"
        ))
        
        # DSAR按时完成率
        on_time_completion = dsar_stats.get("on_time_completion_rate", 1.0)
        metrics.append(ComplianceMetric(
            name="DSAR按时完成率",
            value=on_time_completion * 100,
            target=100.0,
            status="pass" if on_time_completion >= 0.95 else "warning" if on_time_completion >= 0.9 else "fail",
            description="在30天内完成的DSAR请求比例"
        ))
        
        # 同意记录完整性
        consent_completeness = consent_stats.get("record_completeness", 1.0)
        metrics.append(ComplianceMetric(
            name="同意记录完整性",
            value=consent_completeness * 100,
            target=100.0,
            status="pass" if consent_completeness >= 0.99 else "warning",
            description="完整同意记录的比例"
        ))
        
        # 数据保留合规率
        retention_compliance = retention_stats.get("compliance_rate", 1.0)
        metrics.append(ComplianceMetric(
            name="数据保留合规率",
            value=retention_compliance * 100,
            target=100.0,
            status="pass" if retention_compliance >= 0.95 else "warning" if retention_compliance >= 0.9 else "fail",
            description="符合保留策略的数据比例"
        ))
        
        return metrics
    
    def _assess_overall_status(self, metrics: List[ComplianceMetric]) -> str:
        """
        评估整体合规状态
        
        Args:
            metrics: 指标列表
            
        Returns:
            整体状态
        """
        if any(m.status == "fail" for m in metrics):
            return "non_compliant"
        elif any(m.status == "warning" for m in metrics):
            return "partially_compliant"
        else:
            return "compliant"
    
    def _generate_recommendations(self, metrics: List[ComplianceMetric]) -> List[str]:
        """
        生成改进建议
        
        Args:
            metrics: 指标列表
            
        Returns:
            建议列表
        """
        recommendations = []
        
        for metric in metrics:
            if metric.status == "fail":
                if metric.name == "数据加密覆盖率":
                    recommendations.append("优先对敏感数据实施加密，目标达到100%覆盖率")
                elif metric.name == "DSAR按时完成率":
                    recommendations.append("优化DSAR处理流程，确保在30天法定期限内完成")
                elif metric.name == "数据保留合规率":
                    recommendations.append("清理过期数据，确保符合保留策略")
            elif metric.status == "warning":
                recommendations.append(f"{metric.name}需要改进，当前值: {metric.value:.1f}%")
        
        if not recommendations:
            recommendations.append("继续保持当前合规水平")
        
        return recommendations
    
    def export_report(
        self,
        report: Dict[str, Any],
        format_type: str = "json"
    ) -> str:
        """
        导出报告
        
        Args:
            report: 报告数据
            format_type: 格式类型
            
        Returns:
            格式化报告
        """
        if format_type == "json":
            return json.dumps(report, indent=2, ensure_ascii=False)
        elif format_type == "summary":
            return self._generate_summary_text(report)
        else:
            return str(report)
    
    def _generate_summary_text(self, report: Dict[str, Any]) -> str:
        """
        生成文本摘要
        
        Args:
            report: 报告数据
            
        Returns:
            文本摘要
        """
        lines = [
            "GDPR合规报告摘要",
            "=" * 40,
            f"生成时间: {report['generated_at']}",
            f"整体状态: {report['overall_compliance_status']}",
            "",
            "关键指标:",
        ]
        
        for metric in report['metrics']:
            lines.append(f"  - {metric['name']}: {metric['value']:.1f}% ({metric['status']})")
        
        lines.extend([
            "",
            "主要建议:",
        ])
        
        for rec in report['recommendations'][:3]:
            lines.append(f"  - {rec}")
        
        return "\n".join(lines)
