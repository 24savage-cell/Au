"""报告模块"""
from .compliance_report import ComplianceReportGenerator
from .audit_trail import AuditTrail

__all__ = ["ComplianceReportGenerator", "AuditTrail"]
