"""
审计追踪模块

记录GDPR相关的所有操作
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class AuditEventType(Enum):
    """审计事件类型"""
    DATA_ACCESS = "data_access"
    DATA_MODIFICATION = "data_modification"
    DATA_DELETION = "data_deletion"
    CONSENT_GRANTED = "consent_granted"
    CONSENT_REVOKED = "consent_revoked"
    DSAR_SUBMITTED = "dsar_submitted"
    DSAR_COMPLETED = "dsar_completed"
    POLICY_UPDATED = "policy_updated"
    CONFIGURATION_CHANGED = "configuration_changed"


@dataclass
class AuditEvent:
    """审计事件"""
    id: UUID
    timestamp: datetime
    event_type: AuditEventType
    user_id: Optional[str]
    actor: str  # 执行者
    resource: str  # 受影响的资源
    action: str  # 执行的动作
    details: Dict[str, Any] = field(default_factory=dict)
    ip_address: Optional[str] = None
    success: bool = True
    error_message: Optional[str] = None


class AuditTrail:
    """
    审计追踪
    
    记录所有GDPR相关操作
    """
    
    def __init__(self, max_events: int = 100000):
        """
        初始化审计追踪
        
        Args:
            max_events: 最大事件数
        """
        self._events: List[AuditEvent] = []
        self._max_events = max_events
        self._lock = asyncio.Lock()
        logger.info("审计追踪初始化完成")
    
    async def log_event(
        self,
        event_type: AuditEventType,
        actor: str,
        resource: str,
        action: str,
        user_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None,
        success: bool = True,
        error_message: Optional[str] = None
    ) -> AuditEvent:
        """
        记录事件
        
        Args:
            event_type: 事件类型
            actor: 执行者
            resource: 资源
            action: 动作
            user_id: 用户ID
            details: 详情
            ip_address: IP地址
            success: 是否成功
            error_message: 错误信息
            
        Returns:
            审计事件
        """
        event = AuditEvent(
            id=uuid4(),
            timestamp=datetime.utcnow(),
            event_type=event_type,
            user_id=user_id,
            actor=actor,
            resource=resource,
            action=action,
            details=details or {},
            ip_address=ip_address,
            success=success,
            error_message=error_message
        )
        
        async with self._lock:
            self._events.append(event)
            
            # 限制事件数量
            if len(self._events) > self._max_events:
                self._events = self._events[-self._max_events:]
        
        logger.debug(f"审计事件已记录: {event_type.value} - {action}")
        return event
    
    async def query_events(
        self,
        event_type: Optional[AuditEventType] = None,
        user_id: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: int = 100
    ) -> List[AuditEvent]:
        """
        查询事件
        
        Args:
            event_type: 事件类型
            user_id: 用户ID
            start_time: 开始时间
            end_time: 结束时间
            limit: 限制数量
            
        Returns:
            事件列表
        """
        async with self._lock:
            events = self._events.copy()
        
        # 应用过滤
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        
        if user_id:
            events = [e for e in events if e.user_id == user_id]
        
        if start_time:
            events = [e for e in events if e.timestamp >= start_time]
        
        if end_time:
            events = [e for e in events if e.timestamp <= end_time]
        
        # 按时间倒序
        events.sort(key=lambda e: e.timestamp, reverse=True)
        
        return events[:limit]
    
    async def get_user_activity(
        self,
        user_id: str,
        days: int = 30
    ) -> List[AuditEvent]:
        """
        获取用户活动
        
        Args:
            user_id: 用户ID
            days: 天数
            
        Returns:
            事件列表
        """
        start_time = datetime.utcnow() - __import__('datetime').timedelta(days=days)
        return await self.query_events(
            user_id=user_id,
            start_time=start_time,
            limit=1000
        )
    
    async def get_statistics(self, days: int = 30) -> Dict[str, Any]:
        """
        获取统计信息
        
        Args:
            days: 天数
            
        Returns:
            统计数据
        """
        start_time = datetime.utcnow() - __import__('datetime').timedelta(days=days)
        events = await self.query_events(start_time=start_time, limit=100000)
        
        # 按类型统计
        type_counts = {}
        for event in events:
            type_name = event.event_type.value
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
        
        # 成功率统计
        success_count = sum(1 for e in events if e.success)
        
        return {
            "total_events": len(events),
            "success_rate": success_count / len(events) if events else 1.0,
            "event_types": type_counts,
            "period_days": days
        }
    
    async def export_trail(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """
        导出审计追踪
        
        Args:
            start_time: 开始时间
            end_time: 结束时间
            
        Returns:
            事件字典列表
        """
        events = await self.query_events(
            start_time=start_time,
            end_time=end_time,
            limit=100000
        )
        
        return [
            {
                "id": str(e.id),
                "timestamp": e.timestamp.isoformat(),
                "event_type": e.event_type.value,
                "user_id": e.user_id,
                "actor": e.actor,
                "resource": e.resource,
                "action": e.action,
                "details": e.details,
                "ip_address": e.ip_address,
                "success": e.success,
                "error_message": e.error_message
            }
            for e in events
        ]
