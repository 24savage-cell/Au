"""
数据清单管理模块

提供数据资产发现和清单管理功能
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class DataType(Enum):
    """数据类型"""
    PERSONAL = "personal"
    SENSITIVE = "sensitive"
    FINANCIAL = "financial"
    HEALTH = "health"
    BIOMETRIC = "biometric"
    GENETIC = "genetic"
    CONTACT = "contact"
    LOCATION = "location"
    BEHAVIORAL = "behavioral"


class ProcessingPurpose(Enum):
    """处理目的"""
    SERVICE_PROVISION = "service_provision"
    MARKETING = "marketing"
    ANALYTICS = "analytics"
    LEGAL_COMPLIANCE = "legal_compliance"
    FRAUD_PREVENTION = "fraud_prevention"
    RESEARCH = "research"


@dataclass
class DataAsset:
    """数据资产记录"""
    id: UUID
    name: str
    data_type: DataType
    description: str
    storage_location: str
    data_controller: str
    legal_basis: str
    processing_purposes: List[ProcessingPurpose] = field(default_factory=list)
    retention_period_days: int = 365
    encryption_enabled: bool = False
    pseudonymized: bool = False
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = field(default_factory=dict)


class DataInventory:
    """
    数据清单管理器
    
    管理和追踪组织内的所有数据资产
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化数据清单管理器
        
        Args:
            storage_path: 存储路径
        """
        self._assets: Dict[UUID, DataAsset] = {}
        self._lock = asyncio.Lock()
        logger.info("数据清单管理器初始化完成")
    
    async def register_asset(
        self,
        name: str,
        data_type: DataType,
        description: str,
        storage_location: str,
        data_controller: str,
        legal_basis: str,
        processing_purposes: Optional[List[ProcessingPurpose]] = None,
        retention_period_days: int = 365,
        encryption_enabled: bool = False,
        pseudonymized: bool = False,
        metadata: Optional[Dict[str, Any]] = None
    ) -> DataAsset:
        """
        注册数据资产
        
        Args:
            name: 资产名称
            data_type: 数据类型
            description: 描述
            storage_location: 存储位置
            data_controller: 数据控制者
            legal_basis: 法律依据
            processing_purposes: 处理目的列表
            retention_period_days: 保留期限(天)
            encryption_enabled: 是否加密
            pseudonymized: 是否假名化
            metadata: 元数据
            
        Returns:
            数据资产记录
        """
        asset = DataAsset(
            id=uuid4(),
            name=name,
            data_type=data_type,
            description=description,
            storage_location=storage_location,
            data_controller=data_controller,
            legal_basis=legal_basis,
            processing_purposes=processing_purposes or [],
            retention_period_days=retention_period_days,
            encryption_enabled=encryption_enabled,
            pseudonymized=pseudonymized,
            metadata=metadata or {}
        )
        
        async with self._lock:
            self._assets[asset.id] = asset
        
        logger.info(f"数据资产已注册: {name} ({asset.id})")
        return asset
    
    async def get_asset(self, asset_id: UUID) -> Optional[DataAsset]:
        """
        获取数据资产
        
        Args:
            asset_id: 资产ID
            
        Returns:
            数据资产记录
        """
        async with self._lock:
            return self._assets.get(asset_id)
    
    async def update_asset(
        self,
        asset_id: UUID,
        **kwargs
    ) -> Optional[DataAsset]:
        """
        更新数据资产
        
        Args:
            asset_id: 资产ID
            **kwargs: 要更新的字段
            
        Returns:
            更新后的数据资产
        """
        async with self._lock:
            if asset_id not in self._assets:
                return None
            
            asset = self._assets[asset_id]
            for key, value in kwargs.items():
                if hasattr(asset, key):
                    setattr(asset, key, value)
            
            asset.updated_at = datetime.utcnow()
            logger.info(f"数据资产已更新: {asset.name}")
            return asset
    
    async def delete_asset(self, asset_id: UUID) -> bool:
        """
        删除数据资产
        
        Args:
            asset_id: 资产ID
            
        Returns:
            是否删除成功
        """
        async with self._lock:
            if asset_id in self._assets:
                del self._assets[asset_id]
                logger.info(f"数据资产已删除: {asset_id}")
                return True
            return False
    
    async def list_assets(
        self,
        data_type: Optional[DataType] = None,
        data_controller: Optional[str] = None
    ) -> List[DataAsset]:
        """
        列出数据资产
        
        Args:
            data_type: 筛选数据类型
            data_controller: 筛选数据控制者
            
        Returns:
            数据资产列表
        """
        async with self._lock:
            assets = list(self._assets.values())
            
            if data_type:
                assets = [a for a in assets if a.data_type == data_type]
            
            if data_controller:
                assets = [a for a in assets if a.data_controller == data_controller]
            
            return assets
    
    async def get_statistics(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计数据
        """
        async with self._lock:
            total_assets = len(self._assets)
            type_counts = {}
            encrypted_count = 0
            pseudonymized_count = 0
            
            for asset in self._assets.values():
                type_counts[asset.data_type.value] = type_counts.get(asset.data_type.value, 0) + 1
                if asset.encryption_enabled:
                    encrypted_count += 1
                if asset.pseudonymized:
                    pseudonymized_count += 1
            
            return {
                "total_assets": total_assets,
                "type_distribution": type_counts,
                "encrypted_assets": encrypted_count,
                "pseudonymized_assets": pseudonymized_count,
                "encryption_coverage": encrypted_count / total_assets if total_assets > 0 else 0
            }
