"""
数据分类模块

提供自动数据分类和敏感数据识别功能
"""

import asyncio
import logging
import re
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple
from uuid import UUID

logger = logging.getLogger(__name__)


class ClassificationLevel(Enum):
    """分类级别"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    CRITICAL = "critical"


@dataclass
class ClassificationResult:
    """分类结果"""
    level: ClassificationLevel
    confidence: float
    reasons: List[str]
    detected_patterns: List[str]
    recommendations: List[str]


class DataClassifier:
    """
    数据分类器
    
    自动识别和分类敏感数据
    """
    
    # 敏感数据模式
    PATTERNS = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b(?:\+?\d{1,3}[-.]?)?\(?\d{3}\)?[-.]?\d{3}[-.]?\d{4}\b',
        "credit_card": r'\b(?:\d{4}[-\s]?){3}\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "ip_address": r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
        "api_key": r'(?:api[_-]?key|apikey)["\']?\s*[:=]\s*["\']?[a-zA-Z0-9]{32,}["\']?',
        "password": r'(?:password|passwd|pwd)["\']?\s*[:=]\s*["\']?\S+["\']?',
    }
    
    # 分类规则
    CLASSIFICATION_RULES = {
        ClassificationLevel.CRITICAL: {
            "patterns": ["ssn", "credit_card", "api_key"],
            "keywords": ["password", "secret", "private_key", "token"],
            "min_confidence": 0.9
        },
        ClassificationLevel.RESTRICTED: {
            "patterns": ["email", "phone"],
            "keywords": ["personal", "pii", "sensitive"],
            "min_confidence": 0.8
        },
        ClassificationLevel.CONFIDENTIAL: {
            "patterns": ["ip_address"],
            "keywords": ["internal", "proprietary"],
            "min_confidence": 0.7
        }
    }
    
    def __init__(self):
        """初始化数据分类器"""
        self._compiled_patterns = {
            name: re.compile(pattern, re.IGNORECASE)
            for name, pattern in self.PATTERNS.items()
        }
        logger.info("数据分类器初始化完成")
    
    def classify_text(
        self,
        text: str,
        context: Optional[Dict[str, str]] = None
    ) -> ClassificationResult:
        """
        对文本进行分类
        
        Args:
            text: 要分类的文本
            context: 上下文信息
            
        Returns:
            分类结果
        """
        detected_patterns = []
        pattern_counts = {}
        
        # 检测模式
        for pattern_name, pattern in self._compiled_patterns.items():
            matches = pattern.findall(text)
            if matches:
                detected_patterns.append(pattern_name)
                pattern_counts[pattern_name] = len(matches)
        
        # 根据规则确定分类级别
        level = ClassificationLevel.PUBLIC
        confidence = 0.0
        reasons = []
        
        for cls_level, rules in self.CLASSIFICATION_RULES.items():
            matched_patterns = [p for p in detected_patterns if p in rules["patterns"]]
            
            if matched_patterns:
                matched_keywords = []
                if context:
                    for keyword in rules["keywords"]:
                        for ctx_value in context.values():
                            if keyword.lower() in ctx_value.lower():
                                matched_keywords.append(keyword)
                
                # 计算置信度
                pattern_score = len(matched_patterns) / len(rules["patterns"])
                keyword_score = len(matched_keywords) / len(rules["keywords"]) if rules["keywords"] else 0
                calc_confidence = (pattern_score + keyword_score) / 2
                
                if calc_confidence >= rules["min_confidence"] and calc_confidence > confidence:
                    level = cls_level
                    confidence = calc_confidence
                    reasons = [
                        f"检测到敏感模式: {', '.join(matched_patterns)}",
                        f"匹配关键词: {', '.join(matched_keywords)}" if matched_keywords else "无关键词匹配"
                    ]
        
        # 生成建议
        recommendations = self._generate_recommendations(level, detected_patterns)
        
        return ClassificationResult(
            level=level,
            confidence=confidence,
            reasons=reasons,
            detected_patterns=detected_patterns,
            recommendations=recommendations
        )
    
    def _generate_recommendations(
        self,
        level: ClassificationLevel,
        detected_patterns: List[str]
    ) -> List[str]:
        """
        生成安全建议
        
        Args:
            level: 分类级别
            detected_patterns: 检测到的模式
            
        Returns:
            建议列表
        """
        recommendations = []
        
        if level in [ClassificationLevel.CRITICAL, ClassificationLevel.RESTRICTED]:
            recommendations.append("对数据进行加密存储")
            recommendations.append("实施访问控制")
            recommendations.append("启用审计日志")
        
        if "email" in detected_patterns or "phone" in detected_patterns:
            recommendations.append("考虑对联系信息进行假名化处理")
        
        if "credit_card" in detected_patterns:
            recommendations.append("遵循PCI DSS标准处理支付卡数据")
        
        if "api_key" in detected_patterns or "password" in detected_patterns:
            recommendations.append("使用密钥管理系统存储敏感凭证")
        
        return recommendations
    
    async def scan_dataset(
        self,
        dataset_id: UUID,
        sample_size: int = 1000
    ) -> Dict[str, ClassificationResult]:
        """
        扫描数据集
        
        Args:
            dataset_id: 数据集ID
            sample_size: 采样大小
            
        Returns:
            分类结果映射
        """
        # 模拟数据集扫描
        logger.info(f"开始扫描数据集: {dataset_id}")
        
        # 这里应该实际读取数据集
        # 现在返回模拟结果
        return {
            "column_1": ClassificationResult(
                level=ClassificationLevel.INTERNAL,
                confidence=0.6,
                reasons=["未检测到敏感模式"],
                detected_patterns=[],
                recommendations=["定期重新评估分类"]
            )
        }
