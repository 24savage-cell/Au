"""
用户偏好管理模块

管理用户的隐私偏好设置
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class UserPreferences:
    """用户隐私偏好"""
    user_id: str
    marketing_emails: bool = False
    analytics_cookies: bool = False
    personalization: bool = False
    third_party_sharing: bool = False
    location_tracking: bool = False
    data_retention_extended: bool = False
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    custom_preferences: Dict[str, Any] = field(default_factory=dict)


class PreferenceManager:
    """
    偏好管理器
    
    管理用户的隐私偏好设置
    """
    
    def __init__(self):
        """初始化偏好管理器"""
        self._preferences: Dict[str, UserPreferences] = {}
        self._lock = asyncio.Lock()
        logger.info("偏好管理器初始化完成")
    
    async def set_preferences(
        self,
        user_id: str,
        **kwargs
    ) -> UserPreferences:
        """
        设置用户偏好
        
        Args:
            user_id: 用户ID
            **kwargs: 偏好设置
            
        Returns:
            用户偏好
        """
        async with self._lock:
            if user_id in self._preferences:
                prefs = self._preferences[user_id]
                for key, value in kwargs.items():
                    if hasattr(prefs, key):
                        setattr(prefs, key, value)
                prefs.updated_at = datetime.utcnow()
            else:
                prefs = UserPreferences(user_id=user_id, **kwargs)
                self._preferences[user_id] = prefs
        
        logger.info(f"用户偏好已更新: {user_id}")
        return prefs
    
    async def get_preferences(self, user_id: str) -> Optional[UserPreferences]:
        """
        获取用户偏好
        
        Args:
            user_id: 用户ID
            
        Returns:
            用户偏好
        """
        async with self._lock:
            return self._preferences.get(user_id)
    
    async def get_or_create_preferences(self, user_id: str) -> UserPreferences:
        """
        获取或创建用户偏好
        
        Args:
            user_id: 用户ID
            
        Returns:
            用户偏好
        """
        prefs = await self.get_preferences(user_id)
        if prefs is None:
            prefs = await self.set_preferences(user_id)
        return prefs
    
    async def update_preference(
        self,
        user_id: str,
        preference_name: str,
        value: Any
    ) -> bool:
        """
        更新单个偏好
        
        Args:
            user_id: 用户ID
            preference_name: 偏好名称
            value: 偏好值
            
        Returns:
            是否更新成功
        """
        async with self._lock:
            if user_id not in self._preferences:
                self._preferences[user_id] = UserPreferences(user_id=user_id)
            
            prefs = self._preferences[user_id]
            if hasattr(prefs, preference_name):
                setattr(prefs, preference_name, value)
                prefs.updated_at = datetime.utcnow()
                logger.info(f"偏好已更新: {user_id} - {preference_name}")
                return True
            else:
                prefs.custom_preferences[preference_name] = value
                prefs.updated_at = datetime.utcnow()
                return True
    
    async def export_preferences(self, user_id: str) -> Dict[str, Any]:
        """
        导出用户偏好
        
        Args:
            user_id: 用户ID
            
        Returns:
            偏好字典
        """
        prefs = await self.get_preferences(user_id)
        if prefs is None:
            return {}
        
        return {
            "user_id": prefs.user_id,
            "marketing_emails": prefs.marketing_emails,
            "analytics_cookies": prefs.analytics_cookies,
            "personalization": prefs.personalization,
            "third_party_sharing": prefs.third_party_sharing,
            "location_tracking": prefs.location_tracking,
            "data_retention_extended": prefs.data_retention_extended,
            "custom_preferences": prefs.custom_preferences,
            "updated_at": prefs.updated_at.isoformat()
        }
