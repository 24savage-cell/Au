"""同意管理模块"""
from .manager import ConsentManager, ConsentRecord
from .preferences import PreferenceManager, UserPreferences

__all__ = ["ConsentManager", "ConsentRecord", "PreferenceManager", "UserPreferences"]
