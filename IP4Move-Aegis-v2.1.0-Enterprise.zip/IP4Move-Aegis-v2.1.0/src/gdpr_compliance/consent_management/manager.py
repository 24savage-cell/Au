"""
同意管理模块

提供用户同意收集、存储和撤销功能
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import UUID, uuid4

logger = logging.getLogger(__name__)


class ConsentStatus(Enum):
    """同意状态"""
    GRANTED = "granted"
    REVOKED = "revoked"
    EXPIRED = "expired"
    PENDING = "pending"


class ConsentPurpose(Enum):
    """同意目的"""
    MARKETING = "marketing"
    ANALYTICS = "analytics"
    PERSONALIZATION = "personalization"
    THIRD_PARTY_SHARING = "third_party_sharing"
    LOCATION_TRACKING = "location_tracking"
    COOKIES = "cookies"
    EMAIL_COMMUNICATION = "email_communication"


@dataclass
class ConsentRecord:
    """同意记录"""
    id: UUID
    user_id: str
    purpose: ConsentPurpose
    status: ConsentStatus
    granted_at: datetime
    expires_at: Optional[datetime]
    revoked_at: Optional[datetime] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    consent_version: str = "1.0"
    metadata: Dict[str, Any] = field(default_factory=dict)


class ConsentManager:
    """
    同意管理器
    
    管理用户的同意状态和偏好
    """
    
    def __init__(self):
        """初始化同意管理器"""
        self._consents: Dict[UUID, ConsentRecord] = {}
        self._user_consents: Dict[str, Set[UUID]] = {}
        self._lock = asyncio.Lock()
        logger.info("同意管理器初始化完成")
    
    async def record_consent(
        self,
        user_id: str,
        purpose: ConsentPurpose,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        validity_days: Optional[int] = 365,
        metadata: Optional[Dict[str, Any]] = None
    ) -> ConsentRecord:
        """
        记录用户同意
        
        Args:
            user_id: 用户ID
            purpose: 同意目的
            ip_address: IP地址
            user_agent: 用户代理
            validity_days: 有效期(天)
            metadata: 元数据
            
        Returns:
            同意记录
        """
        granted_at = datetime.utcnow()
        expires_at = granted_at + timedelta(days=validity_days) if validity_days else None
        
        consent = ConsentRecord(
            id=uuid4(),
            user_id=user_id,
            purpose=purpose,
            status=ConsentStatus.GRANTED,
            granted_at=granted_at,
            expires_at=expires_at,
            ip_address=ip_address,
            user_agent=user_agent,
            metadata=metadata or {}
        )
        
        async with self._lock:
            self._consents[consent.id] = consent
            if user_id not in self._user_consents:
                self._user_consents[user_id] = set()
            self._user_consents[user_id].add(consent.id)
        
        logger.info(f"同意已记录: {user_id} - {purpose.value}")
        return consent
    
    async def revoke_consent(
        self,
        user_id: str,
        purpose: Optional[ConsentPurpose] = None
    ) -> int:
        """
        撤销用户同意
        
        Args:
            user_id: 用户ID
            purpose: 特定目的(如为None则撤销所有)
            
        Returns:
            撤销的记录数量
        """
        revoked_count = 0
        
        async with self._lock:
            consent_ids = self._user_consents.get(user_id, set())
            
            for consent_id in consent_ids:
                consent = self._consents.get(consent_id)
                if consent and consent.status == ConsentStatus.GRANTED:
                    if purpose is None or consent.purpose == purpose:
                        consent.status = ConsentStatus.REVOKED
                        consent.revoked_at = datetime.utcnow()
                        revoked_count += 1
        
        logger.info(f"同意已撤销: {user_id} - {revoked_count} 条记录")
        return revoked_count
    
    async def check_consent(
        self,
        user_id: str,
        purpose: ConsentPurpose
    ) -> bool:
        """
        检查用户是否同意特定目的
        
        Args:
            user_id: 用户ID
            purpose: 同意目的
            
        Returns:
            是否有有效同意
        """
        async with self._lock:
            consent_ids = self._user_consents.get(user_id, set())
            
            for consent_id in consent_ids:
                consent = self._consents.get(consent_id)
                if consent and consent.purpose == purpose:
                    if consent.status == ConsentStatus.GRANTED:
                        # 检查是否过期
                        if consent.expires_at and consent.expires_at < datetime.utcnow():
                            consent.status = ConsentStatus.EXPIRED
                            return False
                        return True
            
            return False
    
    async def get_user_consents(self, user_id: str) -> List[ConsentRecord]:
        """
        获取用户的所有同意记录
        
        Args:
            user_id: 用户ID
            
        Returns:
            同意记录列表
        """
        async with self._lock:
            consent_ids = self._user_consents.get(user_id, set())
            return [self._consents[cid] for cid in consent_ids if cid in self._consents]
    
    async def get_consent_summary(self, user_id: str) -> Dict[str, Any]:
        """
        获取用户同意摘要
        
        Args:
            user_id: 用户ID
            
        Returns:
            同意摘要
        """
        consents = await self.get_user_consents(user_id)
        
        granted = [c for c in consents if c.status == ConsentStatus.GRANTED]
        revoked = [c for c in consents if c.status == ConsentStatus.REVOKED]
        expired = [c for c in consents if c.status == ConsentStatus.EXPIRED]
        
        return {
            "user_id": user_id,
            "total_consents": len(consents),
            "granted": len(granted),
            "revoked": len(revoked),
            "expired": len(expired),
            "active_purposes": [c.purpose.value for c in granted],
            "last_updated": max((c.granted_at for c in consents), default=None)
        }
