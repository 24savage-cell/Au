"""
消息队列链路追踪模块

提供消息队列操作的链路追踪能力，包括生产/消费追踪和消息传播。
"""

import time
import uuid
from typing import Optional, Dict, Any, List, Tuple, Callable, Union, AsyncIterator
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import logging
from contextlib import asynccontextmanager, contextmanager
from functools import wraps

# 配置日志
logger = logging.getLogger(__name__)


class SpanKind(Enum):
    """Span类型枚举"""
    SERVER = "server"
    CLIENT = "client"
    PRODUCER = "producer"
    CONSUMER = "consumer"
    INTERNAL = "internal"


class SpanStatus(Enum):
    """Span状态枚举"""
    UNSET = 0
    OK = 1
    ERROR = 2


@dataclass
class Span:
    """追踪Span定义"""
    trace_id: str
    span_id: str
    parent_id: Optional[str]
    name: str
    kind: SpanKind
    start_time: int = field(default_factory=lambda: int(time.time() * 1e6))
    end_time: Optional[int] = None
    attributes: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    status: SpanStatus = SpanStatus.UNSET
    status_message: str = ""
    
    def end(self, timestamp: Optional[int] = None) -> None:
        """结束Span"""
        self.end_time = timestamp or int(time.time() * 1e6)
    
    def set_attribute(self, key: str, value: Any) -> None:
        """设置属性"""
        self.attributes[key] = value
    
    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        """批量设置属性"""
        self.attributes.update(attributes)
    
    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        """添加事件"""
        self.events.append({
            "name": name,
            "timestamp": int(time.time() * 1e6),
            "attributes": attributes or {}
        })
    
    def set_status(self, status: SpanStatus, message: str = "") -> None:
        """设置状态"""
        self.status = status
        self.status_message = message
    
    def duration_ms(self) -> float:
        """获取Span持续时间（毫秒）"""
        if self.end_time is None:
            return 0.0
        return (self.end_time - self.start_time) / 1000.0


@dataclass
class MessageContext:
    """消息上下文"""
    trace_id: str
    span_id: str
    message_id: str
    topic: str
    partition: Optional[int] = None
    offset: Optional[int] = None
    headers: Dict[str, str] = field(default_factory=dict)


class MQInstrument:
    """
    消息队列链路追踪器
    
    提供消息队列操作的自动埋点和追踪功能，支持生产/消费追踪。
    
    Example:
        >>> instrument = MQInstrument()
        >>> # 生产者
        >>> span = instrument.start_produce_span("orders", "order-created")
        >>> headers = instrument.inject_context({})
        >>> # 发送消息
        >>> instrument.end_produce_span(span, message_id="msg-123")
        >>> 
        >>> # 消费者
        >>> span = instrument.start_consume_span("orders", headers)
        >>> # 处理消息
        >>> instrument.end_consume_span(span)
    """
    
    # 消息语义约定属性名
    MESSAGING_SYSTEM = "messaging.system"
    MESSAGING_DESTINATION = "messaging.destination"
    MESSAGING_DESTINATION_KIND = "messaging.destination_kind"
    MESSAGING_MESSAGE_ID = "messaging.message_id"
    MESSAGING_MESSAGE_PAYLOAD_SIZE_BYTES = "messaging.message_payload_size_bytes"
    MESSAGING_OPERATION = "messaging.operation"
    
    # Kafka特定属性
    MESSAGING_KAFKA_PARTITION = "messaging.kafka.partition"
    MESSAGING_KAFKA_OFFSET = "messaging.kafka.offset"
    MESSAGING_KAFKA_CONSUMER_GROUP = "messaging.kafka.consumer_group"
    
    # RabbitMQ特定属性
    MESSAGING_RABBITMQ_ROUTING_KEY = "messaging.rabbitmq.routing_key"
    MESSAGING_RABBITMQ_EXCHANGE = "messaging.rabbitmq.exchange"
    
    # RocketMQ特定属性
    MESSAGING_ROCKETMQ_NAMESPACE = "messaging.rocketmq.namespace"
    MESSAGING_ROCKETMQ_CLIENT_GROUP = "messaging.rocketmq.client_group"
    
    def __init__(self, service_name: str = "unknown-service"):
        """
        初始化消息队列追踪器
        
        Args:
            service_name: 服务名称
        """
        self.service_name = service_name
        self._exporters: List[Any] = []
        self._propagator: Optional[Any] = None
        self._current_span: Optional[Span] = None
    
    def add_exporter(self, exporter: Any) -> None:
        """添加导出器"""
        self._exporters.append(exporter)
    
    def set_propagator(self, propagator: Any) -> None:
        """设置传播器"""
        self._propagator = propagator
    
    def _generate_trace_id(self) -> str:
        """生成追踪ID"""
        return uuid.uuid4().hex
    
    def _generate_span_id(self) -> str:
        """生成Span ID"""
        return uuid.uuid4().hex[:16]
    
    def _generate_message_id(self) -> str:
        """生成消息ID"""
        return str(uuid.uuid4())
    
    def start_produce_span(
        self,
        topic: str,
        message_type: Optional[str] = None,
        messaging_system: str = "kafka",
        partition: Optional[int] = None,
        payload_size: Optional[int] = None,
    ) -> Span:
        """
        创建生产者Span
        
        Args:
            topic: 消息主题/队列名
            message_type: 消息类型
            messaging_system: 消息系统 (kafka, rabbitmq, rocketmq等)
            partition: 分区号
            payload_size: 消息体大小（字节）
            
        Returns:
            创建的Span对象
        """
        # 获取当前追踪上下文
        current_span = self._current_span
        trace_id = current_span.trace_id if current_span else self._generate_trace_id()
        parent_id = current_span.span_id if current_span else None
        
        span_name = f"{topic} send"
        if message_type:
            span_name = f"{topic} {message_type} send"
        
        span = Span(
            trace_id=trace_id,
            span_id=self._generate_span_id(),
            parent_id=parent_id,
            name=span_name,
            kind=SpanKind.PRODUCER,
        )
        
        # 设置消息属性
        span.set_attributes({
            self.MESSAGING_SYSTEM: messaging_system,
            self.MESSAGING_DESTINATION: topic,
            self.MESSAGING_DESTINATION_KIND: "topic",
            self.MESSAGING_OPERATION: "send",
        })
        
        if partition is not None:
            span.set_attribute(self.MESSAGING_KAFKA_PARTITION, partition)
        
        if payload_size is not None:
            span.set_attribute(self.MESSAGING_MESSAGE_PAYLOAD_SIZE_BYTES, payload_size)
        
        self._current_span = span
        
        span.add_event("message_produce_start")
        
        logger.debug(f"Started produce span: {span.span_id} for topic: {topic}")
        
        return span
    
    def end_produce_span(
        self,
        span: Span,
        message_id: Optional[str] = None,
        partition: Optional[int] = None,
        offset: Optional[int] = None,
        error: Optional[Exception] = None,
    ) -> None:
        """
        结束生产者Span
        
        Args:
            span: 要结束的Span
            message_id: 消息ID
            partition: 分区号
            offset: 偏移量
            error: 异常信息
        """
        if message_id:
            span.set_attribute(self.MESSAGING_MESSAGE_ID, message_id)
        
        if partition is not None:
            span.set_attribute(self.MESSAGING_KAFKA_PARTITION, partition)
        
        if offset is not None:
            span.set_attribute(self.MESSAGING_KAFKA_OFFSET, offset)
        
        span.end()
        
        # 设置状态
        if error:
            span.set_status(SpanStatus.ERROR, str(error))
        else:
            span.set_status(SpanStatus.OK)
        
        span.add_event("message_produce_end", {
            "message_id": message_id,
            "error": str(error) if error else None,
        })
        
        # 导出Span
        self._export_span(span)
        
        logger.debug(f"Ended produce span: {span.span_id}, duration: {span.duration_ms():.2f}ms")
    
    def start_consume_span(
        self,
        topic: str,
        headers: Optional[Dict[str, str]] = None,
        messaging_system: str = "kafka",
        message_id: Optional[str] = None,
        partition: Optional[int] = None,
        offset: Optional[int] = None,
        consumer_group: Optional[str] = None,
    ) -> Span:
        """
        创建消费者Span
        
        Args:
            topic: 消息主题/队列名
            headers: 消息头（包含追踪上下文）
            messaging_system: 消息系统
            message_id: 消息ID
            partition: 分区号
            offset: 偏移量
            consumer_group: 消费者组
            
        Returns:
            创建的Span对象
        """
        headers = headers or {}
        
        # 从消息头中提取父上下文
        trace_id, parent_span_id = self._extract_parent_context(headers)
        
        if trace_id is None:
            trace_id = self._generate_trace_id()
        
        span = Span(
            trace_id=trace_id,
            span_id=self._generate_span_id(),
            parent_id=parent_span_id,
            name=f"{topic} process",
            kind=SpanKind.CONSUMER,
        )
        
        # 设置消息属性
        span.set_attributes({
            self.MESSAGING_SYSTEM: messaging_system,
            self.MESSAGING_DESTINATION: topic,
            self.MESSAGING_DESTINATION_KIND: "topic",
            self.MESSAGING_OPERATION: "process",
        })
        
        if message_id:
            span.set_attribute(self.MESSAGING_MESSAGE_ID, message_id)
        
        if partition is not None:
            span.set_attribute(self.MESSAGING_KAFKA_PARTITION, partition)
        
        if offset is not None:
            span.set_attribute(self.MESSAGING_KAFKA_OFFSET, offset)
        
        if consumer_group:
            span.set_attribute(self.MESSAGING_KAFKA_CONSUMER_GROUP, consumer_group)
        
        self._current_span = span
        
        span.add_event("message_consume_start", {
            "message_id": message_id,
            "partition": partition,
            "offset": offset,
        })
        
        logger.debug(f"Started consume span: {span.span_id} for topic: {topic}")
        
        return span
    
    def end_consume_span(
        self,
        span: Span,
        error: Optional[Exception] = None,
        processed_successfully: bool = True,
    ) -> None:
        """
        结束消费者Span
        
        Args:
            span: 要结束的Span
            error: 异常信息
            processed_successfully: 是否成功处理
        """
        span.end()
        
        # 设置状态
        if error:
            span.set_status(SpanStatus.ERROR, str(error))
        elif not processed_successfully:
            span.set_status(SpanStatus.ERROR, "Processing failed")
        else:
            span.set_status(SpanStatus.OK)
        
        span.add_event("message_consume_end", {
            "error": str(error) if error else None,
            "success": processed_successfully,
        })
        
        # 导出Span
        self._export_span(span)
        
        logger.debug(f"Ended consume span: {span.span_id}, duration: {span.duration_ms():.2f}ms")
    
    def _extract_parent_context(self, headers: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
        """
        从消息头中提取父上下文
        
        Args:
            headers: 消息头
            
        Returns:
            (trace_id, parent_span_id) 元组
        """
        if self._propagator:
            return self._propagator.extract(headers)
        
        # 从traceparent头提取
        traceparent = headers.get("traceparent")
        if traceparent:
            parts = traceparent.split("-")
            if len(parts) >= 4:
                return parts[1], parts[2]
        
        return None, None
    
    def inject_context(self, headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """
        将追踪上下文注入到消息头
        
        Args:
            headers: 原始消息头
            
        Returns:
            注入追踪上下文后的消息头
        """
        headers = headers or {}
        
        if not self._current_span:
            return headers
        
        if self._propagator:
            return self._propagator.inject(
                headers,
                self._current_span.trace_id,
                self._current_span.span_id
            )
        
        # 默认使用W3C格式
        traceparent = f"00-{self._current_span.trace_id}-{self._current_span.span_id}-01"
        headers["traceparent"] = traceparent
        
        return headers
    
    def _export_span(self, span: Span) -> None:
        """导出Span到所有配置的导出器"""
        for exporter in self._exporters:
            try:
                if asyncio.iscoroutinefunction(exporter.export):
                    asyncio.create_task(exporter.export(span))
                else:
                    exporter.export(span)
            except Exception as e:
                logger.error(f"Failed to export span to {exporter}: {e}")


class MQTracingProducer:
    """
    追踪生产者包装器
    
    包装消息生产者以启用自动追踪。
    """
    
    def __init__(
        self,
        producer: Any,
        instrument: MQInstrument,
        topic: str,
        messaging_system: str = "kafka",
    ):
        """
        初始化追踪生产者
        
        Args:
            producer: 原始生产者
            instrument: 消息队列追踪器
            topic: 主题名
            messaging_system: 消息系统类型
        """
        self._producer = producer
        self._instrument = instrument
        self._topic = topic
        self._messaging_system = messaging_system
    
    async def send(
        self,
        message: Union[str, bytes],
        key: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        partition: Optional[int] = None,
    ) -> Any:
        """
        发送消息并追踪
        
        Args:
            message: 消息内容
            key: 消息键
            headers: 消息头
            partition: 分区号
            
        Returns:
            发送结果
        """
        payload_size = len(message) if isinstance(message, (str, bytes)) else 0
        
        # 创建生产者Span
        span = self._instrument.start_produce_span(
            topic=self._topic,
            messaging_system=self._messaging_system,
            partition=partition,
            payload_size=payload_size,
        )
        
        # 注入追踪上下文
        headers = self._instrument.inject_context(headers or {})
        
        try:
            # 发送消息
            result = await self._producer.send(
                topic=self._topic,
                value=message,
                key=key,
                headers=headers,
                partition=partition,
            )
            
            # 提取消息元数据
            message_id = getattr(result, "offset", None)
            result_partition = getattr(result, "partition", partition)
            offset = getattr(result, "offset", None)
            
            # 结束Span
            self._instrument.end_produce_span(
                span=span,
                message_id=str(message_id) if message_id else None,
                partition=result_partition,
                offset=offset,
            )
            
            return result
            
        except Exception as e:
            self._instrument.end_produce_span(span=span, error=e)
            raise
    
    async def send_batch(self, messages: List[Dict[str, Any]]) -> List[Any]:
        """
        批量发送消息
        
        Args:
            messages: 消息列表，每个消息是包含value, key, headers等的字典
            
        Returns:
            发送结果列表
        """
        results = []
        for msg in messages:
            result = await self.send(
                message=msg["value"],
                key=msg.get("key"),
                headers=msg.get("headers"),
                partition=msg.get("partition"),
            )
            results.append(result)
        return results
    
    def __getattr__(self, name: str) -> Any:
        """委托其他属性到原始生产者"""
        return getattr(self._producer, name)


class MQTracingConsumer:
    """
    追踪消费者包装器
    
    包装消息消费者以启用自动追踪。
    """
    
    def __init__(
        self,
        consumer: Any,
        instrument: MQInstrument,
        topic: str,
        messaging_system: str = "kafka",
        consumer_group: Optional[str] = None,
    ):
        """
        初始化追踪消费者
        
        Args:
            consumer: 原始消费者
            instrument: 消息队列追踪器
            topic: 主题名
            messaging_system: 消息系统类型
            consumer_group: 消费者组
        """
        self._consumer = consumer
        self._instrument = instrument
        self._topic = topic
        self._messaging_system = messaging_system
        self._consumer_group = consumer_group
    
    async def consume(self) -> AsyncIterator[Any]:
        """
        消费消息并追踪
        
        Yields:
            追踪包装后的消息
        """
        async for message in self._consumer:
            # 提取消息元数据
            headers = dict(message.headers) if hasattr(message, "headers") else {}
            message_id = getattr(message, "key", None)
            partition = getattr(message, "partition", None)
            offset = getattr(message, "offset", None)
            
            # 创建消费者Span
            span = self._instrument.start_consume_span(
                topic=self._topic,
                headers=headers,
                messaging_system=self._messaging_system,
                message_id=str(message_id) if message_id else None,
                partition=partition,
                offset=offset,
                consumer_group=self._consumer_group,
            )
            
            # 将Span附加到消息
            message._tracing_span = span
            message._tracing_instrument = self._instrument
            
            yield message
    
    def ack_message(self, message: Any, error: Optional[Exception] = None) -> None:
        """
        确认消息处理完成
        
        Args:
            message: 消息对象
            error: 异常信息（如果有）
        """
        span = getattr(message, "_tracing_span", None)
        instrument = getattr(message, "_tracing_instrument", None)
        
        if span and instrument:
            instrument.end_consume_span(span, error=error)
    
    async def commit(self) -> None:
        """提交偏移量"""
        await self._consumer.commit()
    
    def __getattr__(self, name: str) -> Any:
        """委托其他属性到原始消费者"""
        return getattr(self._consumer, name)


# 便捷函数
def create_mq_instrument(service_name: str = "unknown-service") -> MQInstrument:
    """
    创建消息队列追踪器的工厂函数
    
    Args:
        service_name: 服务名称
        
    Returns:
        消息队列追踪器实例
    """
    return MQInstrument(service_name)