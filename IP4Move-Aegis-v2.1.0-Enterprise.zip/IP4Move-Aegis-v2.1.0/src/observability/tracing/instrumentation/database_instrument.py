"""
数据库链路追踪模块

提供数据库操作的链路追踪能力，包括SQL查询追踪和慢查询检测。
"""

import time
import uuid
import re
from typing import Optional, Dict, Any, List, Tuple, Callable, Union
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import logging
from contextlib import asynccontextmanager, contextmanager
from functools import wraps

# 配置日志
logger = logging.getLogger(__name__)


class SpanKind(Enum):
    """Span类型枚举"""
    SERVER = "server"
    CLIENT = "client"
    PRODUCER = "producer"
    CONSUMER = "consumer"
    INTERNAL = "internal"


class SpanStatus(Enum):
    """Span状态枚举"""
    UNSET = 0
    OK = 1
    ERROR = 2


@dataclass
class Span:
    """追踪Span定义"""
    trace_id: str
    span_id: str
    parent_id: Optional[str]
    name: str
    kind: SpanKind
    start_time: int = field(default_factory=lambda: int(time.time() * 1e6))
    end_time: Optional[int] = None
    attributes: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    status: SpanStatus = SpanStatus.UNSET
    status_message: str = ""
    
    def end(self, timestamp: Optional[int] = None) -> None:
        """结束Span"""
        self.end_time = timestamp or int(time.time() * 1e6)
    
    def set_attribute(self, key: str, value: Any) -> None:
        """设置属性"""
        self.attributes[key] = value
    
    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        """批量设置属性"""
        self.attributes.update(attributes)
    
    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        """添加事件"""
        self.events.append({
            "name": name,
            "timestamp": int(time.time() * 1e6),
            "attributes": attributes or {}
        })
    
    def set_status(self, status: SpanStatus, message: str = "") -> None:
        """设置状态"""
        self.status = status
        self.status_message = message
    
    def duration_ms(self) -> float:
        """获取Span持续时间（毫秒）"""
        if self.end_time is None:
            return 0.0
        return (self.end_time - self.start_time) / 1000.0


@dataclass
class SlowQueryInfo:
    """慢查询信息"""
    sql: str
    duration_ms: float
    threshold_ms: float
    timestamp: float
    parameters: Optional[Tuple] = None
    stack_trace: Optional[str] = None


class DatabaseInstrument:
    """
    数据库链路追踪器
    
    提供数据库操作的自动埋点和追踪功能，支持SQL查询追踪和慢查询检测。
    
    Example:
        >>> instrument = DatabaseInstrument(slow_query_threshold_ms=100)
        >>> span = instrument.start_query_span("SELECT * FROM users", "postgresql")
        >>> # 执行查询
        >>> instrument.end_query_span(span, row_count=10)
    """
    
    # 数据库语义约定属性名
    DB_SYSTEM = "db.system"
    DB_CONNECTION_STRING = "db.connection_string"
    DB_USER = "db.user"
    DB_NAME = "db.name"
    DB_STATEMENT = "db.statement"
    DB_OPERATION = "db.operation"
    DB_SQL_TABLE = "db.sql.table"
    DB_SQL_PARAMETERS = "db.sql.parameters"
    
    # 性能属性
    DB_ROW_COUNT = "db.row_count"
    DB_AFFECTED_ROWS = "db.affected_rows"
    DB_QUERY_DURATION = "db.query_duration_ms"
    
    def __init__(
        self,
        service_name: str = "unknown-service",
        slow_query_threshold_ms: float = 100.0,
        enable_parameter_logging: bool = False,
    ):
        """
        初始化数据库追踪器
        
        Args:
            service_name: 服务名称
            slow_query_threshold_ms: 慢查询阈值（毫秒）
            enable_parameter_logging: 是否启用参数日志（注意：可能包含敏感信息）
        """
        self.service_name = service_name
        self.slow_query_threshold_ms = slow_query_threshold_ms
        self.enable_parameter_logging = enable_parameter_logging
        self._exporters: List[Any] = []
        self._slow_query_handlers: List[Callable[[SlowQueryInfo], None]] = []
        self._query_stats: Dict[str, Dict[str, Any]] = {}
    
    def add_exporter(self, exporter: Any) -> None:
        """添加导出器"""
        self._exporters.append(exporter)
    
    def add_slow_query_handler(self, handler: Callable[[SlowQueryInfo], None]) -> None:
        """添加慢查询处理器"""
        self._slow_query_handlers.append(handler)
    
    def _generate_trace_id(self) -> str:
        """生成追踪ID"""
        return uuid.uuid4().hex
    
    def _generate_span_id(self) -> str:
        """生成Span ID"""
        return uuid.uuid4().hex[:16]
    
    def _extract_table_name(self, sql: str) -> Optional[str]:
        """
        从SQL语句中提取表名
        
        Args:
            sql: SQL语句
            
        Returns:
            表名或None
        """
        # 匹配常见的SQL模式
        patterns = [
            r"FROM\s+(\w+)",
            r"INTO\s+(\w+)",
            r"UPDATE\s+(\w+)",
            r"JOIN\s+(\w+)",
        ]
        
        sql_upper = sql.upper()
        for pattern in patterns:
            match = re.search(pattern, sql_upper)
            if match:
                return match.group(1).lower()
        
        return None
    
    def _extract_operation(self, sql: str) -> str:
        """
        从SQL语句中提取操作类型
        
        Args:
            sql: SQL语句
            
        Returns:
            操作类型 (SELECT, INSERT, UPDATE, DELETE等)
        """
        sql_upper = sql.strip().upper()
        
        operations = ["SELECT", "INSERT", "UPDATE", "DELETE", "CREATE", "DROP", "ALTER"]
        for op in operations:
            if sql_upper.startswith(op):
                return op
        
        return "UNKNOWN"
    
    def _sanitize_sql(self, sql: str) -> str:
        """
        清理SQL语句，移除敏感信息
        
        Args:
            sql: 原始SQL
            
        Returns:
            清理后的SQL
        """
        # 移除多行注释
        sql = re.sub(r"/\*.*?\*/", "", sql, flags=re.DOTALL)
        # 移除单行注释
        sql = re.sub(r"--.*?$", "", sql, flags=re.MULTILINE)
        # 规范化空白字符
        sql = " ".join(sql.split())
        return sql
    
    def start_query_span(
        self,
        sql: str,
        db_system: str,
        db_name: Optional[str] = None,
        db_user: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        parameters: Optional[Tuple] = None,
    ) -> Span:
        """
        创建查询Span
        
        Args:
            sql: SQL语句
            db_system: 数据库系统 (postgresql, mysql, mongodb等)
            db_name: 数据库名称
            db_user: 数据库用户
            host: 数据库主机
            port: 数据库端口
            parameters: SQL参数
            
        Returns:
            创建的Span对象
        """
        # 获取当前追踪上下文
        current_span = self._get_current_span()
        trace_id = current_span.trace_id if current_span else self._generate_trace_id()
        parent_id = current_span.span_id if current_span else None
        
        operation = self._extract_operation(sql)
        table = self._extract_table_name(sql)
        sanitized_sql = self._sanitize_sql(sql)
        
        span = Span(
            trace_id=trace_id,
            span_id=self._generate_span_id(),
            parent_id=parent_id,
            name=f"{operation} {table or 'unknown'}",
            kind=SpanKind.CLIENT,
        )
        
        # 设置数据库属性
        span.set_attributes({
            self.DB_SYSTEM: db_system,
            self.DB_STATEMENT: sanitized_sql,
            self.DB_OPERATION: operation,
        })
        
        if table:
            span.set_attribute(self.DB_SQL_TABLE, table)
        
        if db_name:
            span.set_attribute(self.DB_NAME, db_name)
        
        if db_user:
            span.set_attribute(self.DB_USER, db_user)
        
        if host:
            span.set_attribute("net.peer.name", host)
        if port:
            span.set_attribute("net.peer.port", port)
        
        if parameters and self.enable_parameter_logging:
            # 注意：在生产环境中应谨慎记录参数
            span.set_attribute(self.DB_SQL_PARAMETERS, str(parameters))
        
        span.add_event("query_start", {"sql": sanitized_sql[:100]})
        
        logger.debug(f"Started query span: {span.span_id} for {operation} on {table}")
        
        return span
    
    def end_query_span(
        self,
        span: Span,
        row_count: Optional[int] = None,
        affected_rows: Optional[int] = None,
        error: Optional[Exception] = None,
        parameters: Optional[Tuple] = None,
    ) -> None:
        """
        结束查询Span并记录结果
        
        Args:
            span: 要结束的Span
            row_count: 返回的行数
            affected_rows: 受影响的行数
            error: 异常信息
            parameters: SQL参数（用于慢查询分析）
        """
        span.end()
        duration_ms = span.duration_ms()
        
        span.set_attribute(self.DB_QUERY_DURATION, duration_ms)
        
        if row_count is not None:
            span.set_attribute(self.DB_ROW_COUNT, row_count)
        
        if affected_rows is not None:
            span.set_attribute(self.DB_AFFECTED_ROWS, affected_rows)
        
        # 设置状态
        if error:
            span.set_status(SpanStatus.ERROR, str(error))
        else:
            span.set_status(SpanStatus.OK)
        
        span.add_event("query_end", {
            "duration_ms": duration_ms,
            "row_count": row_count,
            "error": str(error) if error else None,
        })
        
        # 检查是否为慢查询
        if duration_ms >= self.slow_query_threshold_ms:
            self._handle_slow_query(span, duration_ms, parameters)
        
        # 更新统计信息
        self._update_query_stats(span.name, duration_ms, error is not None)
        
        # 导出Span
        self._export_span(span)
        
        logger.debug(f"Ended query span: {span.span_id}, duration: {duration_ms:.2f}ms")
    
    def _handle_slow_query(self, span: Span, duration_ms: float, parameters: Optional[Tuple]) -> None:
        """处理慢查询"""
        sql = span.attributes.get(self.DB_STATEMENT, "")
        
        slow_query_info = SlowQueryInfo(
            sql=sql,
            duration_ms=duration_ms,
            threshold_ms=self.slow_query_threshold_ms,
            timestamp=time.time(),
            parameters=parameters,
        )
        
        logger.warning(f"Slow query detected: {duration_ms:.2f}ms - {sql[:100]}...")
        
        # 调用注册的处理器
        for handler in self._slow_query_handlers:
            try:
                handler(slow_query_info)
            except Exception as e:
                logger.error(f"Slow query handler failed: {e}")
    
    def _update_query_stats(self, query_name: str, duration_ms: float, has_error: bool) -> None:
        """更新查询统计信息"""
        if query_name not in self._query_stats:
            self._query_stats[query_name] = {
                "count": 0,
                "total_duration": 0.0,
                "max_duration": 0.0,
                "min_duration": float('inf'),
                "errors": 0,
            }
        
        stats = self._query_stats[query_name]
        stats["count"] += 1
        stats["total_duration"] += duration_ms
        stats["max_duration"] = max(stats["max_duration"], duration_ms)
        stats["min_duration"] = min(stats["min_duration"], duration_ms)
        if has_error:
            stats["errors"] += 1
    
    def _export_span(self, span: Span) -> None:
        """导出Span到所有配置的导出器"""
        for exporter in self._exporters:
            try:
                if asyncio.iscoroutinefunction(exporter.export):
                    asyncio.create_task(exporter.export(span))
                else:
                    exporter.export(span)
            except Exception as e:
                logger.error(f"Failed to export span to {exporter}: {e}")
    
    def _get_current_span(self) -> Optional[Span]:
        """获取当前Span（从全局上下文）"""
        # 这里应该与HTTP/gRPC追踪器共享上下文
        # 简化实现，实际应使用统一的上下文管理
        return None
    
    def get_query_stats(self) -> Dict[str, Dict[str, Any]]:
        """获取查询统计信息"""
        return self._query_stats.copy()
    
    def reset_stats(self) -> None:
        """重置统计信息"""
        self._query_stats.clear()


class SQLTracer:
    """
    SQL追踪器
    
    用于包装数据库连接/游标，自动追踪所有SQL操作。
    """
    
    def __init__(
        self,
        instrument: DatabaseInstrument,
        db_system: str,
        db_name: Optional[str] = None,
    ):
        """
        初始化SQL追踪器
        
        Args:
            instrument: 数据库追踪器实例
            db_system: 数据库系统类型
            db_name: 数据库名称
        """
        self.instrument = instrument
        self.db_system = db_system
        self.db_name = db_name
    
    def trace_cursor(self, cursor: Any) -> "TracingCursor":
        """
        包装游标以启用追踪
        
        Args:
            cursor: 原始数据库游标
            
        Returns:
            追踪游标
        """
        return TracingCursor(cursor, self.instrument, self.db_system, self.db_name)
    
    def trace_connection(self, connection: Any) -> "TracingConnection":
        """
        包装连接以启用追踪
        
        Args:
            connection: 原始数据库连接
            
        Returns:
            追踪连接
        """
        return TracingConnection(connection, self.instrument, self.db_system, self.db_name)


class TracingCursor:
    """追踪游标包装器"""
    
    def __init__(
        self,
        cursor: Any,
        instrument: DatabaseInstrument,
        db_system: str,
        db_name: Optional[str] = None,
    ):
        self._cursor = cursor
        self._instrument = instrument
        self._db_system = db_system
        self._db_name = db_name
    
    def execute(self, sql: str, parameters: Optional[Tuple] = None) -> Any:
        """执行SQL并追踪"""
        span = self._instrument.start_query_span(
            sql=sql,
            db_system=self._db_system,
            db_name=self._db_name,
            parameters=parameters,
        )
        
        try:
            result = self._cursor.execute(sql, parameters or ())
            
            # 尝试获取行数
            row_count = getattr(self._cursor, "rowcount", None)
            
            self._instrument.end_query_span(
                span=span,
                affected_rows=row_count,
                parameters=parameters,
            )
            
            return result
            
        except Exception as e:
            self._instrument.end_query_span(
                span=span,
                error=e,
                parameters=parameters,
            )
            raise
    
    def executemany(self, sql: str, parameters_list: List[Tuple]) -> Any:
        """批量执行SQL并追踪"""
        span = self._instrument.start_query_span(
            sql=sql,
            db_system=self._db_system,
            db_name=self._db_name,
        )
        
        try:
            result = self._cursor.executemany(sql, parameters_list)
            row_count = getattr(self._cursor, "rowcount", None)
            
            self._instrument.end_query_span(
                span=span,
                affected_rows=row_count,
            )
            
            return result
            
        except Exception as e:
            self._instrument.end_query_span(span=span, error=e)
            raise
    
    def fetchall(self) -> List[Any]:
        """获取所有结果"""
        return self._cursor.fetchall()
    
    def fetchone(self) -> Any:
        """获取单行结果"""
        return self._cursor.fetchone()
    
    def fetchmany(self, size: int = 0) -> List[Any]:
        """获取多行结果"""
        return self._cursor.fetchmany(size)
    
    def __getattr__(self, name: str) -> Any:
        """委托其他属性到原始游标"""
        return getattr(self._cursor, name)
    
    def __enter__(self) -> "TracingCursor":
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self._cursor.close()


class TracingConnection:
    """追踪连接包装器"""
    
    def __init__(
        self,
        connection: Any,
        instrument: DatabaseInstrument,
        db_system: str,
        db_name: Optional[str] = None,
    ):
        self._connection = connection
        self._instrument = instrument
        self._db_system = db_system
        self._db_name = db_name
    
    def cursor(self) -> TracingCursor:
        """获取追踪游标"""
        cursor = self._connection.cursor()
        return TracingCursor(
            cursor,
            self._instrument,
            self._db_system,
            self._db_name,
        )
    
    def execute(self, sql: str, parameters: Optional[Tuple] = None) -> Any:
        """直接执行SQL"""
        with self.cursor() as cursor:
            return cursor.execute(sql, parameters)
    
    def commit(self) -> None:
        """提交事务"""
        self._connection.commit()
    
    def rollback(self) -> None:
        """回滚事务"""
        self._connection.rollback()
    
    def close(self) -> None:
        """关闭连接"""
        self._connection.close()
    
    def __getattr__(self, name: str) -> Any:
        """委托其他属性到原始连接"""
        return getattr(self._connection, name)
    
    def __enter__(self) -> "TracingConnection":
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type:
            self.rollback()
        else:
            self.commit()
        self.close()


def trace_sql(
    instrument: DatabaseInstrument,
    db_system: str,
    db_name: Optional[str] = None,
) -> Callable:
    """
    SQL追踪装饰器
    
    用于装饰执行SQL的函数。
    
    Example:
        >>> @trace_sql(instrument, "postgresql", "mydb")
        >>> def get_users(conn):
        >>>     return conn.execute("SELECT * FROM users")
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 这里简化实现，实际应从函数中提取SQL
            return func(*args, **kwargs)
        return wrapper
    return decorator


# 便捷函数
def create_database_instrument(
    service_name: str = "unknown-service",
    slow_query_threshold_ms: float = 100.0,
) -> DatabaseInstrument:
    """
    创建数据库追踪器的工厂函数
    
    Args:
        service_name: 服务名称
        slow_query_threshold_ms: 慢查询阈值
        
    Returns:
        数据库追踪器实例
    """
    return DatabaseInstrument(service_name, slow_query_threshold_ms)