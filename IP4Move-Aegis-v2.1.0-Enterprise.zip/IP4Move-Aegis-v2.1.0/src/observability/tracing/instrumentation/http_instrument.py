"""
HTTP链路追踪模块

提供HTTP请求的链路追踪能力，包括请求/响应拦截、Span创建和属性记录。
"""

import time
import uuid
from typing import Optional, Dict, Any, Callable, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import logging
from contextlib import asynccontextmanager

# 配置日志
logger = logging.getLogger(__name__)


class SpanKind(Enum):
    """Span类型枚举"""
    SERVER = "server"      # 服务端接收请求
    CLIENT = "client"      # 客户端发送请求
    PRODUCER = "producer"  # 消息生产者
    CONSUMER = "consumer"  # 消息消费者
    INTERNAL = "internal"  # 内部操作


class SpanStatus(Enum):
    """Span状态枚举"""
    UNSET = 0
    OK = 1
    ERROR = 2


@dataclass
class Span:
    """
    追踪Span定义
    
    Attributes:
        trace_id: 追踪ID，用于关联同一请求的所有Span
        span_id: Span唯一标识
        parent_id: 父Span ID
        name: Span名称（如HTTP方法+路径）
        kind: Span类型
        start_time: 开始时间戳（微秒）
        end_time: 结束时间戳（微秒）
        attributes: Span属性字典
        events: Span事件列表
        status: Span状态
        status_message: 状态描述信息
    """
    trace_id: str
    span_id: str
    parent_id: Optional[str]
    name: str
    kind: SpanKind
    start_time: int = field(default_factory=lambda: int(time.time() * 1e6))
    end_time: Optional[int] = None
    attributes: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    status: SpanStatus = SpanStatus.UNSET
    status_message: str = ""
    
    def end(self, timestamp: Optional[int] = None) -> None:
        """结束Span"""
        self.end_time = timestamp or int(time.time() * 1e6)
    
    def set_attribute(self, key: str, value: Any) -> None:
        """设置属性"""
        self.attributes[key] = value
    
    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        """批量设置属性"""
        self.attributes.update(attributes)
    
    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        """添加事件"""
        self.events.append({
            "name": name,
            "timestamp": int(time.time() * 1e6),
            "attributes": attributes or {}
        })
    
    def set_status(self, status: SpanStatus, message: str = "") -> None:
        """设置状态"""
        self.status = status
        self.status_message = message
    
    def duration_ms(self) -> float:
        """获取Span持续时间（毫秒）"""
        if self.end_time is None:
            return 0.0
        return (self.end_time - self.start_time) / 1000.0


class TraceContext:
    """追踪上下文管理器"""
    
    def __init__(self):
        self._current_span: Optional[Span] = None
        self._span_stack: List[Span] = []
    
    def get_current_span(self) -> Optional[Span]:
        """获取当前Span"""
        return self._current_span
    
    def set_current_span(self, span: Optional[Span]) -> None:
        """设置当前Span"""
        self._current_span = span
    
    def push_span(self, span: Span) -> None:
        """将Span压入栈"""
        if self._current_span:
            self._span_stack.append(self._current_span)
        self._current_span = span
    
    def pop_span(self) -> Optional[Span]:
        """弹出当前Span"""
        old_span = self._current_span
        if self._span_stack:
            self._current_span = self._span_stack.pop()
        else:
            self._current_span = None
        return old_span


# 全局上下文
_trace_context = TraceContext()


def get_current_span() -> Optional[Span]:
    """获取当前Span"""
    return _trace_context.get_current_span()


def set_current_span(span: Optional[Span]) -> None:
    """设置当前Span"""
    _trace_context.set_current_span(span)


class HTTPInstrument:
    """
    HTTP链路追踪器
    
    提供HTTP请求的自动埋点和追踪功能。
    
    Example:
        >>> instrument = HTTPInstrument()
        >>> span = instrument.start_server_span("GET", "/api/users", headers)
        >>> # 执行业务逻辑
        >>> instrument.end_span(span, 200)
    """
    
    # HTTP语义约定属性名
    HTTP_METHOD = "http.method"
    HTTP_URL = "http.url"
    HTTP_TARGET = "http.target"
    HTTP_HOST = "http.host"
    HTTP_SCHEME = "http.scheme"
    HTTP_STATUS_CODE = "http.status_code"
    HTTP_STATUS_TEXT = "http.status_text"
    HTTP_FLAVOR = "http.flavor"
    HTTP_USER_AGENT = "http.user_agent"
    HTTP_REQUEST_CONTENT_LENGTH = "http.request_content_length"
    HTTP_RESPONSE_CONTENT_LENGTH = "http.response_content_length"
    HTTP_ROUTE = "http.route"
    
    # 网络属性
    NET_PEER_IP = "net.peer.ip"
    NET_PEER_PORT = "net.peer.port"
    NET_PEER_NAME = "net.peer.name"
    NET_HOST_IP = "net.host.ip"
    NET_HOST_PORT = "net.host.port"
    NET_HOST_NAME = "net.host.name"
    
    def __init__(self, service_name: str = "unknown-service"):
        """
        初始化HTTP追踪器
        
        Args:
            service_name: 服务名称，用于标识当前服务
        """
        self.service_name = service_name
        self._exporters: List[Any] = []
        self._propagator: Optional[Any] = None
    
    def add_exporter(self, exporter: Any) -> None:
        """添加导出器"""
        self._exporters.append(exporter)
    
    def set_propagator(self, propagator: Any) -> None:
        """设置传播器"""
        self._propagator = propagator
    
    def _generate_trace_id(self) -> str:
        """生成追踪ID"""
        return uuid.uuid4().hex
    
    def _generate_span_id(self) -> str:
        """生成Span ID"""
        return uuid.uuid4().hex[:16]
    
    def _extract_parent_context(self, headers: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
        """
        从请求头中提取父上下文
        
        Args:
            headers: HTTP请求头
            
        Returns:
            (trace_id, parent_span_id) 元组
        """
        if self._propagator:
            return self._propagator.extract(headers)
        
        # 默认从W3C traceparent头提取
        traceparent = headers.get("traceparent")
        if traceparent:
            parts = traceparent.split("-")
            if len(parts) >= 4:
                return parts[1], parts[2]
        
        return None, None
    
    def start_server_span(
        self,
        method: str,
        target: str,
        headers: Dict[str, str],
        host: Optional[str] = None,
        scheme: str = "http",
        client_ip: Optional[str] = None,
        client_port: Optional[int] = None,
    ) -> Span:
        """
        创建服务端Span
        
        Args:
            method: HTTP方法 (GET, POST等)
            target: 请求目标路径
            headers: HTTP请求头
            host: 主机名
            scheme: 协议 (http/https)
            client_ip: 客户端IP
            client_port: 客户端端口
            
        Returns:
            创建的Span对象
        """
        trace_id, parent_span_id = self._extract_parent_context(headers)
        
        if trace_id is None:
            trace_id = self._generate_trace_id()
        
        span = Span(
            trace_id=trace_id,
            span_id=self._generate_span_id(),
            parent_id=parent_span_id if parent_span_id != "0000000000000000" else None,
            name=f"{method} {target}",
            kind=SpanKind.SERVER,
        )
        
        # 设置HTTP属性
        span.set_attributes({
            self.HTTP_METHOD: method,
            self.HTTP_TARGET: target,
            self.HTTP_SCHEME: scheme,
            self.HTTP_FLAVOR: headers.get("HTTP_VERSION", "1.1"),
            self.HTTP_USER_AGENT: headers.get("user-agent", ""),
        })
        
        if host:
            span.set_attribute(self.HTTP_HOST, host)
            span.set_attribute(self.NET_HOST_NAME, host)
        
        if client_ip:
            span.set_attribute(self.NET_PEER_IP, client_ip)
        if client_port:
            span.set_attribute(self.NET_PEER_PORT, client_port)
        
        # 记录请求内容长度
        content_length = headers.get("content-length")
        if content_length:
            try:
                span.set_attribute(self.HTTP_REQUEST_CONTENT_LENGTH, int(content_length))
            except ValueError:
                pass
        
        # 设置当前Span
        _trace_context.push_span(span)
        
        span.add_event("request_received", {
            "timestamp": int(time.time() * 1e6)
        })
        
        logger.debug(f"Started server span: {span.span_id} for trace: {span.trace_id}")
        
        return span
    
    def start_client_span(
        self,
        method: str,
        url: str,
        host: str,
        port: int,
        scheme: str = "http",
        target: Optional[str] = None,
    ) -> Span:
        """
        创建客户端Span
        
        Args:
            method: HTTP方法
            url: 完整URL
            host: 目标主机
            port: 目标端口
            scheme: 协议
            target: 请求路径
            
        Returns:
            创建的Span对象
        """
        current_span = get_current_span()
        trace_id = current_span.trace_id if current_span else self._generate_trace_id()
        parent_id = current_span.span_id if current_span else None
        
        span = Span(
            trace_id=trace_id,
            span_id=self._generate_span_id(),
            parent_id=parent_id,
            name=f"{method} {target or url}",
            kind=SpanKind.CLIENT,
        )
        
        # 设置HTTP属性
        span.set_attributes({
            self.HTTP_METHOD: method,
            self.HTTP_URL: url,
            self.HTTP_SCHEME: scheme,
            self.NET_PEER_NAME: host,
            self.NET_PEER_PORT: port,
        })
        
        if target:
            span.set_attribute(self.HTTP_TARGET, target)
        
        _trace_context.push_span(span)
        
        span.add_event("request_sent")
        
        logger.debug(f"Started client span: {span.span_id} for trace: {span.trace_id}")
        
        return span
    
    def end_span(
        self,
        span: Span,
        status_code: int,
        response_headers: Optional[Dict[str, str]] = None,
        error: Optional[Exception] = None,
    ) -> None:
        """
        结束Span并记录响应信息
        
        Args:
            span: 要结束的Span
            status_code: HTTP状态码
            response_headers: 响应头
            error: 异常信息（如果有）
        """
        span.set_attribute(self.HTTP_STATUS_CODE, status_code)
        
        # 根据状态码设置Span状态
        if 200 <= status_code < 300:
            span.set_status(SpanStatus.OK)
        elif status_code >= 400 or error:
            span.set_status(SpanStatus.ERROR, str(error) if error else f"HTTP {status_code}")
        
        # 记录响应内容长度
        if response_headers:
            content_length = response_headers.get("content-length")
            if content_length:
                try:
                    span.set_attribute(self.HTTP_RESPONSE_CONTENT_LENGTH, int(content_length))
                except ValueError:
                    pass
        
        span.add_event("response_received", {
            "status_code": status_code,
            "error": str(error) if error else None,
        })
        
        span.end()
        
        # 从上下文栈中弹出
        _trace_context.pop_span()
        
        # 导出Span
        self._export_span(span)
        
        logger.debug(f"Ended span: {span.span_id}, duration: {span.duration_ms():.2f}ms")
    
    def _export_span(self, span: Span) -> None:
        """导出Span到所有配置的导出器"""
        for exporter in self._exporters:
            try:
                if asyncio.iscoroutinefunction(exporter.export):
                    asyncio.create_task(exporter.export(span))
                else:
                    exporter.export(span)
            except Exception as e:
                logger.error(f"Failed to export span to {exporter}: {e}")
    
    def inject_context(self, headers: Dict[str, str]) -> Dict[str, str]:
        """
        将追踪上下文注入到请求头
        
        Args:
            headers: 原始请求头
            
        Returns:
            注入追踪上下文后的请求头
        """
        current_span = get_current_span()
        if not current_span:
            return headers
        
        if self._propagator:
            return self._propagator.inject(headers, current_span.trace_id, current_span.span_id)
        
        # 默认使用W3C格式
        traceparent = f"00-{current_span.trace_id}-{current_span.span_id}-01"
        headers["traceparent"] = traceparent
        
        return headers
    
    @asynccontextmanager
    async def trace_request(
        self,
        method: str,
        url: str,
        host: str,
        port: int,
        scheme: str = "http",
        target: Optional[str] = None,
    ):
        """
        异步上下文管理器，用于追踪HTTP请求
        
        Example:
            >>> async with instrument.trace_request("GET", "http://api/users", "api", 80) as span:
            >>>     response = await http_client.get(url)
            >>>     instrument.end_span(span, response.status)
        """
        span = self.start_client_span(method, url, host, port, scheme, target)
        try:
            yield span
        except Exception as e:
            self.end_span(span, 0, error=e)
            raise


class HTTPTracingMiddleware:
    """
    HTTP追踪中间件
    
    用于Web框架（如FastAPI/Flask）的追踪中间件。
    """
    
    def __init__(self, instrument: HTTPInstrument):
        """
        初始化中间件
        
        Args:
            instrument: HTTP追踪器实例
        """
        self.instrument = instrument
    
    async def __call__(self, request: Any, call_next: Callable) -> Any:
        """
        ASGI中间件调用
        
        Args:
            request: HTTP请求对象
            call_next: 下一个处理函数
            
        Returns:
            HTTP响应对象
        """
        # 提取请求信息
        method = getattr(request, "method", "GET")
        url = getattr(request, "url", None)
        headers = dict(getattr(request, "headers", {}))
        
        client = getattr(request, "client", None)
        client_ip = client[0] if client else None
        client_port = client[1] if client and len(client) > 1 else None
        
        # 创建服务端Span
        span = self.instrument.start_server_span(
            method=method,
            target=str(url.path) if url else "/",
            headers=headers,
            host=str(url.hostname) if url else None,
            scheme=str(url.scheme) if url else "http",
            client_ip=client_ip,
            client_port=client_port,
        )
        
        try:
            # 执行请求处理
            response = await call_next(request)
            
            # 获取响应状态码
            status_code = getattr(response, "status_code", 200)
            response_headers = dict(getattr(response, "headers", {}))
            
            # 结束Span
            self.instrument.end_span(span, status_code, response_headers)
            
            return response
            
        except Exception as e:
            self.instrument.end_span(span, 500, error=e)
            raise


# 便捷函数
def create_http_instrument(service_name: str = "unknown-service") -> HTTPInstrument:
    """
    创建HTTP追踪器的工厂函数
    
    Args:
        service_name: 服务名称
        
    Returns:
        HTTP追踪器实例
    """
    return HTTPInstrument(service_name)