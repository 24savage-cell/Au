"""
gRPC链路追踪模块

提供gRPC调用的链路追踪能力，包括拦截器实现和元数据传播。
"""

import time
import uuid
from typing import Optional, Dict, Any, List, Callable, Tuple, Iterator
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import logging
from contextlib import asynccontextmanager

# 配置日志
logger = logging.getLogger(__name__)


class GRPCStatusCode(Enum):
    """gRPC状态码"""
    OK = 0
    CANCELLED = 1
    UNKNOWN = 2
    INVALID_ARGUMENT = 3
    DEADLINE_EXCEEDED = 4
    NOT_FOUND = 5
    ALREADY_EXISTS = 6
    PERMISSION_DENIED = 7
    RESOURCE_EXHAUSTED = 8
    FAILED_PRECONDITION = 9
    ABORTED = 10
    OUT_OF_RANGE = 11
    UNIMPLEMENTED = 12
    INTERNAL = 13
    UNAVAILABLE = 14
    DATA_LOSS = 15
    UNAUTHENTICATED = 16


class SpanKind(Enum):
    """Span类型枚举"""
    SERVER = "server"
    CLIENT = "client"
    PRODUCER = "producer"
    CONSUMER = "consumer"
    INTERNAL = "internal"


class SpanStatus(Enum):
    """Span状态枚举"""
    UNSET = 0
    OK = 1
    ERROR = 2


@dataclass
class Span:
    """追踪Span定义"""
    trace_id: str
    span_id: str
    parent_id: Optional[str]
    name: str
    kind: SpanKind
    start_time: int = field(default_factory=lambda: int(time.time() * 1e6))
    end_time: Optional[int] = None
    attributes: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    status: SpanStatus = SpanStatus.UNSET
    status_message: str = ""
    
    def end(self, timestamp: Optional[int] = None) -> None:
        """结束Span"""
        self.end_time = timestamp or int(time.time() * 1e6)
    
    def set_attribute(self, key: str, value: Any) -> None:
        """设置属性"""
        self.attributes[key] = value
    
    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        """批量设置属性"""
        self.attributes.update(attributes)
    
    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        """添加事件"""
        self.events.append({
            "name": name,
            "timestamp": int(time.time() * 1e6),
            "attributes": attributes or {}
        })
    
    def set_status(self, status: SpanStatus, message: str = "") -> None:
        """设置状态"""
        self.status = status
        self.status_message = message
    
    def duration_ms(self) -> float:
        """获取Span持续时间（毫秒）"""
        if self.end_time is None:
            return 0.0
        return (self.end_time - self.start_time) / 1000.0


class TraceContext:
    """追踪上下文管理器"""
    
    def __init__(self):
        self._current_span: Optional[Span] = None
        self._span_stack: List[Span] = []
    
    def get_current_span(self) -> Optional[Span]:
        """获取当前Span"""
        return self._current_span
    
    def set_current_span(self, span: Optional[Span]) -> None:
        """设置当前Span"""
        self._current_span = span
    
    def push_span(self, span: Span) -> None:
        """将Span压入栈"""
        if self._current_span:
            self._span_stack.append(self._current_span)
        self._current_span = span
    
    def pop_span(self) -> Optional[Span]:
        """弹出当前Span"""
        old_span = self._current_span
        if self._span_stack:
            self._current_span = self._span_stack.pop()
        else:
            self._current_span = None
        return old_span


# 全局上下文
_trace_context = TraceContext()


def get_current_span() -> Optional[Span]:
    """获取当前Span"""
    return _trace_context.get_current_span()


class GRPCInstrument:
    """
    gRPC链路追踪器
    
    提供gRPC调用的自动埋点和追踪功能。
    
    Example:
        >>> instrument = GRPCInstrument()
        >>> span = instrument.start_server_span("/service/method", metadata)
        >>> # 执行业务逻辑
        >>> instrument.end_span(span, GRPCStatusCode.OK)
    """
    
    # RPC语义约定属性名
    RPC_SYSTEM = "rpc.system"
    RPC_SERVICE = "rpc.service"
    RPC_METHOD = "rpc.method"
    RPC_GRPC_STATUS_CODE = "rpc.grpc.status_code"
    RPC_GRPC_MESSAGE = "rpc.grpc.message"
    
    # gRPC特定属性
    GRPC_METHOD_TYPE = "grpc.method_type"  # unary, streaming
    GRPC_REQUEST_METADATA = "grpc.request_metadata"
    GRPC_RESPONSE_METADATA = "grpc.response_metadata"
    GRPC_DEADLINE = "grpc.deadline"
    
    def __init__(self, service_name: str = "unknown-service"):
        """
        初始化gRPC追踪器
        
        Args:
            service_name: 服务名称
        """
        self.service_name = service_name
        self._exporters: List[Any] = []
        self._propagator: Optional[Any] = None
    
    def add_exporter(self, exporter: Any) -> None:
        """添加导出器"""
        self._exporters.append(exporter)
    
    def set_propagator(self, propagator: Any) -> None:
        """设置传播器"""
        self._propagator = propagator
    
    def _generate_trace_id(self) -> str:
        """生成追踪ID"""
        return uuid.uuid4().hex
    
    def _generate_span_id(self) -> str:
        """生成Span ID"""
        return uuid.uuid4().hex[:16]
    
    def _parse_method(self, method: str) -> Tuple[str, str]:
        """
        解析gRPC方法名
        
        Args:
            method: 完整方法名 (如 "/service/method")
            
        Returns:
            (service_name, method_name) 元组
        """
        parts = method.strip("/").split("/")
        if len(parts) >= 2:
            return parts[0], parts[1]
        return method, ""
    
    def _extract_parent_context(self, metadata: List[Tuple[str, str]]) -> Tuple[Optional[str], Optional[str]]:
        """
        从gRPC元数据中提取父上下文
        
        Args:
            metadata: gRPC元数据列表 [(key, value), ...]
            
        Returns:
            (trace_id, parent_span_id) 元组
        """
        metadata_dict = dict(metadata)
        
        if self._propagator:
            return self._propagator.extract(metadata_dict)
        
        # 从traceparent元数据提取
        traceparent = metadata_dict.get("traceparent")
        if traceparent:
            parts = traceparent.split("-")
            if len(parts) >= 4:
                return parts[1], parts[2]
        
        return None, None
    
    def start_server_span(
        self,
        method: str,
        metadata: List[Tuple[str, str]],
        peer: Optional[str] = None,
        deadline: Optional[float] = None,
    ) -> Span:
        """
        创建服务端Span
        
        Args:
            method: gRPC方法名
            metadata: 请求元数据
            peer: 客户端地址
            deadline: 请求截止时间
            
        Returns:
            创建的Span对象
        """
        trace_id, parent_span_id = self._extract_parent_context(metadata)
        
        if trace_id is None:
            trace_id = self._generate_trace_id()
        
        service_name, method_name = self._parse_method(method)
        
        span = Span(
            trace_id=trace_id,
            span_id=self._generate_span_id(),
            parent_id=parent_span_id if parent_span_id != "0000000000000000" else None,
            name=method,
            kind=SpanKind.SERVER,
        )
        
        # 设置RPC属性
        span.set_attributes({
            self.RPC_SYSTEM: "grpc",
            self.RPC_SERVICE: service_name,
            self.RPC_METHOD: method_name,
        })
        
        # 记录元数据（排除敏感信息）
        safe_metadata = [(k, v) for k, v in metadata if k not in ["authorization", "cookie"]]
        if safe_metadata:
            span.set_attribute(self.GRPC_REQUEST_METADATA, dict(safe_metadata))
        
        if peer:
            span.set_attribute("net.peer.name", peer)
        
        if deadline:
            span.set_attribute(self.GRPC_DEADLINE, deadline)
        
        _trace_context.push_span(span)
        
        span.add_event("request_received")
        
        logger.debug(f"Started gRPC server span: {span.span_id} for method: {method}")
        
        return span
    
    def start_client_span(
        self,
        method: str,
        host: str,
        port: int,
        deadline: Optional[float] = None,
    ) -> Span:
        """
        创建客户端Span
        
        Args:
            method: gRPC方法名
            host: 目标主机
            port: 目标端口
            deadline: 请求截止时间
            
        Returns:
            创建的Span对象
        """
        current_span = get_current_span()
        trace_id = current_span.trace_id if current_span else self._generate_trace_id()
        parent_id = current_span.span_id if current_span else None
        
        service_name, method_name = self._parse_method(method)
        
        span = Span(
            trace_id=trace_id,
            span_id=self._generate_span_id(),
            parent_id=parent_id,
            name=method,
            kind=SpanKind.CLIENT,
        )
        
        # 设置RPC属性
        span.set_attributes({
            self.RPC_SYSTEM: "grpc",
            self.RPC_SERVICE: service_name,
            self.RPC_METHOD: method_name,
            "net.peer.name": host,
            "net.peer.port": port,
        })
        
        if deadline:
            span.set_attribute(self.GRPC_DEADLINE, deadline)
        
        _trace_context.push_span(span)
        
        span.add_event("request_sent")
        
        logger.debug(f"Started gRPC client span: {span.span_id} for method: {method}")
        
        return span
    
    def end_span(
        self,
        span: Span,
        status_code: GRPCStatusCode,
        response_metadata: Optional[List[Tuple[str, str]]] = None,
        error: Optional[Exception] = None,
    ) -> None:
        """
        结束Span并记录响应信息
        
        Args:
            span: 要结束的Span
            status_code: gRPC状态码
            response_metadata: 响应元数据
            error: 异常信息
        """
        span.set_attribute(self.RPC_GRPC_STATUS_CODE, status_code.value)
        
        # 根据状态码设置Span状态
        if status_code == GRPCStatusCode.OK:
            span.set_status(SpanStatus.OK)
        else:
            span.set_status(SpanStatus.ERROR, status_code.name)
            span.set_attribute(self.RPC_GRPC_MESSAGE, status_code.name)
        
        if error:
            span.set_status(SpanStatus.ERROR, str(error))
        
        # 记录响应元数据
        if response_metadata:
            safe_metadata = [(k, v) for k, v in response_metadata if k not in ["authorization", "cookie"]]
            if safe_metadata:
                span.set_attribute(self.GRPC_RESPONSE_METADATA, dict(safe_metadata))
        
        span.add_event("response_received", {
            "status_code": status_code.value,
            "error": str(error) if error else None,
        })
        
        span.end()
        
        _trace_context.pop_span()
        
        # 导出Span
        self._export_span(span)
        
        logger.debug(f"Ended gRPC span: {span.span_id}, duration: {span.duration_ms():.2f}ms")
    
    def _export_span(self, span: Span) -> None:
        """导出Span到所有配置的导出器"""
        for exporter in self._exporters:
            try:
                if asyncio.iscoroutinefunction(exporter.export):
                    asyncio.create_task(exporter.export(span))
                else:
                    exporter.export(span)
            except Exception as e:
                logger.error(f"Failed to export span to {exporter}: {e}")
    
    def inject_context(self, metadata: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
        """
        将追踪上下文注入到gRPC元数据
        
        Args:
            metadata: 原始元数据
            
        Returns:
            注入追踪上下文后的元数据
        """
        current_span = get_current_span()
        if not current_span:
            return metadata
        
        metadata_dict = dict(metadata)
        
        if self._propagator:
            metadata_dict = self._propagator.inject(
                metadata_dict,
                current_span.trace_id,
                current_span.span_id
            )
        else:
            # 默认使用W3C格式
            traceparent = f"00-{current_span.trace_id}-{current_span.span_id}-01"
            metadata_dict["traceparent"] = traceparent
        
        return list(metadata_dict.items())


class TracingInterceptor:
    """
    gRPC追踪拦截器
    
    用于在gRPC服务端和客户端自动创建和结束Span。
    """
    
    def __init__(self, instrument: GRPCInstrument):
        """
        初始化拦截器
        
        Args:
            instrument: gRPC追踪器实例
        """
        self.instrument = instrument
    
    async def intercept_service(self, continuation, handler_call_details):
        """
        服务端拦截器
        
        Args:
            continuation: 继续处理函数
            handler_call_details: 调用详情
            
        Returns:
            处理结果
        """
        method = handler_call_details.method
        
        # 创建服务端Span
        span = self.instrument.start_server_span(
            method=method,
            metadata=[],  # 实际实现中需要从invocation_metadata获取
        )
        
        try:
            response = await continuation(handler_call_details)
            self.instrument.end_span(span, GRPCStatusCode.OK)
            return response
        except Exception as e:
            self.instrument.end_span(span, GRPCStatusCode.INTERNAL, error=e)
            raise
    
    async def intercept_unary_unary(self, continuation, client_call_details, request):
        """
        客户端一元拦截器
        
        Args:
            continuation: 继续处理函数
            client_call_details: 客户端调用详情
            request: 请求消息
            
        Returns:
            响应
        """
        method = client_call_details.method
        target = client_call_details.target
        
        # 解析目标地址
        host, port = self._parse_target(target)
        
        # 创建客户端Span
        span = self.instrument.start_client_span(
            method=method,
            host=host,
            port=port,
        )
        
        # 注入追踪上下文到元数据
        metadata = list(client_call_details.metadata or [])
        metadata = self.instrument.inject_context(metadata)
        
        # 更新调用详情
        client_call_details = client_call_details._replace(metadata=metadata)
        
        try:
            response = await continuation(client_call_details, request)
            self.instrument.end_span(span, GRPCStatusCode.OK)
            return response
        except Exception as e:
            self.instrument.end_span(span, GRPCStatusCode.INTERNAL, error=e)
            raise
    
    def _parse_target(self, target: str) -> Tuple[str, int]:
        """
        解析目标地址
        
        Args:
            target: 目标地址 (如 "dns:///localhost:50051")
            
        Returns:
            (host, port) 元组
        """
        # 移除前缀
        target = target.replace("dns:///", "").replace("ipv4:///", "").replace("ipv6:///", "")
        
        if ":" in target:
            host, port_str = target.rsplit(":", 1)
            try:
                port = int(port_str)
            except ValueError:
                port = 50051
        else:
            host = target
            port = 50051
        
        return host, port


class StreamingTracingInterceptor:
    """
    gRPC流式调用追踪拦截器
    
    用于追踪流式RPC调用。
    """
    
    def __init__(self, instrument: GRPCInstrument):
        self.instrument = instrument
    
    async def intercept_stream_stream(
        self,
        continuation,
        client_call_details,
        request_iterator,
    ):
        """双向流拦截器"""
        method = client_call_details.method
        target = client_call_details.target
        host, port = self._parse_target(target)
        
        span = self.instrument.start_client_span(
            method=method,
            host=host,
            port=port,
        )
        
        span.set_attribute("grpc.method_type", "bidi_streaming")
        
        metadata = list(client_call_details.metadata or [])
        metadata = self.instrument.inject_context(metadata)
        client_call_details = client_call_details._replace(metadata=metadata)
        
        try:
            response_iterator = await continuation(client_call_details, request_iterator)
            
            # 包装响应迭代器以追踪接收的消息
            async def wrapped_iterator():
                message_count = 0
                async for response in response_iterator:
                    message_count += 1
                    yield response
                span.set_attribute("grpc.message_received", message_count)
            
            self.instrument.end_span(span, GRPCStatusCode.OK)
            return wrapped_iterator()
            
        except Exception as e:
            self.instrument.end_span(span, GRPCStatusCode.INTERNAL, error=e)
            raise
    
    def _parse_target(self, target: str) -> Tuple[str, int]:
        """解析目标地址"""
        target = target.replace("dns:///", "").replace("ipv4:///", "").replace("ipv6:///", "")
        
        if ":" in target:
            host, port_str = target.rsplit(":", 1)
            try:
                port = int(port_str)
            except ValueError:
                port = 50051
        else:
            host = target
            port = 50051
        
        return host, port


# 便捷函数
def create_grpc_instrument(service_name: str = "unknown-service") -> GRPCInstrument:
    """
    创建gRPC追踪器的工厂函数
    
    Args:
        service_name: 服务名称
        
    Returns:
        gRPC追踪器实例
    """
    return GRPCInstrument(service_name)