"""
延迟分析模块

提供追踪数据的延迟分析能力，包括P50/P95/P99计算和趋势分析。
"""

import time
import statistics
from typing import List, Dict, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from collections import defaultdict
import logging
from datetime import datetime, timedelta

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class LatencyMetrics:
    """延迟指标数据类"""
    p50: float  # 中位数
    p90: float  # 90分位数
    p95: float  # 95分位数
    p99: float  # 99分位数
    min: float  # 最小值
    max: float  # 最大值
    mean: float  # 平均值
    std: float  # 标准差
    count: int  # 样本数量
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "p50": self.p50,
            "p90": self.p90,
            "p95": self.p95,
            "p99": self.p99,
            "min": self.min,
            "max": self.max,
            "mean": self.mean,
            "std": self.std,
            "count": self.count,
        }


@dataclass
class LatencyTrend:
    """延迟趋势数据类"""
    timestamp: int
    metrics: LatencyMetrics
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "timestamp": self.timestamp,
            "metrics": self.metrics.to_dict(),
        }


class LatencyAnalyzer:
    """
    延迟分析器
    
    分析追踪数据的延迟分布，计算P50/P95/P99等分位数，
    并提供趋势分析功能。
    
    Example:
        >>> analyzer = LatencyAnalyzer()
        >>> analyzer.add_span(span)
        >>> metrics = analyzer.calculate_metrics()
        >>> print(f"P99: {metrics.p99}ms")
    """
    
    def __init__(
        self,
        window_size: int = 10000,  # 滑动窗口大小
        trend_interval: int = 60,  # 趋势计算间隔（秒）
    ):
        """
        初始化延迟分析器
        
        Args:
            window_size: 滑动窗口大小（保留的span数量）
            trend_interval: 趋势计算间隔（秒）
        """
        self.window_size = window_size
        self.trend_interval = trend_interval
        
        # Span数据存储
        self._spans: List[Dict[str, Any]] = []
        self._spans_by_service: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._spans_by_operation: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        
        # 趋势数据
        self._trends: List[LatencyTrend] = []
        self._last_trend_time: float = 0
        
        # 告警阈值
        self._thresholds: Dict[str, float] = {
            "p95": 1000.0,  # 1秒
            "p99": 2000.0,  # 2秒
        }
        
        # 告警回调
        self._alert_handlers: List[Callable[[str, float], None]] = []
    
    def add_span(self, span: Any) -> None:
        """
        添加Span进行分析
        
        Args:
            span: Span对象或字典
        """
        # 提取Span信息
        span_data = self._extract_span_data(span)
        
        if span_data is None:
            return
        
        # 添加到全局列表
        self._spans.append(span_data)
        
        # 按服务分组
        service_name = span_data.get("service_name", "unknown")
        self._spans_by_service[service_name].append(span_data)
        
        # 按操作分组
        operation = span_data.get("operation", "unknown")
        self._spans_by_operation[operation].append(span_data)
        
        # 维护窗口大小
        self._maintain_window()
        
        # 检查是否需要计算趋势
        self._check_trend_calculation()
    
    def add_spans(self, spans: List[Any]) -> None:
        """
        批量添加Span
        
        Args:
            spans: Span列表
        """
        for span in spans:
            self.add_span(span)
    
    def _extract_span_data(self, span: Any) -> Optional[Dict[str, Any]]:
        """从Span对象提取数据"""
        try:
            if isinstance(span, dict):
                return {
                    "trace_id": span.get("trace_id"),
                    "span_id": span.get("span_id"),
                    "service_name": span.get("service_name", "unknown"),
                    "operation": span.get("name", "unknown"),
                    "duration_ms": span.get("duration_ms", 0),
                    "timestamp": span.get("start_time", int(time.time() * 1000)),
                    "status": span.get("status"),
                }
            else:
                # 从对象提取
                return {
                    "trace_id": getattr(span, "trace_id", None),
                    "span_id": getattr(span, "span_id", None),
                    "service_name": getattr(span, "service_name", "unknown"),
                    "operation": getattr(span, "name", "unknown"),
                    "duration_ms": getattr(span, "duration_ms", lambda: 0)(),
                    "timestamp": getattr(span, "start_time", int(time.time() * 1000)),
                    "status": getattr(span, "status", None),
                }
        except Exception as e:
            logger.error(f"Failed to extract span data: {e}")
            return None
    
    def _maintain_window(self) -> None:
        """维护滑动窗口大小"""
        if len(self._spans) > self.window_size:
            # 移除最旧的数据
            removed = self._spans[:len(self._spans) - self.window_size]
            self._spans = self._spans[-self.window_size:]
            
            # 从分组中移除
            for span_data in removed:
                service = span_data.get("service_name", "unknown")
                operation = span_data.get("operation", "unknown")
                
                if service in self._spans_by_service:
                    self._remove_from_list(self._spans_by_service[service], span_data)
                
                if operation in self._spans_by_operation:
                    self._remove_from_list(self._spans_by_operation[operation], span_data)
    
    def _remove_from_list(self, lst: List[Dict], item: Dict) -> None:
        """从列表中移除指定项"""
        span_id = item.get("span_id")
        for i, s in enumerate(lst):
            if s.get("span_id") == span_id:
                lst.pop(i)
                return
    
    def _check_trend_calculation(self) -> None:
        """检查是否需要计算趋势"""
        current_time = time.time()
        if current_time - self._last_trend_time >= self.trend_interval:
            self._calculate_trend()
            self._last_trend_time = current_time
    
    def _calculate_trend(self) -> None:
        """计算当前趋势"""
        if not self._spans:
            return
        
        metrics = self.calculate_metrics()
        trend = LatencyTrend(
            timestamp=int(time.time()),
            metrics=metrics
        )
        
        self._trends.append(trend)
        
        # 限制趋势数据数量
        if len(self._trends) > 1440:  # 保留24小时（每分钟一个点）
            self._trends = self._trends[-1440:]
        
        # 检查告警
        self._check_alerts(metrics)
    
    def _check_alerts(self, metrics: LatencyMetrics) -> None:
        """检查是否需要触发告警"""
        for metric_name, threshold in self._thresholds.items():
            value = getattr(metrics, metric_name, 0)
            if value > threshold:
                for handler in self._alert_handlers:
                    try:
                        handler(metric_name, value)
                    except Exception as e:
                        logger.error(f"Alert handler failed: {e}")
    
    def calculate_metrics(
        self,
        spans: Optional[List[Dict[str, Any]]] = None
    ) -> LatencyMetrics:
        """
        计算延迟指标
        
        Args:
            spans: 可选的Span列表，默认使用所有存储的Span
            
        Returns:
            延迟指标
        """
        spans = spans or self._spans
        
        if not spans:
            return LatencyMetrics(
                p50=0, p90=0, p95=0, p99=0,
                min=0, max=0, mean=0, std=0, count=0
            )
        
        durations = [s["duration_ms"] for s in spans if "duration_ms" in s]
        
        if not durations:
            return LatencyMetrics(
                p50=0, p90=0, p95=0, p99=0,
                min=0, max=0, mean=0, std=0, count=0
            )
        
        durations.sort()
        count = len(durations)
        
        return LatencyMetrics(
            p50=self._percentile(durations, 50),
            p90=self._percentile(durations, 90),
            p95=self._percentile(durations, 95),
            p99=self._percentile(durations, 99),
            min=durations[0],
            max=durations[-1],
            mean=statistics.mean(durations),
            std=statistics.stdev(durations) if count > 1 else 0,
            count=count
        )
    
    def _percentile(self, sorted_data: List[float], p: float) -> float:
        """计算百分位数"""
        if not sorted_data:
            return 0
        
        k = (len(sorted_data) - 1) * p / 100
        f = int(k)
        c = f + 1 if f + 1 < len(sorted_data) else f
        
        if f == c:
            return sorted_data[f]
        
        return sorted_data[f] + (k - f) * (sorted_data[c] - sorted_data[f])
    
    def get_service_metrics(self, service_name: str) -> LatencyMetrics:
        """
        获取指定服务的延迟指标
        
        Args:
            service_name: 服务名称
            
        Returns:
            延迟指标
        """
        spans = self._spans_by_service.get(service_name, [])
        return self.calculate_metrics(spans)
    
    def get_operation_metrics(self, operation: str) -> LatencyMetrics:
        """
        获取指定操作的延迟指标
        
        Args:
            operation: 操作名称
            
        Returns:
            延迟指标
        """
        spans = self._spans_by_operation.get(operation, [])
        return self.calculate_metrics(spans)
    
    def get_all_service_metrics(self) -> Dict[str, LatencyMetrics]:
        """
        获取所有服务的延迟指标
        
        Returns:
            服务名称到指标的映射
        """
        return {
            service: self.calculate_metrics(spans)
            for service, spans in self._spans_by_service.items()
        }
    
    def get_trends(
        self,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None
    ) -> List[LatencyTrend]:
        """
        获取趋势数据
        
        Args:
            start_time: 开始时间戳
            end_time: 结束时间戳
            
        Returns:
            趋势数据列表
        """
        trends = self._trends
        
        if start_time:
            trends = [t for t in trends if t.timestamp >= start_time]
        if end_time:
            trends = [t for t in trends if t.timestamp <= end_time]
        
        return trends
    
    def set_threshold(self, metric: str, threshold: float) -> None:
        """
        设置告警阈值
        
        Args:
            metric: 指标名称（p50, p95, p99等）
            threshold: 阈值（毫秒）
        """
        self._thresholds[metric] = threshold
    
    def add_alert_handler(self, handler: Callable[[str, float], None]) -> None:
        """
        添加告警处理器
        
        Args:
            handler: 回调函数，接收(metric_name, value)参数
        """
        self._alert_handlers.append(handler)
    
    def get_slow_operations(self, threshold_ms: float = 1000.0) -> List[Dict[str, Any]]:
        """
        获取慢操作列表
        
        Args:
            threshold_ms: 慢操作阈值（毫秒）
            
        Returns:
            慢操作列表
        """
        slow_ops = []
        
        for operation, spans in self._spans_by_operation.items():
            slow_spans = [s for s in spans if s.get("duration_ms", 0) > threshold_ms]
            if slow_spans:
                slow_ops.append({
                    "operation": operation,
                    "count": len(slow_spans),
                    "max_duration": max(s["duration_ms"] for s in slow_spans),
                    "avg_duration": statistics.mean(s["duration_ms"] for s in slow_spans),
                })
        
        # 按数量排序
        slow_ops.sort(key=lambda x: x["count"], reverse=True)
        return slow_ops
    
    def clear(self) -> None:
        """清除所有数据"""
        self._spans.clear()
        self._spans_by_service.clear()
        self._spans_by_operation.clear()
        self._trends.clear()
        logger.info("Latency analyzer cleared")


# 便捷函数
def create_latency_analyzer(
    window_size: int = 10000,
    trend_interval: int = 60,
) -> LatencyAnalyzer:
    """
    创建延迟分析器的工厂函数
    
    Args:
        window_size: 滑动窗口大小
        trend_interval: 趋势计算间隔（秒）
        
    Returns:
        延迟分析器实例
    """
    return LatencyAnalyzer(window_size, trend_interval)
