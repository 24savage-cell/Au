"""
依赖图谱模块

提供服务调用依赖关系的构建和拓扑分析功能。
"""

import time
from typing import List, Dict, Any, Optional, Set, Tuple
from dataclasses import dataclass, field
from collections import defaultdict
import logging

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class ServiceNode:
    """服务节点"""
    name: str
    type: str = "service"  # service, database, cache, queue
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ServiceEdge:
    """服务间调用边"""
    source: str
    target: str
    operation: str
    count: int = 0
    avg_latency: float = 0.0
    error_rate: float = 0.0
    last_updated: float = field(default_factory=time.time)


@dataclass
class DependencyGraph:
    """依赖图谱"""
    nodes: Dict[str, ServiceNode] = field(default_factory=dict)
    edges: Dict[Tuple[str, str], ServiceEdge] = field(default_factory=dict)
    
    def add_node(self, node: ServiceNode) -> None:
        """添加节点"""
        self.nodes[node.name] = node
    
    def add_edge(self, edge: ServiceEdge) -> None:
        """添加边"""
        key = (edge.source, edge.target)
        if key in self.edges:
            # 更新现有边
            existing = self.edges[key]
            existing.count += edge.count
            existing.avg_latency = (existing.avg_latency + edge.avg_latency) / 2
            existing.error_rate = (existing.error_rate + edge.error_rate) / 2
            existing.last_updated = time.time()
        else:
            self.edges[key] = edge
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "nodes": [
                {"name": n.name, "type": n.type, "metadata": n.metadata}
                for n in self.nodes.values()
            ],
            "edges": [
                {
                    "source": e.source,
                    "target": e.target,
                    "operation": e.operation,
                    "count": e.count,
                    "avg_latency": e.avg_latency,
                    "error_rate": e.error_rate,
                }
                for e in self.edges.values()
            ]
        }


class DependencyMapBuilder:
    """
    依赖图谱构建器
    
    从追踪数据构建服务调用依赖图谱，支持拓扑分析和可视化。
    
    Example:
        >>> builder = DependencyMapBuilder()
        >>> builder.add_span(span)
        >>> graph = builder.build_graph()
        >>> print(f"Services: {list(graph.nodes.keys())}")
    """
    
    def __init__(self):
        """初始化依赖图谱构建器"""
        self._spans: List[Dict[str, Any]] = []
        self._span_index: Dict[str, Dict[str, Any]] = {}  # span_id -> span
        self._trace_spans: Dict[str, List[Dict[str, Any]]] = defaultdict(list)  # trace_id -> spans
        
        # 依赖统计
        self._dependencies: Dict[Tuple[str, str], Dict[str, Any]] = defaultdict(
            lambda: {"count": 0, "latencies": [], "errors": 0}
        )
    
    def add_span(self, span: Any) -> None:
        """
        添加Span
        
        Args:
            span: Span对象
        """
        span_data = self._extract_span_data(span)
        if span_data is None:
            return
        
        self._spans.append(span_data)
        
        span_id = span_data.get("span_id")
        trace_id = span_data.get("trace_id")
        
        if span_id:
            self._span_index[span_id] = span_data
        
        if trace_id:
            self._trace_spans[trace_id].append(span_data)
    
    def add_spans(self, spans: List[Any]) -> None:
        """
        批量添加Span
        
        Args:
            spans: Span列表
        """
        for span in spans:
            self.add_span(span)
    
    def _extract_span_data(self, span: Any) -> Optional[Dict[str, Any]]:
        """提取Span数据"""
        try:
            if isinstance(span, dict):
                return {
                    "trace_id": span.get("trace_id"),
                    "span_id": span.get("span_id"),
                    "parent_id": span.get("parent_id"),
                    "service_name": span.get("service_name", "unknown"),
                    "operation": span.get("name", "unknown"),
                    "kind": span.get("kind", "internal"),
                    "duration_ms": span.get("duration_ms", 0),
                    "status": span.get("status"),
                    "attributes": span.get("attributes", {}),
                }
            else:
                return {
                    "trace_id": getattr(span, "trace_id", None),
                    "span_id": getattr(span, "span_id", None),
                    "parent_id": getattr(span, "parent_id", None),
                    "service_name": getattr(span, "service_name", "unknown"),
                    "operation": getattr(span, "name", "unknown"),
                    "kind": getattr(span, "kind", "internal"),
                    "duration_ms": getattr(span, "duration_ms", lambda: 0)(),
                    "status": getattr(span, "status", None),
                    "attributes": getattr(span, "attributes", {}),
                }
        except Exception as e:
            logger.error(f"Failed to extract span data: {e}")
            return None
    
    def build_graph(self) -> DependencyGraph:
        """
        构建依赖图谱
        
        Returns:
            依赖图谱
        """
        graph = DependencyGraph()
        
        # 按trace分组构建依赖关系
        for trace_id, spans in self._trace_spans.items():
            self._build_trace_graph(graph, spans)
        
        return graph
    
    def _build_trace_graph(self, graph: DependencyGraph, spans: List[Dict[str, Any]]) -> None:
        """构建单个trace的依赖图"""
        # 建立span映射
        span_map = {s["span_id"]: s for s in spans if s.get("span_id")}
        
        for span in spans:
            service_name = span.get("service_name", "unknown")
            
            # 添加节点
            node = ServiceNode(
                name=service_name,
                type=self._detect_service_type(span),
                metadata={
                    "operation": span.get("operation"),
                    "kind": span.get("kind"),
                }
            )
            graph.add_node(node)
            
            # 处理父span关系
            parent_id = span.get("parent_id")
            if parent_id and parent_id in span_map:
                parent_span = span_map[parent_id]
                parent_service = parent_span.get("service_name", "unknown")
                
                if parent_service != service_name:
                    # 添加调用边
                    edge = ServiceEdge(
                        source=parent_service,
                        target=service_name,
                        operation=span.get("operation", "unknown"),
                        count=1,
                        avg_latency=span.get("duration_ms", 0),
                        error_rate=1.0 if span.get("status") == "ERROR" else 0.0
                    )
                    graph.add_edge(edge)
            
            # 检测外部调用（从attributes中）
            self._detect_external_calls(graph, span, service_name)
    
    def _detect_service_type(self, span: Dict[str, Any]) -> str:
        """检测服务类型"""
        attributes = span.get("attributes", {})
        
        if "db.system" in attributes:
            return "database"
        elif "messaging.system" in attributes:
            return "queue"
        elif "cache.system" in attributes:
            return "cache"
        elif span.get("kind") in ["client", "server"]:
            return "service"
        
        return "service"
    
    def _detect_external_calls(
        self,
        graph: DependencyGraph,
        span: Dict[str, Any],
        source_service: str
    ) -> None:
        """检测外部调用"""
        attributes = span.get("attributes", {})
        
        # 检测数据库调用
        if "db.system" in attributes:
            db_system = attributes.get("db.system", "database")
            target = f"{db_system}:{attributes.get('db.name', 'unknown')}"
            
            edge = ServiceEdge(
                source=source_service,
                target=target,
                operation=attributes.get("db.operation", "query"),
                count=1,
                avg_latency=span.get("duration_ms", 0),
                error_rate=1.0 if span.get("status") == "ERROR" else 0.0
            )
            graph.add_edge(edge)
            
            # 添加数据库节点
            node = ServiceNode(
                name=target,
                type="database",
                metadata={"system": db_system}
            )
            graph.add_node(node)
        
        # 检测消息队列调用
        if "messaging.system" in attributes:
            mq_system = attributes.get("messaging.system", "queue")
            destination = attributes.get("messaging.destination", "unknown")
            
            edge = ServiceEdge(
                source=source_service,
                target=f"{mq_system}:{destination}",
                operation=attributes.get("messaging.operation", "send"),
                count=1,
                avg_latency=span.get("duration_ms", 0),
                error_rate=1.0 if span.get("status") == "ERROR" else 0.0
            )
            graph.add_edge(edge)
    
    def get_upstream_services(self, service_name: str) -> Set[str]:
        """
        获取上游服务（调用指定服务的服务）
        
        Args:
            service_name: 服务名称
            
        Returns:
            上游服务集合
        """
        upstream = set()
        
        for (source, target), _ in self._dependencies.items():
            if target == service_name:
                upstream.add(source)
        
        return upstream
    
    def get_downstream_services(self, service_name: str) -> Set[str]:
        """
        获取下游服务（被指定服务调用的服务）
        
        Args:
            service_name: 服务名称
            
        Returns:
            下游服务集合
        """
        downstream = set()
        
        for (source, target), _ in self._dependencies.items():
            if source == service_name:
                downstream.add(target)
        
        return downstream
    
    def find_critical_path(self, start_service: str, end_service: str) -> List[str]:
        """
        查找关键路径
        
        Args:
            start_service: 起始服务
            end_service: 目标服务
            
        Returns:
            路径上的服务列表
        """
        # 使用BFS查找最短路径
        visited = {start_service: None}
        queue = [start_service]
        
        graph = self.build_graph()
        
        while queue:
            current = queue.pop(0)
            
            if current == end_service:
                # 重建路径
                path = []
                while current is not None:
                    path.append(current)
                    current = visited[current]
                return list(reversed(path))
            
            # 查找下游服务
            for edge in graph.edges.values():
                if edge.source == current and edge.target not in visited:
                    visited[edge.target] = current
                    queue.append(edge.target)
        
        return []  # 未找到路径
    
    def detect_cycles(self) -> List[List[str]]:
        """
        检测循环依赖
        
        Returns:
            循环路径列表
        """
        graph = self.build_graph()
        cycles = []
        visited = set()
        rec_stack = set()
        
        def dfs(node: str, path: List[str]) -> None:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)
            
            for edge in graph.edges.values():
                if edge.source == node:
                    if edge.target in rec_stack:
                        # 发现循环
                        cycle_start = path.index(edge.target)
                        cycles.append(path[cycle_start:] + [edge.target])
                    elif edge.target not in visited:
                        dfs(edge.target, path.copy())
            
            rec_stack.remove(node)
        
        for node in graph.nodes:
            if node not in visited:
                dfs(node, [])
        
        return cycles
    
    def get_service_statistics(self) -> Dict[str, Dict[str, Any]]:
        """
        获取服务统计信息
        
        Returns:
            服务统计字典
        """
        stats = defaultdict(lambda: {
            "incoming_calls": 0,
            "outgoing_calls": 0,
            "total_latency": 0,
            "call_count": 0,
            "error_count": 0,
        })
        
        graph = self.build_graph()
        
        for edge in graph.edges.values():
            stats[edge.target]["incoming_calls"] += edge.count
            stats[edge.source]["outgoing_calls"] += edge.count
            stats[edge.source]["total_latency"] += edge.avg_latency * edge.count
            stats[edge.source]["call_count"] += edge.count
            stats[edge.source]["error_count"] += int(edge.error_rate * edge.count)
        
        # 计算平均值
        result = {}
        for service, data in stats.items():
            if data["call_count"] > 0:
                data["avg_latency"] = data["total_latency"] / data["call_count"]
                data["error_rate"] = data["error_count"] / data["call_count"]
            else:
                data["avg_latency"] = 0
                data["error_rate"] = 0
            result[service] = data
        
        return result
    
    def clear(self) -> None:
        """清除所有数据"""
        self._spans.clear()
        self._span_index.clear()
        self._trace_spans.clear()
        self._dependencies.clear()
        logger.info("Dependency map builder cleared")


# 便捷函数
def create_dependency_map_builder() -> DependencyMapBuilder:
    """
    创建依赖图谱构建器的工厂函数
    
    Returns:
        依赖图谱构建器实例
    """
    return DependencyMapBuilder()
