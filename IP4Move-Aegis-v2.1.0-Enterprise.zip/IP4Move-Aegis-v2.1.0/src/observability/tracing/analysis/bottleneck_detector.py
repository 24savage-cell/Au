"""
瓶颈检测模块

提供慢Span识别和关键路径分析功能，帮助定位性能瓶颈。
"""

import time
from typing import List, Dict, Any, Optional, Set, Tuple
from dataclasses import dataclass, field
from collections import defaultdict
import logging
import statistics

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class Bottleneck:
    """瓶颈信息"""
    span_id: str
    trace_id: str
    service_name: str
    operation: str
    duration_ms: float
    contribution_pct: float  # 对总延迟的贡献百分比
    severity: str  # critical, high, medium, low
    children_time_ms: float  # 子Span总耗时
    self_time_ms: float  # 自身耗时
    timestamp: float = field(default_factory=time.time)


@dataclass
class CriticalPathNode:
    """关键路径节点"""
    span_id: str
    service_name: str
    operation: str
    start_time: int
    end_time: int
    duration_ms: float
    cumulative_time_ms: float  # 累积时间


class BottleneckDetector:
    """
    瓶颈检测器
    
    从追踪数据中识别性能瓶颈，分析关键路径。
    
    Example:
        >>> detector = BottleneckDetector(slow_threshold_ms=500)
        >>> detector.add_span(span)
        >>> bottlenecks = detector.detect_bottlenecks()
        >>> for b in bottlenecks:
        ...     print(f"{b.service_name}: {b.duration_ms}ms")
    """
    
    def __init__(
        self,
        slow_threshold_ms: float = 500.0,
        critical_threshold_ms: float = 1000.0,
        min_contribution_pct: float = 20.0,
    ):
        """
        初始化瓶颈检测器
        
        Args:
            slow_threshold_ms: 慢Span阈值（毫秒）
            critical_threshold_ms: 严重瓶颈阈值（毫秒）
            min_contribution_pct: 最小贡献百分比阈值
        """
        self.slow_threshold_ms = slow_threshold_ms
        self.critical_threshold_ms = critical_threshold_ms
        self.min_contribution_pct = min_contribution_pct
        
        # Span存储
        self._spans: List[Dict[str, Any]] = []
        self._span_index: Dict[str, Dict[str, Any]] = {}
        self._trace_spans: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        
        # 历史瓶颈
        self._bottleneck_history: List[Bottleneck] = []
    
    def add_span(self, span: Any) -> None:
        """
        添加Span
        
        Args:
            span: Span对象
        """
        span_data = self._extract_span_data(span)
        if span_data is None:
            return
        
        self._spans.append(span_data)
        
        span_id = span_data.get("span_id")
        trace_id = span_data.get("trace_id")
        
        if span_id:
            self._span_index[span_id] = span_data
        
        if trace_id:
            self._trace_spans[trace_id].append(span_data)
    
    def add_spans(self, spans: List[Any]) -> None:
        """
        批量添加Span
        
        Args:
            spans: Span列表
        """
        for span in spans:
            self.add_span(span)
    
    def _extract_span_data(self, span: Any) -> Optional[Dict[str, Any]]:
        """提取Span数据"""
        try:
            if isinstance(span, dict):
                return {
                    "trace_id": span.get("trace_id"),
                    "span_id": span.get("span_id"),
                    "parent_id": span.get("parent_id"),
                    "service_name": span.get("service_name", "unknown"),
                    "operation": span.get("name", "unknown"),
                    "start_time": span.get("start_time", 0),
                    "end_time": span.get("end_time", 0),
                    "duration_ms": span.get("duration_ms", 0),
                    "status": span.get("status"),
                    "attributes": span.get("attributes", {}),
                }
            else:
                return {
                    "trace_id": getattr(span, "trace_id", None),
                    "span_id": getattr(span, "span_id", None),
                    "parent_id": getattr(span, "parent_id", None),
                    "service_name": getattr(span, "service_name", "unknown"),
                    "operation": getattr(span, "name", "unknown"),
                    "start_time": getattr(span, "start_time", 0),
                    "end_time": getattr(span, "end_time", 0),
                    "duration_ms": getattr(span, "duration_ms", lambda: 0)(),
                    "status": getattr(span, "status", None),
                    "attributes": getattr(span, "attributes", {}),
                }
        except Exception as e:
            logger.error(f"Failed to extract span data: {e}")
            return None
    
    def detect_bottlenecks(
        self,
        trace_id: Optional[str] = None
    ) -> List[Bottleneck]:
        """
        检测瓶颈
        
        Args:
            trace_id: 可选的trace ID，默认分析所有trace
            
        Returns:
            瓶颈列表
        """
        bottlenecks = []
        
        if trace_id:
            traces = {trace_id: self._trace_spans.get(trace_id, [])}
        else:
            traces = self._trace_spans
        
        for tid, spans in traces.items():
            trace_bottlenecks = self._analyze_trace_bottlenecks(tid, spans)
            bottlenecks.extend(trace_bottlenecks)
        
        # 按严重程度排序
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        bottlenecks.sort(key=lambda b: severity_order.get(b.severity, 4))
        
        # 保存历史
        self._bottleneck_history.extend(bottlenecks)
        
        return bottlenecks
    
    def _analyze_trace_bottlenecks(
        self,
        trace_id: str,
        spans: List[Dict[str, Any]]
    ) -> List[Bottleneck]:
        """分析单个trace的瓶颈"""
        bottlenecks = []
        
        if not spans:
            return bottlenecks
        
        # 计算trace总耗时
        root_span = self._find_root_span(spans)
        if not root_span:
            return bottlenecks
        
        trace_duration = root_span.get("duration_ms", 0)
        if trace_duration == 0:
            return bottlenecks
        
        # 构建span树
        span_tree = self._build_span_tree(spans)
        
        # 分析每个span
        for span in spans:
            duration = span.get("duration_ms", 0)
            
            # 跳过非慢span
            if duration < self.slow_threshold_ms:
                continue
            
            # 计算贡献度
            contribution_pct = (duration / trace_duration) * 100
            
            if contribution_pct < self.min_contribution_pct:
                continue
            
            # 计算子span耗时
            children_time = self._calculate_children_time(span, span_tree)
            self_time = duration - children_time
            
            # 确定严重程度
            severity = self._determine_severity(duration, contribution_pct)
            
            bottleneck = Bottleneck(
                span_id=span.get("span_id", ""),
                trace_id=trace_id,
                service_name=span.get("service_name", "unknown"),
                operation=span.get("operation", "unknown"),
                duration_ms=duration,
                contribution_pct=contribution_pct,
                severity=severity,
                children_time_ms=children_time,
                self_time_ms=self_time
            )
            
            bottlenecks.append(bottleneck)
        
        return bottlenecks
    
    def _find_root_span(self, spans: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """查找根Span"""
        for span in spans:
            parent_id = span.get("parent_id")
            if not parent_id:
                return span
        
        # 如果没有明确的根，返回最早的span
        if spans:
            return min(spans, key=lambda s: s.get("start_time", 0))
        
        return None
    
    def _build_span_tree(
        self,
        spans: List[Dict[str, Any]]
    ) -> Dict[str, List[Dict[str, Any]]]:
        """构建Span树"""
        tree = defaultdict(list)
        
        for span in spans:
            parent_id = span.get("parent_id")
            if parent_id:
                tree[parent_id].append(span)
        
        return tree
    
    def _calculate_children_time(
        self,
        span: Dict[str, Any],
        span_tree: Dict[str, List[Dict[str, Any]]]
    ) -> float:
        """计算子span总耗时"""
        span_id = span.get("span_id")
        children = span_tree.get(span_id, [])
        
        total_time = 0.0
        for child in children:
            total_time += child.get("duration_ms", 0)
        
        return total_time
    
    def _determine_severity(self, duration_ms: float, contribution_pct: float) -> str:
        """确定严重程度"""
        if duration_ms >= self.critical_threshold_ms or contribution_pct >= 50:
            return "critical"
        elif duration_ms >= self.slow_threshold_ms * 2 or contribution_pct >= 30:
            return "high"
        elif contribution_pct >= self.min_contribution_pct:
            return "medium"
        else:
            return "low"
    
    def analyze_critical_path(self, trace_id: str) -> List[CriticalPathNode]:
        """
        分析关键路径
        
        关键路径是从根span到最慢叶子span的路径。
        
        Args:
            trace_id: Trace ID
            
        Returns:
            关键路径节点列表
        """
        spans = self._trace_spans.get(trace_id, [])
        if not spans:
            return []
        
        # 构建span树
        span_map = {s["span_id"]: s for s in spans if s.get("span_id")}
        span_tree = self._build_span_tree(spans)
        
        # 找到根span
        root_span = self._find_root_span(spans)
        if not root_span:
            return []
        
        # 找到关键路径
        path = self._find_critical_path_recursive(root_span, span_tree, span_map)
        
        # 转换为CriticalPathNode
        nodes = []
        cumulative_time = 0.0
        
        for span in path:
            duration = span.get("duration_ms", 0)
            cumulative_time += duration
            
            node = CriticalPathNode(
                span_id=span.get("span_id", ""),
                service_name=span.get("service_name", "unknown"),
                operation=span.get("operation", "unknown"),
                start_time=span.get("start_time", 0),
                end_time=span.get("end_time", 0),
                duration_ms=duration,
                cumulative_time_ms=cumulative_time
            )
            nodes.append(node)
        
        return nodes
    
    def _find_critical_path_recursive(
        self,
        span: Dict[str, Any],
        span_tree: Dict[str, List[Dict[str, Any]]],
        span_map: Dict[str, Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """递归查找关键路径"""
        span_id = span.get("span_id")
        children = span_tree.get(span_id, [])
        
        if not children:
            return [span]
        
        # 找到耗时最长的子路径
        longest_path = []
        for child in children:
            child_path = self._find_critical_path_recursive(child, span_tree, span_map)
            total_duration = sum(s.get("duration_ms", 0) for s in child_path)
            
            if total_duration > sum(s.get("duration_ms", 0) for s in longest_path):
                longest_path = child_path
        
        return [span] + longest_path
    
    def get_bottleneck_statistics(self) -> Dict[str, Any]:
        """
        获取瓶颈统计信息
        
        Returns:
            统计字典
        """
        if not self._bottleneck_history:
            return {
                "total_bottlenecks": 0,
                "by_severity": {},
                "by_service": {},
                "avg_duration": 0,
            }
        
        by_severity = defaultdict(int)
        by_service = defaultdict(int)
        durations = []
        
        for b in self._bottleneck_history:
            by_severity[b.severity] += 1
            by_service[b.service_name] += 1
            durations.append(b.duration_ms)
        
        return {
            "total_bottlenecks": len(self._bottleneck_history),
            "by_severity": dict(by_severity),
            "by_service": dict(by_service),
            "avg_duration": statistics.mean(durations) if durations else 0,
            "max_duration": max(durations) if durations else 0,
        }
    
    def get_top_bottlenecks(self, n: int = 10) -> List[Bottleneck]:
        """
        获取最严重的瓶颈
        
        Args:
            n: 返回数量
            
        Returns:
            瓶颈列表
        """
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        
        sorted_bottlenecks = sorted(
            self._bottleneck_history,
            key=lambda b: (severity_order.get(b.severity, 4), -b.duration_ms)
        )
        
        return sorted_bottlenecks[:n]
    
    def get_recurring_bottlenecks(self, min_occurrences: int = 3) -> List[Dict[str, Any]]:
        """
        获取重复出现的瓶颈
        
        Args:
            min_occurrences: 最小出现次数
            
        Returns:
            重复瓶颈列表
        """
        operation_counts = defaultdict(lambda: {"count": 0, "durations": []})
        
        for b in self._bottleneck_history:
            key = f"{b.service_name}:{b.operation}"
            operation_counts[key]["count"] += 1
            operation_counts[key]["durations"].append(b.duration_ms)
        
        recurring = []
        for key, data in operation_counts.items():
            if data["count"] >= min_occurrences:
                service, operation = key.split(":", 1)
                recurring.append({
                    "service_name": service,
                    "operation": operation,
                    "occurrences": data["count"],
                    "avg_duration": statistics.mean(data["durations"]),
                    "max_duration": max(data["durations"]),
                })
        
        # 按出现次数排序
        recurring.sort(key=lambda x: x["occurrences"], reverse=True)
        
        return recurring
    
    def clear(self) -> None:
        """清除所有数据"""
        self._spans.clear()
        self._span_index.clear()
        self._trace_spans.clear()
        self._bottleneck_history.clear()
        logger.info("Bottleneck detector cleared")


# 便捷函数
def create_bottleneck_detector(
    slow_threshold_ms: float = 500.0,
    critical_threshold_ms: float = 1000.0,
) -> BottleneckDetector:
    """
    创建瓶颈检测器的工厂函数
    
    Args:
        slow_threshold_ms: 慢Span阈值
        critical_threshold_ms: 严重瓶颈阈值
        
    Returns:
        瓶颈检测器实例
    """
    return BottleneckDetector(
        slow_threshold_ms=slow_threshold_ms,
        critical_threshold_ms=critical_threshold_ms
    )
