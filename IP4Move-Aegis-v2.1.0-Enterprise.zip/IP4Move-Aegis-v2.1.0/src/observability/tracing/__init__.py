"""
全链路追踪模块

提供分布式系统的全链路追踪能力，包括：
- HTTP/gRPC/数据库/消息队列的自动埋点
- W3C/B3/Jaeger等多种传播协议支持
- Jaeger/Zipkin/OTLP等多种导出器
- 延迟分析、依赖图谱、瓶颈检测等分析能力
"""

from .instrumentation.http_instrument import HTTPInstrument, HTTPTracingMiddleware
from .instrumentation.grpc_instrument import GRPCInstrument, TracingInterceptor
from .instrumentation.database_instrument import DatabaseInstrument, SQLTracer
from .instrumentation.message_queue_instrument import MQInstrument, MQTracingProducer, MQTracingConsumer
from .propagation.w3c_trace_context import W3CTraceContextPropagator
from .propagation.b3_propagation import B3Propagator
from .propagation.jaeger_propagation import JaegerPropagator
from .exporters.jaeger_exporter import JaegerExporter
from .exporters.zipkin_exporter import ZipkinExporter
from .exporters.otlp_exporter import OTLPExporter
from .analysis.latency_analysis import LatencyAnalyzer
from .analysis.dependency_map import DependencyMapBuilder
from .analysis.bottleneck_detector import BottleneckDetector

__version__ = "1.0.0"
__all__ = [
    # Instrumentation
    "HTTPInstrument",
    "HTTPTracingMiddleware",
    "GRPCInstrument",
    "TracingInterceptor",
    "DatabaseInstrument",
    "SQLTracer",
    "MQInstrument",
    "MQTracingProducer",
    "MQTracingConsumer",
    # Propagation
    "W3CTraceContextPropagator",
    "B3Propagator",
    "JaegerPropagator",
    # Exporters
    "JaegerExporter",
    "ZipkinExporter",
    "OTLPExporter",
    # Analysis
    "LatencyAnalyzer",
    "DependencyMapBuilder",
    "BottleneckDetector",
]