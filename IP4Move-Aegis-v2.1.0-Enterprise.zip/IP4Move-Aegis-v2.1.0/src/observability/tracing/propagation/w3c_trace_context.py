"""
W3C Trace Context传播模块

实现W3C Trace Context标准，支持traceparent和tracestate头的解析与注入。
参考: https://www.w3.org/TR/trace-context/
"""

import re
from typing import Optional, Dict, Tuple, List
import logging

logger = logging.getLogger(__name__)


class W3CTraceContextPropagator:
    """
    W3C Trace Context传播器
    
    实现W3C Trace Context标准，用于在HTTP请求头中传播追踪上下文。
    
    traceparent格式: version-trace_id-parent_id-flags
    示例: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
    
    tracestate格式: vendor1=value1,vendor2=value2
    
    Example:
        >>> propagator = W3CTraceContextPropagator()
        >>> # 提取上下文
        >>> trace_id, parent_id = propagator.extract(headers)
        >>> # 注入上下文
        >>> headers = propagator.inject(headers, trace_id, span_id)
    """
    
    # HTTP头名称
    TRACEPARENT_HEADER = "traceparent"
    TRACESTATE_HEADER = "tracestate"
    
    # traceparent格式正则
    # 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
    TRACEPARENT_PATTERN = re.compile(
        r"^(?P<version>[0-9a-f]{2})-"
        r"(?P<trace_id>[0-9a-f]{32})-"
        r"(?P<parent_id>[0-9a-f]{16})-"
        r"(?P<flags>[0-9a-f]{2})$"
    )
    
    # 有效的trace_id（不能全为0）
    INVALID_TRACE_ID = "0" * 32
    INVALID_PARENT_ID = "0" * 16
    
    # 标志位
    FLAG_SAMPLED = 0x01  # 采样标志
    
    def __init__(self):
        """初始化W3C传播器"""
        self._tracestate_limit = 32  # tracestate最大条目数
        self._tracestate_max_length = 128  # 每个条目的最大长度
    
    def extract(self, headers: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
        """
        从HTTP头中提取追踪上下文
        
        Args:
            headers: HTTP请求头字典
            
        Returns:
            (trace_id, parent_span_id) 元组，如果无效则返回(None, None)
        """
        traceparent = headers.get(self.TRACEPARENT_HEADER)
        
        if not traceparent:
            logger.debug("No traceparent header found")
            return None, None
        
        return self._parse_traceparent(traceparent)
    
    def _parse_traceparent(self, traceparent: str) -> Tuple[Optional[str], Optional[str]]:
        """
        解析traceparent头
        
        Args:
            traceparent: traceparent头值
            
        Returns:
            (trace_id, parent_span_id) 元组
        """
        traceparent = traceparent.strip()
        
        match = self.TRACEPARENT_PATTERN.match(traceparent)
        if not match:
            logger.warning(f"Invalid traceparent format: {traceparent}")
            return None, None
        
        version = match.group("version")
        trace_id = match.group("trace_id")
        parent_id = match.group("parent_id")
        flags = match.group("flags")
        
        # 验证版本
        if version == "00":
            # 版本00要求trace_id和parent_id不能全为0
            if trace_id == self.INVALID_TRACE_ID:
                logger.warning("Invalid trace_id: all zeros")
                return None, None
            if parent_id == self.INVALID_PARENT_ID:
                logger.warning("Invalid parent_id: all zeros")
                return None, None
        
        # 验证标志位（必须是有效的十六进制）
        try:
            int(flags, 16)
        except ValueError:
            logger.warning(f"Invalid flags: {flags}")
            return None, None
        
        logger.debug(f"Extracted trace_id={trace_id}, parent_id={parent_id}")
        
        return trace_id, parent_id
    
    def inject(
        self,
        headers: Dict[str, str],
        trace_id: str,
        span_id: str,
        sampled: bool = True,
    ) -> Dict[str, str]:
        """
        将追踪上下文注入到HTTP头
        
        Args:
            headers: 原始HTTP头字典
            trace_id: 追踪ID（32位十六进制）
            span_id: Span ID（16位十六进制）
            sampled: 是否采样
            
        Returns:
            注入追踪上下文后的HTTP头字典
        """
        # 验证并格式化ID
        trace_id = self._format_trace_id(trace_id)
        span_id = self._format_span_id(span_id)
        
        # 构建flags
        flags = self.FLAG_SAMPLED if sampled else 0x00
        
        # 构建traceparent
        traceparent = f"00-{trace_id}-{span_id}-{flags:02x}"
        
        # 复制headers以避免修改原始字典
        new_headers = headers.copy()
        new_headers[self.TRACEPARENT_HEADER] = traceparent
        
        logger.debug(f"Injected traceparent: {traceparent}")
        
        return new_headers
    
    def _format_trace_id(self, trace_id: str) -> str:
        """
        格式化trace_id为32位十六进制
        
        Args:
            trace_id: 原始trace_id
            
        Returns:
            格式化后的trace_id
        """
        # 移除可能的连字符
        trace_id = trace_id.replace("-", "").lower()
        
        # 如果长度不足，左填充0
        if len(trace_id) < 32:
            trace_id = trace_id.zfill(32)
        # 如果长度超过，取后32位
        elif len(trace_id) > 32:
            trace_id = trace_id[-32:]
        
        return trace_id
    
    def _format_span_id(self, span_id: str) -> str:
        """
        格式化span_id为16位十六进制
        
        Args:
            span_id: 原始span_id
            
        Returns:
            格式化后的span_id
        """
        span_id = span_id.replace("-", "").lower()
        
        if len(span_id) < 16:
            span_id = span_id.zfill(16)
        elif len(span_id) > 16:
            span_id = span_id[-16:]
        
        return span_id
    
    def extract_tracestate(self, headers: Dict[str, str]) -> Dict[str, str]:
        """
        提取tracestate头
        
        Args:
            headers: HTTP请求头
            
        Returns:
            tracestate字典
        """
        tracestate_header = headers.get(self.TRACESTATE_HEADER, "")
        
        if not tracestate_header:
            return {}
        
        tracestate = {}
        
        # 解析tracestate: vendor1=value1,vendor2=value2
        for entry in tracestate_header.split(","):
            entry = entry.strip()
            if "=" in entry:
                key, value = entry.split("=", 1)
                tracestate[key.strip()] = value.strip()
        
        return tracestate
    
    def inject_tracestate(
        self,
        headers: Dict[str, str],
        tracestate: Dict[str, str],
        vendor_key: Optional[str] = None,
        vendor_value: Optional[str] = None,
    ) -> Dict[str, str]:
        """
        注入tracestate头
        
        Args:
            headers: HTTP头
            tracestate: 现有的tracestate字典
            vendor_key: 当前vendor的key
            vendor_value: 当前vendor的value
            
        Returns:
            更新后的HTTP头
        """
        # 复制tracestate
        new_tracestate = tracestate.copy()
        
        # 添加当前vendor
        if vendor_key and vendor_value:
            new_tracestate[vendor_key] = vendor_value
        
        # 限制条目数
        if len(new_tracestate) > self._tracestate_limit:
            # 保留最后N个条目
            items = list(new_tracestate.items())
            new_tracestate = dict(items[-self._tracestate_limit:])
        
        # 构建tracestate字符串
        tracestate_entries = []
        for key, value in new_tracestate.items():
            # 验证key和value
            if self._is_valid_tracestate_entry(key, value):
                tracestate_entries.append(f"{key}={value}")
        
        new_headers = headers.copy()
        
        if tracestate_entries:
            new_headers[self.TRACESTATE_HEADER] = ",".join(tracestate_entries)
        
        return new_headers
    
    def _is_valid_tracestate_entry(self, key: str, value: str) -> bool:
        """
        验证tracestate条目是否有效
        
        Args:
            key: 键
            value: 值
            
        Returns:
            是否有效
        """
        # key必须以字母开头，只能包含字母、数字、下划线、连字符、星号
        if not re.match(r"^[a-z][a-z0-9_\-\*/]*$", key, re.IGNORECASE):
            return False
        
        # value长度限制
        if len(value) > self._tracestate_max_length:
            return False
        
        # value不能包含逗号、等号
        if "," in value or "=" in value:
            return False
        
        return True
    
    def is_sampled(self, headers: Dict[str, str]) -> bool:
        """
        检查是否采样
        
        Args:
            headers: HTTP头
            
        Returns:
            是否采样
        """
        traceparent = headers.get(self.TRACEPARENT_HEADER, "")
        
        match = self.TRACEPARENT_PATTERN.match(traceparent)
        if not match:
            return False
        
        flags = int(match.group("flags"), 16)
        return bool(flags & self.FLAG_SAMPLED)
    
    def get_version(self, headers: Dict[str, str]) -> Optional[str]:
        """
        获取traceparent版本
        
        Args:
            headers: HTTP头
            
        Returns:
            版本号或None
        """
        traceparent = headers.get(self.TRACEPARENT_HEADER, "")
        
        match = self.TRACEPARENT_PATTERN.match(traceparent)
        if match:
            return match.group("version")
        
        return None


class W3CTraceContextParser:
    """
    W3C Trace Context解析器
    
    用于解析和验证traceparent和tracestate。
    """
    
    @staticmethod
    def validate_trace_id(trace_id: str) -> bool:
        """
        验证trace_id
        
        Args:
            trace_id: 追踪ID
            
        Returns:
            是否有效
        """
        if not trace_id:
            return False
        
        # 移除连字符
        trace_id = trace_id.replace("-", "").lower()
        
        # 必须是32位十六进制
        if len(trace_id) != 32:
            return False
        
        # 不能全为0
        if trace_id == "0" * 32:
            return False
        
        # 必须是有效的十六进制
        try:
            int(trace_id, 16)
            return True
        except ValueError:
            return False
    
    @staticmethod
    def validate_span_id(span_id: str) -> bool:
        """
        验证span_id
        
        Args:
            span_id: Span ID
            
        Returns:
            是否有效
        """
        if not span_id:
            return False
        
        span_id = span_id.replace("-", "").lower()
        
        # 必须是16位十六进制
        if len(span_id) != 16:
            return False
        
        # 不能全为0
        if span_id == "0" * 16:
            return False
        
        try:
            int(span_id, 16)
            return True
        except ValueError:
            return False


# 便捷函数
def create_w3c_propagator() -> W3CTraceContextPropagator:
    """
    创建W3C传播器的工厂函数
    
    Returns:
        W3C传播器实例
    """
    return W3CTraceContextPropagator()


def parse_traceparent(traceparent: str) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[int]]:
    """
    解析traceparent字符串
    
    Args:
        traceparent: traceparent头值
        
    Returns:
        (version, trace_id, parent_id, flags) 元组
    """
    propagator = W3CTraceContextPropagator()
    trace_id, parent_id = propagator._parse_traceparent(traceparent)
    
    if trace_id is None:
        return None, None, None, None
    
    match = propagator.TRACEPARENT_PATTERN.match(traceparent.strip())
    if match:
        version = match.group("version")
        flags = int(match.group("flags"), 16)
        return version, trace_id, parent_id, flags
    
    return None, None, None, None