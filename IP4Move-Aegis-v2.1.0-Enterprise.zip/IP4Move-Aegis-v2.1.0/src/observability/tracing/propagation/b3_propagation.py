"""
B3传播模块

实现B3（Zipkin）传播格式，支持X-B3-*头的解析与注入。
参考: https://github.com/openzipkin/b3-propagation
"""

import re
from typing import Optional, Dict, Tuple, List
import logging

logger = logging.getLogger(__name__)


class B3Propagator:
    """
    B3传播器
    
    实现B3传播格式，用于在HTTP请求头中传播追踪上下文。
    这是Zipkin使用的传播格式。
    
    B3头包括:
    - X-B3-TraceId: 追踪ID（64位或128位十六进制）
    - X-B3-SpanId: Span ID（64位十六进制）
    - X-B3-ParentSpanId: 父Span ID（可选）
    - X-B3-Sampled: 采样标志（0或1，或true/false）
    - X-B3-Flags: 调试标志（可选）
    
    也支持单头格式:
    - b3: traceId-spanId-sampled-parentSpanId
    
    Example:
        >>> propagator = B3Propagator()
        >>> # 提取上下文
        >>> trace_id, span_id = propagator.extract(headers)
        >>> # 注入上下文
        >>> headers = propagator.inject(headers, trace_id, span_id)
    """
    
    # 多头部格式
    TRACE_ID_HEADER = "X-B3-TraceId"
    SPAN_ID_HEADER = "X-B3-SpanId"
    PARENT_SPAN_ID_HEADER = "X-B3-ParentSpanId"
    SAMPLED_HEADER = "X-B3-Sampled"
    FLAGS_HEADER = "X-B3-Flags"
    
    # 单头部格式
    B3_HEADER = "b3"
    
    # 标志
    FLAG_SAMPLED = 0x01
    FLAG_DEBUG = 0x02
    
    def __init__(self, single_header: bool = False):
        """
        初始化B3传播器
        
        Args:
            single_header: 是否使用单头部格式（b3头）
        """
        self.single_header = single_header
    
    def extract(self, headers: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
        """
        从HTTP头中提取追踪上下文
        
        Args:
            headers: HTTP请求头字典
            
        Returns:
            (trace_id, parent_span_id) 元组
        """
        if self.single_header:
            return self._extract_single_header(headers)
        else:
            return self._extract_multi_header(headers)
    
    def _extract_multi_header(self, headers: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
        """从多头部格式提取"""
        trace_id = headers.get(self.TRACE_ID_HEADER)
        span_id = headers.get(self.SPAN_ID_HEADER)
        
        if not trace_id or not span_id:
            logger.debug("Missing B3 headers")
            return None, None
        
        # 验证格式
        if not self._is_valid_trace_id(trace_id):
            logger.warning(f"Invalid trace_id: {trace_id}")
            return None, None
        
        if not self._is_valid_span_id(span_id):
            logger.warning(f"Invalid span_id: {span_id}")
            return None, None
        
        logger.debug(f"Extracted trace_id={trace_id}, span_id={span_id}")
        
        return trace_id, span_id
    
    def _extract_single_header(self, headers: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
        """从单头部格式提取"""
        b3_value = headers.get(self.B3_HEADER)
        
        if not b3_value:
            return None, None
        
        # 解析b3头: traceId-spanId-sampled-parentSpanId
        # 或: traceId-spanId-sampled
        # 或: 0（表示不采样）
        
        if b3_value == "0":
            logger.debug("B3 header indicates not sampled")
            return None, None
        
        parts = b3_value.split("-")
        
        if len(parts) < 2:
            logger.warning(f"Invalid b3 header format: {b3_value}")
            return None, None
        
        trace_id = parts[0]
        span_id = parts[1]
        
        if not self._is_valid_trace_id(trace_id):
            logger.warning(f"Invalid trace_id in b3 header: {trace_id}")
            return None, None
        
        if not self._is_valid_span_id(span_id):
            logger.warning(f"Invalid span_id in b3 header: {span_id}")
            return None, None
        
        return trace_id, span_id
    
    def inject(
        self,
        headers: Dict[str, str],
        trace_id: str,
        span_id: str,
        parent_span_id: Optional[str] = None,
        sampled: bool = True,
        debug: bool = False,
    ) -> Dict[str, str]:
        """
        将追踪上下文注入到HTTP头
        
        Args:
            headers: 原始HTTP头字典
            trace_id: 追踪ID
            span_id: Span ID
            parent_span_id: 父Span ID
            sampled: 是否采样
            debug: 是否调试模式
            
        Returns:
            注入追踪上下文后的HTTP头字典
        """
        # 格式化ID
        trace_id = self._format_trace_id(trace_id)
        span_id = self._format_span_id(span_id)
        
        new_headers = headers.copy()
        
        if self.single_header:
            # 单头部格式
            parts = [trace_id, span_id]
            
            if debug:
                parts.append("d")
            elif sampled:
                parts.append("1")
            else:
                parts.append("0")
            
            if parent_span_id:
                parts.append(self._format_span_id(parent_span_id))
            
            new_headers[self.B3_HEADER] = "-".join(parts)
        else:
            # 多头部格式
            new_headers[self.TRACE_ID_HEADER] = trace_id
            new_headers[self.SPAN_ID_HEADER] = span_id
            
            if parent_span_id:
                new_headers[self.PARENT_SPAN_ID_HEADER] = self._format_span_id(parent_span_id)
            
            if debug:
                new_headers[self.FLAGS_HEADER] = "1"
                new_headers[self.SAMPLED_HEADER] = "1"
            elif sampled:
                new_headers[self.SAMPLED_HEADER] = "1"
            else:
                new_headers[self.SAMPLED_HEADER] = "0"
        
        logger.debug(f"Injected B3 context: trace_id={trace_id}, span_id={span_id}")
        
        return new_headers
    
    def _format_trace_id(self, trace_id: str) -> str:
        """格式化trace_id"""
        trace_id = trace_id.replace("-", "").lower()
        
        # B3支持64位或128位
        if len(trace_id) > 32:
            trace_id = trace_id[-32:]
        
        return trace_id
    
    def _format_span_id(self, span_id: str) -> str:
        """格式化span_id（B3使用64位）"""
        span_id = span_id.replace("-", "").lower()
        
        # B3使用64位span_id
        if len(span_id) > 16:
            span_id = span_id[-16:]
        elif len(span_id) < 16:
            span_id = span_id.zfill(16)
        
        return span_id
    
    def _is_valid_trace_id(self, trace_id: str) -> bool:
        """验证trace_id"""
        if not trace_id:
            return False
        
        trace_id = trace_id.replace("-", "").lower()
        
        # 必须是16位（64位）或32位（128位）十六进制
        if len(trace_id) not in [16, 32]:
            return False
        
        try:
            int(trace_id, 16)
            return True
        except ValueError:
            return False
    
    def _is_valid_span_id(self, span_id: str) -> bool:
        """验证span_id"""
        if not span_id:
            return False
        
        span_id = span_id.replace("-", "").lower()
        
        # 必须是16位（64位）十六进制
        if len(span_id) != 16:
            return False
        
        try:
            int(span_id, 16)
            return True
        except ValueError:
            return False
    
    def is_sampled(self, headers: Dict[str, str]) -> bool:
        """
        检查是否采样
        
        Args:
            headers: HTTP头
            
        Returns:
            是否采样
        """
        if self.single_header:
            b3_value = headers.get(self.B3_HEADER, "")
            if b3_value == "0":
                return False
            
            parts = b3_value.split("-")
            if len(parts) >= 3:
                sampled = parts[2]
                return sampled in ["1", "d", "true"]
        else:
            sampled = headers.get(self.SAMPLED_HEADER)
            if sampled:
                return sampled in ["1", "true", "d"]
        
        return False
    
    def is_debug(self, headers: Dict[str, str]) -> bool:
        """
        检查是否调试模式
        
        Args:
            headers: HTTP头
            
        Returns:
            是否调试模式
        """
        if self.single_header:
            b3_value = headers.get(self.B3_HEADER, "")
            parts = b3_value.split("-")
            if len(parts) >= 3:
                return parts[2] == "d"
        else:
            flags = headers.get(self.FLAGS_HEADER)
            if flags:
                return flags == "1"
        
        return False


class B3MultiPropagator(B3Propagator):
    """B3多头部格式传播器"""
    
    def __init__(self):
        super().__init__(single_header=False)


class B3SinglePropagator(B3Propagator):
    """B3单头部格式传播器"""
    
    def __init__(self):
        super().__init__(single_header=True)


# 便捷函数
def create_b3_propagator(single_header: bool = False) -> B3Propagator:
    """
    创建B3传播器的工厂函数
    
    Args:
        single_header: 是否使用单头部格式
        
    Returns:
        B3传播器实例
    """
    return B3Propagator(single_header)


def create_b3_multi_propagator() -> B3MultiPropagator:
    """
    创建B3多头部格式传播器
    
    Returns:
        B3多头部传播器实例
    """
    return B3MultiPropagator()


def create_b3_single_propagator() -> B3SinglePropagator:
    """
    创建B3单头部格式传播器
    
    Returns:
        B3单头部传播器实例
    """
    return B3SinglePropagator()