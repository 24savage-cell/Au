"""
Jaeger传播模块

实现Jaeger传播格式，支持Uber-Jaeger头的解析与注入。
参考: https://www.jaegertracing.io/docs/1.50/client-libraries/#propagation-format
"""

import base64
import struct
from typing import Optional, Dict, Tuple, List, Union
import logging

logger = logging.getLogger(__name__)


class JaegerPropagator:
    """
    Jaeger传播器
    
    实现Jaeger传播格式，用于在HTTP请求头中传播追踪上下文。
    
    Jaeger使用uber-trace-id头，格式为:
    {trace-id}:{span-id}:{parent-span-id}:{flags}
    
    其中:
    - trace-id: 64位或128位十六进制
    - span-id: 64位十六进制
    - parent-span-id: 64位十六进制（0表示无父span）
    - flags: 8位十六进制（1表示采样）
    
    Example:
        >>> propagator = JaegerPropagator()
        >>> # 提取上下文
        >>> trace_id, span_id = propagator.extract(headers)
        >>> # 注入上下文
        >>> headers = propagator.inject(headers, trace_id, span_id)
    """
    
    # Jaeger头名称
    TRACE_ID_HEADER = "uber-trace-id"
    BAGGAGE_HEADER_PREFIX = "uberctx-"
    
    # 标志位
    FLAG_SAMPLED = 0x01
    FLAG_DEBUG = 0x02
    
    def __init__(self):
        """初始化Jaeger传播器"""
        pass
    
    def extract(self, headers: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
        """
        从HTTP头中提取追踪上下文
        
        Args:
            headers: HTTP请求头字典
            
        Returns:
            (trace_id, parent_span_id) 元组
        """
        trace_id_header = headers.get(self.TRACE_ID_HEADER)
        
        if not trace_id_header:
            logger.debug("No uber-trace-id header found")
            return None, None
        
        return self._parse_trace_id_header(trace_id_header)
    
    def _parse_trace_id_header(self, header_value: str) -> Tuple[Optional[str], Optional[str]]:
        """
        解析uber-trace-id头
        
        Args:
            header_value: 头值
            
        Returns:
            (trace_id, parent_span_id) 元组
        """
        # 格式: {trace-id}:{span-id}:{parent-span-id}:{flags}
        parts = header_value.split(":")
        
        if len(parts) != 4:
            logger.warning(f"Invalid uber-trace-id format: {header_value}")
            return None, None
        
        trace_id, span_id, parent_span_id, flags = parts
        
        # 验证trace_id
        if not self._is_valid_trace_id(trace_id):
            logger.warning(f"Invalid trace_id: {trace_id}")
            return None, None
        
        # 验证span_id
        if not self._is_valid_span_id(span_id):
            logger.warning(f"Invalid span_id: {span_id}")
            return None, None
        
        # parent_span_id为0表示无父span
        if parent_span_id == "0":
            parent_span_id = None
        elif not self._is_valid_span_id(parent_span_id):
            logger.warning(f"Invalid parent_span_id: {parent_span_id}")
            parent_span_id = None
        
        logger.debug(f"Extracted trace_id={trace_id}, span_id={span_id}")
        
        return trace_id, span_id
    
    def inject(
        self,
        headers: Dict[str, str],
        trace_id: str,
        span_id: str,
        parent_span_id: Optional[str] = None,
        sampled: bool = True,
        debug: bool = False,
    ) -> Dict[str, str]:
        """
        将追踪上下文注入到HTTP头
        
        Args:
            headers: 原始HTTP头字典
            trace_id: 追踪ID
            span_id: Span ID
            parent_span_id: 父Span ID
            sampled: 是否采样
            debug: 是否调试模式
            
        Returns:
            注入追踪上下文后的HTTP头字典
        """
        # 格式化ID
        trace_id = self._format_trace_id(trace_id)
        span_id = self._format_span_id(span_id)
        parent_id = self._format_span_id(parent_span_id) if parent_span_id else "0"
        
        # 计算flags
        flags = 0
        if sampled:
            flags |= self.FLAG_SAMPLED
        if debug:
            flags |= self.FLAG_DEBUG
        
        # 构建header值
        trace_id_header = f"{trace_id}:{span_id}:{parent_id}:{flags:02x}"
        
        new_headers = headers.copy()
        new_headers[self.TRACE_ID_HEADER] = trace_id_header
        
        logger.debug(f"Injected Jaeger context: {trace_id_header}")
        
        return new_headers
    
    def _format_trace_id(self, trace_id: str) -> str:
        """格式化trace_id"""
        trace_id = trace_id.replace("-", "").lower()
        
        # Jaeger支持64位或128位
        if len(trace_id) > 32:
            trace_id = trace_id[-32:]
        elif len(trace_id) < 16:
            trace_id = trace_id.zfill(16)
        
        return trace_id
    
    def _format_span_id(self, span_id: str) -> str:
        """格式化span_id（Jaeger使用64位）"""
        span_id = span_id.replace("-", "").lower()
        
        if len(span_id) > 16:
            span_id = span_id[-16:]
        elif len(span_id) < 16:
            span_id = span_id.zfill(16)
        
        return span_id
    
    def _is_valid_trace_id(self, trace_id: str) -> bool:
        """验证trace_id"""
        if not trace_id:
            return False
        
        trace_id = trace_id.replace("-", "").lower()
        
        # 必须是16位（64位）或32位（128位）十六进制
        if len(trace_id) not in [16, 32]:
            return False
        
        try:
            int(trace_id, 16)
            return True
        except ValueError:
            return False
    
    def _is_valid_span_id(self, span_id: str) -> bool:
        """验证span_id"""
        if not span_id:
            return False
        
        span_id = span_id.replace("-", "").lower()
        
        # 必须是16位（64位）十六进制
        if len(span_id) != 16:
            return False
        
        try:
            int(span_id, 16)
            return True
        except ValueError:
            return False
    
    def extract_baggage(self, headers: Dict[str, str]) -> Dict[str, str]:
        """
        提取 baggage（ baggage 是在 span 之间传递的键值对）
        
        Args:
            headers: HTTP请求头
            
        Returns:
            baggage字典
        """
        baggage = {}
        
        for key, value in headers.items():
            if key.lower().startswith(self.BAGGAGE_HEADER_PREFIX):
                # 提取 baggage 键名
                baggage_key = key[len(self.BAGGAGE_HEADER_PREFIX):]
                baggage[baggage_key] = value
        
        return baggage
    
    def inject_baggage(
        self,
        headers: Dict[str, str],
        baggage: Dict[str, str],
    ) -> Dict[str, str]:
        """
        注入 baggage
        
        Args:
            headers: HTTP头
            baggage: baggage字典
            
        Returns:
            更新后的HTTP头
        """
        new_headers = headers.copy()
        
        for key, value in baggage.items():
            header_key = f"{self.BAGGAGE_HEADER_PREFIX}{key}"
            new_headers[header_key] = value
        
        return new_headers
    
    def is_sampled(self, headers: Dict[str, str]) -> bool:
        """
        检查是否采样
        
        Args:
            headers: HTTP头
            
        Returns:
            是否采样
        """
        trace_id_header = headers.get(self.TRACE_ID_HEADER, "")
        parts = trace_id_header.split(":")
        
        if len(parts) != 4:
            return False
        
        try:
            flags = int(parts[3], 16)
            return bool(flags & self.FLAG_SAMPLED)
        except ValueError:
            return False
    
    def is_debug(self, headers: Dict[str, str]) -> bool:
        """
        检查是否调试模式
        
        Args:
            headers: HTTP头
            
        Returns:
            是否调试模式
        """
        trace_id_header = headers.get(self.TRACE_ID_HEADER, "")
        parts = trace_id_header.split(":")
        
        if len(parts) != 4:
            return False
        
        try:
            flags = int(parts[3], 16)
            return bool(flags & self.FLAG_DEBUG)
        except ValueError:
            return False
    
    def get_flags(self, headers: Dict[str, str]) -> Optional[int]:
        """
        获取flags
        
        Args:
            headers: HTTP头
            
        Returns:
            flags值或None
        """
        trace_id_header = headers.get(self.TRACE_ID_HEADER, "")
        parts = trace_id_header.split(":")
        
        if len(parts) != 4:
            return None
        
        try:
            return int(parts[3], 16)
        except ValueError:
            return None


class JaegerBinaryPropagator:
    """
    Jaeger二进制传播器
    
    用于在二进制协议中传播追踪上下文。
    """
    
    def __init__(self):
        """初始化二进制传播器"""
        pass
    
    def inject(
        self,
        trace_id: str,
        span_id: str,
        parent_span_id: Optional[str] = None,
        sampled: bool = True,
    ) -> bytes:
        """
        将追踪上下文序列化为二进制格式
        
        Args:
            trace_id: 追踪ID
            span_id: Span ID
            parent_span_id: 父Span ID
            sampled: 是否采样
            
        Returns:
            二进制数据
        """
        # 简化的二进制格式实现
        # 实际Jaeger使用Thrift或Protobuf
        
        trace_id_bytes = bytes.fromhex(trace_id.replace("-", ""))
        span_id_bytes = bytes.fromhex(span_id.replace("-", ""))
        parent_id_bytes = bytes.fromhex(parent_span_id.replace("-", "")) if parent_span_id else b'\x00' * 8
        
        flags = 1 if sampled else 0
        
        # 格式: [trace_id(16 bytes)][span_id(8 bytes)][parent_id(8 bytes)][flags(1 byte)]
        data = trace_id_bytes + span_id_bytes + parent_id_bytes + bytes([flags])
        
        return data
    
    def extract(self, data: bytes) -> Tuple[Optional[str], Optional[str]]:
        """
        从二进制数据中提取追踪上下文
        
        Args:
            data: 二进制数据
            
        Returns:
            (trace_id, span_id) 元组
        """
        if len(data) < 25:  # 最小长度
            return None, None
        
        trace_id = data[:16].hex()
        span_id = data[16:24].hex()
        
        return trace_id, span_id


# 便捷函数
def create_jaeger_propagator() -> JaegerPropagator:
    """
    创建Jaeger传播器的工厂函数
    
    Returns:
        Jaeger传播器实例
    """
    return JaegerPropagator()


def create_jaeger_binary_propagator() -> JaegerBinaryPropagator:
    """
    创建Jaeger二进制传播器的工厂函数
    
    Returns:
        Jaeger二进制传播器实例
    """
    return JaegerBinaryPropagator()


def parse_jaeger_header(header_value: str) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[int]]:
    """
    解析Jaeger头值
    
    Args:
        header_value: uber-trace-id头值
        
    Returns:
        (trace_id, span_id, parent_span_id, flags) 元组
    """
    propagator = JaegerPropagator()
    trace_id, span_id = propagator._parse_trace_id_header(header_value)
    
    if trace_id is None:
        return None, None, None, None
    
    parts = header_value.split(":")
    if len(parts) == 4:
        parent_id = parts[2] if parts[2] != "0" else None
        try:
            flags = int(parts[3], 16)
            return trace_id, span_id, parent_id, flags
        except ValueError:
            return trace_id, span_id, parent_id, None
    
    return trace_id, span_id, None, None