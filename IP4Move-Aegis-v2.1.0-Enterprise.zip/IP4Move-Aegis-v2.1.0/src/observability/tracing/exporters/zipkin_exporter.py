"""
Zipkin导出器模块

提供将追踪数据导出到Zipkin后端的实现，支持JSON格式和批量API。
"""

import json
import asyncio
import logging
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, asdict
from datetime import datetime
import time

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class ZipkinSpan:
    """Zipkin格式的Span"""
    traceId: str
    id: str
    parentId: Optional[str]
    name: str
    timestamp: int  # 微秒时间戳
    duration: int  # 微秒
    kind: Optional[str]  # CLIENT, SERVER, PRODUCER, CONSUMER
    localEndpoint: Optional[Dict[str, Any]]
    remoteEndpoint: Optional[Dict[str, Any]]
    tags: Dict[str, str]
    annotations: List[Dict[str, Any]]


class ZipkinExporter:
    """
    Zipkin导出器
    
    将追踪数据以JSON格式导出到Zipkin后端，支持批量API。
    
    Example:
        >>> exporter = ZipkinExporter(
        ...     endpoint_url="http://zipkin:9411/api/v2/spans",
        ...     service_name="my-service"
        ... )
        >>> await exporter.start()
        >>> await exporter.export(span)
        >>> await exporter.stop()
    """
    
    def __init__(
        self,
        endpoint_url: str = "http://localhost:9411/api/v2/spans",
        service_name: str = "unknown-service",
        service_port: int = 0,
        ipv4: Optional[str] = None,
        ipv6: Optional[str] = None,
        batch_size: int = 100,
        flush_interval: float = 1.0,
        max_queue_size: int = 1000,
        timeout: float = 10.0,
    ):
        """
        初始化Zipkin导出器
        
        Args:
            endpoint_url: Zipkin API端点URL
            service_name: 服务名称
            service_port: 服务端口号
            ipv4: IPv4地址
            ipv6: IPv6地址
            batch_size: 批量发送大小
            flush_interval: 自动刷新间隔（秒）
            max_queue_size: 最大队列大小
            timeout: HTTP请求超时（秒）
        """
        self.endpoint_url = endpoint_url
        self.service_name = service_name
        self.service_port = service_port
        self.ipv4 = ipv4
        self.ipv6 = ipv6
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.max_queue_size = max_queue_size
        self.timeout = timeout
        
        self._span_queue: List[Any] = []
        self._lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None
        self._running = False
        self._http_session: Optional[Any] = None
        
        # 本地端点信息（缓存）
        self._local_endpoint: Dict[str, Any] = self._build_local_endpoint()
    
    async def start(self) -> None:
        """启动导出器"""
        self._running = True
        
        try:
            import aiohttp
            self._http_session = aiohttp.ClientSession()
        except ImportError:
            logger.error("aiohttp is required for Zipkin exporter")
            raise
        
        # 启动定时刷新任务
        self._flush_task = asyncio.create_task(self._periodic_flush())
        
        logger.info(f"Zipkin exporter started, endpoint: {self.endpoint_url}")
    
    async def stop(self) -> None:
        """停止导出器"""
        self._running = False
        
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        
        # 刷新剩余数据
        await self._flush()
        
        if self._http_session:
            await self._http_session.close()
        
        logger.info("Zipkin exporter stopped")
    
    async def export(self, span: Any) -> bool:
        """
        导出单个Span
        
        Args:
            span: 要导出的Span对象
            
        Returns:
            是否成功添加到队列
        """
        async with self._lock:
            if len(self._span_queue) >= self.max_queue_size:
                logger.warning("Span queue is full, dropping span")
                return False
            
            self._span_queue.append(span)
            
            # 达到批量大小则立即发送
            if len(self._span_queue) >= self.batch_size:
                asyncio.create_task(self._flush())
        
        return True
    
    async def export_batch(self, spans: List[Any]) -> bool:
        """
        批量导出Span
        
        Args:
            spans: Span列表
            
        Returns:
            是否成功
        """
        async with self._lock:
            available_space = self.max_queue_size - len(self._span_queue)
            spans_to_add = spans[:available_space]
            self._span_queue.extend(spans_to_add)
            
            if len(spans) > available_space:
                logger.warning(f"Dropped {len(spans) - available_space} spans due to queue full")
        
        return True
    
    async def _periodic_flush(self) -> None:
        """定时刷新队列"""
        while self._running:
            try:
                await asyncio.sleep(self.flush_interval)
                await self._flush()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic flush: {e}")
    
    async def _flush(self) -> None:
        """刷新队列中的所有Span"""
        spans_to_send: List[Any] = []
        
        async with self._lock:
            if self._span_queue:
                spans_to_send = self._span_queue.copy()
                self._span_queue.clear()
        
        if not spans_to_send:
            return
        
        try:
            await self._send_http(spans_to_send)
        except Exception as e:
            logger.error(f"Failed to send spans: {e}")
    
    async def _send_http(self, spans: List[Any]) -> None:
        """通过HTTP发送Span"""
        if not self._http_session:
            return
        
        # 转换为Zipkin格式
        zipkin_spans = [self._convert_to_zipkin(span) for span in spans]
        
        # 序列化为JSON
        json_data = json.dumps([asdict(span) for span in zipkin_spans])
        
        try:
            async with self._http_session.post(
                self.endpoint_url,
                data=json_data,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            ) as response:
                if response.status in [200, 202]:
                    logger.debug(f"Sent {len(spans)} spans to Zipkin")
                else:
                    response_text = await response.text()
                    logger.error(f"Zipkin API error: {response.status} - {response_text}")
        except asyncio.TimeoutError:
            logger.error("Timeout sending spans to Zipkin")
            raise
        except Exception as e:
            logger.error(f"HTTP request failed: {e}")
            raise
    
    def _convert_to_zipkin(self, span: Any) -> ZipkinSpan:
        """将内部Span转换为Zipkin格式"""
        # 提取trace_id（Zipkin支持64位或128位）
        trace_id = getattr(span, 'trace_id', '')
        
        # 提取span_id（Zipkin使用64位或128位十六进制）
        span_id = getattr(span, 'span_id', '')
        
        # 提取parent_id
        parent_id = getattr(span, 'parent_id', None)
        
        # 确定Span类型
        kind = self._get_span_kind(span)
        
        # 构建tags
        tags: Dict[str, str] = {}
        attributes = getattr(span, 'attributes', {})
        for key, value in attributes.items():
            tags[key] = str(value)
        
        # 添加状态信息
        status = getattr(span, 'status', None)
        if status:
            tags["status"] = str(status)
        status_message = getattr(span, 'status_message', '')
        if status_message:
            tags["status.message"] = status_message
        
        # 构建annotations（事件）
        annotations: List[Dict[str, Any]] = []
        events = getattr(span, 'events', [])
        for event in events:
            annotations.append({
                "timestamp": event.get('timestamp', 0),
                "value": event.get('name', '')
            })
        
        # 构建remoteEndpoint
        remote_endpoint = None
        if kind == "CLIENT":
            peer_name = attributes.get('net.peer.name')
            peer_port = attributes.get('net.peer.port')
            if peer_name:
                remote_endpoint = {
                    "serviceName": peer_name,
                    "port": peer_port
                }
        
        return ZipkinSpan(
            traceId=trace_id,
            id=span_id,
            parentId=parent_id,
            name=getattr(span, 'name', 'unknown'),
            timestamp=getattr(span, 'start_time', int(time.time() * 1e6)),
            duration=int(getattr(span, 'duration_ms', lambda: 0)() * 1000),
            kind=kind,
            localEndpoint=self._local_endpoint,
            remoteEndpoint=remote_endpoint,
            tags=tags,
            annotations=annotations
        )
    
    def _get_span_kind(self, span: Any) -> Optional[str]:
        """获取Zipkin Span类型"""
        kind = getattr(span, 'kind', None)
        
        if kind is None:
            return None
        
        # 转换内部kind为Zipkin格式
        kind_map = {
            'server': 'SERVER',
            'client': 'CLIENT',
            'producer': 'PRODUCER',
            'consumer': 'CONSUMER',
        }
        
        kind_str = str(kind).lower()
        return kind_map.get(kind_str)
    
    def _build_local_endpoint(self) -> Dict[str, Any]:
        """构建本地端点信息"""
        endpoint: Dict[str, Any] = {
            "serviceName": self.service_name
        }
        
        if self.ipv4:
            endpoint["ipv4"] = self.ipv4
        
        if self.ipv6:
            endpoint["ipv6"] = self.ipv6
        
        if self.service_port:
            endpoint["port"] = self.service_port
        
        return endpoint


class ZipkinKafkaExporter:
    """
    Zipkin Kafka导出器
    
    通过Kafka将追踪数据导出到Zipkin。
    """
    
    def __init__(
        self,
        bootstrap_servers: List[str],
        topic: str = "zipkin",
        service_name: str = "unknown-service",
    ):
        """
        初始化Kafka导出器
        
        Args:
            bootstrap_servers: Kafka服务器列表
            topic: Kafka主题
            service_name: 服务名称
        """
        self.bootstrap_servers = bootstrap_servers
        self.topic = topic
        self.service_name = service_name
        self._producer: Optional[Any] = None
    
    async def start(self) -> None:
        """启动导出器"""
        try:
            from aiokafka import AIOKafkaProducer
            
            self._producer = AIOKafkaProducer(
                bootstrap_servers=self.bootstrap_servers,
                value_serializer=lambda v: json.dumps(v).encode('utf-8')
            )
            await self._producer.start()
            
            logger.info(f"Zipkin Kafka exporter started, topic: {self.topic}")
        except ImportError:
            logger.error("aiokafka is required for Kafka export")
            raise
    
    async def stop(self) -> None:
        """停止导出器"""
        if self._producer:
            await self._producer.stop()
        logger.info("Zipkin Kafka exporter stopped")
    
    async def export(self, span: Any) -> bool:
        """导出Span到Kafka"""
        if not self._producer:
            return False
        
        try:
            zipkin_span = self._convert_to_zipkin(span)
            await self._producer.send(self.topic, zipkin_span.__dict__)
            return True
        except Exception as e:
            logger.error(f"Failed to send span to Kafka: {e}")
            return False
    
    def _convert_to_zipkin(self, span: Any) -> ZipkinSpan:
        """转换为Zipkin格式"""
        # 简化实现，复用ZipkinExporter的逻辑
        exporter = ZipkinExporter(service_name=self.service_name)
        return exporter._convert_to_zipkin(span)


# 便捷函数
def create_zipkin_exporter(
    endpoint_url: str = "http://localhost:9411/api/v2/spans",
    service_name: str = "unknown-service",
) -> ZipkinExporter:
    """
    创建Zipkin导出器的工厂函数
    
    Args:
        endpoint_url: Zipkin API端点
        service_name: 服务名称
        
    Returns:
        Zipkin导出器实例
    """
    return ZipkinExporter(
        endpoint_url=endpoint_url,
        service_name=service_name
    )
