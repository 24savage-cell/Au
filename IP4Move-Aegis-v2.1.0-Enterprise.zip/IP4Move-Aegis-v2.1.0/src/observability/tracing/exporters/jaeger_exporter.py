"""
Jaeger导出器模块

提供将追踪数据导出到Jaeger后端的实现，支持UDP和HTTP传输。
"""

import json
import struct
import socket
import asyncio
import logging
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, asdict
from datetime import datetime
import time

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class JaegerSpan:
    """Jaeger格式的Span"""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str]
    operation_name: str
    start_time: int  # 微秒时间戳
    duration: int  # 微秒
    flags: int
    tags: List[Dict[str, Any]]
    logs: List[Dict[str, Any]]
    references: List[Dict[str, Any]]


class JaegerExporter:
    """
    Jaeger导出器
    
    将追踪数据导出到Jaeger后端，支持UDP和HTTP两种传输方式。
    
    Example:
        >>> # UDP方式（推荐用于高性能场景）
        >>> exporter = JaegerExporter(
        ...     agent_host="localhost",
        ...     agent_port=6831,
        ...     protocol="udp"
        ... )
        >>> 
        >>> # HTTP方式（支持直接发送到Collector）
        >>> exporter = JaegerExporter(
        ...     collector_url="http://jaeger-collector:14268/api/traces",
        ...     protocol="http"
        ... )
        >>> 
        >>> await exporter.export(span)
    """
    
    # Thrift compact协议常量
    THRIFT_COMPACT_PROTOCOL = 0x82
    EMIT_BATCH_OVERHEAD = 30  # Thrift emitBatch开销
    
    def __init__(
        self,
        service_name: str = "unknown-service",
        agent_host: str = "localhost",
        agent_port: int = 6831,
        collector_url: Optional[str] = None,
        protocol: str = "udp",
        batch_size: int = 100,
        flush_interval: float = 1.0,
        max_queue_size: int = 1000,
    ):
        """
        初始化Jaeger导出器
        
        Args:
            service_name: 服务名称
            agent_host: Jaeger Agent主机（UDP模式）
            agent_port: Jaeger Agent端口（UDP模式）
            collector_url: Jaeger Collector URL（HTTP模式）
            protocol: 传输协议（"udp"或"http"）
            batch_size: 批量发送大小
            flush_interval: 自动刷新间隔（秒）
            max_queue_size: 最大队列大小
        """
        self.service_name = service_name
        self.agent_host = agent_host
        self.agent_port = agent_port
        self.collector_url = collector_url
        self.protocol = protocol.lower()
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.max_queue_size = max_queue_size
        
        self._span_queue: List[Any] = []
        self._lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None
        self._running = False
        
        # UDP socket
        self._udp_socket: Optional[socket.socket] = None
        
        # HTTP session
        self._http_session: Optional[Any] = None
    
    async def start(self) -> None:
        """启动导出器"""
        self._running = True
        
        if self.protocol == "udp":
            self._udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        elif self.protocol == "http":
            try:
                import aiohttp
                self._http_session = aiohttp.ClientSession()
            except ImportError:
                logger.error("aiohttp is required for HTTP protocol")
                raise
        
        # 启动定时刷新任务
        self._flush_task = asyncio.create_task(self._periodic_flush())
        
        logger.info(f"Jaeger exporter started with {self.protocol} protocol")
    
    async def stop(self) -> None:
        """停止导出器"""
        self._running = False
        
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        
        # 刷新剩余数据
        await self._flush()
        
        if self._udp_socket:
            self._udp_socket.close()
        
        if self._http_session:
            await self._http_session.close()
        
        logger.info("Jaeger exporter stopped")
    
    async def export(self, span: Any) -> bool:
        """
        导出单个Span
        
        Args:
            span: 要导出的Span对象
            
        Returns:
            是否成功添加到队列
        """
        async with self._lock:
            if len(self._span_queue) >= self.max_queue_size:
                logger.warning("Span queue is full, dropping span")
                return False
            
            self._span_queue.append(span)
            
            # 达到批量大小则立即发送
            if len(self._span_queue) >= self.batch_size:
                asyncio.create_task(self._flush())
        
        return True
    
    async def export_batch(self, spans: List[Any]) -> bool:
        """
        批量导出Span
        
        Args:
            spans: Span列表
            
        Returns:
            是否成功
        """
        async with self._lock:
            available_space = self.max_queue_size - len(self._span_queue)
            spans_to_add = spans[:available_space]
            self._span_queue.extend(spans_to_add)
            
            if len(spans) > available_space:
                logger.warning(f"Dropped {len(spans) - available_space} spans due to queue full")
        
        return True
    
    async def _periodic_flush(self) -> None:
        """定时刷新队列"""
        while self._running:
            try:
                await asyncio.sleep(self.flush_interval)
                await self._flush()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic flush: {e}")
    
    async def _flush(self) -> None:
        """刷新队列中的所有Span"""
        spans_to_send: List[Any] = []
        
        async with self._lock:
            if self._span_queue:
                spans_to_send = self._span_queue.copy()
                self._span_queue.clear()
        
        if not spans_to_send:
            return
        
        try:
            if self.protocol == "udp":
                await self._send_udp(spans_to_send)
            elif self.protocol == "http":
                await self._send_http(spans_to_send)
        except Exception as e:
            logger.error(f"Failed to send spans: {e}")
    
    async def _send_udp(self, spans: List[Any]) -> None:
        """通过UDP发送Span"""
        if not self._udp_socket:
            return
        
        # 转换为Jaeger Thrift格式
        jaeger_spans = [self._convert_to_jaeger(span) for span in spans]
        
        # 序列化为Thrift compact格式
        thrift_data = self._serialize_thrift_compact(jaeger_spans)
        
        # 发送数据
        try:
            self._udp_socket.sendto(thrift_data, (self.agent_host, self.agent_port))
            logger.debug(f"Sent {len(spans)} spans via UDP")
        except socket.error as e:
            logger.error(f"UDP send failed: {e}")
            raise
    
    async def _send_http(self, spans: List[Any]) -> None:
        """通过HTTP发送Span"""
        if not self._http_session or not self.collector_url:
            return
        
        # 转换为Jaeger JSON格式
        jaeger_batch = self._convert_to_jaeger_batch(spans)
        
        try:
            async with self._http_session.post(
                self.collector_url,
                json=jaeger_batch,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status == 202:
                    logger.debug(f"Sent {len(spans)} spans via HTTP")
                else:
                    response_text = await response.text()
                    logger.error(f"HTTP send failed: {response.status} - {response_text}")
        except Exception as e:
            logger.error(f"HTTP request failed: {e}")
            raise
    
    def _convert_to_jaeger(self, span: Any) -> JaegerSpan:
        """将内部Span转换为Jaeger格式"""
        # 提取trace_id（Jaeger使用64位或128位）
        trace_id = getattr(span, 'trace_id', '')
        if len(trace_id) > 32:
            trace_id = trace_id[-32:]
        
        # 提取span_id（Jaeger使用64位）
        span_id = getattr(span, 'span_id', '')
        if len(span_id) > 16:
            span_id = span_id[-16:]
        
        # 提取parent_id
        parent_id = getattr(span, 'parent_id', None)
        if parent_id and len(parent_id) > 16:
            parent_id = parent_id[-16:]
        
        # 构建tags
        tags = []
        attributes = getattr(span, 'attributes', {})
        for key, value in attributes.items():
            tags.append({
                "key": key,
                "vType": self._get_jaeger_type(value),
                "vStr": str(value) if isinstance(value, str) else None,
                "vInt64": int(value) if isinstance(value, (int, float)) else None,
            })
        
        # 构建logs（事件）
        logs = []
        events = getattr(span, 'events', [])
        for event in events:
            logs.append({
                "timestamp": event.get('timestamp', 0),
                "fields": [{"key": "event", "vType": "STRING", "vStr": event.get('name', '')}]
            })
        
        # 构建references
        references = []
        if parent_id:
            references.append({
                "refType": "CHILD_OF",
                "traceId": trace_id,
                "spanId": parent_id
            })
        
        return JaegerSpan(
            trace_id=trace_id,
            span_id=span_id,
            parent_span_id=parent_id,
            operation_name=getattr(span, 'name', 'unknown'),
            start_time=getattr(span, 'start_time', int(time.time() * 1e6)),
            duration=int(getattr(span, 'duration_ms', lambda: 0)() * 1000),
            flags=1,  # sampled
            tags=tags,
            logs=logs,
            references=references
        )
    
    def _convert_to_jaeger_batch(self, spans: List[Any]) -> Dict[str, Any]:
        """转换为Jaeger批处理格式"""
        jaeger_spans = [self._convert_to_jaeger(span) for span in spans]
        
        return {
            "process": {
                "serviceName": self.service_name,
                "tags": [
                    {"key": "hostname", "vType": "STRING", "vStr": socket.gethostname()},
                    {"key": "ip", "vType": "STRING", "vStr": self._get_local_ip()},
                ]
            },
            "spans": [asdict(span) for span in jaeger_spans]
        }
    
    def _serialize_thrift_compact(self, spans: List[JaegerSpan]) -> bytes:
        """
        序列化为Thrift compact格式
        
        注意：这是简化的实现，实际应使用Thrift库
        """
        # 简化的Thrift compact序列化
        # 实际生产环境应使用 thriftpy2 或类似的库
        
        output = bytearray()
        
        # 写入batch header
        output.append(self.THRIFT_COMPACT_PROTOCOL)
        
        # 写入process（服务信息）
        output.extend(self._write_compact_string(self.service_name))
        
        # 写入span数量
        output.extend(self._write_compact_varint(len(spans)))
        
        for span in spans:
            # 写入trace_id
            output.extend(self._write_compact_i64(int(span.trace_id[:16], 16)))
            output.extend(self._write_compact_i64(int(span.trace_id[16:] or "0", 16)))
            
            # 写入span_id
            output.extend(self._write_compact_i64(int(span.span_id, 16)))
            
            # 写入parent_span_id
            if span.parent_span_id:
                output.extend(self._write_compact_i64(int(span.parent_span_id, 16)))
            else:
                output.extend(self._write_compact_i64(0))
            
            # 写入operation_name
            output.extend(self._write_compact_string(span.operation_name))
            
            # 写入flags
            output.append(span.flags)
            
            # 写入start_time
            output.extend(self._write_compact_i64(span.start_time))
            
            # 写入duration
            output.extend(self._write_compact_i64(span.duration))
        
        return bytes(output)
    
    def _write_compact_string(self, s: str) -> bytes:
        """写入compact字符串"""
        encoded = s.encode('utf-8')
        return self._write_compact_varint(len(encoded)) + encoded
    
    def _write_compact_varint(self, n: int) -> bytes:
        """写入compact变长整数"""
        result = bytearray()
        while n >= 0x80:
            result.append((n & 0x7f) | 0x80)
            n >>= 7
        result.append(n)
        return bytes(result)
    
    def _write_compact_i64(self, n: int) -> bytes:
        """写入compact 64位整数（使用zigzag编码）"""
        # Zigzag编码
        encoded = (n << 1) ^ (n >> 63)
        return self._write_compact_varint(encoded)
    
    def _get_jaeger_type(self, value: Any) -> str:
        """获取Jaeger类型"""
        if isinstance(value, bool):
            return "BOOL"
        elif isinstance(value, int):
            return "INT64"
        elif isinstance(value, float):
            return "DOUBLE"
        else:
            return "STRING"
    
    def _get_local_ip(self) -> str:
        """获取本地IP地址"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"


class JaegerGRPCExporter:
    """
    Jaeger gRPC导出器
    
    通过gRPC协议将追踪数据导出到Jaeger Collector。
    """
    
    def __init__(
        self,
        service_name: str = "unknown-service",
        endpoint: str = "localhost:14250",
        insecure: bool = True,
    ):
        """
        初始化gRPC导出器
        
        Args:
            service_name: 服务名称
            endpoint: Jaeger Collector gRPC端点
            insecure: 是否使用非安全连接
        """
        self.service_name = service_name
        self.endpoint = endpoint
        self.insecure = insecure
        self._channel: Optional[Any] = None
        self._stub: Optional[Any] = None
    
    async def start(self) -> None:
        """启动导出器"""
        try:
            import grpc
            
            if self.insecure:
                self._channel = grpc.aio.insecure_channel(self.endpoint)
            else:
                # 需要TLS凭证
                credentials = grpc.ssl_channel_credentials()
                self._channel = grpc.aio.secure_channel(self.endpoint, credentials)
            
            # 这里需要Jaeger的protobuf定义
            # from jaeger_client import collector_pb2_grpc
            # self._stub = collector_pb2_grpc.CollectorServiceStub(self._channel)
            
            logger.info(f"Jaeger gRPC exporter started, endpoint: {self.endpoint}")
        except ImportError:
            logger.error("grpcio is required for gRPC protocol")
            raise
    
    async def stop(self) -> None:
        """停止导出器"""
        if self._channel:
            await self._channel.close()
        logger.info("Jaeger gRPC exporter stopped")
    
    async def export(self, span: Any) -> bool:
        """导出Span"""
        # 实现gRPC导出逻辑
        # 需要Jaeger的protobuf定义
        logger.debug("gRPC export not fully implemented without protobuf definitions")
        return True


# 便捷函数
def create_jaeger_exporter(
    service_name: str = "unknown-service",
    agent_host: str = "localhost",
    agent_port: int = 6831,
    protocol: str = "udp",
) -> JaegerExporter:
    """
    创建Jaeger导出器的工厂函数
    
    Args:
        service_name: 服务名称
        agent_host: Agent主机
        agent_port: Agent端口
        protocol: 传输协议
        
    Returns:
        Jaeger导出器实例
    """
    return JaegerExporter(
        service_name=service_name,
        agent_host=agent_host,
        agent_port=agent_port,
        protocol=protocol
    )
