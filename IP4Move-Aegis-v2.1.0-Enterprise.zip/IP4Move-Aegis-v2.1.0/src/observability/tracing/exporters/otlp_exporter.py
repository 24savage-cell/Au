"""
OpenTelemetry导出器模块

提供将追踪数据导出到OpenTelemetry Collector的实现，支持OTLP/gRPC协议。
"""

import asyncio
import logging
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass
from datetime import datetime
import time

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class OTLPResource:
    """OTLP资源"""
    attributes: Dict[str, Any]


@dataclass
class OTLPSpan:
    """OTLP格式的Span"""
    trace_id: bytes
    span_id: bytes
    parent_span_id: Optional[bytes]
    name: str
    kind: int  # SpanKind enum value
    start_time_unix_nano: int
    end_time_unix_nano: int
    attributes: List[Dict[str, Any]]
    events: List[Dict[str, Any]]
    status: Dict[str, Any]


class OTLPExporter:
    """
    OpenTelemetry导出器
    
    将追踪数据以OTLP格式导出到OpenTelemetry Collector。
    支持gRPC和HTTP协议。
    
    Example:
        >>> exporter = OTLPExporter(
        ...     endpoint="http://otel-collector:4317",
        ...     service_name="my-service",
        ...     insecure=True
        ... )
        >>> await exporter.start()
        >>> await exporter.export(span)
        >>> await exporter.stop()
    """
    
    # OTLP常量
    OTLP_GRPC_DEFAULT_PORT = 4317
    OTLP_HTTP_DEFAULT_PORT = 4318
    
    # SpanKind枚举值
    SPAN_KIND_UNSPECIFIED = 0
    SPAN_KIND_INTERNAL = 1
    SPAN_KIND_SERVER = 2
    SPAN_KIND_CLIENT = 3
    SPAN_KIND_PRODUCER = 4
    SPAN_KIND_CONSUMER = 5
    
    # StatusCode枚举值
    STATUS_CODE_UNSET = 0
    STATUS_CODE_OK = 1
    STATUS_CODE_ERROR = 2
    
    def __init__(
        self,
        endpoint: str = "http://localhost:4317",
        service_name: str = "unknown-service",
        service_version: str = "1.0.0",
        insecure: bool = True,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 10.0,
        batch_size: int = 100,
        flush_interval: float = 1.0,
        max_queue_size: int = 1000,
        protocol: str = "grpc",
    ):
        """
        初始化OTLP导出器
        
        Args:
            endpoint: OTLP Collector端点
            service_name: 服务名称
            service_version: 服务版本
            insecure: 是否使用非安全连接
            headers: 额外的HTTP/gRPC头
            timeout: 请求超时（秒）
            batch_size: 批量发送大小
            flush_interval: 自动刷新间隔（秒）
            max_queue_size: 最大队列大小
            protocol: 传输协议（"grpc"或"http"）
        """
        self.endpoint = endpoint
        self.service_name = service_name
        self.service_version = service_version
        self.insecure = insecure
        self.headers = headers or {}
        self.timeout = timeout
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.max_queue_size = max_queue_size
        self.protocol = protocol.lower()
        
        self._span_queue: List[Any] = []
        self._lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None
        self._running = False
        
        # gRPC/HTTP客户端
        self._channel: Optional[Any] = None
        self._stub: Optional[Any] = None
        self._http_session: Optional[Any] = None
        
        # 资源信息（缓存）
        self._resource = self._build_resource()
    
    async def start(self) -> None:
        """启动导出器"""
        self._running = True
        
        if self.protocol == "grpc":
            await self._start_grpc()
        elif self.protocol == "http":
            await self._start_http()
        else:
            raise ValueError(f"Unsupported protocol: {self.protocol}")
        
        # 启动定时刷新任务
        self._flush_task = asyncio.create_task(self._periodic_flush())
        
        logger.info(f"OTLP exporter started, endpoint: {self.endpoint}, protocol: {self.protocol}")
    
    async def _start_grpc(self) -> None:
        """启动gRPC连接"""
        try:
            import grpc
            from grpc import aio as grpc_aio
            
            if self.insecure:
                self._channel = grpc_aio.insecure_channel(
                    self.endpoint.replace("http://", "").replace("https://", ""),
                    options=[
                        ("grpc.max_send_message_length", 50 * 1024 * 1024),
                        ("grpc.max_receive_message_length", 50 * 1024 * 1024),
                    ]
                )
            else:
                credentials = grpc.ssl_channel_credentials()
                self._channel = grpc_aio.secure_channel(
                    self.endpoint.replace("http://", "").replace("https://", ""),
                    credentials
                )
            
            # 这里需要OTLP的protobuf定义
            # from opentelemetry.proto.collector.trace.v1 import trace_service_pb2_grpc
            # self._stub = trace_service_pb2_grpc.TraceServiceStub(self._channel)
            
        except ImportError:
            logger.error("grpcio is required for gRPC protocol")
            raise
    
    async def _start_http(self) -> None:
        """启动HTTP连接"""
        try:
            import aiohttp
            self._http_session = aiohttp.ClientSession(
                headers=self.headers
            )
        except ImportError:
            logger.error("aiohttp is required for HTTP protocol")
            raise
    
    async def stop(self) -> None:
        """停止导出器"""
        self._running = False
        
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        
        # 刷新剩余数据
        await self._flush()
        
        if self._channel:
            await self._channel.close()
        
        if self._http_session:
            await self._http_session.close()
        
        logger.info("OTLP exporter stopped")
    
    async def export(self, span: Any) -> bool:
        """
        导出单个Span
        
        Args:
            span: 要导出的Span对象
            
        Returns:
            是否成功添加到队列
        """
        async with self._lock:
            if len(self._span_queue) >= self.max_queue_size:
                logger.warning("Span queue is full, dropping span")
                return False
            
            self._span_queue.append(span)
            
            # 达到批量大小则立即发送
            if len(self._span_queue) >= self.batch_size:
                asyncio.create_task(self._flush())
        
        return True
    
    async def export_batch(self, spans: List[Any]) -> bool:
        """
        批量导出Span
        
        Args:
            spans: Span列表
            
        Returns:
            是否成功
        """
        async with self._lock:
            available_space = self.max_queue_size - len(self._span_queue)
            spans_to_add = spans[:available_space]
            self._span_queue.extend(spans_to_add)
            
            if len(spans) > available_space:
                logger.warning(f"Dropped {len(spans) - available_space} spans due to queue full")
        
        return True
    
    async def _periodic_flush(self) -> None:
        """定时刷新队列"""
        while self._running:
            try:
                await asyncio.sleep(self.flush_interval)
                await self._flush()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic flush: {e}")
    
    async def _flush(self) -> None:
        """刷新队列中的所有Span"""
        spans_to_send: List[Any] = []
        
        async with self._lock:
            if self._span_queue:
                spans_to_send = self._span_queue.copy()
                self._span_queue.clear()
        
        if not spans_to_send:
            return
        
        try:
            if self.protocol == "grpc":
                await self._send_grpc(spans_to_send)
            elif self.protocol == "http":
                await self._send_http(spans_to_send)
        except Exception as e:
            logger.error(f"Failed to send spans: {e}")
    
    async def _send_grpc(self, spans: List[Any]) -> None:
        """通过gRPC发送Span"""
        # 转换为OTLP格式
        otlp_spans = [self._convert_to_otlp(span) for span in spans]
        
        # 构建ExportTraceServiceRequest
        request = self._build_export_request(otlp_spans)
        
        # 发送请求
        # 注意：这里需要OTLP的protobuf定义
        # response = await self._stub.Export(request, timeout=self.timeout)
        logger.debug(f"Would send {len(spans)} spans via gRPC (protobuf not available)")
    
    async def _send_http(self, spans: List[Any]) -> None:
        """通过HTTP发送Span"""
        if not self._http_session:
            return
        
        # 转换为OTLP JSON格式
        otlp_spans = [self._convert_to_otlp(span) for span in spans]
        request_data = self._build_export_request_json(otlp_spans)
        
        # 构建URL
        url = f"{self.endpoint}/v1/traces"
        
        try:
            import aiohttp
            
            async with self._http_session.post(
                url,
                json=request_data,
                headers={"Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            ) as response:
                if response.status == 200:
                    logger.debug(f"Sent {len(spans)} spans via HTTP")
                else:
                    response_text = await response.text()
                    logger.error(f"OTLP HTTP error: {response.status} - {response_text}")
        except asyncio.TimeoutError:
            logger.error("Timeout sending spans to OTLP collector")
            raise
        except Exception as e:
            logger.error(f"HTTP request failed: {e}")
            raise
    
    def _convert_to_otlp(self, span: Any) -> OTLPSpan:
        """将内部Span转换为OTLP格式"""
        # 提取trace_id（OTLP使用16字节）
        trace_id = getattr(span, 'trace_id', '')
        trace_id_bytes = self._hex_to_bytes(trace_id, 16)
        
        # 提取span_id（OTLP使用8字节）
        span_id = getattr(span, 'span_id', '')
        span_id_bytes = self._hex_to_bytes(span_id, 8)
        
        # 提取parent_id
        parent_id = getattr(span, 'parent_id', None)
        parent_id_bytes = self._hex_to_bytes(parent_id, 8) if parent_id else None
        
        # 转换kind
        kind = self._convert_kind(getattr(span, 'kind', None))
        
        # 转换时间戳（微秒转纳秒）
        start_time = getattr(span, 'start_time', int(time.time() * 1e6))
        end_time = getattr(span, 'end_time', start_time)
        
        # 转换属性
        attributes = []
        attrs = getattr(span, 'attributes', {})
        for key, value in attrs.items():
            attributes.append(self._convert_attribute(key, value))
        
        # 转换事件
        events = []
        span_events = getattr(span, 'events', [])
        for event in span_events:
            events.append({
                "time_unix_nano": event.get('timestamp', 0) * 1000,  # 微秒转纳秒
                "name": event.get('name', ''),
                "attributes": [
                    self._convert_attribute(k, v)
                    for k, v in event.get('attributes', {}).items()
                ]
            })
        
        # 转换状态
        status = getattr(span, 'status', None)
        status_code = self.STATUS_CODE_UNSET
        status_message = ""
        
        if status:
            status_str = str(status).lower()
            if status_str == "ok" or status_str == "1":
                status_code = self.STATUS_CODE_OK
            elif status_str == "error" or status_str == "2":
                status_code = self.STATUS_CODE_ERROR
                status_message = getattr(span, 'status_message', '')
        
        return OTLPSpan(
            trace_id=trace_id_bytes,
            span_id=span_id_bytes,
            parent_span_id=parent_id_bytes,
            name=getattr(span, 'name', 'unknown'),
            kind=kind,
            start_time_unix_nano=start_time * 1000,  # 微秒转纳秒
            end_time_unix_nano=end_time * 1000,
            attributes=attributes,
            events=events,
            status={
                "code": status_code,
                "message": status_message
            }
        )
    
    def _convert_kind(self, kind: Any) -> int:
        """转换SpanKind为OTLP枚举值"""
        if kind is None:
            return self.SPAN_KIND_UNSPECIFIED
        
        kind_str = str(kind).lower()
        kind_map = {
            'internal': self.SPAN_KIND_INTERNAL,
            'server': self.SPAN_KIND_SERVER,
            'client': self.SPAN_KIND_CLIENT,
            'producer': self.SPAN_KIND_PRODUCER,
            'consumer': self.SPAN_KIND_CONSUMER,
        }
        
        return kind_map.get(kind_str, self.SPAN_KIND_UNSPECIFIED)
    
    def _convert_attribute(self, key: str, value: Any) -> Dict[str, Any]:
        """转换属性为OTLP格式"""
        if isinstance(value, bool):
            return {"key": key, "value": {"boolValue": value}}
        elif isinstance(value, int):
            return {"key": key, "value": {"intValue": value}}
        elif isinstance(value, float):
            return {"key": key, "value": {"doubleValue": value}}
        else:
            return {"key": key, "value": {"stringValue": str(value)}}
    
    def _hex_to_bytes(self, hex_str: str, length: int) -> bytes:
        """将十六进制字符串转换为字节"""
        hex_str = hex_str.replace("-", "").lower()
        
        # 确保长度正确
        if len(hex_str) < length * 2:
            hex_str = hex_str.zfill(length * 2)
        elif len(hex_str) > length * 2:
            hex_str = hex_str[-length * 2:]
        
        return bytes.fromhex(hex_str)
    
    def _build_resource(self) -> OTLPResource:
        """构建资源信息"""
        return OTLPResource(
            attributes={
                "service.name": self.service_name,
                "service.version": self.service_version,
            }
        )
    
    def _build_export_request(self, spans: List[OTLPSpan]) -> Any:
        """构建gRPC导出请求"""
        # 这里需要OTLP的protobuf定义
        # from opentelemetry.proto.collector.trace.v1 import trace_service_pb2
        # from opentelemetry.proto.trace.v1 import trace_pb2
        
        # 简化实现
        return None
    
    def _build_export_request_json(self, spans: List[OTLPSpan]) -> Dict[str, Any]:
        """构建HTTP JSON导出请求"""
        return {
            "resourceSpans": [{
                "resource": {
                    "attributes": [
                        self._convert_attribute(k, v)
                        for k, v in self._resource.attributes.items()
                    ]
                },
                "scopeSpans": [{
                    "scope": {
                        "name": "IP4Move-Aegis",
                        "version": "1.0.0"
                    },
                    "spans": [
                        {
                            "traceId": span.trace_id.hex(),
                            "spanId": span.span_id.hex(),
                            "parentSpanId": span.parent_span_id.hex() if span.parent_span_id else None,
                            "name": span.name,
                            "kind": span.kind,
                            "startTimeUnixNano": str(span.start_time_unix_nano),
                            "endTimeUnixNano": str(span.end_time_unix_nano),
                            "attributes": span.attributes,
                            "events": span.events,
                            "status": span.status
                        }
                        for span in spans
                    ]
                }]
            }]
        }


# 便捷函数
def create_otlp_exporter(
    endpoint: str = "http://localhost:4317",
    service_name: str = "unknown-service",
    protocol: str = "grpc",
) -> OTLPExporter:
    """
    创建OTLP导出器的工厂函数
    
    Args:
        endpoint: OTLP Collector端点
        service_name: 服务名称
        protocol: 传输协议（"grpc"或"http"）
        
    Returns:
        OTLP导出器实例
    """
    return OTLPExporter(
        endpoint=endpoint,
        service_name=service_name,
        protocol=protocol
    )
