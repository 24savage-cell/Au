"""
延迟队列模块 (安全修复版)

修复内容:
1. 添加队列大小限制
2. 添加抗AI时序扰动
3. 添加消息大小验证
4. 改进随机延迟生成
"""

import asyncio
import time
import random
import heapq
import math
import os
import logging
from typing import Optional, Any, List
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# 安全常量
MAX_QUEUE_SIZE = 50000        # 最大队列大小
MAX_ITEM_SIZE = 1024 * 1024   # 最大项目大小 (1MB)
MIN_DELAY_MS = 1              # 最小延迟
MAX_DELAY_MS = 30000          # 最大延迟 (30秒)
JITTER_FACTOR = 0.15          # 抖动因子


@dataclass(order=True)
class DelayedItem:
    """延迟队列项"""
    ready_time: float
    enqueue_time: float
    item: Any = field(compare=False)
    item_id: bytes = field(default_factory=lambda: os.urandom(8), compare=False)


class SecureDelayQueue:
    """
    安全延迟队列
    
    安全增强:
    - 队列大小限制
    - 抗AI时序扰动
    - 消息大小验证
    - 真随机延迟
    """

    def __init__(
        self,
        min_delay_ms: float = 50,
        max_delay_ms: float = 5000,
        distribution: str = "exponential",
        lam: float = 1000,
        max_size: int = MAX_QUEUE_SIZE,
    ):
        # 验证延迟参数
        if min_delay_ms < MIN_DELAY_MS:
            raise ValueError(f"min_delay_ms too small: {min_delay_ms} < {MIN_DELAY_MS}")
        if max_delay_ms > MAX_DELAY_MS:
            raise ValueError(f"max_delay_ms too large: {max_delay_ms} > {MAX_DELAY_MS}")
        if min_delay_ms >= max_delay_ms:
            raise ValueError(f"min_delay_ms must be less than max_delay_ms")
        
        self._min_delay = min_delay_ms / 1000.0
        self._max_delay = max_delay_ms / 1000.0
        self._distribution = distribution
        self._lam = lam / 1000.0
        self._max_size = max_size
        self._heap: List[DelayedItem] = []
        self._lock = asyncio.Lock()
        self._not_empty = asyncio.Event()
        
        # 统计信息
        self._total_enqueued = 0
        self._total_dropped = 0
        self._entropy_samples: List[float] = []

    @property
    def size(self) -> int:
        return len(self._heap)

    @property
    def stats(self) -> dict:
        return {
            "size": len(self._heap),
            "max_size": self._max_size,
            "total_enqueued": self._total_enqueued,
            "total_dropped": self._total_dropped,
            "distribution": self._distribution,
        }

    def sample_delay(self) -> float:
        """
        根据配置的分布采样延迟时间
        
        安全增强:
        - 添加真随机扰动
        - 抗AI时序分析
        """
        # 基础延迟
        if self._distribution == "exponential":
            delay = random.expovariate(1.0 / self._lam)
        elif self._distribution == "uniform":
            delay = random.uniform(self._min_delay, self._max_delay)
        elif self._distribution == "constant":
            delay = (self._min_delay + self._max_delay) / 2
        elif self._distribution == "normal":
            mean = (self._min_delay + self._max_delay) / 2
            std = (self._max_delay - self._min_delay) / 6
            delay = random.gauss(mean, std)
        else:
            delay = random.expovariate(1.0 / self._lam)

        # 截断到有效范围
        delay = max(self._min_delay, min(self._max_delay, delay))
        
        # 抗AI时序扰动: 添加真随机微扰动
        # 使用系统熵源
        try:
            jitter = int.from_bytes(os.urandom(4), "big") / (2**32)  # [0, 1)
            jitter = (jitter - 0.5) * 2 * JITTER_FACTOR * delay  # [-15%, +15%]
            delay = max(self._min_delay, min(self._max_delay, delay + jitter))
        except Exception:
            pass
        
        # 记录熵样本
        self._entropy_samples.append(delay)
        if len(self._entropy_samples) > 1000:
            self._entropy_samples = self._entropy_samples[-500:]
        
        return delay * 1000  # 返回毫秒

    def get_timing_entropy(self) -> float:
        """计算延迟分布的熵值"""
        if len(self._entropy_samples) < 10:
            return 0.0
        
        # 计算Shannon熵
        import math
        samples = self._entropy_samples[-100:]
        min_s = min(samples)
        max_s = max(samples)
        
        if max_s <= min_s:
            return 0.0
        
        # 离散化
        bins = [0] * 20
        for s in samples:
            idx = min(19, int((s - min_s) / (max_s - min_s) * 20))
            bins[idx] += 1
        
        # 计算熵
        total = len(samples)
        entropy = 0.0
        for count in bins:
            if count > 0:
                p = count / total
                entropy -= p * math.log2(p)
        
        return entropy

    def _validate_item(self, item: Any) -> bool:
        """验证项目有效性"""
        if item is None:
            return False
        
        # 如果是bytes，检查大小
        if isinstance(item, bytes):
            if len(item) > MAX_ITEM_SIZE:
                logger.warning(f"Item too large: {len(item)} > {MAX_ITEM_SIZE}")
                return False
        
        return True

    async def enqueue(self, item: Any, delay_ms: Optional[float] = None) -> bool:
        """
        将项目加入延迟队列
        
        安全增强:
        - 队列大小检查
        - 项目验证
        
        Returns:
            是否成功加入队列
        """
        # 验证项目
        if not self._validate_item(item):
            return False
        
        async with self._lock:
            # 检查队列大小
            if len(self._heap) >= self._max_size:
                self._total_dropped += 1
                logger.warning(f"Delay queue full, dropped item (total dropped: {self._total_dropped})")
                return False
            
            if delay_ms is None:
                delay_ms = self.sample_delay()
            
            # 验证延迟范围
            delay_ms = max(MIN_DELAY_MS, min(MAX_DELAY_MS, delay_ms))
            delay_s = delay_ms / 1000.0
            ready_time = time.monotonic() + delay_s
            
            delayed = DelayedItem(
                ready_time=ready_time,
                enqueue_time=time.monotonic(),
                item=item,
            )
            
            heapq.heappush(self._heap, delayed)
            self._not_empty.set()
            self._total_enqueued += 1
            return True

    async def dequeue_ready(self, max_items: int = 100) -> List[Any]:
        """
        取出所有已到期的项目
        
        安全增强:
        - 限制最大返回数量
        """
        now = time.monotonic()
        items = []
        
        async with self._lock:
            while self._heap and self._heap[0].ready_time <= now and len(items) < max_items:
                delayed = heapq.heappop(self._heap)
                items.append(delayed.item)
            if not self._heap:
                self._not_empty.clear()
        
        return items

    async def wait_for_ready(self, timeout: Optional[float] = None) -> List[Any]:
        """等待直到有项目到期"""
        if self._heap:
            next_ready = self._heap[0].ready_time
            wait_time = max(0, next_ready - time.monotonic())
        else:
            wait_time = timeout or 1.0

        try:
            await asyncio.wait_for(self._not_empty.wait(), timeout=wait_time)
        except asyncio.TimeoutError:
            pass
        return await self.dequeue_ready()

    async def peek_next_delay(self) -> Optional[float]:
        """查看下一个项目的剩余延迟"""
        if not self._heap:
            return None
        remaining = self._heap[0].ready_time - time.monotonic()
        return max(0, remaining * 1000)

    def clear(self) -> int:
        """清空队列"""
        count = len(self._heap)
        self._heap.clear()
        self._not_empty.clear()
        return count

    def get_stats(self) -> dict:
        """获取队列统计信息"""
        now = time.monotonic()
        if not self._heap:
            return {
                "size": 0,
                "max_size": self._max_size,
                "min_remaining_ms": 0,
                "max_remaining_ms": 0,
                "avg_remaining_ms": 0,
                "timing_entropy": self.get_timing_entropy(),
            }
        remaining = [max(0, (item.ready_time - now) * 1000) for item in self._heap]
        return {
            "size": len(self._heap),
            "max_size": self._max_size,
            "min_remaining_ms": min(remaining),
            "max_remaining_ms": max(remaining),
            "avg_remaining_ms": sum(remaining) / len(remaining),
            "timing_entropy": self.get_timing_entropy(),
        }


# 向后兼容
DelayQueue = SecureDelayQueue
