"""
Mixnet优化配置 - 动态批处理与紧急通道

修复问题:
1. 固定BATCH_SIZE=64是流量特征 → 改为动态自适应
2. 最大延迟5秒导致实时通信不可用 → 添加紧急通道
3. 线性随机延迟不真实 → 改为指数分布

版本: v2.1.0
"""

from __future__ import annotations

import asyncio
import logging
import math
import random
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Awaitable, Dict, List, Optional, Any

logger = logging.getLogger(__name__)


# ============================================================================
# 流量类型枚举
# ============================================================================

class TrafficClass(Enum):
    """流量类型分类"""
    REALTIME = auto()      # 实时流量 (语音/视频) - 走紧急通道
    INTERACTIVE = auto()   # 交互流量 (SSH/游戏) - 低延迟
    BULK = auto()          # 批量流量 (文件传输) - 正常混洗
    DNS = auto()           # DNS查询 - 超快速通道
    CONTROL = auto()       # 控制信令 - 优先处理


# ============================================================================
# 动态批处理配置
# ============================================================================

@dataclass
class DynamicBatchConfig:
    """
    动态批处理配置
    
    核心改进:
    - 批大小根据队列长度自适应
    - 时间窗口触发刷新
    - 避免固定大小成为流量特征
    """
    min_batch_size: int = 8          # 最小批大小
    max_batch_size: int = 128        # 最大批大小
    target_batch_size: int = 32      # 目标批大小
    
    # 自适应参数
    low_queue_threshold: int = 20    # 低队列阈值
    high_queue_threshold: int = 80   # 高队列阈值
    
    # 时间窗口
    max_wait_ms: float = 200.0       # 最大等待时间(ms)
    min_wait_ms: float = 20.0        # 最小等待时间(ms)
    
    # 紧急刷新阈值
    urgency_threshold_ms: float = 100.0  # 超过此时间强制刷新
    
    def calculate_batch_size(self, queue_size: int) -> int:
        """
        根据队列大小动态计算批大小
        
        策略:
        - 队列小 → 小批量快速发送
        - 队列大 → 大批量提高效率
        - 避免固定大小成为特征
        """
        if queue_size <= self.low_queue_threshold:
            # 低负载: 小批量快速发送
            ratio = queue_size / self.low_queue_threshold
            size = int(self.min_batch_size + (self.target_batch_size - self.min_batch_size) * ratio)
        elif queue_size >= self.high_queue_threshold:
            # 高负载: 大批量
            ratio = min(1.0, (queue_size - self.high_queue_threshold) / self.high_queue_threshold)
            size = int(self.target_batch_size + (self.max_batch_size - self.target_batch_size) * ratio)
        else:
            # 中等负载: 目标大小 + 随机扰动
            jitter = random.gauss(0, self.target_batch_size * 0.1)
            size = int(self.target_batch_size + jitter)
        
        # 添加随机扰动避免固定特征
        size += random.randint(-3, 3)
        
        return max(self.min_batch_size, min(self.max_batch_size, size))
    
    def calculate_wait_time(self, queue_size: int, current_wait_ms: float) -> float:
        """
        动态计算等待时间
        
        策略:
        - 队列空 → 长等待
        - 队列满 → 短等待
        - 超过阈值 → 立即刷新
        """
        if current_wait_ms >= self.urgency_threshold_ms:
            return 0.0  # 立即刷新
        
        if queue_size <= self.low_queue_threshold:
            # 低负载: 较长等待
            return self.max_wait_ms * 0.8
        elif queue_size >= self.high_queue_threshold:
            # 高负载: 短等待
            return self.min_wait_ms
        else:
            # 中等负载: 线性插值
            ratio = (queue_size - self.low_queue_threshold) / (self.high_queue_threshold - self.low_queue_threshold)
            return self.max_wait_ms - (self.max_wait_ms - self.min_wait_ms) * ratio


# ============================================================================
# 指数分布延迟配置
# ============================================================================

@dataclass
class ExponentialDelayConfig:
    """
    指数分布延迟配置
    
    核心改进:
    - 使用指数分布更符合真实网络抖动
    - 避免线性均匀分布的特征
    - 支持多峰混合分布
    """
    # 基础参数
    lambda_base: float = 0.002      # 基础λ参数 (1/ms)
    min_delay_ms: float = 10.0      # 最小延迟
    max_delay_ms: float = 2000.0    # 最大延迟 (从5秒降到2秒)
    
    # 混合分布参数 (模拟多跳网络)
    use_mixture: bool = True
    mixture_weights: List[float] = field(default_factory=lambda: [0.6, 0.3, 0.1])
    mixture_lambdas: List[float] = field(default_factory=lambda: [0.003, 0.001, 0.0005])
    
    # 抗AI扰动
    ai_resistance_jitter: float = 0.15  # 高斯扰动比例
    
    def sample_delay(self) -> float:
        """
        采样延迟时间
        
        使用混合指数分布:
        p(x) = Σ w_i * λ_i * exp(-λ_i * x)
        """
        if self.use_mixture and len(self.mixture_weights) == len(self.mixture_lambdas):
            # 选择哪个分量
            r = random.random()
            cumsum = 0.0
            selected_lambda = self.mixture_lambdas[0]
            for w, lam in zip(self.mixture_weights, self.mixture_lambdas):
                cumsum += w
                if r <= cumsum:
                    selected_lambda = lam
                    break
            
            # 从指数分布采样
            delay = random.expovariate(selected_lambda)
        else:
            # 单一指数分布
            delay = random.expovariate(self.lambda_base)
        
        # 转换为毫秒并限制范围
        delay_ms = delay * 1000.0
        delay_ms = max(self.min_delay_ms, min(self.max_delay_ms, delay_ms))
        
        # 添加抗AI高斯扰动
        if self.ai_resistance_jitter > 0:
            jitter = random.gauss(0, delay_ms * self.ai_resistance_jitter)
            delay_ms = max(self.min_delay_ms, delay_ms + jitter)
        
        return delay_ms


# ============================================================================
# 紧急通道配置
# ============================================================================

@dataclass
class ExpressChannelConfig:
    """
    紧急通道配置
    
    核心改进:
    - 实时流量走快速路径
    - 不参与混批
    - 极低延迟
    """
    enabled: bool = True
    
    # 各流量类型的延迟上限 (ms)
    realtime_max_delay_ms: float = 50.0     # 实时流量最大50ms
    interactive_max_delay_ms: float = 100.0  # 交互流量最大100ms
    dns_max_delay_ms: float = 20.0           # DNS最大20ms
    control_max_delay_ms: float = 30.0       # 控制信令最大30ms
    
    # 紧急通道批处理
    express_batch_size: int = 4              # 紧急通道小批量
    express_flush_interval_ms: float = 10.0  # 快速刷新
    
    def get_max_delay(self, traffic_class: TrafficClass) -> float:
        """获取指定流量类型的最大延迟"""
        limits = {
            TrafficClass.REALTIME: self.realtime_max_delay_ms,
            TrafficClass.INTERACTIVE: self.interactive_max_delay_ms,
            TrafficClass.DNS: self.dns_max_delay_ms,
            TrafficClass.CONTROL: self.control_max_delay_ms,
            TrafficClass.BULK: 2000.0,  # 批量流量走正常通道
        }
        return limits.get(traffic_class, 1000.0)
    
    def is_express(self, traffic_class: TrafficClass) -> bool:
        """判断是否走紧急通道"""
        return self.enabled and traffic_class in {
            TrafficClass.REALTIME,
            TrafficClass.INTERACTIVE,
            TrafficClass.DNS,
            TrafficClass.CONTROL,
        }


# ============================================================================
# 完整Mixnet配置
# ============================================================================

@dataclass
class OptimizedMixnetConfig:
    """
    优化的Mixnet完整配置
    
    整合:
    - 动态批处理
    - 指数分布延迟
    - 紧急通道
    """
    node_id: str
    
    # 子配置
    batch: DynamicBatchConfig = field(default_factory=DynamicBatchConfig)
    delay: ExponentialDelayConfig = field(default_factory=ExponentialDelayConfig)
    express: ExpressChannelConfig = field(default_factory=ExpressChannelConfig)
    
    # 队列限制
    max_queue_size: int = 10000
    max_message_size: int = 1024 * 1024  # 1MB
    
    # 统计信息
    enable_stats: bool = True
    stats_interval_s: float = 60.0


# ============================================================================
# 优化的Mix节点
# ============================================================================

class OptimizedMixNode:
    """
    优化的Mix节点
    
    核心改进:
    1. 动态批处理 - 避免固定大小特征
    2. 指数分布延迟 - 更真实的网络模拟
    3. 紧急通道 - 支持实时通信
    4. 流量分类 - 不同类型不同处理
    """
    
    def __init__(self, config: OptimizedMixnetConfig):
        self._config = config
        self._is_running = False
        
        # 主队列和紧急队列
        self._main_queue: asyncio.Queue = asyncio.Queue(maxsize=config.max_queue_size)
        self._express_queue: asyncio.Queue = asyncio.Queue(maxsize=1000)
        
        # 统计信息
        self._stats = {
            "messages_received": 0,
            "messages_forwarded": 0,
            "express_messages": 0,
            "bulk_messages": 0,
            "batch_sizes": [],
            "delays": [],
        }
        
        # 回调
        self._forward_callback: Optional[Callable[[List], Awaitable[None]]] = None
        
        # 任务
        self._main_task: Optional[asyncio.Task] = None
        self._express_task: Optional[asyncio.Task] = None
    
    @property
    def node_id(self) -> str:
        return self._config.node_id
    
    @property
    def main_queue_size(self) -> int:
        return self._main_queue.qsize()
    
    @property
    def express_queue_size(self) -> int:
        return self._express_queue.qsize()
    
    def set_forward_callback(self, callback: Callable[[List], Awaitable[None]]):
        """设置转发回调"""
        self._forward_callback = callback
    
    def classify_traffic(self, message: Any) -> TrafficClass:
        """
        分类流量类型
        
        可根据消息属性判断:
        - 消息大小
        - 源/目标端口
        - 协议类型
        - 显式标记
        """
        # 检查显式标记
        if hasattr(message, 'traffic_class'):
            return message.traffic_class
        
        # 基于大小启发式判断
        if hasattr(message, 'payload'):
            size = len(message.payload)
            if size < 100:  # 小包可能是DNS/控制
                return TrafficClass.DNS
            elif size < 500:  # 中等可能是交互
                return TrafficClass.INTERACTIVE
            elif size > 50000:  # 大包是批量
                return TrafficClass.BULK
        
        # 默认为批量
        return TrafficClass.BULK
    
    async def receive(self, message: Any) -> bool:
        """
        接收消息
        
        根据流量类型分流到不同队列
        """
        # 流量分类
        traffic_class = self.classify_traffic(message)
        
        # 标记流量类型
        if hasattr(message, '__dict__'):
            message.traffic_class = traffic_class
        
        # 计算延迟
        if self._config.express.is_express(traffic_class):
            # 紧急通道: 极低延迟
            max_delay = self._config.express.get_max_delay(traffic_class)
            delay_ms = random.uniform(5, max_delay)
            message._delay_ms = delay_ms
            message._arrival_time = time.time()
            
            try:
                self._express_queue.put_nowait(message)
                self._stats["express_messages"] += 1
                return True
            except asyncio.QueueFull:
                logger.warning(f"紧急队列已满，降级到主队列")
                # 降级到主队列
        else:
            # 主通道: 指数分布延迟
            delay_ms = self._config.delay.sample_delay()
            message._delay_ms = delay_ms
            message._arrival_time = time.time()
            self._stats["bulk_messages"] += 1
        
        # 放入主队列
        try:
            self._main_queue.put_nowait(message)
            self._stats["messages_received"] += 1
            return True
        except asyncio.QueueFull:
            logger.warning(f"主队列已满，丢弃消息")
            return False
    
    async def _express_loop(self):
        """紧急通道处理循环"""
        batch = []
        last_flush = time.time()
        
        while self._is_running:
            try:
                # 非阻塞获取
                try:
                    msg = self._express_queue.get_nowait()
                    batch.append(msg)
                except asyncio.QueueEmpty:
                    pass
                
                # 检查是否需要刷新
                now = time.time()
                should_flush = (
                    len(batch) >= self._config.express.express_batch_size or
                    (now - last_flush) * 1000 >= self._config.express.express_flush_interval_ms
                )
                
                if batch and should_flush:
                    # 按延迟排序
                    ready = []
                    pending = []
                    for msg in batch:
                        elapsed_ms = (now - msg._arrival_time) * 1000
                        if elapsed_ms >= msg._delay_ms:
                            ready.append(msg)
                        else:
                            pending.append(msg)
                    
                    if ready:
                        # 混洗
                        random.shuffle(ready)
                        await self._forward(ready)
                        batch = pending
                    
                    last_flush = now
                else:
                    await asyncio.sleep(0.005)  # 5ms
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"紧急通道错误: {e}")
                await asyncio.sleep(0.01)
    
    async def _main_loop(self):
        """主通道处理循环"""
        batch = []
        last_flush = time.time()
        
        while self._is_running:
            try:
                # 动态计算等待时间
                queue_size = self._main_queue.qsize()
                current_wait_ms = (time.time() - last_flush) * 1000
                wait_ms = self._config.batch.calculate_wait_time(queue_size, current_wait_ms)
                
                # 等待消息
                if wait_ms > 0:
                    try:
                        msg = await asyncio.wait_for(
                            self._main_queue.get(),
                            timeout=wait_ms / 1000.0
                        )
                        batch.append(msg)
                    except asyncio.TimeoutError:
                        pass
                else:
                    # 非阻塞获取
                    try:
                        msg = self._main_queue.get_nowait()
                        batch.append(msg)
                    except asyncio.QueueEmpty:
                        pass
                
                # 动态计算批大小
                target_size = self._config.batch.calculate_batch_size(queue_size)
                
                # 检查是否需要刷新
                now = time.time()
                should_flush = (
                    len(batch) >= target_size or
                    current_wait_ms >= self._config.batch.urgency_threshold_ms
                )
                
                if batch and should_flush:
                    # 按延迟过滤
                    ready = []
                    pending = []
                    for msg in batch:
                        elapsed_ms = (now - msg._arrival_time) * 1000
                        if elapsed_ms >= msg._delay_ms:
                            ready.append(msg)
                        else:
                            pending.append(msg)
                    
                    if ready:
                        # 混洗
                        random.shuffle(ready)
                        await self._forward(ready)
                        
                        # 记录统计
                        self._stats["batch_sizes"].append(len(ready))
                        self._stats["delays"].extend([m._delay_ms for m in ready])
                        
                        batch = pending
                    
                    last_flush = now
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"主通道错误: {e}")
                await asyncio.sleep(0.1)
    
    async def _forward(self, messages: List):
        """转发消息"""
        if not messages:
            return
        
        self._stats["messages_forwarded"] += len(messages)
        
        if self._forward_callback:
            try:
                await self._forward_callback(messages)
            except Exception as e:
                logger.error(f"转发回调错误: {e}")
        else:
            logger.debug(f"节点 {self._config.node_id} 转发 {len(messages)} 条消息")
    
    async def start(self):
        """启动节点"""
        if self._is_running:
            return
        
        self._is_running = True
        self._express_task = asyncio.create_task(self._express_loop())
        self._main_task = asyncio.create_task(self._main_loop())
        
        logger.info(
            f"Mix节点 {self._config.node_id} 启动 - "
            f"动态批处理 + 指数延迟 + 紧急通道"
        )
    
    async def stop(self):
        """停止节点"""
        self._is_running = False
        
        for task in [self._express_task, self._main_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        
        logger.info(f"Mix节点 {self._config.node_id} 已停止")
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        stats = self._stats.copy()
        
        # 计算平均值
        if stats["batch_sizes"]:
            stats["avg_batch_size"] = sum(stats["batch_sizes"]) / len(stats["batch_sizes"])
        if stats["delays"]:
            stats["avg_delay_ms"] = sum(stats["delays"]) / len(stats["delays"])
        
        stats["main_queue_size"] = self.main_queue_size
        stats["express_queue_size"] = self.express_queue_size
        
        return stats
