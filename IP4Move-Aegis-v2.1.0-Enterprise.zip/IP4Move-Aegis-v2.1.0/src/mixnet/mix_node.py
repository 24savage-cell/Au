"""
Mix 节点核心 (安全修复版)

修复内容:
1. 严格队列大小限制防止内存耗尽
2. 添加消息大小验证
3. 防止整数溢出
4. 添加速率限制
5. 改进错误处理
6. 添加资源监控
"""

import asyncio
import time
import random
import logging
from typing import Optional, Callable, Awaitable
from dataclasses import dataclass, field

from src.mixnet.delay_queue import DelayQueue
from src.mixnet.batch_forwarder import BatchForwarder

logger = logging.getLogger(__name__)

# 安全常量
MAX_QUEUE_SIZE = 10000          # 最大队列大小
MAX_MESSAGE_SIZE = 1024 * 1024  # 最大消息大小(1MB)
MAX_DELAY_MS = 30000            # 最大延迟(30秒)
MIN_DELAY_MS = 1                # 最小延迟(1毫秒)
MAX_BATCH_SIZE = 256            # 最大批处理大小
MAX_FLUSH_INTERVAL_MS = 5000    # 最大刷新间隔(5秒)
RATE_LIMIT_WINDOW = 60.0        # 速率限制窗口
MAX_MESSAGES_PER_WINDOW = 10000  # 每窗口最大消息数


class MixSecurityError(Exception):
    """Mix节点安全错误"""
    pass


@dataclass
class MixMessage:
    """Mix 消息"""
    payload: bytes
    destination: str
    arrival_time: float = field(default_factory=time.time)
    priority: int = 0
    message_id: Optional[str] = None


@dataclass
class MixNodeConfig:
    """Mix 节点配置"""
    node_id: str
    delay_min_ms: float = 50
    delay_max_ms: float = 5000
    delay_distribution: str = "exponential"
    delay_lambda: float = 1000
    batch_size: int = 64
    flush_interval_ms: float = 100
    max_queue_size: int = 10000
    mix_strategy: str = "threshold"


class SecureMixNode:
    """
    安全Mix节点核心
    
    实现Mixnet混淆节点，通过延迟和混洗提供匿名性。
    
    安全特性:
    - 严格资源限制
    - 输入验证
    - 速率限制
    - 资源监控
    """

    def __init__(self, config: MixNodeConfig):
        self._config = config
        
        # 验证配置
        self._validate_config()
        
        self._delay_queue = DelayQueue(
            min_delay_ms=max(MIN_DELAY_MS, config.delay_min_ms),
            max_delay_ms=min(MAX_DELAY_MS, config.delay_max_ms),
            distribution=config.delay_distribution,
            lam=config.delay_lambda,
        )
        self._batch_forwarder = BatchForwarder(
            batch_size=min(MAX_BATCH_SIZE, config.batch_size),
            flush_interval_ms=min(MAX_FLUSH_INTERVAL_MS, config.flush_interval_ms),
        )
        self._message_count = 0
        self._bytes_processed = 0
        self._is_running = False
        self._forward_callback: Optional[Callable[[list], Awaitable[None]]] = None
        self._processing_task: Optional[asyncio.Task] = None
        self._flush_task: Optional[asyncio.Task] = None
        
        # 速率限制
        self._message_timestamps: list = []
        
        # 资源监控
        self._dropped_messages = 0
        self._last_drop_warning = 0

    def _validate_config(self) -> None:
        """验证配置安全性"""
        if self._config.delay_min_ms < MIN_DELAY_MS:
            raise ValueError(f"delay_min_ms too small: {self._config.delay_min_ms}")
        if self._config.delay_max_ms > MAX_DELAY_MS:
            raise ValueError(f"delay_max_ms too large: {self._config.delay_max_ms}")
        if self._config.batch_size > MAX_BATCH_SIZE:
            raise ValueError(f"batch_size too large: {self._config.batch_size}")
        if self._config.flush_interval_ms > MAX_FLUSH_INTERVAL_MS:
            raise ValueError(f"flush_interval_ms too large: {self._config.flush_interval_ms}")
        if self._config.max_queue_size > MAX_QUEUE_SIZE:
            raise ValueError(f"max_queue_size too large: {self._config.max_queue_size}")

    @property
    def node_id(self) -> str:
        return self._config.node_id

    @property
    def queue_size(self) -> int:
        return self._delay_queue.size

    @property
    def is_running(self) -> bool:
        return self._is_running

    @property
    def stats(self) -> dict:
        return {
            "node_id": self._config.node_id,
            "message_count": self._message_count,
            "bytes_processed": self._bytes_processed,
            "queue_size": self._delay_queue.size,
            "is_running": self._is_running,
            "dropped_messages": self._dropped_messages,
        }

    def _check_rate_limit(self) -> bool:
        """检查消息速率限制"""
        now = time.time()
        
        # 清理过期时间戳
        self._message_timestamps = [
            t for t in self._message_timestamps
            if now - t < RATE_LIMIT_WINDOW
        ]
        
        if len(self._message_timestamps) >= MAX_MESSAGES_PER_WINDOW:
            return False
        
        self._message_timestamps.append(now)
        return True

    def _validate_message(self, message: MixMessage) -> bool:
        """验证消息有效性"""
        if not isinstance(message, MixMessage):
            return False
        if not isinstance(message.payload, bytes):
            return False
        if len(message.payload) > MAX_MESSAGE_SIZE:
            logger.warning(f"Message too large: {len(message.payload)} bytes")
            return False
        if not isinstance(message.destination, str):
            return False
        if len(message.destination) > 256:  # 最大地址长度
            return False
        return True

    def get_delay_entropy(self) -> float:
        """计算延迟分布的熵值"""
        import math
        # 模拟采样延迟分布
        samples = [self._delay_queue.sample_delay() for _ in range(100)]
        # 计算直方图
        bins = [0] * 10
        min_d = min(samples)
        max_d = max(samples)
        if max_d <= min_d:
            return 0.0
        for s in samples:
            idx = min(9, int((s - min_d) / (max_d - min_d) * 10))
            bins[idx] += 1
        # 计算熵
        total = len(samples)
        entropy = 0.0
        for count in bins:
            if count > 0:
                p = count / total
                entropy -= p * math.log2(p)
        return entropy

    def set_forward_callback(
        self, callback: Callable[[list], Awaitable[None]]
    ) -> None:
        """设置转发回调函数"""
        self._forward_callback = callback

    async def receive(self, message: MixMessage) -> bool:
        """
        安全接收消息并加入延迟队列
        
        安全增强:
        - 输入验证
        - 速率限制
        - 严格队列限制
        """
        # 输入验证
        if not self._validate_message(message):
            logger.warning("Invalid message received")
            return False
        
        # 速率限制
        if not self._check_rate_limit():
            logger.warning("Rate limit exceeded")
            self._dropped_messages += 1
            return False
        
        # 严格队列大小检查
        if self._delay_queue.size >= self._config.max_queue_size:
            self._dropped_messages += 1
            now = time.time()
            # 每10秒记录一次警告
            if now - self._last_drop_warning > 10:
                logger.warning(f"Mix node {self._config.node_id} queue full, dropped {self._dropped_messages} messages")
                self._last_drop_warning = now
            return False

        # 计算延迟时间
        try:
            delay_ms = self._delay_queue.sample_delay()
            # 验证延迟范围
            delay_ms = max(MIN_DELAY_MS, min(MAX_DELAY_MS, delay_ms))
            
            # 抗AI: 添加真随机微扰动
            jitter = random.gauss(0, delay_ms * 0.15)
            delay_ms = max(MIN_DELAY_MS, delay_ms + jitter)
            
            message.arrival_time = time.time()

            # 加入延迟队列
            await self._delay_queue.enqueue(message, delay_ms)
            self._message_count += 1
            self._bytes_processed += len(message.payload)
            return True
            
        except Exception as e:
            logger.error(f"Error enqueueing message: {e}")
            return False

    async def _process_loop(self) -> None:
        """安全处理循环"""
        while self._is_running:
            try:
                # 获取到期消息
                ready_messages = await self._delay_queue.dequeue_ready()
                if ready_messages:
                    # 验证消息数量
                    if len(ready_messages) > MAX_BATCH_SIZE:
                        logger.warning(f"Too many ready messages: {len(ready_messages)}")
                        ready_messages = ready_messages[:MAX_BATCH_SIZE]
                    
                    # 混洗消息顺序
                    random.shuffle(ready_messages)
                    
                    # 加入批量转发器
                    for msg in ready_messages:
                        await self._batch_forwarder.add(msg)
                else:
                    await asyncio.sleep(0.01)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Mix node processing error: {e}")
                await asyncio.sleep(0.1)

    async def _flush_loop(self) -> None:
        """安全定时刷新循环"""
        while self._is_running:
            try:
                batch = await self._batch_forwarder.wait_for_batch()
                if batch:
                    await self._forward_batch(batch)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Mix node flush error: {e}")
                await asyncio.sleep(0.1)

    async def _forward_batch(self, messages: list) -> None:
        """安全转发一批消息"""
        if not messages:
            return
        
        # 验证消息数量
        if len(messages) > MAX_BATCH_SIZE:
            logger.warning(f"Batch size too large: {len(messages)}")
            messages = messages[:MAX_BATCH_SIZE]
        
        if self._forward_callback:
            try:
                await self._forward_callback(messages)
            except Exception as e:
                logger.error(f"Forward callback error: {e}")
        else:
            logger.debug(
                f"Mix node {self._config.node_id} forwarded {len(messages)} messages (no callback)"
            )

    async def start(self) -> None:
        """启动 Mix 节点"""
        if self._is_running:
            return
        self._is_running = True
        self._processing_task = asyncio.create_task(self._process_loop())
        self._flush_task = asyncio.create_task(self._flush_loop())
        logger.info(f"Mix node {self._config.node_id} started")

    async def stop(self) -> None:
        """停止 Mix 节点"""
        self._is_running = False
        if self._processing_task:
            self._processing_task.cancel()
            try:
                await self._processing_task
            except asyncio.CancelledError:
                pass
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        # 刷新剩余消息
        remaining = self._batch_forwarder.flush()
        if remaining:
            await self._forward_batch(remaining)
        logger.info(f"Mix node {self._config.node_id} stopped, processed {self._message_count} messages")


# 向后兼容
MixNode = SecureMixNode
