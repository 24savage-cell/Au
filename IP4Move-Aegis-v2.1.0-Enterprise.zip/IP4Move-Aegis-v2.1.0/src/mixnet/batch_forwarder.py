"""
批量转发引擎

实现 Mixnet 的批量转发策略，提高匿名集大小。
"""

import asyncio
import time
import random
from typing import Optional, List, Any


class BatchForwarder:
    """
    批量转发引擎

    将消息累积到一定数量或时间后批量转发，
    增加每批中的消息数量以提高匿名性。

    策略:
    - threshold: 达到批量大小后立即转发
    - timed: 定时转发
    - hybrid: 两者结合 (先到先发)
    """

    def __init__(
        self,
        batch_size: int = 64,
        flush_interval_ms: float = 100,
        strategy: str = "hybrid",
        min_batch_size: int = 1,
    ):
        self._batch_size = batch_size
        self._flush_interval = flush_interval_ms / 1000.0
        self._strategy = strategy
        self._min_batch_size = min_batch_size
        self._buffer: List[Any] = []
        self._lock = asyncio.Lock()
        self._batch_ready = asyncio.Event()
        self._last_flush = time.monotonic()

    @property
    def buffer_size(self) -> int:
        return len(self._buffer)

    async def add(self, item: Any) -> None:
        """
        添加消息到批量缓冲区

        如果达到批量大小阈值，触发批量就绪事件。
        批量大小添加随机扰动，防止AI通过批量大小模式识别。
        """
        async with self._lock:
            self._buffer.append(item)
            # 抗AI: 动态批量大小阈值 (±30%随机扰动)
            effective_threshold = int(self._batch_size * random.uniform(0.7, 1.3))
            effective_threshold = max(self._min_batch_size, effective_threshold)
            if (
                self._strategy in ("threshold", "hybrid")
                and len(self._buffer) >= effective_threshold
            ):
                self._batch_ready.set()

    async def wait_for_batch(self, timeout: Optional[float] = None) -> List[Any]:
        """
        等待批量就绪

        Returns:
            批量消息列表
        """
        timeout = timeout or self._flush_interval

        # 检查是否已有足够消息
        async with self._lock:
            if len(self._buffer) >= self._min_batch_size:
                if self._strategy == "threshold" and len(self._buffer) < self._batch_size:
                    self._batch_ready.clear()
                    pass
                elif len(self._buffer) >= self._batch_size:
                    batch = self._buffer[: self._batch_size]
                    self._buffer = self._buffer[self._batch_size :]
                    self._batch_ready.clear()
                    self._last_flush = time.monotonic()
                    return batch

        # 等待批量就绪或超时
        try:
            await asyncio.wait_for(self._batch_ready.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            pass

        # 超时后检查定时刷新
        elapsed = time.monotonic() - self._last_flush
        if self._strategy in ("timed", "hybrid") and elapsed >= self._flush_interval:
            async with self._lock:
                if self._buffer:
                    batch = self._buffer[:]
                    self._buffer.clear()
                    self._batch_ready.clear()
                    self._last_flush = time.monotonic()
                    return batch

        # 返回可用消息
        async with self._lock:
            if self._buffer:
                batch = self._buffer[:]
                self._buffer.clear()
                self._batch_ready.clear()
                self._last_flush = time.monotonic()
                return batch

        return []

    def flush(self) -> List[Any]:
        """
        立即刷新所有缓冲消息 (线程安全版)

        Returns:
            缓冲区中的所有消息
        """
        import asyncio
        # 使用锁确保线程安全
        async def _flush_async():
            async with self._lock:
                batch = self._buffer[:]
                self._buffer.clear()
                self._batch_ready.clear()
                self._last_flush = time.monotonic()
                return batch
        
        # 如果在异步上下文中，使用锁；否则直接操作
        try:
            loop = asyncio.get_running_loop()
            # 已经在事件循环中，创建任务
            future = asyncio.ensure_future(_flush_async())
            # 同步等待结果
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                return list(self._buffer[:])  # 返回副本
        except RuntimeError:
            # 不在事件循环中，直接操作
            batch = self._buffer[:]
            self._buffer.clear()
            self._batch_ready.clear()
            self._last_flush = time.monotonic()
            return batch

    def get_stats(self) -> dict:
        """获取统计信息"""
        return {
            "buffer_size": len(self._buffer),
            "batch_size": self._batch_size,
            "strategy": self._strategy,
            "time_since_flush": time.monotonic() - self._last_flush,
        }
