"""
节点池管理模块

管理 Mixnet 节点池，包括节点注册、健康检查和负载均衡。
"""

import asyncio
import time
import random
import logging
from typing import Optional, List, Dict, Callable
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class NodeStatus(Enum):
    """节点状态"""
    ACTIVE = "active"
    IDLE = "idle"
    BUSY = "busy"
    UNHEALTHY = "unhealthy"
    OFFLINE = "offline"


@dataclass
class PoolNode:
    """池中节点"""
    node_id: str
    address: str
    port: int
    status: NodeStatus = NodeStatus.ACTIVE
    last_seen: float = field(default_factory=time.time)
    load: float = 0.0  # 0.0 ~ 1.0
    latency_ms: float = 0.0
    total_messages: int = 0
    failed_messages: int = 0
    metadata: Dict = field(default_factory=dict)

    @property
    def success_rate(self) -> float:
        if self.total_messages == 0:
            return 1.0
        return (self.total_messages - self.failed_messages) / self.total_messages


@dataclass
class PoolConfig:
    """节点池配置"""
    min_nodes: int = 10
    max_nodes: int = 100
    health_check_interval: float = 30  # 秒
    health_check_timeout: float = 5    # 秒
    max_load: float = 0.9
    max_latency_ms: float = 5000
    offline_threshold: float = 300     # 秒
    selection_strategy: str = "weighted"  # weighted | random | least_loaded | round_robin


class PoolManager:
    """
    节点池管理器

    功能:
    - 节点注册与注销
    - 健康检查
    - 负载均衡选择
    - 节点状态监控
    """

    def __init__(self, config: Optional[PoolConfig] = None):
        self._config = config or PoolConfig()
        self._nodes: Dict[str, PoolNode] = {}
        self._round_robin_index = 0
        self._lock = asyncio.Lock()
        self._health_check_task: Optional[asyncio.Task] = None
        self._is_running = False
        self._health_check_callback: Optional[Callable] = None

    @property
    def size(self) -> int:
        return len(self._nodes)

    @property
    def active_nodes(self) -> int:
        return sum(1 for n in self._nodes.values() if n.status == NodeStatus.ACTIVE)

    def set_health_check_callback(self, callback: Callable) -> None:
        """设置健康检查回调"""
        self._health_check_callback = callback

    async def register(self, node_id: str, address: str, port: int, **metadata) -> PoolNode:
        """
        注册节点

        Args:
            node_id: 节点ID
            address: 地址
            port: 端口
            **metadata: 额外元数据

        Returns:
            注册的节点
        """
        async with self._lock:
            if node_id in self._nodes:
                node = self._nodes[node_id]
                node.address = address
                node.port = port
                node.last_seen = time.time()
                node.status = NodeStatus.ACTIVE
                node.metadata.update(metadata)
            else:
                if len(self._nodes) >= self._config.max_nodes:
                    raise RuntimeError(f"节点池已满 (最大 {self._config.max_nodes})")
                node = PoolNode(
                    node_id=node_id,
                    address=address,
                    port=port,
                    metadata=metadata,
                )
                self._nodes[node_id] = node
            logger.info(f"节点注册: {node_id} ({address}:{port})")
            return node

    async def unregister(self, node_id: str) -> bool:
        """注销节点"""
        async with self._lock:
            if node_id in self._nodes:
                del self._nodes[node_id]
                logger.info(f"节点注销: {node_id}")
                return True
            return False

    async def select_node(self, exclude: Optional[List[str]] = None) -> Optional[PoolNode]:
        """
        选择一个节点

        根据配置的策略选择合适的节点。

        Args:
            exclude: 排除的节点ID列表

        Returns:
            选中的节点，无可用节点时返回 None
        """
        exclude = exclude or []
        candidates = [
            n for n in self._nodes.values()
            if n.status == NodeStatus.ACTIVE
            and n.node_id not in exclude
            and n.load < self._config.max_load
            and n.latency_ms < self._config.max_latency_ms
        ]

        if not candidates:
            return None

        strategy = self._config.selection_strategy

        if strategy == "weighted":
            # 加权随机: 成功率高、延迟低的节点权重更大
            weights = []
            for node in candidates:
                w = node.success_rate * (1.0 - node.load) * (1.0 / (1.0 + node.latency_ms / 1000.0))
                weights.append(max(0.01, w))
            total = sum(weights)
            weights = [w / total for w in weights]
            return random.choices(candidates, weights=weights, k=1)[0]

        elif strategy == "least_loaded":
            return min(candidates, key=lambda n: n.load)

        elif strategy == "round_robin":
            active = sorted(candidates, key=lambda n: n.node_id)
            idx = self._round_robin_index % len(active)
            self._round_robin_index += 1
            return active[idx]

        else:  # random
            return random.choice(candidates)

    async def select_nodes(self, count: int, exclude: Optional[List[str]] = None) -> List[PoolNode]:
        """选择多个不重复的节点"""
        selected = []
        used_ids = list(exclude or [])
        for _ in range(count):
            node = await self.select_node(exclude=used_ids)
            if node is None:
                break
            selected.append(node)
            used_ids.append(node.node_id)
        return selected

    def update_node_stats(
        self,
        node_id: str,
        load: Optional[float] = None,
        latency_ms: Optional[float] = None,
        success: Optional[bool] = None,
    ) -> None:
        """更新节点统计"""
        if node_id not in self._nodes:
            return
        node = self._nodes[node_id]
        if load is not None:
            node.load = max(0, min(1, load))
        if latency_ms is not None:
            node.latency_ms = latency_ms
        if success is not None:
            node.total_messages += 1
            if not success:
                node.failed_messages += 1
        node.last_seen = time.time()

    async def _health_check_loop(self) -> None:
        """健康检查循环"""
        while self._is_running:
            try:
                now = time.time()
                for node in list(self._nodes.values()):
                    # 检查超时
                    if now - node.last_seen > self._config.offline_threshold:
                        node.status = NodeStatus.OFFLINE
                        logger.warning(f"节点离线: {node.node_id}")
                        continue

                    # 执行健康检查
                    if self._health_check_callback:
                        try:
                            healthy = await asyncio.wait_for(
                                self._health_check_callback(node),
                                timeout=self._config.health_check_timeout,
                            )
                            node.status = NodeStatus.ACTIVE if healthy else NodeStatus.UNHEALTHY
                        except (asyncio.TimeoutError, Exception):
                            node.status = NodeStatus.UNHEALTHY

                    # 根据成功率更新状态
                    if node.total_messages > 10 and node.success_rate < 0.5:
                        node.status = NodeStatus.UNHEALTHY

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"健康检查错误: {e}")

            await asyncio.sleep(self._config.health_check_interval)

    async def start(self) -> None:
        """启动节点池管理"""
        if self._is_running:
            return
        self._is_running = True
        self._health_check_task = asyncio.create_task(self._health_check_loop())
        logger.info("节点池管理器已启动")

    async def stop(self) -> None:
        """停止节点池管理"""
        self._is_running = False
        if self._health_check_task:
            self._health_check_task.cancel()
            try:
                await self._health_check_task
            except asyncio.CancelledError:
                pass
        logger.info("节点池管理器已停止")

    def get_stats(self) -> dict:
        """获取节点池统计"""
        status_counts = {}
        for node in self._nodes.values():
            status_counts[node.status.value] = status_counts.get(node.status.value, 0) + 1
        return {
            "total_nodes": len(self._nodes),
            "active_nodes": self.active_nodes,
            "status_distribution": status_counts,
            "avg_load": sum(n.load for n in self._nodes.values()) / max(1, len(self._nodes)),
            "avg_latency_ms": sum(n.latency_ms for n in self._nodes.values()) / max(1, len(self._nodes)),
        }
