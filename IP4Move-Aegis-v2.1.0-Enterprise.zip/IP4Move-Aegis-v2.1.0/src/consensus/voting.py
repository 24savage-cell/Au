"""
分布式投票模块

实现分布式共识投票机制。
"""

import asyncio
import time
import hashlib
import hmac
import logging
from typing import Optional, List, Dict, Callable, Any
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class VoteType(Enum):
    """投票类型"""
    NODE_JOIN = "node_join"
    NODE_EJECT = "node_eject"
    KEY_ROTATION = "key_rotation"
    CONFIG_CHANGE = "config_change"
    EMERGENCY = "emergency"


class VoteResult(Enum):
    """投票结果"""
    APPROVED = "approved"
    REJECTED = "rejected"
    PENDING = "pending"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class Vote:
    """投票"""
    vote_id: str
    vote_type: VoteType
    proposal: bytes
    voter_id: str
    decision: bool  # True=赞成, False=反对
    signature: bytes = b""
    timestamp: float = field(default_factory=time.time)
    reason: str = ""


@dataclass
class VotingRound:
    """投票轮次"""
    round_id: str
    vote_type: VoteType
    proposal: bytes
    proposer_id: str
    threshold: float  # 通过阈值 (0.0 ~ 1.0)
    timeout: float    # 超时时间(秒)
    created_at: float = field(default_factory=time.time)
    votes: Dict[str, Vote] = field(default_factory=dict)
    result: VoteResult = VoteResult.PENDING
    is_closed: bool = False

    @property
    def total_votes(self) -> int:
        return len(self.votes)

    @property
    def approve_count(self) -> int:
        return sum(1 for v in self.votes.values() if v.decision)

    @property
    def reject_count(self) -> int:
        return sum(1 for v in self.votes.values() if not v.decision)

    @property
    def approval_ratio(self) -> float:
        if self.total_votes == 0:
            return 0.0
        return self.approve_count / self.total_votes

    @property
    def is_passed(self) -> bool:
        return self.approval_ratio >= self.threshold


class DistributedVoting:
    """
    分布式投票器

    功能:
    - 创建投票提案
    - 收集和统计投票
    - 超时自动关闭
    - 投票结果通知
    """

    def __init__(
        self,
        node_id: str,
        default_threshold: float = 0.67,
        default_timeout: float = 30.0,
    ):
        self._node_id = node_id
        self._default_threshold = default_threshold
        self._default_timeout = default_timeout
        self._rounds: Dict[str, VotingRound] = {}
        self._vote_counter = 0
        self._callbacks: Dict[str, List[Callable]] = {}
        self._is_running = False
        self._timeout_task: Optional[asyncio.Task] = None
        self._trusted_voters: Dict[str, bytes] = {}  # voter_id -> verify_key

    def register_voter(self, voter_id: str, verify_key: bytes) -> None:
        """
        注册受信任的投票者

        Args:
            voter_id: 投票者ID
            verify_key: 验证密钥 (用于 HMAC-SHA256 签名验证)
        """
        self._trusted_voters[voter_id] = verify_key
        logger.info(f"注册受信任投票者: {voter_id}")

    @property
    def active_rounds(self) -> int:
        return sum(1 for r in self._rounds.values() if not r.is_closed)

    def on_result(self, round_id: str, callback: Callable) -> None:
        """注册结果回调"""
        if round_id not in self._callbacks:
            self._callbacks[round_id] = []
        self._callbacks[round_id].append(callback)

    def create_round(
        self,
        vote_type: VoteType,
        proposal: bytes,
        threshold: Optional[float] = None,
        timeout: Optional[float] = None,
    ) -> VotingRound:
        """
        创建投票轮次

        Args:
            vote_type: 投票类型
            proposal: 提案内容
            threshold: 通过阈值
            timeout: 超时时间

        Returns:
            投票轮次
        """
        self._vote_counter += 1
        round_id = hashlib.sha256(
            f"{self._node_id}-{self._vote_counter}-{time.time()}".encode()
        ).hexdigest()[:16]

        round_obj = VotingRound(
            round_id=round_id,
            vote_type=vote_type,
            proposal=proposal,
            proposer_id=self._node_id,
            threshold=threshold or self._default_threshold,
            timeout=timeout or self._default_timeout,
        )

        self._rounds[round_id] = round_obj
        logger.info(f"创建投票轮次 {round_id}: {vote_type.value}")
        return round_obj

    def cast_vote(
        self,
        round_id: str,
        voter_id: str,
        decision: bool,
        signature: bytes = b"",
        reason: str = "",
    ) -> bool:
        """
        投票

        Args:
            round_id: 投票轮次ID
            voter_id: 投票者ID
            decision: 决定 (True=赞成, False=反对)
            signature: 签名
            reason: 原因

        Returns:
            是否投票成功
        """
        round_obj = self._rounds.get(round_id)
        if not round_obj or round_obj.is_closed:
            return False

        if voter_id in round_obj.votes:
            logger.warning(f"投票者 {voter_id} 已在轮次 {round_id} 中投票")
            return False

        # 签名验证：如果投票者已注册且提供了签名，则验证
        if voter_id in self._trusted_voters:
            verify_key = self._trusted_voters[voter_id]
            if signature:
                # 使用 HMAC-SHA256 验证签名
                # vote_data 作为消息内容
                vote_data = f"{round_id}:{voter_id}:{decision}".encode()
                expected_mac = hmac.new(verify_key, vote_data, hashlib.sha256).digest()
                if not hmac.compare_digest(signature, expected_mac):
                    logger.warning(f"投票者 {voter_id} 签名验证失败")
                    return False
            else:
                logger.warning(f"投票者 {voter_id} 已注册但未提供签名")
        else:
            if voter_id not in self._trusted_voters:
                logger.warning(f"投票者 {voter_id} 未注册，仍然允许投票")

        vote = Vote(
            vote_id=f"{round_id}-{voter_id}",
            vote_type=round_obj.vote_type,
            proposal=round_obj.proposal,
            voter_id=voter_id,
            decision=decision,
            signature=signature,
            reason=reason,
        )
        round_obj.votes[voter_id] = vote

        logger.debug(
            f"投票: {voter_id} -> {round_id} = "
            f"{'赞成' if decision else '反对'} "
            f"({round_obj.approval_ratio:.0%})"
        )

        # 检查是否已达到阈值
        if round_obj.is_passed:
            self._close_round(round_id, VoteResult.APPROVED)
        elif round_obj.total_votes > 0 and round_obj.reject_count / round_obj.total_votes > (1 - round_obj.threshold):
            self._close_round(round_id, VoteResult.REJECTED)

        return True

    def _close_round(self, round_id: str, result: VoteResult) -> None:
        """关闭投票轮次"""
        round_obj = self._rounds.get(round_id)
        if not round_obj:
            return
        round_obj.is_closed = True
        round_obj.result = result
        logger.info(
            f"投票轮次 {round_id} 结束: {result.value} "
            f"({round_obj.approve_count}/{round_obj.total_votes})"
        )
        # 通知回调
        for callback in self._callbacks.get(round_id, []):
            try:
                callback(round_obj)
            except Exception as e:
                logger.error(f"投票回调错误: {e}")

    def get_round(self, round_id: str) -> Optional[VotingRound]:
        """获取投票轮次"""
        return self._rounds.get(round_id)

    def get_active_rounds(self) -> List[VotingRound]:
        """获取活跃的投票轮次"""
        return [r for r in self._rounds.values() if not r.is_closed]

    async def _timeout_loop(self) -> None:
        """超时检查循环"""
        while self._is_running:
            try:
                now = time.time()
                for round_obj in list(self._rounds.values()):
                    if not round_obj.is_closed:
                        elapsed = now - round_obj.created_at
                        if elapsed > round_obj.timeout:
                            self._close_round(round_obj, VoteResult.TIMEOUT)
            except asyncio.CancelledError:
                break
            await asyncio.sleep(1)

    async def start(self) -> None:
        """启动投票器"""
        self._is_running = True
        self._timeout_task = asyncio.create_task(self._timeout_loop())

    async def stop(self) -> None:
        """停止投票器"""
        self._is_running = False
        if self._timeout_task:
            self._timeout_task.cancel()
            try:
                await self._timeout_task
            except asyncio.CancelledError:
                pass
        # 关闭所有活跃轮次
        for round_obj in self._rounds.values():
            if not round_obj.is_closed:
                self._close_round(round_obj.round_id, VoteResult.CANCELLED)
