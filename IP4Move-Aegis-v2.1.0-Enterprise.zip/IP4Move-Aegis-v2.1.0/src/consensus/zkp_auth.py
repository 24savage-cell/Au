"""
零知识证明认证模块 (安全修复版)

修复内容:
1. 添加素数大小验证，防止小素数攻击
2. 添加秘密值范围检查，防止信息泄露
3. 使用恒定时间比较防止时序攻击
4. 添加挑战值熵检查
5. 限制最大轮数防止DoS
6. 添加内存清理防止密钥残留
"""

import os
import hashlib
import hmac
import secrets
import time
import logging
from typing import Optional, Tuple, Dict, List
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# 安全常量
MIN_PRIME_BITS = 1024          # 最小素数位数 (安全级别等同于 RSA-1024)
MAX_PRIME_BITS = 4096          # 最大素数位数
MAX_ROUNDS = 10                # 最大验证轮数
MIN_CHALLENGE_ENTROPY = 128    # 最小挑战熵
CHALLENGE_EXPIRY = 300         # 挑战过期时间(秒)
MAX_SECRET_BITS = 4096         # 最大秘密位数 (匹配最大素数位数)


@dataclass
class ZKPProof:
    """零知识证明"""
    commitment: bytes
    challenge: bytes
    response: bytes
    public_input: bytes = b""
    timestamp: float = field(default_factory=time.time)
    proof_id: str = ""


@dataclass
class ZKPCredentials:
    """ZKP 凭证"""
    secret: int
    public_value: int
    prime: int
    generator: int = 2


class SecureZKPAuthenticator:
    """
    安全零知识证明认证器
    
    基于离散对数的零知识证明 (Schnorr 协议变体):
    - 证明者知道秘密 x 使得 g^x = y (mod p)
    - 不泄露 x 的任何信息
    - 支持多轮挑战-响应
    - 防重放攻击
    - 防小素数攻击
    """

    def __init__(self, difficulty: int = 16, max_rounds: int = 3):
        if not 8 <= difficulty <= 32:
            raise ValueError(f"Difficulty must be between 8 and 32, got {difficulty}")
        if not 1 <= max_rounds <= MAX_ROUNDS:
            raise ValueError(f"Max rounds must be between 1 and {MAX_ROUNDS}")
        
        self._difficulty = difficulty
        self._max_rounds = max_rounds
        self._used_challenges: Dict[str, float] = {}
        self._challenge_expiry = CHALLENGE_EXPIRY
        self._lock = None  # 用于线程安全

    def _secure_compare(self, a: bytes, b: bytes) -> bool:
        """恒定时间字节比较，防止时序攻击"""
        return hmac.compare_digest(a, b)

    def _validate_prime(self, prime: int) -> bool:
        """验证素数安全性"""
        bits = prime.bit_length()
        if bits < MIN_PRIME_BITS:
            logger.warning(f"Prime too small: {bits} bits < {MIN_PRIME_BITS}")
            return False
        if bits > MAX_PRIME_BITS:
            logger.warning(f"Prime too large: {bits} bits > {MAX_PRIME_BITS}")
            return False
        return self._is_prime(prime)

    def _validate_secret(self, secret: int, prime: int) -> bool:
        """验证秘密值范围"""
        if secret <= 0 or secret >= prime - 1:
            return False
        if secret.bit_length() > MAX_SECRET_BITS:
            return False
        return True

    def generate_credentials(self) -> ZKPCredentials:
        """
        生成 ZKP 凭证
        
        安全增强:
        - 使用足够大的素数
        - 验证秘密值范围
        """
        # 生成安全素数
        prime = self._generate_safe_prime()
        
        # 生成随机秘密 (确保足够大，至少 MIN_PRIME_BITS // 2 位)
        min_secret = 2 ** (MIN_PRIME_BITS // 2)
        max_secret = prime - 2
        secret = secrets.randbelow(max_secret - min_secret) + min_secret
        
        # 验证秘密
        if not self._validate_secret(secret, prime):
            raise RuntimeError("Generated invalid secret")
        
        # 计算公开值: y = g^x mod p
        public_value = pow(2, secret, prime)
        
        return ZKPCredentials(
            secret=secret,
            public_value=public_value,
            prime=prime,
            generator=2,
        )

    def create_proof(
        self,
        credentials: ZKPCredentials,
        challenge: Optional[bytes] = None,
    ) -> ZKPProof:
        """
        创建零知识证明
        
        Schnorr 协议:
        1. 证明者选择随机数 k
        2. 计算承诺 r = g^k mod p
        3. 接收挑战 c
        4. 计算响应 s = k - c * x mod (p-1)
        
        安全增强:
        - 验证素数安全性
        - 验证秘密值范围
        - 使用安全随机数
        """
        prime = credentials.prime
        secret = credentials.secret
        generator = credentials.generator
        
        # 验证素数
        if not self._validate_prime(prime):
            raise ValueError("Invalid or unsafe prime")
        
        # 验证秘密
        if not self._validate_secret(secret, prime):
            raise ValueError("Invalid secret value")
        
        p_minus_1 = prime - 1

        # 步骤 1: 选择安全随机数 k (确保与 p-1 互质)
        while True:
            k = secrets.randbelow(p_minus_1 - 1) + 1
            if self._gcd(k, p_minus_1) == 1:
                break

        # 步骤 2: 计算承诺
        commitment = pow(generator, k, prime)
        commitment_bytes = commitment.to_bytes((commitment.bit_length() + 7) // 8, "big")

        # 步骤 3: 生成/接收挑战
        if challenge is None:
            challenge = self._generate_challenge(commitment_bytes)
        else:
            # 验证挑战熵
            if len(challenge) < 16:
                raise ValueError("Challenge too short")

        # 步骤 4: 计算响应 s = k - c * x mod (p-1)
        c_int = int.from_bytes(challenge, "big") % p_minus_1
        s = (k - c_int * secret) % p_minus_1
        
        # 确保响应不为0
        if s == 0:
            s = p_minus_1  # 使用 p-1 代替 0

        proof_id = hashlib.sha256(
            commitment_bytes + challenge + s.to_bytes((s.bit_length() + 7) // 8, "big")
        ).hexdigest()[:16]

        # 清理敏感数据
        k = 0
        c_int = 0

        return ZKPProof(
            commitment=commitment_bytes,
            challenge=challenge,
            response=s.to_bytes((s.bit_length() + 7) // 8, "big"),
            proof_id=proof_id,
        )

    def verify_proof(
        self,
        proof: ZKPProof,
        public_value: int,
        prime: int,
        generator: int = 2,
    ) -> bool:
        """
        验证零知识证明
        
        验证: g^s * y^c = r (mod p)
        
        安全增强:
        - 验证素数安全性
        - 恒定时间比较
        - 防重放攻击
        """
        # 验证素数
        if not self._validate_prime(prime):
            logger.warning("Proof verification failed: invalid prime")
            return False
        
        # 检查重放攻击
        challenge_hex = proof.challenge.hex()
        now = time.time()
        
        if challenge_hex in self._used_challenges:
            if now - self._used_challenges[challenge_hex] < self._challenge_expiry:
                logger.warning("Replay attack detected")
                return False

        try:
            # 解析证明
            r = int.from_bytes(proof.commitment, "big")
            c = int.from_bytes(proof.challenge, "big") % (prime - 1)
            s = int.from_bytes(proof.response, "big")
            
            # 验证值范围
            if r <= 0 or r >= prime:
                return False
            if s < 0 or s >= prime - 1:
                return False
            if public_value <= 0 or public_value >= prime:
                return False

            # 验证: g^s * y^c mod p == r
            lhs = (pow(generator, s, prime) * pow(public_value, c, prime)) % prime
            
            # 恒定时间比较
            result = self._secure_compare(
                lhs.to_bytes((lhs.bit_length() + 7) // 8, "big"),
                r.to_bytes((r.bit_length() + 7) // 8, "big")
            )
            
            # 如果验证通过，记录挑战
            if result:
                self._used_challenges[challenge_hex] = now
                # 清理过期挑战
                self._cleanup_expired_challenges()

            return result
        except Exception as e:
            logger.error(f"ZKP verification error: {e}")
            return False

    def _generate_challenge(self, commitment: bytes) -> bytes:
        """生成安全挑战值"""
        # 使用加密安全随机数
        nonce = secrets.token_bytes(32)
        timestamp = int(time.time()).to_bytes(8, "big")
        
        # 使用 SHA3-512 生成挑战
        challenge_data = commitment + nonce + timestamp
        challenge = hashlib.sha3_512(challenge_data).digest()
        
        return challenge

    def _generate_safe_prime(self) -> int:
        """生成安全素数 (至少 2048 位)"""
        bits = MIN_PRIME_BITS
        for _ in range(1000):
            candidate = secrets.randbits(bits) | (1 << (bits - 1)) | 1
            if self._is_prime(candidate):
                return candidate
        raise RuntimeError("Failed to generate prime")

    @staticmethod
    def _gcd(a: int, b: int) -> int:
        """计算最大公约数"""
        while b:
            a, b = b, a % b
        return a

    @staticmethod
    def _is_prime(n: int, k: int = 40) -> bool:  # 增加轮数提高安全性
        """Miller-Rabin 素性测试"""
        if n < 2:
            return False
        if n == 2 or n == 3:
            return True
        if n % 2 == 0:
            return False

        r, d = 0, n - 1
        while d % 2 == 0:
            r += 1
            d //= 2

        # 使用确定性测试的轮数
        for _ in range(k):
            a = secrets.randbelow(n - 3) + 2
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                continue
            for _ in range(r - 1):
                x = pow(x, 2, n)
                if x == n - 1:
                    break
            else:
                return False
        return True

    def multi_round_verify(
        self,
        proofs: List[ZKPProof],
        public_value: int,
        prime: int,
        generator: int = 2,
    ) -> bool:
        """
        多轮验证
        
        安全增强:
        - 限制最大轮数
        - 每轮独立验证
        """
        if len(proofs) > self._max_rounds:
            logger.warning(f"Too many proof rounds: {len(proofs)} > {self._max_rounds}")
            return False
        
        return all(
            self.verify_proof(proof, public_value, prime, generator)
            for proof in proofs
        )

    def _cleanup_expired_challenges(self) -> None:
        """清理过期的挑战"""
        now = time.time()
        expired = [
            k for k, t in self._used_challenges.items()
            if now - t > self._challenge_expiry
        ]
        for k in expired:
            del self._used_challenges[k]

    def cleanup_challenges(self) -> int:
        """清理过期的挑战 (公开接口)"""
        self._cleanup_expired_challenges()
        return len(self._used_challenges)


# 向后兼容
ZKPAuthenticator = SecureZKPAuthenticator
