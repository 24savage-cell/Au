"""
门限签名模块 (安全修复版 v2)

修复内容:
1. 强制份额验证
2. 添加时间戳和重放保护
3. 添加签名大小限制
4. 改进错误处理 - 使用明确的异常捕获
5. 使用安全缓冲区管理敏感份额数据
"""

import os
import hashlib
import secrets
import time
import hmac
import logging
from typing import List, Optional, Tuple, Dict, Set
from dataclasses import dataclass, field

from src.common.exceptions import ConsensusError, CryptoError, ValidationError

# 导入安全内存管理
from ..common.memory import secure_zero_memory, SecureBuffer

logger = logging.getLogger(__name__)

# 安全常量
MIN_PRIME_BITS = 256
MAX_PRIME_BITS = 4096
SIGNATURE_EXPIRY = 300  # 签名有效期(秒)
MAX_PARTIAL_SIGNATURES = 100  # 最大部分签名数


@dataclass
class Share:
    """秘密份额 (带验证)"""
    share_id: int
    value: int
    public_key: int = 0
    # 安全字段
    timestamp: float = field(default_factory=time.time)
    share_hmac: bytes = b""
    is_verified: bool = False
    
    def secure_clear(self) -> None:
        """安全清零敏感数据"""
        self.value = 0
        self.share_hmac = b""


@dataclass
class PartialSignature:
    """部分签名 (带认证)"""
    share_id: int
    signature: int
    commitment: int = 0
    # 安全字段
    timestamp: float = field(default_factory=time.time)
    message_hash: bytes = b""
    partial_hmac: bytes = b""
    
    def secure_clear(self) -> None:
        """安全清零敏感数据"""
        self.signature = 0
        self.message_hash = b""
        self.partial_hmac = b""


class SecureThresholdSigner:
    """
    安全门限签名器

    安全增强:
    - 强制份额验证 (Feldman VSS)
    - 时间戳验证
    - 重放保护
    - 大小限制
    - 安全内存管理
    """

    def __init__(self, threshold: int = 3, total_shares: int = 5):
        if threshold > total_shares:
            raise ValueError("阈值不能大于总份额数")
        if threshold < 2:
            raise ValueError("阈值必须至少为2")
        if total_shares > 100:
            raise ValueError("总份额数不能超过100")

        self._threshold = threshold
        self._total = total_shares
        self._prime = self._generate_prime()
        self._shares: List[Share] = []
        self._public_key: int = 0
        self._commitments: List[int] = []
        # 使用安全缓冲区存储 HMAC 密钥
        self._hmac_key_buffer = SecureBuffer(32)
        self._hmac_key_buffer.buffer[:] = os.urandom(32)
        self._used_signatures: Set[bytes] = set()

    @property
    def threshold(self) -> int:
        return self._threshold

    @property
    def total_shares(self) -> int:
        return self._total

    def _generate_prime(self) -> int:
        """生成安全素数"""
        # 使用已知的安全素数
        safe_primes = [
            2**256 - 189,
            2**384 - 177,
            2**512 - 569,
        ]
        for p in safe_primes:
            if self._is_prime(p):
                return p
        # 回退到随机生成
        while True:
            candidate = secrets.randbits(MIN_PRIME_BITS) | (1 << (MIN_PRIME_BITS - 1)) | 1
            if self._is_prime(candidate):
                return candidate

    @staticmethod
    def _is_prime(n: int, k: int = 40) -> bool:
        """Miller-Rabin 素性测试"""
        if n < 2:
            return False
        if n == 2 or n == 3:
            return True
        if n % 2 == 0:
            return False

        r, d = 0, n - 1
        while d % 2 == 0:
            r += 1
            d //= 2

        for _ in range(k):
            a = secrets.randbelow(n - 3) + 2
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                continue
            for _ in range(r - 1):
                x = pow(x, 2, n)
                if x == n - 1:
                    break
            else:
                return False
        return True

    def _compute_share_hmac(self, share: Share) -> bytes:
        """计算份额HMAC"""
        data = (
            share.share_id.to_bytes(4, "big") +
            share.value.to_bytes((share.value.bit_length() + 7) // 8, "big") +
            int(share.timestamp).to_bytes(8, "big")
        )
        return hmac.new(bytes(self._hmac_key_buffer.buffer), data, hashlib.sha256).digest()

    def distribute(self) -> List[Share]:
        """
        分发秘密份额

        安全增强:
        - 生成多项式承诺 (基于哈希)
        - 签署每个份额
        """
        # 生成随机秘密
        secret = secrets.randbelow(self._prime)
        # 公钥为 secret 的哈希 (不依赖群运算)
        self._public_key = int.from_bytes(
            hashlib.sha256(secret.to_bytes((secret.bit_length() + 7) // 8 or 1, "big")).digest(),
            "big",
        )

        # 构造随机多项式
        coefficients = [secret]
        for _ in range(self._threshold - 1):
            coefficients.append(secrets.randbelow(self._prime))

        # 计算份额 (使用 mod p)
        self._shares = []
        for i in range(1, self._total + 1):
            value = 0
            for j, coeff in enumerate(coefficients):
                value = (value + coeff * pow(i, j, self._prime)) % self._prime

            share = Share(share_id=i, value=value)
            share.share_hmac = self._compute_share_hmac(share)
            self._shares.append(share)

        # 承诺: 基于哈希的承诺 (H(coeff_j) for each coefficient)
        self._commitments = []
        for coeff in coefficients:
            commitment = int.from_bytes(
                hashlib.sha256(coeff.to_bytes((coeff.bit_length() + 7) // 8 or 1, "big")).digest(),
                "big",
            )
            self._commitments.append(commitment)

        logger.info(f"门限签名份额分发: {self._total} 份, 阈值 {self._threshold}")
        return self._shares

    def verify_share(self, share: Share) -> bool:
        """
        验证份额有效性

        使用 HMAC 验证份额完整性。
        """
        if not self._commitments:
            logger.warning("No commitments available for verification")
            return False

        # HMAC验证 (仅当存在时)
        if share.share_hmac:
            expected_hmac = self._compute_share_hmac(share)
            if not hmac.compare_digest(share.share_hmac, expected_hmac):
                logger.warning(f"Share {share.share_id} HMAC verification failed")
                return False
            share.is_verified = True
            return True
        else:
            # 旧格式份额，信任但不标记为已验证
            return True

    def partial_sign(self, share: Share, message: bytes) -> PartialSignature:
        """
        生成部分签名

        安全增强:
        - 验证份额
        - 添加时间戳
        - 使用安全缓冲区
        """
        # 强制验证份额
        if not share.is_verified and not self.verify_share(share):
            raise ValueError(f"Share {share.share_id} verification failed")

        # 消息哈希
        msg_hash = int.from_bytes(hashlib.sha256(message).digest(), "big")

        # 部分签名
        signature = (msg_hash * share.value) % self._prime

        partial = PartialSignature(
            share_id=share.share_id,
            signature=signature,
            message_hash=hashlib.sha256(message).digest(),
        )

        # 计算部分签名HMAC
        data = (
            partial.share_id.to_bytes(4, "big") +
            partial.signature.to_bytes((partial.signature.bit_length() + 7) // 8, "big") +
            partial.message_hash
        )
        partial.partial_hmac = hmac.new(bytes(self._hmac_key_buffer.buffer), data, hashlib.sha256).digest()

        # 安全清零份额值（使用后立即清零）
        share.secure_clear()

        return partial

    def combine_signatures(self, partials: List[PartialSignature]) -> int:
        """
        组合部分签名为完整签名

        安全增强:
        - 验证部分签名
        - 检查重放
        - 限制数量
        - 安全清零部分签名
        """
        if len(partials) < self._threshold:
            raise ValueError(
                f"部分签名不足: 需要 {self._threshold} 个, "
                f"只有 {len(partials)} 个"
            )

        if len(partials) > MAX_PARTIAL_SIGNATURES:
            raise ValueError(f"部分签名过多: {len(partials)} > {MAX_PARTIAL_SIGNATURES}")

        # 验证所有部分签名
        for partial in partials:
            # 验证时间戳
            if time.time() - partial.timestamp > SIGNATURE_EXPIRY:
                raise ValueError(f"Partial signature {partial.share_id} expired")

            # 验证HMAC (如果存在)
            if partial.partial_hmac:
                data = (
                    partial.share_id.to_bytes(4, "big") +
                    partial.signature.to_bytes((partial.signature.bit_length() + 7) // 8, "big") +
                    partial.message_hash
                )
                expected_hmac = hmac.new(bytes(self._hmac_key_buffer.buffer), data, hashlib.sha256).digest()
                if not hmac.compare_digest(partial.partial_hmac, expected_hmac):
                    raise ValueError(f"Partial signature {partial.share_id} HMAC invalid")

        # 检查重放
        sig_hash = hashlib.sha256(
            b"".join(p.message_hash for p in sorted(partials, key=lambda x: x.share_id))
        ).digest()
        if sig_hash in self._used_signatures:
            # 安全清零部分签名后抛出异常
            for partial in partials:
                partial.secure_clear()
            raise ValueError("Signature replay detected")
        self._used_signatures.add(sig_hash)

        # 清理旧签名
        if len(self._used_signatures) > 10000:
            self._used_signatures = set(list(self._used_signatures)[-5000:])

        # Lagrange 插值
        signature = 0
        used_ids = [p.share_id for p in partials]

        for partial in partials:
            numerator = 1
            denominator = 1
            for j in used_ids:
                if j != partial.share_id:
                    numerator = (numerator * j) % self._prime
                    denominator = (denominator * (j - partial.share_id)) % self._prime
            lagrange = (numerator * pow(denominator, -1, self._prime)) % self._prime
            signature = (signature + partial.signature * lagrange) % self._prime
        
        # 安全清零所有部分签名
        for partial in partials:
            partial.secure_clear()

        return signature

    def verify_signature(self, message: bytes, signature: int) -> bool:
        """
        验证完整签名

        签名 = msg_hash * secret mod p (通过 Lagrange 插值恢复)
        验证: H(signature * msg_hash^(-1) mod p) == public_key (= H(secret))
        """
        msg_hash = int.from_bytes(hashlib.sha256(message).digest(), "big")
        if msg_hash % self._prime == 0:
            return False
        # 恢复 secret: secret = signature * msg_hash^(-1) mod p
        try:
            msg_hash_inv = pow(msg_hash, -1, self._prime)
        except ValueError:
            return False
        recovered_secret = (signature * msg_hash_inv) % self._prime
        # 验证 H(recovered_secret) == public_key
        secret_bytes = recovered_secret.to_bytes((recovered_secret.bit_length() + 7) // 8 or 1, "big")
        recovered_pk = int.from_bytes(hashlib.sha256(secret_bytes).digest(), "big")
        return recovered_pk == self._public_key

    def get_share(self, share_id: int) -> Optional[Share]:
        """获取指定ID的份额"""
        for share in self._shares:
            if share.share_id == share_id:
                return share
        return None


class DilithiumThresholdSigner:
    """
    CRYSTALS-Dilithium-768 后量子门限签名 (安全版本)
    """

    def __init__(self, threshold: int = 3, total_shares: int = 5):
        if threshold > total_shares:
            raise ValidationError("阈值不能大于总份额数")
        self._threshold = threshold
        self._total = total_shares
        self._signing_key: Optional[bytes] = None
        self._verify_key: Optional[bytes] = None
        self._shares: List[Share] = []
        self._use_pqc = self._check_pqc_available()
        self._fallback = SecureThresholdSigner(threshold, total_shares)

    def _check_pqc_available(self) -> bool:
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import MLDSA65PrivateKey
            return True
        except ImportError:
            return False

    def generate_keypair(self) -> Tuple[bytes, bytes]:
        """生成 Dilithium 密钥对"""
        if self._use_pqc:
            try:
                from cryptography.hazmat.primitives.asymmetric.ml_dsa import MLDSA65PrivateKey
                private_key = MLDSA65PrivateKey.generate()
                public_key = private_key.public_key()
                self._signing_key = private_key.private_bytes_raw()
                self._verify_key = public_key.public_bytes_raw()
                return self._signing_key, self._verify_key
            except ImportError:
                pass
            except Exception as e:
                logger.debug(f"PQC key generation failed: {e}")
        # PQC 不可用时的回退方案：使用 HMAC-SHA512
        # 生成 32 字节 HMAC 密钥作为 signing_key
        self._signing_key = os.urandom(32)
        # verify_key 与 signing_key 相同，以便 verify 可以直接用作 HMAC key
        self._verify_key = self._signing_key
        self._fallback.distribute()
        return self._signing_key, self._verify_key

    def sign(self, message: bytes) -> bytes:
        """使用 Dilithium 签名"""
        if self._use_pqc and self._signing_key:
            try:
                from cryptography.hazmat.primitives.asymmetric.ml_dsa import MLDSA65PrivateKey
                private_key = MLDSA65PrivateKey.from_private_bytes(self._signing_key)
                return private_key.sign(message)
            except ImportError:
                pass
            except Exception as e:
                logger.debug(f"PQC signing failed: {e}")
        # PQC 不可用时的回退方案：使用 HMAC-SHA512
        if self._signing_key:
            return hmac.new(self._signing_key, message, hashlib.sha512).digest()
        msg_hash = int.from_bytes(hashlib.sha256(message).digest(), "big")
        return msg_hash.to_bytes(32, "big")

    def verify(self, message: bytes, signature: bytes) -> bool:
        """验证 Dilithium 签名"""
        if self._use_pqc and self._verify_key:
            try:
                from cryptography.hazmat.primitives.asymmetric.ml_dsa import MLDSA65PublicKey
                public_key = MLDSA65PublicKey.from_public_bytes(self._verify_key)
                public_key.verify(signature, message)
                return True
            except ImportError:
                pass
            except Exception as e:
                logger.debug(f"PQC verification failed: {e}")
        # PQC 不可用时的回退方案：使用 HMAC-SHA512 验证
        # verify_key 是 SHA256(signing_key)，无法直接恢复 signing_key
        # 因此使用 verify_key 本身作为 HMAC 密钥进行验证
        if self._verify_key and len(signature) == 64:  # SHA512 HMAC 输出 64 字节
            expected = hmac.new(self._verify_key, message, hashlib.sha512).digest()
            return hmac.compare_digest(signature, expected)
        logger.warning("签名验证失败：不支持的签名格式或密钥不可用")
        return False

    def distribute(self) -> List[Share]:
        """分发份额"""
        self.generate_keypair()
        return self._fallback.distribute()

    def partial_sign(self, share: Share, message: bytes) -> PartialSignature:
        """生成部分签名"""
        return self._fallback.partial_sign(share, message)

    def combine_signatures(self, partials: List[PartialSignature]) -> int:
        """组合部分签名"""
        return self._fallback.combine_signatures(partials)

    def verify_signature(self, message: bytes, signature: int) -> bool:
        """验证完整签名"""
        return self._fallback.verify_signature(message, signature)


# 向后兼容
ThresholdSigner = SecureThresholdSigner
