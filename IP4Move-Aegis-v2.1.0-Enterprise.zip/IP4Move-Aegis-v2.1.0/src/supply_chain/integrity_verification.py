"""
供应链完整性验证模块 (Supply Chain Integrity Verification Module)

本模块实现了软件供应链的完整性验证功能，包含四个核心组件：
1. DependencySignatureVerifier - 依赖库签名验证器（PGP/GPG、SHA-256、pip包签名）
2. VulnerabilityScanner - 依赖库漏洞扫描器（CVE数据库查询、严重程度分级）
3. MinimalDependencyManager - 最小化依赖管理器（依赖树分析、许可证合规）
4. BuildSigner - 构建过程签名器（构建环境指纹、源代码哈希链、可重现构建）

安全级别：供应链完整性 Level 3
兼容性：Python 3.10+

This module implements supply chain integrity verification with four core components:
1. DependencySignatureVerifier - Dependency signature verification (PGP/GPG, SHA-256, pip signatures)
2. VulnerabilityScanner - Dependency vulnerability scanning (CVE database, severity classification)
3. MinimalDependencyManager - Minimal dependency management (dependency tree, license compliance)
4. BuildSigner - Build process signing (build fingerprint, source hash chain, reproducible builds)
"""

import hashlib
import json
import logging
import os
import re
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ============================================================
# 数据模型定义 (Data Models)
# ============================================================


class SignatureAlgorithm(Enum):
    """签名算法枚举 (Signature algorithm enumeration)"""
    PGP = "pgp"
    GPG = "gpg"
    SHA256 = "sha256"
    SHA512 = "sha512"
    ED25519 = "ed25519"
    RSA_PSS = "rsa-pss"


class VulnerabilitySeverity(Enum):
    """漏洞严重程度枚举 (Vulnerability severity enumeration)"""
    CRITICAL = "critical"      # 严重 - 需要立即修复
    HIGH = "high"              # 高危 - 24小时内修复
    MEDIUM = "medium"          # 中危 - 7天内修复
    LOW = "low"                # 低危 - 30天内修复
    INFO = "info"              # 信息 - 建议关注


class LicenseType(Enum):
    """许可证类型枚举 (License type enumeration)"""
    MIT = "mit"
    APACHE_2 = "apache-2.0"
    BSD_2 = "bsd-2-clause"
    BSD_3 = "bsd-3-clause"
    GPL_2 = "gpl-2.0"
    GPL_3 = "gpl-3.0"
    LGPL_3 = "lgpl-3.0"
    MPL_2 = "mpl-2.0"
    ISC = "isc"
    UNLICENSE = "unlicense"
    PROPRIETARY = "proprietary"
    UNKNOWN = "unknown"


@dataclass
class SignatureVerificationResult:
    """签名验证结果 (Signature verification result)

    Attributes:
        package_name: 包名称
        version: 包版本
        is_valid: 签名是否有效
        algorithm: 使用的验证算法
        fingerprint: 签名指纹（如有）
        error_message: 错误信息（如验证失败）
        verified_at: 验证时间戳
    """
    package_name: str
    version: str
    is_valid: bool
    algorithm: SignatureAlgorithm
    fingerprint: Optional[str] = None
    error_message: Optional[str] = None
    verified_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式 (Convert to dictionary format)"""
        return {
            "package_name": self.package_name,
            "version": self.version,
            "is_valid": self.is_valid,
            "algorithm": self.algorithm.value,
            "fingerprint": self.fingerprint,
            "error_message": self.error_message,
            "verified_at": self.verified_at.isoformat(),
        }


@dataclass
class VulnerabilityInfo:
    """漏洞信息 (Vulnerability information)

    Attributes:
        cve_id: CVE编号
        package_name: 受影响的包名称
        affected_versions: 受影响的版本范围
        severity: 严重程度
        description: 漏洞描述
        fix_version: 修复版本
        references: 参考链接
        published_date: 发布日期
    """
    cve_id: str
    package_name: str
    affected_versions: str
    severity: VulnerabilitySeverity
    description: str
    fix_version: Optional[str] = None
    references: List[str] = field(default_factory=list)
    published_date: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式 (Convert to dictionary format)"""
        return {
            "cve_id": self.cve_id,
            "package_name": self.package_name,
            "affected_versions": self.affected_versions,
            "severity": self.severity.value,
            "description": self.description,
            "fix_version": self.fix_version,
            "references": self.references,
            "published_date": self.published_date.isoformat() if self.published_date else None,
        }


@dataclass
class DependencyInfo:
    """依赖信息 (Dependency information)

    Attributes:
        name: 包名称
        version: 版本号
        is_direct: 是否为直接依赖
        is_used: 是否被实际使用
        license_type: 许可证类型
        size_bytes: 包大小（字节）
        transitive_count: 传递依赖数量
    """
    name: str
    version: str
    is_direct: bool = True
    is_used: bool = True
    license_type: LicenseType = LicenseType.UNKNOWN
    size_bytes: int = 0
    transitive_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式 (Convert to dictionary format)"""
        return {
            "name": self.name,
            "version": self.version,
            "is_direct": self.is_direct,
            "is_used": self.is_used,
            "license_type": self.license_type.value,
            "size_bytes": self.size_bytes,
            "transitive_count": self.transitive_count,
        }


@dataclass
class BuildArtifact:
    """构建产物信息 (Build artifact information)

    Attributes:
        artifact_path: 产物路径
        artifact_hash: 产物哈希值
        source_hash_chain: 源代码哈希链
        environment_fingerprint: 构建环境指纹
        build_timestamp: 构建时间戳
        signature: 数字签名
    """
    artifact_path: str
    artifact_hash: str
    source_hash_chain: List[str]
    environment_fingerprint: str
    build_timestamp: datetime
    signature: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式 (Convert to dictionary format)"""
        return {
            "artifact_path": self.artifact_path,
            "artifact_hash": self.artifact_hash,
            "source_hash_chain": self.source_hash_chain,
            "environment_fingerprint": self.environment_fingerprint,
            "build_timestamp": self.build_timestamp.isoformat(),
            "signature": self.signature,
        }


# ============================================================
# 依赖库签名验证器 (Dependency Signature Verifier)
# ============================================================


class DependencySignatureVerifier:
    """依赖库签名验证器 (Dependency Signature Verifier)

    提供对Python依赖库的多层签名验证机制，包括：
    - PGP/GPG签名验证：验证包发布者的数字签名
    - SHA-256校验和验证：验证包内容的完整性
    - pip包签名验证：通过pip audit验证包签名
    - 依赖链完整性检查：递归验证整个依赖链的签名
    - 签名不匹配时自动阻止：防止安装未经验证的包

    Provides multi-layer signature verification for Python dependencies:
    - PGP/GPG signature verification
    - SHA-256 checksum verification
    - pip package signature verification
    - Dependency chain integrity checking
    - Automatic blocking on signature mismatch
    """

    def __init__(
        self,
        gpg_keyring_path: Optional[str] = None,
        trusted_keys: Optional[List[str]] = None,
        block_on_failure: bool = True,
        cache_dir: Optional[str] = None,
    ) -> None:
        """初始化签名验证器 (Initialize signature verifier)

        Args:
            gpg_keyring_path: GPG密钥环路径，默认使用系统密钥环
            trusted_keys: 受信任的GPG密钥指纹列表
            block_on_failure: 签名验证失败时是否阻止安装
            cache_dir: 验证结果缓存目录
        """
        self.gpg_keyring_path: Optional[str] = gpg_keyring_path
        self.trusted_keys: Set[str] = set(trusted_keys or [])
        self.block_on_failure: bool = block_on_failure
        self.cache_dir: str = cache_dir or os.path.join(tempfile.gettempdir(), "sig_verify_cache")
        self._verification_cache: Dict[str, SignatureVerificationResult] = {}
        self._blocked_packages: Set[str] = set()

        # 创建缓存目录
        os.makedirs(self.cache_dir, exist_ok=True)

        logger.info(
            "签名验证器初始化完成: block_on_failure=%s, trusted_keys=%d",
            self.block_on_failure,
            len(self.trusted_keys),
        )

    def verify_package(
        self,
        package_name: str,
        version: str,
        algorithm: SignatureAlgorithm = SignatureAlgorithm.SHA256,
    ) -> SignatureVerificationResult:
        """验证单个包的签名 (Verify signature of a single package)

        Args:
            package_name: 包名称
            version: 包版本号
            algorithm: 使用的验证算法

        Returns:
            SignatureVerificationResult: 签名验证结果

        Raises:
            RuntimeError: 当签名验证失败且block_on_failure为True时
        """
        cache_key = f"{package_name}:{version}:{algorithm.value}"

        # 检查缓存
        if cache_key in self._verification_cache:
            logger.debug("从缓存获取验证结果: %s", cache_key)
            return self._verification_cache[cache_key]

        logger.info("验证包签名: %s==%s (算法: %s)", package_name, version, algorithm.value)

        try:
            if algorithm == SignatureAlgorithm.SHA256:
                result = self._verify_sha256(package_name, version)
            elif algorithm in (SignatureAlgorithm.PGP, SignatureAlgorithm.GPG):
                result = self._verify_gpg(package_name, version)
            elif algorithm == SignatureAlgorithm.ED25519:
                result = self._verify_pip_signature(package_name, version)
            elif algorithm == SignatureAlgorithm.SHA512:
                result = self._verify_sha512(package_name, version)
            else:
                result = SignatureVerificationResult(
                    package_name=package_name,
                    version=version,
                    is_valid=False,
                    algorithm=algorithm,
                    error_message=f"不支持的签名算法: {algorithm.value}",
                )
        except Exception as e:
            logger.error("验证包 %s==%s 时发生异常: %s", package_name, version, e)
            result = SignatureVerificationResult(
                package_name=package_name,
                version=version,
                is_valid=False,
                algorithm=algorithm,
                error_message=str(e),
            )

        # 缓存结果
        self._verification_cache[cache_key] = result

        # 签名不匹配时自动阻止
        if not result.is_valid and self.block_on_failure:
            self._blocked_packages.add(f"{package_name}=={version}")
            error_msg = (
                f"包 {package_name}=={version} 签名验证失败: {result.error_message}。"
                f"已阻止安装。"
            )
            logger.error(error_msg)
            raise RuntimeError(error_msg)

        return result

    def _verify_sha256(
        self, package_name: str, version: str
    ) -> SignatureVerificationResult:
        """通过SHA-256校验和验证包完整性 (Verify package integrity via SHA-256 checksum)

        从PyPI获取包的官方SHA-256哈希值，与本地下载的包进行比对。

        Args:
            package_name: 包名称
            version: 包版本号

        Returns:
            SignatureVerificationResult: 验证结果
        """
        try:
            # 通过pip下载包信息获取哈希
            cmd = [
                "pip", "download", "--no-deps", "--no-binary", ":all:",
                f"{package_name}=={version}",
                "-d", self.cache_dir,
            ]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=60,
            )

            if result.returncode != 0:
                return SignatureVerificationResult(
                    package_name=package_name,
                    version=version,
                    is_valid=False,
                    algorithm=SignatureAlgorithm.SHA256,
                    error_message=f"下载包失败: {result.stderr}",
                )

            # 查找下载的文件并计算哈希
            expected_hash: Optional[str] = None
            actual_hash: Optional[str] = None

            for filename in os.listdir(self.cache_dir):
                if filename.startswith(package_name.replace("-", "_")):
                    filepath = os.path.join(self.cache_dir, filename)
                    with open(filepath, "rb") as f:
                        actual_hash = hashlib.sha256(f.read()).hexdigest()
                    break

            # 从PyPI JSON API获取预期哈希
            try:
                import urllib.request
                url = f"https://pypi.org/pypi/{package_name}/{version}/json"
                req = urllib.request.Request(url, headers={"Accept": "application/json"})
                with urllib.request.urlopen(req, timeout=30) as resp:
                    data = json.loads(resp.read().decode())
                    releases = data.get("releases", {}).get(version, [])
                    for r in releases:
                        if r.get("packagetype") == "sdist":
                            expected_hash = r.get("digests", {}).get("sha256")
                            break
            except Exception as e:
                logger.warning("获取PyPI哈希失败，使用降级验证: %s", e)
                # 降级：仅验证本地哈希可计算
                if actual_hash:
                    return SignatureVerificationResult(
                        package_name=package_name,
                        version=version,
                        is_valid=True,
                        algorithm=SignatureAlgorithm.SHA256,
                        fingerprint=actual_hash,
                        error_message="降级验证：无法获取PyPI官方哈希进行比对",
                    )

            if expected_hash and actual_hash:
                is_valid = expected_hash == actual_hash
                return SignatureVerificationResult(
                    package_name=package_name,
                    version=version,
                    is_valid=is_valid,
                    algorithm=SignatureAlgorithm.SHA256,
                    fingerprint=actual_hash,
                    error_message=None if is_valid else f"哈希不匹配: 预期 {expected_hash[:16]}... 实际 {actual_hash[:16]}...",
                )

            return SignatureVerificationResult(
                package_name=package_name,
                version=version,
                is_valid=False,
                algorithm=SignatureAlgorithm.SHA256,
                error_message="无法获取哈希值进行验证",
            )

        except subprocess.TimeoutExpired:
            return SignatureVerificationResult(
                package_name=package_name,
                version=version,
                is_valid=False,
                algorithm=SignatureAlgorithm.SHA256,
                error_message="下载超时",
            )

    def _verify_sha512(
        self, package_name: str, version: str
    ) -> SignatureVerificationResult:
        """通过SHA-512校验和验证包完整性 (Verify package integrity via SHA-512 checksum)

        Args:
            package_name: 包名称
            version: 包版本号

        Returns:
            SignatureVerificationResult: 验证结果
        """
        try:
            # 从PyPI获取SHA-512哈希
            import urllib.request
            url = f"https://pypi.org/pypi/{package_name}/{version}/json"
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode())
                releases = data.get("releases", {}).get(version, [])
                expected_hash: Optional[str] = None
                for r in releases:
                    if r.get("packagetype") == "sdist":
                        expected_hash = r.get("digests", {}).get("sha512")
                        break

            if expected_hash:
                return SignatureVerificationResult(
                    package_name=package_name,
                    version=version,
                    is_valid=True,
                    algorithm=SignatureAlgorithm.SHA512,
                    fingerprint=expected_hash,
                )

            return SignatureVerificationResult(
                package_name=package_name,
                version=version,
                is_valid=False,
                algorithm=SignatureAlgorithm.SHA512,
                error_message="PyPI上未找到SHA-512哈希",
            )

        except Exception as e:
            return SignatureVerificationResult(
                package_name=package_name,
                version=version,
                is_valid=False,
                algorithm=SignatureAlgorithm.SHA512,
                error_message=f"SHA-512验证失败: {str(e)}",
            )

    def _verify_gpg(
        self, package_name: str, version: str
    ) -> SignatureVerificationResult:
        """通过GPG/PGP验证包签名 (Verify package signature via GPG/PGP)

        检查PyPI上是否有该包的PGP签名，并使用GPG工具验证。

        Args:
            package_name: 包名称
            version: 包版本号

        Returns:
            SignatureVerificationResult: 验证结果
        """
        gpg_cmd = ["gpg", "--version"]
        try:
            subprocess.run(gpg_cmd, capture_output=True, check=True, timeout=10)
        except (subprocess.CalledProcessError, FileNotFoundError):
            return SignatureVerificationResult(
                package_name=package_name,
                version=version,
                is_valid=False,
                algorithm=SignatureAlgorithm.GPG,
                error_message="GPG工具未安装或不可用",
            )

        # 构建GPG验证命令
        cmd = ["gpg", "--verify"]
        if self.gpg_keyring_path:
            cmd.extend(["--keyring", self.gpg_keyring_path])
        if self.trusted_keys:
            cmd.extend(["--trusted-key", ",".join(self.trusted_keys)])

        # 尝试从PyPI下载签名文件
        try:
            import urllib.request
            sig_url = f"https://files.pythonhosted.org/packages/source/{package_name[0]}/{package_name}/{package_name}-{version}.tar.gz.asc"
            req = urllib.request.Request(sig_url)
            with urllib.request.urlopen(req, timeout=30) as resp:
                sig_data = resp.read()

            # 保存签名文件
            sig_path = os.path.join(self.cache_dir, f"{package_name}-{version}.tar.gz.asc")
            with open(sig_path, "wb") as f:
                f.write(sig_data)

            # 下载对应的源码包
            src_url = f"https://files.pythonhosted.org/packages/source/{package_name[0]}/{package_name}/{package_name}-{version}.tar.gz"
            src_path = os.path.join(self.cache_dir, f"{package_name}-{version}.tar.gz")
            req2 = urllib.request.Request(src_url)
            with urllib.request.urlopen(req2, timeout=60) as resp2:
                with open(src_path, "wb") as f:
                    f.write(resp2.read())

            cmd.extend([sig_path, src_path])
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            if result.returncode == 0:
                # 提取签名指纹
                fingerprint = self._extract_gpg_fingerprint(result.stdout)
                return SignatureVerificationResult(
                    package_name=package_name,
                    version=version,
                    is_valid=True,
                    algorithm=SignatureAlgorithm.GPG,
                    fingerprint=fingerprint,
                )
            else:
                return SignatureVerificationResult(
                    package_name=package_name,
                    version=version,
                    is_valid=False,
                    algorithm=SignatureAlgorithm.GPG,
                    error_message=f"GPG验证失败: {result.stderr.strip()}",
                )

        except Exception as e:
            return SignatureVerificationResult(
                package_name=package_name,
                version=version,
                is_valid=False,
                algorithm=SignatureAlgorithm.GPG,
                error_message=f"GPG签名验证异常: {str(e)}",
            )

    def _verify_pip_signature(
        self, package_name: str, version: str
    ) -> SignatureVerificationResult:
        """通过pip验证包签名 (Verify package signature via pip)

        使用pip的内置签名验证机制。

        Args:
            package_name: 包名称
            version: 包版本号

        Returns:
            SignatureVerificationResult: 验证结果
        """
        try:
            cmd = [
                "pip", "download", "--no-deps",
                f"{package_name}=={version}",
                "-d", self.cache_dir,
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)

            if result.returncode == 0:
                return SignatureVerificationResult(
                    package_name=package_name,
                    version=version,
                    is_valid=True,
                    algorithm=SignatureAlgorithm.ED25519,
                    error_message="pip下载成功（签名由PyPI TLS保证）",
                )
            else:
                return SignatureVerificationResult(
                    package_name=package_name,
                    version=version,
                    is_valid=False,
                    algorithm=SignatureAlgorithm.ED25519,
                    error_message=f"pip下载失败: {result.stderr.strip()}",
                )

        except Exception as e:
            return SignatureVerificationResult(
                package_name=package_name,
                version=version,
                is_valid=False,
                algorithm=SignatureAlgorithm.ED25519,
                error_message=f"pip签名验证异常: {str(e)}",
            )

    def _extract_gpg_fingerprint(self, gpg_output: str) -> Optional[str]:
        """从GPG输出中提取签名指纹 (Extract signature fingerprint from GPG output)

        Args:
            gpg_output: GPG命令的标准输出

        Returns:
            Optional[str]: 签名指纹，如果未找到则返回None
        """
        # 匹配GPG指纹格式（40位十六进制）
        match = re.search(r"[A-F0-9]{40}", gpg_output)
        if match:
            return match.group(0)
        return None

    def verify_dependency_chain(
        self, requirements_file: str
    ) -> Dict[str, SignatureVerificationResult]:
        """验证整个依赖链的签名 (Verify signatures of the entire dependency chain)

        解析requirements.txt文件，递归验证所有直接和传递依赖的签名。

        Args:
            requirements_file: requirements.txt文件路径

        Returns:
            Dict[str, SignatureVerificationResult]: 各包的验证结果映射

        Raises:
            FileNotFoundError: 当requirements文件不存在时
            RuntimeError: 当任何包验证失败且block_on_failure为True时
        """
        if not os.path.exists(requirements_file):
            raise FileNotFoundError(f"Requirements文件不存在: {requirements_file}")

        logger.info("开始验证依赖链: %s", requirements_file)
        results: Dict[str, SignatureVerificationResult] = {}

        # 解析requirements文件
        packages = self._parse_requirements(requirements_file)

        # 获取完整的依赖树
        full_deps = self._resolve_dependency_tree(packages)

        # 逐个验证
        for pkg_name, pkg_version in full_deps:
            try:
                result = self.verify_package(pkg_name, pkg_version)
                results[f"{pkg_name}=={pkg_version}"] = result
            except RuntimeError:
                # 如果block_on_failure为True，verify_package会抛出异常
                # 这里记录后继续验证其他包
                results[f"{pkg_name}=={pkg_version}"] = SignatureVerificationResult(
                    package_name=pkg_name,
                    version=pkg_version,
                    is_valid=False,
                    algorithm=SignatureAlgorithm.SHA256,
                    error_message="已阻止安装",
                )

        # 统计验证结果
        valid_count = sum(1 for r in results.values() if r.is_valid)
        total_count = len(results)
        logger.info(
            "依赖链验证完成: %d/%d 通过, %d 被阻止",
            valid_count, total_count, len(self._blocked_packages),
        )

        return results

    def _parse_requirements(self, requirements_file: str) -> List[Tuple[str, str]]:
        """解析requirements.txt文件 (Parse requirements.txt file)

        Args:
            requirements_file: requirements.txt文件路径

        Returns:
            List[Tuple[str, str]]: (包名, 版本号)列表
        """
        packages: List[Tuple[str, str]] = []
        # 匹配包名和版本号的正则表达式
        pattern = re.compile(r"^([a-zA-Z0-9_-]+)\s*([>=<~!]+)\s*([\d.]+)")

        with open(requirements_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                # 跳过注释和空行
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                match = pattern.match(line)
                if match:
                    packages.append((match.group(1), match.group(3)))
                else:
                    # 没有版本约束的包
                    pkg_name = re.match(r"^([a-zA-Z0-9_-]+)", line)
                    if pkg_name:
                        packages.append((pkg_name.group(1), "latest"))

        logger.debug("解析到 %d 个依赖包", len(packages))
        return packages

    def _resolve_dependency_tree(
        self, packages: List[Tuple[str, str]]
    ) -> List[Tuple[str, str]]:
        """解析完整的依赖树 (Resolve full dependency tree)

        使用pip命令获取所有直接和传递依赖。

        Args:
            packages: 直接依赖列表

        Returns:
            List[Tuple[str, str]]: 所有依赖（包括传递依赖）列表
        """
        all_deps: List[Tuple[str, str]] = list(packages)

        try:
            # 使用pip list获取已安装的包信息
            result = subprocess.run(
                ["pip", "list", "--format=json"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                installed = json.loads(result.stdout)
                for pkg in installed:
                    name = pkg.get("name", "").lower().replace("-", "_")
                    version = pkg.get("version", "")
                    # 避免重复
                    if not any(d[0].lower().replace("-", "_") == name for d in all_deps):
                        all_deps.append((pkg.get("name", ""), version))
        except Exception as e:
            logger.warning("解析依赖树时出错，仅使用直接依赖: %s", e)

        return all_deps

    def get_blocked_packages(self) -> Set[str]:
        """获取被阻止的包列表 (Get list of blocked packages)

        Returns:
            Set[str]: 被阻止的包名称集合
        """
        return self._blocked_packages.copy()

    def clear_cache(self) -> None:
        """清除验证缓存 (Clear verification cache)"""
        self._verification_cache.clear()
        logger.info("验证缓存已清除")


# ============================================================
# 依赖库漏洞扫描器 (Dependency Vulnerability Scanner)
# ============================================================


class VulnerabilityScanner:
    """依赖库漏洞扫描器 (Dependency Vulnerability Scanner)

    提供对Python依赖库的漏洞扫描功能（SCA - 软件成分分析），包括：
    - CVE数据库查询接口：从NVD和PyPI Advisory数据库查询漏洞
    - 已知漏洞匹配：将已安装的依赖与已知漏洞进行匹配
    - 严重程度分级：按CRITICAL/HIGH/MEDIUM/LOW/INFO分级
    - 自动修复建议：提供升级版本建议
    - 定期扫描调度：支持定时自动扫描

    Provides Software Composition Analysis (SCA) for Python dependencies:
    - CVE database query interface (NVD, PyPI Advisory)
    - Known vulnerability matching
    - Severity classification (CRITICAL/HIGH/MEDIUM/LOW/INFO)
    - Automatic fix recommendations
    - Periodic scan scheduling
    """

    # CVE数据库查询端点
    NVD_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    PYPI_AUDVSIORY_URL = "https://pypi.org/pypi"

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        scan_timeout: int = 120,
        auto_fix: bool = False,
    ) -> None:
        """初始化漏洞扫描器 (Initialize vulnerability scanner)

        Args:
            cache_dir: 漏洞数据库缓存目录
            scan_timeout: 扫描超时时间（秒）
            auto_fix: 是否自动修复（仅提供建议，不自动执行）
        """
        self.cache_dir: str = cache_dir or os.path.join(
            tempfile.gettempdir(), "vuln_scan_cache"
        )
        self.scan_timeout: int = scan_timeout
        self.auto_fix: bool = auto_fix
        self._vuln_cache: Dict[str, List[VulnerabilityInfo]] = {}
        self._scan_history: List[Dict[str, Any]] = []
        self._scheduled_tasks: Dict[str, Dict[str, Any]] = {}

        # 创建缓存目录
        os.makedirs(self.cache_dir, exist_ok=True)

        # 加载本地漏洞缓存
        self._load_vuln_cache()

        logger.info("漏洞扫描器初始化完成: timeout=%ds, auto_fix=%s", scan_timeout, auto_fix)

    def scan_requirements(
        self, requirements_file: str
    ) -> List[VulnerabilityInfo]:
        """扫描requirements.txt中的依赖漏洞 (Scan dependencies in requirements.txt)

        Args:
            requirements_file: requirements.txt文件路径

        Returns:
            List[VulnerabilityInfo]: 发现的漏洞列表

        Raises:
            FileNotFoundError: 当requirements文件不存在时
        """
        if not os.path.exists(requirements_file):
            raise FileNotFoundError(f"Requirements文件不存在: {requirements_file}")

        logger.info("开始扫描依赖漏洞: %s", requirements_file)
        start_time = time.time()

        # 解析依赖
        packages = self._parse_requirements_file(requirements_file)

        # 扫描每个包
        all_vulns: List[VulnerabilityInfo] = []
        for pkg_name, pkg_version in packages:
            vulns = self._scan_package(pkg_name, pkg_version)
            all_vulns.extend(vulns)

        # 记录扫描历史
        scan_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "requirements_file": requirements_file,
            "packages_scanned": len(packages),
            "vulnerabilities_found": len(all_vulns),
            "scan_duration_seconds": time.time() - start_time,
        }
        self._scan_history.append(scan_record)

        # 按严重程度排序
        severity_order = {
            VulnerabilitySeverity.CRITICAL: 0,
            VulnerabilitySeverity.HIGH: 1,
            VulnerabilitySeverity.MEDIUM: 2,
            VulnerabilitySeverity.LOW: 3,
            VulnerabilitySeverity.INFO: 4,
        }
        all_vulns.sort(key=lambda v: severity_order.get(v.severity, 5))

        # 输出扫描摘要
        summary = self._generate_summary(all_vulns)
        logger.info("漏洞扫描完成:\n%s", summary)

        return all_vulns

    def scan_installed(self) -> List[VulnerabilityInfo]:
        """扫描已安装包的漏洞 (Scan vulnerabilities in installed packages)

        Returns:
            List[VulnerabilityInfo]: 发现的漏洞列表
        """
        logger.info("开始扫描已安装包的漏洞")
        start_time = time.time()

        try:
            result = subprocess.run(
                ["pip", "list", "--format=json"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode != 0:
                logger.error("获取已安装包列表失败: %s", result.stderr)
                return []

            installed = json.loads(result.stdout)
            all_vulns: List[VulnerabilityInfo] = []

            for pkg in installed:
                name = pkg.get("name", "")
                version = pkg.get("version", "")
                vulns = self._scan_package(name, version)
                all_vulns.extend(vulns)

            scan_record = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "scan_type": "installed_packages",
                "packages_scanned": len(installed),
                "vulnerabilities_found": len(all_vulns),
                "scan_duration_seconds": time.time() - start_time,
            }
            self._scan_history.append(scan_record)

            logger.info(
                "已安装包扫描完成: %d 个包, %d 个漏洞",
                len(installed), len(all_vulns),
            )
            return all_vulns

        except Exception as e:
            logger.error("扫描已安装包时发生异常: %s", e)
            return []

    def _scan_package(
        self, package_name: str, version: str
    ) -> List[VulnerabilityInfo]:
        """扫描单个包的漏洞 (Scan vulnerabilities of a single package)

        Args:
            package_name: 包名称
            version: 包版本号

        Returns:
            List[VulnerabilityInfo]: 该包的漏洞列表
        """
        cache_key = f"{package_name}:{version}"

        # 检查缓存
        if cache_key in self._vuln_cache:
            return self._vuln_cache[cache_key]

        vulns: List[VulnerabilityInfo] = []

        # 方法1：查询PyPI Advisory数据库
        try:
            pypi_vulns = self._query_pypi_advisory(package_name, version)
            vulns.extend(pypi_vulns)
        except Exception as e:
            logger.warning("查询PyPI Advisory失败 (%s): %s", package_name, e)

        # 方法2：查询NVD数据库
        try:
            nvd_vulns = self._query_nvd(package_name, version)
            vulns.extend(nvd_vulns)
        except Exception as e:
            logger.warning("查询NVD失败 (%s): %s", package_name, e)

        # 方法3：使用pip-audit（如果可用）
        try:
            pip_audit_vulns = self._run_pip_audit(package_name, version)
            vulns.extend(pip_audit_vulns)
        except Exception as e:
            logger.debug("pip-audit不可用或执行失败: %s", e)

        # 去重
        seen_cves: Set[str] = set()
        unique_vulns: List[VulnerabilityInfo] = []
        for v in vulns:
            if v.cve_id not in seen_cves:
                seen_cves.add(v.cve_id)
                unique_vulns.append(v)

        # 缓存结果
        self._vuln_cache[cache_key] = unique_vulns

        if unique_vulns:
            logger.warning(
                "包 %s==%s 发现 %d 个漏洞", package_name, version, len(unique_vulns),
            )

        return unique_vulns

    def _query_pypi_advisory(
        self, package_name: str, version: str
    ) -> List[VulnerabilityInfo]:
        """查询PyPI Advisory数据库 (Query PyPI Advisory database)

        Args:
            package_name: 包名称
            version: 包版本号

        Returns:
            List[VulnerabilityInfo]: 漏洞列表
        """
        vulns: List[VulnerabilityInfo] = []

        try:
            import urllib.request
            url = f"{self.PYPI_AUDVSIORY_URL}/{package_name}/{version}/json"
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=self.scan_timeout) as resp:
                data = json.loads(resp.read().decode())

            # 检查vulnerabilities字段
            vuln_data = data.get("vulnerabilities", [])
            for v in vuln_data:
                severity = self._parse_severity(v.get("severity", "unknown"))
                vulns.append(VulnerabilityInfo(
                    cve_id=v.get("id", "UNKNOWN"),
                    package_name=package_name,
                    affected_versions=version,
                    severity=severity,
                    description=v.get("summary", "无描述"),
                    fix_version=v.get("fixed_in"),
                    references=v.get("aliases", []),
                    published_date=None,
                ))

        except Exception as e:
            logger.debug("PyPI Advisory查询异常: %s", e)

        return vulns

    def _query_nvd(
        self, package_name: str, version: str
    ) -> List[VulnerabilityInfo]:
        """查询NVD数据库 (Query NVD database)

        Args:
            package_name: 包名称
            version: 包版本号

        Returns:
            List[VulnerabilityInfo]: 漏洞列表
        """
        vulns: List[VulnerabilityInfo] = []

        try:
            import urllib.request
            import urllib.parse
            query = urllib.parse.quote(f"{package_name} {version}")
            url = f"{self.NVD_API_URL}?keywordSearch={query}"
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=self.scan_timeout) as resp:
                data = json.loads(resp.read().decode())

            for vuln in data.get("vulnerabilities", []):
                cve = vuln.get("cve", {})
                cve_id = cve.get("id", "UNKNOWN")
                descriptions = cve.get("descriptions", [])
                desc_text = ""
                for d in descriptions:
                    if d.get("lang") == "en":
                        desc_text = d.get("value", "")
                        break

                # 获取CVSS评分
                metrics = cve.get("metrics", {})
                cvss = metrics.get("cvssMetricV31", [{}])
                severity = VulnerabilitySeverity.INFO
                if cvss:
                    score = cvss[0].get("cvssData", {}).get("baseScore", 0)
                    severity = self._score_to_severity(score)

                vulns.append(VulnerabilityInfo(
                    cve_id=cve_id,
                    package_name=package_name,
                    affected_versions=version,
                    severity=severity,
                    description=desc_text,
                    fix_version=None,
                    references=[r.get("url", "") for r in cve.get("references", [])],
                ))

        except Exception as e:
            logger.debug("NVD查询异常: %s", e)

        return vulns

    def _run_pip_audit(
        self, package_name: str, version: str
    ) -> List[VulnerabilityInfo]:
        """运行pip-audit工具 (Run pip-audit tool)

        Args:
            package_name: 包名称
            version: 包版本号

        Returns:
            List[VulnerabilityInfo]: 漏洞列表
        """
        vulns: List[VulnerabilityInfo] = []

        try:
            result = subprocess.run(
                ["pip-audit", "--format", "json"],
                capture_output=True, text=True, timeout=self.scan_timeout,
            )
            if result.returncode == 0:
                audit_data = json.loads(result.stdout)
                for dep in audit_data.get("dependencies", []):
                    if dep.get("name", "").lower() == package_name.lower():
                        for vuln in dep.get("vulns", []):
                            severity = self._parse_severity(
                                vuln.get("fix_versions", [""])[0]
                            )
                            vulns.append(VulnerabilityInfo(
                                cve_id=vuln.get("id", "UNKNOWN"),
                                package_name=package_name,
                                affected_versions=version,
                                severity=severity,
                                description=vuln.get("description", ""),
                                fix_version=vuln.get("fix_versions", [None])[0],
                            ))
        except (subprocess.CalledProcessError, FileNotFoundError, json.JSONDecodeError):
            pass

        return vulns

    def _parse_requirements_file(
        self, requirements_file: str
    ) -> List[Tuple[str, str]]:
        """解析requirements文件 (Parse requirements file)

        Args:
            requirements_file: 文件路径

        Returns:
            List[Tuple[str, str]]: (包名, 版本号)列表
        """
        packages: List[Tuple[str, str]] = []
        pattern = re.compile(r"^([a-zA-Z0-9_-]+)\s*([>=<~!]+)\s*([\d.]+)")

        with open(requirements_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                match = pattern.match(line)
                if match:
                    packages.append((match.group(1), match.group(3)))
                else:
                    pkg_name = re.match(r"^([a-zA-Z0-9_-]+)", line)
                    if pkg_name:
                        packages.append((pkg_name.group(1), "latest"))

        return packages

    def _parse_severity(self, severity_str: str) -> VulnerabilitySeverity:
        """解析严重程度字符串 (Parse severity string)

        Args:
            severity_str: 严重程度字符串

        Returns:
            VulnerabilitySeverity: 对应的枚举值
        """
        severity_map = {
            "critical": VulnerabilitySeverity.CRITICAL,
            "high": VulnerabilitySeverity.HIGH,
            "medium": VulnerabilitySeverity.MEDIUM,
            "low": VulnerabilitySeverity.LOW,
            "info": VulnerabilitySeverity.INFO,
            "unknown": VulnerabilitySeverity.INFO,
        }
        return severity_map.get(severity_str.lower().strip(), VulnerabilitySeverity.INFO)

    def _score_to_severity(self, score: float) -> VulnerabilitySeverity:
        """将CVSS评分转换为严重程度 (Convert CVSS score to severity)

        Args:
            score: CVSS评分 (0.0 - 10.0)

        Returns:
            VulnerabilitySeverity: 对应的严重程度
        """
        if score >= 9.0:
            return VulnerabilitySeverity.CRITICAL
        elif score >= 7.0:
            return VulnerabilitySeverity.HIGH
        elif score >= 4.0:
            return VulnerabilitySeverity.MEDIUM
        elif score > 0.0:
            return VulnerabilitySeverity.LOW
        return VulnerabilitySeverity.INFO

    def _generate_summary(self, vulns: List[VulnerabilityInfo]) -> str:
        """生成漏洞扫描摘要 (Generate vulnerability scan summary)

        Args:
            vulns: 漏洞列表

        Returns:
            str: 格式化的摘要文本
        """
        if not vulns:
            return "  未发现已知漏洞。"

        counts: Dict[VulnerabilitySeverity, int] = {}
        for v in vulns:
            counts[v.severity] = counts.get(v.severity, 0) + 1

        lines = [f"  发现 {len(vulns)} 个漏洞:"]
        for severity in VulnerabilitySeverity:
            count = counts.get(severity, 0)
            if count > 0:
                lines.append(f"    {severity.value.upper()}: {count}")

        # 自动修复建议
        fixable = [v for v in vulns if v.fix_version]
        if fixable:
            lines.append(f"\n  可自动修复: {len(fixable)} 个")
            for v in fixable[:5]:  # 最多显示5个
                lines.append(
                    f"    {v.cve_id} ({v.package_name}): 升级到 {v.fix_version}"
                )

        return "\n".join(lines)

    def get_fix_suggestions(
        self, vulns: List[VulnerabilityInfo]
    ) -> List[Dict[str, str]]:
        """获取自动修复建议 (Get automatic fix suggestions)

        Args:
            vulns: 漏洞列表

        Returns:
            List[Dict[str, str]]: 修复建议列表，每项包含package, current_version, fix_version, cve_id
        """
        suggestions: List[Dict[str, str]] = []
        seen: Set[str] = set()

        for v in vulns:
            if v.fix_version and v.cve_id not in seen:
                seen.add(v.cve_id)
                suggestions.append({
                    "package": v.package_name,
                    "current_version": v.affected_versions,
                    "fix_version": v.fix_version,
                    "cve_id": v.cve_id,
                    "severity": v.severity.value,
                    "command": f"pip install {v.package_name}=={v.fix_version}",
                })

        # 按严重程度排序
        severity_order = {
            VulnerabilitySeverity.CRITICAL.value: 0,
            VulnerabilitySeverity.HIGH.value: 1,
            VulnerabilitySeverity.MEDIUM.value: 2,
            VulnerabilitySeverity.LOW.value: 3,
            VulnerabilitySeverity.INFO.value: 4,
        }
        suggestions.sort(key=lambda s: severity_order.get(s["severity"], 5))

        return suggestions

    def schedule_scan(
        self,
        scan_id: str,
        target: str,
        interval_hours: int = 24,
    ) -> bool:
        """调度定期扫描 (Schedule periodic scan)

        Args:
            scan_id: 扫描任务ID
            target: 扫描目标（requirements文件路径或"installed"）
            interval_hours: 扫描间隔（小时）

        Returns:
            bool: 是否成功调度
        """
        if interval_hours < 1:
            logger.error("扫描间隔不能小于1小时")
            return False

        self._scheduled_tasks[scan_id] = {
            "target": target,
            "interval_hours": interval_hours,
            "last_scan": None,
            "next_scan": datetime.now(timezone.utc).isoformat(),
            "enabled": True,
        }

        logger.info(
            "已调度定期扫描: id=%s, target=%s, interval=%dh",
            scan_id, target, interval_hours,
        )
        return True

    def _load_vuln_cache(self) -> None:
        """从本地缓存加载漏洞数据 (Load vulnerability data from local cache)"""
        cache_file = os.path.join(self.cache_dir, "vuln_cache.json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                # 将缓存数据转换为VulnerabilityInfo对象
                for key, vulns in data.items():
                    self._vuln_cache[key] = [
                        VulnerabilityInfo(
                            cve_id=v["cve_id"],
                            package_name=v["package_name"],
                            affected_versions=v["affected_versions"],
                            severity=VulnerabilitySeverity(v["severity"]),
                            description=v["description"],
                            fix_version=v.get("fix_version"),
                            references=v.get("references", []),
                        )
                        for v in vulns
                    ]
                logger.debug("从缓存加载了 %d 个包的漏洞数据", len(self._vuln_cache))
            except Exception as e:
                logger.warning("加载漏洞缓存失败: %s", e)

    def save_vuln_cache(self) -> None:
        """保存漏洞缓存到本地 (Save vulnerability cache to local storage)"""
        cache_file = os.path.join(self.cache_dir, "vuln_cache.json")
        try:
            data = {}
            for key, vulns in self._vuln_cache.items():
                data[key] = [v.to_dict() for v in vulns]
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            logger.debug("漏洞缓存已保存: %s", cache_file)
        except Exception as e:
            logger.error("保存漏洞缓存失败: %s", e)

    def get_scan_history(self) -> List[Dict[str, Any]]:
        """获取扫描历史记录 (Get scan history)

        Returns:
            List[Dict[str, Any]]: 扫描历史记录列表
        """
        return self._scan_history.copy()


# ============================================================
# 最小化依赖管理器 (Minimal Dependency Manager)
# ============================================================


class MinimalDependencyManager:
    """最小化依赖管理器 (Minimal Dependency Manager)

    提供依赖管理和优化功能，包括：
    - 依赖树分析：解析并可视化完整的依赖关系树
    - 未使用依赖检测：通过静态代码分析检测未被引用的依赖
    - 替代方案建议：为大型依赖库推荐更轻量的替代方案
    - 依赖大小统计：统计各依赖的磁盘占用
    - 许可证合规检查：检查依赖的许可证兼容性

    Provides dependency management and optimization:
    - Dependency tree analysis and visualization
    - Unused dependency detection via static code analysis
    - Alternative package suggestions for heavy dependencies
    - Dependency size statistics
    - License compliance checking
    """

    # 已知的轻量级替代方案映射
    ALTERNATIVES: Dict[str, List[Dict[str, str]]] = {
        "requests": [
            {"name": "httpx", "reason": "支持async，更现代的API", "size_ratio": "1.2x"},
            {"name": "urllib3", "reason": "更底层的HTTP库，体积更小", "size_ratio": "0.3x"},
        ],
        "pandas": [
            {"name": "polars", "reason": "更快的性能，更小的内存占用", "size_ratio": "0.5x"},
        ],
        "numpy": [
            {"name": "numpy", "reason": "无可替代（核心数值计算库）", "size_ratio": "1.0x"},
        ],
        "django": [
            {"name": "fastapi", "reason": "更轻量的Web框架", "size_ratio": "0.3x"},
            {"name": "flask", "reason": "极简Web框架", "size_ratio": "0.1x"},
        ],
    }

    # 许可证兼容性矩阵（True表示与项目兼容）
    COMPATIBLE_LICENSES: Set[str] = {
        LicenseType.MIT.value,
        LicenseType.APACHE_2.value,
        LicenseType.BSD_2.value,
        LicenseType.BSD_3.value,
        LicenseType.ISC.value,
        LicenseType.UNLICENSE.value,
    }

    def __init__(
        self,
        project_root: Optional[str] = None,
        strict_mode: bool = False,
    ) -> None:
        """初始化最小化依赖管理器 (Initialize minimal dependency manager)

        Args:
            project_root: 项目根目录路径
            strict_mode: 严格模式，发现不兼容许可证时抛出异常
        """
        self.project_root: str = project_root or os.getcwd()
        self.strict_mode: bool = strict_mode
        self._dependency_tree: Dict[str, DependencyInfo] = {}
        self._import_cache: Set[str] = set()

        logger.info(
            "最小化依赖管理器初始化完成: project_root=%s, strict_mode=%s",
            self.project_root, self.strict_mode,
        )

    def analyze_dependency_tree(
        self, requirements_file: Optional[str] = None
    ) -> Dict[str, DependencyInfo]:
        """分析依赖树 (Analyze dependency tree)

        解析requirements文件并获取完整的依赖关系树，包括传递依赖。

        Args:
            requirements_file: requirements.txt文件路径，默认查找项目根目录

        Returns:
            Dict[str, DependencyInfo]: 依赖信息映射（键为"包名==版本"）
        """
        if requirements_file is None:
            requirements_file = os.path.join(self.project_root, "requirements.txt")

        if not os.path.exists(requirements_file):
            logger.warning("Requirements文件不存在: %s", requirements_file)
            return {}

        logger.info("分析依赖树: %s", requirements_file)

        # 解析直接依赖
        direct_deps = self._parse_requirements(requirements_file)

        # 获取已安装包的完整信息
        installed_packages = self._get_installed_packages()

        # 构建依赖树
        self._dependency_tree.clear()
        for pkg_name, pkg_version in direct_deps:
            key = f"{pkg_name}=={pkg_version}"
            pkg_info = installed_packages.get(pkg_name.lower())
            self._dependency_tree[key] = DependencyInfo(
                name=pkg_name,
                version=pkg_version,
                is_direct=True,
                license_type=pkg_info.get("license", LicenseType.UNKNOWN) if pkg_info else LicenseType.UNKNOWN,
                size_bytes=pkg_info.get("size", 0) if pkg_info else 0,
                transitive_count=pkg_info.get("dependencies", 0) if pkg_info else 0,
            )

        # 添加传递依赖
        for pkg_name, info in installed_packages.items():
            key = f"{info['name']}=={info['version']}"
            if key not in self._dependency_tree:
                self._dependency_tree[key] = DependencyInfo(
                    name=info["name"],
                    version=info["version"],
                    is_direct=False,
                    license_type=info.get("license", LicenseType.UNKNOWN),
                    size_bytes=info.get("size", 0),
                    transitive_count=info.get("dependencies", 0),
                )

        logger.info(
            "依赖树分析完成: %d 个直接依赖, %d 个总依赖",
            len(direct_deps), len(self._dependency_tree),
        )
        return self._dependency_tree

    def detect_unused_dependencies(
        self,
        source_dir: Optional[str] = None,
        requirements_file: Optional[str] = None,
    ) -> List[DependencyInfo]:
        """检测未使用的依赖 (Detect unused dependencies)

        通过静态代码分析，扫描源代码中的import语句，
        与requirements.txt中声明的依赖进行比对，找出未被使用的依赖。

        Args:
            source_dir: 源代码目录，默认为项目根目录下的src/
            requirements_file: requirements.txt文件路径

        Returns:
            List[DependencyInfo]: 未使用的依赖列表
        """
        if source_dir is None:
            source_dir = os.path.join(self.project_root, "src")
        if requirements_file is None:
            requirements_file = os.path.join(self.project_root, "requirements.txt")

        logger.info("检测未使用依赖: source=%s, requirements=%s", source_dir, requirements_file)

        # 扫描源代码中的所有import
        self._import_cache = self._scan_imports(source_dir)

        # 解析依赖
        deps = self._parse_requirements(requirements_file)

        # 将包名映射到可能的import名
        unused: List[DependencyInfo] = []
        for pkg_name, pkg_version in deps:
            import_names = self._package_to_import_names(pkg_name)
            is_used = any(name in self._import_cache for name in import_names)

            if not is_used:
                unused.append(DependencyInfo(
                    name=pkg_name,
                    version=pkg_version,
                    is_direct=True,
                    is_used=False,
                ))
                logger.debug("未使用的依赖: %s==%s", pkg_name, pkg_version)

        logger.info("检测到 %d 个未使用的依赖", len(unused))
        return unused

    def suggest_alternatives(
        self, package_name: str
    ) -> List[Dict[str, str]]:
        """建议依赖替代方案 (Suggest dependency alternatives)

        为指定的包推荐更轻量或更安全的替代方案。

        Args:
            package_name: 包名称

        Returns:
            List[Dict[str, str]]: 替代方案列表
        """
        alternatives = self.ALTERNATIVES.get(package_name.lower(), [])
        if alternatives:
            logger.info("为 %s 找到 %d 个替代方案", package_name, len(alternatives))
        else:
            logger.debug("未找到 %s 的替代方案", package_name)
        return alternatives

    def get_dependency_sizes(
        self, requirements_file: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """获取依赖大小统计 (Get dependency size statistics)

        统计各依赖包的磁盘占用大小。

        Args:
            requirements_file: requirements.txt文件路径

        Returns:
            List[Dict[str, Any]]: 按大小降序排列的依赖信息列表
        """
        if requirements_file is None:
            requirements_file = os.path.join(self.project_root, "requirements.txt")

        logger.info("统计依赖大小: %s", requirements_file)

        deps = self._parse_requirements(requirements_file)
        size_info: List[Dict[str, Any]] = []

        for pkg_name, pkg_version in deps:
            size = self._get_package_size(pkg_name)
            size_info.append({
                "name": pkg_name,
                "version": pkg_version,
                "size_bytes": size,
                "size_human": self._format_size(size),
            })

        # 按大小降序排列
        size_info.sort(key=lambda x: x["size_bytes"], reverse=True)

        total_size = sum(s["size_bytes"] for s in size_info)
        logger.info(
            "依赖大小统计完成: 总大小 %s, %d 个包",
            self._format_size(total_size), len(size_info),
        )
        return size_info

    def check_license_compliance(
        self, requirements_file: Optional[str] = None,
    ) -> Dict[str, Any]:
        """检查许可证合规性 (Check license compliance)

        检查所有依赖的许可证是否与项目兼容。

        Args:
            requirements_file: requirements.txt文件路径

        Returns:
            Dict[str, Any]: 合规性检查结果，包含compatible和incompatible列表
        """
        if requirements_file is None:
            requirements_file = os.path.join(self.project_root, "requirements.txt")

        logger.info("检查许可证合规性: %s", requirements_file)

        # 分析依赖树以获取许可证信息
        dep_tree = self.analyze_dependency_tree(requirements_file)

        compatible: List[Dict[str, str]] = []
        incompatible: List[Dict[str, str]] = []
        unknown: List[Dict[str, str]] = []

        for key, dep in dep_tree.items():
            license_info = {
                "package": f"{dep.name}=={dep.version}",
                "license": dep.license_type.value,
            }

            if dep.license_type == LicenseType.UNKNOWN:
                unknown.append(license_info)
            elif dep.license_type.value in self.COMPATIBLE_LICENSES:
                compatible.append(license_info)
            else:
                incompatible.append(license_info)

        result = {
            "total_packages": len(dep_tree),
            "compatible": compatible,
            "incompatible": incompatible,
            "unknown": unknown,
            "is_compliant": len(incompatible) == 0,
        }

        if incompatible and self.strict_mode:
            raise RuntimeError(
                f"发现 {len(incompatible)} 个许可证不兼容的依赖: "
                f"{[p['package'] for p in incompatible]}"
            )

        logger.info(
            "许可证检查完成: %d 兼容, %d 不兼容, %d 未知",
            len(compatible), len(incompatible), len(unknown),
        )
        return result

    def _parse_requirements(
        self, requirements_file: str
    ) -> List[Tuple[str, str]]:
        """解析requirements文件 (Parse requirements file)

        Args:
            requirements_file: 文件路径

        Returns:
            List[Tuple[str, str]]: (包名, 版本号)列表
        """
        packages: List[Tuple[str, str]] = []
        pattern = re.compile(r"^([a-zA-Z0-9_-]+)\s*([>=<~!]+)\s*([\d.]+)")

        with open(requirements_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                match = pattern.match(line)
                if match:
                    packages.append((match.group(1), match.group(3)))
                else:
                    pkg_name = re.match(r"^([a-zA-Z0-9_-]+)", line)
                    if pkg_name:
                        packages.append((pkg_name.group(1), "latest"))

        return packages

    def _scan_imports(self, source_dir: str) -> Set[str]:
        """扫描源代码中的所有import语句 (Scan all import statements in source code)

        递归扫描目录中的所有.py文件，提取import的模块名。

        Args:
            source_dir: 源代码目录

        Returns:
            Set[str]: 所有被import的模块名集合
        """
        imports: Set[str] = set()

        if not os.path.exists(source_dir):
            logger.warning("源代码目录不存在: %s", source_dir)
            return imports

        # import语句匹配模式
        import_patterns = [
            re.compile(r"^import\s+([\w.]+)"),           # import xxx
            re.compile(r"^from\s+([\w.]+)\s+import"),     # from xxx import
        ]

        for root, _dirs, files in os.walk(source_dir):
            for filename in files:
                if not filename.endswith(".py"):
                    continue
                filepath = os.path.join(root, filename)
                try:
                    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            line = line.strip()
                            for pattern in import_patterns:
                                match = pattern.match(line)
                                if match:
                                    # 提取顶层模块名
                                    module = match.group(1).split(".")[0]
                                    imports.add(module)
                except Exception as e:
                    logger.debug("读取文件失败 %s: %s", filepath, e)

        logger.debug("扫描到 %d 个import模块", len(imports))
        return imports

    def _package_to_import_names(self, package_name: str) -> List[str]:
        """将包名转换为可能的import名 (Convert package name to possible import names)

        例如: "beautifulsoup4" -> ["bs4", "beautifulsoup4"]
              "Pillow" -> ["PIL", "pillow"]

        Args:
            package_name: 包名称

        Returns:
            List[str]: 可能的import名称列表
        """
        # 常见的包名到import名映射
        common_mappings: Dict[str, List[str]] = {
            "beautifulsoup4": ["bs4", "beautifulsoup4"],
            "pillow": ["PIL", "pillow"],
            "pyyaml": ["yaml", "pyyaml"],
            "python-dateutil": ["dateutil", "python_dateutil"],
            "opencv-python": ["cv2", "opencv"],
            "scikit-learn": ["sklearn", "scikit_learn"],
            "pytest-cov": ["pytest_cov"],
        }

        name_lower = package_name.lower().replace("-", "_")
        if name_lower in common_mappings:
            return common_mappings[name_lower]

        # 通用转换规则
        names = [name_lower, package_name]
        # 尝试去掉版本后缀
        base_name = re.sub(r"[\d.]+$", "", name_lower)
        if base_name != name_lower:
            names.append(base_name)

        return names

    def _get_installed_packages(self) -> Dict[str, Dict[str, Any]]:
        """获取已安装包的详细信息 (Get detailed info of installed packages)

        Returns:
            Dict[str, Dict[str, Any]]: 包信息映射
        """
        packages: Dict[str, Dict[str, Any]] = {}

        try:
            result = subprocess.run(
                ["pip", "list", "--format=json"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                for pkg in json.loads(result.stdout):
                    name = pkg.get("name", "")
                    packages[name.lower()] = {
                        "name": name,
                        "version": pkg.get("version", ""),
                        "license": LicenseType.UNKNOWN,
                        "size": 0,
                        "dependencies": 0,
                    }
        except Exception as e:
            logger.warning("获取已安装包信息失败: %s", e)

        # 获取包大小信息
        try:
            result = subprocess.run(
                ["pip", "show", "-f"],
                capture_output=True, text=True, timeout=30,
            )
            # pip show -f 需要指定包名，这里使用另一种方式
            site_packages = self._find_site_packages()
            if site_packages:
                for pkg_name in packages:
                    pkg_dir = os.path.join(
                        site_packages,
                        pkg_name.replace("-", "_").lower(),
                    )
                    if os.path.isdir(pkg_dir):
                        total_size = sum(
                            os.path.getsize(os.path.join(dirpath, filename))
                            for dirpath, _, filenames in os.walk(pkg_dir)
                            for filename in filenames
                            if os.path.isfile(os.path.join(dirpath, filename))
                        )
                        packages[pkg_name]["size"] = total_size
        except Exception as e:
            logger.debug("获取包大小失败: %s", e)

        return packages

    def _find_site_packages(self) -> Optional[str]:
        """查找site-packages目录 (Find site-packages directory)

        Returns:
            Optional[str]: site-packages目录路径
        """
        try:
            import site
            paths = site.getsitepackages()
            return paths[0] if paths else None
        except Exception:
            return None

    def _get_package_size(self, package_name: str) -> int:
        """获取包的磁盘大小 (Get disk size of a package)

        Args:
            package_name: 包名称

        Returns:
            int: 包大小（字节）
        """
        site_packages = self._find_site_packages()
        if not site_packages:
            return 0

        pkg_dir = os.path.join(
            site_packages,
            package_name.replace("-", "_").lower(),
        )
        if not os.path.isdir(pkg_dir):
            # 尝试其他命名方式
            pkg_dir = os.path.join(
                site_packages,
                package_name.lower().replace("-", "_"),
            )

        if os.path.isdir(pkg_dir):
            total_size = 0
            for dirpath, _, filenames in os.walk(pkg_dir):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    if os.path.isfile(filepath):
                        total_size += os.path.getsize(filepath)
            return total_size

        return 0

    @staticmethod
    def _format_size(size_bytes: int) -> str:
        """格式化文件大小 (Format file size)

        Args:
            size_bytes: 字节数

        Returns:
            str: 人类可读的大小字符串
        """
        for unit in ["B", "KB", "MB", "GB"]:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} TB"


# ============================================================
# 构建过程签名器 (Build Process Signer)
# ============================================================


class BuildSigner:
    """构建过程签名器 (Build Process Signer)

    提供构建过程的完整性保证，包括：
    - 构建环境指纹：记录构建环境的完整配置信息
    - 源代码哈希链：对源代码文件建立Merkle哈希树
    - 构建产物签名：对构建产物进行数字签名
    - 签名验证：验证构建产物的完整性和来源
    - 可重现构建支持：确保相同源码产生相同产物

    Provides build process integrity guarantees:
    - Build environment fingerprinting
    - Source code hash chain (Merkle tree)
    - Build artifact signing
    - Signature verification
    - Reproducible build support
    """

    def __init__(
        self,
        signing_key_path: Optional[str] = None,
        output_dir: Optional[str] = None,
        hash_algorithm: str = "sha256",
    ) -> None:
        """初始化构建签名器 (Initialize build signer)

        Args:
            signing_key_path: 签名密钥路径（ED25519私钥PEM文件）
            output_dir: 签名产物输出目录
            hash_algorithm: 哈希算法（sha256或sha512）
        """
        self.signing_key_path: Optional[str] = signing_key_path
        self.output_dir: str = output_dir or os.path.join(
            tempfile.gettempdir(), "build_signatures"
        )
        self.hash_algorithm: str = hash_algorithm
        self._signing_key: Optional[Any] = None
        self._environment_fingerprint: Optional[str] = None

        # 创建输出目录
        os.makedirs(self.output_dir, exist_ok=True)

        # 加载签名密钥
        if signing_key_path and os.path.exists(signing_key_path):
            self._load_signing_key()

        logger.info(
            "构建签名器初始化完成: hash_algo=%s, output=%s",
            hash_algorithm, self.output_dir,
        )

    def _load_signing_key(self) -> None:
        """加载签名密钥 (Load signing key)

        从PEM文件加载ED25519私钥。
        """
        try:
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric import ed25519

            with open(self.signing_key_path, "rb") as f:  # type: ignore[arg-type]
                self._signing_key = serialization.load_pem_private_key(
                    f.read(), password=None,
                )

            if not isinstance(self._signing_key, ed25519.Ed25519PrivateKey):
                logger.warning("签名密钥不是ED25519类型，将使用HMAC替代")
                self._signing_key = None

            logger.info("签名密钥加载成功")
        except ImportError:
            logger.warning("cryptography库未安装，将使用HMAC进行签名")
            self._signing_key = None
        except Exception as e:
            logger.error("加载签名密钥失败: %s", e)
            self._signing_key = None

    def generate_environment_fingerprint(self) -> str:
        """生成构建环境指纹 (Generate build environment fingerprint)

        收集构建环境的所有关键信息，生成唯一指纹，包括：
        - 操作系统版本
        - Python版本
        - 编译器版本
        - 依赖库版本
        - 环境变量（排除敏感信息）

        Returns:
            str: 环境指纹（SHA-256哈希值）
        """
        import platform
        import sys

        env_info: Dict[str, str] = {
            "os": platform.system(),
            "os_version": platform.version(),
            "os_release": platform.release(),
            "architecture": platform.machine(),
            "python_version": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "python_compiler": platform.python_compiler(),
        }

        # 收集关键环境变量
        env_vars = [
            "PATH", "LANG", "LC_ALL", "CC", "CXX", "CFLAGS", "LDFLAGS",
            "VIRTUAL_ENV", "CONDA_PREFIX", "HOME",
        ]
        for var in env_vars:
            value = os.environ.get(var, "")
            if value:
                env_info[f"env_{var}"] = value

        # 收集关键依赖版本
        key_packages = ["setuptools", "wheel", "pip", "Cython", "numpy"]
        for pkg in key_packages:
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "show", pkg],
                    capture_output=True, text=True, timeout=10,
                )
                if result.returncode == 0:
                    for line in result.stdout.split("\n"):
                        if line.startswith("Version:"):
                            env_info[f"pkg_{pkg}"] = line.split(":", 1)[1].strip()
                            break
            except Exception:
                pass

        # 生成指纹
        fingerprint_data = json.dumps(env_info, sort_keys=True, separators=(",", ":"))
        fingerprint = hashlib.sha256(fingerprint_data.encode()).hexdigest()

        self._environment_fingerprint = fingerprint
        logger.info("构建环境指纹: %s", fingerprint[:16] + "...")

        return fingerprint

    def compute_source_hash_chain(
        self, source_dir: str, exclude_patterns: Optional[List[str]] = None,
    ) -> List[str]:
        """计算源代码哈希链 (Compute source code hash chain)

        对源代码目录中的所有文件计算哈希值，构建Merkle哈希树。
        每个文件的哈希值按路径排序后，逐层合并生成根哈希。

        Args:
            source_dir: 源代码目录路径
            exclude_patterns: 排除的文件模式列表（glob格式）

        Returns:
            List[str]: 哈希链列表，最后一个元素为根哈希

        Raises:
            FileNotFoundError: 当源代码目录不存在时
        """
        if not os.path.exists(source_dir):
            raise FileNotFoundError(f"源代码目录不存在: {source_dir}")

        exclude_patterns = exclude_patterns or [
            "*.pyc", "__pycache__", ".git", "*.egg-info",
            ".tox", ".mypy_cache", ".pytest_cache", "node_modules",
        ]

        logger.info("计算源代码哈希链: %s", source_dir)

        # 收集所有文件并计算哈希
        file_hashes: List[Tuple[str, str]] = []
        for root, dirs, files in os.walk(source_dir):
            # 排除目录
            dirs[:] = [
                d for d in dirs
                if not any(
                    self._match_pattern(d, pat) for pat in exclude_patterns
                )
            ]

            for filename in sorted(files):
                if any(self._match_pattern(filename, pat) for pat in exclude_patterns):
                    continue

                filepath = os.path.join(root, filename)
                rel_path = os.path.relpath(filepath, source_dir)

                try:
                    file_hash = self._hash_file(filepath)
                    file_hashes.append((rel_path, file_hash))
                except Exception as e:
                    logger.warning("计算文件哈希失败 %s: %s", filepath, e)

        # 按路径排序
        file_hashes.sort(key=lambda x: x[0])

        # 构建Merkle哈希树
        if not file_hashes:
            logger.warning("源代码目录为空")
            return [hashlib.sha256(b"empty").hexdigest()]

        # 叶子节点哈希
        leaf_hashes = [
            hashlib.sha256(f"{path}:{hash_val}".encode()).hexdigest()
            for path, hash_val in file_hashes
        ]

        # 构建哈希链（逐层合并）
        hash_chain = list(leaf_hashes)
        current_level = leaf_hashes

        while len(current_level) > 1:
            next_level: List[str] = []
            for i in range(0, len(current_level), 2):
                if i + 1 < len(current_level):
                    combined = hashlib.sha256(
                        f"{current_level[i]}{current_level[i + 1]}".encode()
                    ).hexdigest()
                else:
                    combined = current_level[i]
                next_level.append(combined)
            hash_chain.extend(next_level)
            current_level = next_level

        root_hash = current_level[0] if current_level else ""
        logger.info(
            "源代码哈希链计算完成: %d 个文件, 根哈希: %s",
            len(file_hashes), root_hash[:16] + "...",
        )

        return hash_chain

    def sign_build(
        self,
        build_dir: str,
        source_dir: str,
        artifact_patterns: Optional[List[str]] = None,
    ) -> BuildArtifact:
        """签名构建产物 (Sign build artifacts)

        对构建目录中的产物进行签名，关联源代码哈希和构建环境指纹。

        Args:
            build_dir: 构建产物目录
            source_dir: 源代码目录
            artifact_patterns: 产物文件匹配模式

        Returns:
            BuildArtifact: 签名后的构建产物信息

        Raises:
            FileNotFoundError: 当构建目录或源代码目录不存在时
        """
        if not os.path.exists(build_dir):
            raise FileNotFoundError(f"构建目录不存在: {build_dir}")
        if not os.path.exists(source_dir):
            raise FileNotFoundError(f"源代码目录不存在: {source_dir}")

        artifact_patterns = artifact_patterns or ["*.whl", "*.tar.gz", "*.zip", "*.egg"]

        logger.info("签名构建产物: build=%s, source=%s", build_dir, source_dir)

        # 1. 生成环境指纹
        env_fingerprint = self.generate_environment_fingerprint()

        # 2. 计算源代码哈希链
        source_hash_chain = self.compute_source_hash_chain(source_dir)
        root_hash = source_hash_chain[-1] if source_hash_chain else ""

        # 3. 收集构建产物
        artifacts: List[str] = []
        for root, _, files in os.walk(build_dir):
            for filename in files:
                if any(self._match_pattern(filename, pat) for pat in artifact_patterns):
                    artifacts.append(os.path.join(root, filename))

        if not artifacts:
            logger.warning("未找到构建产物")

        # 4. 计算产物哈希并签名
        build_timestamp = datetime.now(timezone.utc)
        artifact_hashes: List[str] = []
        for artifact_path in artifacts:
            artifact_hash = self._hash_file(artifact_path)
            artifact_hashes.append(artifact_hash)

        # 合并所有哈希生成最终签名数据
        all_hashes = ":".join([
            env_fingerprint,
            root_hash,
            *artifact_hashes,
            build_timestamp.isoformat(),
        ])

        # 生成签名
        if self._signing_key:
            signature = self._signing_key.sign(all_hashes.encode())
            signature_hex = signature.hex()
        else:
            # 使用HMAC-SHA256作为降级方案
            import hmac
            hmac_key = env_fingerprint.encode()
            signature_hex = hmac.new(
                hmac_key, all_hashes.encode(), hashlib.sha256
            ).hexdigest()

        # 5. 保存签名文件
        manifest = {
            "environment_fingerprint": env_fingerprint,
            "source_root_hash": root_hash,
            "source_hash_chain": source_hash_chain,
            "artifacts": [
                {
                    "path": os.path.relpath(a, build_dir),
                    "hash": h,
                }
                for a, h in zip(artifacts, artifact_hashes)
            ],
            "build_timestamp": build_timestamp.isoformat(),
            "signature": signature_hex,
            "hash_algorithm": self.hash_algorithm,
        }

        manifest_path = os.path.join(self.output_dir, "build_manifest.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)

        logger.info(
            "构建签名完成: %d 个产物, 签名: %s",
            len(artifacts), signature_hex[:16] + "...",
        )

        # 返回第一个主要产物的信息
        primary_artifact = artifacts[0] if artifacts else ""
        primary_hash = artifact_hashes[0] if artifact_hashes else ""

        return BuildArtifact(
            artifact_path=primary_artifact,
            artifact_hash=primary_hash,
            source_hash_chain=source_hash_chain,
            environment_fingerprint=env_fingerprint,
            build_timestamp=build_timestamp,
            signature=signature_hex,
        )

    def verify_build(
        self, manifest_path: str, build_dir: str, source_dir: str,
    ) -> bool:
        """验证构建签名 (Verify build signature)

        验证构建产物的签名是否有效，检查：
        - 构建环境指纹是否匹配
        - 源代码哈希链是否一致
        - 构建产物是否被篡改

        Args:
            manifest_path: 构建清单文件路径
            build_dir: 构建产物目录
            source_dir: 源代码目录

        Returns:
            bool: 验证是否通过

        Raises:
            FileNotFoundError: 当清单文件不存在时
        """
        if not os.path.exists(manifest_path):
            raise FileNotFoundError(f"构建清单文件不存在: {manifest_path}")

        logger.info("验证构建签名: manifest=%s", manifest_path)

        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                manifest = json.load(f)
        except json.JSONDecodeError as e:
            logger.error("构建清单解析失败: %s", e)
            return False

        # 1. 验证源代码哈希链
        current_hash_chain = self.compute_source_hash_chain(source_dir)
        stored_root_hash = manifest.get("source_root_hash", "")
        current_root_hash = current_hash_chain[-1] if current_hash_chain else ""

        if current_root_hash != stored_root_hash:
            logger.error(
                "源代码哈希不匹配: 预期 %s, 实际 %s",
                stored_root_hash[:16], current_root_hash[:16],
            )
            return False

        # 2. 验证构建产物哈希
        stored_artifacts = manifest.get("artifacts", [])
        for artifact_info in stored_artifacts:
            artifact_path = os.path.join(build_dir, artifact_info["path"])
            if not os.path.exists(artifact_path):
                logger.error("构建产物缺失: %s", artifact_path)
                return False

            current_hash = self._hash_file(artifact_path)
            if current_hash != artifact_info["hash"]:
                logger.error(
                    "产物哈希不匹配: %s (预期 %s, 实际 %s)",
                    artifact_info["path"],
                    artifact_info["hash"][:16],
                    current_hash[:16],
                )
                return False

        # 3. 验证签名
        stored_signature = manifest.get("signature", "")
        env_fingerprint = manifest.get("environment_fingerprint", "")
        build_timestamp = manifest.get("build_timestamp", "")

        # 重建签名数据
        artifact_hashes = [a["hash"] for a in stored_artifacts]
        all_hashes = ":".join([
            env_fingerprint,
            stored_root_hash,
            *artifact_hashes,
            build_timestamp,
        ])

        if self._signing_key:
            try:
                from cryptography.hazmat.primitives.asymmetric import ed25519
                pub_key = self._signing_key.public_key()
                pub_key.verify(
                    bytes.fromhex(stored_signature),
                    all_hashes.encode(),
                )
                logger.info("ED25519签名验证通过")
            except Exception as e:
                logger.error("签名验证失败: %s", e)
                return False
        else:
            # HMAC验证
            import hmac
            hmac_key = env_fingerprint.encode()
            expected_sig = hmac.new(
                hmac_key, all_hashes.encode(), hashlib.sha256
            ).hexdigest()
            if expected_sig != stored_signature:
                logger.error("HMAC签名不匹配")
                return False

        logger.info("构建签名验证通过")
        return True

    def verify_reproducibility(
        self,
        build_dir_1: str,
        build_dir_2: str,
    ) -> Dict[str, Any]:
        """验证构建可重现性 (Verify build reproducibility)

        比较两次构建的产物是否完全一致。

        Args:
            build_dir_1: 第一次构建目录
            build_dir_2: 第二次构建目录

        Returns:
            Dict[str, Any]: 验证结果，包含is_reproducible和差异详情
        """
        logger.info(
            "验证构建可重现性: %s vs %s", build_dir_1, build_dir_2,
        )

        # 收集两个目录的文件哈希
        hashes_1 = self._collect_dir_hashes(build_dir_1)
        hashes_2 = self._collect_dir_hashes(build_dir_2)

        # 比较差异
        all_files = set(hashes_1.keys()) | set(hashes_2.keys())
        differences: List[Dict[str, Any]] = []
        matching_count = 0

        for filepath in sorted(all_files):
            h1 = hashes_1.get(filepath)
            h2 = hashes_2.get(filepath)

            if h1 is None:
                differences.append({
                    "file": filepath,
                    "type": "missing_in_second",
                })
            elif h2 is None:
                differences.append({
                    "file": filepath,
                    "type": "missing_in_first",
                })
            elif h1 != h2:
                differences.append({
                    "file": filepath,
                    "type": "hash_mismatch",
                    "hash_1": h1,
                    "hash_2": h2,
                })
            else:
                matching_count += 1

        is_reproducible = len(differences) == 0
        result = {
            "is_reproducible": is_reproducible,
            "matching_files": matching_count,
            "total_files": len(all_files),
            "differences": differences,
        }

        if is_reproducible:
            logger.info("构建可重现: %d 个文件完全一致", matching_count)
        else:
            logger.warning(
                "构建不可重现: %d 个文件有差异", len(differences),
            )

        return result

    def _hash_file(self, filepath: str) -> str:
        """计算文件哈希 (Compute file hash)

        Args:
            filepath: 文件路径

        Returns:
            str: 哈希值（十六进制字符串）
        """
        h = hashlib.new(self.hash_algorithm)
        with open(filepath, "rb") as f:
            # 分块读取以处理大文件
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    def _collect_dir_hashes(self, directory: str) -> Dict[str, str]:
        """收集目录中所有文件的哈希 (Collect hashes of all files in directory)

        Args:
            directory: 目录路径

        Returns:
            Dict[str, str]: 相对路径到哈希值的映射
        """
        hashes: Dict[str, str] = {}
        for root, _, files in os.walk(directory):
            for filename in files:
                filepath = os.path.join(root, filename)
                rel_path = os.path.relpath(filepath, directory)
                try:
                    hashes[rel_path] = self._hash_file(filepath)
                except Exception as e:
                    logger.debug("计算文件哈希失败 %s: %s", filepath, e)
        return hashes

    @staticmethod
    def _match_pattern(name: str, pattern: str) -> bool:
        """匹配文件名模式 (Match filename pattern)

        Args:
            name: 文件名
            pattern: glob模式

        Returns:
            bool: 是否匹配
        """
        import fnmatch
        return fnmatch.fnmatch(name, pattern)

    def generate_signing_key(self, key_path: str) -> str:
        """生成签名密钥对 (Generate signing key pair)

        生成ED25519密钥对，用于构建签名。如果cryptography库不可用，
        则生成HMAC密钥作为降级方案。

        Args:
            key_path: 私钥保存路径

        Returns:
            str: 公钥（十六进制编码）

        Raises:
            ValueError: 当密钥路径无效时
        """
        if not key_path:
            raise ValueError("密钥路径不能为空")

        try:
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric import ed25519

            # 生成ED25519密钥对
            private_key = ed25519.Ed25519PrivateKey.generate()
            public_key = private_key.public_key()

            # 保存私钥
            os.makedirs(os.path.dirname(key_path) if os.path.dirname(key_path) else ".", exist_ok=True)
            with open(key_path, "wb") as f:
                f.write(
                    private_key.private_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PrivateFormat.PKCS8,
                        encryption_algorithm=serialization.NoEncryption(),
                    )
                )

            # 获取公钥
            pub_bytes = public_key.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
            pub_hex = pub_bytes.hex()

            logger.info("ED25519密钥对生成成功: %s", key_path)
            return pub_hex

        except ImportError:
            # 降级：生成随机HMAC密钥
            import secrets
            hmac_key = secrets.token_hex(32)
            os.makedirs(os.path.dirname(key_path) if os.path.dirname(key_path) else ".", exist_ok=True)
            with open(key_path, "w", encoding="utf-8") as f:
                f.write(hmac_key)

            logger.info("HMAC密钥生成成功（降级模式）: %s", key_path)
            return hmac_key
