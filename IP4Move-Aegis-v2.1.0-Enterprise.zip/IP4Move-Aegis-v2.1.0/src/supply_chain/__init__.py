"""
供应链安全模块 (Supply Chain Security Module)

本模块提供软件供应链安全防护功能，包括：
- 依赖库签名验证（PGP/GPG、SHA-256校验和）
- 依赖库漏洞扫描（SCA，基于CVE数据库）
- 最小化依赖管理（依赖树分析、未使用依赖检测）
- 构建过程签名（构建环境指纹、源代码哈希链）

安全级别：供应链完整性 Level 3
兼容性：Python 3.10+

典型用法:
    from src.supply_chain import (
        DependencySignatureVerifier,
        VulnerabilityScanner,
        MinimalDependencyManager,
        BuildSigner,
    )

    # 依赖签名验证
    verifier = DependencySignatureVerifier()
    result = verifier.verify_package("requests", "2.31.0")

    # 漏洞扫描
    scanner = VulnerabilityScanner()
    vulns = scanner.scan_requirements("requirements.txt")

    # 最小化依赖管理
    manager = MinimalDependencyManager()
    unused = manager.detect_unused_dependencies("myproject/")

    # 构建签名
    signer = BuildSigner()
    signer.sign_build("./dist/", "./build_artifacts/")
"""

# 版本信息
__version__ = "1.0.5"
__author__ = "IP4Move Aegis Security Team"
__protocol_version__ = "SCS-1.0"

# 从 integrity_verification 模块导出所有公开类
from src.supply_chain.integrity_verification import (
    DependencySignatureVerifier,
    VulnerabilityScanner,
    MinimalDependencyManager,
    BuildSigner,
)

__all__ = [
    "DependencySignatureVerifier",
    "VulnerabilityScanner",
    "MinimalDependencyManager",
    "BuildSigner",
]
