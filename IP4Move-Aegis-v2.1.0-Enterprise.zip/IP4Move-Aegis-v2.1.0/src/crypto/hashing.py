"""
哈希模块

提供 BLAKE3 哈希、SHA-256 备选、HMAC 消息认证码和哈希链验证。
"""

import os
import hmac
import hashlib
import abc
from typing import List, Optional


class HashEngine(abc.ABC):
    """哈希引擎抽象基类"""

    ALGORITHM_NAME: str = "unknown"
    DIGEST_SIZE: int = 0

    @abc.abstractmethod
    def hash(self, data: bytes) -> bytes:
        """计算哈希值"""
        ...

    @abc.abstractmethod
    def hash_iter(self, chunks: List[bytes]) -> bytes:
        """增量计算多块数据的哈希值"""
        ...


class BLAKE3Hash(HashEngine):
    """
    BLAKE3 哈希实现

    - 256 位输出
    - 支持增量哈希
    - 比 SHA-256 更快且更安全
    """

    ALGORITHM_NAME = "blake3"
    DIGEST_SIZE = 32

    def __init__(self):
        try:
            import blake3 as _blake3

            self._blake3 = _blake3
            self._use_lib = True
        except ImportError:
            self._blake3 = None
            self._use_lib = False

    def hash(self, data: bytes) -> bytes:
        """计算 BLAKE3 哈希"""
        if self._use_lib:
            return self._blake3.blake3(data).digest()
        else:
            # 回退到 hashlib (Python 3.11+ 支持 blake3)
            h = hashlib.blake3(data) if hasattr(hashlib, "blake3") else hashlib.sha256(data)
            return h.digest()

    def hash_iter(self, chunks: List[bytes]) -> bytes:
        """增量计算多块数据的哈希值"""
        if self._use_lib:
            hasher = self._blake3.blake3()
            for chunk in chunks:
                hasher.update(chunk)
            return hasher.digest()
        else:
            if hasattr(hashlib, "blake3"):
                h = hashlib.blake3()
            else:
                h = hashlib.sha256()
            for chunk in chunks:
                h.update(chunk)
            return h.digest()

    def keyed_hash(self, data: bytes, key: bytes) -> bytes:
        """BLAKE3 密钥哈希模式"""
        if self._use_lib:
            return self._blake3.blake3(data, key=key).digest()
        else:
            # 回退: HMAC-BLAKE3 或 HMAC-SHA256
            return hmac.new(key, data, hashlib.blake3 if hasattr(hashlib, "blake3") else hashlib.sha256).digest()

    def derive_key(self, data: bytes, context: str, length: int = 32) -> bytes:
        """BLAKE3 密钥派生模式"""
        if self._use_lib:
            return self._blake3.blake3(data, derive_from_context=context.encode()).digest(length=length)
        else:
            # 回退: HKDF-SHA256
            from cryptography.hazmat.primitives.kdf.hkdf import HKDF
            from cryptography.hazmat.primitives import hashes
            hkdf = HKDF(
                algorithm=hashes.SHA256(),
                length=length,
                salt=data[:32] if len(data) >= 32 else data.ljust(32, b"\x00"),
                info=context.encode(),
            )
            return hkdf.derive(data)


class SHA256Hash(HashEngine):
    """
    SHA-256 哈希实现

    - 256 位输出
    - 广泛兼容
    - 作为 BLAKE3 不可用时的备选
    """

    ALGORITHM_NAME = "sha256"
    DIGEST_SIZE = 32

    def hash(self, data: bytes) -> bytes:
        """计算 SHA-256 哈希"""
        return hashlib.sha256(data).digest()

    def hash_iter(self, chunks: List[bytes]) -> bytes:
        """增量计算多块数据的哈希值"""
        h = hashlib.sha256()
        for chunk in chunks:
            h.update(chunk)
        return h.digest()


class SHA3_512Hash(HashEngine):
    """
    SHA3-512 抗量子哈希实现

    - 512 位输出 (抗 Grover 攻击: 2^256 搜索复杂度)
    - NIST 标准
    - 抗量子计算攻击
    """

    ALGORITHM_NAME = "sha3-512"
    DIGEST_SIZE = 64

    def hash(self, data: bytes) -> bytes:
        """计算 SHA3-512 哈希"""
        try:
            return hashlib.sha3_512(data).digest()
        except AttributeError:
            return hashlib.sha512(data).digest()

    def hash_iter(self, chunks: List[bytes]) -> bytes:
        """增量计算多块数据的哈希值"""
        try:
            h = hashlib.sha3_512()
        except AttributeError:
            h = hashlib.sha512()
        for chunk in chunks:
            h.update(chunk)
        return h.digest()


class HMACAuth:
    """
    HMAC 消息认证码

    - 支持 SHA-256 和 BLAKE3
    - 恒定时间比较防止时序攻击
    """

    def __init__(self, key: Optional[bytes] = None, algorithm: str = "sha256"):
        self._key = key or os.urandom(32)
        self._algorithm = algorithm

    def compute(self, data: bytes) -> bytes:
        """计算 HMAC"""
        if self._algorithm == "blake3" and hasattr(hashlib, "blake3"):
            return hmac.new(self._key, data, hashlib.blake3).digest()
        return hmac.new(self._key, data, hashlib.sha256).digest()

    def verify(self, data: bytes, mac: bytes) -> bool:
        """验证 HMAC，恒定时间比较"""
        expected = self.compute(data)
        return hmac.compare_digest(expected, mac)

    def compute_multi(self, chunks: List[bytes]) -> bytes:
        """增量计算多块数据的 HMAC"""
        h = hmac.new(self._key, digestmod=hashlib.blake3 if (self._algorithm == "blake3" and hasattr(hashlib, "blake3")) else hashlib.sha256)
        for chunk in chunks:
            h.update(chunk)
        return h.digest()


class HashChain:
    """
    哈希链实现

    用于包序号验证和密钥链派生。
    H(n) = H(H(n-1))，从种子开始生成确定性序列。
    """

    def __init__(self, seed: Optional[bytes] = None, hash_engine: Optional[HashEngine] = None):
        self._seed = seed or os.urandom(32)
        self._engine = hash_engine or BLAKE3Hash()
        self._chain: List[bytes] = [self._seed]
        self._current_index = 0

    def next(self) -> bytes:
        """
        生成链中下一个哈希值

        Returns:
            下一个哈希值
        """
        prev = self._chain[-1]
        next_hash = self._engine.hash(prev)
        self._chain.append(next_hash)
        self._current_index += 1
        return next_hash

    def get(self, index: int) -> bytes:
        """获取指定索引的哈希值"""
        if index < 0 or index >= len(self._chain):
            raise IndexError(f"哈希链索引越界: {index}, 链长度: {len(self._chain)}")
        return self._chain[index]

    def verify(self, index: int, value: bytes) -> bool:
        """
        验证指定索引的哈希值是否正确

        通过从种子重新计算到目标索引来验证。
        """
        if index < 0 or index >= len(self._chain):
            return False
        return hmac.compare_digest(self._chain[index], value)

    def verify_chain(self, values: List[bytes]) -> bool:
        """
        验证整个哈希链

        检查每个值是否是前一个值的正确哈希。
        """
        if len(values) != len(self._chain):
            return False
        for i, value in enumerate(values):
            if not self.verify(i, value):
                return False
        return True

    @property
    def length(self) -> int:
        """当前链长度"""
        return len(self._chain)

    @property
    def seed(self) -> bytes:
        """链种子"""
        return self._seed

    def reset(self, new_seed: Optional[bytes] = None) -> None:
        """重置哈希链"""
        self._seed = new_seed or os.urandom(32)
        self._chain = [self._seed]
        self._current_index = 0


def create_hash_engine(algorithm: str = "blake3") -> HashEngine:
    """
    工厂函数: 根据算法名称创建哈希引擎

    Args:
        algorithm: 算法名称 (blake3, sha256)

    Returns:
        对应的哈希引擎实例
    """
    engine_map = {
        "blake3": BLAKE3Hash,
        "sha256": SHA256Hash,
        "sha3-512": SHA3_512Hash,
    }
    engine_cls = engine_map.get(algorithm)
    if engine_cls is None:
        raise ValueError(f"不支持的哈希算法: {algorithm}, 可选: {list(engine_map.keys())}")
    return engine_cls()
