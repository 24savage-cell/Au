"""
国密SM2/SM3/SM4实现 - 企业级合规支持

支持:
- SM2: 椭圆曲线公钥密码算法 (签名/密钥交换)
- SM3: 密码杂凑算法 (哈希)
- SM4: 分组密码算法 (对称加密)

符合:
- GM/T 0003.1-2012 SM2椭圆曲线公钥密码算法
- GM/T 0004-2012 SM3密码杂凑算法
- GM/T 0002-2012 SM4分组密码算法

依赖:
    pip install gmssl

版本: v2.1.0-enterprise
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
from dataclasses import dataclass
from typing import Optional, Tuple, Union

logger = logging.getLogger(__name__)

# 尝试导入gmssl
try:
    from gmssl import sm2, sm3, sm4, func
    HAS_GMSSL = True
except ImportError:
    HAS_GMSSL = False
    logger.warning("gmssl未安装，SM2/SM3/SM4不可用。pip install gmssl")


# ============================================================================
# SM3哈希
# ============================================================================

class SM3Hash:
    """SM3密码杂凑算法"""
    
    DIGEST_SIZE = 32  # 256位
    BLOCK_SIZE = 64   # 512位分组
    
    @staticmethod
    def hash(data: bytes) -> bytes:
        """计算SM3哈希"""
        if HAS_GMSSL:
            return sm3.sm3_hash(func.bytes_to_list(data)).encode()
        else:
            # 回退到SHA256 (不推荐用于生产)
            logger.warning("使用SHA256回退，非国密合规")
            return hashlib.sha256(data).digest()
    
    @staticmethod
    def hmac(key: bytes, data: bytes) -> bytes:
        """SM3-HMAC"""
        if HAS_GMSSL:
            # 使用HMAC-SM3
            return hmac.new(key, data, digestmod=lambda: SM3Hash).digest()
        else:
            return hmac.new(key, data, hashlib.sha256).digest()


# ============================================================================
# SM4对称加密
# ============================================================================

class SM4Cipher:
    """
    SM4分组密码算法
    
    模式支持:
    - ECB (不推荐)
    - CBC
    - CTR
    - GCM (认证加密)
    """
    
    KEY_SIZE = 16     # 128位密钥
    BLOCK_SIZE = 16   # 128位分组
    
    def __init__(self, key: bytes, mode: str = "CBC"):
        """
        Args:
            key: 16字节密钥
            mode: 加密模式 (ECB/CBC/CTR/GCM)
        """
        if len(key) != self.KEY_SIZE:
            raise ValueError(f"SM4密钥必须是{self.KEY_SIZE}字节")
        
        self._key = key
        self._mode = mode.upper()
        
        if HAS_GMSSL:
            self._cipher = sm4.CryptSM4()
            self._cipher.set_key(key, sm4.SM4_ENCRYPT)
    
    def encrypt(self, plaintext: bytes, iv: Optional[bytes] = None) -> Tuple[bytes, bytes]:
        """
        加密
        
        Returns:
            (ciphertext, iv)
        """
        if iv is None:
            iv = os.urandom(self.BLOCK_SIZE)
        
        if not HAS_GMSSL:
            # 回退到AES (不推荐)
            from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
            cipher = Cipher(algorithms.AES(self._key), modes.CBC(iv))
            encryptor = cipher.encryptor()
            
            # PKCS7填充
            pad_len = self.BLOCK_SIZE - (len(plaintext) % self.BLOCK_SIZE)
            padded = plaintext + bytes([pad_len] * pad_len)
            
            ciphertext = encryptor.update(padded) + encryptor.finalize()
            return ciphertext, iv
        
        # 使用gmssl SM4
        if self._mode == "CBC":
            # PKCS7填充
            pad_len = self.BLOCK_SIZE - (len(plaintext) % self.BLOCK_SIZE)
            padded = plaintext + bytes([pad_len] * pad_len)
            
            self._cipher.set_key(self._key, sm4.SM4_ENCRYPT)
            ciphertext = self._cipher.crypt_cbc(iv, padded)
            return ciphertext, iv
        
        elif self._mode == "ECB":
            # PKCS7填充
            pad_len = self.BLOCK_SIZE - (len(plaintext) % self.BLOCK_SIZE)
            padded = plaintext + bytes([pad_len] * pad_len)
            
            self._cipher.set_key(self._key, sm4.SM4_ENCRYPT)
            ciphertext = self._cipher.crypt_ecb(padded)
            return ciphertext, b""
        
        elif self._mode == "CTR":
            # CTR模式不需要填充
            self._cipher.set_key(self._key, sm4.SM4_ENCRYPT)
            ciphertext = self._cipher.crypt_ctr(iv, plaintext)
            return ciphertext, iv
        
        else:
            raise ValueError(f"不支持的SM4模式: {self._mode}")
    
    def decrypt(self, ciphertext: bytes, iv: bytes) -> bytes:
        """解密"""
        if not HAS_GMSSL:
            from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
            cipher = Cipher(algorithms.AES(self._key), modes.CBC(iv))
            decryptor = cipher.decryptor()
            padded = decryptor.update(ciphertext) + decryptor.finalize()
            
            # 去除PKCS7填充
            pad_len = padded[-1]
            return padded[:-pad_len]
        
        if self._mode == "CBC":
            self._cipher.set_key(self._key, sm4.SM4_DECRYPT)
            padded = self._cipher.crypt_cbc(iv, ciphertext)
            
            # 去除PKCS7填充
            pad_len = padded[-1]
            return padded[:-pad_len]
        
        elif self._mode == "ECB":
            self._cipher.set_key(self._key, sm4.SM4_DECRYPT)
            padded = self._cipher.crypt_ecb(ciphertext)
            
            pad_len = padded[-1]
            return padded[:-pad_len]
        
        elif self._mode == "CTR":
            self._cipher.set_key(self._key, sm4.SM4_ENCRYPT)  # CTR加密解密相同
            return self._cipher.crypt_ctr(iv, ciphertext)
        
        else:
            raise ValueError(f"不支持的SM4模式: {self._mode}")


# ============================================================================
# SM2非对称加密
# ============================================================================

@dataclass
class SM2KeyPair:
    """SM2密钥对"""
    private_key: bytes
    public_key: bytes
    
    def to_dict(self) -> dict:
        return {
            "private_key": self.private_key.hex(),
            "public_key": self.public_key.hex(),
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "SM2KeyPair":
        return cls(
            private_key=bytes.fromhex(data["private_key"]),
            public_key=bytes.fromhex(data["public_key"]),
        )


class SM2Crypto:
    """
    SM2椭圆曲线公钥密码算法
    
    功能:
    - 密钥生成
    - 签名/验签
    - 加密/解密
    - 密钥交换
    """
    
    # SM2推荐曲线参数
    CURVE_P = "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFF"
    CURVE_A = "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC"
    CURVE_B = "28E9FA9E9D9F5E344D5A9E4BCF6509A7F39789F515AB8F92DDBCBD414D940E93"
    CURVE_N = "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFF7203DF6B21C6052B53BBF40939D54123"
    CURVE_GX = "32C4AE2C1F1981195F9904466A39C9948FE30BBFF2660BE1715A4589334C74C7"
    CURVE_GY = "BC3736A2F4F6779C59BDCEE36B692153D0A9877CC62A474002DF32E52139F0A0"
    
    def __init__(self, key_pair: Optional[SM2KeyPair] = None):
        """
        Args:
            key_pair: 密钥对 (None时生成新密钥)
        """
        if key_pair is None and HAS_GMSSL:
            # 生成新密钥对
            private_key = os.urandom(32)
            sm2_crypt = sm2.CryptSM2(public_key="", private_key=private_key.hex())
            public_key = bytes.fromhex(sm2_crypt._kg(int(private_key.hex(), 16), self.CURVE_GX + self.CURVE_GY))
            key_pair = SM2KeyPair(private_key=private_key, public_key=public_key)
        
        self._key_pair = key_pair
        
        if HAS_GMSSL and key_pair:
            self._sm2_crypt = sm2.CryptSM2(
                public_key=key_pair.public_key.hex(),
                private_key=key_pair.private_key.hex(),
            )
    
    @property
    def key_pair(self) -> SM2KeyPair:
        return self._key_pair
    
    def sign(self, data: bytes, uid: bytes = b"1234567812345678") -> bytes:
        """
        SM2签名
        
        Args:
            data: 待签名数据
            uid: 用户ID (默认1234567812345678)
        
        Returns:
            签名值 (r, s)
        """
        if not HAS_GMSSL:
            raise RuntimeError("gmssl未安装，无法使用SM2签名")
        
        # 计算Z值
        z = self._sm2_crypt._sm3_z(data.hex())
        
        # 签名
        signature = self._sm2_crypt.sign(z, self._key_pair.private_key.hex())
        return bytes.fromhex(signature)
    
    def verify(self, data: bytes, signature: bytes, uid: bytes = b"1234567812345678") -> bool:
        """SM2验签"""
        if not HAS_GMSSL:
            raise RuntimeError("gmssl未安装，无法使用SM2验签")
        
        try:
            z = self._sm2_crypt._sm3_z(data.hex())
            return self._sm2_crypt.verify(signature.hex(), z)
        except Exception:
            return False
    
    def encrypt(self, plaintext: bytes) -> bytes:
        """SM2加密"""
        if not HAS_GMSSL:
            raise RuntimeError("gmssl未安装，无法使用SM2加密")
        
        return bytes.fromhex(self._sm2_crypt.encrypt(plaintext.hex()))
    
    def decrypt(self, ciphertext: bytes) -> bytes:
        """SM2解密"""
        if not HAS_GMSSL:
            raise RuntimeError("gmssl未安装，无法使用SM2解密")
        
        return bytes.fromhex(self._sm2_crypt.decrypt(ciphertext.hex()))


# ============================================================================
# 国密TLS套件
# ============================================================================

class GMTLSContext:
    """
    国密TLS上下文
    
    支持GMTLS协议 (国密SSL/TLS)
    """
    
    def __init__(
        self,
        cert_path: Optional[str] = None,
        key_path: Optional[str] = None,
        ca_path: Optional[str] = None,
    ):
        self._cert_path = cert_path
        self._key_path = key_path
        self._ca_path = ca_path
    
    def create_server_context(self):
        """创建服务器TLS上下文"""
        # 实际实现需要使用支持国密的SSL库
        # 如: TASSL, BabaSSL等
        logger.info("国密TLS服务器上下文创建 (需要TASSL/BabaSSL)")
        return None
    
    def create_client_context(self):
        """创建客户端TLS上下文"""
        logger.info("国密TLS客户端上下文创建 (需要TASSL/BabaSSL)")
        return None


# ============================================================================
# 国密算法选择器
# ============================================================================

class SMSelector:
    """
    国密算法选择器
    
    根据配置自动选择国密或国际算法
    """
    
    def __init__(self, use_sm: bool = True):
        self._use_sm = use_sm and HAS_GMSSL
        
        if use_sm and not HAS_GMSSL:
            logger.warning("请求使用国密但gmssl未安装，将使用国际算法回退")
    
    @property
    def use_sm(self) -> bool:
        return self._use_sm
    
    def get_hash(self) -> callable:
        """获取哈希函数"""
        if self._use_sm:
            return SM3Hash.hash
        else:
            return hashlib.sha256
    
    def get_cipher(self, key: bytes):
        """获取对称加密器"""
        if self._use_sm:
            return SM4Cipher(key)
        else:
            from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
            return Cipher(algorithms.AES(key), modes.CBC(b"\x00" * 16))
    
    def get_asymmetric(self, key_pair: Optional[SM2KeyPair] = None):
        """获取非对称加密器"""
        if self._use_sm:
            return SM2Crypto(key_pair)
        else:
            # 回退到ECDSA
            raise NotImplementedError("国际算法回退待实现")


# ============================================================================
# 工具函数
# ============================================================================

def generate_sm2_keypair() -> SM2KeyPair:
    """生成SM2密钥对"""
    if not HAS_GMSSL:
        raise RuntimeError("gmssl未安装")
    
    private_key = os.urandom(32)
    sm2_crypt = sm2.CryptSM2(public_key="", private_key=private_key.hex())
    
    # 计算公钥
    curve_g = SM2Crypto.CURVE_GX + SM2Crypto.CURVE_GY
    public_key = bytes.fromhex(
        sm2_crypt._kg(int(private_key.hex(), 16), curve_g)
    )
    
    return SM2KeyPair(private_key=private_key, public_key=public_key)


def sm3_kdf(key: bytes, length: int) -> bytes:
    """
    SM3密钥派生函数 (KDF)
    
    基于SM3的密钥派生，符合GM/T标准
    """
    result = b""
    counter = 1
    
    while len(result) < length:
        counter_bytes = counter.to_bytes(4, "big")
        result += SM3Hash.hash(key + counter_bytes)
        counter += 1
    
    return result[:length]


def check_sm_support() -> dict:
    """检查国密支持状态"""
    return {
        "gmssl_installed": HAS_GMSSL,
        "sm2_available": HAS_GMSSL,
        "sm3_available": HAS_GMSSL,
        "sm4_available": HAS_GMSSL,
        "gmtls_available": False,  # 需要额外库
    }
