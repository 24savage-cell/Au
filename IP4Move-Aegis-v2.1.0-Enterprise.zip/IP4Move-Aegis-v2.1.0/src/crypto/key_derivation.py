"""
密钥链派生模块

BIP-32 风格密钥派生，支持前向安全密钥轮换和密钥隔离。
"""

import os
import time
import hashlib
import abc
from typing import Optional, Tuple, List

from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

from src.crypto.hashing import BLAKE3Hash, HashEngine


class KeyDerivation:
    """
    密钥派生引擎

    - BIP-32 风格: K_child = H(K_parent || index || randomness)
    - 前向安全: 密钥轮换后旧密钥无法推导新密钥
    - 密钥隔离: 单跳密钥泄露不影响其他跳
    """

    def __init__(
        self,
        master_key: Optional[bytes] = None,
        hash_engine: Optional[HashEngine] = None,
        context: str = "ip4move-key-derivation",
    ):
        self._master_key = master_key or os.urandom(32)
        self._engine = hash_engine or BLAKE3Hash()
        self._context = context.encode("utf-8")
        self._backend = default_backend()

    def derive_child_key(
        self,
        parent_key: bytes,
        index: int,
        extra_randomness: Optional[bytes] = None,
    ) -> Tuple[bytes, bytes]:
        """
        从父密钥派生子密钥 (BIP-32 风格)

        K_child = HKDF(K_parent || index || randomness)

        Args:
            parent_key: 父密钥
            index: 派生索引
            extra_randomness: 额外随机数

        Returns:
            (child_key, chain_code)
        """
        randomness = extra_randomness or os.urandom(32)
        # 构造派生材料
        material = parent_key + index.to_bytes(4, "big") + randomness
        # 使用 HKDF 派生
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=64,  # 32字节密钥 + 32字节链码
            salt=self._context,
            info=material[:32],
            backend=self._backend,
        )
        derived = hkdf.derive(material)
        child_key = derived[:32]
        chain_code = derived[32:]
        return child_key, chain_code

    def derive_path(self, path: List[int]) -> bytes:
        """
        沿路径派生密钥

        Args:
            path: 派生路径索引列表, 如 [0, 1, 2] 表示 m/0/1/2

        Returns:
            最终派生的密钥
        """
        current_key = self._master_key
        for index in path:
            current_key, _ = self.derive_child_key(current_key, index)
        return current_key

    def derive_hop_keys(self, num_hops: int) -> List[bytes]:
        """
        为多跳路径派生独立的跳密钥

        每跳密钥相互隔离，单跳泄露不影响其他跳。
        使用确定性派生 (无额外随机数)。

        Args:
            num_hops: 跳数

        Returns:
            跳密钥列表
        """
        keys = []
        for i in range(num_hops):
            key, _ = self.derive_child_key(self._master_key, i, extra_randomness=b"\x00" * 32)
            keys.append(key)
        return keys

    def derive_session_key(
        self,
        shared_secret: bytes,
        session_id: Optional[bytes] = None,
        length: int = 32,
    ) -> bytes:
        """
        从共享密钥派生会话密钥

        Args:
            shared_secret: DH 共享密钥
            session_id: 会话标识符
            length: 输出密钥长度

        Returns:
            会话密钥
        """
        session_id = session_id or os.urandom(16)
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=length,
            salt=session_id,
            info=self._context + b":session",
            backend=self._backend,
        )
        return hkdf.derive(shared_secret)

    def derive_pqc_child_key(
        self,
        parent_key: bytes,
        index: int,
        extra_randomness: Optional[bytes] = None,
    ) -> Tuple[bytes, bytes]:
        """
        后量子安全密钥派生

        使用 SHA3-512 + HMAC 双重派生，抗量子Grover攻击。
        K_child = SHA3-512(K_parent || index || randomness || context)
        chain_code = HMAC-SHA3-512(K_child, context)
        """
        randomness = extra_randomness or os.urandom(48)  # 48字节额外随机数
        material = parent_key + index.to_bytes(4, "big") + randomness + self._context
        # 使用 SHA3-512 派生 (96字节: 48字节密钥 + 48字节链码)
        try:
            derived = hashlib.sha3_512(material).digest()
        except AttributeError:
            derived = hashlib.sha512(material).digest()
        child_key = derived[:48]
        chain_code = derived[48:]
        return child_key, chain_code

    def derive_pqc_path(self, path: List[int]) -> bytes:
        """沿路径进行后量子安全密钥派生"""
        current_key = self._master_key
        for index in path:
            current_key, _ = self.derive_pqc_child_key(current_key, index)
        return current_key


class KeyChain:
    """
    密钥链管理器

    - 前向安全密钥轮换
    - 密钥生命周期管理
    - 自动过期和轮换
    """

    DEFAULT_SESSION_TIMEOUT = 600  # 10分钟

    def __init__(
        self,
        master_key: Optional[bytes] = None,
        session_timeout: int = DEFAULT_SESSION_TIMEOUT,
        hash_engine: Optional[HashEngine] = None,
    ):
        self._derivation = KeyDerivation(master_key, hash_engine)
        self._session_timeout = session_timeout
        self._current_key_index = 0
        self._current_key: bytes = master_key or os.urandom(32)
        self._key_history: List[Tuple[int, bytes, float]] = []
        self._chain_codes: List[bytes] = []
        self._last_rotation = time.time()
        self._engine = hash_engine or BLAKE3Hash()

    @property
    def current_key(self) -> bytes:
        """获取当前密钥"""
        self._check_rotation()
        return self._current_key

    @property
    def current_index(self) -> int:
        """获取当前密钥索引"""
        return self._current_key_index

    def rotate(self) -> bytes:
        """
        手动轮换密钥

        前向安全: 新密钥通过 K_new = H(K_old || random) 生成，
        旧密钥无法推导新密钥。

        Returns:
            新密钥
        """
        # 保存旧密钥到历史
        self._key_history.append(
            (self._current_key_index, self._current_key, time.time())
        )
        # 限制历史密钥数量，防止内存无限增长
        if len(self._key_history) > 100:
            self._key_history = self._key_history[-50:]
        # 派生新密钥
        new_key, chain_code = self._derivation.derive_child_key(
            self._current_key, self._current_key_index
        )
        self._current_key = new_key
        self._chain_codes.append(chain_code)
        self._current_key_index += 1
        self._last_rotation = time.time()
        return new_key

    def _check_rotation(self) -> None:
        """检查是否需要自动轮换密钥"""
        if time.time() - self._last_rotation > self._session_timeout:
            self.rotate()

    def derive_hop_key(self, hop_index: int) -> bytes:
        """
        派生指定跳的密钥

        密钥隔离: 每跳密钥独立派生，单跳泄露不影响其他跳。

        Args:
            hop_index: 跳索引

        Returns:
            该跳的独立密钥
        """
        key, _ = self._derivation.derive_child_key(self._current_key, hop_index)
        return key

    def derive_all_hop_keys(self, num_hops: int) -> List[bytes]:
        """
        派生所有跳的密钥

        Args:
            num_hops: 跳数

        Returns:
            跳密钥列表
        """
        return self._derivation.derive_hop_keys(num_hops)

    def get_key_at_index(self, index: int) -> Optional[bytes]:
        """获取指定索引的历史密钥"""
        for idx, key, _ in self._key_history:
            if idx == index:
                return key
        return None

    def verify_key(self, key: bytes, index: int) -> bool:
        """
        验证密钥是否在指定索引处有效

        通过重新派生来验证。
        """
        derived_key, _ = self._derivation.derive_child_key(
            self._current_key, index
        )
        import hmac
        return hmac.compare_digest(derived_key, key)

    def cleanup_history(self, max_age: float = 3600) -> int:
        """
        清理过期的历史密钥

        Args:
            max_age: 最大保留时间(秒)

        Returns:
            清理的密钥数量
        """
        cutoff = time.time() - max_age
        original_len = len(self._key_history)
        self._key_history = [
            (idx, key, ts) for idx, key, ts in self._key_history if ts > cutoff
        ]
        return original_len - len(self._key_history)

    @property
    def session_age(self) -> float:
        """当前会话密钥的年龄(秒)"""
        return time.time() - self._last_rotation

    @property
    def is_expired(self) -> bool:
        """当前会话密钥是否已过期"""
        return self.session_age > self._session_timeout

    def reset(self, new_master_key: Optional[bytes] = None) -> None:
        """重置密钥链"""
        master = new_master_key or os.urandom(32)
        self._derivation = KeyDerivation(master, self._engine)
        self._current_key = master
        self._current_key_index = 0
        self._key_history.clear()
        self._chain_codes.clear()
        self._last_rotation = time.time()

    def pqc_rotate(self) -> bytes:
        """
        后量子前向安全密钥轮换

        使用 SHA3-512 进行密钥更新，提供更强的前向安全性。
        即使量子计算机攻破当前密钥，也无法推导未来密钥。
        """
        self._key_history.append(
            (self._current_key_index, self._current_key, time.time())
        )
        # 限制历史密钥数量，防止内存无限增长
        if len(self._key_history) > 100:
            self._key_history = self._key_history[-50:]
        new_key, chain_code = self._derivation.derive_pqc_child_key(
            self._current_key, self._current_key_index
        )
        self._current_key = new_key
        self._chain_codes.append(chain_code)
        self._current_key_index += 1
        self._last_rotation = time.time()
        return new_key

    def derive_pqc_hop_key(self, hop_index: int) -> bytes:
        """
        派生指定跳的后量子安全密钥

        使用 SHA3-512 派生，提供 48 字节密钥（抗 Grover 攻击）。
        """
        key, _ = self._derivation.derive_pqc_child_key(self._current_key, hop_index)
        return key
