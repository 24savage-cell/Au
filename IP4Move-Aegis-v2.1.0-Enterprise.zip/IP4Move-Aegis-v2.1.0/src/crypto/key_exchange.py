"""
密钥交换模块

提供 X25519 ECDH 密钥交换和 ECDH-ES 每包一密生成。
"""

import os
import abc
import logging
from typing import Optional, Tuple

from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend

logger = logging.getLogger(__name__)


class KeyExchange(abc.ABC):
    """密钥交换抽象基类"""

    ALGORITHM_NAME: str = "unknown"

    @abc.abstractmethod
    def generate_keypair(self) -> Tuple[bytes, bytes]:
        """生成临时密钥对，返回 (private_key_bytes, public_key_bytes)"""
        ...

    @abc.abstractmethod
    def compute_shared_secret(
        self, private_key_bytes: bytes, peer_public_key_bytes: bytes
    ) -> bytes:
        """计算共享密钥"""
        ...

    @abc.abstractmethod
    def derive_session_key(
        self,
        shared_secret: bytes,
        salt: Optional[bytes] = None,
        info: Optional[bytes] = None,
        length: int = 32,
    ) -> bytes:
        """从共享密钥派生会话密钥"""
        ...

    def full_handshake(
        self, peer_public_key_bytes: bytes
    ) -> Tuple[bytes, bytes, bytes]:
        """
        执行完整密钥交换握手

        Returns:
            (my_public_key, session_key, shared_secret)
        """
        private_key_bytes, my_public_key_bytes = self.generate_keypair()
        shared_secret = self.compute_shared_secret(private_key_bytes, peer_public_key_bytes)
        session_key = self.derive_session_key(shared_secret)
        return my_public_key_bytes, session_key, shared_secret


class X25519KeyExchange(KeyExchange):
    """
    X25519 ECDH 密钥交换

    - Curve25519 椭圆曲线
    - HKDF-SHA256 会话密钥派生
    - 支持每包一密 (ECDH-ES 模式)
    """

    ALGORITHM_NAME = "x25519"

    def __init__(self, info: Optional[bytes] = None):
        self._info = info or b"ip4move-key-exchange"
        self._backend = default_backend()

    def generate_keypair(self) -> Tuple[bytes, bytes]:
        """
        生成 X25519 临时密钥对

        Returns:
            (private_key_bytes[32], public_key_bytes[32])
        """
        private_key = X25519PrivateKey.generate()
        public_key = private_key.public_key()
        private_bytes = private_key.private_bytes_raw()
        public_bytes = public_key.public_bytes_raw()
        return private_bytes, public_bytes

    def compute_shared_secret(
        self, private_key_bytes: bytes, peer_public_key_bytes: bytes
    ) -> bytes:
        """
        计算 Diffie-Hellman 共享密钥

        Args:
            private_key_bytes: 本地私钥 (32字节)
            peer_public_key_bytes: 对端公钥 (32字节)

        Returns:
            共享密钥 (32字节)
        """
        private_key = X25519PrivateKey.from_private_bytes(private_key_bytes)
        peer_public_key = X25519PublicKey.from_public_bytes(peer_public_key_bytes)
        return private_key.exchange(peer_public_key)

    def derive_session_key(
        self,
        shared_secret: bytes,
        salt: Optional[bytes] = None,
        info: Optional[bytes] = None,
        length: int = 32,
    ) -> bytes:
        """
        使用 HKDF-SHA256 从共享密钥派生会话密钥

        Args:
            shared_secret: DH 共享密钥
            salt: 可选盐值
            info: 上下文信息
            length: 输出密钥长度

        Returns:
            派生的会话密钥
        """
        salt = salt or os.urandom(32)
        info = info or self._info
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=length,
            salt=salt,
            info=info,
            backend=self._backend,
        )
        return hkdf.derive(shared_secret)

    def ecdh_es_per_packet(
        self,
        peer_public_key_bytes: bytes,
        packet_id: bytes,
        salt: Optional[bytes] = None,
    ) -> Tuple[bytes, bytes]:
        """
        ECDH-ES 每包一密模式

        为每个数据包生成独立的临时密钥对，计算唯一的包密钥。
        即使长期密钥泄露，历史包密钥也不会被推导。

        Args:
            peer_public_key_bytes: 对端公钥
            packet_id: 包唯一标识符
            salt: 可选盐值

        Returns:
            (ephemeral_public_key, packet_key)
        """
        ephemeral_private, ephemeral_public = self.generate_keypair()
        shared_secret = self.compute_shared_secret(ephemeral_private, peer_public_key_bytes)
        # 使用 packet_id 作为 HKDF info 实现每包一密
        info = self._info + b":per-packet:" + packet_id
        packet_key = self.derive_session_key(shared_secret, salt=salt, info=info)
        return ephemeral_public, packet_key

    def mutual_handshake(
        self,
        local_private_bytes: bytes,
        local_public_bytes: bytes,
        peer_public_bytes: bytes,
    ) -> Tuple[bytes, bytes]:
        """
        双向握手: 双方各自计算共享密钥

        由于 X25519 的对称性，双方计算结果相同。

        Returns:
            (shared_secret, session_key)
        """
        shared_secret = self.compute_shared_secret(local_private_bytes, peer_public_bytes)
        session_key = self.derive_session_key(shared_secret)
        return shared_secret, session_key


class KyberKeyExchange(KeyExchange):
    """
    CRYSTALS-Kyber-768 后量子密钥交换

    NIST PQC 标准化算法，抗量子计算机攻击。
    使用 ML-KEM (Module-Lattice Key Encapsulation Mechanism)。
    回退到 X25519+AES-256-GCM 混合模式当 liboqs 不可用时。
    """

    ALGORITHM_NAME = "kyber-768"

    def __init__(self, info: Optional[bytes] = None):
        self._info = info or b"ip4move-pqc-key-exchange"
        self._backend = default_backend()
        self._fallback = X25519KeyExchange(info)
        self._use_pqc = self._check_pqc_available()

    def _check_pqc_available(self) -> bool:
        """检查后量子密码学库是否可用"""
        try:
            from cryptography.hazmat.primitives.asymmetric.kyber import (
                MLKEM768PrivateKey, MLKEM768PublicKey,
            )
            return True
        except ImportError:
            try:
                import liboqs
                return True
            except ImportError:
                return False

    def generate_keypair(self) -> Tuple[bytes, bytes]:
        """生成 Kyber-768 密钥对"""
        if self._use_pqc:
            try:
                from cryptography.hazmat.primitives.asymmetric.kyber import (
                    MLKEM768PrivateKey,
                )
                private_key = MLKEM768PrivateKey.generate()
                public_key = private_key.public_key()
                private_bytes = private_key.private_bytes_raw()
                public_bytes = public_key.public_bytes_raw()
                return private_bytes, public_bytes
            except Exception:
                pass
        # 回退到 X25519
        return self._fallback.generate_keypair()

    def encapsulate(self, public_key_bytes: bytes) -> Tuple[bytes, bytes]:
        """
        Kyber 封装: 使用对端公钥生成共享密钥和密文

        Returns:
            (ciphertext, shared_secret)
        """
        if self._use_pqc:
            try:
                from cryptography.hazmat.primitives.asymmetric.kyber import (
                    MLKEM768PublicKey,
                )
                public_key = MLKEM768PublicKey.from_public_bytes(public_key_bytes)
                ciphertext, shared_secret = public_key.encapsulate()
                return ciphertext, shared_secret
            except Exception:
                pass
        # 回退: X25519 + HKDF
        # 注意: 当 Kyber 不可用时，public_key_bytes 应为 X25519 公钥 (32字节)
        # 如果传入的是 Kyber 公钥格式，调用方需要提供正确的 X25519 公钥
        if len(public_key_bytes) != 32:
            raise ValueError(
                f"Kyber unavailable, fallback requires X25519 public key (32 bytes), "
                f"got {len(public_key_bytes)} bytes. Please provide a valid X25519 public key."
            )
        ephemeral_private, ephemeral_public = self._fallback.generate_keypair()
        shared_secret = self._fallback.compute_shared_secret(ephemeral_private, public_key_bytes)
        session_key = self._fallback.derive_session_key(shared_secret)
        return ephemeral_public, session_key

    def decapsulate(self, private_key_bytes: bytes, ciphertext: bytes) -> bytes:
        """
        Kyber 解封装: 使用私钥从密文恢复共享密钥
        
        注意: 当 Kyber 不可用时，回退模式需要:
        - private_key_bytes: X25519 私钥 (32字节)
        - ciphertext: X25519 公钥 (32字节，来自封装时的 ephemeral_public)
        """
        if self._use_pqc:
            try:
                from cryptography.hazmat.primitives.asymmetric.kyber import (
                    MLKEM768PrivateKey,
                )
                private_key = MLKEM768PrivateKey.from_private_bytes(private_key_bytes)
                shared_secret = private_key.decapsulate(ciphertext)
                return shared_secret
            except Exception:
                pass
        # 回退: X25519
        # 注意: ciphertext 在回退模式下应为封装时生成的 ephemeral_public (32字节)
        if len(ciphertext) != 32:
            raise ValueError(
                f"Kyber unavailable, fallback requires X25519 ephemeral public key (32 bytes), "
                f"got {len(ciphertext)} bytes. The ciphertext from encapsulate() should be used."
            )
        return self._fallback.compute_shared_secret(private_key_bytes, ciphertext)

    def compute_shared_secret(self, private_key_bytes: bytes, peer_public_key_bytes: bytes) -> bytes:
        """计算共享密钥 (兼容接口)"""
        _, shared = self.encapsulate(peer_public_key_bytes)
        return shared

    def derive_session_key(self, shared_secret, salt=None, info=None, length=32):
        """从共享密钥派生会话密钥"""
        return self._fallback.derive_session_key(shared_secret, salt, info, length)

    def hybrid_handshake(self, peer_public_key_bytes: bytes) -> Tuple[bytes, bytes, bytes]:
        """
        混合握手: Kyber + X25519 双重保护

        同时使用后量子和经典密钥交换，任一算法安全即可保证整体安全。
        
        Args:
            peer_public_key_bytes: 对端的公钥 (用于封装)
                - 当 Kyber 可用时: 应为 Kyber 公钥
                - 当 Kyber 不可用时: 应为 X25519 公钥 (32字节)
        
        Returns:
            (my_public_key, session_key, combined_secret)
            - my_public_key: 本地生成的公钥，用于发送给对端
            - session_key: 派生的会话密钥
            - combined_secret: 组合共享密钥 (用于审计)
        """
        # X25519 交换 (始终执行)
        x25519_public, x25519_session, x25519_shared = self._fallback.full_handshake(peer_public_key_bytes)
        
        if self._use_pqc:
            try:
                # Kyber 封装 - 使用对端公钥
                kyber_ciphertext, kyber_shared = self.encapsulate(peer_public_key_bytes)
                # 组合共享密钥: HKDF(Kyber_shared || X25519_shared)
                combined = kyber_shared + x25519_shared
                session_key = self.derive_session_key(
                    combined,
                    info=self._info + b":hybrid"
                )
                # 返回 Kyber 密文作为 "公钥" (对端需要用私钥解封装)
                return kyber_ciphertext, session_key, combined
            except Exception:
                pass
        
        # 回退: 仅使用 X25519
        logger.warning("Kyber unavailable, hybrid handshake using X25519 only")
        session_key = self.derive_session_key(
            x25519_shared,
            info=self._info + b":x25519-only"
        )
        return x25519_public, session_key, x25519_shared
