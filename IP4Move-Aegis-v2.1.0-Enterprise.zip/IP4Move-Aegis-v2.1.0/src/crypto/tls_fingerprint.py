"""
动态TLS指纹生成模块

生成随机化的 TLS ClientHello 指纹，模拟常见浏览器行为。
"""

import os
import struct
import random
import hashlib
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field


# 常见浏览器 TLS 指纹模板
BROWSER_PROFILES = {
    "chrome_120": {
        "version": "TLS 1.3",
        "cipher_suites": [
            0x1301, 0x1302, 0x1303,  # TLS_AES_128_GCM_SHA256, TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256
            0xC02C, 0xC02B,          # TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384, TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256
            0xC030, 0xC02F,          # TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384, TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256
            0xCCA9, 0xCCA8,          # TLS_ECDHE_CHACHA20_POLY1305_SHA256
            0xC013, 0xC014,          # TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA, TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA
            0x009C, 0x009D,          # TLS_RSA_WITH_AES_128_GCM_SHA256, TLS_RSA_WITH_AES_256_GCM_SHA384
        ],
        "extensions": [
            0x0000,  # server_name
            0x0017,  # extended_master_secret
            0xFF01,  # renegotiation_info
            0x0010,  # supported_groups
            0x000D,  # signature_algorithms
            0x0016,  # application_layer_protocol_negotiation
            0x0023,  # session_ticket
            0x002B,  # compress_certificate
            0x002D,  # psk_key_exchange_modes
            0x0033,  # key_share
            0x001B,  # padding
            0x0029,  # pre_shared_key
            0x0015,  # padding (old)
        ],
        "supported_groups": [0x001D, 0x0017, 0x0018],  # x25519, secp256r1, secp384r1
        "sig_algorithms": [
            0x0804, 0x0805, 0x0806,  # ecdsa_secp256r1_sha256, ecdsa_secp384r1_sha384, ecdsa_secp521r1_sha512
            0x0401, 0x0501, 0x0601,  # rsa_pss_rsae_sha256, rsa_pss_rsae_sha384, rsa_pss_rsae_sha512
            0x0201, 0x0403, 0x0503,  # rsa_pkcs1_sha256, ecdsa_secp256r1_sha256, ecdsa_secp384r1_sha384
        ],
        "alpn_protocols": [b"h2", b"http/1.1"],
        "compression_methods": [0x00],  # null
    },
    "firefox_121": {
        "version": "TLS 1.3",
        "cipher_suites": [
            0x1301, 0x1302, 0x1303,
            0xC02C, 0xC02B,
            0xC030, 0xC02F,
            0xCCA9, 0xCCA8,
            0xC013, 0xC014,
            0x009C, 0x009D,
        ],
        "extensions": [
            0x0000, 0x0017, 0xFF01, 0x0010, 0x000D,
            0x0016, 0x0023, 0x002D, 0x0033, 0x001B,
        ],
        "supported_groups": [0x001D, 0x0017, 0x0018],
        "sig_algorithms": [
            0x0804, 0x0805, 0x0806,
            0x0401, 0x0501, 0x0601,
            0x0201, 0x0403, 0x0503,
        ],
        "alpn_protocols": [b"h2", b"http/1.1"],
        "compression_methods": [0x00],
    },
    "safari_17": {
        "version": "TLS 1.3",
        "cipher_suites": [
            0x1301, 0x1302, 0x1303,
            0xC02C, 0xC02B,
            0xC030, 0xC02F,
            0xC013, 0xC014,
            0x009C, 0x009D,
        ],
        "extensions": [
            0x0000, 0x0017, 0xFF01, 0x0010, 0x000D,
            0x0016, 0x0023, 0x002D, 0x0033,
        ],
        "supported_groups": [0x001D, 0x0017, 0x0018],
        "sig_algorithms": [
            0x0804, 0x0805, 0x0806,
            0x0401, 0x0501, 0x0601,
            0x0201,
        ],
        "alpn_protocols": [b"h2", b"http/1.1"],
        "compression_methods": [0x00],
    },
}


@dataclass
class TLSFingerprint:
    """TLS 指纹数据"""

    ja3_hash: str
    ja4_hash: str
    cipher_suites: List[int]
    extensions: List[int]
    supported_groups: List[int]
    sig_algorithms: List[int]
    alpn_protocols: List[bytes]
    tls_version: str
    raw_client_hello: bytes


class TLSFingerprintGenerator:
    """
    动态 TLS 指纹生成器

    - 每连接生成唯一 TLS 指纹
    - 支持模拟常见浏览器指纹
    - 随机化 ClientHello 参数
    - 计算 JA3/JA4 指纹哈希
    """

    def __init__(self, seed: Optional[int] = None):
        self._rng = random.Random(seed)
        self._profiles = list(BROWSER_PROFILES.values())

    def generate(
        self,
        profile_name: Optional[str] = None,
        randomize: bool = True,
    ) -> TLSFingerprint:
        """
        生成 TLS 指纹

        Args:
            profile_name: 浏览器配置名称 (chrome_120, firefox_121, safari_17)
                         为 None 时随机选择
            randomize: 是否对配置进行随机化

        Returns:
            TLSFingerprint 实例
        """
        # 选择配置
        if profile_name and profile_name in BROWSER_PROFILES:
            profile = BROWSER_PROFILES[profile_name]
        else:
            profile = self._rng.choice(self._profiles)

        cipher_suites = list(profile["cipher_suites"])
        extensions = list(profile["extensions"])
        supported_groups = list(profile["supported_groups"])
        sig_algorithms = list(profile["sig_algorithms"])
        alpn_protocols = list(profile["alpn_protocols"])

        if randomize:
            cipher_suites = self._randomize_cipher_suites(cipher_suites)
            extensions = self._randomize_extensions(extensions)
            supported_groups = self._randomize_order(supported_groups)
            sig_algorithms = self._randomize_order(sig_algorithms)
            # 抗AI: 注入随机扩展和密码套件，确保每次生成唯一指纹
            extra_suites = [0x1301 + self._rng.randint(0, 5), 0xC0A0 + self._rng.randint(0, 10)]
            cipher_suites = list(set(cipher_suites + extra_suites))
            self._rng.shuffle(cipher_suites)
            # 随机修改 ALPN 顺序
            if alpn_protocols and self._rng.random() < 0.3:
                self._rng.shuffle(alpn_protocols)

        # 构建 ClientHello
        client_hello = self._build_client_hello(
            cipher_suites=cipher_suites,
            extensions=extensions,
            supported_groups=supported_groups,
            sig_algorithms=sig_algorithms,
            alpn_protocols=alpn_protocols,
            compression_methods=profile["compression_methods"],
            tls_version=profile["version"],
        )

        # 计算 JA3/JA4 哈希
        ja3_str = self._compute_ja3(
            tls_version=profile["version"],
            cipher_suites=cipher_suites,
            extensions=extensions,
            supported_groups=supported_groups,
            sig_algorithms=sig_algorithms,
        )
        ja3_hash = hashlib.md5(ja3_str.encode()).hexdigest()
        ja4_hash = self._compute_ja4(
            tls_version=profile["version"],
            cipher_suites=cipher_suites,
            extensions=extensions,
            sig_algorithms=sig_algorithms,
        )

        return TLSFingerprint(
            ja3_hash=ja3_hash,
            ja4_hash=ja4_hash,
            cipher_suites=cipher_suites,
            extensions=extensions,
            supported_groups=supported_groups,
            sig_algorithms=sig_algorithms,
            alpn_protocols=alpn_protocols,
            tls_version=profile["version"],
            raw_client_hello=client_hello,
        )

    def _randomize_cipher_suites(self, suites: List[int]) -> List[int]:
        """
        随机化密码套件顺序

        保持前3个为 TLS 1.3 套件(安全优先)，其余随机排列。
        """
        tls13_suites = [s for s in suites if s >= 0x1300]
        other_suites = [s for s in suites if s < 0x1300]
        self._rng.shuffle(other_suites)
        # 随机选择是否保留所有 TLS 1.3 套件
        if len(tls13_suites) > 1 and self._rng.random() < 0.3:
            self._rng.shuffle(tls13_suites)
        return tls13_suites + other_suites

    def _randomize_extensions(self, extensions: List[int]) -> List[int]:
        """
        随机化扩展字段顺序

        保持关键扩展在前(server_name, supported_groups)，
        其余随机排列。
        """
        critical = [0x0000, 0x0010, 0x0033, 0x002D]  # SNI, groups, key_share, psk_modes
        critical_present = [e for e in extensions if e in critical]
        others = [e for e in extensions if e not in critical]
        self._rng.shuffle(others)
        # 随机决定是否添加额外扩展
        extra_extensions = [0x0015, 0x002B, 0x001B, 0x0029, 0x0023]
        for ext in extra_extensions:
            if ext not in others and self._rng.random() < 0.5:
                others.append(ext)
        self._rng.shuffle(others)
        return critical_present + others

    def _randomize_order(self, items: List) -> List:
        """随机排列列表"""
        result = list(items)
        self._rng.shuffle(result)
        return result

    def _build_client_hello(
        self,
        cipher_suites: List[int],
        extensions: List[int],
        supported_groups: List[int],
        sig_algorithms: List[int],
        alpn_protocols: List[bytes],
        compression_methods: List[int],
        tls_version: str,
    ) -> bytes:
        """
        构建 TLS ClientHello 报文

        Returns:
            完整的 ClientHello 字节序列
        """
        # ClientHello 版本 (TLS 1.2 for compatibility)
        version = b"\x03\x03"
        # 随机 32 字节
        random_bytes = os.urandom(32)
        # Session ID (空)
        session_id = b"\x00"
        # 密码套件
        cipher_suites_bytes = struct.pack("!H", len(cipher_suites) * 2)
        for cs in cipher_suites:
            cipher_suites_bytes += struct.pack("!H", cs)
        # 压缩方法
        compression_bytes = struct.pack("!B", len(compression_methods))
        for cm in compression_methods:
            compression_bytes += struct.pack("!B", cm)
        # 扩展
        extensions_bytes = self._build_extensions(
            extensions, supported_groups, sig_algorithms, alpn_protocols
        )
        extensions_length = struct.pack("!H", len(extensions_bytes))
        # 组装
        hello_body = (
            version
            + random_bytes
            + session_id
            + cipher_suites_bytes
            + compression_bytes
            + extensions_length
            + extensions_bytes
        )
        # Handshake 头
        handshake_type = b"\x01"  # ClientHello
        handshake_length = struct.pack("!I", len(hello_body))[1:]  # 3字节长度
        # Record 头
        record_type = b"\x16"  # Handshake
        record_version = b"\x03\x01"  # TLS 1.0
        record_length = struct.pack("!H", 1 + 3 + len(hello_body))
        return record_type + record_version + record_length + handshake_type + handshake_length + hello_body

    def _build_extensions(
        self,
        extensions: List[int],
        supported_groups: List[int],
        sig_algorithms: List[int],
        alpn_protocols: List[bytes],
    ) -> bytes:
        """构建 TLS 扩展块"""
        ext_data = b""
        for ext_type in extensions:
            ext_body = b""
            if ext_type == 0x0010:  # supported_groups
                groups_bytes = struct.pack("!H", len(supported_groups) * 2)
                for g in supported_groups:
                    groups_bytes += struct.pack("!H", g)
                ext_body = groups_bytes
            elif ext_type == 0x000D:  # signature_algorithms
                sig_bytes = struct.pack("!H", len(sig_algorithms) * 2)
                for sa in sig_algorithms:
                    sig_bytes += struct.pack("!H", sa)
                ext_body = sig_bytes
            elif ext_type == 0x0016:  # ALPN
                alpn_data = b""
                for proto in alpn_protocols:
                    alpn_data += struct.pack("!B", len(proto)) + proto
                ext_body = struct.pack("!H", len(alpn_data)) + alpn_data
            elif ext_type == 0x0000:  # SNI
                hostname = os.urandom(8).hex() + ".example.com"
                hostname_bytes = hostname.encode()
                sni_data = struct.pack("!B", 0)  # host_name type
                sni_data += struct.pack("!H", len(hostname_bytes)) + hostname_bytes
                ext_body = struct.pack("!H", len(sni_data)) + sni_data
            else:
                ext_body = os.urandom(self._rng.randint(0, 16))
            ext_data += struct.pack("!HH", ext_type, len(ext_body)) + ext_body
        return ext_data

    def _compute_ja3(
        self,
        tls_version: str,
        cipher_suites: List[int],
        extensions: List[int],
        supported_groups: List[int],
        sig_algorithms: List[int],
    ) -> str:
        """计算 JA3 指纹字符串"""
        version_map = {"TLS 1.3": "771", "TLS 1.2": "771", "TLS 1.1": "770", "TLS 1.0": "769"}
        version_str = version_map.get(tls_version, "771")
        cipher_str = "-".join(str(c) for c in cipher_suites)
        ext_str = "-".join(str(e) for e in sorted(extensions))
        groups_str = "-".join(str(g) for g in supported_groups)
        sig_str = "-".join(str(s) for s in sig_algorithms)
        return f"{version_str},{cipher_str},{ext_str},{groups_str},{sig_str}"

    def _compute_ja4(
        self,
        tls_version: str,
        cipher_suites: List[int],
        extensions: List[int],
        sig_algorithms: List[int],
    ) -> str:
        """
        计算 JA4 指纹哈希

        JA4 格式: tt-ff-pppp-rrrr-cccc-ffff
        """
        # TLS 版本
        tls_map = {"TLS 1.3": "13", "TLS 1.2": "12", "TLS 1.1": "11", "TLS 1.0": "10"}
        tt = tls_map.get(tls_version, "12")
        # 是否可接受 TLS 1.3
        has_tls13 = any(c >= 0x1300 for c in cipher_suites)
        ff = "d" if has_tls13 else "i"
        # 密码套件计数
        pp = f"{len(cipher_suites):04d}"
        # 扩展计数
        rr = f"{len(extensions):04d}"
        # 前4个密码套件
        cc = "-".join(f"{c:04x}" for c in cipher_suites[:4])
        # 前4个扩展
        ee = "-".join(f"{e:04x}" for e in sorted(extensions)[:4])
        ja4_raw = f"t{tt}{ff}-{pp}-{rr}-{cc}-{ee}"
        return hashlib.sha256(ja4_raw.encode()).hexdigest()[:32]

    def generate_pool(self, size: int = 10) -> List[TLSFingerprint]:
        """
        生成指纹池

        Args:
            size: 池大小

        Returns:
            TLS 指纹列表
        """
        return [self.generate() for _ in range(size)]

    def generate_pqc_fingerprint(self) -> TLSFingerprint:
        """
        生成兼容 Kyber 密钥交换的 TLS 指纹

        在 supported_groups 中添加 Kyber 相关组，
        在扩展中添加 post_quantum_key_exchange 扩展。
        """
        profile = self._rng.choice(self._profiles)

        cipher_suites = list(profile["cipher_suites"])
        extensions = list(profile["extensions"])
        supported_groups = list(profile["supported_groups"])
        sig_algorithms = list(profile["sig_algorithms"])
        alpn_protocols = list(profile["alpn_protocols"])

        # 添加 Kyber 密钥交换组 (0x0020 = kyber512, 0x0021 = kyber768)
        pqc_groups = [0x0020, 0x0021]
        supported_groups = pqc_groups + supported_groups

        # 添加后量子密钥交换扩展 (0x002E)
        if 0x002E not in extensions:
            extensions.append(0x002E)

        # 随机化
        cipher_suites = self._randomize_cipher_suites(cipher_suites)
        extensions = self._randomize_extensions(extensions)

        client_hello = self._build_client_hello(
            cipher_suites=cipher_suites,
            extensions=extensions,
            supported_groups=supported_groups,
            sig_algorithms=sig_algorithms,
            alpn_protocols=alpn_protocols,
            compression_methods=profile["compression_methods"],
            tls_version=profile["version"],
        )

        ja3_str = self._compute_ja3(
            tls_version=profile["version"],
            cipher_suites=cipher_suites,
            extensions=extensions,
            supported_groups=supported_groups,
            sig_algorithms=sig_algorithms,
        )
        ja3_hash = hashlib.md5(ja3_str.encode()).hexdigest()
        ja4_hash = self._compute_ja4(
            tls_version=profile["version"],
            cipher_suites=cipher_suites,
            extensions=extensions,
            sig_algorithms=sig_algorithms,
        )

        return TLSFingerprint(
            ja3_hash=ja3_hash,
            ja4_hash=ja4_hash,
            cipher_suites=cipher_suites,
            extensions=extensions,
            supported_groups=supported_groups,
            sig_algorithms=sig_algorithms,
            alpn_protocols=alpn_protocols,
            tls_version=profile["version"],
            raw_client_hello=client_hello,
        )
