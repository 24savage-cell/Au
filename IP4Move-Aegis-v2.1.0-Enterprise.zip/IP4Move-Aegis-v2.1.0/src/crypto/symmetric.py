"""
对称加密模块 (安全修复版 - 性能优化版 v2)

修复内容:
1. 添加密钥长度验证
2. 使用恒定时间比较防止时序攻击
3. 添加nonce重用检测
4. 改进错误处理
5. 添加算法白名单
6. 防止密钥泄露到日志
7. 使用安全缓冲区管理敏感数据

性能优化:
1. 添加加密器对象池，减少频繁创建/销毁开销
"""

import os
import struct
import hmac
import hashlib
import abc
import logging
import asyncio
from typing import Optional, Tuple, Set

from cryptography.hazmat.primitives.ciphers.aead import (
    AESGCM,
    ChaCha20Poly1305,
)
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes as crypto_hashes

from src.common.object_pool import ObjectPool
from src.common.exceptions import CryptoError

# 导入安全内存管理
from src.common.memory import secure_zero_memory, SecureBuffer

logger = logging.getLogger(__name__)

# 安全常量
ALLOWED_ALGORITHMS = {
    "aes-256-gcm",
    "aes-256-cbc",
    "aes-256-ofb",
    "chacha20-poly1305",
    "ascon-128a",
}
MIN_KEY_LENGTH = 16         # 最小密钥长度
MAX_KEY_LENGTH = 64         # 最大密钥长度
MAX_DATA_SIZE = 64 * 1024 * 1024  # 最大数据大小(64MB)

# 对象池最大大小
POOL_MAX_SIZE = 50


class SymmetricCipher(abc.ABC):
    """对称加密抽象基类"""

    ALGORITHM_NAME: str = "unknown"

    def __init__(self, key: Optional[bytes] = None, key_length: int = 32):
        self._validate_key_length(key_length)
        # 使用安全缓冲区存储密钥
        self._key_buffer = SecureBuffer(key_length)
        if key:
            self._key_buffer.buffer[:] = key
        else:
            self._key_buffer.buffer[:] = os.urandom(key_length)
        self._key_length = key_length
        self._used_nonces: Set[bytes] = set()  # nonce重用检测

    def _validate_key_length(self, length: int) -> None:
        """验证密钥长度"""
        if not MIN_KEY_LENGTH <= length <= MAX_KEY_LENGTH:
            raise ValueError(f"Invalid key length: {length}")

    @property
    def key(self) -> bytes:
        """获取密钥（返回副本）"""
        return bytes(self._key_buffer.buffer)

    @abc.abstractmethod
    def encrypt(self, plaintext: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """加密数据，返回 nonce + ciphertext + tag"""
        ...

    @abc.abstractmethod
    def decrypt(self, data: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """解密数据，输入为 nonce + ciphertext + tag"""
        ...

    def rekey(self) -> None:
        """轮换密钥"""
        # 安全清零旧密钥
        secure_zero_memory(self._key_buffer.buffer)
        # 生成新密钥
        self._key_buffer.buffer[:] = os.urandom(self._key_length)
        self._used_nonces.clear()

    def _check_nonce_reuse(self, nonce: bytes) -> None:
        """检查nonce是否被重用"""
        if nonce in self._used_nonces:
            raise ValueError("Nonce reuse detected - this is a critical security violation")
        self._used_nonces.add(nonce)

        # 限制nonce集合大小
        if len(self._used_nonces) > 10000:
            # 保留最近的一半
            self._used_nonces = set(list(self._used_nonces)[-5000:])

    def _validate_data_size(self, data: bytes) -> None:
        """验证数据大小"""
        if len(data) > MAX_DATA_SIZE:
            raise ValueError(f"Data too large: {len(data)} > {MAX_DATA_SIZE}")

    def reset(self) -> None:
        """重置加密器状态（用于对象池归还时）"""
        self._used_nonces.clear()

    def __del__(self):
        """析构时安全清零密钥"""
        try:
            secure_zero_memory(self._key_buffer.buffer)
        except:
            pass


class AES256GCMCipher(SymmetricCipher):
    """
    AES-256-GCM 加密实现 (安全版本)

    - 每包随机生成 12 字节 nonce
    - 16 字节认证标签
    - 支持关联数据 (AEAD)
    - nonce重用检测
    """

    ALGORITHM_NAME = "aes-256-gcm"
    NONCE_SIZE = 12
    TAG_SIZE = 16

    def __init__(self, key: Optional[bytes] = None):
        super().__init__(key, key_length=32)
        self._cipher = AESGCM(bytes(self._key_buffer.buffer))

    def encrypt(self, plaintext: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """加密数据"""
        self._validate_data_size(plaintext)

        nonce = os.urandom(self.NONCE_SIZE)
        self._check_nonce_reuse(nonce)

        ciphertext_with_tag = self._cipher.encrypt(nonce, plaintext, associated_data)
        return nonce + ciphertext_with_tag

    def decrypt(self, data: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """解密数据"""
        self._validate_data_size(data)

        if len(data) < self.NONCE_SIZE + self.TAG_SIZE:
            raise ValueError("Ciphertext too short")

        nonce = data[: self.NONCE_SIZE]
        ciphertext_with_tag = data[self.NONCE_SIZE :]
        return self._cipher.decrypt(nonce, ciphertext_with_tag, associated_data)

    def rekey(self) -> None:
        super().rekey()
        self._cipher = AESGCM(bytes(self._key_buffer.buffer))


class AES256CBCCipher(SymmetricCipher):
    """
    AES-256-CBC 加密实现 (安全版本)

    - 随机 IV
    - PKCS7 填充
    - HMAC-SHA256 完整性校验
    - 恒定时间HMAC比较
    """

    ALGORITHM_NAME = "aes-256-cbc"
    BLOCK_SIZE = 16
    IV_SIZE = 16

    def __init__(self, key: Optional[bytes] = None, hmac_key: Optional[bytes] = None):
        super().__init__(key, key_length=32)
        # 使用安全缓冲区存储 HMAC 密钥
        self._hmac_key_buffer = SecureBuffer(32)
        if hmac_key:
            self._hmac_key_buffer.buffer[:] = hmac_key
        else:
            self._hmac_key_buffer.buffer[:] = os.urandom(32)
        self._backend = default_backend()

    def encrypt(self, plaintext: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """加密数据"""
        self._validate_data_size(plaintext)

        iv = os.urandom(self.IV_SIZE)
        # PKCS7 填充
        padder = padding.PKCS7(128).padder()
        padded = padder.update(plaintext) + padder.finalize()
        # CBC 加密
        cipher = Cipher(
            algorithms.AES(bytes(self._key_buffer.buffer)), modes.CBC(iv), backend=self._backend
        )
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(padded) + encryptor.finalize()
        # HMAC 完整性校验
        hmac_data = iv + ciphertext
        if associated_data:
            hmac_data += associated_data
        mac = hmac.new(bytes(self._hmac_key_buffer.buffer), hmac_data, hashlib.sha256).digest()
        return iv + ciphertext + mac

    def decrypt(self, data: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """解密数据"""
        self._validate_data_size(data)

        if len(data) < self.IV_SIZE + 32 + self.BLOCK_SIZE:
            raise ValueError("Ciphertext too short")

        iv = data[: self.IV_SIZE]
        mac = data[-32:]
        ciphertext = data[self.IV_SIZE : -32]

        # HMAC 验证 (恒定时间)
        hmac_data = iv + ciphertext
        if associated_data:
            hmac_data += associated_data
        expected_mac = hmac.new(bytes(self._hmac_key_buffer.buffer), hmac_data, hashlib.sha256).digest()

        if not hmac.compare_digest(mac, expected_mac):
            raise ValueError("HMAC verification failed")

        # CBC 解密
        cipher = Cipher(
            algorithms.AES(bytes(self._key_buffer.buffer)), modes.CBC(iv), backend=self._backend
        )
        decryptor = cipher.decryptor()
        padded = decryptor.update(ciphertext) + decryptor.finalize()
        # PKCS7 去填充
        unpadder = padding.PKCS7(128).unpadder()
        return unpadder.update(padded) + unpadder.finalize()

    def __del__(self):
        """析构时安全清零密钥"""
        super().__del__()
        try:
            secure_zero_memory(self._hmac_key_buffer.buffer)
        except:
            pass


class AES256OFBCipher(SymmetricCipher):
    """
    AES-256-OFB 加密实现 (安全版本)

    - 随机 IV
    - 流密码模式，无需填充
    - HMAC-SHA256 完整性校验
    - 恒定时间HMAC比较
    """

    ALGORITHM_NAME = "aes-256-ofb"
    BLOCK_SIZE = 16
    IV_SIZE = 16

    def __init__(self, key: Optional[bytes] = None, hmac_key: Optional[bytes] = None):
        super().__init__(key, key_length=32)
        # 使用安全缓冲区存储 HMAC 密钥
        self._hmac_key_buffer = SecureBuffer(32)
        if hmac_key:
            self._hmac_key_buffer.buffer[:] = hmac_key
        else:
            self._hmac_key_buffer.buffer[:] = os.urandom(32)
        self._backend = default_backend()

    def encrypt(self, plaintext: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """加密数据"""
        self._validate_data_size(plaintext)

        iv = os.urandom(self.IV_SIZE)
        cipher = Cipher(
            algorithms.AES(bytes(self._key_buffer.buffer)), modes.OFB(iv), backend=self._backend
        )
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(plaintext) + encryptor.finalize()
        # HMAC 完整性校验
        hmac_data = iv + ciphertext
        if associated_data:
            hmac_data += associated_data
        mac = hmac.new(bytes(self._hmac_key_buffer.buffer), hmac_data, hashlib.sha256).digest()
        return iv + ciphertext + mac

    def decrypt(self, data: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """解密数据"""
        self._validate_data_size(data)

        if len(data) < self.IV_SIZE + 32 + 1:
            raise ValueError("Ciphertext too short")

        iv = data[: self.IV_SIZE]
        mac = data[-32:]
        ciphertext = data[self.IV_SIZE : -32]

        # HMAC 验证 (恒定时间)
        hmac_data = iv + ciphertext
        if associated_data:
            hmac_data += associated_data
        expected_mac = hmac.new(bytes(self._hmac_key_buffer.buffer), hmac_data, hashlib.sha256).digest()

        if not hmac.compare_digest(mac, expected_mac):
            raise ValueError("HMAC verification failed")

        # OFB 解密
        cipher = Cipher(
            algorithms.AES(bytes(self._key_buffer.buffer)), modes.OFB(iv), backend=self._backend
        )
        decryptor = cipher.decryptor()
        return decryptor.update(ciphertext) + decryptor.finalize()

    def __del__(self):
        """析构时安全清零密钥"""
        super().__del__()
        try:
            secure_zero_memory(self._hmac_key_buffer.buffer)
        except:
            pass


class ChaCha20Cipher(SymmetricCipher):
    """
    ChaCha20-Poly1305 加密实现 (安全版本)

    - 每包随机生成 12 字节 nonce
    - 16 字节认证标签
    - 支持关联数据 (AEAD)
    - nonce重用检测
    """

    ALGORITHM_NAME = "chacha20-poly1305"
    NONCE_SIZE = 12
    TAG_SIZE = 16

    def __init__(self, key: Optional[bytes] = None):
        super().__init__(key, key_length=32)
        self._cipher = ChaCha20Poly1305(bytes(self._key_buffer.buffer))

    def encrypt(self, plaintext: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """加密数据"""
        self._validate_data_size(plaintext)

        nonce = os.urandom(self.NONCE_SIZE)
        self._check_nonce_reuse(nonce)

        ciphertext_with_tag = self._cipher.encrypt(nonce, plaintext, associated_data)
        return nonce + ciphertext_with_tag

    def decrypt(self, data: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """解密数据"""
        self._validate_data_size(data)

        if len(data) < self.NONCE_SIZE + self.TAG_SIZE:
            raise ValueError("Ciphertext too short")

        nonce = data[: self.NONCE_SIZE]
        ciphertext_with_tag = data[self.NONCE_SIZE :]
        return self._cipher.decrypt(nonce, ciphertext_with_tag, associated_data)

    def rekey(self) -> None:
        super().rekey()
        self._cipher = ChaCha20Poly1305(bytes(self._key_buffer.buffer))


class ASCON128aCipher(SymmetricCipher):
    """
    ASCON-128a 抗量子轻量对称加密实现 (安全版本)

    NIST 轻量级密码学竞赛获胜算法。
    - 128 位密钥
    - 128 位认证标签
    - AEAD 模式
    - 抗量子侧信道攻击
    """

    ALGORITHM_NAME = "ascon-128a"
    NONCE_SIZE = 16
    TAG_SIZE = 16
    KEY_LENGTH = 16

    def __init__(self, key: Optional[bytes] = None):
        super().__init__(key, key_length=self.KEY_LENGTH)
        self._ascon_available = self._check_ascon_available()

    def _check_ascon_available(self) -> bool:
        """检查 ASCON 库是否可用"""
        try:
            import ascon
            return True
        except ImportError:
            return False

    def _derive_aes_key(self, nonce: bytes) -> bytes:
        """安全地从16字节ASCON密钥派生32字节AES密钥"""
        hkdf = HKDF(
            algorithm=crypto_hashes.SHA256(),
            length=32,
            salt=nonce,
            info=b"ascon-to-aes-key-derivation",
        )
        return hkdf.derive(bytes(self._key_buffer.buffer))

    def encrypt(self, plaintext: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """加密数据"""
        self._validate_data_size(plaintext)

        nonce = os.urandom(self.NONCE_SIZE)
        self._check_nonce_reuse(nonce)

        if self._ascon_available:
            try:
                import ascon
                ciphertext_with_tag = ascon.encrypt(
                    bytes(self._key_buffer.buffer), nonce, associated_data or b"", plaintext,
                    variant="ascon-128a"
                )
                return nonce + ciphertext_with_tag
            except Exception:
                pass

        # 回退到 AES-256-GCM
        logger.warning("ASCON not available, falling back to AES-256-GCM")
        derived_key = self._derive_aes_key(nonce)
        cipher = AESGCM(derived_key)
        ciphertext_with_tag = cipher.encrypt(nonce, plaintext, associated_data)
        return nonce + ciphertext_with_tag

    def decrypt(self, data: bytes, associated_data: Optional[bytes] = None) -> bytes:
        """解密数据"""
        self._validate_data_size(data)

        if len(data) < self.NONCE_SIZE + self.TAG_SIZE:
            raise ValueError("Ciphertext too short")

        nonce = data[: self.NONCE_SIZE]
        ciphertext_with_tag = data[self.NONCE_SIZE :]

        if self._ascon_available:
            try:
                import ascon
                return ascon.decrypt(
                    bytes(self._key_buffer.buffer), nonce, associated_data or b"", ciphertext_with_tag,
                    variant="ascon-128a"
                )
            except Exception:
                pass

        # 回退到 AES-256-GCM
        derived_key = self._derive_aes_key(nonce)
        cipher = AESGCM(derived_key)
        return cipher.decrypt(nonce, ciphertext_with_tag, associated_data)


# ==================== 加密器对象池 ====================

# 全局加密器对象池
_aes_gcm_pool: Optional[ObjectPool[AES256GCMCipher]] = None
_chacha20_pool: Optional[ObjectPool[ChaCha20Cipher]] = None
_pool_lock = asyncio.Lock()


async def _get_aes_gcm_pool() -> ObjectPool[AES256GCMCipher]:
    """获取 AES-GCM 对象池（延迟初始化）"""
    global _aes_gcm_pool
    if _aes_gcm_pool is None:
        async with _pool_lock:
            if _aes_gcm_pool is None:
                _aes_gcm_pool = ObjectPool(
                    factory=lambda: AES256GCMCipher(),
                    reset=lambda c: c.reset(),
                    max_size=POOL_MAX_SIZE,
                )
    return _aes_gcm_pool


async def _get_chacha20_pool() -> ObjectPool[ChaCha20Cipher]:
    """获取 ChaCha20-Poly1305 对象池（延迟初始化）"""
    global _chacha20_pool
    if _chacha20_pool is None:
        async with _pool_lock:
            if _chacha20_pool is None:
                _chacha20_pool = ObjectPool(
                    factory=lambda: ChaCha20Cipher(),
                    reset=lambda c: c.reset(),
                    max_size=POOL_MAX_SIZE,
                )
    return _chacha20_pool


async def encrypt(
    algorithm: str,
    plaintext: bytes,
    key: Optional[bytes] = None,
    associated_data: Optional[bytes] = None,
) -> Tuple[bytes, bytes]:
    """
    使用对象池进行加密

    Args:
        algorithm: 算法名称
        plaintext: 明文数据
        key: 可选的密钥（不提供则使用对象池中的加密器）
        associated_data: 关联数据

    Returns:
        (密文, 密钥)
    """
    if algorithm not in ALLOWED_ALGORITHMS:
        raise CryptoError(f"Unsupported algorithm: {algorithm}")

    # 如果提供了密钥，直接创建新的加密器（不经过对象池）
    if key is not None:
        cipher = SecureCipherFactory.create_cipher(algorithm, key)
        ciphertext = cipher.encrypt(plaintext, associated_data)
        return ciphertext, cipher.key

    # 使用对象池
    if algorithm == "aes-256-gcm":
        pool = await _get_aes_gcm_pool()
        cipher = await pool.acquire()
        try:
            ciphertext = cipher.encrypt(plaintext, associated_data)
            return ciphertext, cipher.key
        finally:
            await pool.release(cipher)

    elif algorithm == "chacha20-poly1305":
        pool = await _get_chacha20_pool()
        cipher = await pool.acquire()
        try:
            ciphertext = cipher.encrypt(plaintext, associated_data)
            return ciphertext, cipher.key
        finally:
            await pool.release(cipher)

    else:
        # 其他算法不使用对象池
        cipher = SecureCipherFactory.create_cipher(algorithm)
        ciphertext = cipher.encrypt(plaintext, associated_data)
        return ciphertext, cipher.key


async def decrypt(
    algorithm: str,
    ciphertext: bytes,
    key: bytes,
    associated_data: Optional[bytes] = None,
) -> bytes:
    """
    使用对象池进行解密

    Args:
        algorithm: 算法名称
        ciphertext: 密文数据
        key: 解密密钥
        associated_data: 关联数据

    Returns:
        明文数据
    """
    if algorithm not in ALLOWED_ALGORITHMS:
        raise CryptoError(f"Unsupported algorithm: {algorithm}")

    # 使用对象池
    if algorithm == "aes-256-gcm":
        pool = await _get_aes_gcm_pool()
        cipher = await pool.acquire()
        try:
            # 安全地临时设置密钥 - 使用SecureBuffer
            temp_key = key
            cipher._key_buffer.buffer[:] = temp_key
            cipher._cipher = AESGCM(temp_key)
            result = cipher.decrypt(ciphertext, associated_data)
            return result
        finally:
            # 安全清除密钥
            secure_zero_memory(cipher._key_buffer.buffer)
            cipher._used_nonces.clear()
            await pool.release(cipher)

    elif algorithm == "chacha20-poly1305":
        pool = await _get_chacha20_pool()
        cipher = await pool.acquire()
        try:
            # 安全地临时设置密钥
            temp_key = key
            cipher._key_buffer.buffer[:] = temp_key
            cipher._cipher = ChaCha20Poly1305(temp_key)
            result = cipher.decrypt(ciphertext, associated_data)
            return result
        finally:
            # 安全清除密钥
            secure_zero_memory(cipher._key_buffer.buffer)
            cipher._used_nonces.clear()
            await pool.release(cipher)

    else:
        # 其他算法不使用对象池
        cipher = SecureCipherFactory.create_cipher(algorithm, key)
        return cipher.decrypt(ciphertext, associated_data)


class SecureCipherFactory:
    """安全加密器工厂"""

    @staticmethod
    def create_cipher(algorithm: str, key: Optional[bytes] = None) -> SymmetricCipher:
        """
        工厂函数: 根据算法名称创建加密器

        安全增强:
        - 算法白名单验证
        - 密钥长度验证
        """
        if algorithm not in ALLOWED_ALGORITHMS:
            raise ValueError(
                f"Unsupported algorithm: {algorithm}. "
                f"Allowed: {ALLOWED_ALGORITHMS}"
            )

        cipher_map = {
            "aes-256-gcm": AES256GCMCipher,
            "aes-256-cbc": AES256CBCCipher,
            "aes-256-ofb": AES256OFBCipher,
            "chacha20-poly1305": ChaCha20Cipher,
            "ascon-128a": ASCON128aCipher,
        }

        cipher_cls = cipher_map.get(algorithm)
        if cipher_cls is None:
            raise ValueError(f"Cipher class not found for {algorithm}")

        return cipher_cls(key)


# 向后兼容
create_cipher = SecureCipherFactory.create_cipher
