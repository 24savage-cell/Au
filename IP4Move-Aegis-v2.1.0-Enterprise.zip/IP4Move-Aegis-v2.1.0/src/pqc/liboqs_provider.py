"""
liboqs集成提供者 - 生产级后量子密码学实现

⚠️ 安全警告 ⚠️
================
纯Python实现的PQC存在严重的侧信道攻击风险：
- Python解释器的时序抖动
- 垃圾回收的不确定性
- 内存分配模式泄露

本模块提供liboqs (Open Quantum Safe) 的Python绑定集成，
使用经过NIST FIPS 203/204/205认证的C实现。

依赖:
    pip install liboqs-python>=0.15.0

参考文献:
    [1] NIST FIPS 203: ML-KEM (Kyber) 标准
    [2] NIST FIPS 204: ML-DSA (Dilithium) 标准
    [3] NIST FIPS 205: SLH-DSA (Sphincs+) 标准
    [4] https://openquantumsafe.org/liboqs/

版本: v2.1.0
"""

from __future__ import annotations

import logging
import os
import secrets
import time
import warnings
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)

# ============================================================================
# 安全警告 - 启动时显示
# ============================================================================

SECURITY_WARNING = """
╔═══════════════════════════════════════════════════════════════════════════╗
║                        ⚠️  PQC 安全警告 ⚠️                                ║
╠═══════════════════════════════════════════════════════════════════════════╣
║  纯Python PQC实现存在侧信道攻击风险，不适合生产环境！                      ║
║                                                                           ║
║  风险来源:                                                                ║
║  • Python解释器时序抖动 - 可泄露密钥位信息                                ║
║  • 垃圾回收不确定性 - 内存模式可被分析                                    ║
║  • 无恒定时间保证 - 分支预测可泄露信息                                    ║
║                                                                           ║
║  生产环境解决方案:                                                        ║
║  1. 安装liboqs-python: pip install liboqs-python>=0.15.0                 ║
║  2. 使用LiboqsKEM/LiboqsSigner类                                          ║
║  3. 或集成OpenSSL 3.4+ with oqs-provider                                  ║
║                                                                           ║
║  参考: https://openquantumsafe.org/                                       ║
╚═══════════════════════════════════════════════════════════════════════════╝
"""

# 尝试导入liboqs
try:
    import oqs
    HAS_LIBOQS = True
    LIBOQS_VERSION = oqs.oqs_version()
    logger.info(f"liboqs {LIBOQS_VERSION} 已加载 - 生产级PQC可用")
except ImportError:
    HAS_LIBOQS = False
    LIBOQS_VERSION = None
    # 显示安全警告
    warnings.warn(SECURITY_WARNING, UserWarning, stacklevel=2)
    logger.warning("liboqs未安装，使用Python参考实现（不安全！）")


# ============================================================================
# 算法枚举
# ============================================================================

class KEMAlgorithm(Enum):
    """支持的KEM算法 (NIST标准化)"""
    # NIST Level 1 (128位经典安全)
    KYBER_512 = "Kyber512"
    ML_KEM_512 = "ML-KEM-512"  # FIPS 203
    
    # NIST Level 3 (192位经典安全) - 推荐
    KYBER_768 = "Kyber768"
    ML_KEM_768 = "ML-KEM-768"  # FIPS 203 推荐
    
    # NIST Level 5 (256位经典安全)
    KYBER_1024 = "Kyber1024"
    ML_KEM_1024 = "ML-KEM-1024"  # FIPS 203
    
    # 混合方案 (经典 + PQC)
    HYBRID_X25519_KYBER768 = "x25519_Kyber768"
    
    # 备选方案 (NIST第4轮候选)
    HQC_128 = "HQC-128"
    HQC_192 = "HQC-192"
    HQC_256 = "HQC-256"


class SignAlgorithm(Enum):
    """支持的签名算法 (NIST标准化)"""
    # ML-DSA (Dilithium) - FIPS 204
    ML_DSA_44 = "ML-DSA-44"      # Level 2
    ML_DSA_65 = "ML-DSA-65"      # Level 3 - 推荐
    ML_DSA_87 = "ML-DSA-87"      # Level 5
    
    # SLH-DSA (Sphincs+) - FIPS 205
    SLH_DSA_SHA2_128F = "SLH-DSA-SHA2-128F"
    SLH_DSA_SHA2_192F = "SLH-DSA-SHA2-192F"
    SLH_DSA_SHA2_256F = "SLH-DSA-SHA2-256F"
    
    # 混合签名
    HYBRID_ECDSA_MLDSA = "ECDSA_ML-DSA-65"


# ============================================================================
# Crypto-Agility 接口
# ============================================================================

class CryptoProvider(ABC):
    """
    密码敏捷性接口 - 支持算法热切换
    
    2026年最佳实践：密码敏捷架构，能随时切换算法而不改业务代码。
    未来NIST标准化HQC（预计2027年）时能无缝升级。
    """
    
    @abstractmethod
    def get_algorithm_name(self) -> str:
        """获取当前算法名称"""
        pass
    
    @abstractmethod
    def get_security_level(self) -> int:
        """获取NIST安全级别 (1/3/5)"""
        pass
    
    @abstractmethod
    def is_production_safe(self) -> bool:
        """是否适合生产环境"""
        pass


class KEMProvider(CryptoProvider):
    """KEM提供者抽象基类"""
    
    @abstractmethod
    def keygen(self) -> Tuple[bytes, bytes]:
        """生成密钥对 (public_key, secret_key)"""
        pass
    
    @abstractmethod
    def encapsulate(self, public_key: bytes) -> Tuple[bytes, bytes]:
        """封装 (ciphertext, shared_secret)"""
        pass
    
    @abstractmethod
    def decapsulate(self, secret_key: bytes, ciphertext: bytes) -> bytes:
        """解封装 -> shared_secret"""
        pass


class SignerProvider(CryptoProvider):
    """签名提供者抽象基类"""
    
    @abstractmethod
    def keygen(self) -> Tuple[bytes, bytes]:
        """生成密钥对 (public_key, secret_key)"""
        pass
    
    @abstractmethod
    def sign(self, secret_key: bytes, message: bytes) -> bytes:
        """签名"""
        pass
    
    @abstractmethod
    def verify(self, public_key: bytes, message: bytes, signature: bytes) -> bool:
        """验签"""
        pass


# ============================================================================
# liboqs 实现
# ============================================================================

class LiboqsKEM(KEMProvider):
    """
    liboqs KEM实现 - 生产级安全
    
    使用C实现的liboqs库，提供恒定时间操作和侧信道防护。
    """
    
    def __init__(self, algorithm: KEMAlgorithm = KEMAlgorithm.ML_KEM_768):
        if not HAS_LIBOQS:
            raise RuntimeError(
                "liboqs未安装。请运行: pip install liboqs-python>=0.15.0"
            )
        
        self._algorithm = algorithm
        self._kem = oqs.KeyEncapsulation(algorithm.value)
        
        logger.info(f"初始化liboqs KEM: {algorithm.value}, "
                   f"公钥大小: {self._kem.details['public_key_bytes']} bytes, "
                   f"安全级别: {self._kem.details['claimed_nist_level']}")
    
    def get_algorithm_name(self) -> str:
        return self._algorithm.value
    
    def get_security_level(self) -> int:
        return self._kem.details['claimed_nist_level']
    
    def is_production_safe(self) -> bool:
        return True  # liboqs是生产安全的
    
    def keygen(self) -> Tuple[bytes, bytes]:
        """生成密钥对"""
        public_key = self._kem.generate_keypair()
        secret_key = self._kem.export_secret_key()
        return public_key, secret_key
    
    def encapsulate(self, public_key: bytes) -> Tuple[bytes, bytes]:
        """封装"""
        ciphertext, shared_secret = self._kem.encapsulate(public_key)
        return ciphertext, shared_secret
    
    def decapsulate(self, secret_key: bytes, ciphertext: bytes) -> bytes:
        """解封装"""
        return self._kem.decapsulate(ciphertext, secret_key)
    
    def get_details(self) -> Dict[str, Any]:
        """获取算法详细信息"""
        return self._kem.details


class LiboqsSigner(SignerProvider):
    """
    liboqs 签名实现 - 生产级安全
    """
    
    def __init__(self, algorithm: SignAlgorithm = SignAlgorithm.ML_DSA_65):
        if not HAS_LIBOQS:
            raise RuntimeError(
                "liboqs未安装。请运行: pip install liboqs-python>=0.15.0"
            )
        
        self._algorithm = algorithm
        self._sig = oqs.Signature(algorithm.value)
        
        logger.info(f"初始化liboqs Signer: {algorithm.value}, "
                   f"公钥大小: {self._sig.details['public_key_bytes']} bytes, "
                   f"签名大小: {self._sig.details['signature_bytes']} bytes")
    
    def get_algorithm_name(self) -> str:
        return self._algorithm.value
    
    def get_security_level(self) -> int:
        return self._sig.details['claimed_nist_level']
    
    def is_production_safe(self) -> bool:
        return True
    
    def keygen(self) -> Tuple[bytes, bytes]:
        """生成密钥对"""
        public_key = self._sig.generate_keypair()
        secret_key = self._sig.export_secret_key()
        return public_key, secret_key
    
    def sign(self, secret_key: bytes, message: bytes) -> bytes:
        """签名"""
        return self._sig.sign(message, secret_key)
    
    def verify(self, public_key: bytes, message: bytes, signature: bytes) -> bool:
        """验签"""
        return self._sig.verify(message, signature, public_key)
    
    def get_details(self) -> Dict[str, Any]:
        """获取算法详细信息"""
        return self._sig.details


# ============================================================================
# 混合KEM (经典 + PQC)
# ============================================================================

class HybridKEM(KEMProvider):
    """
    混合KEM - 经典ECDH + PQC
    
    提供前向兼容：即使PQC被破解，经典ECDH仍提供保护。
    Cloudflare、Google、Apple已在生产环境部署类似方案。
    """
    
    def __init__(
        self,
        classic_kem: str = "X25519",
        pqc_kem: KEMAlgorithm = KEMAlgorithm.ML_KEM_768
    ):
        self._classic_kem = classic_kem
        self._pqc_kem = pqc_kem
        
        # 经典ECDH
        from cryptography.hazmat.primitives.asymmetric.x25519 import (
            X25519PrivateKey, X25519PublicKey
        )
        self._x25519 = X25519PrivateKey
        
        # PQC KEM
        if HAS_LIBOQS:
            self._pqc = LiboqsKEM(pqc_kem)
        else:
            raise RuntimeError("混合KEM需要liboqs支持")
    
    def get_algorithm_name(self) -> str:
        return f"Hybrid({self._classic_kem}+{self._pqc_kem.value})"
    
    def get_security_level(self) -> int:
        return self._pqc.get_security_level()
    
    def is_production_safe(self) -> bool:
        return True
    
    def keygen(self) -> Tuple[bytes, bytes]:
        """生成混合密钥对"""
        # 经典密钥
        classic_priv = self._x25519.generate()
        classic_pub = classic_priv.public_key()
        classic_pub_bytes = classic_pub.public_bytes_raw()
        classic_priv_bytes = classic_priv.private_bytes_raw()
        
        # PQC密钥
        pqc_pub, pqc_priv = self._pqc.keygen()
        
        # 组合公钥: classic_pub || pqc_pub
        public_key = classic_pub_bytes + pqc_pub
        # 组合私钥: classic_priv || pqc_priv
        secret_key = classic_priv_bytes + pqc_priv
        
        return public_key, secret_key
    
    def encapsulate(self, public_key: bytes) -> Tuple[bytes, bytes]:
        """混合封装"""
        # 分离公钥
        classic_pub_bytes = public_key[:32]  # X25519公钥32字节
        pqc_pub = public_key[32:]
        
        # 经典封装
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PublicKey
        classic_pub = X25519PublicKey.from_public_bytes(classic_pub_bytes)
        ephemeral_priv = self._x25519.generate()
        classic_shared = ephemeral_priv.exchange(classic_pub)
        classic_ct = ephemeral_priv.public_key().public_bytes_raw()
        
        # PQC封装
        pqc_ct, pqc_shared = self._pqc.encapsulate(pqc_pub)
        
        # 组合密文: classic_ct || pqc_ct
        ciphertext = classic_ct + pqc_ct
        
        # 组合共享密钥: HKDF(classic_shared || pqc_shared)
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        from cryptography.hazmat.primitives import hashes
        hkdf = HKDF(
            algorithm=hashes.SHA384(),
            length=32,
            salt=None,
            info=b"HybridKEMv1",
        )
        shared_secret = hkdf.derive(classic_shared + pqc_shared)
        
        return ciphertext, shared_secret
    
    def decapsulate(self, secret_key: bytes, ciphertext: bytes) -> bytes:
        """混合解封装"""
        # 分离私钥
        classic_priv_bytes = secret_key[:32]
        pqc_priv = secret_key[32:]
        
        # 分离密文
        classic_ct = ciphertext[:32]
        pqc_ct = ciphertext[32:]
        
        # 经典解封装
        from cryptography.hazmat.primitives.asymmetric.x25519 import (
            X25519PrivateKey, X25519PublicKey
        )
        classic_priv = X25519PrivateKey.from_private_bytes(classic_priv_bytes)
        classic_pub = X25519PublicKey.from_public_bytes(classic_ct)
        classic_shared = classic_priv.exchange(classic_pub)
        
        # PQC解封装
        pqc_shared = self._pqc.decapsulate(pqc_priv, pqc_ct)
        
        # 组合共享密钥
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        from cryptography.hazmat.primitives import hashes
        hkdf = HKDF(
            algorithm=hashes.SHA384(),
            length=32,
            salt=None,
            info=b"HybridKEMv1",
        )
        shared_secret = hkdf.derive(classic_shared + pqc_shared)
        
        return shared_secret


# ============================================================================
# Crypto-Agility 管理器
# ============================================================================

class CryptoAgilityManager:
    """
    密码敏捷管理器 - 算法热切换
    
    支持:
    - 运行时切换算法
    - 算法优先级配置
    - 未来算法升级
    """
    
    def __init__(self):
        self._kem_providers: Dict[str, KEMProvider] = {}
        self._signer_providers: Dict[str, SignerProvider] = {}
        self._default_kem: Optional[str] = None
        self._default_signer: Optional[str] = None
    
    def register_kem(self, name: str, provider: KEMProvider, is_default: bool = False):
        """注册KEM提供者"""
        self._kem_providers[name] = provider
        if is_default or self._default_kem is None:
            self._default_kem = name
        logger.info(f"注册KEM: {name}, 默认: {is_default}")
    
    def register_signer(self, name: str, provider: SignerProvider, is_default: bool = False):
        """注册签名提供者"""
        self._signer_providers[name] = provider
        if is_default or self._default_signer is None:
            self._default_signer = name
        logger.info(f"注册Signer: {name}, 默认: {is_default}")
    
    def get_kem(self, name: Optional[str] = None) -> KEMProvider:
        """获取KEM提供者"""
        kem_name = name or self._default_kem
        if kem_name not in self._kem_providers:
            raise ValueError(f"未注册的KEM: {kem_name}")
        return self._kem_providers[kem_name]
    
    def get_signer(self, name: Optional[str] = None) -> SignerProvider:
        """获取签名提供者"""
        signer_name = name or self._default_signer
        if signer_name not in self._signer_providers:
            raise ValueError(f"未注册的Signer: {signer_name}")
        return self._signer_providers[signer_name]
    
    def switch_default_kem(self, name: str):
        """切换默认KEM"""
        if name not in self._kem_providers:
            raise ValueError(f"未注册的KEM: {name}")
        old = self._default_kem
        self._default_kem = name
        logger.info(f"KEM切换: {old} -> {name}")
    
    def list_algorithms(self) -> Dict[str, List[Dict]]:
        """列出所有可用算法"""
        return {
            "kem": [
                {
                    "name": name,
                    "algorithm": p.get_algorithm_name(),
                    "security_level": p.get_security_level(),
                    "production_safe": p.is_production_safe(),
                    "is_default": name == self._default_kem,
                }
                for name, p in self._kem_providers.items()
            ],
            "signer": [
                {
                    "name": name,
                    "algorithm": p.get_algorithm_name(),
                    "security_level": p.get_security_level(),
                    "production_safe": p.is_production_safe(),
                    "is_default": name == self._default_signer,
                }
                for name, p in self._signer_providers.items()
            ],
        }


# ============================================================================
# 全局默认管理器
# ============================================================================

def create_default_manager() -> CryptoAgilityManager:
    """创建默认配置的密码敏捷管理器"""
    manager = CryptoAgilityManager()
    
    if HAS_LIBOQS:
        # 注册生产级KEM
        manager.register_kem("ml-kem-768", LiboqsKEM(KEMAlgorithm.ML_KEM_768), is_default=True)
        manager.register_kem("kyber-768", LiboqsKEM(KEMAlgorithm.KYBER_768))
        manager.register_kem("hybrid", HybridKEM())
        
        # 注册生产级签名
        manager.register_signer("ml-dsa-65", LiboqsSigner(SignAlgorithm.ML_DSA_65), is_default=True)
        manager.register_signer("slh-dsa", LiboqsSigner(SignAlgorithm.SLH_DSA_SHA2_192F))
    
    return manager


# 全局实例
_global_manager: Optional[CryptoAgilityManager] = None


def get_global_manager() -> CryptoAgilityManager:
    """获取全局密码敏捷管理器"""
    global _global_manager
    if _global_manager is None:
        _global_manager = create_default_manager()
    return _global_manager
