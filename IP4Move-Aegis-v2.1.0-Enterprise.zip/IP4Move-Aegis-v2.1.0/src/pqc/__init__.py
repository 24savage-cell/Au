"""
PQC - 后量子密码学升级模块 (Post-Quantum Cryptography Module)

本模块提供后量子密码学(PQC)相关功能，包括：
- Kyber-768 2025修订版密钥封装机制（修复侧信道漏洞）
- CRYSTALS-Sphincs+ 状态哈希签名算法
- Dilithium + Sphincs+ 双重签名保护方案
- 后量子密钥轮换管理（2分钟间隔）
- 量子安全随机数生成器(QRNG)接口
- HKDF-SHA3-512 增强密钥派生

安全级别：NIST PQC Level 3 (Kyber-768) / Level 5 (Sphincs+)
兼容性：Python 3.10+

典型用法:
    from src.pqc import Kyber768_2025, DualSignatureScheme, PQCKeyRotator

    # 创建Kyber-768实例
    kyber = Kyber768_2025()
    pk, sk = kyber.keygen()
    ct, ss_enc = kyber.encapsulate(pk)
    ss_dec = kyber.decapsulate(ct, sk)

    # 双重签名
    dual_sig = DualSignatureScheme()
    dual_sig.setup()
    signature = dual_sig.sign(b"message")
    valid = dual_sig.verify(b"message", signature)

    # 密钥轮换
    rotator = PQCKeyRotator(interval_seconds=120)
    rotator.start_rotation()
"""

# 版本信息
__version__ = "1.0.5"
__author__ = "IP4Move Aegis Security Team"
__protocol_version__ = "NIST-PQC-2025-R1"

# 从 advanced_pqc 模块导出所有公开类
from src.pqc.advanced_pqc import (
    Kyber768_2025,
    SphincsPlusSigner,
    DualSignatureScheme,
    PQCKeyRotator,
    QuantumRandomInterface,
)

__all__ = [
    "Kyber768_2025",
    "SphincsPlusSigner",
    "DualSignatureScheme",
    "PQCKeyRotator",
    "QuantumRandomInterface",
]
