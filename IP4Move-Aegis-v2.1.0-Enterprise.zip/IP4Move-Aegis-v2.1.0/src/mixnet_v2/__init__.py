"""
Mixnet架构优化模块 (Mixnet V2)
==============================

本模块实现了增强型Mixnet匿名通信架构，结合洋葱路由的低延迟特性和
Mixnet的高匿名性特性，提供更强的抗流量分析能力。

主要组件:
    - OnionMixnetHybrid: 洋葱Mixnet混合架构，前3跳洋葱路由+后3跳Mixnet
    - TrafficSplitter: 流量拆分与重组器，基于秘密共享的多路径传输
    - PacketShuffler: 随机包插入与删除器，使输入输出流量完全不相关
    - DecoyNodeManager: 诱饵节点管理器，部署虚假节点迷惑攻击者

使用示例:
    >>> from mixnet_v2 import OnionMixnetHybrid, TrafficSplitter
    >>> hybrid = OnionMixnetHybrid()
    >>> route = hybrid.build_hybrid_route()

版本: 2.0.0
作者: IP4Move Aegis Team
许可: MIT License
"""

from mixnet_v2.enhanced_mixnet import (
    OnionMixnetHybrid,
    TrafficSplitter,
    PacketShuffler,
    DecoyNodeManager,
)

__all__ = [
    "OnionMixnetHybrid",
    "TrafficSplitter",
    "PacketShuffler",
    "DecoyNodeManager",
]

__version__ = "2.0.0"
