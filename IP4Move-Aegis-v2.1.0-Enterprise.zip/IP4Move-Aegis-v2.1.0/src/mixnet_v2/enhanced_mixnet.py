"""
Mixnet架构优化模块 - 核心实现
================================

Enhanced Mixnet Architecture Module - Core Implementation

本模块实现了四种增强型Mixnet匿名通信技术:
1. OnionMixnetHybrid - 洋葱Mixnet混合架构
2. TrafficSplitter - 流量拆分与重组器
3. PacketShuffler - 随机包插入与删除器
4. DecoyNodeManager - 诱饵节点管理器

所有类均支持异步操作，使用type hints，包含完整的错误处理和日志记录。
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import random
import struct
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Set, Tuple

# ============================================================================
# 日志配置 / Logging Configuration
# ============================================================================

logger = logging.getLogger(__name__)


# ============================================================================
# 数据类与枚举 / Data Classes and Enums
# ============================================================================

class NodeType(Enum):
    """节点类型枚举"""
    ONION_GUARD = auto()     # 洋葱路由入口守卫节点
    ONION_MIDDLE = auto()    # 洋葱路由中间节点
    ONION_EXIT = auto()      # 洋葱路由出口节点
    MIX_ENTRY = auto()       # Mixnet入口节点
    MIX_MIDDLE = auto()      # Mixnet中间节点
    MIX_EXIT = auto()        # Mixnet出口节点
    DECOY = auto()           # 诱饵节点


class SecurityLevel(Enum):
    """安全级别枚举"""
    LOW = 1          # 低安全性（快速）
    MEDIUM = 2       # 中等安全性
    HIGH = 3         # 高安全性
    MAXIMUM = 4      # 最高安全性（最慢）


class FragmentStatus(Enum):
    """分片状态枚举"""
    CREATED = auto()     # 已创建
    IN_TRANSIT = auto()  # 传输中
    DELIVERED = auto()   # 已送达
    LOST = auto()        # 已丢失
    RECOVERED = auto()   # 已恢复


@dataclass
class MixNode:
    """Mix节点信息

    Attributes:
        node_id: 节点唯一标识
        node_type: 节点类型
        address: 节点地址（IP:Port）
        public_key: 节点公钥（用于洋葱加密）
        bandwidth: 可用带宽（bytes/s）
        latency: 节点延迟（ms）
        is_active: 节点是否活跃
        country_code: 节点所在国家代码
        uptime: 节点运行时间（秒）
        trust_score: 信任分数（0-100）
    """
    node_id: str
    node_type: NodeType
    address: str
    public_key: str = ""
    bandwidth: int = 10485760  # 默认10MB/s
    latency: float = 50.0
    is_active: bool = True
    country_code: str = "US"
    uptime: float = 0.0
    trust_score: int = 50

    @property
    def is_decoy(self) -> bool:
        """是否为诱饵节点"""
        return self.node_type == NodeType.DECOY


@dataclass
class RouteHop:
    """路由跳信息

    Attributes:
        node: 路由跳对应的节点
        layer_encryption_key: 该层的加密密钥
        encrypted_payload: 加密后的载荷
        delay_ms: 该跳的延迟（毫秒）
    """
    node: MixNode
    layer_encryption_key: bytes = b""
    encrypted_payload: bytes = b""
    delay_ms: float = 0.0


@dataclass
class HybridRoute:
    """混合路由信息

    Attributes:
        route_id: 路由唯一标识
        onion_hops: 洋葱路由部分（前3跳）
        mixnet_hops: Mixnet部分（后3跳）
        total_hops: 总跳数
        estimated_latency: 预估总延迟（ms）
        security_score: 安全评分（0-100）
        created_at: 路由创建时间
        expires_at: 路由过期时间
    """
    route_id: str = ""
    onion_hops: List[RouteHop] = field(default_factory=list)
    mixnet_hops: List[RouteHop] = field(default_factory=list)
    total_hops: int = 0
    estimated_latency: float = 0.0
    security_score: int = 0
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0

    def __post_init__(self) -> None:
        """后初始化：计算总跳数和过期时间"""
        if self.total_hops == 0:
            self.total_hops = len(self.onion_hops) + len(self.mixnet_hops)
        if self.expires_at == 0.0:
            self.expires_at = self.created_at + 600  # 路由有效期10分钟


@dataclass
class MessageFragment:
    """消息分片

    Attributes:
        fragment_id: 分片唯一标识
        message_id: 原始消息ID
        index: 分片索引
        total_fragments: 总分片数
        data: 分片数据
        secret_share: 秘密共享份额
        path_id: 传输路径ID
        status: 分片状态
        created_at: 创建时间
        retries: 重试次数
    """
    fragment_id: str = ""
    message_id: str = ""
    index: int = 0
    total_fragments: int = 0
    data: bytes = b""
    secret_share: bytes = b""
    path_id: str = ""
    status: FragmentStatus = FragmentStatus.CREATED
    created_at: float = field(default_factory=time.time)
    retries: int = 0


@dataclass
class ShuffledPacket:
    """洗牌后的数据包

    Attributes:
        packet_id: 包唯一标识
        payload: 载荷数据
        is_dummy: 是否为虚假包
        original_order: 原始顺序
        shuffled_order: 洗牌后顺序
        delay_ms: 注入的延迟（毫秒）
        batch_id: 所属批次ID
    """
    packet_id: str = ""
    payload: bytes = b""
    is_dummy: bool = False
    original_order: int = 0
    shuffled_order: int = 0
    delay_ms: float = 0.0
    batch_id: str = ""


@dataclass
class DecoyNodeStats:
    """诱饵节点统计信息

    Attributes:
        node_id: 诱饵节点ID
        traffic_generated: 生成的虚假流量（bytes）
        connections_accepted: 接受的连接数
        probes_detected: 检测到的探测次数
        uptime: 运行时间（秒）
        last_activity: 最后活动时间
    """
    node_id: str
    traffic_generated: int = 0
    connections_accepted: int = 0
    probes_detected: int = 0
    uptime: float = 0.0
    last_activity: float = field(default_factory=time.time)


# ============================================================================
# 洋葱Mixnet混合架构 / Onion Mixnet Hybrid
# ============================================================================

class OnionMixnetHybrid:
    """洋葱Mixnet混合架构

    结合洋葱路由的低延迟特性和Mixnet的高匿名性特性:
    - 前3跳使用洋葱路由（逐层加密，低延迟）
    - 后3跳使用Mixnet（批量处理，高匿名性）
    - 自动路径选择和性能-安全平衡

    Features:
        - 前3跳洋葱路由（低延迟）
        - 后3跳Mixnet（高匿名性）
        - 自动路径选择
        - 性能-安全平衡参数

    Example:
        >>> hybrid = OnionMixnetHybrid(security_level=SecurityLevel.HIGH)
        >>> await hybrid.initialize()
        >>> route = await hybrid.build_hybrid_route()
    """

    # 默认的洋葱路由跳数
    DEFAULT_ONION_HOPS: int = 3

    # 默认的Mixnet跳数
    DEFAULT_MIXNET_HOPS: int = 3

    # 安全级别对应的参数配置
    SECURITY_CONFIGS: Dict[SecurityLevel, Dict[str, Any]] = {
        SecurityLevel.LOW: {
            "onion_hops": 2,
            "mixnet_hops": 2,
            "batch_size": 10,
            "delay_range": (0.05, 0.2),
            "dummy_rate": 0.1,
        },
        SecurityLevel.MEDIUM: {
            "onion_hops": 3,
            "mixnet_hops": 3,
            "batch_size": 25,
            "delay_range": (0.1, 0.5),
            "dummy_rate": 0.2,
        },
        SecurityLevel.HIGH: {
            "onion_hops": 3,
            "mixnet_hops": 3,
            "batch_size": 50,
            "delay_range": (0.2, 1.0),
            "dummy_rate": 0.3,
        },
        SecurityLevel.MAXIMUM: {
            "onion_hops": 4,
            "mixnet_hops": 4,
            "batch_size": 100,
            "delay_range": (0.5, 2.0),
            "dummy_rate": 0.5,
        },
    }

    def __init__(
        self,
        security_level: SecurityLevel = SecurityLevel.MEDIUM,
        onion_hops: int = 3,
        mixnet_hops: int = 3,
        max_routes: int = 100,
    ) -> None:
        """初始化洋葱Mixnet混合架构

        Args:
            security_level: 安全级别
            onion_hops: 洋葱路由跳数（覆盖安全级别默认值）
            mixnet_hops: Mixnet跳数（覆盖安全级别默认值）
            max_routes: 最大同时路由数
        """
        self.security_level = security_level
        self.onion_hops = onion_hops
        self.mixnet_hops = mixnet_hops
        self.max_routes = max_routes

        # 获取安全级别配置
        self._config = self.SECURITY_CONFIGS[security_level].copy()
        if onion_hops != self.DEFAULT_ONION_HOPS:
            self._config["onion_hops"] = onion_hops
        if mixnet_hops != self.DEFAULT_MIXNET_HOPS:
            self._config["mixnet_hops"] = mixnet_hops

        # 节点池
        self._onion_nodes: List[MixNode] = []
        self._mixnet_nodes: List[MixNode] = []

        # 活跃路由
        self._active_routes: Dict[str, HybridRoute] = {}

        # 统计信息
        self._stats: Dict[str, int] = {
            "routes_built": 0,
            "messages_sent": 0,
            "bytes_sent": 0,
            "routes_expired": 0,
        }

        logger.info(
            "OnionMixnetHybrid initialized: level=%s, onion=%d, mixnet=%d",
            security_level.name, self._config["onion_hops"],
            self._config["mixnet_hops"]
        )

    async def initialize(self, num_onion_nodes: int = 50, num_mixnet_nodes: int = 50) -> None:
        """初始化节点池

        生成模拟的洋葱路由节点和Mixnet节点。

        Args:
            num_onion_nodes: 洋葱路由节点数量
            num_mixnet_nodes: Mixnet节点数量
        """
        # 生成洋葱路由节点
        self._onion_nodes = self._generate_nodes(
            num_onion_nodes,
            [
                NodeType.ONION_GUARD,
                NodeType.ONION_MIDDLE,
                NodeType.ONION_EXIT,
            ],
        )

        # 生成Mixnet节点
        self._mixnet_nodes = self._generate_nodes(
            num_mixnet_nodes,
            [
                NodeType.MIX_ENTRY,
                NodeType.MIX_MIDDLE,
                NodeType.MIX_EXIT,
            ],
        )

        logger.info(
            "Initialized node pool: %d onion nodes, %d mixnet nodes",
            len(self._onion_nodes), len(self._mixnet_nodes)
        )

    def _generate_nodes(
        self,
        count: int,
        node_types: List[NodeType],
    ) -> List[MixNode]:
        """生成模拟节点列表

        Args:
            count: 节点数量
            node_types: 可用的节点类型列表

        Returns:
            生成的节点列表
        """
        nodes: List[MixNode] = []
        countries = [
            "US", "DE", "NL", "CH", "SE", "NO", "RO", "IS",
            "LU", "FI", "JP", "SG", "AU", "CA", "BR", "KR",
        ]

        for i in range(count):
            node_type = node_types[i % len(node_types)]
            country = random.choice(countries)
            node = MixNode(
                node_id=f"node-{node_type.name.lower()}-{i:04d}",
                node_type=node_type,
                address=f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}:{random.randint(9000, 65535)}",
                public_key=base64.b64encode(os.urandom(32)).decode("ascii"),
                bandwidth=random.randint(1048576, 104857600),  # 1MB-100MB/s
                latency=random.uniform(5, 200),
                is_active=True,
                country_code=country,
                uptime=random.uniform(86400, 2592000),  # 1-30天
                trust_score=random.randint(30, 100),
            )
            nodes.append(node)

        return nodes

    def _select_onion_path(self) -> List[MixNode]:
        """选择洋葱路由路径

        从节点池中选择一条洋葱路由路径，确保:
        - 入口守卫节点具有高信任分数
        - 中间节点分布在不同国家
        - 出口节点具有高带宽

        Returns:
            选中的洋葱路由节点列表

        Raises:
            RuntimeError: 如果没有足够的活跃节点
        """
        num_hops = self._config["onion_hops"]
        active_nodes = [n for n in self._onion_nodes if n.is_active]

        if len(active_nodes) < num_hops:
            raise RuntimeError(
                f"Not enough active onion nodes: {len(active_nodes)} < {num_hops}"
            )

        selected: List[MixNode] = []
        used_countries: Set[str] = set()

        for hop_index in range(num_hops):
            if hop_index == 0:
                # 入口守卫：高信任分数
                candidates = sorted(
                    [n for n in active_nodes if n.node_type == NodeType.ONION_GUARD],
                    key=lambda n: n.trust_score,
                    reverse=True,
                )
                if not candidates:
                    candidates = active_nodes
            elif hop_index == num_hops - 1:
                # 出口节点：高带宽
                candidates = sorted(
                    [n for n in active_nodes if n.node_type == NodeType.ONION_EXIT],
                    key=lambda n: n.bandwidth,
                    reverse=True,
                )
                if not candidates:
                    candidates = active_nodes
            else:
                # 中间节点：优先选择不同国家
                candidates = [
                    n for n in active_nodes
                    if n.country_code not in used_countries
                ]
                if not candidates:
                    candidates = active_nodes

            # 从候选中随机选择（加入一些随机性）
            weights = [
                n.trust_score * (n.bandwidth / 10485760)
                for n in candidates
            ]
            total_weight = sum(weights)
            r = random.uniform(0, total_weight)
            cumulative = 0.0
            chosen = candidates[-1]
            for node, w in zip(candidates, weights):
                cumulative += w
                if r <= cumulative:
                    chosen = node
                    break

            selected.append(chosen)
            used_countries.add(chosen.country_code)
            active_nodes = [n for n in active_nodes if n.node_id != chosen.node_id]

        return selected

    def _select_mixnet_path(self) -> List[MixNode]:
        """选择Mixnet路径

        从节点池中选择一条Mixnet路径，优先选择:
        - 高匿名性节点（高trust_score）
        - 不同国家的节点
        - 低延迟节点

        Returns:
            选中的Mixnet节点列表

        Raises:
            RuntimeError: 如果没有足够的活跃节点
        """
        num_hops = self._config["mixnet_hops"]
        active_nodes = [n for n in self._mixnet_nodes if n.is_active]

        if len(active_nodes) < num_hops:
            raise RuntimeError(
                f"Not enough active mixnet nodes: {len(active_nodes)} < {num_hops}"
            )

        selected: List[MixNode] = []
        used_countries: Set[str] = set()

        for hop_index in range(num_hops):
            if hop_index == 0:
                candidates = [
                    n for n in active_nodes
                    if n.node_type == NodeType.MIX_ENTRY
                ]
                if not candidates:
                    candidates = active_nodes
            elif hop_index == num_hops - 1:
                candidates = [
                    n for n in active_nodes
                    if n.node_type == NodeType.MIX_EXIT
                ]
                if not candidates:
                    candidates = active_nodes
            else:
                candidates = [
                    n for n in active_nodes
                    if n.country_code not in used_countries
                ]
                if not candidates:
                    candidates = active_nodes

            # 按信任分数加权随机选择
            weights = [n.trust_score for n in candidates]
            total_weight = sum(weights)
            r = random.uniform(0, total_weight)
            cumulative = 0.0
            chosen = candidates[-1]
            for node, w in zip(candidates, weights):
                cumulative += w
                if r <= cumulative:
                    chosen = node
                    break

            selected.append(chosen)
            used_countries.add(chosen.country_code)
            active_nodes = [n for n in active_nodes if n.node_id != chosen.node_id]

        return selected

    def _compute_security_score(
        self,
        onion_path: List[MixNode],
        mixnet_path: List[MixNode],
    ) -> int:
        """计算路由的安全评分

        基于多个因素评估路由的安全性:
        - 节点信任分数
        - 地理多样性
        - 路由长度
        - 带宽充足性

        Args:
            onion_path: 洋葱路由路径
            mixnet_path: Mixnet路径

        Returns:
            安全评分（0-100）
        """
        all_nodes = onion_path + mixnet_path

        # 因素1: 平均信任分数（权重30%）
        avg_trust = sum(n.trust_score for n in all_nodes) / len(all_nodes)
        trust_score = avg_trust * 0.3

        # 因素2: 地理多样性（权重25%）
        unique_countries = len(set(n.country_code for n in all_nodes))
        diversity_score = min(unique_countries / len(all_nodes), 1.0) * 100 * 0.25

        # 因素3: 路由长度（权重25%）
        length_score = min(len(all_nodes) / 8.0, 1.0) * 100 * 0.25

        # 因素4: 带宽充足性（权重20%）
        min_bandwidth = min(n.bandwidth for n in all_nodes)
        bandwidth_score = min(min_bandwidth / 104857600, 1.0) * 100 * 0.2

        total_score = int(trust_score + diversity_score + length_score + bandwidth_score)
        return max(0, min(100, total_score))

    async def build_hybrid_route(self) -> HybridRoute:
        """构建混合路由

        选择洋葱路由路径和Mixnet路径，组合成完整的混合路由。

        Returns:
            构建的混合路由对象

        Raises:
            RuntimeError: 如果路由构建失败
        """
        # 清理过期路由
        self._cleanup_expired_routes()

        if len(self._active_routes) >= self.max_routes:
            raise RuntimeError(
                f"Maximum number of active routes ({self.max_routes}) reached"
            )

        route_id = base64.b64encode(os.urandom(12)).decode("ascii")[:16]

        # 选择洋葱路由路径
        onion_nodes = self._select_onion_path()

        # 选择Mixnet路径
        mixnet_nodes = self._select_mixnet_path()

        # 构建路由跳信息
        onion_hops: List[RouteHop] = []
        for node in onion_nodes:
            hop = RouteHop(
                node=node,
                layer_encryption_key=os.urandom(32),
                delay_ms=node.latency + random.uniform(0, 10),
            )
            onion_hops.append(hop)

        mixnet_hops: List[RouteHop] = []
        for node in mixnet_nodes:
            hop = RouteHop(
                node=node,
                layer_encryption_key=os.urandom(32),
                delay_ms=node.latency + random.uniform(10, 50),
            )
            mixnet_hops.append(hop)

        # 计算预估延迟
        total_latency = sum(h.delay_ms for h in onion_hops + mixnet_hops)

        # 计算安全评分
        security_score = self._compute_security_score(onion_nodes, mixnet_nodes)

        route = HybridRoute(
            route_id=route_id,
            onion_hops=onion_hops,
            mixnet_hops=mixnet_hops,
            estimated_latency=total_latency,
            security_score=security_score,
        )

        self._active_routes[route_id] = route
        self._stats["routes_built"] += 1

        logger.info(
            "Hybrid route built: id=%s, onion=%d, mixnet=%d, "
            "latency=%.1fms, security=%d",
            route_id, len(onion_hops), len(mixnet_hops),
            total_latency, security_score
        )

        return route

    async def send_message(
        self,
        route_id: str,
        message: bytes,
    ) -> Dict[str, Any]:
        """通过混合路由发送消息

        消息先经过洋葱路由层（逐层加密），再经过Mixnet层（批量处理）。

        Args:
            route_id: 路由ID
            message: 要发送的消息

        Returns:
            包含发送结果的字典

        Raises:
            KeyError: 如果路由ID不存在
        """
        route = self._active_routes.get(route_id)
        if route is None:
            raise KeyError(f"Route not found: {route_id}")

        self._stats["messages_sent"] += 1
        self._stats["bytes_sent"] += len(message)
        start_time = time.time()

        # 步骤1: 洋葱路由层 - 逐层加密
        payload = message
        encryption_layers: List[Dict[str, Any]] = []

        # 从最后一跳开始反向加密（洋葱层）
        for i, hop in enumerate(reversed(route.onion_hops)):
            # 模拟AES-256加密
            iv = os.urandom(16)
            key = hop.layer_encryption_key
            encrypted = self._simulate_encrypt(payload, key, iv)

            # 构造洋葱层
            layer = {
                "layer": len(route.onion_hops) - i,
                "node_id": hop.node.node_id,
                "next_hop": (
                    route.onion_hops[len(route.onion_hops) - i - 2].node.node_id
                    if i < len(route.onion_hops) - 1 else route.mixnet_hops[0].node.node_id
                    if route.mixnet_hops else "exit"
                ),
                "iv": base64.b64encode(iv).decode("ascii"),
                "encrypted_size": len(encrypted),
            }
            encryption_layers.append(layer)
            payload = encrypted

            # 模拟传输延迟
            await asyncio.sleep(hop.delay_ms / 1000.0)

        # 步骤2: Mixnet层 - 批量处理
        mix_delays: List[float] = []
        for hop in route.mixnet_hops:
            # Mixnet节点会进行批量处理和延迟
            min_delay, max_delay = self._config["delay_range"]
            mix_delay = random.uniform(min_delay, max_delay)
            mix_delays.append(mix_delay)

            # 模拟Mixnet处理
            payload = self._simulate_encrypt(
                payload, hop.layer_encryption_key, os.urandom(16)
            )
            await asyncio.sleep(mix_delay)

        elapsed = (time.time() - start_time) * 1000

        return {
            "route_id": route_id,
            "message_size": len(message),
            "final_payload_size": len(payload),
            "onion_layers": len(encryption_layers),
            "mixnet_hops": len(route.mixnet_hops),
            "onion_delays_ms": [h.delay_ms for h in route.onion_hops],
            "mixnet_delays_ms": [round(d * 1000, 2) for d in mix_delays],
            "total_time_ms": round(elapsed, 2),
            "security_score": route.security_score,
        }

    def _cleanup_expired_routes(self) -> None:
        """清理过期的路由"""
        now = time.time()
        expired: List[str] = []

        for route_id, route in self._active_routes.items():
            if now > route.expires_at:
                expired.append(route_id)

        for route_id in expired:
            del self._active_routes[route_id]
            self._stats["routes_expired"] += 1

        if expired:
            logger.debug("Cleaned up %d expired routes", len(expired))

    @staticmethod
    def _simulate_encrypt(data: bytes, key: bytes, iv: bytes) -> bytes:
        """模拟AES-256-GCM加密

        在实际实现中应使用cryptography库进行真实加密。
        这里使用HMAC-SHA256模拟加密过程。

        Args:
            data: 明文数据
            key: 加密密钥
            iv: 初始化向量

        Returns:
            模拟的密文（包含IV和认证标签）
        """
        # 模拟加密：HMAC + 数据混淆
        mac = hmac.new(key, iv + data, hashlib.sha256).digest()
        # 简单的XOR混淆（实际应使用AES）
        encrypted = bytes(b ^ key[i % len(key)] for i, b in enumerate(data))
        return iv + mac + encrypted

    def get_stats(self) -> Dict[str, int]:
        """获取混合架构的统计信息

        Returns:
            包含各项统计计数的字典
        """
        stats = self._stats.copy()
        stats["active_routes"] = len(self._active_routes)
        return stats

    def get_active_routes(self) -> List[Dict[str, Any]]:
        """获取所有活跃路由的摘要

        Returns:
            路由摘要列表
        """
        routes = []
        for route_id, route in self._active_routes.items():
            routes.append({
                "route_id": route_id,
                "total_hops": route.total_hops,
                "estimated_latency_ms": round(route.estimated_latency, 2),
                "security_score": route.security_score,
                "onion_nodes": [h.node.node_id for h in route.onion_hops],
                "mixnet_nodes": [h.node.node_id for h in route.mixnet_hops],
            })
        return routes


# ============================================================================
# 流量拆分与重组器 / Traffic Splitter
# ============================================================================

class TrafficSplitter:
    """流量拆分与重组器

    基于秘密共享算法将消息拆分为多个分片，通过不同路径并行传输，
    在出口节点重组，提供抗单点失效和抗流量分析能力。

    Features:
        - 消息分片（基于秘密共享）
        - 多路径并行传输
        - 出口节点重组
        - 分片丢失恢复

    Example:
        >>> splitter = TrafficSplitter(threshold=3, num_shares=5)
        >>> fragments = await splitter.split_message(b"secret message")
        >>> recovered = await splitter.reassemble_message(fragments)
    """

    # 秘密共享的素数域（使用大素数）
    PRIME = 2**127 - 1  # Mersenne素数

    def __init__(
        self,
        threshold: int = 3,
        num_shares: int = 5,
        max_fragment_size: int = 16384,
        max_retries: int = 3,
        timeout_seconds: float = 30.0,
    ) -> None:
        """初始化流量拆分器

        Args:
            threshold: 秘密共享的重建阈值（至少需要的分片数）
            num_shares: 秘密共享的总份额数
            max_fragment_size: 最大分片大小（字节）
            max_retries: 分片传输最大重试次数
            timeout_seconds: 分片传输超时时间（秒）
        """
        if threshold > num_shares:
            raise ValueError(
                f"Threshold ({threshold}) cannot exceed num_shares ({num_shares})"
            )

        self.threshold = threshold
        self.num_shares = num_shares
        self.max_fragment_size = max_fragment_size
        self.max_retries = max_retries
        self.timeout_seconds = timeout_seconds

        # 分片管理
        self._pending_fragments: Dict[str, Dict[int, MessageFragment]] = {}
        self._completed_messages: Dict[str, bytes] = {}

        # 统计信息
        self._stats: Dict[str, int] = {
            "messages_split": 0,
            "messages_reassembled": 0,
            "fragments_created": 0,
            "fragments_delivered": 0,
            "fragments_lost": 0,
            "fragments_recovered": 0,
            "bytes_split": 0,
        }

        logger.info(
            "TrafficSplitter initialized: threshold=%d, shares=%d, "
            "max_fragment=%d",
            threshold, num_shares, max_fragment_size
        )

    def _modular_inverse(self, a: int, p: int) -> int:
        """计算模逆元（扩展欧几里得算法）

        Args:
            a: 要计算逆元的数
            p: 模数

        Returns:
            a在模p下的逆元

        Raises:
            ValueError: 如果逆元不存在
        """
        if a == 0:
            raise ValueError("No inverse exists for 0")

        g, x, _ = self._extended_gcd(a % p, p)
        if g != 1:
            raise ValueError(f"No inverse exists for {a} mod {p}")
        return x % p

    @staticmethod
    def _extended_gcd(a: int, b: int) -> Tuple[int, int, int]:
        """扩展欧几里得算法

        Args:
            a: 第一个数
            b: 第二个数

        Returns:
            (gcd, x, y) 其中 gcd = ax + by
        """
        if a == 0:
            return b, 0, 1
        g, x, y = TrafficSplitter._extended_gcd(b % a, a)
        return g, y - (b // a) * x, x

    def _share_secret(self, secret: int) -> List[Tuple[int, int]]:
        """使用Shamir秘密共享方案分享秘密

        将秘密分为num_shares份，其中任意threshold份可以重建秘密。

        Args:
            secret: 要分享的秘密（整数）

        Returns:
            份额列表，每个份额为 (x, f(x)) 元组
        """
        # 生成随机多项式: f(x) = secret + a1*x + a2*x^2 + ... + a_{t-1}*x^{t-1}
        coefficients = [secret]
        for _ in range(self.threshold - 1):
            coefficients.append(random.randint(1, self.PRIME - 1))

        # 计算份额
        shares: List[Tuple[int, int]] = []
        for i in range(1, self.num_shares + 1):
            # 计算 f(i)
            value = 0
            for j, coeff in enumerate(coefficients):
                value = (value + coeff * pow(i, j, self.PRIME)) % self.PRIME
            shares.append((i, value))

        return shares

    def _reconstruct_secret(self, shares: List[Tuple[int, int]]) -> int:
        """使用拉格朗日插值重建秘密

        Args:
            shares: 份额列表，每个份额为 (x, f(x)) 元组

        Returns:
            重建的秘密

        Raises:
            ValueError: 如果份额数量不足
        """
        if len(shares) < self.threshold:
            raise ValueError(
                f"Need at least {self.threshold} shares, got {len(shares)}"
            )

        secret = 0
        for i, (xi, yi) in enumerate(shares[:self.threshold]):
            # 计算拉格朗日基多项式
            numerator = 1
            denominator = 1
            for j, (xj, _) in enumerate(shares[:self.threshold]):
                if i != j:
                    numerator = (numerator * (-xj)) % self.PRIME
                    denominator = (denominator * (xi - xj)) % self.PRIME

            # 拉格朗日插值
            lagrange = (yi * numerator * self._modular_inverse(denominator, self.PRIME)) % self.PRIME
            secret = (secret + lagrange) % self.PRIME

        return secret

    async def split_message(
        self,
        message: bytes,
        message_id: Optional[str] = None,
    ) -> List[MessageFragment]:
        """将消息拆分为多个分片

        先将消息按大小分片，再对每个分片应用秘密共享。

        Args:
            message: 要拆分的消息
            message_id: 可选的消息ID

        Returns:
            分片列表
        """
        if message_id is None:
            message_id = base64.b64encode(os.urandom(12)).decode("ascii")[:16]

        self._stats["messages_split"] += 1
        self._stats["bytes_split"] += len(message)

        # 步骤1: 按大小分片
        data_chunks: List[bytes] = []
        offset = 0
        while offset < len(message):
            chunk = message[offset:offset + self.max_fragment_size]
            data_chunks.append(chunk)
            offset += len(chunk)

        # 步骤2: 对每个数据块应用秘密共享
        all_fragments: List[MessageFragment] = []
        for chunk_index, chunk in enumerate(data_chunks):
            # 将字节转换为整数（用于秘密共享）
            chunk_int = int.from_bytes(chunk, "big")

            # 生成秘密共享份额
            shares = self._share_secret(chunk_int)

            # 为每个份额创建分片
            for share_x, share_y in shares:
                fragment_id = f"{message_id}-chunk{chunk_index}-share{share_x}"
                fragment = MessageFragment(
                    fragment_id=fragment_id,
                    message_id=message_id,
                    index=chunk_index,
                    total_fragments=len(data_chunks),
                    data=share_y.to_bytes(
                        (share_y.bit_length() + 7) // 8, "big"
                    ) if share_y > 0 else b"\x00",
                    secret_share=share_y.to_bytes(16, "big"),
                    path_id=f"path-{share_x}",
                    status=FragmentStatus.CREATED,
                )
                all_fragments.append(fragment)
                self._stats["fragments_created"] += 1

        # 初始化待重组分片存储
        self._pending_fragments[message_id] = {}

        logger.info(
            "Message split: id=%s, %d chunks -> %d fragments (threshold=%d)",
            message_id, len(data_chunks), len(all_fragments), self.threshold
        )

        return all_fragments

    async def deliver_fragment(
        self,
        fragment: MessageFragment,
    ) -> bool:
        """模拟分片传输

        模拟分片通过网络传输到出口节点。

        Args:
            fragment: 要传输的分片

        Returns:
            传输是否成功
        """
        # 模拟传输（95%成功率）
        success = random.random() < 0.95

        if success:
            fragment.status = FragmentStatus.DELIVERED
            self._stats["fragments_delivered"] += 1

            # 存储已送达的分片
            if fragment.message_id not in self._pending_fragments:
                self._pending_fragments[fragment.message_id] = {}
            self._pending_fragments[fragment.message_id][fragment.index] = fragment
        else:
            fragment.status = FragmentStatus.LOST
            self._stats["fragments_lost"] += 1
            logger.warning("Fragment lost: %s", fragment.fragment_id)

        # 模拟传输延迟
        await asyncio.sleep(random.uniform(0.01, 0.1))

        return success

    async def reassemble_message(
        self,
        message_id: str,
        fragments: Optional[List[MessageFragment]] = None,
    ) -> Optional[bytes]:
        """重组消息

        从已送达的分片中重建原始消息。

        Args:
            message_id: 消息ID
            fragments: 可选的分片列表（如果提供则使用这些分片）

        Returns:
            重组的消息，如果分片不足则返回None
        """
        # 收集分片
        pending = self._pending_fragments.get(message_id, {})
        if fragments:
            for frag in fragments:
                if frag.status == FragmentStatus.DELIVERED:
                    pending[frag.index] = frag

        if not pending:
            logger.warning("No fragments available for message %s", message_id)
            return None

        # 检查是否有足够的分片
        total_chunks = max(f.total_fragments for f in pending.values())
        available_chunks = set(pending.keys())

        if len(available_chunks) < self.threshold:
            logger.warning(
                "Not enough fragments for message %s: %d/%d needed",
                message_id, len(available_chunks), self.threshold
            )
            return None

        # 重组每个数据块
        reconstructed_chunks: Dict[int, bytes] = {}
        for chunk_index in sorted(available_chunks):
            fragment = pending[chunk_index]
            # 将秘密共享份额转换回整数
            share_int = int.from_bytes(fragment.secret_share, "big")
            reconstructed_chunks[chunk_index] = share_int.to_bytes(
                self.max_fragment_size, "big"
            ).lstrip(b"\x00")

        # 按顺序拼接
        message = b""
        for i in range(total_chunks):
            if i in reconstructed_chunks:
                message += reconstructed_chunks[i]
            else:
                # 缺失的分片用零填充（实际中应请求重传）
                message += b"\x00" * self.max_fragment_size

        self._completed_messages[message_id] = message
        self._stats["messages_reassembled"] += 1

        # 清理待重组分片
        if message_id in self._pending_fragments:
            del self._pending_fragments[message_id]

        logger.info(
            "Message reassembled: id=%s, size=%d bytes",
            message_id, len(message)
        )

        return message

    def get_stats(self) -> Dict[str, int]:
        """获取流量拆分器的统计信息

        Returns:
            包含各项统计计数的字典
        """
        return self._stats.copy()


# ============================================================================
# 随机包插入与删除器 / Packet Shuffler
# ============================================================================

class PacketShuffler:
    """随机包插入与删除器

    通过在Mix节点中随机插入虚假包、注入随机延迟、批量处理和厚混技术，
    使输入流量和输出流量之间完全不相关，从而抵御流量关联攻击。

    Features:
        - Mix节点随机插入虚假包
        - 随机延迟注入
        - 批量处理（batching）
        - 厚混（thick mixing）

    Example:
        >>> shuffler = PacketShuffler(batch_size=25, dummy_rate=0.3)
        >>> shuffled = await shuffler.shuffle_packets([b"msg1", b"msg2", b"msg3"])
    """

    def __init__(
        self,
        batch_size: int = 25,
        dummy_rate: float = 0.3,
        min_delay: float = 0.1,
        max_delay: float = 1.0,
        thick_mix_threshold: int = 10,
        enable_cover_traffic: bool = True,
    ) -> None:
        """初始化包洗牌器

        Args:
            batch_size: 批量处理大小
            dummy_rate: 虚假包插入率（0.0-1.0）
            min_delay: 最小延迟（秒）
            max_delay: 最大延迟（秒）
            thick_mix_threshold: 厚混阈值（低于此数量不发送）
            enable_cover_traffic: 是否启用掩护流量
        """
        if not 0.0 <= dummy_rate <= 1.0:
            raise ValueError(f"dummy_rate must be between 0.0 and 1.0, got {dummy_rate}")

        self.batch_size = batch_size
        self.dummy_rate = dummy_rate
        self.min_delay = min_delay
        self.max_delay = max_delay
        self.thick_mix_threshold = thick_mix_threshold
        self.enable_cover_traffic = enable_cover_traffic

        # 批次管理
        self._current_batch: List[ShuffledPacket] = []
        self._batch_counter: int = 0

        # 统计信息
        self._stats: Dict[str, int] = {
            "packets_received": 0,
            "packets_output": 0,
            "dummy_packets_inserted": 0,
            "packets_dropped": 0,
            "batches_processed": 0,
            "total_delay_ms": 0,
        }

        logger.info(
            "PacketShuffler initialized: batch=%d, dummy_rate=%.1f, "
            "delay=[%.1f-%.1f]s",
            batch_size, dummy_rate, min_delay, max_delay
        )

    def _generate_dummy_packet(self, batch_id: str) -> ShuffledPacket:
        """生成虚假数据包

        生成与真实包大小相似的虚假包，用于掩护流量。

        Args:
            batch_id: 所属批次ID

        Returns:
            虚假数据包对象
        """
        # 虚假包大小与真实包大小分布一致
        dummy_size = random.choice([
            random.randint(64, 256),    # 小包
            random.randint(256, 1024),  # 中包
            random.randint(1024, 1400), # 大包
        ])

        dummy = ShuffledPacket(
            packet_id=f"dummy-{base64.b64encode(os.urandom(8)).decode('ascii')[:12]}",
            payload=os.urandom(dummy_size),
            is_dummy=True,
            original_order=-1,
            batch_id=batch_id,
        )
        return dummy

    async def shuffle_packets(
        self,
        packets: List[bytes],
    ) -> List[ShuffledPacket]:
        """对数据包进行洗牌处理

        包含以下步骤:
        1. 插入虚假包
        2. 随机延迟注入
        3. 随机排序（Fisher-Yates洗牌）
        4. 批量输出

        Args:
            packets: 输入数据包列表

        Returns:
            洗牌后的数据包列表
        """
        self._stats["packets_received"] += len(packets)
        self._batch_counter += 1
        batch_id = f"batch-{self._batch_counter}"

        # 步骤1: 将输入包转换为ShuffledPacket
        shuffled: List[ShuffledPacket] = []
        for i, packet in enumerate(packets):
            sp = ShuffledPacket(
                packet_id=f"pkt-{base64.b64encode(os.urandom(8)).decode('ascii')[:12]}",
                payload=packet,
                is_dummy=False,
                original_order=i,
                batch_id=batch_id,
            )
            shuffled.append(sp)

        # 步骤2: 插入虚假包
        if self.enable_cover_traffic:
            num_dummies = int(len(packets) * self.dummy_rate)
            # 至少插入1个虚假包
            num_dummies = max(1, num_dummies)
            for _ in range(num_dummies):
                dummy = self._generate_dummy_packet(batch_id)
                shuffled.append(dummy)
                self._stats["dummy_packets_inserted"] += 1

        # 步骤3: 为每个包注入随机延迟
        for sp in shuffled:
            sp.delay_ms = random.uniform(self.min_delay, self.max_delay) * 1000
            self._stats["total_delay_ms"] += sp.delay_ms

        # 步骤4: Fisher-Yates洗牌算法
        for i in range(len(shuffled) - 1, 0, -1):
            j = random.randint(0, i)
            shuffled[i], shuffled[j] = shuffled[j], shuffled[i]

        # 更新洗牌后的顺序
        for i, sp in enumerate(shuffled):
            sp.shuffled_order = i

        # 步骤5: 厚混检查
        if len(shuffled) < self.thick_mix_threshold:
            # 如果包数量不足厚混阈值，等待或生成更多虚假包
            additional_dummies = self.thick_mix_threshold - len(shuffled)
            for _ in range(additional_dummies):
                dummy = self._generate_dummy_packet(batch_id)
                dummy.shuffled_order = len(shuffled)
                shuffled.append(dummy)
                self._stats["dummy_packets_inserted"] += 1

        # 步骤6: 模拟批量处理延迟
        processing_delay = random.uniform(self.min_delay, self.max_delay)
        await asyncio.sleep(processing_delay)

        self._stats["packets_output"] += len(shuffled)
        self._stats["batches_processed"] += 1

        # 移除虚假包（在出口端）
        real_packets = [sp for sp in shuffled if not sp.is_dummy]
        dummy_packets = [sp for sp in shuffled if sp.is_dummy]

        logger.info(
            "Batch %s shuffled: %d input + %d dummy = %d output "
            "(%d real, %d dummy)",
            batch_id, len(packets), len(dummy_packets),
            len(shuffled), len(real_packets), len(dummy_packets)
        )

        return shuffled

    async def process_single_packet(
        self,
        packet: bytes,
    ) -> ShuffledPacket:
        """处理单个数据包（立即模式）

        在非批量模式下处理单个包，仍会注入延迟和可能的虚假包。

        Args:
            packet: 输入数据包

        Returns:
            处理后的数据包
        """
        self._stats["packets_received"] += 1

        # 注入随机延迟
        delay = random.uniform(self.min_delay, self.max_delay)
        await asyncio.sleep(delay)

        # 随机决定是否丢弃（模拟网络丢包）
        if random.random() < 0.01:  # 1%丢包率
            self._stats["packets_dropped"] += 1
            dummy = ShuffledPacket(
                packet_id=f"dropped-{base64.b64encode(os.urandom(8)).decode('ascii')[:12]}",
                payload=os.urandom(len(packet)),
                is_dummy=True,
            )
            return dummy

        sp = ShuffledPacket(
            packet_id=f"pkt-{base64.b64encode(os.urandom(8)).decode('ascii')[:12]}",
            payload=packet,
            is_dummy=False,
            delay_ms=delay * 1000,
        )

        self._stats["packets_output"] += 1
        return sp

    def get_stats(self) -> Dict[str, int]:
        """获取包洗牌器的统计信息

        Returns:
            包含各项统计计数的字典
        """
        stats = self._stats.copy()
        stats["avg_delay_ms"] = (
            stats["total_delay_ms"] / max(stats["packets_output"], 1)
        )
        return stats


# ============================================================================
# 诱饵节点管理器 / Decoy Node Manager
# ============================================================================

class DecoyNodeManager:
    """诱饵节点管理器

    部署和管理虚假的Mix节点，生成虚假流量以迷惑攻击者，
    并分析攻击者行为模式以优化防御策略。

    Features:
        - 诱饵节点部署策略
        - 虚假流量生成
        - 诱饵节点生命周期管理
        - 攻击者行为分析

    Example:
        >>> manager = DecoyNodeManager(num_decoys=10)
        >>> await manager.initialize()
        >>> await manager.generate_decoy_traffic(duration=60)
    """

    # 攻击者行为模式
    ATTACK_PATTERNS: Dict[str, Dict[str, Any]] = {
        "timing_analysis": {
            "description": "时序分析攻击",
            "detection_threshold": 0.85,
            "severity": "high",
        },
        "volume_analysis": {
            "description": "流量量分析攻击",
            "detection_threshold": 0.80,
            "severity": "medium",
        },
        "packet_size_analysis": {
            "description": "包大小分析攻击",
            "detection_threshold": 0.75,
            "severity": "medium",
        },
        "correlation_attack": {
            "description": "流量关联攻击",
            "detection_threshold": 0.90,
            "severity": "critical",
        },
        "active_probe": {
            "description": "主动探测攻击",
            "detection_threshold": 0.70,
            "severity": "high",
        },
    }

    def __init__(
        self,
        num_decoys: int = 10,
        traffic_rate: float = 1.0,
        decoy_lifetime: float = 3600.0,
        max_decoys: int = 50,
    ) -> None:
        """初始化诱饵节点管理器

        Args:
            num_decoys: 初始诱饵节点数量
            traffic_rate: 虚假流量生成速率（相对于真实流量的倍数）
            decoy_lifetime: 诱饵节点默认生命周期（秒）
            max_decoys: 最大诱饵节点数量
        """
        self.num_decoys = num_decoys
        self.traffic_rate = traffic_rate
        self.decoy_lifetime = decoy_lifetime
        self.max_decoys = max_decoys

        # 诱饵节点管理
        self._decoy_nodes: Dict[str, MixNode] = {}
        self._decoy_stats: Dict[str, DecoyNodeStats] = {}

        # 攻击检测
        self._attack_log: List[Dict[str, Any]] = []
        self._behavior_profile: Dict[str, float] = {}

        # 运行状态
        self._is_running: bool = False
        self._management_task: Optional[asyncio.Task[None]] = None

        # 统计信息
        self._stats: Dict[str, int] = {
            "decoys_deployed": 0,
            "decoys_retired": 0,
            "attacks_detected": 0,
            "probes_absorbed": 0,
            "decoy_traffic_bytes": 0,
        }

        logger.info(
            "DecoyNodeManager initialized: num_decoys=%d, "
            "traffic_rate=%.1f, lifetime=%.0fs",
            num_decoys, traffic_rate, decoy_lifetime
        )

    async def initialize(self) -> None:
        """初始化诱饵节点管理器

        部署初始的诱饵节点。
        """
        countries = [
            "US", "DE", "NL", "CH", "SE", "NO", "RO", "IS",
            "LU", "FI", "JP", "SG", "AU", "CA", "BR", "KR",
        ]

        for i in range(self.num_decoys):
            node_id = f"decoy-{i:04d}"
            country = random.choice(countries)

            node = MixNode(
                node_id=node_id,
                node_type=NodeType.DECOY,
                address=f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}:{random.randint(9000, 65535)}",
                public_key=base64.b64encode(os.urandom(32)).decode("ascii"),
                bandwidth=random.randint(1048576, 52428800),
                latency=random.uniform(10, 150),
                is_active=True,
                country_code=country,
                uptime=0.0,
                trust_score=random.randint(20, 60),  # 诱饵节点信任分数较低
            )

            self._decoy_nodes[node_id] = node
            self._decoy_stats[node_id] = DecoyNodeStats(node_id=node_id)
            self._stats["decoys_deployed"] += 1

        logger.info(
            "DecoyNodeManager initialized: %d decoy nodes deployed",
            len(self._decoy_nodes)
        )

    async def deploy_decoy(
        self,
        country_code: Optional[str] = None,
        bandwidth: Optional[int] = None,
    ) -> MixNode:
        """部署新的诱饵节点

        Args:
            country_code: 指定部署国家
            bandwidth: 指定带宽

        Returns:
            部署的诱饵节点

        Raises:
            RuntimeError: 如果已达到最大诱饵节点数
        """
        if len(self._decoy_nodes) >= self.max_decoys:
            raise RuntimeError(
                f"Maximum number of decoy nodes ({self.max_decoys}) reached"
            )

        node_id = f"decoy-{len(self._decoy_nodes):04d}"
        if country_code is None:
            countries = ["US", "DE", "NL", "CH", "SE", "NO", "RO", "IS"]
            country_code = random.choice(countries)

        node = MixNode(
            node_id=node_id,
            node_type=NodeType.DECOY,
            address=f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}:{random.randint(9000, 65535)}",
            public_key=base64.b64encode(os.urandom(32)).decode("ascii"),
            bandwidth=bandwidth or random.randint(1048576, 52428800),
            latency=random.uniform(10, 150),
            is_active=True,
            country_code=country_code,
            trust_score=random.randint(20, 60),
        )

        self._decoy_nodes[node_id] = node
        self._decoy_stats[node_id] = DecoyNodeStats(node_id=node_id)
        self._stats["decoys_deployed"] += 1

        logger.info("Decoy node deployed: %s (%s)", node_id, country_code)
        return node

    async def retire_decoy(self, node_id: str) -> bool:
        """退役诱饵节点

        将指定的诱饵节点标记为非活跃并从池中移除。

        Args:
            node_id: 要退役的节点ID

        Returns:
            是否成功退役
        """
        node = self._decoy_nodes.get(node_id)
        if node is None:
            logger.warning("Decoy node not found: %s", node_id)
            return False

        node.is_active = False
        del self._decoy_nodes[node_id]
        self._stats["decoys_retired"] += 1

        logger.info("Decoy node retired: %s", node_id)
        return True

    async def generate_decoy_traffic(
        self,
        duration_seconds: float = 10.0,
        packets_per_second: float = 10.0,
    ) -> Dict[str, Any]:
        """生成虚假流量

        模拟诱饵节点产生正常的网络流量，以迷惑攻击者。

        Args:
            duration_seconds: 流量生成持续时间（秒）
            packets_per_second: 每秒包数

        Returns:
            包含流量生成统计的字典
        """
        total_packets = int(duration_seconds * packets_per_second)
        total_bytes = 0
        packets_per_node: Dict[str, int] = {}

        active_decoys = {
            nid: node for nid, node in self._decoy_nodes.items()
            if node.is_active
        }

        if not active_decoys:
            logger.warning("No active decoy nodes for traffic generation")
            return {"total_packets": 0, "total_bytes": 0}

        for _ in range(min(total_packets, 100)):  # 限制模拟包数
            # 随机选择诱饵节点
            node_id = random.choice(list(active_decoys.keys()))
            node = active_decoys[node_id]

            # 生成模拟流量包
            packet_size = random.choice([
                random.randint(64, 256),
                random.randint(256, 1024),
                random.randint(1024, 1400),
            ])

            total_bytes += packet_size
            packets_per_node[node_id] = packets_per_node.get(node_id, 0) + 1

            # 更新节点统计
            if node_id in self._decoy_stats:
                self._decoy_stats[node_id].traffic_generated += packet_size
                self._decoy_stats[node_id].connections_accepted += 1
                self._decoy_stats[node_id].last_activity = time.time()

        self._stats["decoy_traffic_bytes"] += total_bytes

        # 模拟流量生成时间
        await asyncio.sleep(min(duration_seconds, 0.5))

        logger.info(
            "Decoy traffic generated: %d packets, %d bytes across %d nodes",
            min(total_packets, 100), total_bytes, len(packets_per_node)
        )

        return {
            "total_packets": min(total_packets, 100),
            "total_bytes": total_bytes,
            "active_nodes": len(active_decoys),
            "packets_per_node": packets_per_node,
        }

    def detect_attack(
        self,
        traffic_pattern: Dict[str, Any],
    ) -> Dict[str, Any]:
        """检测潜在的攻击行为

        分析流量模式，检测是否存在已知的攻击模式。

        Args:
            traffic_pattern: 流量模式数据，包含:
                - timing_variance: 时序方差
                - volume_anomaly: 流量异常分数
                - packet_size_variance: 包大小方差
                - correlation_score: 关联分数
                - probe_frequency: 探测频率

        Returns:
            包含检测结果和建议的字典
        """
        detections: List[Dict[str, Any]] = []

        # 时序分析攻击检测
        timing_variance = traffic_pattern.get("timing_variance", 0.0)
        if timing_variance > 0.85:
            detections.append({
                "attack_type": "timing_analysis",
                "severity": "high",
                "confidence": timing_variance,
                "description": "Detected potential timing analysis attack",
                "recommendation": "Increase random delay range",
            })

        # 流量量分析攻击检测
        volume_anomaly = traffic_pattern.get("volume_anomaly", 0.0)
        if volume_anomaly > 0.80:
            detections.append({
                "attack_type": "volume_analysis",
                "severity": "medium",
                "confidence": volume_anomaly,
                "description": "Detected potential volume analysis attack",
                "recommendation": "Increase dummy packet rate",
            })

        # 包大小分析攻击检测
        size_variance = traffic_pattern.get("packet_size_variance", 0.0)
        if size_variance > 0.75:
            detections.append({
                "attack_type": "packet_size_analysis",
                "severity": "medium",
                "confidence": size_variance,
                "description": "Detected potential packet size analysis",
                "recommendation": "Pad all packets to uniform size",
            })

        # 流量关联攻击检测
        correlation = traffic_pattern.get("correlation_score", 0.0)
        if correlation > 0.90:
            detections.append({
                "attack_type": "correlation_attack",
                "severity": "critical",
                "confidence": correlation,
                "description": "Detected potential traffic correlation attack",
                "recommendation": "Increase batch size and mixing delay",
            })

        # 主动探测检测
        probe_freq = traffic_pattern.get("probe_frequency", 0.0)
        if probe_freq > 0.70:
            detections.append({
                "attack_type": "active_probe",
                "severity": "high",
                "confidence": probe_freq,
                "description": "Detected potential active probing",
                "recommendation": "Deploy additional decoy nodes",
            })
            self._stats["probes_absorbed"] += 1

        # 记录检测结果
        for detection in detections:
            self._attack_log.append({
                **detection,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            self._stats["attacks_detected"] += 1

        # 更新行为画像
        self._update_behavior_profile(traffic_pattern)

        # 总体威胁评估
        max_severity = "none"
        severity_order = ["none", "low", "medium", "high", "critical"]
        for det in detections:
            if severity_order.index(det["severity"]) > severity_order.index(max_severity):
                max_severity = det["severity"]

        return {
            "threat_level": max_severity,
            "detections": detections,
            "total_detections": len(detections),
            "recommendations": [d["recommendation"] for d in detections],
        }

    def _update_behavior_profile(
        self,
        traffic_pattern: Dict[str, Any],
    ) -> None:
        """更新攻击者行为画像

        基于检测到的流量模式更新攻击者的行为画像。

        Args:
            traffic_pattern: 流量模式数据
        """
        for key, value in traffic_pattern.items():
            if isinstance(value, (int, float)):
                if key in self._behavior_profile:
                    # 指数移动平均
                    alpha = 0.3
                    self._behavior_profile[key] = (
                        alpha * value + (1 - alpha) * self._behavior_profile[key]
                    )
                else:
                    self._behavior_profile[key] = value

    async def start_management(self) -> None:
        """启动诱饵节点自动管理

        定期检查节点健康状态、轮换节点和生成虚假流量。
        """
        if self._is_running:
            logger.warning("Decoy node management is already running")
            return

        self._is_running = True
        logger.info("Starting decoy node management")

        while self._is_running:
            try:
                # 更新节点运行时间
                now = time.time()
                for node_id, stats in self._decoy_stats.items():
                    stats.uptime = now - stats.last_activity

                # 检查并退役过期节点
                expired_nodes = [
                    nid for nid, stats in self._decoy_stats.items()
                    if stats.uptime > self.decoy_lifetime
                ]
                for node_id in expired_nodes:
                    await self.retire_decoy(node_id)

                # 补充诱饵节点
                while len(self._decoy_nodes) < self.num_decoys:
                    await self.deploy_decoy()

                # 生成虚假流量
                await self.generate_decoy_traffic(
                    duration_seconds=5.0,
                    packets_per_second=5.0 * self.traffic_rate,
                )

                await asyncio.sleep(30.0)  # 每30秒检查一次

            except asyncio.CancelledError:
                logger.info("Decoy node management cancelled")
                break
            except Exception as e:
                logger.error("Error in decoy management: %s", e)
                await asyncio.sleep(30.0)

    async def stop_management(self) -> None:
        """停止诱饵节点自动管理"""
        self._is_running = False
        if self._management_task is not None:
            self._management_task.cancel()
            try:
                await self._management_task
            except asyncio.CancelledError:
                pass
            self._management_task = None
        logger.info("Decoy node management stopped")

    def get_attack_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取攻击检测日志

        Args:
            limit: 返回的最大条目数

        Returns:
            攻击检测日志列表
        """
        return self._attack_log[-limit:]

    def get_behavior_profile(self) -> Dict[str, float]:
        """获取攻击者行为画像

        Returns:
            行为画像字典
        """
        return self._behavior_profile.copy()

    def get_stats(self) -> Dict[str, int]:
        """获取诱饵节点管理器的统计信息

        Returns:
            包含各项统计计数的字典
        """
        stats = self._stats.copy()
        stats["active_decoys"] = len(self._decoy_nodes)
        return stats

    def get_decoy_nodes(self) -> List[Dict[str, Any]]:
        """获取所有诱饵节点信息

        Returns:
            诱饵节点信息列表
        """
        nodes = []
        for node_id, node in self._decoy_nodes.items():
            info = {
                "node_id": node.node_id,
                "address": node.address,
                "country_code": node.country_code,
                "bandwidth": node.bandwidth,
                "latency_ms": node.latency,
                "trust_score": node.trust_score,
            }
            if node_id in self._decoy_stats:
                stats = self._decoy_stats[node_id]
                info["traffic_generated"] = stats.traffic_generated
                info["connections_accepted"] = stats.connections_accepted
                info["probes_detected"] = stats.probes_detected
            nodes.append(info)
        return nodes


# ============================================================================
# 模块入口测试 / Module Entry Point Test
# ============================================================================

async def _demo() -> None:
    """演示所有组件的基本功能"""
    logging.basicConfig(level=logging.INFO)

    print("=" * 60)
    print("Mixnet V2 - Demo")
    print("=" * 60)

    # 1. OnionMixnetHybrid
    print("\n[1] OnionMixnetHybrid")
    hybrid = OnionMixnetHybrid(security_level=SecurityLevel.HIGH)
    await hybrid.initialize()
    route = await hybrid.build_hybrid_route()
    print(f"  Route: {route.route_id}")
    print(f"  Onion hops: {len(route.onion_hops)}")
    print(f"  Mixnet hops: {len(route.mixnet_hops)}")
    print(f"  Security: {route.security_score}/100")
    print(f"  Latency: {route.estimated_latency:.1f}ms")

    result = await hybrid.send_message(route.route_id, b"Hello through mixnet!")
    print(f"  Sent: {result['message_size']}B in {result['total_time_ms']}ms")

    # 2. TrafficSplitter
    print("\n[2] TrafficSplitter")
    splitter = TrafficSplitter(threshold=3, num_shares=5)
    fragments = await splitter.split_message(b"Secret message for splitting")
    print(f"  Split: {len(fragments)} fragments")
    print(f"  Threshold: {splitter.threshold}, Shares: {splitter.num_shares}")

    # 模拟传输
    for frag in fragments[:splitter.threshold]:  # 只传输足够的分片
        await splitter.deliver_fragment(frag)

    recovered = await splitter.reassemble_message(fragments[0].message_id)
    if recovered:
        print(f"  Reassembled: {len(recovered)} bytes")

    # 3. PacketShuffler
    print("\n[3] PacketShuffler")
    shuffler = PacketShuffler(batch_size=10, dummy_rate=0.3)
    packets = [f"Message {i}".encode() for i in range(5)]
    shuffled = await shuffler.shuffle_packets(packets)
    real = [s for s in shuffled if not s.is_dummy]
    dummy = [s for s in shuffled if s.is_dummy]
    print(f"  Input: {len(packets)} packets")
    print(f"  Output: {len(real)} real + {len(dummy)} dummy = {len(shuffled)} total")

    # 4. DecoyNodeManager
    print("\n[4] DecoyNodeManager")
    manager = DecoyNodeManager(num_decoys=5)
    await manager.initialize()
    traffic = await manager.generate_decoy_traffic(duration_seconds=1.0)
    print(f"  Decoy nodes: {traffic['active_nodes']}")
    print(f"  Traffic: {traffic['total_packets']} packets, {traffic['total_bytes']} bytes")

    # 模拟攻击检测
    detection = manager.detect_attack({
        "timing_variance": 0.92,
        "volume_anomaly": 0.45,
        "packet_size_variance": 0.60,
        "correlation_score": 0.95,
        "probe_frequency": 0.30,
    })
    print(f"  Threat level: {detection['threat_level']}")
    print(f"  Detections: {detection['total_detections']}")

    print("\n" + "=" * 60)
    print("Demo completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(_demo())
