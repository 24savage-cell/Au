"""
内存取证模块

提供进程内存dump、字符串提取和密码恢复功能
"""

import asyncio
import hashlib
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


@dataclass
class MemoryDump:
    """内存转储记录"""
    id: UUID
    process_id: int
    process_name: str
    dump_path: str
    size_bytes: int
    hash_md5: str
    hash_sha256: str
    created_at: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class StringMatch:
    """字符串匹配结果"""
    offset: int
    string: str
    encoding: str
    context: str


class MemoryCollector:
    """
    内存收集器
    
    提供内存取证功能：
    - 进程内存dump
    - 字符串提取
    - 密码/密钥恢复
    """
    
    # 常见密码模式
    PASSWORD_PATTERNS = [
        rb'password[=:]\s*(\S+)',
        rb'passwd[=:]\s*(\S+)',
        rb'pwd[=:]\s*(\S+)',
        rb'api[_-]?key[=:]\s*(\S+)',
        rb'secret[=:]\s*(\S+)',
        rb'token[=:]\s*(\S+)',
    ]
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化内存收集器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/memory_dumps")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._dumps: Dict[UUID, MemoryDump] = {}
        self._lock = asyncio.Lock()
        
        logger.info("内存收集器初始化完成")
    
    async def dump_process_memory(
        self,
        process_id: int,
        process_name: Optional[str] = None,
        output_name: Optional[str] = None
    ) -> MemoryDump:
        """
        转储进程内存
        
        Args:
            process_id: 进程ID
            process_name: 进程名称
            output_name: 输出文件名
            
        Returns:
            内存转储记录
        """
        if output_name is None:
            output_name = f"proc_{process_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.dmp"
        
        output_path = self.storage_path / output_name
        
        logger.info(f"开始转储进程内存: PID={process_id}")
        
        try:
            # 模拟内存转储
            # 实际实现中应使用/proc/[pid]/mem或Windows API
            await self._perform_memory_dump(process_id, output_path)
            
            # 计算哈希
            md5_hash, sha256_hash = await self._calculate_hashes(output_path)
            
            # 获取文件大小
            size_bytes = output_path.stat().st_size
            
            dump = MemoryDump(
                id=uuid4(),
                process_id=process_id,
                process_name=process_name or f"process_{process_id}",
                dump_path=str(output_path),
                size_bytes=size_bytes,
                hash_md5=md5_hash,
                hash_sha256=sha256_hash,
                created_at=datetime.utcnow(),
                metadata={
                    "dump_method": "standard",
                    "compression": False,
                },
            )
            
            async with self._lock:
                self._dumps[dump.id] = dump
            
            logger.info(f"内存转储完成: {dump.id} ({size_bytes} bytes)")
            return dump
            
        except Exception as e:
            logger.error(f"内存转储失败: {e}")
            raise
    
    async def _perform_memory_dump(self, process_id: int, output_path: Path) -> None:
        """执行内存转储"""
        # 模拟内存转储过程
        await asyncio.sleep(0.5)
        
        # 创建模拟的内存dump文件
        async with aiofiles.open(output_path, 'wb') as f:
            # 写入模拟数据
            mock_data = b"MOCK_MEMORY_DUMP_" + str(process_id).encode() * 1000
            await f.write(mock_data)
    
    async def _calculate_hashes(self, file_path: Path) -> Tuple[str, str]:
        """计算文件哈希"""
        md5 = hashlib.md5()
        sha256 = hashlib.sha256()
        
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                md5.update(chunk)
                sha256.update(chunk)
        
        return md5.hexdigest(), sha256.hexdigest()
    
    async def extract_strings(
        self,
        dump_id: UUID,
        min_length: int = 4,
        encodings: List[str] = None
    ) -> List[StringMatch]:
        """
        从内存转储中提取字符串
        
        Args:
            dump_id: 转储ID
            min_length: 最小字符串长度
            encodings: 编码列表
            
        Returns:
            字符串匹配列表
        """
        if encodings is None:
            encodings = ['ascii', 'utf-8', 'utf-16']
        
        async with self._lock:
            if dump_id not in self._dumps:
                raise ValueError(f"转储不存在: {dump_id}")
            
            dump = self._dumps[dump_id]
        
        logger.info(f"开始提取字符串: {dump_id}")
        
        strings = []
        
        async with aiofiles.open(dump.dump_path, 'rb') as f:
            data = await f.read()
        
        # ASCII字符串
        if 'ascii' in encodings:
            for match in re.finditer(rb'[\x20-\x7E]{' + str(min_length).encode() + rb',}', data):
                strings.append(StringMatch(
                    offset=match.start(),
                    string=match.group().decode('ascii', errors='ignore'),
                    encoding='ascii',
                    context=data[max(0, match.start()-20):match.end()+20].decode('ascii', errors='ignore'),
                ))
        
        logger.info(f"字符串提取完成: {len(strings)} 个")
        return strings
    
    async def search_credentials(
        self,
        dump_id: UUID
    ) -> List[Dict[str, Any]]:
        """
        搜索凭证信息
        
        Args:
            dump_id: 转储ID
            
        Returns:
            凭证列表
        """
        async with self._lock:
            if dump_id not in self._dumps:
                raise ValueError(f"转储不存在: {dump_id}")
            
            dump = self._dumps[dump_id]
        
        logger.info(f"开始搜索凭证: {dump_id}")
        
        credentials = []
        
        async with aiofiles.open(dump.dump_path, 'rb') as f:
            data = await f.read()
        
        for pattern in self.PASSWORD_PATTERNS:
            for match in re.finditer(pattern, data, re.IGNORECASE):
                credentials.append({
                    "type": "password_pattern",
                    "offset": match.start(),
                    "value": match.group().decode('utf-8', errors='ignore'),
                    "pattern": pattern.decode('utf-8'),
                })
        
        logger.info(f"凭证搜索完成: {len(credentials)} 个")
        return credentials
    
    async def analyze_dump(self, dump_id: UUID) -> Dict[str, Any]:
        """
        分析内存转储
        
        Args:
            dump_id: 转储ID
            
        Returns:
            分析结果
        """
        async with self._lock:
            if dump_id not in self._dumps:
                raise ValueError(f"转储不存在: {dump_id}")
            
            dump = self._dumps[dump_id]
        
        # 提取字符串
        strings = await self.extract_strings(dump_id)
        
        # 搜索凭证
        credentials = await self.search_credentials(dump_id)
        
        return {
            "dump_id": str(dump_id),
            "process_id": dump.process_id,
            "process_name": dump.process_name,
            "size_bytes": dump.size_bytes,
            "analysis_time": datetime.utcnow().isoformat(),
            "strings_extracted": len(strings),
            "credentials_found": len(credentials),
            "credentials": credentials,
        }
    
    async def get_dump_info(self, dump_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取转储信息
        
        Args:
            dump_id: 转储ID
            
        Returns:
            转储信息
        """
        async with self._lock:
            if dump_id not in self._dumps:
                return None
            
            dump = self._dumps[dump_id]
            
            return {
                "id": str(dump.id),
                "process_id": dump.process_id,
                "process_name": dump.process_name,
                "dump_path": dump.dump_path,
                "size_bytes": dump.size_bytes,
                "hash_md5": dump.hash_md5,
                "hash_sha256": dump.hash_sha256,
                "created_at": dump.created_at.isoformat(),
            }
