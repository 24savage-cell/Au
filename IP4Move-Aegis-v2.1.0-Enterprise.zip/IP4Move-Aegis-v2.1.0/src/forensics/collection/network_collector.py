"""
网络取证模块

提供流量捕获、PCAP分析和会话重建功能
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class ProtocolType(Enum):
    """协议类型"""
    TCP = "tcp"
    UDP = "udp"
    ICMP = "icmp"
    HTTP = "http"
    HTTPS = "https"
    DNS = "dns"
    FTP = "ftp"
    SSH = "ssh"


@dataclass
class NetworkCapture:
    """网络捕获记录"""
    id: UUID
    interface: str
    capture_path: str
    start_time: datetime
    end_time: Optional[datetime]
    packet_count: int
    size_bytes: int
    filter_expression: Optional[str]
    hash_md5: str
    hash_sha256: str


@dataclass
class Session:
    """网络会话"""
    id: UUID
    capture_id: UUID
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: ProtocolType
    start_time: datetime
    end_time: Optional[datetime]
    packet_count: int
    byte_count: int
    reconstructed_data: Optional[bytes]


class NetworkCollector:
    """
    网络收集器
    
    提供网络取证功能：
    - 流量捕获
    - PCAP分析
    - 会话重建
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化网络收集器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/network_captures")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._captures: Dict[UUID, NetworkCapture] = {}
        self._sessions: Dict[UUID, List[Session]] = {}
        self._lock = asyncio.Lock()
        
        logger.info("网络收集器初始化完成")
    
    async def start_capture(
        self,
        interface: str = "any",
        filter_expression: Optional[str] = None,
        duration: Optional[int] = None,
        packet_limit: Optional[int] = None
    ) -> NetworkCapture:
        """
        开始流量捕获
        
        Args:
            interface: 网络接口
            filter_expression: BPF过滤表达式
            duration: 捕获持续时间（秒）
            packet_limit: 数据包限制
            
        Returns:
            捕获记录
        """
        capture_id = uuid4()
        capture_path = self.storage_path / f"capture_{capture_id}.pcap"
        
        logger.info(f"开始网络捕获: {interface}")
        
        # 模拟流量捕获
        # 实际实现中应使用pcapy或scapy
        start_time = datetime.utcnow()
        packet_count = 0
        
        try:
            # 模拟捕获过程
            capture_duration = duration or 60
            await asyncio.sleep(min(capture_duration, 5))  # 限制模拟时间
            
            # 创建模拟PCAP文件
            await self._create_mock_pcap(capture_path, packet_limit or 100)
            packet_count = packet_limit or 100
            
            end_time = datetime.utcnow()
            
            # 计算哈希
            md5_hash, sha256_hash = await self._calculate_hashes(capture_path)
            size_bytes = capture_path.stat().st_size
            
            capture = NetworkCapture(
                id=capture_id,
                interface=interface,
                capture_path=str(capture_path),
                start_time=start_time,
                end_time=end_time,
                packet_count=packet_count,
                size_bytes=size_bytes,
                filter_expression=filter_expression,
                hash_md5=md5_hash,
                hash_sha256=sha256_hash,
            )
            
            async with self._lock:
                self._captures[capture.id] = capture
                self._sessions[capture.id] = []
            
            logger.info(f"网络捕获完成: {capture.id} ({packet_count} packets)")
            return capture
            
        except Exception as e:
            logger.error(f"网络捕获失败: {e}")
            raise
    
    async def _create_mock_pcap(self, path: Path, packet_count: int) -> None:
        """创建模拟PCAP文件"""
        # PCAP文件头
        pcap_header = bytes([
            0xa1, 0xb2, 0xc3, 0xd4,  # 魔数
            0x00, 0x02,              # 主版本
            0x00, 0x04,              # 次版本
            0x00, 0x00, 0x00, 0x00,  # 时区
            0x00, 0x00, 0x00, 0x00,  # 时间戳精度
            0x00, 0x00, 0x00, 0xff,  # 快照长度
            0x00, 0x00, 0x00, 0x01,  # 链路类型 (Ethernet)
        ])
        
        async with aiofiles.open(path, 'wb') as f:
            await f.write(pcap_header)
            
            # 写入模拟数据包
            for i in range(packet_count):
                packet_data = b"MOCK_PACKET_" + str(i).encode() * 10
                
                # 数据包头
                ts_sec = int(datetime.utcnow().timestamp())
                ts_usec = 0
                incl_len = len(packet_data)
                orig_len = len(packet_data)
                
                header = (
                    ts_sec.to_bytes(4, 'little') +
                    ts_usec.to_bytes(4, 'little') +
                    incl_len.to_bytes(4, 'little') +
                    orig_len.to_bytes(4, 'little')
                )
                
                await f.write(header)
                await f.write(packet_data)
    
    async def _calculate_hashes(self, file_path: Path) -> Tuple[str, str]:
        """计算文件哈希"""
        md5 = hashlib.md5()
        sha256 = hashlib.sha256()
        
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                md5.update(chunk)
                sha256.update(chunk)
        
        return md5.hexdigest(), sha256.hexdigest()
    
    async def analyze_pcap(self, capture_id: UUID) -> Dict[str, Any]:
        """
        分析PCAP文件
        
        Args:
            capture_id: 捕获ID
            
        Returns:
            分析结果
        """
        async with self._lock:
            if capture_id not in self._captures:
                raise ValueError(f"捕获不存在: {capture_id}")
            
            capture = self._captures[capture_id]
        
        logger.info(f"开始分析PCAP: {capture_id}")
        
        # 模拟PCAP分析
        analysis = {
            "capture_id": str(capture_id),
            "analysis_time": datetime.utcnow().isoformat(),
            "total_packets": capture.packet_count,
            "duration_seconds": (capture.end_time - capture.start_time).total_seconds() if capture.end_time else 0,
            "protocol_distribution": {
                "TCP": int(capture.packet_count * 0.7),
                "UDP": int(capture.packet_count * 0.2),
                "ICMP": int(capture.packet_count * 0.05),
                "Other": int(capture.packet_count * 0.05),
            },
            "top_talkers": [
                {"ip": "192.168.1.100", "packets": 500},
                {"ip": "192.168.1.1", "packets": 300},
                {"ip": "8.8.8.8", "packets": 200},
            ],
            "suspicious_activity": [
                {"type": "port_scan", "source": "10.0.0.5", "target": "192.168.1.100"},
            ],
        }
        
        logger.info(f"PCAP分析完成: {capture_id}")
        return analysis
    
    async def reconstruct_sessions(self, capture_id: UUID) -> List[Session]:
        """
        重建网络会话
        
        Args:
            capture_id: 捕获ID
            
        Returns:
            会话列表
        """
        async with self._lock:
            if capture_id not in self._captures:
                raise ValueError(f"捕获不存在: {capture_id}")
        
        logger.info(f"开始重建会话: {capture_id}")
        
        # 模拟会话重建
        sessions = []
        
        for i in range(10):  # 模拟10个会话
            session = Session(
                id=uuid4(),
                capture_id=capture_id,
                src_ip=f"192.168.1.{100 + i}",
                dst_ip=f"10.0.0.{i}",
                src_port=50000 + i,
                dst_port=80 if i % 2 == 0 else 443,
                protocol=ProtocolType.TCP,
                start_time=datetime.utcnow(),
                end_time=datetime.utcnow(),
                packet_count=50 + i * 10,
                byte_count=5000 + i * 1000,
                reconstructed_data=b"HTTP/1.1 200 OK\r\n" if i % 2 == 0 else None,
            )
            sessions.append(session)
        
        async with self._lock:
            self._sessions[capture_id] = sessions
        
        logger.info(f"会话重建完成: {len(sessions)} 个会话")
        return sessions
    
    async def extract_files(self, capture_id: UUID) -> List[Dict[str, Any]]:
        """
        从流量中提取文件
        
        Args:
            capture_id: 捕获ID
            
        Returns:
            提取的文件列表
        """
        logger.info(f"开始提取文件: {capture_id}")
        
        # 模拟文件提取
        files = [
            {
                "filename": "document.pdf",
                "size": 102400,
                "source_ip": "192.168.1.100",
                "destination_ip": "10.0.0.5",
                "protocol": "HTTP",
            },
            {
                "filename": "image.jpg",
                "size": 204800,
                "source_ip": "10.0.0.5",
                "destination_ip": "192.168.1.100",
                "protocol": "HTTP",
            },
        ]
        
        logger.info(f"文件提取完成: {len(files)} 个文件")
        return files
