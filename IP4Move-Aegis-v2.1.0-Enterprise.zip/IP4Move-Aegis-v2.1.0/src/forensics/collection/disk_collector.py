"""
磁盘取证模块

提供镜像创建、文件系统分析和已删除文件恢复功能
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class FileSystemType(Enum):
    """文件系统类型"""
    NTFS = "ntfs"
    FAT32 = "fat32"
    EXT4 = "ext4"
    EXT3 = "ext3"
    HFS = "hfs"
    APFS = "apfs"
    EXFAT = "exfat"


@dataclass
class DiskImage:
    """磁盘镜像记录"""
    id: UUID
    source_device: str
    image_path: str
    size_bytes: int
    hash_md5: str
    hash_sha256: str
    filesystem_type: Optional[FileSystemType]
    created_at: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RecoveredFile:
    """恢复的文件"""
    id: UUID
    image_id: UUID
    filename: str
    original_path: Optional[str]
    size_bytes: int
    recovered_at: datetime
    integrity_verified: bool


class DiskCollector:
    """
    磁盘收集器
    
    提供磁盘取证功能：
    - 磁盘镜像创建
    - 文件系统分析
    - 已删除文件恢复
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化磁盘收集器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/disk_images")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._images: Dict[UUID, DiskImage] = {}
        self._recovered_files: Dict[UUID, List[RecoveredFile]] = {}
        self._lock = asyncio.Lock()
        
        logger.info("磁盘收集器初始化完成")
    
    async def create_disk_image(
        self,
        source_device: str,
        image_name: Optional[str] = None,
        compress: bool = True
    ) -> DiskImage:
        """
        创建磁盘镜像
        
        Args:
            source_device: 源设备路径
            image_name: 镜像名称
            compress: 是否压缩
            
        Returns:
            磁盘镜像记录
        """
        if image_name is None:
            image_name = f"disk_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.img"
        
        if compress and not image_name.endswith('.gz'):
            image_name += '.gz'
        
        output_path = self.storage_path / image_name
        
        logger.info(f"开始创建磁盘镜像: {source_device} -> {output_path}")
        
        try:
            # 模拟磁盘镜像创建
            # 实际实现中应使用dd或专用工具
            await self._perform_disk_imaging(source_device, output_path, compress)
            
            # 计算哈希
            md5_hash, sha256_hash = await self._calculate_hashes(output_path)
            
            # 获取文件大小
            size_bytes = output_path.stat().st_size
            
            # 检测文件系统类型
            filesystem_type = await self._detect_filesystem(output_path)
            
            image = DiskImage(
                id=uuid4(),
                source_device=source_device,
                image_path=str(output_path),
                size_bytes=size_bytes,
                hash_md5=md5_hash,
                hash_sha256=sha256_hash,
                filesystem_type=filesystem_type,
                created_at=datetime.utcnow(),
                metadata={
                    "compression": compress,
                    "imaging_method": "sector-by-sector",
                },
            )
            
            async with self._lock:
                self._images[image.id] = image
                self._recovered_files[image.id] = []
            
            logger.info(f"磁盘镜像创建完成: {image.id} ({size_bytes} bytes)")
            return image
            
        except Exception as e:
            logger.error(f"磁盘镜像创建失败: {e}")
            raise
    
    async def _perform_disk_imaging(
        self,
        source_device: str,
        output_path: Path,
        compress: bool
    ) -> None:
        """执行磁盘镜像"""
        # 模拟磁盘镜像过程
        await asyncio.sleep(1.0)
        
        # 创建模拟的镜像文件
        async with aiofiles.open(output_path, 'wb') as f:
            # 写入模拟数据
            mock_data = b"MOCK_DISK_IMAGE_" + source_device.encode() * 10000
            await f.write(mock_data)
    
    async def _calculate_hashes(self, file_path: Path) -> Tuple[str, str]:
        """计算文件哈希"""
        md5 = hashlib.md5()
        sha256 = hashlib.sha256()
        
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                md5.update(chunk)
                sha256.update(chunk)
        
        return md5.hexdigest(), sha256.hexdigest()
    
    async def _detect_filesystem(self, image_path: Path) -> Optional[FileSystemType]:
        """检测文件系统类型"""
        # 简化实现
        return FileSystemType.EXT4
    
    async def analyze_filesystem(
        self,
        image_id: UUID
    ) -> Dict[str, Any]:
        """
        分析文件系统
        
        Args:
            image_id: 镜像ID
            
        Returns:
            文件系统分析结果
        """
        async with self._lock:
            if image_id not in self._images:
                raise ValueError(f"镜像不存在: {image_id}")
            
            image = self._images[image_id]
        
        logger.info(f"开始分析文件系统: {image_id}")
        
        # 模拟文件系统分析
        analysis = {
            "image_id": str(image_id),
            "filesystem_type": image.filesystem_type.value if image.filesystem_type else "unknown",
            "analysis_time": datetime.utcnow().isoformat(),
            "total_files": 15000,
            "total_directories": 2500,
            "total_size": "45.2 GB",
            "free_space": "12.8 GB",
            "partition_info": {
                "partition_count": 3,
                "partitions": [
                    {"number": 1, "type": "boot", "size": "512 MB"},
                    {"number": 2, "type": "system", "size": "50 GB"},
                    {"number": 3, "type": "data", "size": "200 GB"},
                ],
            },
            "file_types": {
                "documents": 3500,
                "images": 5200,
                "videos": 800,
                "executables": 450,
                "other": 5050,
            },
        }
        
        logger.info(f"文件系统分析完成: {image_id}")
        return analysis
    
    async def recover_deleted_files(
        self,
        image_id: UUID,
        file_types: List[str] = None
    ) -> List[RecoveredFile]:
        """
        恢复已删除文件
        
        Args:
            image_id: 镜像ID
            file_types: 文件类型过滤
            
        Returns:
            恢复的文件列表
        """
        if file_types is None:
            file_types = ['*']
        
        async with self._lock:
            if image_id not in self._images:
                raise ValueError(f"镜像不存在: {image_id}")
        
        logger.info(f"开始恢复已删除文件: {image_id}")
        
        # 模拟文件恢复
        recovered = []
        
        for i in range(5):  # 模拟恢复5个文件
            file = RecoveredFile(
                id=uuid4(),
                image_id=image_id,
                filename=f"recovered_file_{i}.txt",
                original_path=f"/home/user/deleted/file_{i}.txt",
                size_bytes=1024 * (i + 1),
                recovered_at=datetime.utcnow(),
                integrity_verified=True,
            )
            recovered.append(file)
        
        async with self._lock:
            self._recovered_files[image_id].extend(recovered)
        
        logger.info(f"文件恢复完成: {len(recovered)} 个文件")
        return recovered
    
    async def get_image_info(self, image_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取镜像信息
        
        Args:
            image_id: 镜像ID
            
        Returns:
            镜像信息
        """
        async with self._lock:
            if image_id not in self._images:
                return None
            
            image = self._images[image_id]
            
            return {
                "id": str(image.id),
                "source_device": image.source_device,
                "image_path": image.image_path,
                "size_bytes": image.size_bytes,
                "hash_md5": image.hash_md5,
                "hash_sha256": image.hash_sha256,
                "filesystem_type": image.filesystem_type.value if image.filesystem_type else None,
                "created_at": image.created_at.isoformat(),
            }
