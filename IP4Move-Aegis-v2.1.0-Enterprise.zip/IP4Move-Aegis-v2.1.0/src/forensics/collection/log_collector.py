"""
日志取证模块

提供多源日志收集、时间线对齐和完整性验证功能
"""

import asyncio
import hashlib
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


@dataclass
class LogEvidence:
    """日志证据"""
    id: UUID
    source: str
    log_type: str
    file_path: str
    hash_md5: str
    hash_sha256: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    line_count: int
    collected_at: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LogEntry:
    """日志条目"""
    timestamp: datetime
    source: str
    level: str
    message: str
    raw_line: str
    parsed_fields: Dict[str, Any]


class LogCollector:
    """
    日志收集器
    
    提供日志取证功能：
    - 多源日志收集
    - 时间线对齐
    - 完整性验证
    """
    
    # 常见日志格式
    LOG_PATTERNS = {
        "syslog": re.compile(
            r'^(?P<timestamp>\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+'
            r'(?P<host>\S+)\s+(?P<process>\S+):\s+(?P<message>.*)$'
        ),
        "apache": re.compile(
            r'^(?P<ip>\S+)\s+\S+\s+\S+\s+\[(?P<timestamp>[^\]]+)\]\s+'
            r'"(?P<request>[^"]+)"\s+(?P<status>\d+)\s+(?P<size>\d+)'
        ),
        "json": re.compile(r'^\s*\{.*\}\s*$'),
    }
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化日志收集器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/log_evidence")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._evidence: Dict[UUID, LogEvidence] = {}
        self._entries: Dict[UUID, List[LogEntry]] = {}
        self._lock = asyncio.Lock()
        
        logger.info("日志收集器初始化完成")
    
    async def collect_log(
        self,
        source: str,
        log_type: str,
        file_path: Union[str, Path],
        copy_to_storage: bool = True
    ) -> LogEvidence:
        """
        收集日志文件
        
        Args:
            source: 日志来源
            log_type: 日志类型
            file_path: 日志文件路径
            copy_to_storage: 是否复制到存储
            
        Returns:
            日志证据记录
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"日志文件不存在: {file_path}")
        
        logger.info(f"开始收集日志: {file_path}")
        
        try:
            # 计算哈希
            md5_hash, sha256_hash = await self._calculate_hashes(file_path)
            
            # 复制到存储
            storage_path = file_path
            if copy_to_storage:
                storage_path = self.storage_path / f"{source}_{log_type}_{file_path.name}"
                await self._copy_file(file_path, storage_path)
            
            # 分析日志
            line_count, start_time, end_time = await self._analyze_log(storage_path)
            
            evidence = LogEvidence(
                id=uuid4(),
                source=source,
                log_type=log_type,
                file_path=str(storage_path),
                hash_md5=md5_hash,
                hash_sha256=sha256_hash,
                start_time=start_time,
                end_time=end_time,
                line_count=line_count,
                collected_at=datetime.utcnow(),
                metadata={
                    "original_path": str(file_path),
                    "copied": copy_to_storage,
                },
            )
            
            async with self._lock:
                self._evidence[evidence.id] = evidence
                self._entries[evidence.id] = []
            
            logger.info(f"日志收集完成: {evidence.id} ({line_count} lines)")
            return evidence
            
        except Exception as e:
            logger.error(f"日志收集失败: {e}")
            raise
    
    async def _calculate_hashes(self, file_path: Path) -> Tuple[str, str]:
        """计算文件哈希"""
        md5 = hashlib.md5()
        sha256 = hashlib.sha256()
        
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                md5.update(chunk)
                sha256.update(chunk)
        
        return md5.hexdigest(), sha256.hexdigest()
    
    async def _copy_file(self, src: Path, dst: Path) -> None:
        """复制文件"""
        async with aiofiles.open(src, 'rb') as src_f:
            async with aiofiles.open(dst, 'wb') as dst_f:
                while chunk := await src_f.read(8192):
                    await dst_f.write(chunk)
    
    async def _analyze_log(self, file_path: Path) -> Tuple[int, Optional[datetime], Optional[datetime]]:
        """分析日志文件"""
        line_count = 0
        timestamps = []
        
        async with aiofiles.open(file_path, 'r', errors='ignore') as f:
            async for line in f:
                line_count += 1
                
                # 尝试解析时间戳
                ts = self._extract_timestamp(line)
                if ts:
                    timestamps.append(ts)
        
        start_time = min(timestamps) if timestamps else None
        end_time = max(timestamps) if timestamps else None
        
        return line_count, start_time, end_time
    
    def _extract_timestamp(self, line: str) -> Optional[datetime]:
        """从日志行提取时间戳"""
        # 尝试多种时间格式
        patterns = [
            (r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}', '%Y-%m-%d %H:%M:%S'),
            (r'\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}', '%d/%b/%Y:%H:%M:%S'),
        ]
        
        for pattern, fmt in patterns:
            match = re.search(pattern, line)
            if match:
                try:
                    return datetime.strptime(match.group(), fmt)
                except ValueError:
                    continue
        
        return None
    
    async def parse_log_entries(
        self,
        evidence_id: UUID,
        log_format: str = "auto"
    ) -> List[LogEntry]:
        """
        解析日志条目
        
        Args:
            evidence_id: 证据ID
            log_format: 日志格式
            
        Returns:
            日志条目列表
        """
        async with self._lock:
            if evidence_id not in self._evidence:
                raise ValueError(f"证据不存在: {evidence_id}")
            
            evidence = self._evidence[evidence_id]
        
        logger.info(f"开始解析日志条目: {evidence_id}")
        
        entries = []
        
        async with aiofiles.open(evidence.file_path, 'r', errors='ignore') as f:
            async for line in f:
                entry = self._parse_line(line, evidence.source, log_format)
                if entry:
                    entries.append(entry)
        
        async with self._lock:
            self._entries[evidence_id] = entries
        
        logger.info(f"日志条目解析完成: {len(entries)} 条")
        return entries
    
    def _parse_line(self, line: str, source: str, log_format: str) -> Optional[LogEntry]:
        """解析单行日志"""
        line = line.strip()
        if not line:
            return None
        
        # 自动检测格式
        if log_format == "auto":
            for fmt_name, pattern in self.LOG_PATTERNS.items():
                match = pattern.match(line)
                if match:
                    log_format = fmt_name
                    break
        
        # 解析时间戳
        timestamp = self._extract_timestamp(line) or datetime.utcnow()
        
        return LogEntry(
            timestamp=timestamp,
            source=source,
            level="INFO",
            message=line[:500],
            raw_line=line,
            parsed_fields={},
        )
    
    async def align_timeline(
        self,
        evidence_ids: List[UUID],
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[LogEntry]:
        """
        对齐多个日志的时间线
        
        Args:
            evidence_ids: 证据ID列表
            start_time: 开始时间
            end_time: 结束时间
            
        Returns:
            对齐后的日志条目
        """
        logger.info(f"开始对齐时间线: {len(evidence_ids)} 个日志源")
        
        all_entries = []
        
        for evidence_id in evidence_ids:
            async with self._lock:
                entries = self._entries.get(evidence_id, [])
                
                if not entries:
                    # 如果未解析，先解析
                    entries = await self.parse_log_entries(evidence_id)
            
            for entry in entries:
                # 时间过滤
                if start_time and entry.timestamp < start_time:
                    continue
                if end_time and entry.timestamp > end_time:
                    continue
                
                all_entries.append(entry)
        
        # 按时间排序
        all_entries.sort(key=lambda x: x.timestamp)
        
        logger.info(f"时间线对齐完成: {len(all_entries)} 条")
        return all_entries
    
    async def verify_integrity(self, evidence_id: UUID) -> bool:
        """
        验证日志完整性
        
        Args:
            evidence_id: 证据ID
            
        Returns:
            是否完整
        """
        async with self._lock:
            if evidence_id not in self._evidence:
                return False
            
            evidence = self._evidence[evidence_id]
        
        # 重新计算哈希
        current_md5, current_sha256 = await self._calculate_hashes(Path(evidence.file_path))
        
        return (
            current_md5 == evidence.hash_md5 and
            current_sha256 == evidence.hash_sha256
        )
    
    async def search_logs(
        self,
        evidence_ids: List[UUID],
        keyword: str,
        case_sensitive: bool = False
    ) -> List[Dict[str, Any]]:
        """
        搜索日志
        
        Args:
            evidence_ids: 证据ID列表
            keyword: 关键词
            case_sensitive: 是否区分大小写
            
        Returns:
            搜索结果
        """
        results = []
        
        for evidence_id in evidence_ids:
            async with self._lock:
                entries = self._entries.get(evidence_id, [])
                evidence = self._evidence.get(evidence_id)
            
            if not evidence:
                continue
            
            for entry in entries:
                message = entry.message
                search_term = keyword
                
                if not case_sensitive:
                    message = message.lower()
                    search_term = search_term.lower()
                
                if search_term in message:
                    results.append({
                        "evidence_id": str(evidence_id),
                        "source": evidence.source,
                        "timestamp": entry.timestamp.isoformat(),
                        "message": entry.raw_line,
                    })
        
        return results
