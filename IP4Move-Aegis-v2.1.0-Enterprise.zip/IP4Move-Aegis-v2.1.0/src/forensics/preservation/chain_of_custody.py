"""
监管链模块

提供证据监管链记录、移交追踪和完整性保证功能
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class CustodyAction(Enum):
    """监管动作"""
    COLLECTION = "collection"
    TRANSFER = "transfer"
    STORAGE = "storage"
    ANALYSIS = "analysis"
    COPYING = "copying"
    DESTRUCTION = "destruction"
    RETURN = "return"
    DISCLOSURE = "disclosure"


class CustodyStatus(Enum):
    """监管状态"""
    IN_CUSTODY = "in_custody"
    TRANSFERRED = "transferred"
    ANALYZED = "analyzed"
    DESTROYED = "destroyed"
    RETURNED = "returned"


@dataclass
class CustodyRecord:
    """监管记录"""
    id: UUID
    evidence_id: UUID
    action: CustodyAction
    from_custodian: Optional[str]
    to_custodian: str
    timestamp: datetime
    location: str
    description: str
    hash_verification: Optional[str]
    signatures: Dict[str, str]
    attachments: List[str]


@dataclass
class EvidenceItem:
    """证据项"""
    id: UUID
    evidence_type: str
    description: str
    collected_by: str
    collected_at: datetime
    original_hash: str
    current_hash: str
    storage_location: str
    status: CustodyStatus
    chain_id: UUID


class ChainOfCustody:
    """
    监管链管理器
    
    提供证据监管链功能：
    - 监管链记录
    - 移交追踪
    - 完整性保证
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化监管链管理器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/custody_chain")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._chains: Dict[UUID, List[CustodyRecord]] = {}
        self._evidence: Dict[UUID, EvidenceItem] = {}
        self._lock = asyncio.Lock()
        
        logger.info("监管链管理器初始化完成")
    
    async def register_evidence(
        self,
        evidence_type: str,
        description: str,
        collected_by: str,
        storage_location: str,
        original_hash: str
    ) -> EvidenceItem:
        """
        注册证据
        
        Args:
            evidence_type: 证据类型
            description: 描述
            collected_by: 收集人
            storage_location: 存储位置
            original_hash: 原始哈希
            
        Returns:
            证据项
        """
        evidence_id = uuid4()
        chain_id = uuid4()
        
        item = EvidenceItem(
            id=evidence_id,
            evidence_type=evidence_type,
            description=description,
            collected_by=collected_by,
            collected_at=datetime.utcnow(),
            original_hash=original_hash,
            current_hash=original_hash,
            storage_location=storage_location,
            status=CustodyStatus.IN_CUSTODY,
            chain_id=chain_id,
        )
        
        # 创建初始监管记录
        record = CustodyRecord(
            id=uuid4(),
            evidence_id=evidence_id,
            action=CustodyAction.COLLECTION,
            from_custodian=None,
            to_custodian=collected_by,
            timestamp=datetime.utcnow(),
            location=storage_location,
            description=f"证据收集: {description}",
            hash_verification=original_hash,
            signatures={},
            attachments=[],
        )
        
        async with self._lock:
            self._evidence[evidence_id] = item
            self._chains[evidence_id] = [record]
        
        logger.info(f"证据已注册: {evidence_id}")
        return item
    
    async def transfer_custody(
        self,
        evidence_id: UUID,
        from_custodian: str,
        to_custodian: str,
        new_location: str,
        description: str,
        hash_verification: Optional[str] = None
    ) -> CustodyRecord:
        """
        移交监管权
        
        Args:
            evidence_id: 证据ID
            from_custodian: 移交人
            to_custodian: 接收人
            new_location: 新位置
            description: 描述
            hash_verification: 哈希验证
            
        Returns:
            监管记录
        """
        async with self._lock:
            if evidence_id not in self._evidence:
                raise ValueError(f"证据不存在: {evidence_id}")
            
            evidence = self._evidence[evidence_id]
        
        record = CustodyRecord(
            id=uuid4(),
            evidence_id=evidence_id,
            action=CustodyAction.TRANSFER,
            from_custodian=from_custodian,
            to_custodian=to_custodian,
            timestamp=datetime.utcnow(),
            location=new_location,
            description=description,
            hash_verification=hash_verification,
            signatures={},
            attachments=[],
        )
        
        async with self._lock:
            self._chains[evidence_id].append(record)
            evidence.storage_location = new_location
            if hash_verification:
                evidence.current_hash = hash_verification
        
        logger.info(f"监管权已移交: {evidence_id} ({from_custodian} -> {to_custodian})")
        return record
    
    async def record_analysis(
        self,
        evidence_id: UUID,
        analyst: str,
        analysis_type: str,
        location: str,
        working_copy_hash: Optional[str] = None
    ) -> CustodyRecord:
        """
        记录分析活动
        
        Args:
            evidence_id: 证据ID
            analyst: 分析师
            analysis_type: 分析类型
            location: 位置
            working_copy_hash: 工作副本哈希
            
        Returns:
            监管记录
        """
        record = CustodyRecord(
            id=uuid4(),
            evidence_id=evidence_id,
            action=CustodyAction.ANALYSIS,
            from_custodian=None,
            to_custodian=analyst,
            timestamp=datetime.utcnow(),
            location=location,
            description=f"分析: {analysis_type}",
            hash_verification=working_copy_hash,
            signatures={},
            attachments=[],
        )
        
        async with self._lock:
            if evidence_id in self._chains:
                self._chains[evidence_id].append(record)
        
        logger.info(f"分析活动已记录: {evidence_id} ({analysis_type})")
        return record
    
    async def verify_chain_integrity(self, evidence_id: UUID) -> Dict[str, Any]:
        """
        验证监管链完整性
        
        Args:
            evidence_id: 证据ID
            
        Returns:
            验证结果
        """
        async with self._lock:
            if evidence_id not in self._chains:
                return {"valid": False, "error": "证据不存在"}
            
            records = self._chains[evidence_id]
            evidence = self._evidence[evidence_id]
        
        issues = []
        
        # 检查记录连续性
        for i in range(1, len(records)):
            prev = records[i - 1]
            curr = records[i]
            
            # 检查时间顺序
            if curr.timestamp < prev.timestamp:
                issues.append(f"记录{i}: 时间顺序错误")
            
            # 检查监管人连续性
            if curr.from_custodian and curr.from_custodian != prev.to_custodian:
                issues.append(f"记录{i}: 监管人不连续")
        
        # 检查哈希完整性
        if evidence.current_hash != evidence.original_hash:
            issues.append("证据哈希已改变")
        
        return {
            "valid": len(issues) == 0,
            "evidence_id": str(evidence_id),
            "record_count": len(records),
            "issues": issues,
        }
    
    async def get_chain_of_custody(self, evidence_id: UUID) -> List[Dict[str, Any]]:
        """
        获取完整监管链
        
        Args:
            evidence_id: 证据ID
            
        Returns:
            监管链记录
        """
        async with self._lock:
            if evidence_id not in self._chains:
                return []
            
            records = self._chains[evidence_id]
        
        return [
            {
                "id": str(r.id),
                "action": r.action.value,
                "from": r.from_custodian,
                "to": r.to_custodian,
                "timestamp": r.timestamp.isoformat(),
                "location": r.location,
                "description": r.description,
                "hash_verification": r.hash_verification,
            }
            for r in records
        ]
    
    async def export_chain_report(self, evidence_id: UUID, output_path: str) -> str:
        """
        导出监管链报告
        
        Args:
            evidence_id: 证据ID
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        async with self._lock:
            if evidence_id not in self._evidence:
                raise ValueError(f"证据不存在: {evidence_id}")
            
            evidence = self._evidence[evidence_id]
            chain = self._chains.get(evidence_id, [])
        
        report = {
            "report_type": "Chain of Custody",
            "generated_at": datetime.utcnow().isoformat(),
            "evidence": {
                "id": str(evidence.id),
                "type": evidence.evidence_type,
                "description": evidence.description,
                "collected_by": evidence.collected_by,
                "collected_at": evidence.collected_at.isoformat(),
                "original_hash": evidence.original_hash,
                "current_hash": evidence.current_hash,
                "status": evidence.status.value,
            },
            "chain": [
                {
                    "sequence": i + 1,
                    "action": r.action.value,
                    "from_custodian": r.from_custodian,
                    "to_custodian": r.to_custodian,
                    "timestamp": r.timestamp.isoformat(),
                    "location": r.location,
                    "description": r.description,
                }
                for i, r in enumerate(chain)
            ],
        }
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(report, indent=2, ensure_ascii=False))
        
        logger.info(f"监管链报告已导出: {output_file}")
        return str(output_file)
