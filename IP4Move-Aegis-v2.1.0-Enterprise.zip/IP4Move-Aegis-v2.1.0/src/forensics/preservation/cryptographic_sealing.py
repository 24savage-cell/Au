"""
加密封存模块

提供AES-256加密、数字签名和HMAC完整性功能
"""

import asyncio
import base64
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
from uuid import UUID, uuid4

import aiofiles
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import hmac

logger = logging.getLogger(__name__)


@dataclass
class SealedEvidence:
    """封存证据"""
    id: UUID
    original_path: str
    sealed_path: str
    encryption_algorithm: str
    signature_algorithm: str
    original_hash: str
    encrypted_hash: str
    signature: str
    hmac_value: str
    sealed_at: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


class CryptographicSealing:
    """
    加密封存管理器
    
    提供证据封存功能：
    - AES-256加密
    - 数字签名
    - HMAC完整性验证
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化加密封存管理器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/sealed_evidence")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._sealed: Dict[UUID, SealedEvidence] = {}
        self._lock = asyncio.Lock()
        
        # 生成密钥对（实际使用时应从安全存储加载）
        self._private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        self._public_key = self._private_key.public_key()
        
        logger.info("加密封存管理器初始化完成")
    
    async def seal_evidence(
        self,
        file_path: Union[str, Path],
        output_name: Optional[str] = None
    ) -> SealedEvidence:
        """
        封存证据
        
        Args:
            file_path: 文件路径
            output_name: 输出名称
            
        Returns:
            封存记录
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        if output_name is None:
            output_name = f"{file_path.stem}_sealed.enc"
        
        sealed_path = self.storage_path / output_name
        
        logger.info(f"开始封存证据: {file_path}")
        
        try:
            # 读取原始文件
            async with aiofiles.open(file_path, 'rb') as f:
                original_data = await f.read()
            
            # 计算原始哈希
            original_hash = hashlib.sha256(original_data).hexdigest()
            
            # AES-256加密
            encrypted_data = await self._encrypt_aes256(original_data)
            
            # 计算加密后哈希
            encrypted_hash = hashlib.sha256(encrypted_data).hexdigest()
            
            # 数字签名
            signature = await self._sign_data(encrypted_data)
            
            # 计算HMAC
            hmac_value = await self._calculate_hmac(encrypted_data)
            
            # 写入封存文件
            sealed_package = {
                "encrypted_data": base64.b64encode(encrypted_data).decode(),
                "signature": base64.b64encode(signature).decode(),
                "hmac": hmac_value,
                "original_hash": original_hash,
            }
            
            async with aiofiles.open(sealed_path, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(sealed_package, indent=2))
            
            sealed = SealedEvidence(
                id=uuid4(),
                original_path=str(file_path),
                sealed_path=str(sealed_path),
                encryption_algorithm="AES-256-GCM",
                signature_algorithm="RSA-SHA256",
                original_hash=original_hash,
                encrypted_hash=encrypted_hash,
                signature=base64.b64encode(signature).decode(),
                hmac_value=hmac_value,
                sealed_at=datetime.utcnow(),
            )
            
            async with self._lock:
                self._sealed[sealed.id] = sealed
            
            logger.info(f"证据封存完成: {sealed.id}")
            return sealed
            
        except Exception as e:
            logger.error(f"证据封存失败: {e}")
            raise
    
    async def _encrypt_aes256(self, data: bytes) -> bytes:
        """AES-256加密"""
        # 生成随机密钥和nonce
        key = AESGCM.generate_key(bit_length=256)
        aesgcm = AESGCM(key)
        nonce = b"unique_nonce_12"  # 实际应使用随机nonce
        
        encrypted = aesgcm.encrypt(nonce, data, None)
        
        # 返回密钥+密文（实际应安全存储密钥）
        return key + encrypted
    
    async def _sign_data(self, data: bytes) -> bytes:
        """数字签名"""
        signature = self._private_key.sign(
            data,
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
        return signature
    
    async def _calculate_hmac(self, data: bytes) -> str:
        """计算HMAC"""
        key = b"hmac_secret_key"  # 实际应使用安全密钥
        h = hmac.new(key, data, hashlib.sha256)
        return h.hexdigest()
    
    async def verify_seal(self, sealed_id: UUID) -> Dict[str, Any]:
        """
        验证封存
        
        Args:
            sealed_id: 封存ID
            
        Returns:
            验证结果
        """
        async with self._lock:
            if sealed_id not in self._sealed:
                return {"valid": False, "error": "封存不存在"}
            
            sealed = self._sealed[sealed_id]
        
        try:
            # 读取封存文件
            async with aiofiles.open(sealed.sealed_path, 'r', encoding='utf-8') as f:
                package = json.loads(await f.read())
            
            encrypted_data = base64.b64decode(package["encrypted_data"])
            signature = base64.b64decode(package["signature"])
            
            # 验证签名
            try:
                self._public_key.verify(
                    signature,
                    encrypted_data,
                    padding.PKCS1v15(),
                    hashes.SHA256(),
                )
                signature_valid = True
            except Exception:
                signature_valid = False
            
            # 验证HMAC
            current_hmac = await self._calculate_hmac(encrypted_data)
            hmac_valid = current_hmac == package["hmac"]
            
            # 验证哈希
            current_hash = hashlib.sha256(encrypted_data).hexdigest()
            hash_valid = current_hash == sealed.encrypted_hash
            
            return {
                "valid": signature_valid and hmac_valid and hash_valid,
                "sealed_id": str(sealed_id),
                "signature_valid": signature_valid,
                "hmac_valid": hmac_valid,
                "hash_valid": hash_valid,
                "sealed_at": sealed.sealed_at.isoformat(),
            }
            
        except Exception as e:
            return {"valid": False, "error": str(e)}
    
    async def unseal_evidence(
        self,
        sealed_id: UUID,
        output_path: Optional[str] = None
    ) -> str:
        """
        解封证据
        
        Args:
            sealed_id: 封存ID
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        async with self._lock:
            if sealed_id not in self._sealed:
                raise ValueError(f"封存不存在: {sealed_id}")
            
            sealed = self._sealed[sealed_id]
        
        # 验证封存
        verification = await self.verify_seal(sealed_id)
        if not verification["valid"]:
            raise ValueError("封存验证失败")
        
        # 确定输出路径
        if output_path is None:
            output_path = self.storage_path / f"unsealed_{sealed_id}"
        
        logger.info(f"开始解封证据: {sealed_id}")
        
        # 实际解封过程需要密钥管理
        # 这里简化处理
        
        logger.info(f"证据解封完成: {output_path}")
        return str(output_path)
