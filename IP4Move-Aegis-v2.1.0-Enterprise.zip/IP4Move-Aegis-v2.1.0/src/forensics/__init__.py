"""
证据保全与取证模块

提供完整的数字取证功能，包括：
- 证据收集（内存、磁盘、网络、日志）
- 证据保全（监管链、加密、时间戳）
- 证据分析（时间线、伪影提取、IOC扫描）
- 报告生成

Author: IP4Move Security Team
Version: 1.0.0
"""

from .collection.memory_collector import MemoryCollector, MemoryDump
from .collection.disk_collector import DiskCollector, DiskImage
from .collection.network_collector import NetworkCollector, NetworkCapture
from .collection.log_collector import LogCollector, LogEvidence
from .preservation.chain_of_custody import ChainOfCustody, CustodyRecord
from .preservation.cryptographic_sealing import CryptographicSealing, SealedEvidence
from .preservation.timestamp_authority import TimestampAuthority, TimestampRecord
from .analysis.timeline_analysis import TimelineAnalyzer, TimelineEvent
from .analysis.artifact_extractor import ArtifactExtractor, Artifact
from .analysis.ioc_scanner import IOCScanner, IOCMatch
from .reporting.forensic_report import ForensicReportGenerator
from .reporting.legal_package import LegalPackageGenerator

__version__ = "1.0.0"
__all__ = [
    # 证据收集
    "MemoryCollector",
    "MemoryDump",
    "DiskCollector",
    "DiskImage",
    "NetworkCollector",
    "NetworkCapture",
    "LogCollector",
    "LogEvidence",
    # 证据保全
    "ChainOfCustody",
    "CustodyRecord",
    "CryptographicSealing",
    "SealedEvidence",
    "TimestampAuthority",
    "TimestampRecord",
    # 证据分析
    "TimelineAnalyzer",
    "TimelineEvent",
    "ArtifactExtractor",
    "Artifact",
    "IOCScanner",
    "IOCMatch",
    # 报告
    "ForensicReportGenerator",
    "LegalPackageGenerator",
]
