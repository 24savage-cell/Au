"""
时间线分析模块

提供事件排序、间隔分析和异常模式检测功能
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class EventType(Enum):
    """事件类型"""
    FILE_ACCESS = "file_access"
    FILE_CREATION = "file_creation"
    FILE_DELETION = "file_deletion"
    FILE_MODIFICATION = "file_modification"
    NETWORK_CONNECTION = "network_connection"
    PROCESS_START = "process_start"
    PROCESS_END = "process_end"
    REGISTRY_CHANGE = "registry_change"
    LOGON = "logon"
    LOGOFF = "logoff"
    USB_INSERT = "usb_insert"
    USB_REMOVE = "usb_remove"


class EventSeverity(Enum):
    """事件严重性"""
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class TimelineEvent:
    """时间线事件"""
    id: UUID
    timestamp: datetime
    event_type: EventType
    source: str
    description: str
    severity: EventSeverity
    evidence_id: Optional[UUID]
    metadata: Dict[str, Any] = field(default_factory=dict)
    related_events: List[UUID] = field(default_factory=list)


class TimelineAnalyzer:
    """
    时间线分析器
    
    提供时间线分析功能：
    - 事件排序
    - 间隔分析
    - 异常模式检测
    """
    
    def __init__(self):
        """初始化时间线分析器"""
        self._events: List[TimelineEvent] = []
        self._lock = asyncio.Lock()
        
        logger.info("时间线分析器初始化完成")
    
    async def add_event(
        self,
        timestamp: datetime,
        event_type: EventType,
        source: str,
        description: str,
        severity: EventSeverity = EventSeverity.INFO,
        evidence_id: Optional[UUID] = None,
        metadata: Dict[str, Any] = None
    ) -> TimelineEvent:
        """
        添加事件
        
        Args:
            timestamp: 时间戳
            event_type: 事件类型
            source: 来源
            description: 描述
            severity: 严重性
            evidence_id: 证据ID
            metadata: 元数据
            
        Returns:
            事件对象
        """
        if metadata is None:
            metadata = {}
        
        event = TimelineEvent(
            id=uuid4(),
            timestamp=timestamp,
            event_type=event_type,
            source=source,
            description=description,
            severity=severity,
            evidence_id=evidence_id,
            metadata=metadata,
        )
        
        async with self._lock:
            self._events.append(event)
        
        return event
    
    async def import_from_logs(
        self,
        log_entries: List[Dict[str, Any]],
        source: str
    ) -> List[TimelineEvent]:
        """
        从日志导入事件
        
        Args:
            log_entries: 日志条目
            source: 来源
            
        Returns:
            导入的事件列表
        """
        events = []
        
        for entry in log_entries:
            try:
                timestamp = datetime.fromisoformat(entry.get("timestamp", ""))
                event_type = EventType(entry.get("event_type", "file_access"))
                severity = EventSeverity(entry.get("severity", "info"))
                
                event = await self.add_event(
                    timestamp=timestamp,
                    event_type=event_type,
                    source=source,
                    description=entry.get("message", ""),
                    severity=severity,
                    metadata=entry.get("metadata", {}),
                )
                events.append(event)
            except Exception as e:
                logger.error(f"导入事件失败: {e}")
        
        logger.info(f"从日志导入 {len(events)} 个事件")
        return events
    
    async def get_timeline(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        event_types: List[EventType] = None,
        severity: Optional[EventSeverity] = None
    ) -> List[TimelineEvent]:
        """
        获取时间线
        
        Args:
            start_time: 开始时间
            end_time: 结束时间
            event_types: 事件类型过滤
            severity: 严重性过滤
            
        Returns:
            事件列表
        """
        async with self._lock:
            events = self._events.copy()
        
        # 应用过滤
        filtered = events
        
        if start_time:
            filtered = [e for e in filtered if e.timestamp >= start_time]
        
        if end_time:
            filtered = [e for e in filtered if e.timestamp <= end_time]
        
        if event_types:
            filtered = [e for e in filtered if e.event_type in event_types]
        
        if severity:
            filtered = [e for e in filtered if e.severity == severity]
        
        # 按时间排序
        filtered.sort(key=lambda x: x.timestamp)
        
        return filtered
    
    async def analyze_intervals(self) -> Dict[str, Any]:
        """
        分析事件间隔
        
        Returns:
            间隔分析结果
        """
        async with self._lock:
            events = sorted(self._events, key=lambda x: x.timestamp)
        
        if len(events) < 2:
            return {"error": "事件数量不足"}
        
        intervals = []
        for i in range(1, len(events)):
            interval = (events[i].timestamp - events[i-1].timestamp).total_seconds()
            intervals.append(interval)
        
        avg_interval = sum(intervals) / len(intervals)
        min_interval = min(intervals)
        max_interval = max(intervals)
        
        # 检测异常间隔（超过平均值3倍）
        anomalies = [
            {
                "index": i + 1,
                "interval": interval,
                "from_event": str(events[i].id),
                "to_event": str(events[i+1].id),
            }
            for i, interval in enumerate(intervals)
            if interval > avg_interval * 3
        ]
        
        return {
            "total_events": len(events),
            "total_intervals": len(intervals),
            "average_interval_seconds": avg_interval,
            "min_interval_seconds": min_interval,
            "max_interval_seconds": max_interval,
            "anomaly_count": len(anomalies),
            "anomalies": anomalies,
        }
    
    async def detect_patterns(self) -> List[Dict[str, Any]]:
        """
        检测异常模式
        
        Returns:
            检测到的模式
        """
        async with self._lock:
            events = self._events.copy()
        
        patterns = []
        
        # 按类型分组
        by_type = {}
        for event in events:
            if event.event_type not in by_type:
                by_type[event.event_type] = []
            by_type[event.event_type].append(event)
        
        # 检测快速连续事件
        for event_type, type_events in by_type.items():
            type_events.sort(key=lambda x: x.timestamp)
            
            for i in range(1, len(type_events)):
                interval = (type_events[i].timestamp - type_events[i-1].timestamp).total_seconds()
                
                if interval < 1:  # 1秒内连续事件
                    patterns.append({
                        "type": "rapid_sequence",
                        "event_type": event_type.value,
                        "events": [str(type_events[i-1].id), str(type_events[i].id)],
                        "interval_seconds": interval,
                    })
        
        # 检测非工作时间活动
        for event in events:
            hour = event.timestamp.hour
            if hour < 6 or hour > 22:
                patterns.append({
                    "type": "after_hours_activity",
                    "event_id": str(event.id),
                    "timestamp": event.timestamp.isoformat(),
                    "hour": hour,
                })
        
        # 检测高严重性事件聚集
        high_severity = [e for e in events if e.severity in [EventSeverity.HIGH, EventSeverity.CRITICAL]]
        if len(high_severity) > 5:
            patterns.append({
                "type": "high_severity_cluster",
                "count": len(high_severity),
                "events": [str(e.id) for e in high_severity[:10]],
            })
        
        return patterns
    
    async def export_timeline(
        self,
        output_path: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> str:
        """
        导出时间线
        
        Args:
            output_path: 输出路径
            start_time: 开始时间
            end_time: 结束时间
            
        Returns:
            输出文件路径
        """
        events = await self.get_timeline(start_time, end_time)
        
        data = {
            "generated_at": datetime.utcnow().isoformat(),
            "event_count": len(events),
            "time_range": {
                "start": events[0].timestamp.isoformat() if events else None,
                "end": events[-1].timestamp.isoformat() if events else None,
            },
            "events": [
                {
                    "id": str(e.id),
                    "timestamp": e.timestamp.isoformat(),
                    "type": e.event_type.value,
                    "source": e.source,
                    "description": e.description,
                    "severity": e.severity.value,
                }
                for e in events
            ],
        }
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(data, indent=2, ensure_ascii=False))
        
        logger.info(f"时间线已导出: {output_file}")
        return str(output_file)
