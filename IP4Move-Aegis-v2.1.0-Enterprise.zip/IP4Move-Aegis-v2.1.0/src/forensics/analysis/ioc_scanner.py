"""
IOC扫描模块

提供IP/域名/URL/哈希/邮箱批量扫描和MITRE映射功能
"""

import asyncio
import hashlib
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class IOCType(Enum):
    """IOC类型"""
    IP = "ip"
    DOMAIN = "domain"
    URL = "url"
    HASH_MD5 = "hash_md5"
    HASH_SHA1 = "hash_sha1"
    HASH_SHA256 = "hash_sha256"
    EMAIL = "email"
    CVE = "cve"
    MUTEX = "mutex"
    REGISTRY = "registry"


@dataclass
class IOCMatch:
    """IOC匹配结果"""
    id: UUID
    ioc_type: IOCType
    ioc_value: str
    source: str
    matched_at: datetime
    confidence: float
    mitre_techniques: List[str]
    threat_actor: Optional[str]
    malware_family: Optional[str]
    description: str


class IOCScanner:
    """
    IOC扫描器
    
    提供威胁情报扫描功能：
    - IP/域名/URL/哈希/邮箱批量扫描
    - MITRE ATT&CK映射
    - 威胁情报关联
    """
    
    # 模拟威胁情报数据库
    THREAT_INTEL_DB = {
        "ips": {
            "192.168.1.100": {"threat_actor": "APT29", "malware": "CozyBear", "confidence": 0.95},
            "10.0.0.50": {"threat_actor": "Lazarus", "malware": "AppleJeus", "confidence": 0.88},
        },
        "domains": {
            "malicious-site.com": {"threat_actor": "FIN7", "malware": "Carbanak", "confidence": 0.92},
            "evil-c2.net": {"threat_actor": "APT28", "malware": "X-Agent", "confidence": 0.90},
        },
        "hashes": {
            "d41d8cd98f00b204e9800998ecf8427e": {"threat_actor": "Unknown", "malware": "Ransomware", "confidence": 0.85},
        },
    }
    
    # MITRE ATT&CK技术映射
    MITRE_MAPPING = {
        "192.168.1.100": ["T1071", "T1041"],  # C2通信
        "malicious-site.com": ["T1566", "T1071"],  # 钓鱼、C2
        "d41d8cd98f00b204e9800998ecf8427e": ["T1486"],  # 勒索软件
    }
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化IOC扫描器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/ioc_scanner")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._matches: List[IOCMatch] = []
        self._lock = asyncio.Lock()
        
        logger.info("IOC扫描器初始化完成")
    
    async def scan_ip(self, ip_address: str, source: str = "manual") -> Optional[IOCMatch]:
        """
        扫描IP地址
        
        Args:
            ip_address: IP地址
            source: 来源
            
        Returns:
            匹配结果
        """
        logger.info(f"扫描IP: {ip_address}")
        
        # 查询威胁情报
        intel = self.THREAT_INTEL_DB["ips"].get(ip_address)
        
        if intel:
            match = IOCMatch(
                id=uuid4(),
                ioc_type=IOCType.IP,
                ioc_value=ip_address,
                source=source,
                matched_at=datetime.utcnow(),
                confidence=intel["confidence"],
                mitre_techniques=self.MITRE_MAPPING.get(ip_address, []),
                threat_actor=intel.get("threat_actor"),
                malware_family=intel.get("malware"),
                description=f"已知恶意IP，关联威胁组织: {intel['threat_actor']}",
            )
            
            async with self._lock:
                self._matches.append(match)
            
            logger.warning(f"IP威胁发现: {ip_address}")
            return match
        
        return None
    
    async def scan_domain(self, domain: str, source: str = "manual") -> Optional[IOCMatch]:
        """
        扫描域名
        
        Args:
            domain: 域名
            source: 来源
            
        Returns:
            匹配结果
        """
        logger.info(f"扫描域名: {domain}")
        
        intel = self.THREAT_INTEL_DB["domains"].get(domain)
        
        if intel:
            match = IOCMatch(
                id=uuid4(),
                ioc_type=IOCType.DOMAIN,
                ioc_value=domain,
                source=source,
                matched_at=datetime.utcnow(),
                confidence=intel["confidence"],
                mitre_techniques=self.MITRE_MAPPING.get(domain, []),
                threat_actor=intel.get("threat_actor"),
                malware_family=intel.get("malware"),
                description=f"已知恶意域名，关联威胁组织: {intel['threat_actor']}",
            )
            
            async with self._lock:
                self._matches.append(match)
            
            logger.warning(f"域名威胁发现: {domain}")
            return match
        
        return None
    
    async def scan_hash(self, file_hash: str, source: str = "manual") -> Optional[IOCMatch]:
        """
        扫描文件哈希
        
        Args:
            file_hash: 文件哈希
            source: 来源
            
        Returns:
            匹配结果
        """
        logger.info(f"扫描哈希: {file_hash}")
        
        # 确定哈希类型
        hash_type = self._detect_hash_type(file_hash)
        
        intel = self.THREAT_INTEL_DB["hashes"].get(file_hash)
        
        if intel:
            match = IOCMatch(
                id=uuid4(),
                ioc_type=hash_type,
                ioc_value=file_hash,
                source=source,
                matched_at=datetime.utcnow(),
                confidence=intel["confidence"],
                mitre_techniques=self.MITRE_MAPPING.get(file_hash, []),
                threat_actor=intel.get("threat_actor"),
                malware_family=intel.get("malware"),
                description=f"已知恶意文件，关联恶意软件: {intel['malware']}",
            )
            
            async with self._lock:
                self._matches.append(match)
            
            logger.warning(f"哈希威胁发现: {file_hash}")
            return match
        
        return None
    
    def _detect_hash_type(self, hash_value: str) -> IOCType:
        """检测哈希类型"""
        length = len(hash_value)
        if length == 32:
            return IOCType.HASH_MD5
        elif length == 40:
            return IOCType.HASH_SHA1
        elif length == 64:
            return IOCType.HASH_SHA256
        else:
            return IOCType.HASH_MD5
    
    async def batch_scan(
        self,
        iocs: List[Dict[str, Any]],
        source: str = "bulk_scan"
    ) -> List[IOCMatch]:
        """
        批量扫描IOC
        
        Args:
            iocs: IOC列表
            source: 来源
            
        Returns:
            匹配结果列表
        """
        logger.info(f"开始批量扫描: {len(iocs)} 个IOC")
        
        matches = []
        
        for ioc in iocs:
            ioc_type = ioc.get("type")
            ioc_value = ioc.get("value")
            
            match = None
            
            if ioc_type == "ip":
                match = await self.scan_ip(ioc_value, source)
            elif ioc_type == "domain":
                match = await self.scan_domain(ioc_value, source)
            elif ioc_type == "hash":
                match = await self.scan_hash(ioc_value, source)
            
            if match:
                matches.append(match)
        
        logger.info(f"批量扫描完成: {len(matches)} 个威胁发现")
        return matches
    
    async def scan_file(self, file_path: Union[str, Path]) -> List[IOCMatch]:
        """
        扫描文件中的IOC
        
        Args:
            file_path: 文件路径
            
        Returns:
            匹配结果列表
        """
        logger.info(f"扫描文件中的IOC: {file_path}")
        
        matches = []
        
        # 提取文件中的IOC
        async with aiofiles.open(file_path, 'r', errors='ignore') as f:
            content = await f.read()
        
        # 提取IP地址
        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        for ip in re.findall(ip_pattern, content):
            match = await self.scan_ip(ip, f"file:{file_path}")
            if match:
                matches.append(match)
        
        # 提取域名
        domain_pattern = r'\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b'
        for domain in re.findall(domain_pattern, content):
            match = await self.scan_domain(domain, f"file:{file_path}")
            if match:
                matches.append(match)
        
        # 提取哈希
        hash_pattern = r'\b[a-fA-F0-9]{32,64}\b'
        for hash_val in re.findall(hash_pattern, content):
            match = await self.scan_hash(hash_val, f"file:{file_path}")
            if match:
                matches.append(match)
        
        return matches
    
    async def get_mitre_summary(self) -> Dict[str, Any]:
        """
        获取MITRE ATT&CK摘要
        
        Returns:
            MITRE摘要
        """
        async with self._lock:
            matches = self._matches.copy()
        
        # 统计技术
        techniques = {}
        for match in matches:
            for tech in match.mitre_techniques:
                if tech not in techniques:
                    techniques[tech] = {
                        "count": 0,
                        "iocs": [],
                    }
                techniques[tech]["count"] += 1
                techniques[tech]["iocs"].append(match.ioc_value)
        
        return {
            "generated_at": datetime.utcnow().isoformat(),
            "total_matches": len(matches),
            "unique_techniques": len(techniques),
            "techniques": techniques,
        }
    
    async def export_matches(self, output_path: str) -> str:
        """
        导出匹配结果
        
        Args:
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        async with self._lock:
            matches = self._matches.copy()
        
        data = {
            "exported_at": datetime.utcnow().isoformat(),
            "match_count": len(matches),
            "matches": [
                {
                    "id": str(m.id),
                    "type": m.ioc_type.value,
                    "value": m.ioc_value,
                    "source": m.source,
                    "matched_at": m.matched_at.isoformat(),
                    "confidence": m.confidence,
                    "mitre_techniques": m.mitre_techniques,
                    "threat_actor": m.threat_actor,
                    "malware_family": m.malware_family,
                    "description": m.description,
                }
                for m in matches
            ],
        }
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(data, indent=2, ensure_ascii=False))
        
        logger.info(f"匹配结果已导出: {output_file}")
        return str(output_file)
