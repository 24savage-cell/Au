"""
伪影提取模块

提供注册表、浏览器历史、最近文件和预取分析功能
"""

import asyncio
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class ArtifactType(Enum):
    """伪影类型"""
    REGISTRY = "registry"
    BROWSER_HISTORY = "browser_history"
    RECENT_FILES = "recent_files"
    PREFETCH = "prefetch"
    JUMP_LIST = "jump_list"
    SHELLBAGS = "shellbags"
    LNK_FILES = "lnk_files"
    EVENT_LOGS = "event_logs"


@dataclass
class Artifact:
    """伪影"""
    id: UUID
    artifact_type: ArtifactType
    source_path: str
    extracted_at: datetime
    data: Dict[str, Any]
    metadata: Dict[str, Any] = field(default_factory=dict)


class ArtifactExtractor:
    """
    伪影提取器
    
    提供系统伪影提取功能：
    - 注册表分析
    - 浏览器历史
    - 最近文件
    - 预取分析
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化伪影提取器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/artifacts")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._artifacts: Dict[UUID, Artifact] = {}
        self._lock = asyncio.Lock()
        
        logger.info("伪影提取器初始化完成")
    
    async def extract_registry_artifacts(
        self,
        registry_hive: Union[str, Path]
    ) -> Artifact:
        """
        提取注册表伪影
        
        Args:
            registry_hive: 注册表hive路径
            
        Returns:
            伪影对象
        """
        logger.info(f"开始提取注册表伪影: {registry_hive}")
        
        # 模拟注册表分析
        registry_data = {
            "user_assist": [
                {"program": "chrome.exe", "last_run": datetime.utcnow().isoformat(), "run_count": 50},
                {"program": "notepad.exe", "last_run": datetime.utcnow().isoformat(), "run_count": 20},
            ],
            "recent_docs": [
                {"document": "secret.docx", "last_access": datetime.utcnow().isoformat()},
                {"document": "budget.xlsx", "last_access": datetime.utcnow().isoformat()},
            ],
            "usb_devices": [
                {"device": "USB\\VID_0781&PID_5567", "first_insert": datetime.utcnow().isoformat()},
            ],
        }
        
        artifact = Artifact(
            id=uuid4(),
            artifact_type=ArtifactType.REGISTRY,
            source_path=str(registry_hive),
            extracted_at=datetime.utcnow(),
            data=registry_data,
        )
        
        async with self._lock:
            self._artifacts[artifact.id] = artifact
        
        logger.info(f"注册表伪影提取完成: {artifact.id}")
        return artifact
    
    async def extract_browser_history(
        self,
        browser_type: str,
        profile_path: Union[str, Path]
    ) -> Artifact:
        """
        提取浏览器历史
        
        Args:
            browser_type: 浏览器类型
            profile_path: 配置文件路径
            
        Returns:
            伪影对象
        """
        logger.info(f"开始提取浏览器历史: {browser_type}")
        
        # 模拟浏览器历史提取
        history_data = {
            "browser": browser_type,
            "history_entries": [
                {
                    "url": "https://example.com/login",
                    "title": "Login Page",
                    "visit_time": datetime.utcnow().isoformat(),
                    "visit_count": 5,
                },
                {
                    "url": "https://malicious-site.com/download",
                    "title": "Download",
                    "visit_time": datetime.utcnow().isoformat(),
                    "visit_count": 1,
                },
            ],
            "downloads": [
                {
                    "filename": "malware.exe",
                    "url": "https://malicious-site.com/malware.exe",
                    "download_time": datetime.utcnow().isoformat(),
                },
            ],
        }
        
        artifact = Artifact(
            id=uuid4(),
            artifact_type=ArtifactType.BROWSER_HISTORY,
            source_path=str(profile_path),
            extracted_at=datetime.utcnow(),
            data=history_data,
        )
        
        async with self._lock:
            self._artifacts[artifact.id] = artifact
        
        logger.info(f"浏览器历史提取完成: {artifact.id}")
        return artifact
    
    async def extract_recent_files(
        self,
        recent_items_path: Union[str, Path]
    ) -> Artifact:
        """
        提取最近文件
        
        Args:
            recent_items_path: 最近项目路径
            
        Returns:
            伪影对象
        """
        logger.info(f"开始提取最近文件: {recent_items_path}")
        
        # 模拟最近文件提取
        recent_data = {
            "recent_files": [
                {"path": "C:\\Users\\Admin\\Documents\\secret.docx", "last_access": datetime.utcnow().isoformat()},
                {"path": "C:\\Users\\Admin\\Downloads\\data.zip", "last_access": datetime.utcnow().isoformat()},
            ],
            "frequent_folders": [
                {"path": "C:\\Users\\Admin\\Documents", "access_count": 100},
                {"path": "C:\\Users\\Admin\\Downloads", "access_count": 50},
            ],
        }
        
        artifact = Artifact(
            id=uuid4(),
            artifact_type=ArtifactType.RECENT_FILES,
            source_path=str(recent_items_path),
            extracted_at=datetime.utcnow(),
            data=recent_data,
        )
        
        async with self._lock:
            self._artifacts[artifact.id] = artifact
        
        logger.info(f"最近文件提取完成: {artifact.id}")
        return artifact
    
    async def extract_prefetch(
        self,
        prefetch_dir: Union[str, Path]
    ) -> Artifact:
        """
        提取预取文件
        
        Args:
            prefetch_dir: 预取目录
            
        Returns:
            伪影对象
        """
        logger.info(f"开始提取预取文件: {prefetch_dir}")
        
        # 模拟预取分析
        prefetch_data = {
            "executables": [
                {
                    "name": "CHROME.EXE",
                    "run_count": 150,
                    "last_run": datetime.utcnow().isoformat(),
                    "files_accessed": ["C:\\Windows\\System32\\ntdll.dll", "C:\\Program Files\\Chrome\\chrome.dll"],
                },
                {
                    "name": "MALWARE.EXE",
                    "run_count": 1,
                    "last_run": datetime.utcnow().isoformat(),
                    "files_accessed": ["C:\\Windows\\System32\\kernel32.dll"],
                },
            ],
        }
        
        artifact = Artifact(
            id=uuid4(),
            artifact_type=ArtifactType.PREFETCH,
            source_path=str(prefetch_dir),
            extracted_at=datetime.utcnow(),
            data=prefetch_data,
        )
        
        async with self._lock:
            self._artifacts[artifact.id] = artifact
        
        logger.info(f"预取文件提取完成: {artifact.id}")
        return artifact
    
    async def search_artifacts(
        self,
        keyword: str,
        artifact_types: List[ArtifactType] = None
    ) -> List[Dict[str, Any]]:
        """
        搜索伪影
        
        Args:
            keyword: 关键词
            artifact_types: 伪影类型过滤
            
        Returns:
            搜索结果
        """
        async with self._lock:
            artifacts = list(self._artifacts.values())
        
        results = []
        
        for artifact in artifacts:
            if artifact_types and artifact.artifact_type not in artifact_types:
                continue
            
            # 在数据中搜索
            data_str = json.dumps(artifact.data, default=str).lower()
            if keyword.lower() in data_str:
                results.append({
                    "artifact_id": str(artifact.id),
                    "type": artifact.artifact_type.value,
                    "source": artifact.source_path,
                    "extracted_at": artifact.extracted_at.isoformat(),
                })
        
        return results
    
    async def export_artifacts(
        self,
        artifact_ids: List[UUID],
        output_path: str
    ) -> str:
        """
        导出伪影
        
        Args:
            artifact_ids: 伪影ID列表
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        async with self._lock:
            artifacts = [
                self._artifacts.get(aid) for aid in artifact_ids
                if aid in self._artifacts
            ]
        
        data = {
            "exported_at": datetime.utcnow().isoformat(),
            "artifact_count": len(artifacts),
            "artifacts": [
                {
                    "id": str(a.id),
                    "type": a.artifact_type.value,
                    "source": a.source_path,
                    "extracted_at": a.extracted_at.isoformat(),
                    "data": a.data,
                }
                for a in artifacts
            ],
        }
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(data, indent=2, ensure_ascii=False))
        
        logger.info(f"伪影已导出: {output_file}")
        return str(output_file)
