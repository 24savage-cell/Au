"""
法律包模块

提供证据打包、哈希校验和律师审查接口功能
"""

import asyncio
import hashlib
import json
import logging
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


@dataclass
class LegalPackage:
    """法律证据包"""
    id: UUID
    case_id: str
    package_name: str
    created_at: datetime
    evidence_items: List[Dict[str, Any]]
    chain_of_custody: List[Dict[str, Any]]
    hashes: Dict[str, str]
    attorney_reviewed: bool
    attorney_notes: Optional[str]
    metadata: Dict[str, Any] = field(default_factory=dict)


class LegalPackageGenerator:
    """
    法律包生成器
    
    提供法律证据包功能：
    - 证据打包
    - 哈希校验
    - 律师审查接口
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化法律包生成器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/legal_packages")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._packages: Dict[UUID, LegalPackage] = {}
        self._lock = asyncio.Lock()
        
        logger.info("法律包生成器初始化完成")
    
    async def create_package(
        self,
        case_id: str,
        package_name: str,
        evidence_items: List[Dict[str, Any]],
        chain_of_custody: List[Dict[str, Any]]
    ) -> LegalPackage:
        """
        创建法律证据包
        
        Args:
            case_id: 案件ID
            package_name: 包名称
            evidence_items: 证据项列表
            chain_of_custody: 监管链记录
            
        Returns:
            法律包对象
        """
        # 计算所有证据的哈希
        hashes = {}
        for item in evidence_items:
            item_id = item.get("id", str(uuid4()))
            file_path = item.get("file_path")
            if file_path and Path(file_path).exists():
                file_hash = await self._hash_file(file_path)
                hashes[item_id] = file_hash
        
        package = LegalPackage(
            id=uuid4(),
            case_id=case_id,
            package_name=package_name,
            created_at=datetime.utcnow(),
            evidence_items=evidence_items,
            chain_of_custody=chain_of_custody,
            hashes=hashes,
            attorney_reviewed=False,
            attorney_notes=None,
        )
        
        async with self._lock:
            self._packages[package.id] = package
        
        logger.info(f"法律包已创建: {package.id}")
        return package
    
    async def _hash_file(self, file_path: str) -> str:
        """计算文件哈希"""
        sha256 = hashlib.sha256()
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    async def verify_package_integrity(self, package_id: UUID) -> Dict[str, Any]:
        """
        验证包完整性
        
        Args:
            package_id: 包ID
            
        Returns:
            验证结果
        """
        async with self._lock:
            if package_id not in self._packages:
                return {"valid": False, "error": "包不存在"}
            
            package = self._packages[package_id]
        
        results = []
        all_valid = True
        
        for item in package.evidence_items:
            item_id = item.get("id")
            file_path = item.get("file_path")
            original_hash = package.hashes.get(item_id)
            
            if not file_path or not Path(file_path).exists():
                results.append({
                    "item_id": item_id,
                    "valid": False,
                    "error": "文件不存在",
                })
                all_valid = False
                continue
            
            current_hash = await self._hash_file(file_path)
            valid = current_hash == original_hash
            
            results.append({
                "item_id": item_id,
                "valid": valid,
                "original_hash": original_hash,
                "current_hash": current_hash,
            })
            
            if not valid:
                all_valid = False
        
        return {
            "valid": all_valid,
            "package_id": str(package_id),
            "case_id": package.case_id,
            "item_count": len(package.evidence_items),
            "results": results,
        }
    
    async def submit_for_attorney_review(
        self,
        package_id: UUID,
        attorney_name: str
    ) -> bool:
        """
        提交律师审查
        
        Args:
            package_id: 包ID
            attorney_name: 律师姓名
            
        Returns:
            是否成功
        """
        async with self._lock:
            if package_id not in self._packages:
                return False
            
            package = self._packages[package_id]
            package.metadata["attorney_assigned"] = attorney_name
            package.metadata["review_submitted_at"] = datetime.utcnow().isoformat()
        
        logger.info(f"已提交律师审查: {package_id} -> {attorney_name}")
        return True
    
    async def complete_attorney_review(
        self,
        package_id: UUID,
        approved: bool,
        notes: str
    ) -> bool:
        """
        完成律师审查
        
        Args:
            package_id: 包ID
            approved: 是否批准
            notes: 审查意见
            
        Returns:
            是否成功
        """
        async with self._lock:
            if package_id not in self._packages:
                return False
            
            package = self._packages[package_id]
            package.attorney_reviewed = True
            package.attorney_notes = notes
            package.metadata["review_completed_at"] = datetime.utcnow().isoformat()
            package.metadata["approved"] = approved
        
        logger.info(f"律师审查完成: {package_id}, 批准: {approved}")
        return True
    
    async def export_legal_package(
        self,
        package_id: UUID,
        output_path: Optional[str] = None
    ) -> str:
        """
        导出法律包
        
        Args:
            package_id: 包ID
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        async with self._lock:
            if package_id not in self._packages:
                raise ValueError(f"包不存在: {package_id}")
            
            package = self._packages[package_id]
        
        if output_path is None:
            filename = f"legal_package_{package.case_id}_{datetime.utcnow().strftime('%Y%m%d')}.zip"
            output_path = self.storage_path / filename
        else:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 创建ZIP包
        zip_buffer = BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            # 添加证据文件
            for item in package.evidence_items:
                file_path = item.get("file_path")
                if file_path and Path(file_path).exists():
                    arcname = f"evidence/{Path(file_path).name}"
                    zip_file.write(file_path, arcname)
            
            # 添加清单文件
            manifest = {
                "package_id": str(package.id),
                "case_id": package.case_id,
                "package_name": package.package_name,
                "created_at": package.created_at.isoformat(),
                "evidence_count": len(package.evidence_items),
                "hashes": package.hashes,
                "attorney_reviewed": package.attorney_reviewed,
            }
            zip_file.writestr("manifest.json", json.dumps(manifest, indent=2))
            
            # 添加监管链
            zip_file.writestr(
                "chain_of_custody.json",
                json.dumps(package.chain_of_custody, indent=2)
            )
            
            # 添加律师审查意见
            if package.attorney_reviewed:
                review_doc = f"""
法律审查意见
============

审查状态: {'批准' if package.metadata.get('approved') else '未批准'}
审查意见: {package.attorney_notes or '无'}
审查完成时间: {package.metadata.get('review_completed_at', '未知')}
"""
                zip_file.writestr("attorney_review.txt", review_doc)
        
        # 写入文件
        async with aiofiles.open(output_path, 'wb') as f:
            await f.write(zip_buffer.getvalue())
        
        logger.info(f"法律包已导出: {output_path}")
        return str(output_path)
