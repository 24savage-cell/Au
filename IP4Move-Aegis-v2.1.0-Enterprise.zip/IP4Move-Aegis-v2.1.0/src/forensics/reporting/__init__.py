"""
取证报告模块

提供取证报告生成和法律证据包功能
"""

from .forensic_report import ForensicReportGenerator
from .legal_package import LegalPackageGenerator

__all__ = [
    "ForensicReportGenerator",
    "LegalPackageGenerator",
]
