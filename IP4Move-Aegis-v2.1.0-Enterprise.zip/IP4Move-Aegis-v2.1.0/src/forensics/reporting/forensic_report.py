"""
取证报告模块

提供报告生成、章节管理和PDF/HTML导出功能
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class ReportFormat(Enum):
    """报告格式"""
    PDF = "pdf"
    HTML = "html"
    MARKDOWN = "markdown"
    JSON = "json"


@dataclass
class ReportSection:
    """报告章节"""
    id: UUID
    title: str
    content: str
    order: int
    evidence_refs: List[UUID]
    created_at: datetime


@dataclass
class ForensicReport:
    """取证报告"""
    id: UUID
    case_id: str
    title: str
    author: str
    created_at: datetime
    updated_at: datetime
    sections: List[ReportSection]
    summary: str
    conclusions: str
    metadata: Dict[str, Any] = field(default_factory=dict)


class ForensicReportGenerator:
    """
    取证报告生成器
    
    提供报告生成功能：
    - 报告生成
    - 章节管理
    - PDF/HTML导出
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化报告生成器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/forensic_reports")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._reports: Dict[UUID, ForensicReport] = {}
        self._lock = asyncio.Lock()
        
        logger.info("取证报告生成器初始化完成")
    
    async def create_report(
        self,
        case_id: str,
        title: str,
        author: str
    ) -> ForensicReport:
        """
        创建报告
        
        Args:
            case_id: 案件ID
            title: 标题
            author: 作者
            
        Returns:
            报告对象
        """
        now = datetime.utcnow()
        
        report = ForensicReport(
            id=uuid4(),
            case_id=case_id,
            title=title,
            author=author,
            created_at=now,
            updated_at=now,
            sections=[],
            summary="",
            conclusions="",
        )
        
        async with self._lock:
            self._reports[report.id] = report
        
        logger.info(f"报告已创建: {report.id}")
        return report
    
    async def add_section(
        self,
        report_id: UUID,
        title: str,
        content: str,
        order: Optional[int] = None,
        evidence_refs: List[UUID] = None
    ) -> ReportSection:
        """
        添加章节
        
        Args:
            report_id: 报告ID
            title: 标题
            content: 内容
            order: 顺序
            evidence_refs: 证据引用
            
        Returns:
            章节对象
        """
        if evidence_refs is None:
            evidence_refs = []
        
        async with self._lock:
            if report_id not in self._reports:
                raise ValueError(f"报告不存在: {report_id}")
            
            report = self._reports[report_id]
            
            if order is None:
                order = len(report.sections) + 1
        
        section = ReportSection(
            id=uuid4(),
            title=title,
            content=content,
            order=order,
            evidence_refs=evidence_refs,
            created_at=datetime.utcnow(),
        )
        
        async with self._lock:
            report.sections.append(section)
            report.sections.sort(key=lambda x: x.order)
            report.updated_at = datetime.utcnow()
        
        logger.info(f"章节已添加: {section.id}")
        return section
    
    async def update_summary(
        self,
        report_id: UUID,
        summary: str
    ) -> bool:
        """
        更新摘要
        
        Args:
            report_id: 报告ID
            summary: 摘要
            
        Returns:
            是否成功
        """
        async with self._lock:
            if report_id not in self._reports:
                return False
            
            report = self._reports[report_id]
            report.summary = summary
            report.updated_at = datetime.utcnow()
        
        return True
    
    async def update_conclusions(
        self,
        report_id: UUID,
        conclusions: str
    ) -> bool:
        """
        更新结论
        
        Args:
            report_id: 报告ID
            conclusions: 结论
            
        Returns:
            是否成功
        """
        async with self._lock:
            if report_id not in self._reports:
                return False
            
            report = self._reports[report_id]
            report.conclusions = conclusions
            report.updated_at = datetime.utcnow()
        
        return True
    
    async def export_report(
        self,
        report_id: UUID,
        output_format: ReportFormat,
        output_path: Optional[str] = None
    ) -> str:
        """
        导出报告
        
        Args:
            report_id: 报告ID
            output_format: 输出格式
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        async with self._lock:
            if report_id not in self._reports:
                raise ValueError(f"报告不存在: {report_id}")
            
            report = self._reports[report_id]
        
        if output_path is None:
            filename = f"forensic_report_{report.case_id}_{datetime.utcnow().strftime('%Y%m%d')}.{output_format.value}"
            output_path = self.storage_path / filename
        else:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if output_format == ReportFormat.MARKDOWN:
            await self._export_markdown(report, output_path)
        elif output_format == ReportFormat.HTML:
            await self._export_html(report, output_path)
        elif output_format == ReportFormat.JSON:
            await self._export_json(report, output_path)
        else:
            # 默认Markdown
            await self._export_markdown(report, output_path)
        
        logger.info(f"报告已导出: {output_path}")
        return str(output_path)
    
    async def _export_markdown(self, report: ForensicReport, output_path: Path) -> None:
        """导出为Markdown"""
        lines = []
        
        # 标题
        lines.append(f"# {report.title}")
        lines.append("")
        lines.append(f"**案件ID**: {report.case_id}")
        lines.append(f"**作者**: {report.author}")
        lines.append(f"**创建时间**: {report.created_at.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**更新时间**: {report.updated_at.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("")
        
        # 摘要
        lines.append("## 执行摘要")
        lines.append("")
        lines.append(report.summary or "（待填写）")
        lines.append("")
        
        # 章节
        for section in report.sections:
            lines.append(f"## {section.title}")
            lines.append("")
            lines.append(section.content)
            lines.append("")
        
        # 结论
        lines.append("## 结论")
        lines.append("")
        lines.append(report.conclusions or "（待填写）")
        lines.append("")
        
        async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
            await f.write('\n'.join(lines))
    
    async def _export_html(self, report: ForensicReport, output_path: Path) -> None:
        """导出为HTML"""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{report.title}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        h1 {{ color: #333; }}
        h2 {{ color: #666; border-bottom: 1px solid #ddd; padding-bottom: 5px; }}
        .metadata {{ color: #999; font-size: 0.9em; }}
        .section {{ margin: 20px 0; }}
    </style>
</head>
<body>
    <h1>{report.title}</h1>
    <div class="metadata">
        <p><strong>案件ID:</strong> {report.case_id}</p>
        <p><strong>作者:</strong> {report.author}</p>
        <p><strong>创建时间:</strong> {report.created_at.strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>
    
    <h2>执行摘要</h2>
    <p>{report.summary or "（待填写）"}</p>
"""
        
        for section in report.sections:
            html += f"""
    <div class="section">
        <h2>{section.title}</h2>
        <p>{section.content}</p>
    </div>
"""
        
        html += f"""
    <h2>结论</h2>
    <p>{report.conclusions or "（待填写）"}</p>
</body>
</html>
"""
        
        async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
            await f.write(html)
    
    async def _export_json(self, report: ForensicReport, output_path: Path) -> None:
        """导出为JSON"""
        data = {
            "id": str(report.id),
            "case_id": report.case_id,
            "title": report.title,
            "author": report.author,
            "created_at": report.created_at.isoformat(),
            "updated_at": report.updated_at.isoformat(),
            "summary": report.summary,
            "conclusions": report.conclusions,
            "sections": [
                {
                    "id": str(s.id),
                    "title": s.title,
                    "content": s.content,
                    "order": s.order,
                }
                for s in report.sections
            ],
        }
        
        async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(data, indent=2, ensure_ascii=False))
