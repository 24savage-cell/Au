"""
合规与透明度模块 (Compliance & Transparency Module)

本模块提供合规性管理和透明度相关的核心功能，包括：
- 安全报告自动生成 (Automated Security Report Generation)
- 漏洞赏金计划管理 (Bug Bounty Program Management)
- 合规性设计框架 (Compliance Design Framework)
- 透明度日志 (Transparency Log)

支持 GDPR、CCPA 等主流隐私法规的合规检查，
并提供完整的审计追踪能力。

This module provides compliance management and transparency functionalities:
- Automated security report generation
- Bug bounty program management
- Compliance design framework (GDPR, CCPA, etc.)
- Transparency logging with tamper-proof audit trails
"""

from src.compliance.compliance_framework import (
    SecurityReportGenerator,
    BugBountyManager,
    ComplianceFramework,
    TransparencyLog,
)

__all__ = [
    "SecurityReportGenerator",
    "BugBountyManager",
    "ComplianceFramework",
    "TransparencyLog",
]

__version__ = "1.0.0"
__author__ = "IP4Move Aegis Security Team"
