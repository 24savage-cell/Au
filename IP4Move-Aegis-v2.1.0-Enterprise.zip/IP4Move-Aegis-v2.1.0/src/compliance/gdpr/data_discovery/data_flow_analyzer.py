"""
数据流分析模块

提供数据流图构建、跨境数据流检测和数据依赖分析功能
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class FlowDirection(Enum):
    """数据流方向"""
    INBOUND = "inbound"         # 入站
    OUTBOUND = "outbound"       # 出站
    INTERNAL = "internal"       # 内部
    BIDIRECTIONAL = "bidirectional"  # 双向


class FlowType(Enum):
    """数据流类型"""
    API = "api"                 # API调用
    DATABASE = "database"       # 数据库同步
    FILE_TRANSFER = "file"      # 文件传输
    MESSAGE_QUEUE = "mq"        # 消息队列
    STREAMING = "streaming"     # 流式传输
    EMAIL = "email"             # 邮件
    MANUAL = "manual"           # 人工处理


@dataclass
class DataNode:
    """数据节点"""
    id: UUID
    name: str
    node_type: str            # system/database/application/user
    location: str             # 地理位置
    jurisdiction: str         # 司法管辖区
    owner: str
    description: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DataEdge:
    """数据边（流）"""
    id: UUID
    source_id: UUID
    target_id: UUID
    flow_type: FlowType
    direction: FlowDirection
    data_types: List[str]
    volume_estimate: str      # 数据量估计
    frequency: str            # 传输频率
    legal_basis: str
    safeguards: List[str]
    cross_border: bool
    third_countries: List[str]
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class FlowPath:
    """数据流路径"""
    nodes: List[UUID]
    edges: List[UUID]
    risk_score: float
    cross_border_segments: int
    third_countries: Set[str]


class DataFlowAnalyzer:
    """
    数据流分析器
    
    构建数据流图，检测跨境传输，分析数据依赖关系
    """
    
    # 欧盟成员国
    EU_COUNTRIES = {
        'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR',
        'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL',
        'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE'
    }
    
    # 充分性决定国家
    ADEQUACY_COUNTRIES = {
        'AD', 'AR', 'CA', 'CH', 'FO', 'GB', 'GG', 'IL', 'IM', 'JE',
        'JP', 'NZ', 'UY', 'US'  # 美国需符合Privacy Shield框架
    }
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化数据流分析器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/flow_analyzer")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._nodes: Dict[UUID, DataNode] = {}
        self._edges: Dict[UUID, DataEdge] = {}
        self._lock = asyncio.Lock()
        
        logger.info(f"数据流分析器初始化完成")
    
    async def add_node(
        self,
        name: str,
        node_type: str,
        location: str,
        jurisdiction: str,
        owner: str,
        description: str = "",
        metadata: Dict[str, Any] = None
    ) -> DataNode:
        """
        添加数据节点
        
        Args:
            name: 节点名称
            node_type: 节点类型
            location: 地理位置
            jurisdiction: 司法管辖区
            owner: 所有者
            description: 描述
            metadata: 元数据
            
        Returns:
            创建的节点
        """
        if metadata is None:
            metadata = {}
        
        node = DataNode(
            id=uuid4(),
            name=name,
            node_type=node_type,
            location=location,
            jurisdiction=jurisdiction,
            owner=owner,
            description=description,
            metadata=metadata,
        )
        
        async with self._lock:
            self._nodes[node.id] = node
        
        logger.info(f"数据节点添加: {name} ({node.id})")
        return node
    
    async def add_edge(
        self,
        source_id: UUID,
        target_id: UUID,
        flow_type: FlowType,
        direction: FlowDirection,
        data_types: List[str],
        legal_basis: str,
        volume_estimate: str = "unknown",
        frequency: str = "unknown",
        safeguards: List[str] = None,
        third_countries: List[str] = None
    ) -> DataEdge:
        """
        添加数据流边
        
        Args:
            source_id: 源节点ID
            target_id: 目标节点ID
            flow_type: 流类型
            direction: 方向
            data_types: 数据类型列表
            legal_basis: 法律依据
            volume_estimate: 数据量估计
            frequency: 传输频率
            safeguards: 保障措施
            third_countries: 第三国列表
            
        Returns:
            创建的边
        """
        if safeguards is None:
            safeguards = []
        if third_countries is None:
            third_countries = []
        
        async with self._lock:
            if source_id not in self._nodes:
                raise ValueError(f"源节点不存在: {source_id}")
            if target_id not in self._nodes:
                raise ValueError(f"目标节点不存在: {target_id}")
            
            source = self._nodes[source_id]
            target = self._nodes[target_id]
            
            # 检测跨境
            cross_border = self._is_cross_border(source.jurisdiction, target.jurisdiction)
            
            edge = DataEdge(
                id=uuid4(),
                source_id=source_id,
                target_id=target_id,
                flow_type=flow_type,
                direction=direction,
                data_types=data_types,
                volume_estimate=volume_estimate,
                frequency=frequency,
                legal_basis=legal_basis,
                safeguards=safeguards,
                cross_border=cross_border,
                third_countries=third_countries,
            )
            
            self._edges[edge.id] = edge
        
        logger.info(f"数据流边添加: {source.name} -> {target.name}")
        return edge
    
    def _is_cross_border(self, source_jurisdiction: str, target_jurisdiction: str) -> bool:
        """检测是否跨境传输"""
        source_upper = source_jurisdiction.upper()
        target_upper = target_jurisdiction.upper()
        
        # 欧盟内部传输
        if source_upper in self.EU_COUNTRIES and target_upper in self.EU_COUNTRIES:
            return False
        
        # 同一司法管辖区
        if source_upper == target_upper:
            return False
        
        # 充分性决定国家
        if target_upper in self.ADEQUACY_COUNTRIES:
            return False
        
        return True
    
    async def build_flow_graph(self) -> Dict[str, Any]:
        """
        构建数据流图
        
        Returns:
            图数据
        """
        async with self._lock:
            nodes_data = []
            for node in self._nodes.values():
                nodes_data.append({
                    "id": str(node.id),
                    "name": node.name,
                    "type": node.node_type,
                    "location": node.location,
                    "jurisdiction": node.jurisdiction,
                    "owner": node.owner,
                })
            
            edges_data = []
            for edge in self._edges.values():
                source = self._nodes[edge.source_id]
                target = self._nodes[edge.target_id]
                
                edges_data.append({
                    "id": str(edge.id),
                    "source": str(edge.source_id),
                    "target": str(edge.target_id),
                    "source_name": source.name,
                    "target_name": target.name,
                    "flow_type": edge.flow_type.value,
                    "direction": edge.direction.value,
                    "cross_border": edge.cross_border,
                    "legal_basis": edge.legal_basis,
                })
            
            return {
                "nodes": nodes_data,
                "edges": edges_data,
                "metadata": {
                    "total_nodes": len(nodes_data),
                    "total_edges": len(edges_data),
                    "cross_border_edges": sum(1 for e in edges_data if e["cross_border"]),
                }
            }
    
    async def detect_cross_border_flows(self) -> List[Dict[str, Any]]:
        """
        检测跨境数据流
        
        Returns:
            跨境流列表
        """
        async with self._lock:
            cross_border_flows = []
            
            for edge in self._edges.values():
                if edge.cross_border:
                    source = self._nodes[edge.source_id]
                    target = self._nodes[edge.target_id]
                    
                    # 评估风险
                    risk_level = self._assess_flow_risk(edge)
                    
                    cross_border_flows.append({
                        "edge_id": str(edge.id),
                        "source": {
                            "id": str(source.id),
                            "name": source.name,
                            "jurisdiction": source.jurisdiction,
                        },
                        "target": {
                            "id": str(target.id),
                            "name": target.name,
                            "jurisdiction": target.jurisdiction,
                        },
                        "data_types": edge.data_types,
                        "legal_basis": edge.legal_basis,
                        "safeguards": edge.safeguards,
                        "third_countries": edge.third_countries,
                        "risk_level": risk_level,
                    })
            
            return cross_border_flows
    
    def _assess_flow_risk(self, edge: DataEdge) -> str:
        """评估数据流风险等级"""
        risk_score = 0
        
        # 敏感数据类型增加风险
        sensitive_types = {'personal', 'sensitive', 'financial', 'health', 'biometric'}
        for data_type in edge.data_types:
            if data_type.lower() in sensitive_types:
                risk_score += 2
        
        # 缺乏保障措施增加风险
        if not edge.safeguards:
            risk_score += 3
        
        # 传输到第三国增加风险
        if edge.third_countries:
            risk_score += 2
        
        if risk_score >= 5:
            return "high"
        elif risk_score >= 3:
            return "medium"
        else:
            return "low"
    
    async def find_data_paths(
        self,
        source_id: UUID,
        target_id: UUID,
        max_depth: int = 10
    ) -> List[FlowPath]:
        """
        查找数据路径
        
        Args:
            source_id: 源节点ID
            target_id: 目标节点ID
            max_depth: 最大深度
            
        Returns:
            路径列表
        """
        async with self._lock:
            if source_id not in self._nodes or target_id not in self._nodes:
                return []
            
            paths = []
            visited = set()
            
            async def dfs(current_id: UUID, path_nodes: List[UUID], path_edges: List[UUID], depth: int):
                if depth > max_depth:
                    return
                
                if current_id == target_id:
                    # 计算路径风险
                    risk_score = 0
                    cross_segments = 0
                    countries = set()
                    
                    for edge_id in path_edges:
                        edge = self._edges[edge_id]
                        if edge.cross_border:
                            cross_segments += 1
                            countries.update(edge.third_countries)
                        if edge.flow_type in [FlowType.EMAIL, FlowType.MANUAL]:
                            risk_score += 1
                    
                    paths.append(FlowPath(
                        nodes=path_nodes.copy(),
                        edges=path_edges.copy(),
                        risk_score=risk_score,
                        cross_border_segments=cross_segments,
                        third_countries=countries,
                    ))
                    return
                
                # 查找出边
                for edge in self._edges.values():
                    if edge.source_id == current_id and edge.id not in path_edges:
                        next_id = edge.target_id
                        if next_id not in visited:
                            visited.add(next_id)
                            path_nodes.append(next_id)
                            path_edges.append(edge.id)
                            
                            await dfs(next_id, path_nodes, path_edges, depth + 1)
                            
                            path_nodes.pop()
                            path_edges.pop()
                            visited.remove(next_id)
            
            await dfs(source_id, [source_id], [], 0)
            return paths
    
    async def analyze_dependencies(self, node_id: UUID) -> Dict[str, Any]:
        """
        分析节点依赖关系
        
        Args:
            node_id: 节点ID
            
        Returns:
            依赖分析结果
        """
        async with self._lock:
            if node_id not in self._nodes:
                return {}
            
            node = self._nodes[node_id]
            
            # 上游依赖（入边）
            upstream = []
            for edge in self._edges.values():
                if edge.target_id == node_id:
                    source = self._nodes[edge.source_id]
                    upstream.append({
                        "node_id": str(source.id),
                        "node_name": source.name,
                        "edge_id": str(edge.id),
                        "flow_type": edge.flow_type.value,
                        "data_types": edge.data_types,
                    })
            
            # 下游依赖（出边）
            downstream = []
            for edge in self._edges.values():
                if edge.source_id == node_id:
                    target = self._nodes[edge.target_id]
                    downstream.append({
                        "node_id": str(target.id),
                        "node_name": target.name,
                        "edge_id": str(edge.id),
                        "flow_type": edge.flow_type.value,
                        "data_types": edge.data_types,
                    })
            
            return {
                "node_id": str(node_id),
                "node_name": node.name,
                "upstream_dependencies": upstream,
                "downstream_dependencies": downstream,
                "total_dependencies": len(upstream) + len(downstream),
            }
    
    async def identify_bottlenecks(self) -> List[Dict[str, Any]]:
        """
        识别数据流瓶颈
        
        Returns:
            瓶颈节点列表
        """
        async with self._lock:
            # 计算每个节点的入度和出度
            in_degree = {node_id: 0 for node_id in self._nodes}
            out_degree = {node_id: 0 for node_id in self._nodes}
            
            for edge in self._edges.values():
                out_degree[edge.source_id] += 1
                in_degree[edge.target_id] += 1
            
            # 识别高度连接的节点
            bottlenecks = []
            for node_id, node in self._nodes.items():
                total_degree = in_degree[node_id] + out_degree[node_id]
                if total_degree > 5:  # 阈值
                    bottlenecks.append({
                        "node_id": str(node_id),
                        "node_name": node.name,
                        "in_degree": in_degree[node_id],
                        "out_degree": out_degree[node_id],
                        "total_degree": total_degree,
                        "risk": "high" if total_degree > 10 else "medium",
                    })
            
            return sorted(bottlenecks, key=lambda x: x["total_degree"], reverse=True)
    
    async def export_to_graphviz(self, output_path: str) -> str:
        """
        导出为Graphviz格式
        
        Args:
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        lines = ["digraph DataFlow {"]
        lines.append("  rankdir=LR;")
        lines.append('  node [shape=box, style=rounded];')
        
        async with self._lock:
            # 添加节点
            for node in self._nodes.values():
                color = "lightblue" if node.jurisdiction in self.EU_COUNTRIES else "lightyellow"
                lines.append(f'  "{node.id}" [label="{node.name}", fillcolor={color}, style=filled];')
            
            # 添加边
            for edge in self._edges.values():
                color = "red" if edge.cross_border else "black"
                style = "dashed" if edge.flow_type == FlowType.MANUAL else "solid"
                lines.append(
                    f'  "{edge.source_id}" -> "{edge.target_id}" '
                    f'[color={color}, style={style}, label="{edge.flow_type.value}"];'
                )
        
        lines.append("}")
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write('\n'.join(lines))
        
        logger.info(f"Graphviz文件已导出: {output_file}")
        return str(output_file)
    
    async def generate_compliance_report(self) -> Dict[str, Any]:
        """
        生成合规报告
        
        Returns:
            合规报告
        """
        cross_border = await self.detect_cross_border_flows()
        bottlenecks = await self.identify_bottlenecks()
        
        # 合规检查
        compliance_issues = []
        
        for flow in cross_border:
            if not flow["safeguards"]:
                compliance_issues.append({
                    "severity": "high",
                    "issue": "跨境传输缺乏保障措施",
                    "flow": flow,
                })
            
            if flow["legal_basis"] not in ["consent", "contract", "legal_obligation", "vital_interests", "public_task", "legitimate_interests"]:
                compliance_issues.append({
                    "severity": "medium",
                    "issue": "法律依据不明确",
                    "flow": flow,
                })
        
        return {
            "generated_at": datetime.utcnow().isoformat(),
            "summary": {
                "total_nodes": len(self._nodes),
                "total_edges": len(self._edges),
                "cross_border_flows": len(cross_border),
                "bottlenecks": len(bottlenecks),
                "compliance_issues": len(compliance_issues),
            },
            "cross_border_flows": cross_border,
            "bottlenecks": bottlenecks,
            "compliance_issues": compliance_issues,
        }
