"""
PII扫描模块

提供个人身份信息(PII)的检测功能，支持正则匹配、NER模型和多语言检测
"""

import asyncio
import hashlib
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class PIIType(Enum):
    """PII类型枚举"""
    # 基础PII
    EMAIL = auto()
    PHONE = auto()
    NAME = auto()
    ADDRESS = auto()
    DATE_OF_BIRTH = auto()
    
    # 身份标识
    NATIONAL_ID = auto()        # 身份证号
    PASSPORT = auto()           # 护照号
    DRIVER_LICENSE = auto()     # 驾照号
    SOCIAL_SECURITY = auto()    # 社保号
    TAX_ID = auto()             # 税号
    
    # 金融信息
    CREDIT_CARD = auto()        # 信用卡号
    BANK_ACCOUNT = auto()       # 银行账号
    IBAN = auto()               # IBAN
    
    # 在线标识
    IP_ADDRESS = auto()         # IP地址
    MAC_ADDRESS = auto()        # MAC地址
    USERNAME = auto()           # 用户名
    
    # 生物识别
    FINGERPRINT = auto()        # 指纹
    FACE_PRINT = auto()         # 面部特征
    VOICE_PRINT = auto()        # 声纹
    
    # 健康信息
    MEDICAL_RECORD = auto()     # 医疗记录
    HEALTH_INSURANCE = auto()   # 医保号
    
    # 位置信息
    GPS_COORDINATES = auto()    # GPS坐标
    GEOLOCATION = auto()        # 地理位置
    
    # 其他
    CUSTOM = auto()             # 自定义


@dataclass
class PIIFinding:
    """PII发现结果"""
    id: UUID
    pii_type: PIIType
    value_hash: str           # PII值的哈希（不存储原始值）
    value_preview: str        # 脱敏预览
    confidence: float         # 置信度 0-1
    location: str             # 发现位置
    field_name: Optional[str] # 字段名
    line_number: Optional[int] = None
    column_start: Optional[int] = None
    column_end: Optional[int] = None
    context: str = ""         # 上下文
    detected_at: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": str(self.id),
            "pii_type": self.pii_type.name,
            "value_hash": self.value_hash,
            "value_preview": self.value_preview,
            "confidence": self.confidence,
            "location": self.location,
            "field_name": self.field_name,
            "line_number": self.line_number,
            "column_start": self.column_start,
            "column_end": self.column_end,
            "context": self.context,
            "detected_at": self.detected_at.isoformat(),
        }


class PIIScanner:
    """
    PII扫描器
    
    支持多种检测方法：
    - 正则表达式匹配
    - NER模型识别
    - 多语言PII检测
    """
    
    # 正则表达式模式
    PATTERNS = {
        PIIType.EMAIL: re.compile(
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            re.IGNORECASE
        ),
        PIIType.PHONE: re.compile(
            r'\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b'
        ),
        PIIType.CREDIT_CARD: re.compile(
            r'\b(?:\d{4}[-\s]?){3}\d{4}\b'
        ),
        PIIType.IP_ADDRESS: re.compile(
            r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b'
        ),
        PIIType.MAC_ADDRESS: re.compile(
            r'\b(?:[0-9A-Fa-f]{2}[:-]){5}(?:[0-9A-Fa-f]{2})\b'
        ),
        PIIType.NATIONAL_ID: re.compile(
            r'\b\d{17}[\dXx]\b'  # 中国身份证号
        ),
        PIIType.DATE_OF_BIRTH: re.compile(
            r'\b(?:19|20)\d{2}[-/](?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12]\d|3[01])\b'
        ),
    }
    
    # 多语言模式
    MULTILANG_PATTERNS = {
        'zh': {
            PIIType.NATIONAL_ID: re.compile(r'\b\d{17}[\dXx]\b'),
            PIIType.PHONE: re.compile(r'\b1[3-9]\d{9}\b'),
        },
        'en': {
            PIIType.SOCIAL_SECURITY: re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
            PIIType.PHONE: re.compile(r'\b\(\d{3}\)\s?\d{3}-\d{4}\b'),
        },
        'de': {
            PIIType.TAX_ID: re.compile(r'\b\d{11}\b'),
        },
    }
    
    def __init__(
        self,
        use_ner: bool = False,
        ner_model: Optional[str] = None,
        confidence_threshold: float = 0.8,
        enable_multilang: bool = True
    ):
        """
        初始化PII扫描器
        
        Args:
            use_ner: 是否使用NER模型
            ner_model: NER模型路径或名称
            confidence_threshold: 置信度阈值
            enable_multilang: 是否启用多语言检测
        """
        self.use_ner = use_ner
        self.ner_model = ner_model
        self.confidence_threshold = confidence_threshold
        self.enable_multilang = enable_multilang
        
        self._ner_pipeline = None
        self._custom_patterns: Dict[str, re.Pattern] = {}
        
        if use_ner:
            self._init_ner_model()
        
        logger.info(f"PII扫描器初始化完成 (NER: {use_ner}, 多语言: {enable_multilang})")
    
    def _init_ner_model(self) -> None:
        """初始化NER模型"""
        try:
            # 这里可以集成transformers等NER模型
            # from transformers import pipeline
            # self._ner_pipeline = pipeline("ner", model=self.ner_model)
            logger.info("NER模型初始化完成")
        except Exception as e:
            logger.warning(f"NER模型初始化失败: {e}")
            self.use_ner = False
    
    def add_custom_pattern(
        self,
        name: str,
        pattern: str,
        pii_type: PIIType = PIIType.CUSTOM
    ) -> None:
        """
        添加自定义检测模式
        
        Args:
            name: 模式名称
            pattern: 正则表达式
            pii_type: PII类型
        """
        try:
            compiled = re.compile(pattern)
            self._custom_patterns[name] = compiled
            logger.info(f"自定义模式添加成功: {name}")
        except re.error as e:
            logger.error(f"自定义模式编译失败: {e}")
    
    async def scan_text(
        self,
        text: str,
        location: str = "unknown",
        language: Optional[str] = None
    ) -> List[PIIFinding]:
        """
        扫描文本中的PII
        
        Args:
            text: 要扫描的文本
            location: 文本来源位置
            language: 语言代码 (zh/en/de等)
            
        Returns:
            PII发现列表
        """
        findings = []
        
        # 正则匹配
        regex_findings = await self._scan_with_regex(text, location, language)
        findings.extend(regex_findings)
        
        # NER模型检测
        if self.use_ner and self._ner_pipeline:
            ner_findings = await self._scan_with_ner(text, location)
            findings.extend(ner_findings)
        
        # 去重
        findings = self._deduplicate_findings(findings)
        
        return findings
    
    async def _scan_with_regex(
        self,
        text: str,
        location: str,
        language: Optional[str] = None
    ) -> List[PIIFinding]:
        """使用正则表达式扫描"""
        findings = []
        lines = text.split('\n')
        
        # 基础模式
        for pii_type, pattern in self.PATTERNS.items():
            for line_num, line in enumerate(lines, 1):
                for match in pattern.finditer(line):
                    if self._validate_match(pii_type, match.group()):
                        finding = self._create_finding(
                            pii_type=pii_type,
                            value=match.group(),
                            location=location,
                            line_number=line_num,
                            column_start=match.start(),
                            column_end=match.end(),
                            context=line[max(0, match.start()-20):match.end()+20]
                        )
                        if finding.confidence >= self.confidence_threshold:
                            findings.append(finding)
        
        # 多语言模式
        if self.enable_multilang and language:
            lang_patterns = self.MULTILANG_PATTERNS.get(language, {})
            for pii_type, pattern in lang_patterns.items():
                for line_num, line in enumerate(lines, 1):
                    for match in pattern.finditer(line):
                        finding = self._create_finding(
                            pii_type=pii_type,
                            value=match.group(),
                            location=location,
                            line_number=line_num,
                            column_start=match.start(),
                            column_end=match.end(),
                            context=line[max(0, match.start()-20):match.end()+20]
                        )
                        if finding.confidence >= self.confidence_threshold:
                            findings.append(finding)
        
        # 自定义模式
        for name, pattern in self._custom_patterns.items():
            for line_num, line in enumerate(lines, 1):
                for match in pattern.finditer(line):
                    finding = self._create_finding(
                        pii_type=PIIType.CUSTOM,
                        value=match.group(),
                        location=location,
                        line_number=line_num,
                        column_start=match.start(),
                        column_end=match.end(),
                        context=line[max(0, match.start()-20):match.end()+20]
                    )
                    if finding.confidence >= self.confidence_threshold:
                        findings.append(finding)
        
        return findings
    
    async def _scan_with_ner(self, text: str, location: str) -> List[PIIFinding]:
        """使用NER模型扫描"""
        findings = []
        
        if not self._ner_pipeline:
            return findings
        
        try:
            # 运行NER模型
            # entities = self._ner_pipeline(text)
            # 处理实体结果...
            pass
        except Exception as e:
            logger.error(f"NER扫描失败: {e}")
        
        return findings
    
    def _validate_match(self, pii_type: PIIType, value: str) -> bool:
        """验证匹配结果"""
        if pii_type == PIIType.CREDIT_CARD:
            return self._luhn_check(value.replace('-', '').replace(' ', ''))
        if pii_type == PIIType.NATIONAL_ID:
            return self._validate_chinese_id(value)
        return True
    
    def _luhn_check(self, card_number: str) -> bool:
        """Luhn算法验证信用卡号"""
        if not card_number.isdigit():
            return False
        
        digits = [int(d) for d in card_number]
        odd_digits = digits[-1::-2]
        even_digits = digits[-2::-2]
        
        total = sum(odd_digits)
        for d in even_digits:
            d *= 2
            if d > 9:
                d -= 9
            total += d
        
        return total % 10 == 0
    
    def _validate_chinese_id(self, id_number: str) -> bool:
        """验证中国身份证号"""
        if len(id_number) != 18:
            return False
        
        weights = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
        check_codes = '10X98765432'
        
        try:
            sum_val = sum(int(id_number[i]) * weights[i] for i in range(17))
            return check_codes[sum_val % 11].upper() == id_number[17].upper()
        except (ValueError, IndexError):
            return False
    
    def _create_finding(
        self,
        pii_type: PIIType,
        value: str,
        location: str,
        line_number: Optional[int] = None,
        column_start: Optional[int] = None,
        column_end: Optional[int] = None,
        context: str = "",
        field_name: Optional[str] = None
    ) -> PIIFinding:
        """创建PII发现记录"""
        # 计算哈希
        value_hash = hashlib.sha256(value.encode()).hexdigest()
        
        # 生成脱敏预览
        if len(value) <= 4:
            preview = "****"
        else:
            preview = value[:2] + "****" + value[-2:]
        
        # 计算置信度
        confidence = self._calculate_confidence(pii_type, value)
        
        return PIIFinding(
            id=uuid4(),
            pii_type=pii_type,
            value_hash=value_hash,
            value_preview=preview,
            confidence=confidence,
            location=location,
            field_name=field_name,
            line_number=line_number,
            column_start=column_start,
            column_end=column_end,
            context=context[:200],  # 限制上下文长度
        )
    
    def _calculate_confidence(self, pii_type: PIIType, value: str) -> float:
        """计算置信度"""
        base_confidence = 0.9
        
        # 根据类型调整
        if pii_type == PIIType.EMAIL:
            if '@' in value and '.' in value.split('@')[1]:
                base_confidence = 0.95
        elif pii_type == PIIType.PHONE:
            digits = len(re.sub(r'\D', '', value))
            if digits >= 10:
                base_confidence = 0.92
        elif pii_type == PIIType.CREDIT_CARD:
            if self._luhn_check(value.replace('-', '').replace(' ', '')):
                base_confidence = 0.98
        
        return base_confidence
    
    def _deduplicate_findings(self, findings: List[PIIFinding]) -> List[PIIFinding]:
        """去重"""
        seen = set()
        unique = []
        
        for finding in findings:
            key = (finding.pii_type, finding.value_hash, finding.location)
            if key not in seen:
                seen.add(key)
                unique.append(finding)
        
        return unique
    
    async def scan_file(
        self,
        file_path: Union[str, Path],
        file_type: Optional[str] = None
    ) -> List[PIIFinding]:
        """
        扫描文件中的PII
        
        Args:
            file_path: 文件路径
            file_type: 文件类型 (csv/json/txt等)
            
        Returns:
            PII发现列表
        """
        path = Path(file_path)
        
        if not path.exists():
            logger.error(f"文件不存在: {file_path}")
            return []
        
        try:
            async with aiofiles.open(path, 'r', encoding='utf-8', errors='ignore') as f:
                content = await f.read()
            
            # 根据文件类型处理
            if file_type == 'json' or path.suffix == '.json':
                return await self._scan_json(content, str(path))
            elif file_type == 'csv' or path.suffix == '.csv':
                return await self._scan_csv(content, str(path))
            else:
                return await self.scan_text(content, str(path))
        
        except Exception as e:
            logger.error(f"文件扫描失败 {file_path}: {e}")
            return []
    
    async def _scan_json(self, content: str, location: str) -> List[PIIFinding]:
        """扫描JSON内容"""
        findings = []
        
        try:
            data = json.loads(content)
            findings.extend(await self._scan_json_object(data, location))
        except json.JSONDecodeError:
            # 作为纯文本扫描
            findings.extend(await self.scan_text(content, location))
        
        return findings
    
    async def _scan_json_object(
        self,
        obj: Any,
        location: str,
        path: str = ""
    ) -> List[PIIFinding]:
        """递归扫描JSON对象"""
        findings = []
        
        if isinstance(obj, dict):
            for key, value in obj.items():
                current_path = f"{path}.{key}" if path else key
                
                if isinstance(value, str):
                    field_findings = await self.scan_text(value, location)
                    for finding in field_findings:
                        finding.field_name = current_path
                    findings.extend(field_findings)
                elif isinstance(value, (dict, list)):
                    findings.extend(await self._scan_json_object(value, location, current_path))
        
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                current_path = f"{path}[{i}]"
                findings.extend(await self._scan_json_object(item, location, current_path))
        
        return findings
    
    async def _scan_csv(self, content: str, location: str) -> List[PIIFinding]:
        """扫描CSV内容"""
        findings = []
        lines = content.split('\n')
        
        if not lines:
            return findings
        
        # 解析表头
        headers = lines[0].split(',')
        
        for line_num, line in enumerate(lines[1:], 2):
            values = line.split(',')
            for col_num, value in enumerate(values):
                if col_num < len(headers):
                    field_name = headers[col_num].strip()
                else:
                    field_name = f"column_{col_num}"
                
                field_findings = await self.scan_text(value.strip(), location)
                for finding in field_findings:
                    finding.field_name = field_name
                    finding.line_number = line_num
                findings.extend(field_findings)
        
        return findings
    
    async def scan_directory(
        self,
        directory: Union[str, Path],
        patterns: List[str] = None,
        recursive: bool = True
    ) -> Dict[str, List[PIIFinding]]:
        """
        扫描目录中的所有文件
        
        Args:
            directory: 目录路径
            patterns: 文件匹配模式
            recursive: 是否递归扫描
            
        Returns:
            文件路径到PII发现的映射
        """
        if patterns is None:
            patterns = ['*.txt', '*.csv', '*.json', '*.xml', '*.log']
        
        results = {}
        dir_path = Path(directory)
        
        if not dir_path.exists():
            logger.error(f"目录不存在: {directory}")
            return results
        
        for pattern in patterns:
            if recursive:
                files = list(dir_path.rglob(pattern))
            else:
                files = list(dir_path.glob(pattern))
            
            for file_path in files:
                findings = await self.scan_file(file_path)
                if findings:
                    results[str(file_path)] = findings
        
        return results
    
    def generate_report(self, findings: List[PIIFinding]) -> Dict[str, Any]:
        """
        生成扫描报告
        
        Args:
            findings: PII发现列表
            
        Returns:
            报告数据
        """
        # 按类型统计
        type_counts = {}
        for finding in findings:
            type_name = finding.pii_type.name
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
        
        # 按位置统计
        location_counts = {}
        for finding in findings:
            location_counts[finding.location] = location_counts.get(finding.location, 0) + 1
        
        # 风险等级
        high_risk_types = {PIIType.CREDIT_CARD, PIIType.NATIONAL_ID, PIIType.PASSPORT}
        high_risk_count = sum(
            1 for f in findings if f.pii_type in high_risk_types
        )
        
        return {
            "generated_at": datetime.utcnow().isoformat(),
            "summary": {
                "total_findings": len(findings),
                "unique_types": len(type_counts),
                "high_risk_findings": high_risk_count,
            },
            "type_distribution": type_counts,
            "location_distribution": location_counts,
            "findings": [f.to_dict() for f in findings],
        }
