"""
数据地图模块

提供数据资产发现、分类分级和数据流映射功能
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles
from typing_extensions import TypedDict

logger = logging.getLogger(__name__)


class DataClassification(Enum):
    """数据分类级别"""
    PUBLIC = "public"           # 公开数据
    INTERNAL = "internal"       # 内部数据
    CONFIDENTIAL = "confidential"  # 机密数据
    RESTRICTED = "restricted"   # 受限数据
    CRITICAL = "critical"       # 关键数据


class DataType(Enum):
    """数据类型"""
    PERSONAL = auto()           # 个人数据
    SENSITIVE = auto()          # 敏感个人数据
    FINANCIAL = auto()          # 财务数据
    HEALTH = auto()             # 健康数据
    BIOMETRIC = auto()          # 生物识别数据
    GENETIC = auto()            # 基因数据
    CHILD = auto()              # 儿童数据
    CRIMINAL = auto()           # 犯罪记录
    OTHER = auto()              # 其他


@dataclass
class DataAsset:
    """数据资产定义"""
    id: UUID
    name: str
    description: str
    data_type: DataType
    classification: DataClassification
    location: str
    owner: str
    retention_days: int
    created_at: datetime
    updated_at: datetime
    pii_fields: List[str] = field(default_factory=list)
    volume_gb: float = 0.0
    access_count: int = 0
    third_party_shared: bool = False
    cross_border: bool = False
    encryption_enabled: bool = False
    pseudonymized: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": str(self.id),
            "name": self.name,
            "description": self.description,
            "data_type": self.data_type.name,
            "classification": self.classification.value,
            "location": self.location,
            "owner": self.owner,
            "retention_days": self.retention_days,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "pii_fields": self.pii_fields,
            "volume_gb": self.volume_gb,
            "access_count": self.access_count,
            "third_party_shared": self.third_party_shared,
            "cross_border": self.cross_border,
            "encryption_enabled": self.encryption_enabled,
            "pseudonymized": self.pseudonymized,
        }


@dataclass
class DataFlow:
    """数据流定义"""
    id: UUID
    source_id: UUID
    destination_id: UUID
    flow_type: str
    description: str
    legal_basis: str
    cross_border: bool
    third_countries: List[str]
    safeguards: List[str]
    created_at: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": str(self.id),
            "source_id": str(self.source_id),
            "destination_id": str(self.destination_id),
            "flow_type": self.flow_type,
            "description": self.description,
            "legal_basis": self.legal_basis,
            "cross_border": self.cross_border,
            "third_countries": self.third_countries,
            "safeguards": self.safeguards,
            "created_at": self.created_at.isoformat(),
        }


class DataMapper:
    """
    数据地图管理器
    
    负责数据资产的发现、分类分级和数据流映射
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化数据地图管理器
        
        Args:
            storage_path: 数据存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/data_mapper")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._assets: Dict[UUID, DataAsset] = {}
        self._flows: Dict[UUID, DataFlow] = {}
        self._lock = asyncio.Lock()
        
        logger.info(f"数据地图管理器初始化完成，存储路径: {self.storage_path}")
    
    async def discover_databases(
        self,
        connection_strings: List[str],
        scan_depth: str = "standard"
    ) -> List[DataAsset]:
        """
        发现数据库中的数据资产
        
        Args:
            connection_strings: 数据库连接字符串列表
            scan_depth: 扫描深度 (basic/standard/deep)
            
        Returns:
            发现的数据资产列表
        """
        assets = []
        
        for conn_str in connection_strings:
            try:
                asset = await self._scan_database(conn_str, scan_depth)
                if asset:
                    assets.append(asset)
                    async with self._lock:
                        self._assets[asset.id] = asset
                logger.info(f"数据库扫描完成: {conn_str}")
            except Exception as e:
                logger.error(f"数据库扫描失败 {conn_str}: {e}")
        
        return assets
    
    async def _scan_database(self, connection_string: str, scan_depth: str) -> Optional[DataAsset]:
        """扫描单个数据库"""
        # 模拟数据库扫描
        await asyncio.sleep(0.1)
        
        asset_id = uuid4()
        asset = DataAsset(
            id=asset_id,
            name=f"Database_{asset_id.hex[:8]}",
            description=f"自动发现的数据库: {connection_string}",
            data_type=DataType.PERSONAL,
            classification=DataClassification.CONFIDENTIAL,
            location=connection_string,
            owner="system",
            retention_days=365,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            pii_fields=["email", "phone", "name", "address"],
            volume_gb=10.5,
        )
        
        return asset
    
    async def discover_file_systems(
        self,
        paths: List[str],
        file_patterns: List[str] = None
    ) -> List[DataAsset]:
        """
        发现文件系统中的数据资产
        
        Args:
            paths: 扫描路径列表
            file_patterns: 文件匹配模式
            
        Returns:
            发现的数据资产列表
        """
        if file_patterns is None:
            file_patterns = ["*.csv", "*.json", "*.xlsx", "*.parquet"]
        
        assets = []
        
        for path in paths:
            try:
                path_obj = Path(path)
                if not path_obj.exists():
                    logger.warning(f"路径不存在: {path}")
                    continue
                
                for pattern in file_patterns:
                    for file_path in path_obj.rglob(pattern):
                        asset = await self._analyze_file(file_path)
                        if asset:
                            assets.append(asset)
                            async with self._lock:
                                self._assets[asset.id] = asset
                
                logger.info(f"文件系统扫描完成: {path}")
            except Exception as e:
                logger.error(f"文件系统扫描失败 {path}: {e}")
        
        return assets
    
    async def _analyze_file(self, file_path: Path) -> Optional[DataAsset]:
        """分析单个文件"""
        try:
            stat = file_path.stat()
            size_gb = stat.st_size / (1024 ** 3)
            
            # 根据文件扩展名判断数据类型
            suffix = file_path.suffix.lower()
            if suffix in ['.csv', '.json', '.xlsx']:
                data_type = DataType.PERSONAL
            else:
                data_type = DataType.OTHER
            
            asset = DataAsset(
                id=uuid4(),
                name=file_path.name,
                description=f"数据文件: {file_path}",
                data_type=data_type,
                classification=DataClassification.INTERNAL,
                location=str(file_path),
                owner="system",
                retention_days=180,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                volume_gb=size_gb,
            )
            
            return asset
        except Exception as e:
            logger.error(f"文件分析失败 {file_path}: {e}")
            return None
    
    async def classify_asset(
        self,
        asset_id: UUID,
        classification: DataClassification,
        reason: str
    ) -> bool:
        """
        对数据资产进行分类
        
        Args:
            asset_id: 资产ID
            classification: 分类级别
            reason: 分类理由
            
        Returns:
            是否成功
        """
        async with self._lock:
            if asset_id not in self._assets:
                logger.error(f"资产不存在: {asset_id}")
                return False
            
            asset = self._assets[asset_id]
            old_classification = asset.classification
            asset.classification = classification
            asset.updated_at = datetime.utcnow()
            
            logger.info(
                f"资产分类更新: {asset.name} "
                f"{old_classification.value} -> {classification.value}, 理由: {reason}"
            )
            return True
    
    async def map_data_flow(
        self,
        source_id: UUID,
        destination_id: UUID,
        flow_type: str,
        legal_basis: str,
        description: str = "",
        third_countries: List[str] = None,
        safeguards: List[str] = None
    ) -> DataFlow:
        """
        映射数据流
        
        Args:
            source_id: 源资产ID
            destination_id: 目标资产ID
            flow_type: 流类型
            legal_basis: 法律依据
            description: 描述
            third_countries: 第三国列表
            safeguards: 保障措施
            
        Returns:
            数据流对象
        """
        if third_countries is None:
            third_countries = []
        if safeguards is None:
            safeguards = []
        
        async with self._lock:
            if source_id not in self._assets:
                raise ValueError(f"源资产不存在: {source_id}")
            if destination_id not in self._assets:
                raise ValueError(f"目标资产不存在: {destination_id}")
            
            flow = DataFlow(
                id=uuid4(),
                source_id=source_id,
                destination_id=destination_id,
                flow_type=flow_type,
                description=description,
                legal_basis=legal_basis,
                cross_border=len(third_countries) > 0,
                third_countries=third_countries,
                safeguards=safeguards,
                created_at=datetime.utcnow(),
            )
            
            self._flows[flow.id] = flow
            logger.info(f"数据流映射创建: {flow.id}")
            return flow
    
    async def get_assets_by_classification(
        self,
        classification: DataClassification
    ) -> List[DataAsset]:
        """
        按分类获取数据资产
        
        Args:
            classification: 分类级别
            
        Returns:
            数据资产列表
        """
        async with self._lock:
            return [
                asset for asset in self._assets.values()
                if asset.classification == classification
            ]
    
    async def get_cross_border_flows(self) -> List[DataFlow]:
        """
        获取跨境数据流
        
        Returns:
            跨境数据流列表
        """
        async with self._lock:
            return [
                flow for flow in self._flows.values()
                if flow.cross_border
            ]
    
    async def generate_data_map_report(self) -> Dict[str, Any]:
        """
        生成数据地图报告
        
        Returns:
            报告数据
        """
        async with self._lock:
            total_volume = sum(a.volume_gb for a in self._assets.values())
            
            classification_counts = {}
            for c in DataClassification:
                count = sum(1 for a in self._assets.values() if a.classification == c)
                classification_counts[c.value] = count
            
            type_counts = {}
            for t in DataType:
                count = sum(1 for a in self._assets.values() if a.data_type == t)
                type_counts[t.name] = count
            
            report = {
                "generated_at": datetime.utcnow().isoformat(),
                "summary": {
                    "total_assets": len(self._assets),
                    "total_flows": len(self._flows),
                    "total_volume_gb": round(total_volume, 2),
                    "cross_border_flows": len(await self.get_cross_border_flows()),
                },
                "classification_distribution": classification_counts,
                "type_distribution": type_counts,
                "assets": [a.to_dict() for a in self._assets.values()],
                "flows": [f.to_dict() for f in self._flows.values()],
            }
            
            return report
    
    async def export_data_map(self, output_path: str) -> str:
        """
        导出数据地图到文件
        
        Args:
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        report = await self.generate_data_map_report()
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(report, indent=2, ensure_ascii=False))
        
        logger.info(f"数据地图已导出: {output_file}")
        return str(output_file)
    
    async def import_data_map(self, input_path: str) -> bool:
        """
        从文件导入数据地图
        
        Args:
            input_path: 输入文件路径
            
        Returns:
            是否成功
        """
        try:
            async with aiofiles.open(input_path, 'r', encoding='utf-8') as f:
                content = await f.read()
                data = json.loads(content)
            
            async with self._lock:
                # 导入资产
                for asset_data in data.get("assets", []):
                    asset = DataAsset(
                        id=UUID(asset_data["id"]),
                        name=asset_data["name"],
                        description=asset_data["description"],
                        data_type=DataType[asset_data["data_type"]],
                        classification=DataClassification(asset_data["classification"]),
                        location=asset_data["location"],
                        owner=asset_data["owner"],
                        retention_days=asset_data["retention_days"],
                        created_at=datetime.fromisoformat(asset_data["created_at"]),
                        updated_at=datetime.fromisoformat(asset_data["updated_at"]),
                        pii_fields=asset_data.get("pii_fields", []),
                        volume_gb=asset_data.get("volume_gb", 0.0),
                        access_count=asset_data.get("access_count", 0),
                        third_party_shared=asset_data.get("third_party_shared", False),
                        cross_border=asset_data.get("cross_border", False),
                        encryption_enabled=asset_data.get("encryption_enabled", False),
                        pseudonymized=asset_data.get("pseudonymized", False),
                    )
                    self._assets[asset.id] = asset
                
                # 导入数据流
                for flow_data in data.get("flows", []):
                    flow = DataFlow(
                        id=UUID(flow_data["id"]),
                        source_id=UUID(flow_data["source_id"]),
                        destination_id=UUID(flow_data["destination_id"]),
                        flow_type=flow_data["flow_type"],
                        description=flow_data["description"],
                        legal_basis=flow_data["legal_basis"],
                        cross_border=flow_data["cross_border"],
                        third_countries=flow_data.get("third_countries", []),
                        safeguards=flow_data.get("safeguards", []),
                        created_at=datetime.fromisoformat(flow_data["created_at"]),
                    )
                    self._flows[flow.id] = flow
            
            logger.info(f"数据地图已导入: {input_path}")
            return True
        except Exception as e:
            logger.error(f"数据地图导入失败: {e}")
            return False
