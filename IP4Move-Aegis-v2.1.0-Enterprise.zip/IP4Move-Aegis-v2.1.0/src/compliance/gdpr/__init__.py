"""
GDPR合规工具链模块

提供完整的GDPR合规功能，包括：
- 数据发现与分类
- 权利管理（访问、删除、携带、更正）
- 同意管理
- DPA和ROPA生成

Author: IP4Move Security Team
Version: 1.0.0
"""

from .data_discovery.data_mapper import DataMapper, DataAsset, DataFlow
from .data_discovery.pii_scanner import PIIScanner, PIIFinding
from .data_discovery.data_flow_analyzer import DataFlowAnalyzer
from .rights_management.access_request import AccessRequestHandler
from .rights_management.erasure_request import ErasureRequestHandler
from .rights_management.portability_request import PortabilityRequestHandler
from .rights_management.rectification_request import RectificationRequestHandler
from .consent.consent_manager import ConsentManager, ConsentRecord
from .consent.consent_proof import ConsentProof, ProofChain
from .dpa.dpa_generator import DPAGenerator
from .dpa.ropa_generator import ROPAGenerator

__version__ = "1.0.0"
__all__ = [
    # 数据发现
    "DataMapper",
    "DataAsset",
    "DataFlow",
    "PIIScanner",
    "PIIFinding",
    "DataFlowAnalyzer",
    # 权利管理
    "AccessRequestHandler",
    "ErasureRequestHandler",
    "PortabilityRequestHandler",
    "RectificationRequestHandler",
    # 同意管理
    "ConsentManager",
    "ConsentRecord",
    "ConsentProof",
    "ProofChain",
    # DPA/ROPA
    "DPAGenerator",
    "ROPAGenerator",
]
