"""
ROPA生成模块

提供处理活动记录(ROPA)的生成、自动更新和合规报告功能
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class ProcessingActivityStatus(Enum):
    """处理活动状态"""
    ACTIVE = "active"
    PLANNED = "planned"
    SUSPENDED = "suspended"
    TERMINATED = "terminated"


@dataclass
class ProcessingActivity:
    """处理活动"""
    id: UUID
    name: str
    description: str
    purposes: List[str]
    data_categories: List[str]
    data_subject_categories: List[str]
    recipients: List[str]
    retention_period: str
    security_measures: List[str]
    legal_basis: List[str]
    cross_border: bool
    third_countries: List[str]
    safeguards: List[str]
    dpa_reference: Optional[str]
    status: ProcessingActivityStatus
    created_at: datetime
    updated_at: datetime
    last_reviewed: Optional[datetime]
    next_review: Optional[datetime]


@dataclass
class ROPARecord:
    """ROPA记录"""
    id: UUID
    organization_name: str
    version: str
    effective_date: datetime
    activities: List[ProcessingActivity]
    generated_at: datetime
    generated_by: str


class ROPAGenerator:
    """
    ROPA生成器
    
    提供处理活动记录的生成和管理功能，包括：
    - 处理活动记录
    - 自动更新
    - 合规报告
    - 审计跟踪
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化ROPA生成器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/ropa_generator")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._activities: Dict[UUID, ProcessingActivity] = {}
        self._ropa_history: List[ROPARecord] = []
        self._lock = asyncio.Lock()
        
        logger.info("ROPA生成器初始化完成")
    
    async def add_processing_activity(
        self,
        name: str,
        description: str,
        purposes: List[str],
        data_categories: List[str],
        data_subject_categories: List[str],
        recipients: List[str],
        retention_period: str,
        security_measures: List[str],
        legal_basis: List[str],
        cross_border: bool = False,
        third_countries: List[str] = None,
        safeguards: List[str] = None,
        dpa_reference: Optional[str] = None
    ) -> ProcessingActivity:
        """
        添加处理活动
        
        Args:
            name: 活动名称
            description: 描述
            purposes: 处理目的
            data_categories: 数据类别
            data_subject_categories: 数据主体类别
            recipients: 接收方
            retention_period: 保留期限
            security_measures: 安全措施
            legal_basis: 法律依据
            cross_border: 是否跨境
            third_countries: 第三国
            safeguards: 保障措施
            dpa_reference: DPA引用
            
        Returns:
            处理活动
        """
        if third_countries is None:
            third_countries = []
        if safeguards is None:
            safeguards = []
        
        now = datetime.utcnow()
        next_review = now + timedelta(days=365)
        
        activity = ProcessingActivity(
            id=uuid4(),
            name=name,
            description=description,
            purposes=purposes,
            data_categories=data_categories,
            data_subject_categories=data_subject_categories,
            recipients=recipients,
            retention_period=retention_period,
            security_measures=security_measures,
            legal_basis=legal_basis,
            cross_border=cross_border,
            third_countries=third_countries,
            safeguards=safeguards,
            dpa_reference=dpa_reference,
            status=ProcessingActivityStatus.ACTIVE,
            created_at=now,
            updated_at=now,
            last_reviewed=None,
            next_review=next_review,
        )
        
        async with self._lock:
            self._activities[activity.id] = activity
        
        logger.info(f"处理活动已添加: {activity.id} ({name})")
        return activity
    
    async def update_activity(
        self,
        activity_id: UUID,
        updates: Dict[str, Any]
    ) -> bool:
        """
        更新处理活动
        
        Args:
            activity_id: 活动ID
            updates: 更新内容
            
        Returns:
            是否成功
        """
        async with self._lock:
            if activity_id not in self._activities:
                return False
            
            activity = self._activities[activity_id]
            
            # 更新字段
            for key, value in updates.items():
                if hasattr(activity, key):
                    setattr(activity, key, value)
            
            activity.updated_at = datetime.utcnow()
            activity.next_review = datetime.utcnow() + timedelta(days=365)
        
        logger.info(f"处理活动已更新: {activity_id}")
        return True
    
    async def review_activity(
        self,
        activity_id: UUID,
        reviewer: str,
        notes: str = ""
    ) -> bool:
        """
        审核处理活动
        
        Args:
            activity_id: 活动ID
            reviewer: 审核人
            notes: 备注
            
        Returns:
            是否成功
        """
        async with self._lock:
            if activity_id not in self._activities:
                return False
            
            activity = self._activities[activity_id]
            activity.last_reviewed = datetime.utcnow()
            activity.next_review = datetime.utcnow() + timedelta(days=365)
            activity.updated_at = datetime.utcnow()
        
        logger.info(f"处理活动已审核: {activity_id} ({reviewer})")
        return True
    
    async def generate_ropa(
        self,
        organization_name: str,
        version: str = "1.0"
    ) -> ROPARecord:
        """
        生成ROPA
        
        Args:
            organization_name: 组织名称
            version: 版本
            
        Returns:
            ROPA记录
        """
        async with self._lock:
            activities = list(self._activities.values())
        
        ropa = ROPARecord(
            id=uuid4(),
            organization_name=organization_name,
            version=version,
            effective_date=datetime.utcnow(),
            activities=activities.copy(),
            generated_at=datetime.utcnow(),
            generated_by="system",
        )
        
        async with self._lock:
            self._ropa_history.append(ropa)
        
        logger.info(f"ROPA已生成: {ropa.id} (活动数: {len(activities)})")
        return ropa
    
    async def export_ropa(
        self,
        ropa_id: Optional[UUID] = None,
        output_format: str = "json",
        output_path: Optional[str] = None
    ) -> str:
        """
        导出ROPA
        
        Args:
            ropa_id: ROPA ID（如不提供则使用最新的）
            output_format: 输出格式
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        async with self._lock:
            if ropa_id:
                ropa = next((r for r in self._ropa_history if r.id == ropa_id), None)
                if not ropa:
                    raise ValueError(f"ROPA不存在: {ropa_id}")
            else:
                if not self._ropa_history:
                    raise ValueError("没有可用的ROPA")
                ropa = self._ropa_history[-1]
        
        if output_path is None:
            filename = f"ropa_{ropa.id}_{datetime.utcnow().strftime('%Y%m%d')}.{output_format}"
            output_path = self.storage_path / filename
        else:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if output_format == "json":
            await self._export_json(ropa, output_path)
        elif output_format == "csv":
            await self._export_csv(ropa, output_path)
        elif output_format == "markdown":
            await self._export_markdown(ropa, output_path)
        else:
            raise ValueError(f"不支持的格式: {output_format}")
        
        logger.info(f"ROPA已导出: {output_path}")
        return str(output_path)
    
    async def _export_json(self, ropa: ROPARecord, output_path: Path) -> None:
        """导出为JSON"""
        data = {
            "ropa_id": str(ropa.id),
            "organization": ropa.organization_name,
            "version": ropa.version,
            "effective_date": ropa.effective_date.isoformat(),
            "generated_at": ropa.generated_at.isoformat(),
            "activities": [
                {
                    "id": str(a.id),
                    "name": a.name,
                    "description": a.description,
                    "purposes": a.purposes,
                    "data_categories": a.data_categories,
                    "data_subject_categories": a.data_subject_categories,
                    "recipients": a.recipients,
                    "retention_period": a.retention_period,
                    "security_measures": a.security_measures,
                    "legal_basis": a.legal_basis,
                    "cross_border": a.cross_border,
                    "third_countries": a.third_countries,
                    "safeguards": a.safeguards,
                    "dpa_reference": a.dpa_reference,
                    "status": a.status.value,
                }
                for a in ropa.activities
            ],
        }
        
        async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(data, indent=2, ensure_ascii=False))
    
    async def _export_csv(self, ropa: ROPARecord, output_path: Path) -> None:
        """导出为CSV"""
        lines = ["id,name,description,purposes,data_categories,legal_basis,cross_border,status"]
        
        for a in ropa.activities:
            line = f'"{a.id}","{a.name}","{a.description[:50]}...","{";".join(a.purposes)}","{";".join(a.data_categories)}","{";".join(a.legal_basis)}",{a.cross_border},{a.status.value}'
            lines.append(line)
        
        async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
            await f.write('\n'.join(lines))
    
    async def _export_markdown(self, ropa: ROPARecord, output_path: Path) -> None:
        """导出为Markdown"""
        lines = []
        
        lines.append(f"# 处理活动记录 (ROPA)")
        lines.append("")
        lines.append(f"**组织**: {ropa.organization_name}")
        lines.append(f"**版本**: {ropa.version}")
        lines.append(f"**生效日期**: {ropa.effective_date.strftime('%Y-%m-%d')}")
        lines.append(f"**生成日期**: {ropa.generated_at.strftime('%Y-%m-%d')}")
        lines.append("")
        
        lines.append("## 处理活动清单")
        lines.append("")
        
        for i, activity in enumerate(ropa.activities, 1):
            lines.append(f"### {i}. {activity.name}")
            lines.append("")
            lines.append(f"**描述**: {activity.description}")
            lines.append("")
            lines.append(f"**处理目的**: {', '.join(activity.purposes)}")
            lines.append("")
            lines.append(f"**数据类别**: {', '.join(activity.data_categories)}")
            lines.append("")
            lines.append(f"**数据主体类别**: {', '.join(activity.data_subject_categories)}")
            lines.append("")
            lines.append(f"**接收方**: {', '.join(activity.recipients)}")
            lines.append("")
            lines.append(f"**保留期限**: {activity.retention_period}")
            lines.append("")
            lines.append(f"**法律依据**: {', '.join(activity.legal_basis)}")
            lines.append("")
            
            if activity.cross_border:
                lines.append(f"**跨境传输**: 是")
                lines.append(f"**第三国**: {', '.join(activity.third_countries)}")
                lines.append(f"**保障措施**: {', '.join(activity.safeguards)}")
                lines.append("")
            
            lines.append(f"**状态**: {activity.status.value}")
            lines.append("")
            lines.append("---")
            lines.append("")
        
        async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
            await f.write('\n'.join(lines))
    
    async def generate_compliance_report(self) -> Dict[str, Any]:
        """
        生成合规报告
        
        Returns:
            合规报告
        """
        async with self._lock:
            activities = list(self._activities.values())
        
        # 统计
        total = len(activities)
        active = sum(1 for a in activities if a.status == ProcessingActivityStatus.ACTIVE)
        cross_border = sum(1 for a in activities if a.cross_border)
        
        # 数据类别统计
        data_categories = {}
        for a in activities:
            for cat in a.data_categories:
                data_categories[cat] = data_categories.get(cat, 0) + 1
        
        # 法律依据统计
        legal_basis = {}
        for a in activities:
            for basis in a.legal_basis:
                legal_basis[basis] = legal_basis.get(basis, 0) + 1
        
        # 需要审核的活动
        now = datetime.utcnow()
        needs_review = [a for a in activities if a.next_review and a.next_review < now]
        
        return {
            "generated_at": datetime.utcnow().isoformat(),
            "summary": {
                "total_activities": total,
                "active_activities": active,
                "cross_border_activities": cross_border,
                "activities_needing_review": len(needs_review),
            },
            "data_categories": data_categories,
            "legal_basis_distribution": legal_basis,
            "activities_needing_review": [
                {
                    "id": str(a.id),
                    "name": a.name,
                    "next_review": a.next_review.isoformat(),
                }
                for a in needs_review
            ],
        }
    
    async def get_activity_summary(self, activity_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取活动摘要
        
        Args:
            activity_id: 活动ID
            
        Returns:
            活动摘要
        """
        async with self._lock:
            if activity_id not in self._activities:
                return None
            
            a = self._activities[activity_id]
            
            return {
                "id": str(a.id),
                "name": a.name,
                "description": a.description,
                "purposes": a.purposes,
                "data_categories": a.data_categories,
                "legal_basis": a.legal_basis,
                "cross_border": a.cross_border,
                "status": a.status.value,
                "created_at": a.created_at.isoformat(),
                "updated_at": a.updated_at.isoformat(),
                "next_review": a.next_review.isoformat() if a.next_review else None,
            }
    
    async def list_activities(
        self,
        status: Optional[ProcessingActivityStatus] = None
    ) -> List[Dict[str, Any]]:
        """
        列出处理活动
        
        Args:
            status: 状态过滤
            
        Returns:
            活动列表
        """
        async with self._lock:
            activities = self._activities.values()
            
            if status:
                activities = [a for a in activities if a.status == status]
            
            return [
                {
                    "id": str(a.id),
                    "name": a.name,
                    "purposes": a.purposes,
                    "data_categories": a.data_categories,
                    "status": a.status.value,
                    "cross_border": a.cross_border,
                }
                for a in activities
            ]
    
    async def auto_update_from_data_mapper(self, data_mapper_results: Dict[str, Any]) -> int:
        """
        从数据地图自动更新ROPA
        
        Args:
            data_mapper_results: 数据地图结果
            
        Returns:
            更新的活动数
        """
        updated_count = 0
        
        # 从数据地图提取处理活动
        for asset_data in data_mapper_results.get("assets", []):
            try:
                # 检查是否已存在
                existing = None
                async with self._lock:
                    for activity in self._activities.values():
                        if activity.name == asset_data.get("name"):
                            existing = activity
                            break
                
                if existing:
                    # 更新现有活动
                    await self.update_activity(existing.id, {
                        "data_categories": asset_data.get("pii_fields", []),
                        "updated_at": datetime.utcnow(),
                    })
                else:
                    # 创建新活动
                    await self.add_processing_activity(
                        name=asset_data.get("name", "Unknown"),
                        description=f"自动发现的数据处理活动: {asset_data.get('name')}",
                        purposes=["数据处理"],
                        data_categories=asset_data.get("pii_fields", []),
                        data_subject_categories=["客户", "用户"],
                        recipients=["内部系统"],
                        retention_period=f"{asset_data.get('retention_days', 365)}天",
                        security_measures=["加密", "访问控制"],
                        legal_basis=["合法利益", "合同履行"],
                        cross_border=asset_data.get("cross_border", False),
                    )
                
                updated_count += 1
            except Exception as e:
                logger.error(f"自动更新失败: {e}")
        
        logger.info(f"ROPA自动更新完成: {updated_count} 个活动")
        return updated_count
