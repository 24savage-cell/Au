"""
DPA生成模块

提供数据处理协议(DPA)的生成、条款管理和签署工作流功能
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class DPAStatus(Enum):
    """DPA状态"""
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    PENDING_SIGNATURE = "pending_signature"
    ACTIVE = "active"
    EXPIRED = "expired"
    TERMINATED = "terminated"


class ClauseType(Enum):
    """条款类型"""
    PROCESSING_PURPOSE = "processing_purpose"
    DATA_CATEGORIES = "data_categories"
    DATA_SUBJECT_CATEGORIES = "data_subject_categories"
    PROCESSING_DURATION = "processing_duration"
    SECURITY_MEASURES = "security_measures"
    SUBPROCESSORS = "subprocessors"
    CROSS_BORDER_TRANSFER = "cross_border_transfer"
    AUDIT_RIGHTS = "audit_rights"
    BREACH_NOTIFICATION = "breach_notification"
    DATA_DELETION = "data_deletion"
    LIABILITY = "liability"
    INSURANCE = "insurance"
    TERMINATION = "termination"


@dataclass
class DPAClause:
    """DPA条款"""
    id: UUID
    clause_type: ClauseType
    title: str
    content: str
    is_mandatory: bool
    is_negotiable: bool
    version: str
    created_at: datetime
    updated_at: datetime


@dataclass
class DPAParty:
    """DPA参与方"""
    id: UUID
    name: str
    legal_name: str
    address: str
    contact_email: str
    contact_phone: str
    role: str          # controller/processor/subprocessor
    signature_date: Optional[datetime]
    signature_hash: Optional[str]


@dataclass
class DataProcessingAgreement:
    """数据处理协议"""
    id: UUID
    title: str
    controller: DPAParty
    processor: DPAParty
    status: DPAStatus
    clauses: List[DPAClause]
    effective_date: Optional[datetime]
    expiration_date: Optional[datetime]
    termination_notice_days: int
    governing_law: str
    jurisdiction: str
    created_at: datetime
    updated_at: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


class DPAGenerator:
    """
    DPA生成器
    
    提供数据处理协议的生成和管理功能，包括：
    - 协议模板管理
    - 条款管理
    - 签署工作流
    - 合规检查
    """
    
    # 标准DPA条款模板
    STANDARD_CLAUSES = {
        ClauseType.PROCESSING_PURPOSE: {
            "title": "处理目的",
            "content": """
处理者应根据控制者的指示，仅为以下目的处理个人数据：
1. 提供约定的服务
2. 履行合同义务
3. 遵守法律要求

处理者不得将个人数据用于任何其他目的，除非获得控制者的书面授权。
            """,
            "is_mandatory": True,
            "is_negotiable": False,
        },
        ClauseType.SECURITY_MEASURES: {
            "title": "技术和组织措施",
            "content": """
处理者应实施以下技术和组织措施：
1. 数据加密（传输中和静态）
2. 访问控制和身份验证
3. 定期安全评估
4. 员工培训和意识
5. 事件响应计划

处理者应每年至少进行一次安全审计，并向控制者提供审计报告。
            """,
            "is_mandatory": True,
            "is_negotiable": True,
        },
        ClauseType.BREACH_NOTIFICATION: {
            "title": "数据泄露通知",
            "content": """
处理者在发现个人数据泄露后，应在72小时内通知控制者。
通知应包括：
1. 泄露的性质和范围
2. 可能受影响的数据主体类别
3. 已采取或计划采取的缓解措施
4. 联系人的详细信息
            """,
            "is_mandatory": True,
            "is_negotiable": False,
        },
        ClauseType.DATA_DELETION: {
            "title": "数据删除和返还",
            "content": """
协议终止后，处理者应：
1. 删除或返还所有个人数据
2. 删除现有副本
3. 提供删除证明

此要求不适用于法律要求保留的数据。
            """,
            "is_mandatory": True,
            "is_negotiable": False,
        },
    }
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化DPA生成器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/dpa_generator")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._dpas: Dict[UUID, DataProcessingAgreement] = {}
        self._templates: Dict[str, Dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        
        # 加载标准条款
        self._load_standard_clauses()
        
        logger.info("DPA生成器初始化完成")
    
    def _load_standard_clauses(self) -> None:
        """加载标准条款"""
        for clause_type, template in self.STANDARD_CLAUSES.items():
            self._templates[clause_type.value] = template
    
    async def create_dpa(
        self,
        title: str,
        controller: Dict[str, Any],
        processor: Dict[str, Any],
        governing_law: str = "GDPR",
        jurisdiction: str = "EU",
        termination_notice_days: int = 30
    ) -> DataProcessingAgreement:
        """
        创建DPA
        
        Args:
            title: 协议标题
            controller: 控制者信息
            processor: 处理者信息
            governing_law: 适用法律
            jurisdiction: 司法管辖区
            termination_notice_days: 终止通知天数
            
        Returns:
            创建的DPA
        """
        controller_party = DPAParty(
            id=uuid4(),
            name=controller["name"],
            legal_name=controller["legal_name"],
            address=controller["address"],
            contact_email=controller["email"],
            contact_phone=controller.get("phone", ""),
            role="controller",
            signature_date=None,
            signature_hash=None,
        )
        
        processor_party = DPAParty(
            id=uuid4(),
            name=processor["name"],
            legal_name=processor["legal_name"],
            address=processor["address"],
            contact_email=processor["email"],
            contact_phone=processor.get("phone", ""),
            role="processor",
            signature_date=None,
            signature_hash=None,
        )
        
        # 添加标准条款
        clauses = []
        for clause_type, template in self.STANDARD_CLAUSES.items():
            clause = DPAClause(
                id=uuid4(),
                clause_type=clause_type,
                title=template["title"],
                content=template["content"],
                is_mandatory=template["is_mandatory"],
                is_negotiable=template["is_negotiable"],
                version="1.0",
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            clauses.append(clause)
        
        dpa = DataProcessingAgreement(
            id=uuid4(),
            title=title,
            controller=controller_party,
            processor=processor_party,
            status=DPAStatus.DRAFT,
            clauses=clauses,
            effective_date=None,
            expiration_date=None,
            termination_notice_days=termination_notice_days,
            governing_law=governing_law,
            jurisdiction=jurisdiction,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        
        async with self._lock:
            self._dpas[dpa.id] = dpa
        
        logger.info(f"DPA已创建: {dpa.id}")
        return dpa
    
    async def add_clause(
        self,
        dpa_id: UUID,
        clause_type: ClauseType,
        title: str,
        content: str,
        is_mandatory: bool = True,
        is_negotiable: bool = True
    ) -> DPAClause:
        """
        添加条款
        
        Args:
            dpa_id: DPA ID
            clause_type: 条款类型
            title: 标题
            content: 内容
            is_mandatory: 是否强制
            is_negotiable: 是否可协商
            
        Returns:
            创建的条款
        """
        async with self._lock:
            if dpa_id not in self._dpas:
                raise ValueError(f"DPA不存在: {dpa_id}")
            
            dpa = self._dpas[dpa_id]
            
            if dpa.status != DPAStatus.DRAFT:
                raise ValueError("只能在草稿状态添加条款")
        
        clause = DPAClause(
            id=uuid4(),
            clause_type=clause_type,
            title=title,
            content=content,
            is_mandatory=is_mandatory,
            is_negotiable=is_negotiable,
            version="1.0",
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        
        async with self._lock:
            dpa.clauses.append(clause)
            dpa.updated_at = datetime.utcnow()
        
        logger.info(f"条款已添加: {clause.id} 到 DPA {dpa_id}")
        return clause
    
    async def update_clause(
        self,
        dpa_id: UUID,
        clause_id: UUID,
        new_content: str
    ) -> bool:
        """
        更新条款
        
        Args:
            dpa_id: DPA ID
            clause_id: 条款ID
            new_content: 新内容
            
        Returns:
            是否成功
        """
        async with self._lock:
            if dpa_id not in self._dpas:
                return False
            
            dpa = self._dpas[dpa_id]
            
            for clause in dpa.clauses:
                if clause.id == clause_id:
                    if not clause.is_negotiable:
                        logger.warning(f"条款不可协商: {clause_id}")
                        return False
                    
                    clause.content = new_content
                    clause.updated_at = datetime.utcnow()
                    dpa.updated_at = datetime.utcnow()
                    
                    logger.info(f"条款已更新: {clause_id}")
                    return True
            
            return False
    
    async def submit_for_review(self, dpa_id: UUID) -> bool:
        """
        提交审核
        
        Args:
            dpa_id: DPA ID
            
        Returns:
            是否成功
        """
        async with self._lock:
            if dpa_id not in self._dpas:
                return False
            
            dpa = self._dpas[dpa_id]
            
            if dpa.status != DPAStatus.DRAFT:
                return False
            
            # 验证必要条款
            required_types = {ClauseType.PROCESSING_PURPOSE, ClauseType.SECURITY_MEASURES}
            existing_types = {c.clause_type for c in dpa.clauses}
            
            if not required_types.issubset(existing_types):
                missing = required_types - existing_types
                logger.error(f"缺少必要条款: {missing}")
                return False
            
            dpa.status = DPAStatus.PENDING_REVIEW
            dpa.updated_at = datetime.utcnow()
        
        logger.info(f"DPA已提交审核: {dpa_id}")
        return True
    
    async def approve_dpa(self, dpa_id: UUID, reviewer_id: UUID) -> bool:
        """
        批准DPA
        
        Args:
            dpa_id: DPA ID
            reviewer_id: 审核人ID
            
        Returns:
            是否成功
        """
        async with self._lock:
            if dpa_id not in self._dpas:
                return False
            
            dpa = self._dpas[dpa_id]
            
            if dpa.status != DPAStatus.PENDING_REVIEW:
                return False
            
            dpa.status = DPAStatus.PENDING_SIGNATURE
            dpa.updated_at = datetime.utcnow()
            dpa.metadata["review"] = {
                "reviewer_id": str(reviewer_id),
                "approved_at": datetime.utcnow().isoformat(),
            }
        
        logger.info(f"DPA已批准: {dpa_id}")
        return True
    
    async def sign_dpa(
        self,
        dpa_id: UUID,
        party_role: str,
        signature_data: str
    ) -> bool:
        """
        签署DPA
        
        Args:
            dpa_id: DPA ID
            party_role: 参与方角色 (controller/processor)
            signature_data: 签名数据
            
        Returns:
            是否成功
        """
        async with self._lock:
            if dpa_id not in self._dpas:
                return False
            
            dpa = self._dpas[dpa_id]
            
            if dpa.status != DPAStatus.PENDING_SIGNATURE:
                return False
            
            # 计算签名哈希
            signature_hash = hashlib.sha256(signature_data.encode()).hexdigest()
            
            if party_role == "controller":
                dpa.controller.signature_date = datetime.utcnow()
                dpa.controller.signature_hash = signature_hash
            elif party_role == "processor":
                dpa.processor.signature_date = datetime.utcnow()
                dpa.processor.signature_hash = signature_hash
            else:
                return False
            
            # 检查是否双方都签署了
            if dpa.controller.signature_date and dpa.processor.signature_date:
                dpa.status = DPAStatus.ACTIVE
                dpa.effective_date = datetime.utcnow()
            
            dpa.updated_at = datetime.utcnow()
        
        logger.info(f"DPA已签署: {dpa_id} ({party_role})")
        return True
    
    async def generate_dpa_document(self, dpa_id: UUID) -> str:
        """
        生成DPA文档
        
        Args:
            dpa_id: DPA ID
            
        Returns:
            文档路径
        """
        async with self._lock:
            if dpa_id not in self._dpas:
                raise ValueError(f"DPA不存在: {dpa_id}")
            
            dpa = self._dpas[dpa_id]
        
        # 生成文档内容
        document = self._format_dpa_document(dpa)
        
        # 保存文档
        filename = f"dpa_{dpa_id}_{datetime.utcnow().strftime('%Y%m%d')}.md"
        output_path = self.storage_path / filename
        
        async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
            await f.write(document)
        
        logger.info(f"DPA文档已生成: {output_path}")
        return str(output_path)
    
    def _format_dpa_document(self, dpa: DataProcessingAgreement) -> str:
        """格式化DPA文档"""
        lines = []
        
        # 标题
        lines.append(f"# {dpa.title}")
        lines.append("")
        
        # 参与方
        lines.append("## 参与方")
        lines.append("")
        lines.append(f"**控制者**: {dpa.controller.legal_name}")
        lines.append(f"- 地址: {dpa.controller.address}")
        lines.append(f"- 联系邮箱: {dpa.controller.contact_email}")
        lines.append("")
        lines.append(f"**处理者**: {dpa.processor.legal_name}")
        lines.append(f"- 地址: {dpa.processor.address}")
        lines.append(f"- 联系邮箱: {dpa.processor.contact_email}")
        lines.append("")
        
        # 条款
        lines.append("## 条款")
        lines.append("")
        
        for clause in dpa.clauses:
            lines.append(f"### {clause.title}")
            lines.append("")
            lines.append(clause.content)
            lines.append("")
        
        # 签名
        lines.append("## 签名")
        lines.append("")
        lines.append("| 参与方 | 签名日期 | 签名哈希 |")
        lines.append("|--------|----------|----------|")
        
        ctrl_date = dpa.controller.signature_date.isoformat() if dpa.controller.signature_date else "未签署"
        ctrl_hash = dpa.controller.signature_hash[:16] + "..." if dpa.controller.signature_hash else "N/A"
        lines.append(f"| 控制者 | {ctrl_date} | {ctrl_hash} |")
        
        proc_date = dpa.processor.signature_date.isoformat() if dpa.processor.signature_date else "未签署"
        proc_hash = dpa.processor.signature_hash[:16] + "..." if dpa.processor.signature_hash else "N/A"
        lines.append(f"| 处理者 | {proc_date} | {proc_hash} |")
        lines.append("")
        
        # 元数据
        lines.append("---")
        lines.append(f"- 协议ID: {dpa.id}")
        lines.append(f"- 状态: {dpa.status.value}")
        lines.append(f"- 适用法律: {dpa.governing_law}")
        lines.append(f"- 司法管辖区: {dpa.jurisdiction}")
        lines.append(f"- 生成日期: {datetime.utcnow().isoformat()}")
        
        return '\n'.join(lines)
    
    async def get_dpa_summary(self, dpa_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取DPA摘要
        
        Args:
            dpa_id: DPA ID
            
        Returns:
            DPA摘要
        """
        async with self._lock:
            if dpa_id not in self._dpas:
                return None
            
            dpa = self._dpas[dpa_id]
            
            return {
                "id": str(dpa.id),
                "title": dpa.title,
                "status": dpa.status.value,
                "controller": dpa.controller.name,
                "processor": dpa.processor.name,
                "effective_date": dpa.effective_date.isoformat() if dpa.effective_date else None,
                "expiration_date": dpa.expiration_date.isoformat() if dpa.expiration_date else None,
                "clause_count": len(dpa.clauses),
                "governing_law": dpa.governing_law,
            }
    
    async def list_active_dpas(self) -> List[Dict[str, Any]]:
        """
        列出活跃DPA
        
        Returns:
            活跃DPA列表
        """
        async with self._lock:
            active = []
            for dpa in self._dpas.values():
                if dpa.status == DPAStatus.ACTIVE:
                    active.append({
                        "id": str(dpa.id),
                        "title": dpa.title,
                        "controller": dpa.controller.name,
                        "processor": dpa.processor.name,
                        "effective_date": dpa.effective_date.isoformat() if dpa.effective_date else None,
                    })
            return active
