"""
同意证明模块

提供同意证据链、时间戳和不可篡改存储功能
"""

import asyncio
import base64
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


@dataclass
class TimestampRecord:
    """时间戳记录"""
    id: UUID
    record_id: UUID
    timestamp_authority: str
    timestamp_token: str
    timestamp_value: datetime
    algorithm: str
    certificate_chain: List[str]


@dataclass
class ProofNode:
    """证明链节点"""
    id: UUID
    record_id: UUID
    previous_hash: Optional[str]
    current_hash: str
    timestamp: datetime
    evidence_type: str
    evidence_data: Dict[str, Any]
    signature: Optional[str]


@dataclass
class ProofChain:
    """证明链"""
    id: UUID
    subject_id: UUID
    consent_record_id: UUID
    nodes: List[ProofNode]
    created_at: datetime
    merkle_root: Optional[str] = None


class ConsentProof:
    """
    同意证明管理器
    
    提供同意的不可篡改证明，包括：
    - 证据链构建
    - RFC3161时间戳
    - 区块链时间戳
    - 完整性验证
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化同意证明管理器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/consent_proof")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._chains: Dict[UUID, ProofChain] = {}
        self._timestamps: Dict[UUID, List[TimestampRecord]] = {}
        self._lock = asyncio.Lock()
        
        logger.info("同意证明管理器初始化完成")
    
    async def create_proof_chain(
        self,
        subject_id: UUID,
        consent_record_id: UUID
    ) -> ProofChain:
        """
        创建证明链
        
        Args:
            subject_id: 数据主体ID
            consent_record_id: 同意记录ID
            
        Returns:
            证明链
        """
        chain = ProofChain(
            id=uuid4(),
            subject_id=subject_id,
            consent_record_id=consent_record_id,
            nodes=[],
            created_at=datetime.utcnow(),
        )
        
        async with self._lock:
            self._chains[chain.id] = chain
            self._timestamps[chain.id] = []
        
        logger.info(f"证明链已创建: {chain.id}")
        return chain
    
    async def add_evidence(
        self,
        chain_id: UUID,
        evidence_type: str,
        evidence_data: Dict[str, Any],
        sign: bool = True
    ) -> ProofNode:
        """
        添加证据到链
        
        Args:
            chain_id: 链ID
            evidence_type: 证据类型
            evidence_data: 证据数据
            sign: 是否签名
            
        Returns:
            证据节点
        """
        async with self._lock:
            if chain_id not in self._chains:
                raise ValueError(f"证明链不存在: {chain_id}")
            
            chain = self._chains[chain_id]
            
            # 计算前一个哈希
            previous_hash = None
            if chain.nodes:
                previous_hash = chain.nodes[-1].current_hash
            
            # 构建节点数据
            node_data = {
                "chain_id": str(chain_id),
                "previous_hash": previous_hash,
                "evidence_type": evidence_type,
                "evidence_data": evidence_data,
                "timestamp": datetime.utcnow().isoformat(),
            }
            
            # 计算当前哈希
            current_hash = self._calculate_hash(node_data)
            
            # 签名
            signature = None
            if sign:
                signature = await self._sign_data(node_data)
            
            node = ProofNode(
                id=uuid4(),
                record_id=chain.consent_record_id,
                previous_hash=previous_hash,
                current_hash=current_hash,
                timestamp=datetime.utcnow(),
                evidence_type=evidence_type,
                evidence_data=evidence_data,
                signature=signature,
            )
            
            chain.nodes.append(node)
            
            # 更新Merkle根
            chain.merkle_root = self._calculate_merkle_root(chain.nodes)
        
        logger.info(f"证据已添加: {node.id} 到链 {chain_id}")
        return node
    
    def _calculate_hash(self, data: Dict[str, Any]) -> str:
        """计算数据哈希"""
        data_str = json.dumps(data, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(data_str.encode()).hexdigest()
    
    async def _sign_data(self, data: Dict[str, Any]) -> str:
        """签名数据"""
        # 简化实现，实际应使用私钥签名
        data_str = json.dumps(data, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(f"SIGN:{data_str}".encode()).hexdigest()
    
    def _calculate_merkle_root(self, nodes: List[ProofNode]) -> str:
        """计算Merkle根"""
        if not nodes:
            return ""
        
        hashes = [node.current_hash for node in nodes]
        
        while len(hashes) > 1:
            new_hashes = []
            for i in range(0, len(hashes), 2):
                if i + 1 < len(hashes):
                    combined = hashes[i] + hashes[i + 1]
                else:
                    combined = hashes[i] + hashes[i]
                new_hashes.append(hashlib.sha256(combined.encode()).hexdigest())
            hashes = new_hashes
        
        return hashes[0]
    
    async def request_rfc3161_timestamp(
        self,
        chain_id: UUID,
        timestamp_authority: str = "http://timestamp.digicert.com"
    ) -> Optional[TimestampRecord]:
        """
        请求RFC3161时间戳
        
        Args:
            chain_id: 链ID
            timestamp_authority: 时间戳权威URL
            
        Returns:
            时间戳记录
        """
        async with self._lock:
            if chain_id not in self._chains:
                return None
            
            chain = self._chains[chain_id]
        
        logger.info(f"请求RFC3161时间戳: {chain_id}")
        
        # 模拟RFC3161时间戳请求
        # 实际实现需要使用rfc3161库
        await asyncio.sleep(0.1)
        
        timestamp_token = base64.b64encode(
            f"TST:{chain_id}:{datetime.utcnow().timestamp()}".encode()
        ).decode()
        
        record = TimestampRecord(
            id=uuid4(),
            record_id=chain.consent_record_id,
            timestamp_authority=timestamp_authority,
            timestamp_token=timestamp_token,
            timestamp_value=datetime.utcnow(),
            algorithm="sha256",
            certificate_chain=["cert1", "cert2"],
        )
        
        async with self._lock:
            self._timestamps[chain_id].append(record)
        
        logger.info(f"RFC3161时间戳已获取: {record.id}")
        return record
    
    async def request_blockchain_timestamp(
        self,
        chain_id: UUID,
        blockchain: str = "bitcoin"
    ) -> Optional[TimestampRecord]:
        """
        请求区块链时间戳
        
        Args:
            chain_id: 链ID
            blockchain: 区块链类型
            
        Returns:
            时间戳记录
        """
        async with self._lock:
            if chain_id not in self._chains:
                return None
            
            chain = self._chains[chain_id]
        
        logger.info(f"请求区块链时间戳: {chain_id} ({blockchain})")
        
        # 模拟区块链时间戳
        await asyncio.sleep(0.1)
        
        # 计算Merkle根哈希
        merkle_hash = chain.merkle_root or self._calculate_merkle_root(chain.nodes)
        
        # 模拟区块链交易哈希
        tx_hash = hashlib.sha256(f"BLOCKCHAIN:{merkle_hash}".encode()).hexdigest()
        
        record = TimestampRecord(
            id=uuid4(),
            record_id=chain.consent_record_id,
            timestamp_authority=f"blockchain_{blockchain}",
            timestamp_token=tx_hash,
            timestamp_value=datetime.utcnow(),
            algorithm=f"blockchain_{blockchain}",
            certificate_chain=[],
        )
        
        async with self._lock:
            self._timestamps[chain_id].append(record)
        
        logger.info(f"区块链时间戳已获取: {record.id}")
        return record
    
    async def verify_chain_integrity(self, chain_id: UUID) -> Dict[str, Any]:
        """
        验证链完整性
        
        Args:
            chain_id: 链ID
            
        Returns:
            验证结果
        """
        async with self._lock:
            if chain_id not in self._chains:
                return {"valid": False, "error": "链不存在"}
            
            chain = self._chains[chain_id]
        
        results = {
            "chain_id": str(chain_id),
            "verified_at": datetime.utcnow().isoformat(),
            "valid": True,
            "node_count": len(chain.nodes),
            "checks": [],
        }
        
        # 验证每个节点
        for i, node in enumerate(chain.nodes):
            check = {
                "node_id": str(node.id),
                "index": i,
                "valid": True,
            }
            
            # 验证哈希链
            if i > 0:
                expected_previous = chain.nodes[i - 1].current_hash
                if node.previous_hash != expected_previous:
                    check["valid"] = False
                    check["error"] = "哈希链断裂"
                    results["valid"] = False
            
            # 验证签名
            if node.signature:
                # 实际实现中验证签名
                pass
            
            results["checks"].append(check)
        
        # 验证Merkle根
        calculated_root = self._calculate_merkle_root(chain.nodes)
        if chain.merkle_root and chain.merkle_root != calculated_root:
            results["valid"] = False
            results["merkle_error"] = "Merkle根不匹配"
        
        return results
    
    async def verify_timestamp(
        self,
        timestamp_id: UUID,
        chain_id: UUID
    ) -> Dict[str, Any]:
        """
        验证时间戳
        
        Args:
            timestamp_id: 时间戳ID
            chain_id: 链ID
            
        Returns:
            验证结果
        """
        async with self._lock:
            if chain_id not in self._timestamps:
                return {"valid": False, "error": "时间戳不存在"}
            
            timestamps = self._timestamps[chain_id]
            timestamp = next((t for t in timestamps if t.id == timestamp_id), None)
            
            if not timestamp:
                return {"valid": False, "error": "时间戳记录不存在"}
        
        # 验证时间戳令牌
        # 实际实现中需要解析和验证RFC3161令牌
        
        return {
            "valid": True,
            "timestamp_id": str(timestamp_id),
            "authority": timestamp.timestamp_authority,
            "timestamp": timestamp.timestamp_value.isoformat(),
            "algorithm": timestamp.algorithm,
        }
    
    async def export_proof_package(
        self,
        chain_id: UUID,
        output_path: str
    ) -> str:
        """
        导出证明包
        
        Args:
            chain_id: 链ID
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        async with self._lock:
            if chain_id not in self._chains:
                raise ValueError(f"证明链不存在: {chain_id}")
            
            chain = self._chains[chain_id]
            timestamps = self._timestamps.get(chain_id, [])
        
        package = {
            "chain_id": str(chain_id),
            "subject_id": str(chain.subject_id),
            "consent_record_id": str(chain.consent_record_id),
            "created_at": chain.created_at.isoformat(),
            "merkle_root": chain.merkle_root,
            "nodes": [
                {
                    "id": str(node.id),
                    "previous_hash": node.previous_hash,
                    "current_hash": node.current_hash,
                    "timestamp": node.timestamp.isoformat(),
                    "evidence_type": node.evidence_type,
                    "evidence_data": node.evidence_data,
                    "signature": node.signature,
                }
                for node in chain.nodes
            ],
            "timestamps": [
                {
                    "id": str(ts.id),
                    "authority": ts.timestamp_authority,
                    "token": ts.timestamp_token,
                    "timestamp": ts.timestamp_value.isoformat(),
                    "algorithm": ts.algorithm,
                }
                for ts in timestamps
            ],
        }
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(package, indent=2, ensure_ascii=False))
        
        logger.info(f"证明包已导出: {output_file}")
        return str(output_file)
    
    async def get_chain_summary(self, chain_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取链摘要
        
        Args:
            chain_id: 链ID
            
        Returns:
            链摘要
        """
        async with self._lock:
            if chain_id not in self._chains:
                return None
            
            chain = self._chains[chain_id]
            timestamps = self._timestamps.get(chain_id, [])
            
            return {
                "chain_id": str(chain_id),
                "subject_id": str(chain.subject_id),
                "consent_record_id": str(chain.consent_record_id),
                "created_at": chain.created_at.isoformat(),
                "node_count": len(chain.nodes),
                "merkle_root": chain.merkle_root,
                "timestamp_count": len(timestamps),
                "evidence_types": list(set(node.evidence_type for node in chain.nodes)),
            }
