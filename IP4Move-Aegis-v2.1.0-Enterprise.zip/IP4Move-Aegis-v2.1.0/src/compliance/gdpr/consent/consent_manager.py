"""
同意管理模块

提供GDPR同意的记录、版本管理和撤回处理功能
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class ConsentStatus(Enum):
    """同意状态"""
    ACTIVE = "active"           # 有效
    WITHDRAWN = "withdrawn"     # 已撤回
    EXPIRED = "expired"         # 已过期
    PENDING = "pending"         # 待确认


class ConsentType(Enum):
    """同意类型"""
    MARKETING = "marketing"             # 营销
    ANALYTICS = "analytics"             # 分析
    THIRD_PARTY = "third_party"         # 第三方共享
    PERSONALIZATION = "personalization"  # 个性化
    ESSENTIAL = "essential"             # 必要
    COOKIES = "cookies"                 # Cookie


@dataclass
class ConsentVersion:
    """同意版本"""
    version_id: str
    effective_date: datetime
    policy_text: str
    policy_hash: str
    changes_summary: str


@dataclass
class ConsentRecord:
    """同意记录"""
    id: UUID
    subject_id: UUID
    consent_type: ConsentType
    status: ConsentStatus
    granted_at: datetime
    expires_at: Optional[datetime]
    withdrawn_at: Optional[datetime]
    version_id: str
    mechanism: str              # 同意机制 (checkbox/click/verbal)
    ip_address: Optional[str]
    user_agent: Optional[str]
    language: str
    purposes: List[str]
    legal_basis: str
    metadata: Dict[str, Any] = field(default_factory=dict)


class ConsentManager:
    """
    同意管理器
    
    管理GDPR同意记录，包括：
    - 同意记录创建和存储
    - 版本管理
    - 撤回处理
    - 合规报告
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化同意管理器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/consent_manager")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._records: Dict[UUID, ConsentRecord] = {}
        self._versions: Dict[str, ConsentVersion] = {}
        self._subject_consents: Dict[UUID, Set[UUID]] = {}  # subject_id -> set of record_ids
        self._lock = asyncio.Lock()
        
        logger.info("同意管理器初始化完成")
    
    async def register_consent_version(
        self,
        version_id: str,
        policy_text: str,
        changes_summary: str,
        effective_date: Optional[datetime] = None
    ) -> ConsentVersion:
        """
        注册同意政策版本
        
        Args:
            version_id: 版本ID
            policy_text: 政策文本
            changes_summary: 变更摘要
            effective_date: 生效日期
            
        Returns:
            版本记录
        """
        if effective_date is None:
            effective_date = datetime.utcnow()
        
        # 计算政策哈希
        policy_hash = hashlib.sha256(policy_text.encode()).hexdigest()
        
        version = ConsentVersion(
            version_id=version_id,
            effective_date=effective_date,
            policy_text=policy_text,
            policy_hash=policy_hash,
            changes_summary=changes_summary,
        )
        
        async with self._lock:
            self._versions[version_id] = version
        
        logger.info(f"同意版本已注册: {version_id}")
        return version
    
    async def record_consent(
        self,
        subject_id: UUID,
        consent_type: ConsentType,
        version_id: str,
        mechanism: str,
        purposes: List[str],
        legal_basis: str = "consent",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        language: str = "zh-CN",
        expiry_days: Optional[int] = None,
        metadata: Dict[str, Any] = None
    ) -> ConsentRecord:
        """
        记录同意
        
        Args:
            subject_id: 数据主体ID
            consent_type: 同意类型
            version_id: 政策版本ID
            mechanism: 同意机制
            purposes: 目的列表
            legal_basis: 法律依据
            ip_address: IP地址
            user_agent: 用户代理
            language: 语言
            expiry_days: 过期天数
            metadata: 元数据
            
        Returns:
            同意记录
        """
        if metadata is None:
            metadata = {}
        
        # 验证版本
        async with self._lock:
            if version_id not in self._versions:
                raise ValueError(f"未知的同意版本: {version_id}")
        
        # 计算过期时间
        expires_at = None
        if expiry_days:
            expires_at = datetime.utcnow() + timedelta(days=expiry_days)
        
        record = ConsentRecord(
            id=uuid4(),
            subject_id=subject_id,
            consent_type=consent_type,
            status=ConsentStatus.ACTIVE,
            granted_at=datetime.utcnow(),
            expires_at=expires_at,
            withdrawn_at=None,
            version_id=version_id,
            mechanism=mechanism,
            ip_address=ip_address,
            user_agent=user_agent,
            language=language,
            purposes=purposes,
            legal_basis=legal_basis,
            metadata=metadata,
        )
        
        async with self._lock:
            self._records[record.id] = record
            
            if subject_id not in self._subject_consents:
                self._subject_consents[subject_id] = set()
            self._subject_consents[subject_id].add(record.id)
        
        logger.info(f"同意已记录: {record.id} (主体: {subject_id}, 类型: {consent_type.value})")
        return record
    
    async def withdraw_consent(
        self,
        record_id: UUID,
        withdrawal_mechanism: str = "user_request",
        reason: Optional[str] = None
    ) -> bool:
        """
        撤回同意
        
        Args:
            record_id: 记录ID
            withdrawal_mechanism: 撤回机制
            reason: 撤回原因
            
        Returns:
            是否成功
        """
        async with self._lock:
            if record_id not in self._records:
                return False
            
            record = self._records[record_id]
            
            if record.status != ConsentStatus.ACTIVE:
                logger.warning(f"同意不是活跃状态: {record_id}")
                return False
            
            record.status = ConsentStatus.WITHDRAWN
            record.withdrawn_at = datetime.utcnow()
            record.metadata["withdrawal"] = {
                "mechanism": withdrawal_mechanism,
                "reason": reason,
                "withdrawn_at": datetime.utcnow().isoformat(),
            }
        
        logger.info(f"同意已撤回: {record_id}")
        
        # 触发撤回后处理
        asyncio.create_task(self._handle_withdrawal(record_id))
        
        return True
    
    async def withdraw_all_consents(
        self,
        subject_id: UUID,
        withdrawal_mechanism: str = "user_request",
        reason: Optional[str] = None
    ) -> int:
        """
        撤回数据主体的所有同意
        
        Args:
            subject_id: 数据主体ID
            withdrawal_mechanism: 撤回机制
            reason: 撤回原因
            
        Returns:
            撤回的同意数量
        """
        async with self._lock:
            record_ids = self._subject_consents.get(subject_id, set()).copy()
        
        withdrawn_count = 0
        for record_id in record_ids:
            if await self.withdraw_consent(record_id, withdrawal_mechanism, reason):
                withdrawn_count += 1
        
        logger.info(f"已撤回 {withdrawn_count} 项同意 (主体: {subject_id})")
        return withdrawn_count
    
    async def _handle_withdrawal(self, record_id: UUID) -> None:
        """处理撤回后的操作"""
        async with self._lock:
            if record_id not in self._records:
                return
            
            record = self._records[record_id]
        
        # 根据同意类型执行不同的撤回后处理
        if record.consent_type == ConsentType.MARKETING:
            await self._stop_marketing(record.subject_id)
        elif record.consent_type == ConsentType.ANALYTICS:
            await self._disable_analytics(record.subject_id)
        elif record.consent_type == ConsentType.THIRD_PARTY:
            await self._notify_third_parties(record.subject_id)
        
        logger.info(f"撤回后处理完成: {record_id}")
    
    async def _stop_marketing(self, subject_id: UUID) -> None:
        """停止营销"""
        logger.info(f"营销已停止: {subject_id}")
    
    async def _disable_analytics(self, subject_id: UUID) -> None:
        """禁用分析"""
        logger.info(f"分析已禁用: {subject_id}")
    
    async def _notify_third_parties(self, subject_id: UUID) -> None:
        """通知第三方"""
        logger.info(f"第三方通知已发送: {subject_id}")
    
    async def check_consent(
        self,
        subject_id: UUID,
        consent_type: ConsentType
    ) -> Optional[ConsentRecord]:
        """
        检查同意状态
        
        Args:
            subject_id: 数据主体ID
            consent_type: 同意类型
            
        Returns:
            有效的同意记录，如果没有则返回None
        """
        async with self._lock:
            record_ids = self._subject_consents.get(subject_id, set())
            
            for record_id in record_ids:
                record = self._records.get(record_id)
                if record and record.consent_type == consent_type:
                    # 检查是否有效
                    if record.status == ConsentStatus.ACTIVE:
                        # 检查是否过期
                        if record.expires_at and record.expires_at < datetime.utcnow():
                            record.status = ConsentStatus.EXPIRED
                        else:
                            return record
        
        return None
    
    async def has_valid_consent(
        self,
        subject_id: UUID,
        consent_type: ConsentType
    ) -> bool:
        """
        检查是否有有效同意
        
        Args:
            subject_id: 数据主体ID
            consent_type: 同意类型
            
        Returns:
            是否有有效同意
        """
        record = await self.check_consent(subject_id, consent_type)
        return record is not None
    
    async def get_subject_consents(self, subject_id: UUID) -> List[Dict[str, Any]]:
        """
        获取数据主体的所有同意记录
        
        Args:
            subject_id: 数据主体ID
            
        Returns:
            同意记录列表
        """
        async with self._lock:
            record_ids = self._subject_consents.get(subject_id, set())
            records = []
            
            for record_id in record_ids:
                record = self._records.get(record_id)
                if record:
                    records.append({
                        "id": str(record.id),
                        "type": record.consent_type.value,
                        "status": record.status.value,
                        "granted_at": record.granted_at.isoformat(),
                        "expires_at": record.expires_at.isoformat() if record.expires_at else None,
                        "withdrawn_at": record.withdrawn_at.isoformat() if record.withdrawn_at else None,
                        "purposes": record.purposes,
                        "version_id": record.version_id,
                    })
            
            return records
    
    async def get_consent_statistics(self) -> Dict[str, Any]:
        """
        获取同意统计信息
        
        Returns:
            统计信息
        """
        async with self._lock:
            total_records = len(self._records)
            
            status_counts = {}
            for status in ConsentStatus:
                count = sum(1 for r in self._records.values() if r.status == status)
                status_counts[status.value] = count
            
            type_counts = {}
            for consent_type in ConsentType:
                count = sum(1 for r in self._records.values() if r.consent_type == consent_type)
                type_counts[consent_type.value] = count
            
            # 计算撤回率
            withdrawn_count = status_counts.get(ConsentStatus.WITHDRAWN.value, 0)
            withdrawal_rate = (withdrawn_count / total_records * 100) if total_records > 0 else 0
            
            return {
                "generated_at": datetime.utcnow().isoformat(),
                "total_records": total_records,
                "active_subjects": len(self._subject_consents),
                "status_distribution": status_counts,
                "type_distribution": type_counts,
                "withdrawal_rate": round(withdrawal_rate, 2),
            }
    
    async def generate_consent_report(
        self,
        subject_id: Optional[UUID] = None,
        consent_type: Optional[ConsentType] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """
        生成同意报告
        
        Args:
            subject_id: 数据主体ID（可选）
            consent_type: 同意类型（可选）
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            报告数据
        """
        async with self._lock:
            records = list(self._records.values())
        
        # 过滤记录
        filtered = records
        
        if subject_id:
            filtered = [r for r in filtered if r.subject_id == subject_id]
        
        if consent_type:
            filtered = [r for r in filtered if r.consent_type == consent_type]
        
        if start_date:
            filtered = [r for r in filtered if r.granted_at >= start_date]
        
        if end_date:
            filtered = [r for r in filtered if r.granted_at <= end_date]
        
        return {
            "generated_at": datetime.utcnow().isoformat(),
            "filters": {
                "subject_id": str(subject_id) if subject_id else None,
                "consent_type": consent_type.value if consent_type else None,
                "start_date": start_date.isoformat() if start_date else None,
                "end_date": end_date.isoformat() if end_date else None,
            },
            "summary": {
                "total_records": len(filtered),
                "active": sum(1 for r in filtered if r.status == ConsentStatus.ACTIVE),
                "withdrawn": sum(1 for r in filtered if r.status == ConsentStatus.WITHDRAWN),
                "expired": sum(1 for r in filtered if r.status == ConsentStatus.EXPIRED),
            },
            "records": [
                {
                    "id": str(r.id),
                    "subject_id": str(r.subject_id),
                    "type": r.consent_type.value,
                    "status": r.status.value,
                    "granted_at": r.granted_at.isoformat(),
                    "version_id": r.version_id,
                    "purposes": r.purposes,
                }
                for r in filtered
            ],
        }
    
    async def cleanup_expired_consents(self) -> int:
        """
        清理过期同意
        
        Returns:
            清理的记录数
        """
        async with self._lock:
            expired_count = 0
            now = datetime.utcnow()
            
            for record in self._records.values():
                if record.status == ConsentStatus.ACTIVE:
                    if record.expires_at and record.expires_at < now:
                        record.status = ConsentStatus.EXPIRED
                        expired_count += 1
            
            return expired_count
    
    async def export_consent_records(self, output_path: str) -> str:
        """
        导出同意记录
        
        Args:
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        report = await self.generate_consent_report()
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(report, indent=2, ensure_ascii=False))
        
        logger.info(f"同意记录已导出: {output_file}")
        return str(output_file)
