"""
同意管理模块

提供GDPR同意记录管理和证明功能
"""

from .consent_manager import ConsentManager, ConsentRecord
from .consent_proof import ConsentProof, ProofChain

__all__ = ["ConsentManager", "ConsentRecord", "ConsentProof", "ProofChain"]
