"""
删除权请求处理模块

处理GDPR第17条规定的删除权请求（Right to Erasure / Right to be Forgotten）
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class ErasureStatus(Enum):
    """删除状态"""
    PENDING = "pending"
    VALIDATING = "validating"
    LOCATING = "locating"
    DELETING = "deleting"
    PROPAGATING = "propagating"
    VERIFYING = "verifying"
    COMPLETED = "completed"
    REJECTED = "rejected"
    PARTIAL = "partial"


class RejectionReason(Enum):
    """拒绝原因"""
    LEGAL_OBLIGATION = "legal_obligation"       # 法律义务
    PUBLIC_INTEREST = "public_interest"         # 公共利益
    LEGAL_CLAIMS = "legal_claims"               # 法律主张
    EXERCISE_RIGHT = "exercise_right"           # 行使权利
    CONSENT_WITHDRAWN = "consent_withdrawn"     # 撤回同意
    NO_DATA_FOUND = "no_data_found"             # 未找到数据


@dataclass
class DataLocation:
    """数据位置"""
    id: UUID
    system_name: str
    location_type: str      # database/file_system/backup/archive
    location_path: str
    data_categories: List[str]
    estimated_records: int
    deletion_complexity: str  # simple/moderate/complex


@dataclass
class DeletionRecord:
    """删除记录"""
    id: UUID
    request_id: UUID
    location_id: UUID
    status: str
    started_at: datetime
    completed_at: Optional[datetime]
    records_deleted: int
    error_message: Optional[str]
    verification_hash: str


@dataclass
class ErasureRequest:
    """删除权请求"""
    id: UUID
    subject_id: UUID
    request_date: datetime
    status: ErasureStatus
    reason: str
    scope: List[str]
    exceptions_requested: List[str]
    verification_completed: bool
    response_deadline: datetime
    completed_at: Optional[datetime] = None
    rejection_reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class ErasureRequestHandler:
    """
    删除权请求处理器
    
    处理GDPR第17条删除权请求，包括：
    - 数据定位
    - 级联删除
    - 备份处理
    - 验证确认
    """
    
    DEFAULT_RESPONSE_DAYS = 30
    
    # 删除例外情况（GDPR第17条第3款）
    EXEMPTIONS = [
        "exercise_right_of_freedom_of_expression",
        "legal_obligation",
        "public_interest",
        "archiving_public_interest",
        "legal_claims",
    ]
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化删除权请求处理器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/erasure_requests")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._requests: Dict[UUID, ErasureRequest] = {}
        self._locations: Dict[UUID, List[DataLocation]] = {}
        self._deletion_records: Dict[UUID, List[DeletionRecord]] = {}
        self._lock = asyncio.Lock()
        
        logger.info("删除权请求处理器初始化完成")
    
    async def submit_request(
        self,
        subject_id: UUID,
        reason: str,
        scope: List[str],
        exceptions: List[str] = None
    ) -> ErasureRequest:
        """
        提交删除权请求
        
        Args:
            subject_id: 数据主体ID
            reason: 删除原因
            scope: 删除范围
            exceptions: 例外情况
            
        Returns:
            创建的请求
        """
        if exceptions is None:
            exceptions = []
        
        deadline = datetime.utcnow() + timedelta(days=self.DEFAULT_RESPONSE_DAYS)
        
        request = ErasureRequest(
            id=uuid4(),
            subject_id=subject_id,
            request_date=datetime.utcnow(),
            status=ErasureStatus.PENDING,
            reason=reason,
            scope=scope,
            exceptions_requested=exceptions,
            verification_completed=False,
            response_deadline=deadline,
        )
        
        async with self._lock:
            self._requests[request.id] = request
            self._locations[request.id] = []
            self._deletion_records[request.id] = []
        
        logger.info(f"删除权请求已提交: {request.id}")
        
        # 启动处理流程
        asyncio.create_task(self._process_request(request.id))
        
        return request
    
    async def _process_request(self, request_id: UUID) -> None:
        """处理删除请求"""
        try:
            # 1. 验证请求
            await self._validate_request(request_id)
            
            # 2. 定位数据
            await self._locate_data(request_id)
            
            # 3. 执行删除
            await self._execute_deletion(request_id)
            
            # 4. 传播删除
            await self._propagate_deletion(request_id)
            
            # 5. 验证删除
            await self._verify_deletion(request_id)
            
        except Exception as e:
            logger.error(f"删除请求处理失败 {request_id}: {e}")
            async with self._lock:
                if request_id in self._requests:
                    self._requests[request_id].status = ErasureStatus.REJECTED
    
    async def _validate_request(self, request_id: UUID) -> bool:
        """验证删除请求"""
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            request.status = ErasureStatus.VALIDATING
            
            # 检查是否存在例外情况阻止删除
            for exception in request.exceptions_requested:
                if exception in self.EXEMPTIONS:
                    logger.warning(f"删除请求存在例外情况: {exception}")
                    # 记录但不阻止，继续处理
        
        logger.info(f"删除请求验证完成: {request_id}")
        return True
    
    async def _locate_data(self, request_id: UUID) -> None:
        """定位数据主体数据"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            request.status = ErasureStatus.LOCATING
        
        logger.info(f"开始数据定位: {request_id}")
        
        # 模拟在不同系统中定位数据
        systems = [
            ("用户数据库", "database", "users", ["personal", "account"], 1000),
            ("日志系统", "file_system", "/var/logs", ["activity"], 5000),
            ("备份存储", "backup", "/backups", ["personal", "account"], 500),
            ("分析仓库", "database", "analytics", ["behavior"], 2000),
        ]
        
        for system_name, loc_type, path, categories, records in systems:
            location = DataLocation(
                id=uuid4(),
                system_name=system_name,
                location_type=loc_type,
                location_path=path,
                data_categories=categories,
                estimated_records=records,
                deletion_complexity="moderate" if loc_type == "backup" else "simple",
            )
            
            async with self._lock:
                self._locations[request_id].append(location)
        
        logger.info(f"数据定位完成: {request_id}, 找到 {len(systems)} 个位置")
    
    async def _execute_deletion(self, request_id: UUID) -> None:
        """执行删除操作"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            request.status = ErasureStatus.DELETING
            locations = self._locations.get(request_id, [])
        
        logger.info(f"开始删除操作: {request_id}")
        
        for location in locations:
            try:
                # 根据位置类型执行不同的删除策略
                if location.location_type == "database":
                    deleted = await self._delete_from_database(request_id, location)
                elif location.location_type == "file_system":
                    deleted = await self._delete_from_filesystem(request_id, location)
                elif location.location_type == "backup":
                    deleted = await self._delete_from_backup(request_id, location)
                else:
                    deleted = await self._delete_generic(request_id, location)
                
                # 记录删除
                record = DeletionRecord(
                    id=uuid4(),
                    request_id=request_id,
                    location_id=location.id,
                    status="completed" if deleted > 0 else "failed",
                    started_at=datetime.utcnow(),
                    completed_at=datetime.utcnow(),
                    records_deleted=deleted,
                    error_message=None,
                    verification_hash=hashlib.sha256(str(deleted).encode()).hexdigest(),
                )
                
                async with self._lock:
                    self._deletion_records[request_id].append(record)
                
            except Exception as e:
                logger.error(f"删除失败 {location.system_name}: {e}")
                
                record = DeletionRecord(
                    id=uuid4(),
                    request_id=request_id,
                    location_id=location.id,
                    status="failed",
                    started_at=datetime.utcnow(),
                    completed_at=datetime.utcnow(),
                    records_deleted=0,
                    error_message=str(e),
                    verification_hash="",
                )
                
                async with self._lock:
                    self._deletion_records[request_id].append(record)
        
        logger.info(f"删除操作完成: {request_id}")
    
    async def _delete_from_database(self, request_id: UUID, location: DataLocation) -> int:
        """从数据库删除"""
        # 模拟数据库删除
        await asyncio.sleep(0.1)
        return location.estimated_records
    
    async def _delete_from_filesystem(self, request_id: UUID, location: DataLocation) -> int:
        """从文件系统删除"""
        # 模拟文件系统删除
        await asyncio.sleep(0.1)
        return location.estimated_records
    
    async def _delete_from_backup(self, request_id: UUID, location: DataLocation) -> int:
        """从备份删除（标记为删除）"""
        # 备份通常不立即删除，而是标记
        await asyncio.sleep(0.1)
        return 0  # 备份中的数据将在保留期后删除
    
    async def _delete_generic(self, request_id: UUID, location: DataLocation) -> int:
        """通用删除"""
        await asyncio.sleep(0.1)
        return location.estimated_records
    
    async def _propagate_deletion(self, request_id: UUID) -> None:
        """传播删除到第三方"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            request.status = ErasureStatus.PROPAGATING
        
        logger.info(f"开始传播删除: {request_id}")
        
        # 通知第三方系统删除数据
        third_parties = ["支付处理商", "邮件服务商", "分析提供商"]
        
        for party in third_parties:
            try:
                await self._notify_third_party(request_id, party)
                logger.info(f"第三方通知已发送: {party}")
            except Exception as e:
                logger.error(f"第三方通知失败 {party}: {e}")
        
        logger.info(f"删除传播完成: {request_id}")
    
    async def _notify_third_party(self, request_id: UUID, party: str) -> None:
        """通知第三方"""
        # 实际实现中发送删除通知
        await asyncio.sleep(0.05)
    
    async def _verify_deletion(self, request_id: UUID) -> bool:
        """验证删除结果"""
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            request.status = ErasureStatus.VERIFYING
            
            records = self._deletion_records.get(request_id, [])
        
        logger.info(f"开始验证删除: {request_id}")
        
        # 检查所有删除记录
        total_deleted = sum(r.records_deleted for r in records if r.status == "completed")
        failed_count = sum(1 for r in records if r.status == "failed")
        
        # 执行验证扫描
        verification_passed = await self._scan_for_remaining_data(request_id)
        
        async with self._lock:
            if failed_count == 0 and verification_passed:
                request.status = ErasureStatus.COMPLETED
            elif failed_count > 0 and total_deleted > 0:
                request.status = ErasureStatus.PARTIAL
            else:
                request.status = ErasureStatus.REJECTED
            
            request.completed_at = datetime.utcnow()
            request.metadata["verification"] = {
                "total_deleted": total_deleted,
                "failed_count": failed_count,
                "verification_passed": verification_passed,
            }
        
        logger.info(f"删除验证完成: {request_id}, 状态: {request.status.value}")
        return verification_passed
    
    async def _scan_for_remaining_data(self, request_id: UUID) -> bool:
        """扫描残留数据"""
        # 模拟验证扫描
        await asyncio.sleep(0.1)
        return True
    
    async def get_deletion_status(self, request_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取删除状态
        
        Args:
            request_id: 请求ID
            
        Returns:
            状态信息
        """
        async with self._lock:
            if request_id not in self._requests:
                return None
            
            request = self._requests[request_id]
            records = self._deletion_records.get(request_id, [])
            
            total_records = sum(r.records_deleted for r in records)
            completed_locations = sum(1 for r in records if r.status == "completed")
            failed_locations = sum(1 for r in records if r.status == "failed")
            
            return {
                "request_id": str(request_id),
                "status": request.status.value,
                "request_date": request.request_date.isoformat(),
                "completed_at": request.completed_at.isoformat() if request.completed_at else None,
                "total_records_deleted": total_records,
                "locations_completed": completed_locations,
                "locations_failed": failed_locations,
                "progress_percentage": (completed_locations / len(records) * 100) if records else 0,
            }
    
    async def generate_deletion_report(self, request_id: UUID) -> Dict[str, Any]:
        """
        生成删除报告
        
        Args:
            request_id: 请求ID
            
        Returns:
            删除报告
        """
        async with self._lock:
            if request_id not in self._requests:
                raise ValueError(f"请求不存在: {request_id}")
            
            request = self._requests[request_id]
            records = self._deletion_records.get(request_id, [])
            locations = self._locations.get(request_id, [])
        
        report = {
            "report_type": "Data Erasure Report",
            "generated_at": datetime.utcnow().isoformat(),
            "request": {
                "id": str(request_id),
                "subject_id": str(request.subject_id),
                "request_date": request.request_date.isoformat(),
                "status": request.status.value,
                "reason": request.reason,
                "scope": request.scope,
            },
            "summary": {
                "total_locations": len(locations),
                "completed_deletions": sum(1 for r in records if r.status == "completed"),
                "failed_deletions": sum(1 for r in records if r.status == "failed"),
                "total_records_deleted": sum(r.records_deleted for r in records),
            },
            "deletion_details": [
                {
                    "location": loc.system_name,
                    "type": loc.location_type,
                    "categories": loc.data_categories,
                    "estimated_records": loc.estimated_records,
                    "deletion_record": next(
                        ({
                            "status": r.status,
                            "deleted": r.records_deleted,
                            "completed_at": r.completed_at.isoformat() if r.completed_at else None,
                        } for r in records if r.location_id == loc.id),
                        None
                    ),
                }
                for loc in locations
            ],
            "verification": request.metadata.get("verification", {}),
        }
        
        return report
    
    async def handle_backup_retention(self, request_id: UUID) -> Dict[str, Any]:
        """
        处理备份保留策略
        
        Args:
            request_id: 请求ID
            
        Returns:
            备份处理结果
        """
        # GDPR允许在备份中保留数据，但需确保不会恢复
        backup_policy = {
            "retention_period_days": 90,
            "deletion_scheduled": True,
            "irreversible_deletion": True,
            "notes": "数据已从活动系统删除，将在备份保留期后自动清除",
        }
        
        logger.info(f"备份保留策略已应用: {request_id}")
        return backup_policy
