"""
权利管理模块

处理GDPR数据主体权利请求：
- 访问权 (Right to Access)
- 删除权 (Right to Erasure)
- 数据携带权 (Right to Portability)
- 更正权 (Right to Rectification)
"""

from .access_request import AccessRequestHandler
from .erasure_request import ErasureRequestHandler
from .portability_request import PortabilityRequestHandler
from .rectification_request import RectificationRequestHandler

__all__ = [
    "AccessRequestHandler",
    "ErasureRequestHandler",
    "PortabilityRequestHandler",
    "RectificationRequestHandler",
]
