"""
访问权请求处理模块

处理GDPR第15条规定的访问权请求（DSAR - Data Subject Access Request）
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class RequestStatus(Enum):
    """请求状态"""
    PENDING = "pending"                 # 待处理
    VALIDATING = "validating"           # 验证中
    COLLECTING = "collecting"           # 收集中
    REVIEWING = "reviewing"             # 审核中
    READY = "ready"                     # 准备就绪
    DELIVERED = "delivered"             # 已交付
    REJECTED = "rejected"               # 已拒绝
    EXPIRED = "expired"                 # 已过期


class IdentityVerificationMethod(Enum):
    """身份验证方法"""
    EMAIL = "email"
    SMS = "sms"
    GOVERNMENT_ID = "government_id"
    KNOWLEDGE_BASED = "knowledge_based"
    BIOMETRIC = "biometric"
    IN_PERSON = "in_person"


@dataclass
class DataSubject:
    """数据主体"""
    id: UUID
    email: str
    first_name: str
    last_name: str
    date_of_birth: Optional[datetime] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    verification_status: bool = False
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class AccessRequest:
    """访问权请求"""
    id: UUID
    subject_id: UUID
    request_date: datetime
    status: RequestStatus
    scope: List[str]                 # 请求范围
    format_preference: str           # 格式偏好
    verification_method: IdentityVerificationMethod
    verification_completed: bool
    response_deadline: datetime
    completed_at: Optional[datetime] = None
    rejection_reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CollectedData:
    """收集的数据"""
    id: UUID
    request_id: UUID
    source_system: str
    data_category: str
    data_content: Dict[str, Any]
    collected_at: datetime
    retention_until: datetime
    hash_verification: str


class AccessRequestHandler:
    """
    访问权请求处理器
    
    处理GDPR第15条访问权请求，包括：
    - 身份验证
    - 数据收集
    - 第三方披露信息
    - 响应生成
    """
    
    # GDPR规定响应期限：30天，可延长到60天
    DEFAULT_RESPONSE_DAYS = 30
    MAX_RESPONSE_DAYS = 60
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化访问权请求处理器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/access_requests")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._requests: Dict[UUID, AccessRequest] = {}
        self._subjects: Dict[UUID, DataSubject] = {}
        self._collected_data: Dict[UUID, List[CollectedData]] = {}
        self._lock = asyncio.Lock()
        
        logger.info("访问权请求处理器初始化完成")
    
    async def submit_request(
        self,
        email: str,
        first_name: str,
        last_name: str,
        scope: List[str],
        format_preference: str = "json",
        verification_method: IdentityVerificationMethod = IdentityVerificationMethod.EMAIL,
        additional_info: Dict[str, Any] = None
    ) -> AccessRequest:
        """
        提交访问权请求
        
        Args:
            email: 邮箱
            first_name: 名
            last_name: 姓
            scope: 请求范围
            format_preference: 格式偏好 (json/pdf/csv)
            verification_method: 验证方法
            additional_info: 附加信息
            
        Returns:
            创建的请求
        """
        if additional_info is None:
            additional_info = {}
        
        # 查找或创建数据主体
        subject = await self._get_or_create_subject(email, first_name, last_name)
        
        # 计算响应截止日期
        deadline = datetime.utcnow() + timedelta(days=self.DEFAULT_RESPONSE_DAYS)
        
        request = AccessRequest(
            id=uuid4(),
            subject_id=subject.id,
            request_date=datetime.utcnow(),
            status=RequestStatus.PENDING,
            scope=scope,
            format_preference=format_preference,
            verification_method=verification_method,
            verification_completed=False,
            response_deadline=deadline,
            metadata=additional_info,
        )
        
        async with self._lock:
            self._requests[request.id] = request
            self._collected_data[request.id] = []
        
        logger.info(f"访问权请求已提交: {request.id} (主体: {email})")
        
        # 启动验证流程
        asyncio.create_task(self._initiate_verification(request.id))
        
        return request
    
    async def _get_or_create_subject(
        self,
        email: str,
        first_name: str,
        last_name: str
    ) -> DataSubject:
        """获取或创建数据主体"""
        async with self._lock:
            # 查找现有主体
            for subject in self._subjects.values():
                if subject.email.lower() == email.lower():
                    return subject
            
            # 创建新主体
            subject = DataSubject(
                id=uuid4(),
                email=email,
                first_name=first_name,
                last_name=last_name,
            )
            self._subjects[subject.id] = subject
            return subject
    
    async def _initiate_verification(self, request_id: UUID) -> None:
        """启动身份验证流程"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            request.status = RequestStatus.VALIDATING
        
        # 根据验证方法发送验证请求
        if request.verification_method == IdentityVerificationMethod.EMAIL:
            await self._send_email_verification(request_id)
        elif request.verification_method == IdentityVerificationMethod.SMS:
            await self._send_sms_verification(request_id)
        
        logger.info(f"身份验证已启动: {request_id}")
    
    async def _send_email_verification(self, request_id: UUID) -> None:
        """发送邮件验证"""
        # 实际实现中发送验证邮件
        logger.info(f"验证邮件已发送: {request_id}")
    
    async def _send_sms_verification(self, request_id: UUID) -> None:
        """发送短信验证"""
        # 实际实现中发送验证短信
        logger.info(f"验证短信已发送: {request_id}")
    
    async def verify_identity(
        self,
        request_id: UUID,
        verification_token: str
    ) -> bool:
        """
        验证身份
        
        Args:
            request_id: 请求ID
            verification_token: 验证令牌
            
        Returns:
            验证是否成功
        """
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            
            # 验证令牌（简化实现）
            if verification_token:
                request.verification_completed = True
                request.status = RequestStatus.COLLECTING
                
                # 启动数据收集
                asyncio.create_task(self._collect_data(request_id))
                
                logger.info(f"身份验证成功: {request_id}")
                return True
            
            return False
    
    async def _collect_data(self, request_id: UUID) -> None:
        """收集数据主体数据"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            subject = self._subjects[request.subject_id]
        
        logger.info(f"开始数据收集: {request_id}")
        
        # 根据请求范围收集数据
        for scope_item in request.scope:
            try:
                data = await self._fetch_data_from_source(subject, scope_item)
                if data:
                    async with self._lock:
                        self._collected_data[request_id].append(data)
            except Exception as e:
                logger.error(f"数据收集失败 {scope_item}: {e}")
        
        async with self._lock:
            request.status = RequestStatus.REVIEWING
        
        logger.info(f"数据收集完成: {request_id}")
    
    async def _fetch_data_from_source(
        self,
        subject: DataSubject,
        scope: str
    ) -> Optional[CollectedData]:
        """从数据源获取数据"""
        # 模拟从不同数据源获取数据
        data_content = {
            "scope": scope,
            "subject_email": subject.email,
            "data": f"模拟数据: {scope}",
        }
        
        # 计算哈希
        content_str = json.dumps(data_content, sort_keys=True)
        hash_verification = hashlib.sha256(content_str.encode()).hexdigest()
        
        return CollectedData(
            id=uuid4(),
            request_id=uuid4(),  # 将在调用处更新
            source_system=scope,
            data_category=scope,
            data_content=data_content,
            collected_at=datetime.utcnow(),
            retention_until=datetime.utcnow() + timedelta(days=90),
            hash_verification=hash_verification,
        )
    
    async def generate_response(self, request_id: UUID) -> Dict[str, Any]:
        """
        生成访问权响应
        
        Args:
            request_id: 请求ID
            
        Returns:
            响应数据
        """
        async with self._lock:
            if request_id not in self._requests:
                raise ValueError(f"请求不存在: {request_id}")
            
            request = self._requests[request_id]
            subject = self._subjects[request.subject_id]
            collected = self._collected_data.get(request_id, [])
        
        # 构建响应
        response = {
            "request_id": str(request_id),
            "response_date": datetime.utcnow().isoformat(),
            "data_subject": {
                "id": str(subject.id),
                "email": subject.email,
                "name": f"{subject.first_name} {subject.last_name}",
            },
            "processing_information": {
                "purposes": ["服务提供", "客户支持", "营销推广"],
                "legal_basis": ["合同履行", "合法利益", "同意"],
                "retention_periods": {
                    "account_data": "账户存续期间",
                    "transaction_data": "7年",
                    "marketing_data": "直到撤回同意",
                },
            },
            "personal_data": {},
            "recipients": [
                {"name": "云服务提供商", "purpose": "托管服务"},
                {"name": "支付处理商", "purpose": "支付处理"},
            ],
            "data_transfers": [
                {
                    "country": "美国",
                    "safeguards": "标准合同条款",
                    "purpose": "云服务托管",
                }
            ],
            "automated_decision_making": {
                "exists": False,
                "details": None,
            },
        }
        
        # 添加收集的数据
        for data in collected:
            response["personal_data"][data.data_category] = data.data_content
        
        # 更新请求状态
        async with self._lock:
            request.status = RequestStatus.READY
        
        return response
    
    async def export_response(
        self,
        request_id: UUID,
        output_format: Optional[str] = None
    ) -> str:
        """
        导出响应到文件
        
        Args:
            request_id: 请求ID
            output_format: 输出格式
            
        Returns:
            文件路径
        """
        response = await self.generate_response(request_id)
        
        async with self._lock:
            request = self._requests[request_id]
            fmt = output_format or request.format_preference
        
        # 生成文件名
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"dsar_response_{request_id}_{timestamp}.{fmt}"
        output_path = self.storage_path / filename
        
        if fmt == "json":
            async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(response, indent=2, ensure_ascii=False))
        elif fmt == "csv":
            # CSV格式处理
            await self._export_to_csv(response, output_path)
        else:
            # 默认JSON
            async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(response, indent=2, ensure_ascii=False))
        
        # 更新状态
        async with self._lock:
            request.status = RequestStatus.DELIVERED
            request.completed_at = datetime.utcnow()
        
        logger.info(f"响应已导出: {output_path}")
        return str(output_path)
    
    async def _export_to_csv(self, response: Dict[str, Any], output_path: Path) -> None:
        """导出为CSV格式"""
        # 简化实现
        async with aiofiles.open(output_path, 'w', encoding='utf-8') as f:
            await f.write("category,value\n")
            await f.write(f"request_id,{response['request_id']}\n")
            await f.write(f"response_date,{response['response_date']}\n")
    
    async def reject_request(
        self,
        request_id: UUID,
        reason: str,
        notify_subject: bool = True
    ) -> bool:
        """
        拒绝请求
        
        Args:
            request_id: 请求ID
            reason: 拒绝原因
            notify_subject: 是否通知数据主体
            
        Returns:
            是否成功
        """
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            request.status = RequestStatus.REJECTED
            request.rejection_reason = reason
            request.completed_at = datetime.utcnow()
        
        if notify_subject:
            await self._notify_rejection(request_id, reason)
        
        logger.info(f"请求已拒绝: {request_id}, 原因: {reason}")
        return True
    
    async def _notify_rejection(self, request_id: UUID, reason: str) -> None:
        """通知拒绝"""
        logger.info(f"拒绝通知已发送: {request_id}")
    
    async def get_request_status(self, request_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取请求状态
        
        Args:
            request_id: 请求ID
            
        Returns:
            状态信息
        """
        async with self._lock:
            if request_id not in self._requests:
                return None
            
            request = self._requests[request_id]
            subject = self._subjects[request.subject_id]
            
            return {
                "request_id": str(request_id),
                "status": request.status.value,
                "subject_email": subject.email,
                "request_date": request.request_date.isoformat(),
                "response_deadline": request.response_deadline.isoformat(),
                "verification_completed": request.verification_completed,
                "days_remaining": (request.response_deadline - datetime.utcnow()).days,
            }
    
    async def list_pending_requests(self) -> List[Dict[str, Any]]:
        """
        列出待处理请求
        
        Returns:
            待处理请求列表
        """
        async with self._lock:
            pending = []
            for request_id, request in self._requests.items():
                if request.status in [RequestStatus.PENDING, RequestStatus.COLLECTING, RequestStatus.REVIEWING]:
                    subject = self._subjects[request.subject_id]
                    pending.append({
                        "request_id": str(request_id),
                        "subject_email": subject.email,
                        "status": request.status.value,
                        "request_date": request.request_date.isoformat(),
                        "deadline": request.response_deadline.isoformat(),
                    })
            return pending
    
    async def extend_deadline(
        self,
        request_id: UUID,
        additional_days: int,
        reason: str
    ) -> bool:
        """
        延长响应期限
        
        Args:
            request_id: 请求ID
            additional_days: 额外天数
            reason: 延长原因
            
        Returns:
            是否成功
        """
        if additional_days > 30:
            logger.error("延长期限不能超过30天")
            return False
        
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            new_deadline = request.response_deadline + timedelta(days=additional_days)
            
            # 检查是否超过最大期限
            max_deadline = request.request_date + timedelta(days=self.MAX_RESPONSE_DAYS)
            if new_deadline > max_deadline:
                logger.error("超过最大响应期限")
                return False
            
            request.response_deadline = new_deadline
            request.metadata["deadline_extension"] = {
                "additional_days": additional_days,
                "reason": reason,
                "extended_at": datetime.utcnow().isoformat(),
            }
        
        logger.info(f"期限已延长: {request_id}, +{additional_days}天")
        return True
