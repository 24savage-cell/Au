"""
数据携带权请求处理模块

处理GDPR第20条规定的数据携带权请求（Right to Data Portability）
"""

import asyncio
import base64
import hashlib
import json
import logging
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)


class PortabilityStatus(Enum):
    """携带权请求状态"""
    PENDING = "pending"
    VALIDATING = "validating"
    EXTRACTING = "extracting"
    TRANSFORMING = "transforming"
    PACKAGING = "packaging"
    ENCRYPTING = "encrypting"
    READY = "ready"
    DELIVERED = "delivered"
    REJECTED = "rejected"


class DataFormat(Enum):
    """数据格式"""
    JSON = "json"
    CSV = "csv"
    XML = "xml"
    PARQUET = "parquet"
    SQL = "sql"


@dataclass
class PortabilityRequest:
    """数据携带权请求"""
    id: UUID
    subject_id: UUID
    request_date: datetime
    status: PortabilityStatus
    data_categories: List[str]
    target_format: DataFormat
    encryption_required: bool
    verification_completed: bool
    response_deadline: datetime
    completed_at: Optional[datetime] = None
    package_path: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DataExport:
    """数据导出记录"""
    id: UUID
    request_id: UUID
    source_system: str
    data_category: str
    raw_data: Dict[str, Any]
    exported_at: datetime
    record_count: int


class PortabilityRequestHandler:
    """
    数据携带权请求处理器
    
    处理GDPR第20条数据携带权请求，包括：
    - 数据提取
    - 格式转换
    - 加密打包
    - 安全交付
    """
    
    DEFAULT_RESPONSE_DAYS = 30
    SUPPORTED_FORMATS = [DataFormat.JSON, DataFormat.CSV, DataFormat.XML]
    
    def __init__(self, storage_path: Optional[str] = None, encryption_key: Optional[str] = None):
        """
        初始化携带权请求处理器
        
        Args:
            storage_path: 存储路径
            encryption_key: 加密密钥
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/portability_requests")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # 初始化加密
        if encryption_key:
            self._cipher = Fernet(encryption_key.encode())
        else:
            self._cipher = Fernet(Fernet.generate_key())
        
        self._requests: Dict[UUID, PortabilityRequest] = {}
        self._exports: Dict[UUID, List[DataExport]] = {}
        self._lock = asyncio.Lock()
        
        logger.info("数据携带权请求处理器初始化完成")
    
    async def submit_request(
        self,
        subject_id: UUID,
        data_categories: List[str],
        target_format: str = "json",
        encryption_required: bool = True
    ) -> PortabilityRequest:
        """
        提交数据携带权请求
        
        Args:
            subject_id: 数据主体ID
            data_categories: 数据类别列表
            target_format: 目标格式
            encryption_required: 是否需要加密
            
        Returns:
            创建的请求
        """
        # 验证格式
        try:
            format_enum = DataFormat(target_format.lower())
        except ValueError:
            raise ValueError(f"不支持的格式: {target_format}")
        
        if format_enum not in self.SUPPORTED_FORMATS:
            raise ValueError(f"不支持的格式: {target_format}")
        
        deadline = datetime.utcnow() + timedelta(days=self.DEFAULT_RESPONSE_DAYS)
        
        request = PortabilityRequest(
            id=uuid4(),
            subject_id=subject_id,
            request_date=datetime.utcnow(),
            status=PortabilityStatus.PENDING,
            data_categories=data_categories,
            target_format=format_enum,
            encryption_required=encryption_required,
            verification_completed=False,
            response_deadline=deadline,
        )
        
        async with self._lock:
            self._requests[request.id] = request
            self._exports[request.id] = []
        
        logger.info(f"数据携带权请求已提交: {request.id}")
        
        # 启动处理流程
        asyncio.create_task(self._process_request(request.id))
        
        return request
    
    async def _process_request(self, request_id: UUID) -> None:
        """处理携带权请求"""
        try:
            # 1. 验证请求
            await self._validate_request(request_id)
            
            # 2. 提取数据
            await self._extract_data(request_id)
            
            # 3. 格式转换
            await self._transform_data(request_id)
            
            # 4. 打包数据
            await self._package_data(request_id)
            
            # 5. 加密（如需要）
            await self._encrypt_package(request_id)
            
            async with self._lock:
                if request_id in self._requests:
                    self._requests[request_id].status = PortabilityStatus.READY
        
        except Exception as e:
            logger.error(f"携带权请求处理失败 {request_id}: {e}")
            async with self._lock:
                if request_id in self._requests:
                    self._requests[request_id].status = PortabilityStatus.REJECTED
    
    async def _validate_request(self, request_id: UUID) -> bool:
        """验证请求"""
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            request.status = PortabilityStatus.VALIDATING
        
        logger.info(f"请求验证完成: {request_id}")
        return True
    
    async def _extract_data(self, request_id: UUID) -> None:
        """提取数据主体数据"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            request.status = PortabilityStatus.EXTRACTING
            categories = request.data_categories
        
        logger.info(f"开始数据提取: {request_id}")
        
        # 模拟从不同系统提取数据
        for category in categories:
            try:
                export = await self._fetch_category_data(request_id, category)
                if export:
                    async with self._lock:
                        self._exports[request_id].append(export)
            except Exception as e:
                logger.error(f"数据提取失败 {category}: {e}")
        
        logger.info(f"数据提取完成: {request_id}")
    
    async def _fetch_category_data(
        self,
        request_id: UUID,
        category: str
    ) -> Optional[DataExport]:
        """从特定类别获取数据"""
        # 模拟数据提取
        await asyncio.sleep(0.1)
        
        sample_data = {
            "category": category,
            "records": [
                {"id": 1, "data": f"Sample data for {category}"},
                {"id": 2, "data": f"More data for {category}"},
            ]
        }
        
        return DataExport(
            id=uuid4(),
            request_id=request_id,
            source_system=f"system_{category}",
            data_category=category,
            raw_data=sample_data,
            exported_at=datetime.utcnow(),
            record_count=len(sample_data["records"]),
        )
    
    async def _transform_data(self, request_id: UUID) -> None:
        """转换数据格式"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            request.status = PortabilityStatus.TRANSFORMING
            target_format = request.target_format
            exports = self._exports.get(request_id, [])
        
        logger.info(f"开始格式转换: {request_id} -> {target_format.value}")
        
        for export in exports:
            try:
                if target_format == DataFormat.JSON:
                    export.raw_data = await self._to_json(export.raw_data)
                elif target_format == DataFormat.CSV:
                    export.raw_data = await self._to_csv(export.raw_data)
                elif target_format == DataFormat.XML:
                    export.raw_data = await self._to_xml(export.raw_data)
            except Exception as e:
                logger.error(f"格式转换失败 {export.data_category}: {e}")
        
        logger.info(f"格式转换完成: {request_id}")
    
    async def _to_json(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """转换为JSON格式"""
        return data
    
    async def _to_csv(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """转换为CSV格式"""
        # 简化实现
        return {
            "format": "csv",
            "content": "id,data\n1,sample\n2,more",
        }
    
    async def _to_xml(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """转换为XML格式"""
        # 简化实现
        return {
            "format": "xml",
            "content": "<?xml version='1.0'?><data></data>",
        }
    
    async def _package_data(self, request_id: UUID) -> str:
        """打包数据"""
        async with self._lock:
            if request_id not in self._requests:
                raise ValueError(f"请求不存在: {request_id}")
            
            request = self._requests[request_id]
            request.status = PortabilityStatus.PACKAGING
            exports = self._exports.get(request_id, [])
        
        logger.info(f"开始打包数据: {request_id}")
        
        # 创建ZIP包
        zip_buffer = BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            # 添加数据文件
            for export in exports:
                filename = f"{export.data_category}.{request.target_format.value}"
                content = json.dumps(export.raw_data, indent=2, ensure_ascii=False)
                zip_file.writestr(filename, content)
            
            # 添加清单文件
            manifest = {
                "export_date": datetime.utcnow().isoformat(),
                "request_id": str(request_id),
                "subject_id": str(request.subject_id),
                "format": request.target_format.value,
                "categories": [e.data_category for e in exports],
                "total_records": sum(e.record_count for e in exports),
            }
            zip_file.writestr("manifest.json", json.dumps(manifest, indent=2))
            
            # 添加README
            readme = self._generate_readme(request, exports)
            zip_file.writestr("README.txt", readme)
        
        # 保存ZIP文件
        package_filename = f"portability_{request_id}_{datetime.utcnow().strftime('%Y%m%d')}.zip"
        package_path = self.storage_path / package_filename
        
        async with aiofiles.open(package_path, 'wb') as f:
            await f.write(zip_buffer.getvalue())
        
        async with self._lock:
            request.package_path = str(package_path)
        
        logger.info(f"数据打包完成: {package_path}")
        return str(package_path)
    
    def _generate_readme(self, request: PortabilityRequest, exports: List[DataExport]) -> str:
        """生成README文件"""
        readme = f"""数据携带权导出包
================

请求ID: {request.id}
导出日期: {datetime.utcnow().isoformat()}
数据主体ID: {request.subject_id}
格式: {request.target_format.value}

包含的数据类别:
"""
        for export in exports:
            readme += f"  - {export.data_category}: {export.record_count} 条记录\n"
        
        readme += """
使用说明:
1. 此包包含您的个人数据导出
2. 数据以结构化、通用格式提供
3. 您可以将此数据导入其他服务提供商
4. 请妥善保管此文件

安全提示:
- 此文件包含个人敏感信息
- 请勿通过不安全的渠道传输
- 建议在使用后安全删除
"""
        return readme
    
    async def _encrypt_package(self, request_id: UUID) -> Optional[str]:
        """加密数据包"""
        async with self._lock:
            if request_id not in self._requests:
                return None
            
            request = self._requests[request_id]
            
            if not request.encryption_required:
                return request.package_path
            
            request.status = PortabilityStatus.ENCRYPTING
            package_path = request.package_path
        
        if not package_path:
            return None
        
        logger.info(f"开始加密数据包: {request_id}")
        
        # 读取原始文件
        async with aiofiles.open(package_path, 'rb') as f:
            data = await f.read()
        
        # 加密
        encrypted = self._cipher.encrypt(data)
        
        # 保存加密文件
        encrypted_path = package_path + ".encrypted"
        async with aiofiles.open(encrypted_path, 'wb') as f:
            await f.write(encrypted)
        
        # 删除原始文件
        Path(package_path).unlink()
        
        async with self._lock:
            request.package_path = encrypted_path
        
        logger.info(f"数据包加密完成: {encrypted_path}")
        return encrypted_path
    
    async def get_download_info(self, request_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取下载信息
        
        Args:
            request_id: 请求ID
            
        Returns:
            下载信息
        """
        async with self._lock:
            if request_id not in self._requests:
                return None
            
            request = self._requests[request_id]
            
            if request.status != PortabilityStatus.READY:
                return {
                    "request_id": str(request_id),
                    "status": request.status.value,
                    "message": "数据包尚未就绪",
                }
            
            # 生成下载令牌
            download_token = self._generate_download_token(request_id)
            
            return {
                "request_id": str(request_id),
                "status": "ready",
                "download_url": f"/api/portability/download/{request_id}",
                "download_token": download_token,
                "expires_at": (datetime.utcnow() + timedelta(hours=24)).isoformat(),
                "encrypted": request.encryption_required,
                "format": request.target_format.value,
            }
    
    def _generate_download_token(self, request_id: UUID) -> str:
        """生成下载令牌"""
        token_data = f"{request_id}:{datetime.utcnow().timestamp()}"
        return base64.urlsafe_b64encode(
            hashlib.sha256(token_data.encode()).digest()
        ).decode()[:32]
    
    async def verify_and_deliver(
        self,
        request_id: UUID,
        verification_code: str
    ) -> Optional[str]:
        """
        验证并交付数据包
        
        Args:
            request_id: 请求ID
            verification_code: 验证码
            
        Returns:
            文件路径
        """
        async with self._lock:
            if request_id not in self._requests:
                return None
            
            request = self._requests[request_id]
            
            # 验证验证码（简化实现）
            if verification_code:
                request.verification_completed = True
                request.status = PortabilityStatus.DELIVERED
                request.completed_at = datetime.utcnow()
                return request.package_path
            
            return None
    
    async def get_request_status(self, request_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取请求状态
        
        Args:
            request_id: 请求ID
            
        Returns:
            状态信息
        """
        async with self._lock:
            if request_id not in self._requests:
                return None
            
            request = self._requests[request_id]
            exports = self._exports.get(request_id, [])
            
            return {
                "request_id": str(request_id),
                "status": request.status.value,
                "request_date": request.request_date.isoformat(),
                "target_format": request.target_format.value,
                "categories_requested": request.data_categories,
                "categories_exported": [e.data_category for e in exports],
                "total_records": sum(e.record_count for e in exports),
                "encryption_enabled": request.encryption_required,
                "completed_at": request.completed_at.isoformat() if request.completed_at else None,
            }
    
    async def delete_package(self, request_id: UUID) -> bool:
        """
        删除数据包
        
        Args:
            request_id: 请求ID
            
        Returns:
            是否成功
        """
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            
            if request.package_path and Path(request.package_path).exists():
                Path(request.package_path).unlink()
                request.package_path = None
                logger.info(f"数据包已删除: {request_id}")
                return True
            
            return False
