"""
更正权请求处理模块

处理GDPR第16条规定的更正权请求（Right to Rectification）
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import UUID, uuid4

import aiofiles

logger = logging.getLogger(__name__)


class RectificationStatus(Enum):
    """更正状态"""
    PENDING = "pending"
    VALIDATING = "validating"
    REVIEWING = "reviewing"
    APPROVED = "approved"
    REJECTED = "rejected"
    APPLYING = "applying"
    PROPAGATING = "propagating"
    COMPLETED = "completed"
    PARTIAL = "partial"


class CorrectionType(Enum):
    """更正类型"""
    UPDATE = "update"           # 更新
    DELETE_FIELD = "delete"     # 删除字段
    ADD_FIELD = "add"           # 添加字段
    MERGE = "merge"             # 合并记录


@dataclass
class Correction:
    """更正记录"""
    id: UUID
    field_path: str             # 字段路径 (e.g., "profile.name")
    old_value: Any
    new_value: Any
    correction_type: CorrectionType
    reason: str
    supporting_documents: List[str]
    requested_at: datetime


@dataclass
class RectificationRequest:
    """更正权请求"""
    id: UUID
    subject_id: UUID
    request_date: datetime
    status: RectificationStatus
    corrections: List[Correction]
    verification_completed: bool
    response_deadline: datetime
    reviewed_by: Optional[UUID] = None
    review_notes: Optional[str] = None
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PropagationRecord:
    """传播记录"""
    id: UUID
    request_id: UUID
    target_system: str
    status: str
    applied_at: Optional[datetime]
    error_message: Optional[str]


class RectificationRequestHandler:
    """
    更正权请求处理器
    
    处理GDPR第16条更正权请求，包括：
    - 数据修正
    - 传播通知
    - 审计日志
    - 第三方通知
    """
    
    DEFAULT_RESPONSE_DAYS = 30
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        初始化更正权请求处理器
        
        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/rectification_requests")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._requests: Dict[UUID, RectificationRequest] = {}
        self._propagation_records: Dict[UUID, List[PropagationRecord]] = {}
        self._audit_log: List[Dict[str, Any]] = []
        self._lock = asyncio.Lock()
        
        logger.info("更正权请求处理器初始化完成")
    
    async def submit_request(
        self,
        subject_id: UUID,
        corrections: List[Dict[str, Any]],
        supporting_documents: List[str] = None
    ) -> RectificationRequest:
        """
        提交更正权请求
        
        Args:
            subject_id: 数据主体ID
            corrections: 更正列表
            supporting_documents: 支持文档
            
        Returns:
            创建的请求
        """
        if supporting_documents is None:
            supporting_documents = []
        
        deadline = datetime.utcnow() + timedelta(days=self.DEFAULT_RESPONSE_DAYS)
        
        # 创建更正记录
        correction_objects = []
        for corr_data in corrections:
            correction = Correction(
                id=uuid4(),
                field_path=corr_data["field_path"],
                old_value=corr_data.get("old_value"),
                new_value=corr_data["new_value"],
                correction_type=CorrectionType(corr_data.get("type", "update")),
                reason=corr_data.get("reason", ""),
                supporting_documents=supporting_documents,
                requested_at=datetime.utcnow(),
            )
            correction_objects.append(correction)
        
        request = RectificationRequest(
            id=uuid4(),
            subject_id=subject_id,
            request_date=datetime.utcnow(),
            status=RectificationStatus.PENDING,
            corrections=correction_objects,
            verification_completed=False,
            response_deadline=deadline,
        )
        
        async with self._lock:
            self._requests[request.id] = request
            self._propagation_records[request.id] = []
        
        # 记录审计日志
        await self._log_audit_event(
            event_type="REQUEST_SUBMITTED",
            request_id=request.id,
            subject_id=subject_id,
            details={"correction_count": len(correction_objects)},
        )
        
        logger.info(f"更正权请求已提交: {request.id}")
        return request
    
    async def review_request(
        self,
        request_id: UUID,
        reviewer_id: UUID,
        decision: str,
        notes: str = ""
    ) -> bool:
        """
        审核更正请求
        
        Args:
            request_id: 请求ID
            reviewer_id: 审核人ID
            decision: 决定 (approve/reject)
            notes: 审核备注
            
        Returns:
            是否成功
        """
        async with self._lock:
            if request_id not in self._requests:
                return False
            
            request = self._requests[request_id]
            request.status = RectificationStatus.REVIEWING
            request.reviewed_by = reviewer_id
            request.review_notes = notes
            
            if decision == "approve":
                request.status = RectificationStatus.APPROVED
                request.verification_completed = True
                
                # 启动应用流程
                asyncio.create_task(self._apply_corrections(request_id))
            else:
                request.status = RectificationStatus.REJECTED
                request.completed_at = datetime.utcnow()
        
        # 记录审计日志
        await self._log_audit_event(
            event_type="REQUEST_REVIEWED",
            request_id=request_id,
            reviewer_id=reviewer_id,
            details={"decision": decision, "notes": notes},
        )
        
        logger.info(f"请求已审核: {request_id}, 决定: {decision}")
        return True
    
    async def _apply_corrections(self, request_id: UUID) -> None:
        """应用更正"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            request.status = RectificationStatus.APPLYING
            corrections = request.corrections
        
        logger.info(f"开始应用更正: {request_id}")
        
        success_count = 0
        for correction in corrections:
            try:
                await self._apply_single_correction(request_id, correction)
                success_count += 1
            except Exception as e:
                logger.error(f"更正应用失败 {correction.field_path}: {e}")
        
        # 传播更正
        await self._propagate_corrections(request_id)
        
        # 更新状态
        async with self._lock:
            if success_count == len(corrections):
                request.status = RectificationStatus.COMPLETED
            elif success_count > 0:
                request.status = RectificationStatus.PARTIAL
            else:
                request.status = RectificationStatus.REJECTED
            
            request.completed_at = datetime.utcnow()
            request.metadata["application_result"] = {
                "total": len(corrections),
                "successful": success_count,
                "failed": len(corrections) - success_count,
            }
        
        # 记录审计日志
        await self._log_audit_event(
            event_type="CORRECTIONS_APPLIED",
            request_id=request_id,
            details={"successful": success_count, "total": len(corrections)},
        )
        
        logger.info(f"更正应用完成: {request_id}")
    
    async def _apply_single_correction(
        self,
        request_id: UUID,
        correction: Correction
    ) -> bool:
        """应用单个更正"""
        # 根据字段路径确定目标系统
        system = self._get_system_for_field(correction.field_path)
        
        try:
            # 模拟数据更新
            await asyncio.sleep(0.05)
            
            logger.info(
                f"更正已应用: {correction.field_path} "
                f"({correction.old_value} -> {correction.new_value})"
            )
            return True
        except Exception as e:
            logger.error(f"更正应用失败: {e}")
            return False
    
    def _get_system_for_field(self, field_path: str) -> str:
        """根据字段路径确定目标系统"""
        # 简化实现
        if field_path.startswith("profile"):
            return "user_profile_service"
        elif field_path.startswith("preferences"):
            return "preference_service"
        elif field_path.startswith("contact"):
            return "contact_service"
        else:
            return "main_database"
    
    async def _propagate_corrections(self, request_id: UUID) -> None:
        """传播更正到相关系统"""
        async with self._lock:
            if request_id not in self._requests:
                return
            
            request = self._requests[request_id]
            request.status = RectificationStatus.PROPAGATING
        
        logger.info(f"开始传播更正: {request_id}")
        
        # 确定需要通知的系统
        target_systems = set()
        for correction in request.corrections:
            target_systems.add(self._get_system_for_field(correction.field_path))
        
        # 添加第三方系统
        target_systems.update(["analytics_service", "marketing_platform", "crm_system"])
        
        for system in target_systems:
            try:
                await self._notify_system(request_id, system)
                
                record = PropagationRecord(
                    id=uuid4(),
                    request_id=request_id,
                    target_system=system,
                    status="completed",
                    applied_at=datetime.utcnow(),
                    error_message=None,
                )
                
                async with self._lock:
                    self._propagation_records[request_id].append(record)
                
            except Exception as e:
                logger.error(f"传播失败 {system}: {e}")
                
                record = PropagationRecord(
                    id=uuid4(),
                    request_id=request_id,
                    target_system=system,
                    status="failed",
                    applied_at=None,
                    error_message=str(e),
                )
                
                async with self._lock:
                    self._propagation_records[request_id].append(record)
        
        logger.info(f"更正传播完成: {request_id}")
    
    async def _notify_system(self, request_id: UUID, system: str) -> None:
        """通知系统更新"""
        # 实际实现中发送通知到各系统
        await asyncio.sleep(0.05)
        logger.info(f"系统通知已发送: {system}")
    
    async def _log_audit_event(
        self,
        event_type: str,
        request_id: Optional[UUID] = None,
        subject_id: Optional[UUID] = None,
        reviewer_id: Optional[UUID] = None,
        details: Dict[str, Any] = None
    ) -> None:
        """记录审计事件"""
        if details is None:
            details = {}
        
        event = {
            "id": str(uuid4()),
            "event_type": event_type,
            "request_id": str(request_id) if request_id else None,
            "subject_id": str(subject_id) if subject_id else None,
            "reviewer_id": str(reviewer_id) if reviewer_id else None,
            "timestamp": datetime.utcnow().isoformat(),
            "details": details,
        }
        
        async with self._lock:
            self._audit_log.append(event)
    
    async def get_request_status(self, request_id: UUID) -> Optional[Dict[str, Any]]:
        """
        获取请求状态
        
        Args:
            request_id: 请求ID
            
        Returns:
            状态信息
        """
        async with self._lock:
            if request_id not in self._requests:
                return None
            
            request = self._requests[request_id]
            propagation = self._propagation_records.get(request_id, [])
            
            return {
                "request_id": str(request_id),
                "status": request.status.value,
                "subject_id": str(request.subject_id),
                "request_date": request.request_date.isoformat(),
                "correction_count": len(request.corrections),
                "reviewed_by": str(request.reviewed_by) if request.reviewed_by else None,
                "review_notes": request.review_notes,
                "completed_at": request.completed_at.isoformat() if request.completed_at else None,
                "propagation_status": {
                    "total": len(propagation),
                    "completed": sum(1 for p in propagation if p.status == "completed"),
                    "failed": sum(1 for p in propagation if p.status == "failed"),
                },
            }
    
    async def get_correction_details(self, request_id: UUID) -> Optional[List[Dict[str, Any]]]:
        """
        获取更正详情
        
        Args:
            request_id: 请求ID
            
        Returns:
            更正详情列表
        """
        async with self._lock:
            if request_id not in self._requests:
                return None
            
            request = self._requests[request_id]
            
            return [
                {
                    "id": str(c.id),
                    "field_path": c.field_path,
                    "old_value": c.old_value,
                    "new_value": c.new_value,
                    "type": c.correction_type.value,
                    "reason": c.reason,
                    "requested_at": c.requested_at.isoformat(),
                }
                for c in request.corrections
            ]
    
    async def generate_audit_report(
        self,
        request_id: Optional[UUID] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """
        生成审计报告
        
        Args:
            request_id: 请求ID（可选）
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            审计报告
        """
        async with self._lock:
            events = self._audit_log.copy()
        
        # 过滤事件
        filtered = events
        
        if request_id:
            filtered = [e for e in filtered if e.get("request_id") == str(request_id)]
        
        if start_date:
            filtered = [
                e for e in filtered
                if datetime.fromisoformat(e["timestamp"]) >= start_date
            ]
        
        if end_date:
            filtered = [
                e for e in filtered
                if datetime.fromisoformat(e["timestamp"]) <= end_date
            ]
        
        # 统计
        event_types = {}
        for event in filtered:
            event_type = event["event_type"]
            event_types[event_type] = event_types.get(event_type, 0) + 1
        
        return {
            "generated_at": datetime.utcnow().isoformat(),
            "filters": {
                "request_id": str(request_id) if request_id else None,
                "start_date": start_date.isoformat() if start_date else None,
                "end_date": end_date.isoformat() if end_date else None,
            },
            "summary": {
                "total_events": len(filtered),
                "event_types": event_types,
            },
            "events": filtered,
        }
    
    async def export_audit_log(self, output_path: str) -> str:
        """
        导出审计日志
        
        Args:
            output_path: 输出路径
            
        Returns:
            输出文件路径
        """
        report = await self.generate_audit_report()
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(report, indent=2, ensure_ascii=False))
        
        logger.info(f"审计日志已导出: {output_file}")
        return str(output_file)
    
    async def list_pending_requests(self) -> List[Dict[str, Any]]:
        """
        列出待审核请求
        
        Returns:
            待审核请求列表
        """
        async with self._lock:
            pending = []
            for request_id, request in self._requests.items():
                if request.status == RectificationStatus.PENDING:
                    pending.append({
                        "request_id": str(request_id),
                        "subject_id": str(request.subject_id),
                        "request_date": request.request_date.isoformat(),
                        "correction_count": len(request.corrections),
                        "deadline": request.response_deadline.isoformat(),
                    })
            return pending
