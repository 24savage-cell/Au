"""
合规与透明度框架模块 (Compliance & Transparency Framework Module)

本模块实现了 IP4Move Aegis 系统中的合规性管理和透明度功能，包括：
1. 安全报告生成器 - 自动收集安全指标并生成 PDF/HTML 报告
2. 漏洞赏金计划管理器 - 管理漏洞提交、评估和赏金发放
3. 合规性设计框架 - GDPR/CCPA 等法规的合规检查和管理
4. 透明度日志 - 基于 Merkle 树的不可篡改操作日志

所有组件均支持多司法管辖区，并提供完整的审计追踪能力。

This module implements compliance management and transparency features:
1. Security Report Generator - auto-collect metrics and generate PDF/HTML reports
2. Bug Bounty Manager - manage vulnerability submission, assessment, and bounties
3. Compliance Framework - GDPR/CCPA compliance checking and management
4. Transparency Log - tamper-proof operation log based on Merkle tree
"""

from __future__ import annotations

import hashlib
import html as html_module
import json
import logging
import os
import re
import secrets
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Set,
    Tuple,
)

logger = logging.getLogger(__name__)


# ============================================================================
# 工具类和枚举定义 (Utility Classes and Enumerations)
# ============================================================================


class VulnerabilitySeverity(Enum):
    """漏洞严重程度枚举 (Vulnerability severity enumeration)

    基于 CVSS (Common Vulnerability Scoring System) 评分标准。
    """
    CRITICAL = "critical"      # 严重 (CVSS 9.0-10.0)
    HIGH = "high"              # 高危 (CVSS 7.0-8.9)
    MEDIUM = "medium"          # 中危 (CVSS 4.0-6.9)
    LOW = "low"                # 低危 (CVSS 0.1-3.9)
    INFO = "info"              # 信息 (CVSS 0.0)


class VulnerabilityStatus(Enum):
    """漏洞生命周期状态枚举 (Vulnerability lifecycle status enumeration)"""
    SUBMITTED = "submitted"        # 已提交
    TRIAGED = "triaged"            # 已分类
    CONFIRMED = "confirmed"        # 已确认
    IN_PROGRESS = "in_progress"    # 修复中
    FIXED = "fixed"                # 已修复
    VERIFIED = "verified"          # 已验证
    CLOSED = "closed"              # 已关闭
    DUPLICATE = "duplicate"        # 重复
    NOT_APPLICABLE = "not_applicable"  # 不适用


class ReportFormat(Enum):
    """报告格式枚举 (Report format enumeration)"""
    HTML = "html"
    JSON = "json"
    TEXT = "text"


class DataCategory(Enum):
    """数据分类枚举 (Data category enumeration)

    用于 GDPR 合规中的数据处理分类。
    """
    PERSONAL = "personal"              # 个人身份信息 (PII)
    SENSITIVE = "sensitive"            # 敏感个人信息
    USAGE = "usage"                    # 使用数据
    TECHNICAL = "technical"            # 技术数据
    ANALYTICS = "analytics"            # 分析数据
    PUBLIC = "public"                  # 公开数据


class UserRightType(Enum):
    """用户权利类型枚举 (User right type enumeration)

    基于 GDPR 第 15-22 条定义的用户权利。
    """
    RIGHT_OF_ACCESS = "right_of_access"             # 访问权 (第15条)
    RIGHT_TO_RECTIFICATION = "right_to_rectification"  # 更正权 (第16条)
    RIGHT_TO_ERASURE = "right_to_erasure"           # 删除权 (第17条)
    RIGHT_TO_RESTRICT = "right_to_restrict"         # 限制处理权 (第18条)
    RIGHT_TO_PORTABILITY = "right_to_portability"   # 数据移植权 (第20条)
    RIGHT_TO_OBJECT = "right_to_object"             # 反对权 (第21条)


class Jurisdiction(Enum):
    """司法管辖区枚举 (Jurisdiction enumeration)"""
    EU = "eu"            # 欧盟 (GDPR)
    US_CA = "us_ca"      # 美国加利福尼亚州 (CCPA)
    US = "us"            # 美国 (一般)
    CN = "cn"            # 中国 (PIPL)
    UK = "uk"            # 英国 (UK GDPR)
    OTHER = "other"      # 其他


@dataclass
class VulnerabilityReport:
    """漏洞报告数据结构 (Vulnerability report data structure)

    Attributes:
        report_id: 报告唯一标识
        title: 漏洞标题
        description: 详细描述
        severity: 严重程度
        status: 当前状态
        cvss_score: CVSS 评分 (0.0-10.0)
        reporter_id: 报告人标识
        bounty_amount: 赏金金额 (USD)
        submitted_at: 提交时间
        updated_at: 最后更新时间
        affected_components: 受影响的组件列表
        reproduction_steps: 复现步骤
        remediation: 修复建议
    """
    report_id: str
    title: str
    description: str
    severity: VulnerabilitySeverity
    status: VulnerabilityStatus = VulnerabilityStatus.SUBMITTED
    cvss_score: float = 0.0
    reporter_id: str = ""
    bounty_amount: float = 0.0
    submitted_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    affected_components: List[str] = field(default_factory=list)
    reproduction_steps: List[str] = field(default_factory=list)
    remediation: str = ""


@dataclass
class SecurityMetric:
    """安全指标数据结构 (Security metric data structure)

    Attributes:
        name: 指标名称
        value: 当前值
        unit: 单位
        trend: 趋势方向 ("up", "down", "stable")
        threshold_warning: 警告阈值
        threshold_critical: 严重阈值
        description: 指标描述
    """
    name: str
    value: float
    unit: str = ""
    trend: str = "stable"
    threshold_warning: Optional[float] = None
    threshold_critical: Optional[float] = None
    description: str = ""


@dataclass
class DPIARecord:
    """数据保护影响评估记录 (Data Protection Impact Assessment record)

    Attributes:
        assessment_id: 评估唯一标识
        processing_activity: 数据处理活动描述
        data_categories: 涉及的数据分类
        risk_level: 风险等级
        mitigation_measures: 缓解措施
        dpo_approval: 数据保护官审批状态
        assessment_date: 评估日期
        reviewer: 评估人
    """
    assessment_id: str
    processing_activity: str
    data_categories: List[DataCategory]
    risk_level: str = "medium"  # low, medium, high, critical
    mitigation_measures: List[str] = field(default_factory=list)
    dpo_approval: bool = False
    assessment_date: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    reviewer: str = ""


@dataclass
class UserRightRequest:
    """用户权利请求数据结构 (User right request data structure)

    Attributes:
        request_id: 请求唯一标识
        user_id: 用户标识
        right_type: 权利类型
        status: 处理状态
        requested_at: 请求时间
        completed_at: 完成时间
        response_data: 响应数据
        notes: 备注
    """
    request_id: str
    user_id: str
    right_type: UserRightType
    status: str = "pending"  # pending, processing, completed, rejected
    requested_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: Optional[datetime] = None
    response_data: Optional[Dict[str, Any]] = None
    notes: str = ""


@dataclass
class MerkleNode:
    """Merkle 树节点 (Merkle tree node)

    Attributes:
        hash_value: 节点哈希值
        left: 左子节点
        right: 右子节点
        data: 叶子节点存储的原始数据
        index: 叶子节点索引（仅叶子节点有效）
    """
    hash_value: str
    left: Optional[MerkleNode] = None
    right: Optional[MerkleNode] = None
    data: Optional[str] = None
    index: Optional[int] = None


# ============================================================================
# 安全报告生成器 (Security Report Generator)
# ============================================================================


class SecurityReportGenerator:
    """安全报告生成器 (Security Report Generator)

    自动收集安全指标、漏洞统计和合规状态，生成结构化的安全报告。
    支持 HTML、JSON 和纯文本三种输出格式，可配置定期自动生成。

    报告内容包括：
    - 安全指标概览（攻击检测率、漏洞修复时间等）
    - 漏洞统计和趋势分析
    - 合规状态检查结果
    - 建议和改进措施

    Example:
        >>> generator = SecurityReportGenerator(
        ...     report_title="IP4Move Aegis 安全报告",
        ...     auto_generate_hours=24,
        ... )
        >>> generator.add_metric(SecurityMetric(
        ...     name="攻击检测率", value=99.7, unit="%",
        ...     trend="up", description="过去30天的攻击检测率",
        ... ))
        >>> html_report = generator.generate_report(ReportFormat.HTML)
    """

    def __init__(
        self,
        report_title: str = "Security Report",
        organization: str = "IP4Move Aegis",
        auto_generate_hours: int = 24,
        retention_days: int = 90,
    ) -> None:
        """初始化安全报告生成器 (Initialize security report generator)

        Args:
            report_title: 报告标题
            organization: 组织名称
            auto_generate_hours: 自动生成周期（小时），0 表示禁用
            retention_days: 报告保留天数
        """
        self._report_title = report_title
        self._organization = organization
        self._auto_generate_hours = auto_generate_hours
        self._retention_days = retention_days

        # 安全指标收集
        self._metrics: Dict[str, SecurityMetric] = {}

        # 漏洞统计
        self._vulnerability_stats: Dict[str, int] = {
            "critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0,
        }

        # 合规状态
        self._compliance_status: Dict[str, bool] = {}

        # 历史报告
        self._report_history: List[Dict[str, Any]] = []

        # 上次自动生成时间
        self._last_generated: Optional[datetime] = None

        # 线程锁
        self._lock = threading.RLock()

        logger.info(
            "安全报告生成器初始化完成: title='%s', org='%s', auto=%dh",
            report_title, organization, auto_generate_hours,
        )

    # ------------------------------------------------------------------
    # 指标管理 (Metric Management)
    # ------------------------------------------------------------------

    def add_metric(self, metric: SecurityMetric) -> None:
        """添加安全指标 (Add security metric)

        Args:
            metric: 安全指标对象
        """
        if not metric.name:
            raise ValueError("指标名称不能为空")

        with self._lock:
            self._metrics[metric.name] = metric
            logger.debug("安全指标已添加: %s = %.2f %s", metric.name, metric.value, metric.unit)

    def remove_metric(self, name: str) -> bool:
        """移除安全指标 (Remove security metric)

        Args:
            name: 指标名称

        Returns:
            bool: 是否成功移除
        """
        with self._lock:
            if name not in self._metrics:
                return False
            del self._metrics[name]
            return True

    def update_vulnerability_stats(
        self,
        severity: VulnerabilitySeverity,
        count: int = 1,
    ) -> None:
        """更新漏洞统计 (Update vulnerability statistics)

        Args:
            severity: 漏洞严重程度
            count: 新增数量（可为负数，表示修复）
        """
        with self._lock:
            key = severity.value
            self._vulnerability_stats[key] = max(
                0, self._vulnerability_stats.get(key, 0) + count
            )

    def update_compliance_status(self, check_name: str, passed: bool) -> None:
        """更新合规状态 (Update compliance status)

        Args:
            check_name: 检查项名称
            passed: 是否通过
        """
        with self._lock:
            self._compliance_status[check_name] = passed

    # ------------------------------------------------------------------
    # 报告生成 (Report Generation)
    # ------------------------------------------------------------------

    def generate_report(
        self,
        format: ReportFormat = ReportFormat.HTML,
        include_metrics: bool = True,
        include_vulnerabilities: bool = True,
        include_compliance: bool = True,
    ) -> str:
        """生成安全报告 (Generate security report)

        Args:
            format: 报告格式
            include_metrics: 是否包含安全指标
            include_vulnerabilities: 是否包含漏洞统计
            include_compliance: 是否包含合规状态

        Returns:
            str: 生成的报告内容
        """
        with self._lock:
            report_data = {
                "title": self._report_title,
                "organization": self._organization,
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "report_period": {
                    "start": (
                        datetime.now(timezone.utc) - timedelta(days=30)
                    ).isoformat(),
                    "end": datetime.now(timezone.utc).isoformat(),
                },
            }

            if include_metrics:
                report_data["metrics"] = self._collect_metrics_summary()
            if include_vulnerabilities:
                report_data["vulnerabilities"] = self._collect_vulnerability_summary()
            if include_compliance:
                report_data["compliance"] = self._collect_compliance_summary()

            # 根据格式生成报告
            if format == ReportFormat.HTML:
                content = self._render_html(report_data)
            elif format == ReportFormat.JSON:
                content = json.dumps(report_data, indent=2, ensure_ascii=False)
            elif format == ReportFormat.TEXT:
                content = self._render_text(report_data)
            else:
                raise ValueError(f"不支持的报告格式: {format}")

            # 记录历史
            self._last_generated = datetime.now(timezone.utc)
            self._report_history.append({
                "timestamp": self._last_generated.isoformat(),
                "format": format.value,
                "size": len(content),
            })

            # 限制历史长度
            if len(self._report_history) > 1000:
                self._report_history = self._report_history[-1000:]

            logger.info(
                "安全报告已生成: format=%s, size=%d bytes",
                format.value, len(content),
            )
            return content

    def _collect_metrics_summary(self) -> Dict[str, Any]:
        """收集指标摘要 (Collect metrics summary)"""
        metrics_list = []
        for name, metric in self._metrics.items():
            entry = {
                "name": name,
                "value": metric.value,
                "unit": metric.unit,
                "trend": metric.trend,
                "description": metric.description,
            }
            # 添加阈值状态
            if metric.threshold_critical is not None:
                if metric.value >= metric.threshold_critical:
                    entry["status"] = "critical"
                elif metric.threshold_warning is not None and metric.value >= metric.threshold_warning:
                    entry["status"] = "warning"
                else:
                    entry["status"] = "ok"
            metrics_list.append(entry)
        return {"total": len(metrics_list), "items": metrics_list}

    def _collect_vulnerability_summary(self) -> Dict[str, Any]:
        """收集漏洞摘要 (Collect vulnerability summary)"""
        total = sum(self._vulnerability_stats.values())
        return {
            "total": total,
            "by_severity": self._vulnerability_stats.copy(),
            "critical_ratio": (
                self._vulnerability_stats.get("critical", 0) / total
                if total > 0 else 0.0
            ),
        }

    def _collect_compliance_summary(self) -> Dict[str, Any]:
        """收集合规摘要 (Collect compliance summary)"""
        total = len(self._compliance_status)
        passed = sum(1 for v in self._compliance_status.values() if v)
        return {
            "total_checks": total,
            "passed": passed,
            "failed": total - passed,
            "pass_rate": passed / total if total > 0 else 1.0,
            "details": self._compliance_status.copy(),
        }

    # ------------------------------------------------------------------
    # 报告渲染 (Report Rendering)
    # ------------------------------------------------------------------

    def _render_html(self, data: Dict[str, Any]) -> str:
        """渲染 HTML 格式报告 (Render HTML format report)

        Args:
            data: 报告数据

        Returns:
            str: HTML 格式的报告
        """
        lines = [
            "<!DOCTYPE html>",
            "<html lang='zh-CN'>",
            "<head>",
            f"<title>{html_module.escape(data['title'])}</title>",
            "<meta charset='UTF-8'>",
            "<style>",
            "  body { font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; "
            "background: #f5f5f5; color: #333; }",
            "  .container { max-width: 1200px; margin: 0 auto; background: white; "
            "padding: 40px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }",
            "  h1 { color: #1a73e8; border-bottom: 2px solid #1a73e8; padding-bottom: 10px; }",
            "  h2 { color: #333; margin-top: 30px; }",
            "  .metric { display: inline-block; padding: 15px 20px; margin: 5px; "
            "border-radius: 6px; background: #f8f9fa; min-width: 200px; }",
            "  .metric.ok { border-left: 4px solid #34a853; }",
            "  .metric.warning { border-left: 4px solid #fbbc04; }",
            "  .metric.critical { border-left: 4px solid #ea4335; }",
            "  .metric-value { font-size: 24px; font-weight: bold; }",
            "  .metric-name { font-size: 12px; color: #666; }",
            "  table { width: 100%; border-collapse: collapse; margin: 15px 0; }",
            "  th, td { padding: 10px 15px; text-align: left; border-bottom: 1px solid #ddd; }",
            "  th { background: #f8f9fa; font-weight: 600; }",
            "  .badge { display: inline-block; padding: 3px 8px; border-radius: 12px; "
            "font-size: 12px; font-weight: bold; }",
            "  .badge-critical { background: #ea4335; color: white; }",
            "  .badge-high { background: #ff6d01; color: white; }",
            "  .badge-medium { background: #fbbc04; color: #333; }",
            "  .badge-low { background: #34a853; color: white; }",
            "  .badge-info { background: #4285f4; color: white; }",
            "  .badge-pass { background: #34a853; color: white; }",
            "  .badge-fail { background: #ea4335; color: white; }",
            "  .footer { margin-top: 30px; padding-top: 15px; border-top: 1px solid #ddd; "
            "color: #999; font-size: 12px; }",
            "</style>",
            "</head>",
            "<body>",
            "<div class='container'>",
            f"<h1>{html_module.escape(data['title'])}</h1>",
            f"<p><strong>组织:</strong> {html_module.escape(data['organization'])}</p>",
            f"<p><strong>生成时间:</strong> {data['generated_at']}</p>",
            f"<p><strong>报告周期:</strong> {data['report_period']['start']} ~ "
            f"{data['report_period']['end']}</p>",
        ]

        # 安全指标部分
        if "metrics" in data:
            lines.append("<h2>安全指标概览</h2>")
            lines.append("<div class='metrics-container'>")
            for item in data["metrics"]["items"]:
                status = item.get("status", "ok")
                lines.append(
                    f"<div class='metric {status}'>"
                    f"<div class='metric-value'>{item['value']}{item['unit']}</div>"
                    f"<div class='metric-name'>{html_module.escape(item['name'])}</div>"
                    f"</div>"
                )
            lines.append("</div>")

        # 漏洞统计部分
        if "vulnerabilities" in data:
            vuln = data["vulnerabilities"]
            lines.append("<h2>漏洞统计</h2>")
            lines.append("<table>")
            lines.append("<tr><th>严重程度</th><th>数量</th><th>占比</th></tr>")
            severity_labels = {
                "critical": ("严重", "badge-critical"),
                "high": ("高危", "badge-high"),
                "medium": ("中危", "badge-medium"),
                "low": ("低危", "badge-low"),
                "info": ("信息", "badge-info"),
            }
            for sev_key, count in vuln["by_severity"].items():
                label, badge_class = severity_labels.get(sev_key, (sev_key, "badge-info"))
                ratio = f"{count / vuln['total'] * 100:.1f}%" if vuln["total"] > 0 else "0%"
                lines.append(
                    f"<tr><td><span class='badge {badge_class}'>{label}</span></td>"
                    f"<td>{count}</td><td>{ratio}</td></tr>"
                )
            lines.append(f"<tr><td><strong>总计</strong></td><td><strong>{vuln['total']}</strong></td>"
                         f"<td></td></tr>")
            lines.append("</table>")

        # 合规状态部分
        if "compliance" in data:
            comp = data["compliance"]
            lines.append("<h2>合规状态</h2>")
            lines.append(
                f"<p>通过率: <strong>{comp['pass_rate']:.1%}</strong> "
                f"({comp['passed']}/{comp['total_checks']})</p>"
            )
            lines.append("<table>")
            lines.append("<tr><th>检查项</th><th>状态</th></tr>")
            for check_name, passed in comp["details"].items():
                badge = "badge-pass" if passed else "badge-fail"
                status_text = "通过" if passed else "未通过"
                lines.append(
                    f"<tr><td>{html_module.escape(check_name)}</td>"
                    f"<td><span class='badge {badge}'>{status_text}</span></td></tr>"
                )
            lines.append("</table>")

        # 页脚
        lines.extend([
            "<div class='footer'>",
            f"<p>本报告由 {html_module.escape(data['organization'])} 安全系统自动生成。</p>",
            f"<p>生成时间: {data['generated_at']} (UTC)</p>",
            "</div>",
            "</div>",
            "</body>",
            "</html>",
        ])

        return "\n".join(lines)

    def _render_text(self, data: Dict[str, Any]) -> str:
        """渲染纯文本格式报告 (Render plain text format report)

        Args:
            data: 报告数据

        Returns:
            str: 纯文本格式的报告
        """
        separator = "=" * 70
        lines = [
            separator,
            f"  {data['title']}",
            f"  组织: {data['organization']}",
            f"  生成时间: {data['generated_at']}",
            separator,
            "",
        ]

        if "metrics" in data:
            lines.append(">> 安全指标概览")
            lines.append("-" * 40)
            for item in data["metrics"]["items"]:
                status = item.get("status", "ok")
                status_mark = {
                    "ok": "[OK]", "warning": "[!!]", "critical": "[!!]"
                }.get(status, "[--]")
                lines.append(
                    f"  {status_mark} {item['name']}: {item['value']}{item['unit']}"
                    f" (趋势: {item['trend']})"
                )
            lines.append("")

        if "vulnerabilities" in data:
            vuln = data["vulnerabilities"]
            lines.append(">> 漏洞统计")
            lines.append("-" * 40)
            severity_labels = {
                "critical": "严重", "high": "高危",
                "medium": "中危", "low": "低危", "info": "信息",
            }
            for sev_key, count in vuln["by_severity"].items():
                label = severity_labels.get(sev_key, sev_key)
                lines.append(f"  {label}: {count}")
            lines.append(f"  总计: {vuln['total']}")
            lines.append("")

        if "compliance" in data:
            comp = data["compliance"]
            lines.append(">> 合规状态")
            lines.append("-" * 40)
            lines.append(f"  通过率: {comp['pass_rate']:.1%} ({comp['passed']}/{comp['total_checks']})")
            for check_name, passed in comp["details"].items():
                status = "PASS" if passed else "FAIL"
                lines.append(f"  [{status}] {check_name}")
            lines.append("")

        lines.append(separator)
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # 自动生成 (Auto Generation)
    # ------------------------------------------------------------------

    def should_auto_generate(self) -> bool:
        """检查是否应该自动生成报告 (Check if auto-generation is due)

        Returns:
            bool: 是否到达自动生成时间
        """
        if self._auto_generate_hours <= 0:
            return False
        if self._last_generated is None:
            return True

        elapsed = datetime.now(timezone.utc) - self._last_generated
        return elapsed >= timedelta(hours=self._auto_generate_hours)

    def get_report_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取报告生成历史 (Get report generation history)"""
        with self._lock:
            return self._report_history[-limit:]


# ============================================================================
# 漏洞赏金计划管理器 (Bug Bounty Manager)
# ============================================================================


class BugBountyManager:
    """漏洞赏金计划管理器 (Bug Bounty Program Manager)

    管理漏洞赏金计划的全生命周期，包括漏洞提交、严重程度评估、
    赏金计算和研究人员信誉管理。

    功能：
    - 漏洞提交接口：接收外部研究人员的漏洞报告
    - CVSS 评分：自动或手动评估漏洞严重程度
    - 赏金计算：基于严重程度和影响范围的赏金分配
    - 研究人员信誉：跟踪和管理研究人员的贡献历史
    - 漏洞生命周期：从提交到关闭的完整状态管理

    Example:
        >>> manager = BugBountyManager(
        ...     bounty_table={VulnerabilitySeverity.CRITICAL: 10000.0, ...},
        ... )
        >>> report_id = manager.submit_vulnerability(
        ...     title="XSS in login page",
        ...     description="Reflected XSS vulnerability...",
        ...     reporter_id="researcher_001",
        ...     severity=VulnerabilitySeverity.HIGH,
        ... )
    """

    # 默认赏金表（USD）
    DEFAULT_BOUNTY_TABLE: Dict[VulnerabilitySeverity, float] = {
        VulnerabilitySeverity.CRITICAL: 10000.0,
        VulnerabilitySeverity.HIGH: 5000.0,
        VulnerabilitySeverity.MEDIUM: 1000.0,
        VulnerabilitySeverity.LOW: 200.0,
        VulnerabilitySeverity.INFO: 50.0,
    }

    def __init__(
        self,
        bounty_table: Optional[Dict[VulnerabilitySeverity, float]] = None,
        duplicate_threshold: float = 0.85,
        max_bounty_multiplier: float = 3.0,
    ) -> None:
        """初始化漏洞赏金管理器 (Initialize bug bounty manager)

        Args:
            bounty_table: 自定义赏金表，为 None 则使用默认值
            duplicate_threshold: 重复检测的相似度阈值
            max_bounty_multiplier: 最大赏金倍数（基于研究员信誉）
        """
        self._bounty_table = bounty_table or self.DEFAULT_BOUNTY_TABLE.copy()
        self._duplicate_threshold = duplicate_threshold
        self._max_bounty_multiplier = max_bounty_multiplier

        # 漏洞报告存储
        self._reports: Dict[str, VulnerabilityReport] = {}

        # 研究人员信誉
        self._researcher_reputation: Dict[str, float] = {}
        self._researcher_stats: Dict[str, Dict[str, int]] = {}

        # 线程锁
        self._lock = threading.RLock()

        logger.info("漏洞赏金管理器初始化完成")

    # ------------------------------------------------------------------
    # 漏洞提交 (Vulnerability Submission)
    # ------------------------------------------------------------------

    def submit_vulnerability(
        self,
        title: str,
        description: str,
        reporter_id: str,
        severity: VulnerabilitySeverity = VulnerabilitySeverity.MEDIUM,
        affected_components: Optional[List[str]] = None,
        reproduction_steps: Optional[List[str]] = None,
        remediation: str = "",
    ) -> str:
        """提交漏洞报告 (Submit vulnerability report)

        Args:
            title: 漏洞标题
            description: 详细描述
            reporter_id: 报告人标识
            severity: 建议的严重程度
            affected_components: 受影响的组件列表
            reproduction_steps: 复现步骤
            remediation: 修复建议

        Returns:
            str: 报告 ID

        Raises:
            ValueError: 必填字段为空时抛出
        """
        if not title.strip():
            raise ValueError("漏洞标题不能为空")
        if not description.strip():
            raise ValueError("漏洞描述不能为空")
        if not reporter_id.strip():
            raise ValueError("报告人标识不能为空")

        # 检查重复
        is_duplicate = self._check_duplicate(title, description)
        if is_duplicate:
            logger.warning("检测到可能的重复漏洞: %s", title)

        # 生成报告 ID
        report_id = f"VULN-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{secrets.token_hex(4)}"

        # 创建报告
        report = VulnerabilityReport(
            report_id=report_id,
            title=title.strip(),
            description=description.strip(),
            severity=severity,
            reporter_id=reporter_id,
            cvss_score=self._severity_to_cvss(severity),
            affected_components=affected_components or [],
            reproduction_steps=reproduction_steps or [],
            remediation=remediation,
            status=VulnerabilityStatus.DUPLICATE if is_duplicate else VulnerabilityStatus.SUBMITTED,
        )

        with self._lock:
            self._reports[report_id] = report

            # 更新研究人员统计
            if reporter_id not in self._researcher_stats:
                self._researcher_stats[reporter_id] = {
                    "submitted": 0, "accepted": 0, "rejected": 0,
                }
            self._researcher_stats[reporter_id]["submitted"] += 1

        logger.info(
            "漏洞报告已提交: id=%s, title='%s', severity=%s, reporter=%s",
            report_id, title, severity.value, reporter_id,
        )
        return report_id

    def _check_duplicate(self, title: str, description: str) -> bool:
        """检查是否为重复漏洞 (Check for duplicate vulnerability)

        使用简单的文本相似度比较（Jaccard 相似度）。

        Args:
            title: 漏洞标题
            description: 漏洞描述

        Returns:
            bool: 是否为可能的重复
        """
        if not self._reports:
            return False

        # 提取关键词
        def tokenize(text: str) -> Set[str]:
            words = re.findall(r'\w+', text.lower())
            return set(words)

        new_tokens = tokenize(title + " " + description)

        for report in self._reports.values():
            existing_tokens = tokenize(report.title + " " + report.description)
            if not existing_tokens or not new_tokens:
                continue
            # Jaccard 相似度
            intersection = new_tokens & existing_tokens
            union = new_tokens | existing_tokens
            similarity = len(intersection) / len(union)
            if similarity >= self._duplicate_threshold:
                return True

        return False

    def _severity_to_cvss(self, severity: VulnerabilitySeverity) -> float:
        """将严重程度映射到 CVSS 分数 (Map severity to CVSS score)

        Args:
            severity: 漏洞严重程度

        Returns:
            float: 对应的 CVSS 分数
        """
        mapping = {
            VulnerabilitySeverity.CRITICAL: 9.5,
            VulnerabilitySeverity.HIGH: 7.5,
            VulnerabilitySeverity.MEDIUM: 5.5,
            VulnerabilitySeverity.LOW: 2.5,
            VulnerabilitySeverity.INFO: 0.0,
        }
        return mapping.get(severity, 5.0)

    # ------------------------------------------------------------------
    # 漏洞管理 (Vulnerability Management)
    # ------------------------------------------------------------------

    def update_status(
        self,
        report_id: str,
        new_status: VulnerabilityStatus,
        reviewer: str = "",
    ) -> bool:
        """更新漏洞状态 (Update vulnerability status)

        Args:
            report_id: 报告 ID
            new_status: 新状态
            reviewer: 审核人

        Returns:
            bool: 是否成功更新
        """
        with self._lock:
            report = self._reports.get(report_id)
            if report is None:
                logger.error("报告不存在: %s", report_id)
                return False

            old_status = report.status
            report.status = new_status
            report.updated_at = datetime.now(timezone.utc)

            # 如果状态变为已确认，更新研究人员统计
            if new_status in (
                VulnerabilityStatus.CONFIRMED,
                VulnerabilityStatus.FIXED,
                VulnerabilityStatus.VERIFIED,
            ):
                stats = self._researcher_stats.get(report.reporter_id, {})
                if stats.get("accepted", 0) == 0 or old_status == VulnerabilityStatus.SUBMITTED:
                    stats["accepted"] = stats.get("accepted", 0) + 1
                self._researcher_stats[report.reporter_id] = stats

            # 计算赏金
            if new_status == VulnerabilityStatus.CONFIRMED:
                report.bounty_amount = self._calculate_bounty(report)

            logger.info(
                "漏洞状态已更新: id=%s, %s -> %s, reviewer=%s",
                report_id, old_status.value, new_status.value, reviewer,
            )
            return True

    def _calculate_bounty(self, report: VulnerabilityReport) -> float:
        """计算漏洞赏金 (Calculate vulnerability bounty)

        基础赏金由赏金表决定，最终赏金受研究人员信誉倍数影响。

        Args:
            report: 漏洞报告

        Returns:
            float: 赏金金额 (USD)
        """
        base_bounty = self._bounty_table.get(report.severity, 0.0)

        # 信誉倍数（1.0 - max_multiplier）
        reputation = self._researcher_reputation.get(report.reporter_id, 0.5)
        multiplier = 1.0 + (reputation / 100.0) * (self._max_bounty_multiplier - 1.0)
        multiplier = min(multiplier, self._max_bounty_multiplier)

        return round(base_bounty * multiplier, 2)

    # ------------------------------------------------------------------
    # 研究人员管理 (Researcher Management)
    # ------------------------------------------------------------------

    def update_researcher_reputation(
        self,
        researcher_id: str,
        delta: float,
    ) -> float:
        """更新研究人员信誉分数 (Update researcher reputation score)

        Args:
            researcher_id: 研究人员标识
            delta: 信誉变化值（可正可负）

        Returns:
            float: 更新后的信誉分数
        """
        with self._lock:
            current = self._researcher_reputation.get(researcher_id, 50.0)
            new_score = max(0.0, min(100.0, current + delta))
            self._researcher_reputation[researcher_id] = new_score
            logger.info(
                "研究人员信誉更新: %s, %.1f -> %.1f",
                researcher_id, current, new_score,
            )
            return new_score

    def get_researcher_stats(self, researcher_id: str) -> Dict[str, Any]:
        """获取研究人员统计信息 (Get researcher statistics)

        Args:
            researcher_id: 研究人员标识

        Returns:
            Dict: 包含提交数、接受数、信誉分数等信息
        """
        with self._lock:
            return {
                "researcher_id": researcher_id,
                "reputation": self._researcher_reputation.get(researcher_id, 50.0),
                "stats": self._researcher_stats.get(researcher_id, {
                    "submitted": 0, "accepted": 0, "rejected": 0,
                }),
            }

    # ------------------------------------------------------------------
    # 查询接口 (Query Interface)
    # ------------------------------------------------------------------

    def get_report(self, report_id: str) -> Optional[Dict[str, Any]]:
        """获取漏洞报告详情 (Get vulnerability report details)

        Args:
            report_id: 报告 ID

        Returns:
            Optional[Dict]: 报告详情，不存在返回 None
        """
        report = self._reports.get(report_id)
        if report is None:
            return None

        return {
            "report_id": report.report_id,
            "title": report.title,
            "description": report.description,
            "severity": report.severity.value,
            "status": report.status.value,
            "cvss_score": report.cvss_score,
            "reporter_id": report.reporter_id,
            "bounty_amount": report.bounty_amount,
            "submitted_at": report.submitted_at.isoformat(),
            "updated_at": report.updated_at.isoformat(),
            "affected_components": report.affected_components,
            "reproduction_steps": report.reproduction_steps,
            "remediation": report.remediation,
        }

    def list_reports(
        self,
        severity: Optional[VulnerabilitySeverity] = None,
        status: Optional[VulnerabilityStatus] = None,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """列出漏洞报告 (List vulnerability reports)

        Args:
            severity: 按严重程度过滤
            status: 按状态过滤
            limit: 最大返回数量

        Returns:
            List[Dict]: 报告列表
        """
        reports = list(self._reports.values())

        if severity is not None:
            reports = [r for r in reports if r.severity == severity]
        if status is not None:
            reports = [r for r in reports if r.status == status]

        # 按提交时间倒序
        reports.sort(key=lambda r: r.submitted_at, reverse=True)

        return [
            {
                "report_id": r.report_id,
                "title": r.title,
                "severity": r.severity.value,
                "status": r.status.value,
                "cvss_score": r.cvss_score,
                "bounty_amount": r.bounty_amount,
                "submitted_at": r.submitted_at.isoformat(),
            }
            for r in reports[:limit]
        ]

    def get_dashboard_stats(self) -> Dict[str, Any]:
        """获取仪表盘统计数据 (Get dashboard statistics)

        Returns:
            Dict: 包含各状态和严重程度的统计数据
        """
        with self._lock:
            status_counts: Dict[str, int] = {}
            severity_counts: Dict[str, int] = {}
            total_bounty = 0.0

            for report in self._reports.values():
                status_counts[report.status.value] = status_counts.get(report.status.value, 0) + 1
                severity_counts[report.severity.value] = severity_counts.get(report.severity.value, 0) + 1
                total_bounty += report.bounty_amount

            return {
                "total_reports": len(self._reports),
                "by_status": status_counts,
                "by_severity": severity_counts,
                "total_bounty_paid": total_bounty,
                "total_researchers": len(self._researcher_stats),
            }


# ============================================================================
# 合规性设计框架 (Compliance Design Framework)
# ============================================================================


class ComplianceFramework:
    """合规性设计框架 (Compliance Design Framework)

    提供全面的合规性管理功能，支持 GDPR、CCPA、PIPL 等主流隐私法规。
    核心功能包括：

    - GDPR 合规检查：自动化检查数据处理活动是否符合 GDPR 要求
    - 数据保护影响评估 (DPIA)：评估高风险数据处理活动
    - 数据保留策略：管理数据的保留期限和删除
    - 用户权利管理：处理用户的访问、删除、移植等权利请求
    - 合规审计日志：记录所有合规相关操作
    - 多司法管辖区支持：针对不同地区应用不同的合规规则

    Example:
        >>> framework = ComplianceFramework(
        ...     organization="IP4Move Aegis",
        ...     jurisdictions=[Jurisdiction.EU, Jurisdiction.US_CA],
        ... )
        >>> framework.register_data_processing(
        ...     activity="用户流量分析",
        ...     categories=[DataCategory.USAGE, DataCategory.ANALYTICS],
        ...     retention_days=90,
        ... )
        >>> results = framework.run_gdpr_check()
    """

    def __init__(
        self,
        organization: str = "IP4Move Aegis",
        jurisdictions: Optional[List[Jurisdiction]] = None,
        default_retention_days: int = 365,
        dpo_email: str = "",
    ) -> None:
        """初始化合规框架 (Initialize compliance framework)

        Args:
            organization: 组织名称
            jurisdictions: 支持的司法管辖区列表
            default_retention_days: 默认数据保留天数
            dpo_email: 数据保护官 (DPO) 邮箱
        """
        self._organization = organization
        self._jurisdictions = jurisdictions or [Jurisdiction.EU]
        self._default_retention_days = default_retention_days
        self._dpo_email = dpo_email

        # 数据处理活动注册表
        self._processing_activities: List[Dict[str, Any]] = []

        # 数据保留策略
        self._retention_policies: Dict[str, int] = {}

        # DPIA 记录
        self._dpia_records: Dict[str, DPIARecord] = {}

        # 用户权利请求
        self._right_requests: Dict[str, UserRightRequest] = {}

        # 合规审计日志
        self._audit_log: List[Dict[str, Any]] = []

        # 数据主体同意记录
        self._consent_records: Dict[str, Dict[str, Any]] = {}

        # 线程锁
        self._lock = threading.RLock()

        logger.info(
            "合规框架初始化完成: org='%s', jurisdictions=%s",
            organization, [j.value for j in self._jurisdictions],
        )

    # ------------------------------------------------------------------
    # 数据处理活动管理 (Data Processing Activity Management)
    # ------------------------------------------------------------------

    def register_data_processing(
        self,
        activity: str,
        categories: List[DataCategory],
        purpose: str = "",
        legal_basis: str = "consent",
        retention_days: Optional[int] = None,
        data_controller: str = "",
    ) -> str:
        """注册数据处理活动 (Register data processing activity)

        根据 GDPR 第30条，数据控制者必须记录所有数据处理活动。

        Args:
            activity: 活动描述
            categories: 涉及的数据分类
            purpose: 处理目的
            legal_basis: 法律依据 (consent, contract, legal_obligation, vital_interest,
                        public_task, legitimate_interest)
            retention_days: 数据保留天数
            data_controller: 数据控制者

        Returns:
            str: 活动注册 ID
        """
        if not activity.strip():
            raise ValueError("活动描述不能为空")
        if not categories:
            raise ValueError("数据分类不能为空")

        valid_bases = {
            "consent", "contract", "legal_obligation", "vital_interest",
            "public_task", "legitimate_interest",
        }
        if legal_basis not in valid_bases:
            raise ValueError(f"无效的法律依据: {legal_basis}，有效值: {valid_bases}")

        activity_id = f"DPA-{secrets.token_hex(8)}"
        retention = retention_days or self._default_retention_days

        record = {
            "activity_id": activity_id,
            "activity": activity.strip(),
            "categories": [c.value for c in categories],
            "purpose": purpose,
            "legal_basis": legal_basis,
            "retention_days": retention,
            "data_controller": data_controller or self._organization,
            "registered_at": datetime.now(timezone.utc).isoformat(),
            "jurisdictions": [j.value for j in self._jurisdictions],
        }

        with self._lock:
            self._processing_activities.append(record)
            self._retention_policies[activity_id] = retention

        self._log_audit("register_processing", record)
        logger.info("数据处理活动已注册: id=%s, activity='%s'", activity_id, activity)
        return activity_id

    # ------------------------------------------------------------------
    # GDPR 合规检查 (GDPR Compliance Check)
    # ------------------------------------------------------------------

    def run_gdpr_check(self) -> Dict[str, Any]:
        """运行 GDPR 合规检查 (Run GDPR compliance check)

        检查以下方面：
        1. 数据处理活动是否已注册
        2. 是否有有效的法律依据
        3. 数据保留策略是否合理
        4. DPIA 是否已为高风险活动完成
        5. 数据保护官是否已指定
        6. 用户权利请求是否及时处理

        Returns:
            Dict: 检查结果，包含各检查项的通过/失败状态
        """
        results: Dict[str, Any] = {
            "framework": "GDPR",
            "organization": self._organization,
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "checks": [],
            "overall_pass": True,
        }

        # 检查 1: 数据处理活动注册
        check1 = {
            "name": "数据处理活动注册 (GDPR Art. 30)",
            "passed": len(self._processing_activities) > 0,
            "details": f"已注册 {len(self._processing_activities)} 个数据处理活动",
        }
        results["checks"].append(check1)

        # 检查 2: 法律依据
        activities_without_basis = [
            a for a in self._processing_activities
            if not a.get("legal_basis")
        ]
        check2 = {
            "name": "法律依据 (GDPR Art. 6)",
            "passed": len(activities_without_basis) == 0,
            "details": f"{len(activities_without_basis)} 个活动缺少法律依据",
        }
        results["checks"].append(check2)

        # 检查 3: 数据保留策略
        activities_without_retention = [
            a for a in self._processing_activities
            if a.get("retention_days", 0) <= 0
        ]
        check3 = {
            "name": "数据保留策略 (GDPR Art. 5(1)(e))",
            "passed": len(activities_without_retention) == 0,
            "details": f"{len(activities_without_retention)} 个活动缺少保留策略",
        }
        results["checks"].append(check3)

        # 检查 4: DPIA
        high_risk_activities = [
            a for a in self._processing_activities
            if any(c in a.get("categories", []) for c in ["sensitive", "personal"])
        ]
        dpia_completed = sum(
            1 for a in high_risk_activities
            if any(r.processing_activity == a["activity"] for r in self._dpia_records.values())
        )
        check4 = {
            "name": "数据保护影响评估 (GDPR Art. 35)",
            "passed": dpia_completed >= len(high_risk_activities),
            "details": (
                f"高风险活动: {len(high_risk_activities)}, "
                f"已完成 DPIA: {dpia_completed}"
            ),
        }
        results["checks"].append(check4)

        # 检查 5: 数据保护官
        check5 = {
            "name": "数据保护官指定 (GDPR Art. 37)",
            "passed": bool(self._dpo_email),
            "details": f"DPO 邮箱: {self._dpo_email or '未指定'}",
        }
        results["checks"].append(check5)

        # 检查 6: 用户权利请求处理
        pending_requests = [
            r for r in self._right_requests.values()
            if r.status == "pending"
        ]
        overdue_requests = [
            r for r in pending_requests
            if (datetime.now(timezone.utc) - r.requested_at) > timedelta(days=30)
        ]
        check6 = {
            "name": "用户权利请求处理 (GDPR Art. 15-22)",
            "passed": len(overdue_requests) == 0,
            "details": (
                f"待处理: {len(pending_requests)}, "
                f"逾期: {len(overdue_requests)}"
            ),
        }
        results["checks"].append(check6)

        # 计算总体结果
        results["overall_pass"] = all(c["passed"] for c in results["checks"])
        results["pass_rate"] = (
            sum(1 for c in results["checks"] if c["passed"]) / len(results["checks"])
            if results["checks"] else 1.0
        )

        self._log_audit("gdpr_check", {"overall_pass": results["overall_pass"]})
        logger.info(
            "GDPR 合规检查完成: pass=%s, rate=%.1f%%",
            results["overall_pass"], results["pass_rate"] * 100,
        )
        return results

    # ------------------------------------------------------------------
    # 数据保护影响评估 (DPIA)
    # ------------------------------------------------------------------

    def create_dpia(
        self,
        processing_activity: str,
        data_categories: List[DataCategory],
        risk_level: str = "medium",
        mitigation_measures: Optional[List[str]] = None,
        reviewer: str = "",
    ) -> str:
        """创建数据保护影响评估 (Create DPIA)

        GDPR 第35条要求对可能对自然人权利和自由造成高风险的
        数据处理活动进行影响评估。

        Args:
            processing_activity: 数据处理活动描述
            data_categories: 涉及的数据分类
            risk_level: 风险等级 (low, medium, high, critical)
            mitigation_measures: 缓解措施列表
            reviewer: 评估人

        Returns:
            str: DPIA 记录 ID
        """
        assessment_id = f"DPIA-{secrets.token_hex(8)}"

        record = DPIARecord(
            assessment_id=assessment_id,
            processing_activity=processing_activity,
            data_categories=data_categories,
            risk_level=risk_level,
            mitigation_measures=mitigation_measures or [],
            reviewer=reviewer,
        )

        with self._lock:
            self._dpia_records[assessment_id] = record

        self._log_audit("create_dpia", {"assessment_id": assessment_id})
        logger.info("DPIA 已创建: id=%s, activity='%s', risk=%s",
                     assessment_id, processing_activity, risk_level)
        return assessment_id

    def approve_dpia(self, assessment_id: str, approved: bool) -> bool:
        """审批 DPIA (Approve/reject DPIA)

        Args:
            assessment_id: DPIA 记录 ID
            approved: 是否批准

        Returns:
            bool: 是否成功更新
        """
        with self._lock:
            record = self._dpia_records.get(assessment_id)
            if record is None:
                return False
            record.dpo_approval = approved
            self._log_audit("approve_dpia", {
                "assessment_id": assessment_id,
                "approved": approved,
            })
            return True

    # ------------------------------------------------------------------
    # 数据保留策略 (Data Retention Policy)
    # ------------------------------------------------------------------

    def set_retention_policy(
        self,
        activity_id: str,
        retention_days: int,
    ) -> bool:
        """设置数据保留策略 (Set data retention policy)

        Args:
            activity_id: 数据处理活动 ID
            retention_days: 保留天数

        Returns:
            bool: 是否成功设置
        """
        if retention_days <= 0:
            raise ValueError(f"retention_days 必须为正数，当前值: {retention_days}")

        with self._lock:
            if activity_id not in self._retention_policies:
                logger.warning("活动 ID 不存在: %s", activity_id)
                return False
            self._retention_policies[activity_id] = retention_days
            self._log_audit("set_retention", {
                "activity_id": activity_id,
                "retention_days": retention_days,
            })
            return True

    def check_retention_compliance(self) -> List[Dict[str, Any]]:
        """检查数据保留合规性 (Check data retention compliance)

        识别超过保留期限的数据处理活动。

        Returns:
            List[Dict]: 超期活动列表
        """
        overdue: List[Dict[str, Any]] = []
        now = datetime.now(timezone.utc)

        for activity in self._processing_activities:
            activity_id = activity["activity_id"]
            retention_days = self._retention_policies.get(activity_id, self._default_retention_days)
            registered_at = datetime.fromisoformat(activity["registered_at"])
            expiry_date = registered_at + timedelta(days=retention_days)

            if now > expiry_date:
                overdue.append({
                    "activity_id": activity_id,
                    "activity": activity["activity"],
                    "retention_days": retention_days,
                    "expiry_date": expiry_date.isoformat(),
                    "days_overdue": (now - expiry_date).days,
                })

        return overdue

    # ------------------------------------------------------------------
    # 用户权利管理 (User Rights Management)
    # ------------------------------------------------------------------

    def submit_right_request(
        self,
        user_id: str,
        right_type: UserRightType,
        details: str = "",
    ) -> str:
        """提交用户权利请求 (Submit user right request)

        处理 GDPR 规定的用户权利请求，包括：
        - 访问权 (Art. 15): 用户有权访问其个人数据
        - 更正权 (Art. 16): 用户有权更正不准确的个人数据
        - 删除权 (Art. 17): 用户有权要求删除其个人数据
        - 限制处理权 (Art. 18): 用户有权限制数据处理
        - 数据移植权 (Art. 20): 用户有权以结构化格式接收其数据
        - 反对权 (Art. 21): 用户有权反对数据处理

        Args:
            user_id: 用户标识
            right_type: 权利类型
            details: 请求详情

        Returns:
            str: 请求 ID
        """
        request_id = f"REQ-{secrets.token_hex(8)}"

        request = UserRightRequest(
            request_id=request_id,
            user_id=user_id,
            right_type=right_type,
            notes=details,
        )

        with self._lock:
            self._right_requests[request_id] = request

        self._log_audit("submit_right_request", {
            "request_id": request_id,
            "user_id": user_id,
            "right_type": right_type.value,
        })
        logger.info(
            "用户权利请求已提交: id=%s, user=%s, right=%s",
            request_id, user_id, right_type.value,
        )
        return request_id

    def process_right_request(
        self,
        request_id: str,
        action: str,
        response_data: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """处理用户权利请求 (Process user right request)

        Args:
            request_id: 请求 ID
            action: 处理动作 ("approve", "reject", "complete")
            response_data: 响应数据

        Returns:
            bool: 是否成功处理
        """
        if action not in ("approve", "reject", "complete"):
            raise ValueError(f"无效的 action: {action}")

        with self._lock:
            request = self._right_requests.get(request_id)
            if request is None:
                logger.error("请求不存在: %s", request_id)
                return False

            if action == "approve":
                request.status = "processing"
            elif action == "complete":
                request.status = "completed"
                request.completed_at = datetime.now(timezone.utc)
                request.response_data = response_data
            elif action == "reject":
                request.status = "rejected"
                request.completed_at = datetime.now(timezone.utc)

        self._log_audit("process_right_request", {
            "request_id": request_id,
            "action": action,
        })
        return True

    def get_user_data(self, user_id: str) -> Dict[str, Any]:
        """获取用户数据（用于访问权请求）(Get user data for access right request)

        Args:
            user_id: 用户标识

        Returns:
            Dict: 用户持有的所有数据
        """
        # 收集与用户相关的所有数据
        user_data = {
            "user_id": user_id,
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
            "data_categories": {},
            "consent_records": [],
            "right_requests": [],
        }

        # 查找同意记录
        with self._lock:
            for consent_id, consent in self._consent_records.items():
                if consent.get("user_id") == user_id:
                    user_data["consent_records"].append(consent)

            # 查找权利请求
            for req_id, req in self._right_requests.items():
                if req.user_id == user_id:
                    user_data["right_requests"].append({
                        "request_id": req.request_id,
                        "right_type": req.right_type.value,
                        "status": req.status,
                        "requested_at": req.requested_at.isoformat(),
                    })

        return user_data

    # ------------------------------------------------------------------
    # 多司法管辖区支持 (Multi-Jurisdiction Support)
    # ------------------------------------------------------------------

    def get_jurisdiction_requirements(
        self, jurisdiction: Jurisdiction
    ) -> Dict[str, Any]:
        """获取司法管辖区合规要求 (Get jurisdiction compliance requirements)

        Args:
            jurisdiction: 司法管辖区

        Returns:
            Dict: 该司法管辖区的合规要求
        """
        requirements = {
            Jurisdiction.EU: {
                "name": "欧盟 GDPR",
                "key_articles": [
                    "Art. 5: 数据处理原则",
                    "Art. 6: 处理合法性",
                    "Art. 13-14: 信息透明度",
                    "Art. 15-22: 数据主体权利",
                    "Art. 25: 隐私设计",
                    "Art. 30: 处理活动记录",
                    "Art. 32: 安全性",
                    "Art. 33-34: 违约通知",
                    "Art. 35: DPIA",
                ],
                "max_fine": "2000万欧元或全球营业额的4%",
                "dpo_required": True,
                "breach_notification_hours": 72,
                "data_retention": "必要且不过度",
            },
            Jurisdiction.US_CA: {
                "name": "加州 CCPA",
                "key_provisions": [
                    "知情权 (Right to Know)",
                    "删除权 (Right to Delete)",
                    "拒绝出售权 (Right to Opt-Out)",
                    "非歧视条款",
                    "私人诉讼权",
                ],
                "max_fine": "每次违规最高$7,500",
                "dpo_required": False,
                "breach_notification_days": 45,
                "data_retention": "消费者要求时必须删除",
            },
            Jurisdiction.CN: {
                "name": "中国 PIPL",
                "key_provisions": [
                    "告知同意原则",
                    "最小必要原则",
                    "跨境传输限制",
                    "个人信息主体权利",
                    "敏感个人信息特殊保护",
                ],
                "max_fine": "5000万元人民币或上一年度营业额的5%",
                "dpo_required": True,
                "breach_notification_hours": 72,
                "data_retention": "必要且不过度",
            },
            Jurisdiction.UK: {
                "name": "英国 UK GDPR",
                "key_articles": [
                    "与 EU GDPR 基本一致",
                    "补充: 适度的国内修改",
                ],
                "max_fine": "1750万英镑或全球营业额的4%",
                "dpo_required": True,
                "breach_notification_hours": 72,
                "data_retention": "必要且不过度",
            },
            Jurisdiction.US: {
                "name": "美国联邦 (一般)",
                "key_provisions": [
                    "无统一联邦隐私法",
                    "行业特定法规 (HIPAA, COPPA, GLBA等)",
                    "FTC Section 5 (不公平/欺骗行为)",
                ],
                "max_fine": "因法规而异",
                "dpo_required": False,
                "breach_notification_days": "因州而异",
                "data_retention": "因行业而异",
            },
        }

        return requirements.get(jurisdiction, {
            "name": jurisdiction.value,
            "key_provisions": ["请咨询当地法律顾问"],
            "max_fine": "未知",
            "dpo_required": False,
            "breach_notification_hours": None,
            "data_retention": "请咨询当地法律顾问",
        })

    # ------------------------------------------------------------------
    # 审计日志 (Audit Log)
    # ------------------------------------------------------------------

    def _log_audit(self, action: str, details: Dict[str, Any]) -> None:
        """记录审计日志 (Log audit entry)"""
        self._audit_log.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": action,
            "details": details,
            "organization": self._organization,
        })

    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取审计日志 (Get audit log)

        Args:
            limit: 最大返回条数

        Returns:
            List[Dict]: 审计日志列表
        """
        with self._lock:
            return self._audit_log[-limit:]


# ============================================================================
# 透明度日志 (Transparency Log)
# ============================================================================


class TransparencyLog:
    """透明度日志 (Transparency Log)

    基于 Merkle 树的不可篡改操作日志系统。所有系统操作记录为
    Merkle 树的叶子节点，任何对历史记录的修改都会导致根哈希变化，
    从而被检测到。

    功能：
    - 不可篡改的操作日志（Merkle 树）
    - 定期发布透明度报告
    - 公开审计接口
    - 数据处理记录

    安全保证：
    - 基于 SHA-256 的哈希链确保日志完整性
    - Merkle 树证明支持高效的完整性验证
    - 日志一旦写入不可修改或删除

    Example:
        >>> tlog = TransparencyLog(system_name="IP4Move Aegis")
        >>> tlog.record_operation(
        ...     operation="node_join",
        ...     operator="node_001",
        ...     details={"ip": "10.0.0.1", "role": "mix"},
        ... )
        >>> root = tlog.get_merkle_root()
        >>> proof = tlog.get_proof(0)
        >>> is_valid = tlog.verify_proof(0, proof, root)
    """

    def __init__(
        self,
        system_name: str = "IP4Move Aegis",
        max_entries: int = 100000,
    ) -> None:
        """初始化透明度日志 (Initialize transparency log)

        Args:
            system_name: 系统名称
            max_entries: 最大日志条目数
        """
        self._system_name = system_name
        self._max_entries = max_entries

        # 日志条目（叶子节点数据）
        self._entries: List[Dict[str, Any]] = []

        # Merkle 树
        self._merkle_root: Optional[str] = None
        self._merkle_tree: Optional[MerkleNode] = None

        # 透明度报告历史
        self._reports: List[Dict[str, Any]] = []

        # 线程锁
        self._lock = threading.RLock()

        logger.info("透明度日志初始化完成: system='%s'", system_name)

    # ------------------------------------------------------------------
    # 哈希和 Merkle 树 (Hashing and Merkle Tree)
    # ------------------------------------------------------------------

    @staticmethod
    def _hash(data: str) -> str:
        """计算 SHA-256 哈希 (Compute SHA-256 hash)

        Args:
            data: 输入数据字符串

        Returns:
            str: 十六进制哈希值
        """
        return hashlib.sha256(data.encode("utf-8")).hexdigest()

    def _build_merkle_tree(self) -> MerkleNode:
        """构建 Merkle 树 (Build Merkle tree)

        将所有日志条目作为叶子节点，自底向上构建 Merkle 树。
        如果叶子节点数为奇数，则复制最后一个节点。

        Returns:
            MerkleNode: Merkle 树根节点
        """
        if not self._entries:
            # 空树的根哈希
            return MerkleNode(hash_value=self._hash("EMPTY_TREE"))

        # 创建叶子节点
        leaves: List[MerkleNode] = []
        for idx, entry in enumerate(self._entries):
            entry_str = json.dumps(entry, sort_keys=True, ensure_ascii=False)
            leaf_hash = self._hash(f"leaf:{idx}:{entry_str}")
            leaves.append(MerkleNode(
                hash_value=leaf_hash,
                data=entry_str,
                index=idx,
            ))

        # 自底向上构建树
        nodes = leaves
        level = 0
        while len(nodes) > 1:
            next_level: List[MerkleNode] = []
            # 如果节点数为奇数，复制最后一个
            if len(nodes) % 2 == 1:
                nodes.append(nodes[-1])

            for i in range(0, len(nodes), 2):
                combined = self._hash(f"{nodes[i].hash_value}:{nodes[i+1].hash_value}")
                parent = MerkleNode(
                    hash_value=combined,
                    left=nodes[i],
                    right=nodes[i + 1],
                )
                next_level.append(parent)

            nodes = next_level
            level += 1

        self._merkle_tree = nodes[0]
        self._merkle_root = nodes[0].hash_value
        return nodes[0]

    def get_merkle_root(self) -> str:
        """获取 Merkle 树根哈希 (Get Merkle tree root hash)

        根哈希是整个日志完整性的摘要。任何日志条目的修改
        都会导致根哈希变化。

        Returns:
            str: Merkle 根哈希值
        """
        with self._lock:
            tree = self._build_merkle_tree()
            return tree.hash_value

    def get_proof(self, entry_index: int) -> List[str]:
        """获取 Merkle 证明 (Get Merkle proof)

        返回从指定叶子节点到根节点的哈希路径，用于验证
        该条目确实存在于日志中且未被篡改。

        Args:
            entry_index: 日志条目索引

        Returns:
            List[str]: 哈希路径（兄弟节点哈希列表）

        Raises:
            IndexError: 索引超出范围时抛出
        """
        with self._lock:
            if entry_index < 0 or entry_index >= len(self._entries):
                raise IndexError(
                    f"索引 {entry_index} 超出范围 [0, {len(self._entries)})"
                )

            tree = self._build_merkle_tree()
            proof: List[str] = []

            # 收集从叶子到根的路径
            def _collect_proof(
                node: Optional[MerkleNode],
                target_index: int,
                path: List[str],
            ) -> bool:
                """递归收集证明路径 (Recursively collect proof path)"""
                if node is None:
                    return False

                # 叶子节点
                if node.left is None and node.right is None:
                    return node.index == target_index

                # 检查左子树
                if _collect_proof(node.left, target_index, path):
                    if node.right is not None:
                        path.append(node.right.hash_value)
                    return True

                # 检查右子树
                if _collect_proof(node.right, target_index, path):
                    if node.left is not None:
                        path.append(node.left.hash_value)
                    return True

                return False

            _collect_proof(tree, entry_index, proof)
            return proof

    def verify_proof(
        self,
        entry_index: int,
        proof: List[str],
        expected_root: str,
    ) -> bool:
        """验证 Merkle 证明 (Verify Merkle proof)

        使用证明路径和条目数据重新计算根哈希，与期望的根哈希比较。

        Args:
            entry_index: 日志条目索引
            proof: Merkle 证明路径
            expected_root: 期望的 Merkle 根哈希

        Returns:
            bool: 证明是否有效
        """
        if entry_index < 0 or entry_index >= len(self._entries):
            return False

        # 计算叶子哈希
        entry = self._entries[entry_index]
        entry_str = json.dumps(entry, sort_keys=True, ensure_ascii=False)
        current_hash = self._hash(f"leaf:{entry_index}:{entry_str}")

        # 沿证明路径向上计算
        idx = entry_index
        for sibling_hash in proof:
            if idx % 2 == 0:
                # 当前是左子节点
                current_hash = self._hash(f"{current_hash}:{sibling_hash}")
            else:
                # 当前是右子节点
                current_hash = self._hash(f"{sibling_hash}:{current_hash}")
            idx //= 2

        return current_hash == expected_root

    # ------------------------------------------------------------------
    # 日志记录 (Log Recording)
    # ------------------------------------------------------------------

    def record_operation(
        self,
        operation: str,
        operator: str = "",
        details: Optional[Dict[str, Any]] = None,
        data_categories: Optional[List[str]] = None,
    ) -> int:
        """记录操作到透明度日志 (Record operation to transparency log)

        Args:
            operation: 操作类型
            operator: 操作者标识
            details: 操作详情
            data_categories: 涉及的数据分类

        Returns:
            int: 日志条目索引
        """
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "operation": operation,
            "operator": operator,
            "details": details or {},
            "data_categories": data_categories or [],
            "system": self._system_name,
            "entry_index": len(self._entries),
        }

        with self._lock:
            # 检查容量
            if len(self._entries) >= self._max_entries:
                logger.warning(
                    "透明度日志已达到最大容量: %d", self._max_entries
                )

            self._entries.append(entry)
            index = len(self._entries) - 1

            # 重建 Merkle 树
            self._build_merkle_tree()

        logger.debug(
            "操作已记录: index=%d, operation='%s', operator='%s'",
            index, operation, operator,
        )
        return index

    def get_entry(self, index: int) -> Optional[Dict[str, Any]]:
        """获取日志条目 (Get log entry)

        Args:
            index: 条目索引

        Returns:
            Optional[Dict]: 日志条目，不存在返回 None
        """
        if 0 <= index < len(self._entries):
            return self._entries[index].copy()
        return None

    @property
    def entry_count(self) -> int:
        """获取日志条目总数 (Get total entry count)"""
        return len(self._entries)

    # ------------------------------------------------------------------
    # 透明度报告 (Transparency Reports)
    # ------------------------------------------------------------------

    def generate_transparency_report(
        self,
        period_days: int = 30,
    ) -> Dict[str, Any]:
        """生成透明度报告 (Generate transparency report)

        汇总指定时间段内的操作日志，生成公开的透明度报告。

        Args:
            period_days: 报告周期（天）

        Returns:
            Dict: 透明度报告
        """
        with self._lock:
            cutoff = datetime.now(timezone.utc) - timedelta(days=period_days)

            # 筛选周期内的条目
            period_entries = [
                e for e in self._entries
                if datetime.fromisoformat(e["timestamp"]) >= cutoff
            ]

            # 按操作类型统计
            operation_counts: Dict[str, int] = {}
            operator_counts: Dict[str, int] = {}
            category_counts: Dict[str, int] = {}

            for entry in period_entries:
                op = entry["operation"]
                operation_counts[op] = operation_counts.get(op, 0) + 1

                operator = entry.get("operator", "system")
                operator_counts[operator] = operator_counts.get(operator, 0) + 1

                for cat in entry.get("data_categories", []):
                    category_counts[cat] = category_counts.get(cat, 0) + 1

            report = {
                "system": self._system_name,
                "report_period_days": period_days,
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "merkle_root": self._merkle_root,
                "total_entries": len(period_entries),
                "operation_summary": operation_counts,
                "operator_summary": operator_counts,
                "data_category_summary": category_counts,
                "integrity_verification": {
                    "merkle_root": self._merkle_root,
                    "total_entries_all_time": len(self._entries),
                },
            }

            self._reports.append(report)
            logger.info(
                "透明度报告已生成: 周期=%d天, 条目=%d, root=%s",
                period_days, len(period_entries),
                self._merkle_root[:16] if self._merkle_root else "N/A",
            )
            return report

    def get_transparency_reports(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取历史透明度报告 (Get historical transparency reports)

        Args:
            limit: 最大返回数量

        Returns:
            List[Dict]: 透明度报告列表
        """
        with self._lock:
            return self._reports[-limit:]

    # ------------------------------------------------------------------
    # 公开审计接口 (Public Audit Interface)
    # ------------------------------------------------------------------

    def public_audit(
        self,
        entry_index: int,
    ) -> Dict[str, Any]:
        """公开审计接口 (Public audit interface)

        允许外部审计者验证指定日志条目的完整性。
        返回条目内容、Merkle 证明和验证结果。

        Args:
            entry_index: 要审计的日志条目索引

        Returns:
            Dict: 审计结果
        """
        with self._lock:
            entry = self.get_entry(entry_index)
            if entry is None:
                return {
                    "valid": False,
                    "error": f"条目索引 {entry_index} 不存在",
                }

            root = self.get_merkle_root()
            proof = self.get_proof(entry_index)
            is_valid = self.verify_proof(entry_index, proof, root)

            return {
                "valid": is_valid,
                "entry_index": entry_index,
                "entry": entry,
                "merkle_root": root,
                "merkle_proof": proof,
                "proof_length": len(proof),
                "total_entries": len(self._entries),
            }


# ============================================================================
# 模块自测试 (Module Self-Test)
# ============================================================================


def _run_self_test() -> None:
    """运行模块自测试 (Run module self-test)

    验证所有核心类的基本功能是否正常工作。
    """
    print("=" * 60)
    print("合规与透明度模块自测试 (Compliance Module Self-Test)")
    print("=" * 60)

    # 测试 1: 安全报告生成器
    print("\n[测试 1] 安全报告生成器")
    generator = SecurityReportGenerator(
        report_title="IP4Move Aegis 安全报告",
        organization="IP4Move Aegis",
    )
    generator.add_metric(SecurityMetric(
        name="攻击检测率", value=99.7, unit="%",
        trend="up", description="过去30天的攻击检测率",
    ))
    generator.add_metric(SecurityMetric(
        name="平均响应时间", value=45.2, unit="ms",
        trend="down", description="API 平均响应时间",
    ))
    generator.update_vulnerability_stats(VulnerabilitySeverity.CRITICAL, 2)
    generator.update_vulnerability_stats(VulnerabilitySeverity.HIGH, 5)
    generator.update_vulnerability_stats(VulnerabilitySeverity.MEDIUM, 12)
    generator.update_compliance_status("GDPR 数据处理注册", True)
    generator.update_compliance_status("加密传输", True)
    generator.update_compliance_status("访问日志审计", False)

    html_report = generator.generate_report(ReportFormat.HTML)
    text_report = generator.generate_report(ReportFormat.TEXT)
    json_report = generator.generate_report(ReportFormat.JSON)
    print(f"  HTML 报告大小: {len(html_report)} bytes")
    print(f"  TEXT 报告大小: {len(text_report)} bytes")
    print(f"  JSON 报告大小: {len(json_report)} bytes")

    # 测试 2: 漏洞赏金管理器
    print("\n[测试 2] 漏洞赏金管理器")
    bounty_mgr = BugBountyManager()
    report_id = bounty_mgr.submit_vulnerability(
        title="Reflected XSS in login page",
        description="The login page reflects user input without sanitization...",
        reporter_id="researcher_001",
        severity=VulnerabilitySeverity.HIGH,
        affected_components=["web_auth", "login_api"],
    )
    print(f"  漏洞报告 ID: {report_id}")
    bounty_mgr.update_status(report_id, VulnerabilityStatus.CONFIRMED, reviewer="security_team")
    report = bounty_mgr.get_report(report_id)
    print(f"  状态: {report['status']}, 赏金: ${report['bounty_amount']:.2f}")

    bounty_mgr.update_researcher_reputation("researcher_001", 10.0)
    stats = bounty_mgr.get_researcher_stats("researcher_001")
    print(f"  研究人员信誉: {stats['reputation']:.1f}")

    dashboard = bounty_mgr.get_dashboard_stats()
    print(f"  总报告数: {dashboard['total_reports']}, 总赏金: ${dashboard['total_bounty_paid']:.2f}")

    # 测试 3: 合规性设计框架
    print("\n[测试 3] 合规性设计框架")
    framework = ComplianceFramework(
        organization="IP4Move Aegis",
        jurisdictions=[Jurisdiction.EU, Jurisdiction.US_CA, Jurisdiction.CN],
        dpo_email="dpo@ip4move.example",
    )
    framework.register_data_processing(
        activity="用户流量路由",
        categories=[DataCategory.USAGE, DataCategory.TECHNICAL],
        purpose="提供匿名网络路由服务",
        legal_basis="consent",
        retention_days=90,
    )
    framework.register_data_processing(
        activity="节点信誉评估",
        categories=[DataCategory.ANALYTICS],
        purpose="维护网络安全",
        legal_basis="legitimate_interest",
        retention_days=180,
    )

    gdpr_results = framework.run_gdpr_check()
    print(f"  GDPR 合规: {'通过' if gdpr_results['overall_pass'] else '未通过'}")
    for check in gdpr_results["checks"]:
        status = "PASS" if check["passed"] else "FAIL"
        print(f"    [{status}] {check['name']}")

    # DPIA 测试
    dpia_id = framework.create_dpia(
        processing_activity="用户流量路由",
        data_categories=[DataCategory.USAGE, DataCategory.TECHNICAL],
        risk_level="medium",
        mitigation_measures=["差分隐私保护", "数据最小化"],
    )
    framework.approve_dpia(dpia_id, approved=True)
    print(f"  DPIA 已创建并审批: {dpia_id}")

    # 用户权利请求测试
    req_id = framework.submit_right_request(
        user_id="user_001",
        right_type=UserRightType.RIGHT_TO_ERASURE,
        details="请删除我的所有数据",
    )
    framework.process_right_request(req_id, "approve")
    framework.process_right_request(req_id, "complete", {"status": "data_deleted"})
    print(f"  用户权利请求: {req_id}")

    # 司法管辖区测试
    requirements = framework.get_jurisdiction_requirements(Jurisdiction.CN)
    print(f"  中国 PIPL 最高罚款: {requirements['max_fine']}")

    # 测试 4: 透明度日志
    print("\n[测试 4] 透明度日志")
    tlog = TransparencyLog(system_name="IP4Move Aegis")
    for i in range(10):
        tlog.record_operation(
            operation=f"test_operation_{i}",
            operator=f"node_{i:03d}",
            details={"action": "test", "value": i},
        )

    root = tlog.get_merkle_root()
    print(f"  Merkle 根哈希: {root[:32]}...")
    print(f"  日志条目数: {tlog.entry_count}")

    # 验证 Merkle 证明
    proof = tlog.get_proof(5)
    is_valid = tlog.verify_proof(5, proof, root)
    print(f"  条目 5 的 Merkle 证明验证: {'有效' if is_valid else '无效'}")

    # 审计接口测试
    audit_result = tlog.public_audit(3)
    print(f"  公开审计结果: {'通过' if audit_result['valid'] else '失败'}")

    # 透明度报告
    report = tlog.generate_transparency_report(period_days=30)
    print(f"  透明度报告: {report['total_entries']} 条操作记录")

    print("\n" + "=" * 60)
    print("所有自测试通过!")
    print("=" * 60)


if __name__ == "__main__":
    _run_self_test()
