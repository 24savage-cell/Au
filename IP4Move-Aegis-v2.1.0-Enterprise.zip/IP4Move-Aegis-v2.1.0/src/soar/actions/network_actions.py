"""
网络操作模块

提供网络相关的响应操作，包括ACL更新、DNS黑名单和端口关闭。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

# 配置日志
logger = logging.getLogger(__name__)


class NetworkActionType(Enum):
    """网络操作类型"""
    UPDATE_ACL = "update_acl"
    ADD_DNS_BLACKLIST = "add_dns_blacklist"
    REMOVE_DNS_BLACKLIST = "remove_dns_blacklist"
    CLOSE_PORT = "close_port"
    OPEN_PORT = "open_port"
    BLOCK_DOMAIN = "block_domain"
    UNBLOCK_DOMAIN = "unblock_domain"


@dataclass
class ACLRule:
    """ACL规则"""
    action: str  # allow, deny
    protocol: str  # tcp, udp, icmp, any
    source: str
    destination: str
    port: Optional[str] = None
    priority: int = 100
    description: str = ""


class NetworkActions:
    """
    网络操作类

    提供网络相关的响应操作能力。

    Example:
        >>> actions = NetworkActions()
        >>>
        >>> # 更新ACL
        >>> result = await actions.update_acl(
        ...     device_id="firewall-01",
        ...     rule=ACLRule(
        ...         action="deny",
        ...         protocol="tcp",
        ...         source="192.168.1.100",
        ...         destination="any",
        ...         port="443",
        ...         description="Block malicious IP"
        ...     )
        ... )
    """

    def __init__(self):
        """初始化网络操作"""
        self._dns_blacklist: List[str] = []
        self._blocked_domains: List[str] = []
        self._closed_ports: Dict[str, List[int]] = {}  # device_id -> ports

    async def update_acl(
        self,
        device_id: str,
        rule: ACLRule,
    ) -> Dict[str, Any]:
        """
        更新ACL规则

        Args:
            device_id: 网络设备ID
            rule: ACL规则

        Returns:
            操作结果
        """
        logger.info(f"Updating ACL on {device_id}: {rule}")

        # 实际实现需要调用网络设备API
        # 这里提供模拟实现

        return {
            "success": True,
            "device_id": device_id,
            "action": "acl_updated",
            "rule": {
                "action": rule.action,
                "protocol": rule.protocol,
                "source": rule.source,
                "destination": rule.destination,
                "port": rule.port,
                "priority": rule.priority,
            },
            "timestamp": datetime.utcnow().isoformat(),
        }

    async def remove_acl(
        self,
        device_id: str,
        rule_id: str,
    ) -> Dict[str, Any]:
        """
        移除ACL规则

        Args:
            device_id: 网络设备ID
            rule_id: 规则ID

        Returns:
            操作结果
        """
        logger.info(f"Removing ACL rule {rule_id} from {device_id}")

        return {
            "success": True,
            "device_id": device_id,
            "rule_id": rule_id,
            "action": "acl_removed",
        }

    async def add_dns_blacklist(
        self,
        domain: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        添加域名到DNS黑名单

        Args:
            domain: 域名
            reason: 原因

        Returns:
            操作结果
        """
        if domain in self._dns_blacklist:
            return {
                "success": False,
                "error": f"Domain {domain} is already blacklisted",
            }

        self._dns_blacklist.append(domain)
        logger.info(f"Domain added to DNS blacklist: {domain}")

        return {
            "success": True,
            "domain": domain,
            "action": "dns_blacklist_added",
            "reason": reason,
        }

    async def remove_dns_blacklist(
        self,
        domain: str,
    ) -> Dict[str, Any]:
        """
        从DNS黑名单移除域名

        Args:
            domain: 域名

        Returns:
            操作结果
        """
        if domain not in self._dns_blacklist:
            return {
                "success": False,
                "error": f"Domain {domain} is not in blacklist",
            }

        self._dns_blacklist.remove(domain)
        logger.info(f"Domain removed from DNS blacklist: {domain}")

        return {
            "success": True,
            "domain": domain,
            "action": "dns_blacklist_removed",
        }

    async def block_domain(
        self,
        domain: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        阻断域名

        Args:
            domain: 域名
            reason: 原因

        Returns:
            操作结果
        """
        if domain in self._blocked_domains:
            return {
                "success": False,
                "error": f"Domain {domain} is already blocked",
            }

        self._blocked_domains.append(domain)
        logger.info(f"Domain blocked: {domain}")

        return {
            "success": True,
            "domain": domain,
            "action": "domain_blocked",
            "reason": reason,
        }

    async def unblock_domain(
        self,
        domain: str,
    ) -> Dict[str, Any]:
        """
        解除域名阻断

        Args:
            domain: 域名

        Returns:
            操作结果
        """
        if domain not in self._blocked_domains:
            return {
                "success": False,
                "error": f"Domain {domain} is not blocked",
            }

        self._blocked_domains.remove(domain)
        logger.info(f"Domain unblocked: {domain}")

        return {
            "success": True,
            "domain": domain,
            "action": "domain_unblocked",
        }

    async def close_port(
        self,
        device_id: str,
        port: int,
        protocol: str = "tcp",
    ) -> Dict[str, Any]:
        """
        关闭端口

        Args:
            device_id: 设备ID
            port: 端口号
            protocol: 协议

        Returns:
            操作结果
        """
        if device_id not in self._closed_ports:
            self._closed_ports[device_id] = []

        if port in self._closed_ports[device_id]:
            return {
                "success": False,
                "error": f"Port {port} is already closed on {device_id}",
            }

        self._closed_ports[device_id].append(port)
        logger.info(f"Port {port}/{protocol} closed on {device_id}")

        return {
            "success": True,
            "device_id": device_id,
            "port": port,
            "protocol": protocol,
            "action": "port_closed",
        }

    async def open_port(
        self,
        device_id: str,
        port: int,
        protocol: str = "tcp",
    ) -> Dict[str, Any]:
        """
        开放端口

        Args:
            device_id: 设备ID
            port: 端口号
            protocol: 协议

        Returns:
            操作结果
        """
        if device_id not in self._closed_ports:
            return {
                "success": False,
                "error": f"No ports are closed on {device_id}",
            }

        if port not in self._closed_ports[device_id]:
            return {
                "success": False,
                "error": f"Port {port} is not closed on {device_id}",
            }

        self._closed_ports[device_id].remove(port)
        logger.info(f"Port {port}/{protocol} opened on {device_id}")

        return {
            "success": True,
            "device_id": device_id,
            "port": port,
            "protocol": protocol,
            "action": "port_opened",
        }

    def get_dns_blacklist(self) -> List[str]:
        """
        获取DNS黑名单

        Returns:
            黑名单域名列表
        """
        return self._dns_blacklist.copy()

    def get_blocked_domains(self) -> List[str]:
        """
        获取被阻断的域名

        Returns:
            被阻断域名列表
        """
        return self._blocked_domains.copy()

    def get_closed_ports(self, device_id: Optional[str] = None) -> Dict[str, List[int]]:
        """
        获取关闭的端口

        Args:
            device_id: 设备ID（可选）

        Returns:
            关闭的端口字典
        """
        if device_id:
            return {device_id: self._closed_ports.get(device_id, [])}
        return self._closed_ports.copy()


# 便捷函数
def create_network_actions() -> NetworkActions:
    """
    创建网络操作的工厂函数

    Returns:
        网络操作实例
    """
    return NetworkActions()
