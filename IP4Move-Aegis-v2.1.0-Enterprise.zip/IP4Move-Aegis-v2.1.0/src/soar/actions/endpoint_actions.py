"""
终端操作模块

提供终端相关的响应操作，包括进程终止、文件隔离和注册表修改。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

# 配置日志
logger = logging.getLogger(__name__)


class EndpointActionType(Enum):
    """终端操作类型"""
    TERMINATE_PROCESS = "terminate_process"
    ISOLATE_FILE = "isolate_file"
    RESTORE_FILE = "restore_file"
    DELETE_FILE = "delete_file"
    MODIFY_REGISTRY = "modify_registry"
    RESTORE_REGISTRY = "restore_registry"
    KILL_CONNECTION = "kill_connection"


@dataclass
class ProcessInfo:
    """进程信息"""
    pid: int
    name: str
    path: str
    user: str
    command_line: str


@dataclass
class FileInfo:
    """文件信息"""
    path: str
    hash_md5: Optional[str] = None
    hash_sha256: Optional[str] = None
    size: Optional[int] = None


class EndpointActions:
    """
    终端操作类

    提供终端相关的响应操作能力。

    Example:
        >>> actions = EndpointActions()
        >>>
        >>> # 终止进程
        >>> result = await actions.terminate_process(
        ...     endpoint_id="host-001",
        ...     pid=1234,
        ...     reason="Malicious process"
        ... )
    """

    def __init__(self):
        """初始化终端操作"""
        self._isolated_files: Dict[str, List[str]] = {}  # endpoint_id -> paths
        self._terminated_processes: Dict[str, List[int]] = {}  # endpoint_id -> pids
        self._modified_registry: Dict[str, List[Dict[str, Any]]] = {}  # endpoint_id -> changes

    async def terminate_process(
        self,
        endpoint_id: str,
        pid: int,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        终止进程

        Args:
            endpoint_id: 终端ID
            pid: 进程ID
            reason: 原因

        Returns:
            操作结果
        """
        logger.info(f"Terminating process {pid} on {endpoint_id}")

        if endpoint_id not in self._terminated_processes:
            self._terminated_processes[endpoint_id] = []

        self._terminated_processes[endpoint_id].append(pid)

        # 实际实现需要调用EDR API

        return {
            "success": True,
            "endpoint_id": endpoint_id,
            "pid": pid,
            "action": "process_terminated",
            "reason": reason,
            "timestamp": datetime.utcnow().isoformat(),
        }

    async def terminate_process_by_name(
        self,
        endpoint_id: str,
        process_name: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        按名称终止进程

        Args:
            endpoint_id: 终端ID
            process_name: 进程名称
            reason: 原因

        Returns:
            操作结果
        """
        logger.info(f"Terminating process '{process_name}' on {endpoint_id}")

        # 实际实现需要调用EDR API

        return {
            "success": True,
            "endpoint_id": endpoint_id,
            "process_name": process_name,
            "action": "process_terminated_by_name",
            "reason": reason,
        }

    async def isolate_file(
        self,
        endpoint_id: str,
        file_path: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        隔离文件

        Args:
            endpoint_id: 终端ID
            file_path: 文件路径
            reason: 原因

        Returns:
            操作结果
        """
        logger.info(f"Isolating file {file_path} on {endpoint_id}")

        if endpoint_id not in self._isolated_files:
            self._isolated_files[endpoint_id] = []

        if file_path in self._isolated_files[endpoint_id]:
            return {
                "success": False,
                "error": f"File {file_path} is already isolated",
            }

        self._isolated_files[endpoint_id].append(file_path)

        return {
            "success": True,
            "endpoint_id": endpoint_id,
            "file_path": file_path,
            "action": "file_isolated",
            "reason": reason,
        }

    async def restore_file(
        self,
        endpoint_id: str,
        file_path: str,
    ) -> Dict[str, Any]:
        """
        恢复隔离的文件

        Args:
            endpoint_id: 终端ID
            file_path: 文件路径

        Returns:
            操作结果
        """
        logger.info(f"Restoring file {file_path} on {endpoint_id}")

        if endpoint_id not in self._isolated_files:
            return {
                "success": False,
                "error": f"No isolated files on {endpoint_id}",
            }

        if file_path not in self._isolated_files[endpoint_id]:
            return {
                "success": False,
                "error": f"File {file_path} is not isolated",
            }

        self._isolated_files[endpoint_id].remove(file_path)

        return {
            "success": True,
            "endpoint_id": endpoint_id,
            "file_path": file_path,
            "action": "file_restored",
        }

    async def delete_file(
        self,
        endpoint_id: str,
        file_path: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        删除文件

        Args:
            endpoint_id: 终端ID
            file_path: 文件路径
            reason: 原因

        Returns:
            操作结果
        """
        logger.info(f"Deleting file {file_path} on {endpoint_id}")

        return {
            "success": True,
            "endpoint_id": endpoint_id,
            "file_path": file_path,
            "action": "file_deleted",
            "reason": reason,
        }

    async def modify_registry(
        self,
        endpoint_id: str,
        key_path: str,
        value_name: str,
        value_data: Any,
        value_type: str = "REG_SZ",
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        修改注册表

        Args:
            endpoint_id: 终端ID
            key_path: 注册表键路径
            value_name: 值名称
            value_data: 值数据
            value_type: 值类型
            reason: 原因

        Returns:
            操作结果
        """
        logger.info(f"Modifying registry on {endpoint_id}: {key_path}\\{value_name}")

        if endpoint_id not in self._modified_registry:
            self._modified_registry[endpoint_id] = []

        self._modified_registry[endpoint_id].append({
            "key_path": key_path,
            "value_name": value_name,
            "value_data": value_data,
            "value_type": value_type,
            "timestamp": datetime.utcnow().isoformat(),
        })

        return {
            "success": True,
            "endpoint_id": endpoint_id,
            "key_path": key_path,
            "value_name": value_name,
            "action": "registry_modified",
            "reason": reason,
        }

    async def kill_connection(
        self,
        endpoint_id: str,
        remote_ip: str,
        remote_port: Optional[int] = None,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        终止网络连接

        Args:
            endpoint_id: 终端ID
            remote_ip: 远程IP
            remote_port: 远程端口（可选）
            reason: 原因

        Returns:
            操作结果
        """
        logger.info(f"Killing connection from {endpoint_id} to {remote_ip}:{remote_port}")

        return {
            "success": True,
            "endpoint_id": endpoint_id,
            "remote_ip": remote_ip,
            "remote_port": remote_port,
            "action": "connection_killed",
            "reason": reason,
        }

    def get_isolated_files(self, endpoint_id: Optional[str] = None) -> Dict[str, List[str]]:
        """
        获取隔离的文件

        Args:
            endpoint_id: 终端ID（可选）

        Returns:
            隔离文件字典
        """
        if endpoint_id:
            return {endpoint_id: self._isolated_files.get(endpoint_id, [])}
        return self._isolated_files.copy()

    def get_terminated_processes(self, endpoint_id: Optional[str] = None) -> Dict[str, List[int]]:
        """
        获取终止的进程

        Args:
            endpoint_id: 终端ID（可选）

        Returns:
            终止进程字典
        """
        if endpoint_id:
            return {endpoint_id: self._terminated_processes.get(endpoint_id, [])}
        return self._terminated_processes.copy()


# 便捷函数
def create_endpoint_actions() -> EndpointActions:
    """
    创建终端操作的工厂函数

    Returns:
        终端操作实例
    """
    return EndpointActions()
