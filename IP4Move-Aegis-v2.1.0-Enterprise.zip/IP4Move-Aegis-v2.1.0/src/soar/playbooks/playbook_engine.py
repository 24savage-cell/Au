"""
剧本引擎模块

提供SOAR剧本的执行引擎，支持YAML解析、步骤执行、条件分支和并行执行。
"""

import asyncio
import logging
import yaml
from typing import Dict, Any, List, Optional, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import json

# 配置日志
logger = logging.getLogger(__name__)


class StepType(Enum):
    """步骤类型"""
    ACTION = "action"
    CONDITION = "condition"
    LOOP = "loop"
    PARALLEL = "parallel"
    WAIT = "wait"
    APPROVAL = "approval"


class StepStatus(Enum):
    """步骤状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class PlaybookStep:
    """剧本步骤"""
    id: str
    name: str
    type: StepType
    params: Dict[str, Any] = field(default_factory=dict)
    condition: Optional[str] = None
    on_success: Optional[str] = None
    on_failure: Optional[str] = None
    timeout: int = 300
    retries: int = 0


@dataclass
class Playbook:
    """剧本定义"""
    id: str
    name: str
    description: str
    version: str
    steps: List[PlaybookStep]
    variables: Dict[str, Any] = field(default_factory=dict)
    triggers: List[str] = field(default_factory=list)
    enabled: bool = True


@dataclass
class StepResult:
    """步骤执行结果"""
    step_id: str
    status: StepStatus
    output: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None


class PlaybookEngine:
    """
    剧本引擎

    提供SOAR剧本的执行能力，支持YAML解析、步骤执行、条件分支和并行执行。

    Example:
        >>> engine = PlaybookEngine()
        >>>
        >>> # 从YAML加载剧本
        >>> playbook = engine.load_from_yaml("playbook.yaml")
        >>>
        >>> # 执行剧本
        >>> result = await engine.execute(playbook, context={"ip": "1.2.3.4"})
    """

    def __init__(self):
        """初始化剧本引擎"""
        self._action_handlers: Dict[str, Callable] = {}
        self._execution_context: Dict[str, Any] = {}
        self._step_results: Dict[str, StepResult] = {}

    def register_action_handler(self, action_name: str, handler: Callable) -> None:
        """
        注册动作处理器

        Args:
            action_name: 动作名称
            handler: 处理器函数
        """
        self._action_handlers[action_name] = handler
        logger.info(f"Action handler registered: {action_name}")

    def load_from_yaml(self, yaml_content: str) -> Playbook:
        """
        从YAML内容加载剧本

        Args:
            yaml_content: YAML内容

        Returns:
            剧本对象
        """
        data = yaml.safe_load(yaml_content)
        return self._parse_playbook(data)

    def load_from_file(self, file_path: str) -> Playbook:
        """
        从文件加载剧本

        Args:
            file_path: 文件路径

        Returns:
            剧本对象
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            return self.load_from_yaml(f.read())

    def _parse_playbook(self, data: Dict[str, Any]) -> Playbook:
        """解析剧本数据"""
        steps = []
        for step_data in data.get("steps", []):
            step = PlaybookStep(
                id=step_data["id"],
                name=step_data["name"],
                type=StepType(step_data["type"]),
                params=step_data.get("params", {}),
                condition=step_data.get("condition"),
                on_success=step_data.get("on_success"),
                on_failure=step_data.get("on_failure"),
                timeout=step_data.get("timeout", 300),
                retries=step_data.get("retries", 0),
            )
            steps.append(step)

        return Playbook(
            id=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            version=data.get("version", "1.0"),
            steps=steps,
            variables=data.get("variables", {}),
            triggers=data.get("triggers", []),
            enabled=data.get("enabled", True),
        )

    async def execute(
        self,
        playbook: Playbook,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        执行剧本

        Args:
            playbook: 剧本对象
            context: 执行上下文

        Returns:
            执行结果
        """
        if not playbook.enabled:
            return {"status": "skipped", "reason": "Playbook is disabled"}

        # 初始化执行上下文
        self._execution_context = {
            **playbook.variables,
            **(context or {}),
            "playbook_id": playbook.id,
            "playbook_name": playbook.name,
            "execution_id": f"exec_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
        }
        self._step_results = {}

        logger.info(f"Starting playbook execution: {playbook.name}")

        # 按顺序执行步骤
        for step in playbook.steps:
            result = await self._execute_step(step)
            self._step_results[step.id] = result

            if result.status == StepStatus.FAILED:
                logger.error(f"Step failed: {step.name}")
                if step.on_failure:
                    await self._handle_failure_branch(step)
                else:
                    break
            elif result.status == StepStatus.COMPLETED and step.on_success:
                await self._handle_success_branch(step)

        return {
            "status": "completed",
            "execution_id": self._execution_context["execution_id"],
            "step_results": {k: {
                "status": v.status.value,
                "error": v.error,
            } for k, v in self._step_results.items()},
        }

    async def _execute_step(self, step: PlaybookStep) -> StepResult:
        """执行单个步骤"""
        start_time = datetime.utcnow()

        # 检查条件
        if step.condition and not self._evaluate_condition(step.condition):
            return StepResult(
                step_id=step.id,
                status=StepStatus.SKIPPED,
                start_time=start_time,
                end_time=datetime.utcnow(),
            )

        result = StepResult(
            step_id=step.id,
            status=StepStatus.RUNNING,
            start_time=start_time,
        )

        try:
            if step.type == StepType.ACTION:
                await self._execute_action_step(step, result)
            elif step.type == StepType.CONDITION:
                await self._execute_condition_step(step, result)
            elif step.type == StepType.PARALLEL:
                await self._execute_parallel_step(step, result)
            elif step.type == StepType.WAIT:
                await self._execute_wait_step(step, result)
            elif step.type == StepType.LOOP:
                await self._execute_loop_step(step, result)

            result.status = StepStatus.COMPLETED
            result.end_time = datetime.utcnow()

        except Exception as e:
            logger.error(f"Step execution failed: {e}")
            result.status = StepStatus.FAILED
            result.error = str(e)
            result.end_time = datetime.utcnow()

        return result

    async def _execute_action_step(self, step: PlaybookStep, result: StepResult) -> None:
        """执行动作步骤"""
        action_name = step.params.get("action")
        action_params = step.params.get("parameters", {})

        # 替换变量
        action_params = self._substitute_variables(action_params)

        handler = self._action_handlers.get(action_name)
        if not handler:
            raise ValueError(f"Unknown action: {action_name}")

        # 执行动作
        output = await handler(**action_params) if asyncio.iscoroutinefunction(handler) else handler(**action_params)
        result.output = {"action_result": output}

    async def _execute_condition_step(self, step: PlaybookStep, result: StepResult) -> None:
        """执行条件步骤"""
        condition = step.params.get("expression")
        is_true = self._evaluate_condition(condition)
        result.output = {"condition_result": is_true}

    async def _execute_parallel_step(self, step: PlaybookStep, result: StepResult) -> None:
        """执行并行步骤"""
        branches = step.params.get("branches", [])

        async def execute_branch(branch_steps: List[Dict[str, Any]]):
            branch_playbook = Playbook(
                id=f"{step.id}_branch",
                name=f"Branch of {step.name}",
                description="Parallel branch",
                version="1.0",
                steps=[self._dict_to_step(s) for s in branch_steps],
            )
            return await self.execute(branch_playbook, self._execution_context)

        tasks = [execute_branch(branch) for branch in branches]
        branch_results = await asyncio.gather(*tasks, return_exceptions=True)

        result.output = {"branch_results": branch_results}

    async def _execute_wait_step(self, step: PlaybookStep, result: StepResult) -> None:
        """执行等待步骤"""
        wait_seconds = step.params.get("seconds", 10)
        await asyncio.sleep(wait_seconds)
        result.output = {"waited_seconds": wait_seconds}

    async def _execute_loop_step(self, step: PlaybookStep, result: StepResult) -> None:
        """执行循环步骤"""
        items = step.params.get("items", [])
        loop_step = step.params.get("step", {})

        loop_results = []
        for item in items:
            self._execution_context["loop_item"] = item
            loop_step_obj = self._dict_to_step(loop_step)
            loop_result = await self._execute_step(loop_step_obj)
            loop_results.append(loop_result.output)

        result.output = {"loop_results": loop_results}

    def _dict_to_step(self, data: Dict[str, Any]) -> PlaybookStep:
        """将字典转换为步骤对象"""
        return PlaybookStep(
            id=data.get("id", "unknown"),
            name=data.get("name", "Unnamed Step"),
            type=StepType(data.get("type", "action")),
            params=data.get("params", {}),
            condition=data.get("condition"),
            on_success=data.get("on_success"),
            on_failure=data.get("on_failure"),
        )

    def _evaluate_condition(self, condition: str) -> bool:
        """评估条件表达式"""
        try:
            # 替换变量
            condition = self._substitute_variables_in_string(condition)
            # 安全评估（简化实现）
            return eval(condition, {"__builtins__": {}}, self._execution_context)
        except Exception as e:
            logger.error(f"Condition evaluation failed: {e}")
            return False

    def _substitute_variables(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """替换参数中的变量"""
        result = {}
        for key, value in params.items():
            if isinstance(value, str):
                result[key] = self._substitute_variables_in_string(value)
            elif isinstance(value, dict):
                result[key] = self._substitute_variables(value)
            elif isinstance(value, list):
                result[key] = [
                    self._substitute_variables_in_string(item) if isinstance(item, str) else item
                    for item in value
                ]
            else:
                result[key] = value
        return result

    def _substitute_variables_in_string(self, value: str) -> str:
        """在字符串中替换变量"""
        import re
        pattern = r'\$\{(\w+)\}'

        def replace_var(match):
            var_name = match.group(1)
            return str(self._execution_context.get(var_name, match.group(0)))

        return re.sub(pattern, replace_var, value)

    async def _handle_success_branch(self, step: PlaybookStep) -> None:
        """处理成功分支"""
        logger.debug(f"Handling success branch for step: {step.name}")

    async def _handle_failure_branch(self, step: PlaybookStep) -> None:
        """处理失败分支"""
        logger.debug(f"Handling failure branch for step: {step.name}")


# 便捷函数
def create_playbook_engine() -> PlaybookEngine:
    """
    创建剧本引擎的工厂函数

    Returns:
        剧本引擎实例
    """
    return PlaybookEngine()
