"""
IP封禁剧本模块

提供IP封禁的自动化剧本，支持XDP/iptables/防火墙封禁和自动解封。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum

# 配置日志
logger = logging.getLogger(__name__)


class BlockingMethod(Enum):
    """封禁方法"""
    XDP = "xdp"
    IPTABLES = "iptables"
    FIREWALL_API = "firewall_api"
    CLOUD_WAF = "cloud_waf"


@dataclass
class BlockedIP:
    """被封禁的IP"""
    ip: str
    method: BlockingMethod
    blocked_at: datetime
    expires_at: Optional[datetime]
    reason: str
    blocked_by: str


class IPBlockingPlaybook:
    """
    IP封禁剧本

    提供IP封禁的自动化能力，支持多种封禁方法和自动解封。

    Example:
        >>> playbook = IPBlockingPlaybook()
        >>>
        >>> # 封禁IP
        >>> result = await playbook.block_ip(
        ...     ip="192.168.1.100",
        ...     method=BlockingMethod.IPTABLES,
        ...     duration_minutes=60,
        ...     reason="Brute force attack"
        ... )
        >>>
        >>> # 解封IP
        >>> await playbook.unblock_ip("192.168.1.100")
    """

    def __init__(self):
        """初始化IP封禁剧本"""
        self._blocked_ips: Dict[str, BlockedIP] = {}
        self._method_handlers = {
            BlockingMethod.XDP: self._block_with_xdp,
            BlockingMethod.IPTABLES: self._block_with_iptables,
            BlockingMethod.FIREWALL_API: self._block_with_firewall_api,
            BlockingMethod.CLOUD_WAF: self._block_with_cloud_waf,
        }
        self._unblock_handlers = {
            BlockingMethod.XDP: self._unblock_with_xdp,
            BlockingMethod.IPTABLES: self._unblock_with_iptables,
            BlockingMethod.FIREWALL_API: self._unblock_with_firewall_api,
            BlockingMethod.CLOUD_WAF: self._unblock_with_cloud_waf,
        }

    async def block_ip(
        self,
        ip: str,
        method: BlockingMethod = BlockingMethod.IPTABLES,
        duration_minutes: Optional[int] = None,
        reason: str = "",
        blocked_by: str = "system",
    ) -> Dict[str, Any]:
        """
        封禁IP

        Args:
            ip: 要封禁的IP地址
            method: 封禁方法
            duration_minutes: 封禁时长（分钟），None表示永久封禁
            reason: 封禁原因
            blocked_by: 封禁操作者

        Returns:
            操作结果
        """
        if ip in self._blocked_ips:
            return {
                "success": False,
                "error": f"IP {ip} is already blocked",
                "existing_block": self._blocked_ips[ip].__dict__,
            }

        handler = self._method_handlers.get(method)
        if not handler:
            return {"success": False, "error": f"Unknown blocking method: {method}"}

        try:
            # 执行封禁
            await handler(ip)

            # 记录封禁信息
            expires_at = None
            if duration_minutes:
                expires_at = datetime.utcnow() + timedelta(minutes=duration_minutes)

            blocked_ip = BlockedIP(
                ip=ip,
                method=method,
                blocked_at=datetime.utcnow(),
                expires_at=expires_at,
                reason=reason,
                blocked_by=blocked_by,
            )
            self._blocked_ips[ip] = blocked_ip

            logger.info(f"IP blocked: {ip} using {method.value}")

            # 如果需要自动解封，启动计时器
            if duration_minutes:
                asyncio.create_task(self._schedule_unblock(ip, duration_minutes))

            return {
                "success": True,
                "ip": ip,
                "method": method.value,
                "expires_at": expires_at.isoformat() if expires_at else None,
            }

        except Exception as e:
            logger.error(f"Failed to block IP {ip}: {e}")
            return {"success": False, "error": str(e)}

    async def unblock_ip(
        self,
        ip: str,
        unblocked_by: str = "system",
    ) -> Dict[str, Any]:
        """
        解封IP

        Args:
            ip: 要解封的IP地址
            unblocked_by: 解封操作者

        Returns:
            操作结果
        """
        if ip not in self._blocked_ips:
            return {"success": False, "error": f"IP {ip} is not blocked"}

        blocked_info = self._blocked_ips[ip]
        handler = self._unblock_handlers.get(blocked_info.method)

        if not handler:
            return {"success": False, "error": f"Unknown unblocking method: {blocked_info.method}"}

        try:
            await handler(ip)
            del self._blocked_ips[ip]

            logger.info(f"IP unblocked: {ip} by {unblocked_by}")

            return {
                "success": True,
                "ip": ip,
                "was_blocked_since": blocked_info.blocked_at.isoformat(),
            }

        except Exception as e:
            logger.error(f"Failed to unblock IP {ip}: {e}")
            return {"success": False, "error": str(e)}

    async def _schedule_unblock(self, ip: str, delay_minutes: int) -> None:
        """计划自动解封"""
        await asyncio.sleep(delay_minutes * 60)
        if ip in self._blocked_ips:
            await self.unblock_ip(ip, unblocked_by="auto")

    async def _block_with_xdp(self, ip: str) -> None:
        """使用XDP封禁"""
        # 简化实现，实际需要调用XDP程序
        logger.debug(f"Blocking {ip} with XDP")
        # 这里应该调用XDP相关的命令或API

    async def _unblock_with_xdp(self, ip: str) -> None:
        """使用XDP解封"""
        logger.debug(f"Unblocking {ip} with XDP")

    async def _block_with_iptables(self, ip: str) -> None:
        """使用iptables封禁"""
        import subprocess

        cmd = ["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"]
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            raise RuntimeError(f"iptables failed: {result.stderr}")

        logger.debug(f"Blocked {ip} with iptables")

    async def _unblock_with_iptables(self, ip: str) -> None:
        """使用iptables解封"""
        import subprocess

        cmd = ["iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"]
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            raise RuntimeError(f"iptables failed: {result.stderr}")

        logger.debug(f"Unblocked {ip} with iptables")

    async def _block_with_firewall_api(self, ip: str) -> None:
        """使用防火墙API封禁"""
        # 需要集成具体的防火墙API
        logger.debug(f"Blocking {ip} with firewall API")

    async def _unblock_with_firewall_api(self, ip: str) -> None:
        """使用防火墙API解封"""
        logger.debug(f"Unblocking {ip} with firewall API")

    async def _block_with_cloud_waf(self, ip: str) -> None:
        """使用云WAF封禁"""
        # 需要集成具体的云WAF API
        logger.debug(f"Blocking {ip} with cloud WAF")

    async def _unblock_with_cloud_waf(self, ip: str) -> None:
        """使用云WAF解封"""
        logger.debug(f"Unblocking {ip} with cloud WAF")

    def get_blocked_ips(self) -> List[Dict[str, Any]]:
        """
        获取所有被封禁的IP

        Returns:
            被封禁IP列表
        """
        return [
            {
                "ip": info.ip,
                "method": info.method.value,
                "blocked_at": info.blocked_at.isoformat(),
                "expires_at": info.expires_at.isoformat() if info.expires_at else None,
                "reason": info.reason,
                "blocked_by": info.blocked_by,
            }
            for info in self._blocked_ips.values()
        ]

    def is_blocked(self, ip: str) -> bool:
        """
        检查IP是否被封禁

        Args:
            ip: IP地址

        Returns:
            是否被封禁
        """
        return ip in self._blocked_ips

    async def cleanup_expired_blocks(self) -> int:
        """
        清理过期的封禁

        Returns:
            解封的IP数量
        """
        now = datetime.utcnow()
        expired_ips = [
            ip for ip, info in self._blocked_ips.items()
            if info.expires_at and info.expires_at <= now
        ]

        for ip in expired_ips:
            await self.unblock_ip(ip, unblocked_by="cleanup")

        return len(expired_ips)


# 便捷函数
def create_ip_blocking_playbook() -> IPBlockingPlaybook:
    """
    创建IP封禁剧本的工厂函数

    Returns:
        IP封禁剧本实例
    """
    return IPBlockingPlaybook()
