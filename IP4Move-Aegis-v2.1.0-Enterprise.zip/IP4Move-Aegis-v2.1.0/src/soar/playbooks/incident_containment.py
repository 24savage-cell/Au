"""
事件遏制剧本模块

提供事件遏制的自动化剧本，支持网络隔离、进程终止和证据保全。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

# 配置日志
logger = logging.getLogger(__name__)


class ContainmentAction(Enum):
    """遏制动作"""
    NETWORK_ISOLATION = "network_isolation"
    PROCESS_TERMINATION = "process_termination"
    FILE_QUARANTINE = "file_quarantine"
    MEMORY_DUMP = "memory_dump"
    DISK_IMAGE = "disk_image"
    LOG_COLLECTION = "log_collection"


@dataclass
class ContainedEndpoint:
    """被遏制的终端"""
    endpoint_id: str
    hostname: str
    ip_address: str
    actions_taken: List[ContainmentAction]
    contained_at: datetime
    reason: str
    contained_by: str


class IncidentContainmentPlaybook:
    """
    事件遏制剧本

    提供事件遏制的自动化能力，支持网络隔离、进程终止和证据保全。

    Example:
        >>> playbook = IncidentContainmentPlaybook()
        >>>
        >>> # 遏制终端
        >>> result = await playbook.contain_endpoint(
        ...     endpoint_id="host001",
        ...     hostname="workstation-01",
        ...     ip_address="192.168.1.100",
        ...     actions=[ContainmentAction.NETWORK_ISOLATION, ContainmentAction.PROCESS_TERMINATION],
        ...     reason="Malware infection detected"
        ... )
        >>>
        >>> # 解除遏制
        >>> await playbook.release_endpoint("host001")
    """

    def __init__(self):
        """初始化事件遏制剧本"""
        self._contained_endpoints: Dict[str, ContainedEndpoint] = {}
        self._action_handlers = {
            ContainmentAction.NETWORK_ISOLATION: self._isolate_network,
            ContainmentAction.PROCESS_TERMINATION: self._terminate_processes,
            ContainmentAction.FILE_QUARANTINE: self._quarantine_files,
            ContainmentAction.MEMORY_DUMP: self._capture_memory,
            ContainmentAction.DISK_IMAGE: self._create_disk_image,
            ContainmentAction.LOG_COLLECTION: self._collect_logs,
        }

    async def contain_endpoint(
        self,
        endpoint_id: str,
        hostname: str,
        ip_address: str,
        actions: List[ContainmentAction],
        reason: str = "",
        contained_by: str = "system",
    ) -> Dict[str, Any]:
        """
        遏制终端

        Args:
            endpoint_id: 终端ID
            hostname: 主机名
            ip_address: IP地址
            actions: 要执行的遏制动作列表
            reason: 遏制原因
            contained_by: 遏制操作者

        Returns:
            操作结果
        """
        if endpoint_id in self._contained_endpoints:
            return {
                "success": False,
                "error": f"Endpoint {hostname} is already contained",
                "existing_containment": self._contained_endpoints[endpoint_id].__dict__,
            }

        actions_taken = []
        failed_actions = []
        evidence_collected = []

        for action in actions:
            handler = self._action_handlers.get(action)
            if not handler:
                failed_actions.append({"action": action.value, "error": "Unknown action"})
                continue

            try:
                result = await handler(endpoint_id, hostname, ip_address)
                actions_taken.append(action)

                if action in [ContainmentAction.MEMORY_DUMP, ContainmentAction.DISK_IMAGE, ContainmentAction.LOG_COLLECTION]:
                    evidence_collected.append({
                        "action": action.value,
                        "result": result,
                    })

                logger.info(f"Action {action.value} executed for endpoint {hostname}")
            except Exception as e:
                logger.error(f"Action {action.value} failed for endpoint {hostname}: {e}")
                failed_actions.append({"action": action.value, "error": str(e)})

        # 记录遏制信息
        contained_endpoint = ContainedEndpoint(
            endpoint_id=endpoint_id,
            hostname=hostname,
            ip_address=ip_address,
            actions_taken=actions_taken,
            contained_at=datetime.utcnow(),
            reason=reason,
            contained_by=contained_by,
        )
        self._contained_endpoints[endpoint_id] = contained_endpoint

        logger.info(f"Endpoint contained: {hostname} ({endpoint_id})")

        return {
            "success": True,
            "endpoint_id": endpoint_id,
            "hostname": hostname,
            "actions_taken": [a.value for a in actions_taken],
            "failed_actions": failed_actions,
            "evidence_collected": evidence_collected,
        }

    async def release_endpoint(
        self,
        endpoint_id: str,
        released_by: str = "system",
    ) -> Dict[str, Any]:
        """
        解除终端遏制

        Args:
            endpoint_id: 终端ID
            released_by: 解除操作者

        Returns:
            操作结果
        """
        if endpoint_id not in self._contained_endpoints:
            return {"success": False, "error": f"Endpoint {endpoint_id} is not contained"}

        contained_info = self._contained_endpoints[endpoint_id]

        # 恢复终端
        try:
            await self._restore_endpoint(
                endpoint_id,
                contained_info.hostname,
                contained_info.ip_address,
                contained_info.actions_taken
            )
            del self._contained_endpoints[endpoint_id]

            logger.info(f"Endpoint released: {contained_info.hostname} ({endpoint_id}) by {released_by}")

            return {
                "success": True,
                "endpoint_id": endpoint_id,
                "hostname": contained_info.hostname,
                "was_contained_since": contained_info.contained_at.isoformat(),
            }

        except Exception as e:
            logger.error(f"Failed to release endpoint {endpoint_id}: {e}")
            return {"success": False, "error": str(e)}

    async def _isolate_network(self, endpoint_id: str, hostname: str, ip_address: str) -> Dict[str, Any]:
        """网络隔离"""
        logger.debug(f"Isolating network for: {hostname}")
        # 实际实现需要调用EDR或网络设备API
        return {"method": "network_isolation", "status": "success"}

    async def _terminate_processes(self, endpoint_id: str, hostname: str, ip_address: str) -> Dict[str, Any]:
        """终止进程"""
        logger.debug(f"Terminating suspicious processes on: {hostname}")
        # 实际实现需要调用EDR API
        return {"method": "process_termination", "status": "success"}

    async def _quarantine_files(self, endpoint_id: str, hostname: str, ip_address: str) -> Dict[str, Any]:
        """文件隔离"""
        logger.debug(f"Quarantining files on: {hostname}")
        # 实际实现需要调用EDR API
        return {"method": "file_quarantine", "status": "success"}

    async def _capture_memory(self, endpoint_id: str, hostname: str, ip_address: str) -> Dict[str, Any]:
        """内存转储"""
        logger.debug(f"Capturing memory dump from: {hostname}")
        # 实际实现需要调用EDR API
        return {
            "method": "memory_dump",
            "status": "success",
            "evidence_path": f"/evidence/{endpoint_id}/memory.dmp",
        }

    async def _create_disk_image(self, endpoint_id: str, hostname: str, ip_address: str) -> Dict[str, Any]:
        """磁盘镜像"""
        logger.debug(f"Creating disk image of: {hostname}")
        # 实际实现需要调用EDR API
        return {
            "method": "disk_image",
            "status": "success",
            "evidence_path": f"/evidence/{endpoint_id}/disk.img",
        }

    async def _collect_logs(self, endpoint_id: str, hostname: str, ip_address: str) -> Dict[str, Any]:
        """日志收集"""
        logger.debug(f"Collecting logs from: {hostname}")
        # 实际实现需要调用EDR或日志收集API
        return {
            "method": "log_collection",
            "status": "success",
            "evidence_path": f"/evidence/{endpoint_id}/logs/",
        }

    async def _restore_endpoint(
        self,
        endpoint_id: str,
        hostname: str,
        ip_address: str,
        actions_taken: List[ContainmentAction]
    ) -> None:
        """恢复终端"""
        logger.debug(f"Restoring endpoint: {hostname}")

        # 恢复网络连接
        if ContainmentAction.NETWORK_ISOLATION in actions_taken:
            logger.debug(f"Restoring network for: {hostname}")

        # 恢复文件
        if ContainmentAction.FILE_QUARANTINE in actions_taken:
            logger.debug(f"Restoring quarantined files on: {hostname}")

    def get_contained_endpoints(self) -> List[Dict[str, Any]]:
        """
        获取所有被遏制的终端

        Returns:
            被遏制终端列表
        """
        return [
            {
                "endpoint_id": info.endpoint_id,
                "hostname": info.hostname,
                "ip_address": info.ip_address,
                "actions_taken": [a.value for a in info.actions_taken],
                "contained_at": info.contained_at.isoformat(),
                "reason": info.reason,
                "contained_by": info.contained_by,
            }
            for info in self._contained_endpoints.values()
        ]

    def is_contained(self, endpoint_id: str) -> bool:
        """
        检查终端是否被遏制

        Args:
            endpoint_id: 终端ID

        Returns:
            是否被遏制
        """
        return endpoint_id in self._contained_endpoints


# 便捷函数
def create_incident_containment_playbook() -> IncidentContainmentPlaybook:
    """
    创建事件遏制剧本的工厂函数

    Returns:
        事件遏制剧本实例
    """
    return IncidentContainmentPlaybook()
