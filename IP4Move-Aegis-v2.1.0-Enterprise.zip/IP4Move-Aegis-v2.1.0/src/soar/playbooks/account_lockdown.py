"""
账号锁定剧本模块

提供账号锁定的自动化剧本，支持临时锁定、权限降级和通知。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum

# 配置日志
logger = logging.getLogger(__name__)


class LockdownAction(Enum):
    """锁定动作"""
    DISABLE_ACCOUNT = "disable_account"
    RESET_PASSWORD = "reset_password"
    REVOKE_SESSIONS = "revoke_sessions"
    DEMOTE_PRIVILEGES = "demote_privileges"
    NOTIFY_USER = "notify_user"


@dataclass
class LockedAccount:
    """被锁定的账号"""
    user_id: str
    username: str
    actions_taken: List[LockdownAction]
    locked_at: datetime
    expires_at: Optional[datetime]
    reason: str
    locked_by: str


class AccountLockdownPlaybook:
    """
    账号锁定剧本

    提供账号锁定的自动化能力，支持临时锁定、权限降级和通知。

    Example:
        >>> playbook = AccountLockdownPlaybook()
        >>>
        >>> # 锁定账号
        >>> result = await playbook.lockdown_account(
        ...     user_id="user123",
        ...     username="john.doe",
        ...     actions=[LockdownAction.DISABLE_ACCOUNT, LockdownAction.REVOKE_SESSIONS],
        ...     duration_hours=24,
        ...     reason="Suspicious activity detected"
        ... )
        >>>
        >>> # 解锁账号
        >>> await playbook.unlock_account("user123")
    """

    def __init__(self):
        """初始化账号锁定剧本"""
        self._locked_accounts: Dict[str, LockedAccount] = {}
        self._action_handlers = {
            LockdownAction.DISABLE_ACCOUNT: self._disable_account,
            LockdownAction.RESET_PASSWORD: self._reset_password,
            LockdownAction.REVOKE_SESSIONS: self._revoke_sessions,
            LockdownAction.DEMOTE_PRIVILEGES: self._demote_privileges,
            LockdownAction.NOTIFY_USER: self._notify_user,
        }

    async def lockdown_account(
        self,
        user_id: str,
        username: str,
        actions: List[LockdownAction],
        duration_hours: Optional[int] = None,
        reason: str = "",
        locked_by: str = "system",
    ) -> Dict[str, Any]:
        """
        锁定账号

        Args:
            user_id: 用户ID
            username: 用户名
            actions: 要执行的锁定动作列表
            duration_hours: 锁定时长（小时），None表示永久锁定
            reason: 锁定原因
            locked_by: 锁定操作者

        Returns:
            操作结果
        """
        if user_id in self._locked_accounts:
            return {
                "success": False,
                "error": f"Account {username} is already locked",
                "existing_lockdown": self._locked_accounts[user_id].__dict__,
            }

        actions_taken = []
        failed_actions = []

        for action in actions:
            handler = self._action_handlers.get(action)
            if not handler:
                failed_actions.append({"action": action.value, "error": "Unknown action"})
                continue

            try:
                await handler(user_id, username)
                actions_taken.append(action)
                logger.info(f"Action {action.value} executed for user {username}")
            except Exception as e:
                logger.error(f"Action {action.value} failed for user {username}: {e}")
                failed_actions.append({"action": action.value, "error": str(e)})

        # 记录锁定信息
        expires_at = None
        if duration_hours:
            expires_at = datetime.utcnow() + timedelta(hours=duration_hours)

        locked_account = LockedAccount(
            user_id=user_id,
            username=username,
            actions_taken=actions_taken,
            locked_at=datetime.utcnow(),
            expires_at=expires_at,
            reason=reason,
            locked_by=locked_by,
        )
        self._locked_accounts[user_id] = locked_account

        logger.info(f"Account locked: {username} ({user_id})")

        # 如果需要自动解锁，启动计时器
        if duration_hours:
            asyncio.create_task(self._schedule_unlock(user_id, duration_hours))

        return {
            "success": True,
            "user_id": user_id,
            "username": username,
            "actions_taken": [a.value for a in actions_taken],
            "failed_actions": failed_actions,
            "expires_at": expires_at.isoformat() if expires_at else None,
        }

    async def unlock_account(
        self,
        user_id: str,
        unlocked_by: str = "system",
    ) -> Dict[str, Any]:
        """
        解锁账号

        Args:
            user_id: 用户ID
            unlocked_by: 解锁操作者

        Returns:
            操作结果
        """
        if user_id not in self._locked_accounts:
            return {"success": False, "error": f"Account {user_id} is not locked"}

        locked_info = self._locked_accounts[user_id]

        # 恢复账号
        try:
            await self._restore_account(user_id, locked_info.username, locked_info.actions_taken)
            del self._locked_accounts[user_id]

            logger.info(f"Account unlocked: {locked_info.username} ({user_id}) by {unlocked_by}")

            return {
                "success": True,
                "user_id": user_id,
                "username": locked_info.username,
                "was_locked_since": locked_info.locked_at.isoformat(),
            }

        except Exception as e:
            logger.error(f"Failed to unlock account {user_id}: {e}")
            return {"success": False, "error": str(e)}

    async def _schedule_unlock(self, user_id: str, delay_hours: int) -> None:
        """计划自动解锁"""
        await asyncio.sleep(delay_hours * 3600)
        if user_id in self._locked_accounts:
            await self.unlock_account(user_id, unlocked_by="auto")

    async def _disable_account(self, user_id: str, username: str) -> None:
        """禁用账号"""
        logger.debug(f"Disabling account: {username}")
        # 实际实现需要调用身份提供商API

    async def _reset_password(self, user_id: str, username: str) -> None:
        """重置密码"""
        logger.debug(f"Resetting password for: {username}")
        # 实际实现需要调用身份提供商API

    async def _revoke_sessions(self, user_id: str, username: str) -> None:
        """撤销会话"""
        logger.debug(f"Revoking sessions for: {username}")
        # 实际实现需要调用身份提供商API

    async def _demote_privileges(self, user_id: str, username: str) -> None:
        """降级权限"""
        logger.debug(f"Demoting privileges for: {username}")
        # 实际实现需要调用身份提供商API

    async def _notify_user(self, user_id: str, username: str) -> None:
        """通知用户"""
        logger.debug(f"Notifying user: {username}")
        # 实际实现需要调用邮件/消息服务

    async def _restore_account(
        self,
        user_id: str,
        username: str,
        actions_taken: List[LockdownAction]
    ) -> None:
        """恢复账号"""
        logger.debug(f"Restoring account: {username}")
        # 恢复被禁用的账号
        if LockdownAction.DISABLE_ACCOUNT in actions_taken:
            logger.debug(f"Re-enabling account: {username}")
        # 恢复权限
        if LockdownAction.DEMOTE_PRIVILEGES in actions_taken:
            logger.debug(f"Restoring privileges for: {username}")

    def get_locked_accounts(self) -> List[Dict[str, Any]]:
        """
        获取所有被锁定的账号

        Returns:
            被锁定账号列表
        """
        return [
            {
                "user_id": info.user_id,
                "username": info.username,
                "actions_taken": [a.value for a in info.actions_taken],
                "locked_at": info.locked_at.isoformat(),
                "expires_at": info.expires_at.isoformat() if info.expires_at else None,
                "reason": info.reason,
                "locked_by": info.locked_by,
            }
            for info in self._locked_accounts.values()
        ]

    def is_locked(self, user_id: str) -> bool:
        """
        检查账号是否被锁定

        Args:
            user_id: 用户ID

        Returns:
            是否被锁定
        """
        return user_id in self._locked_accounts

    async def cleanup_expired_lockdowns(self) -> int:
        """
        清理过期的锁定

        Returns:
            解锁的账号数量
        """
        now = datetime.utcnow()
        expired_accounts = [
            uid for uid, info in self._locked_accounts.items()
            if info.expires_at and info.expires_at <= now
        ]

        for user_id in expired_accounts:
            await self.unlock_account(user_id, unlocked_by="cleanup")

        return len(expired_accounts)


# 便捷函数
def create_account_lockdown_playbook() -> AccountLockdownPlaybook:
    """
    创建账号锁定剧本的工厂函数

    Returns:
        账号锁定剧本实例
    """
    return AccountLockdownPlaybook()
