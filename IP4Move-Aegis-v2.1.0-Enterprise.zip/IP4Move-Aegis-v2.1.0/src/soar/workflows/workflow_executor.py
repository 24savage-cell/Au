"""
工作流执行器模块

提供工作流的执行能力，支持DAG执行、重试、超时和审批门。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional, Callable, Set, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict
import uuid

# 配置日志
logger = logging.getLogger(__name__)


class WorkflowStatus(Enum):
    """工作流状态"""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    WAITING_APPROVAL = "waiting_approval"


@dataclass
class WorkflowTask:
    """工作流任务"""
    id: str
    name: str
    action: str
    params: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    timeout: int = 300
    retries: int = 0
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None


@dataclass
class Workflow:
    """工作流定义"""
    id: str
    name: str
    description: str
    tasks: Dict[str, WorkflowTask]
    variables: Dict[str, Any] = field(default_factory=dict)
    status: WorkflowStatus = WorkflowStatus.PENDING
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class WorkflowExecutor:
    """
    工作流执行器

    提供工作流的执行能力，支持DAG执行、重试、超时和审批门。

    Example:
        >>> executor = WorkflowExecutor()
        >>>
        >>> # 定义工作流
        >>> workflow = Workflow(
        ...     id="wf-001",
        ...     name="Incident Response",
        ...     description="Automated incident response workflow",
        ...     tasks={
        ...         "task1": WorkflowTask(id="task1", name="Block IP", action="block_ip"),
        ...         "task2": WorkflowTask(id="task2", name="Notify", action="notify", dependencies=["task1"]),
        ...     }
        ... )
        >>>
        >>> # 执行工作流
        >>> result = await executor.execute(workflow)
    """

    def __init__(self):
        """初始化工作流执行器"""
        self._action_handlers: Dict[str, Callable] = {}
        self._running_workflows: Dict[str, Workflow] = {}
        self._completed_workflows: Dict[str, Workflow] = {}

    def register_action_handler(self, action_name: str, handler: Callable) -> None:
        """
        注册动作处理器

        Args:
            action_name: 动作名称
            handler: 处理器函数
        """
        self._action_handlers[action_name] = handler

    async def execute(
        self,
        workflow: Workflow,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        执行工作流

        Args:
            workflow: 工作流对象
            context: 执行上下文

        Returns:
            执行结果
        """
        workflow.status = WorkflowStatus.RUNNING
        workflow.started_at = datetime.utcnow()
        self._running_workflows[workflow.id] = workflow

        execution_context = {
            **workflow.variables,
            **(context or {}),
            "workflow_id": workflow.id,
        }

        try:
            # 构建依赖图
            dependency_graph = self._build_dependency_graph(workflow.tasks)

            # 执行就绪的任务
            while True:
                ready_tasks = self._get_ready_tasks(workflow.tasks, dependency_graph)
                if not ready_tasks:
                    break

                # 并行执行就绪任务
                await asyncio.gather(*[
                    self._execute_task(task, workflow, execution_context)
                    for task in ready_tasks
                ])

            # 检查工作流状态
            if any(t.status == TaskStatus.FAILED for t in workflow.tasks.values()):
                workflow.status = WorkflowStatus.FAILED
            else:
                workflow.status = WorkflowStatus.COMPLETED

        except asyncio.TimeoutError:
            workflow.status = WorkflowStatus.TIMEOUT
            logger.error(f"Workflow {workflow.id} timed out")
        except Exception as e:
            workflow.status = WorkflowStatus.FAILED
            logger.error(f"Workflow {workflow.id} failed: {e}")

        workflow.completed_at = datetime.utcnow()
        self._completed_workflows[workflow.id] = workflow
        del self._running_workflows[workflow.id]

        return {
            "workflow_id": workflow.id,
            "status": workflow.status.value,
            "task_results": {
                task_id: {
                    "status": task.status.value,
                    "result": task.result,
                    "error": task.error,
                }
                for task_id, task in workflow.tasks.items()
            },
        }

    def _build_dependency_graph(
        self,
        tasks: Dict[str, WorkflowTask]
    ) -> Dict[str, Set[str]]:
        """构建依赖图"""
        graph = defaultdict(set)
        for task_id, task in tasks.items():
            for dep in task.dependencies:
                graph[task_id].add(dep)
        return dict(graph)

    def _get_ready_tasks(
        self,
        tasks: Dict[str, WorkflowTask],
        dependency_graph: Dict[str, Set[str]],
    ) -> List[WorkflowTask]:
        """获取就绪的任务"""
        ready = []
        for task_id, task in tasks.items():
            if task.status != TaskStatus.PENDING:
                continue

            # 检查依赖是否完成
            deps = dependency_graph.get(task_id, set())
            if all(tasks[dep].status == TaskStatus.COMPLETED for dep in deps):
                ready.append(task)

        return ready

    async def _execute_task(
        self,
        task: WorkflowTask,
        workflow: Workflow,
        context: Dict[str, Any],
    ) -> None:
        """执行任务"""
        task.status = TaskStatus.RUNNING
        task.start_time = datetime.utcnow()

        handler = self._action_handlers.get(task.action)
        if not handler:
            task.status = TaskStatus.FAILED
            task.error = f"Unknown action: {task.action}"
            task.end_time = datetime.utcnow()
            return

        # 替换参数中的变量
        params = self._substitute_variables(task.params, context)

        # 执行动作（带重试）
        for attempt in range(task.retries + 1):
            try:
                result = await asyncio.wait_for(
                    handler(**params) if asyncio.iscoroutinefunction(handler) else handler(**params),
                    timeout=task.timeout
                )
                task.status = TaskStatus.COMPLETED
                task.result = result
                break
            except asyncio.TimeoutError:
                task.status = TaskStatus.FAILED
                task.error = "Task timed out"
            except Exception as e:
                if attempt < task.retries:
                    await asyncio.sleep(2 ** attempt)  # 指数退避
                    continue
                task.status = TaskStatus.FAILED
                task.error = str(e)

        task.end_time = datetime.utcnow()

    def _substitute_variables(
        self,
        params: Dict[str, Any],
        context: Dict[str, Any],
    ) -> Dict[str, Any]:
        """替换参数中的变量"""
        result = {}
        for key, value in params.items():
            if isinstance(value, str) and value.startswith("$"):
                var_name = value[1:]
                result[key] = context.get(var_name, value)
            else:
                result[key] = value
        return result

    def cancel_workflow(self, workflow_id: str) -> bool:
        """
        取消工作流

        Args:
            workflow_id: 工作流ID

        Returns:
            是否成功
        """
        workflow = self._running_workflows.get(workflow_id)
        if not workflow:
            return False

        workflow.status = WorkflowStatus.CANCELLED
        logger.info(f"Workflow {workflow_id} cancelled")
        return True

    def get_workflow_status(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        """
        获取工作流状态

        Args:
            workflow_id: 工作流ID

        Returns:
            状态信息
        """
        workflow = self._running_workflows.get(workflow_id) or self._completed_workflows.get(workflow_id)
        if not workflow:
            return None

        return {
            "workflow_id": workflow.id,
            "name": workflow.name,
            "status": workflow.status.value,
            "created_at": workflow.created_at.isoformat(),
            "started_at": workflow.started_at.isoformat() if workflow.started_at else None,
            "completed_at": workflow.completed_at.isoformat() if workflow.completed_at else None,
            "task_count": len(workflow.tasks),
            "completed_tasks": sum(1 for t in workflow.tasks.values() if t.status == TaskStatus.COMPLETED),
        }


# 便捷函数
def create_workflow_executor() -> WorkflowExecutor:
    """
    创建工作流执行器的工厂函数

    Returns:
        工作流执行器实例
    """
    return WorkflowExecutor()
