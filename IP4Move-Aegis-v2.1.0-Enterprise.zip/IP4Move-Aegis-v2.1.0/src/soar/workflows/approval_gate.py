"""
审批门模块

提供工作流中的审批门功能，支持人工审批、自动审批和升级策略。
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict
import uuid

# 配置日志
logger = logging.getLogger(__name__)


class ApprovalStatus(Enum):
    """审批状态"""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    ESCALATED = "escalated"


class ApprovalType(Enum):
    """审批类型"""
    MANUAL = "manual"
    AUTO = "auto"
    CONDITIONAL = "conditional"


@dataclass
class ApprovalRequest:
    """审批请求"""
    id: str
    workflow_id: str
    task_id: str
    title: str
    description: str
    requester: str
    approvers: List[str]
    status: ApprovalStatus = ApprovalStatus.PENDING
    type: ApprovalType = ApprovalType.MANUAL
    created_at: datetime = field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = None
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    comments: List[Dict[str, Any]] = field(default_factory=list)
    escalation_level: int = 0


class ApprovalGate:
    """
    审批门

    提供工作流中的审批功能，支持人工审批、自动审批和升级策略。

    Example:
        >>> gate = ApprovalGate()
        >>>
        >>> # 创建审批请求
        >>> request = await gate.create_request(
        ...     workflow_id="wf-001",
        ...     task_id="task-001",
        ...     title="Approve IP Block",
        ...     description="Block IP 192.168.1.100",
        ...     requester="system",
        ...     approvers=["admin1", "admin2"],
        ... )
        >>>
        >>> # 审批
        >>> await gate.approve(request.id, "admin1", "Approved")
    """

    def __init__(
        self,
        default_timeout: int = 3600,
        auto_approve_conditions: Optional[List[Callable]] = None,
    ):
        """
        初始化审批门

        Args:
            default_timeout: 默认超时时间（秒）
            auto_approve_conditions: 自动审批条件列表
        """
        self.default_timeout = default_timeout
        self.auto_approve_conditions = auto_approve_conditions or []
        self._requests: Dict[str, ApprovalRequest] = {}
        self._escalation_policies: Dict[str, Dict[str, Any]] = {}
        self._approval_handlers: List[Callable] = []

    async def create_request(
        self,
        workflow_id: str,
        task_id: str,
        title: str,
        description: str,
        requester: str,
        approvers: List[str],
        approval_type: ApprovalType = ApprovalType.MANUAL,
        timeout: Optional[int] = None,
        escalation_policy: Optional[str] = None,
    ) -> ApprovalRequest:
        """
        创建审批请求

        Args:
            workflow_id: 工作流ID
            task_id: 任务ID
            title: 标题
            description: 描述
            requester: 请求者
            approvers: 审批人列表
            approval_type: 审批类型
            timeout: 超时时间（秒）
            escalation_policy: 升级策略ID

        Returns:
            审批请求对象
        """
        request_id = f"APR-{uuid.uuid4().hex[:12].upper()}"
        expires_at = datetime.utcnow() + timedelta(seconds=timeout or self.default_timeout)

        request = ApprovalRequest(
            id=request_id,
            workflow_id=workflow_id,
            task_id=task_id,
            title=title,
            description=description,
            requester=requester,
            approvers=approvers,
            type=approval_type,
            expires_at=expires_at,
        )

        self._requests[request_id] = request

        # 检查自动审批
        if approval_type == ApprovalType.AUTO:
            await self._check_auto_approval(request)
        elif approval_type == ApprovalType.CONDITIONAL:
            await self._check_conditional_approval(request)

        # 启动超时计时器
        asyncio.create_task(self._timeout_watcher(request_id))

        # 启动升级计时器
        if escalation_policy:
            asyncio.create_task(self._escalation_watcher(request_id, escalation_policy))

        logger.info(f"Approval request created: {request_id}")
        return request

    async def approve(
        self,
        request_id: str,
        approver: str,
        comment: str = "",
    ) -> Dict[str, Any]:
        """
        批准请求

        Args:
            request_id: 请求ID
            approver: 审批人
            comment: 备注

        Returns:
            操作结果
        """
        request = self._requests.get(request_id)
        if not request:
            return {"success": False, "error": "Request not found"}

        if request.status != ApprovalStatus.PENDING:
            return {"success": False, "error": f"Request is already {request.status.value}"}

        if approver not in request.approvers:
            return {"success": False, "error": "Not an authorized approver"}

        request.status = ApprovalStatus.APPROVED
        request.approved_by = approver
        request.approved_at = datetime.utcnow()
        request.comments.append({
            "author": approver,
            "comment": comment,
            "action": "approved",
            "timestamp": datetime.utcnow().isoformat(),
        })

        await self._notify_approval_handlers(request)

        logger.info(f"Request {request_id} approved by {approver}")
        return {"success": True, "request_id": request_id}

    async def reject(
        self,
        request_id: str,
        approver: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        拒绝请求

        Args:
            request_id: 请求ID
            approver: 审批人
            reason: 拒绝原因

        Returns:
            操作结果
        """
        request = self._requests.get(request_id)
        if not request:
            return {"success": False, "error": "Request not found"}

        if request.status != ApprovalStatus.PENDING:
            return {"success": False, "error": f"Request is already {request.status.value}"}

        request.status = ApprovalStatus.REJECTED
        request.approved_by = approver
        request.approved_at = datetime.utcnow()
        request.comments.append({
            "author": approver,
            "comment": reason,
            "action": "rejected",
            "timestamp": datetime.utcnow().isoformat(),
        })

        await self._notify_approval_handlers(request)

        logger.info(f"Request {request_id} rejected by {approver}")
        return {"success": True, "request_id": request_id}

    async def _check_auto_approval(self, request: ApprovalRequest) -> None:
        """检查自动审批"""
        # 自动审批逻辑
        for condition in self.auto_approve_conditions:
            try:
                if condition(request):
                    await self.approve(request.id, "auto", "Auto-approved by condition")
                    return
            except Exception as e:
                logger.error(f"Auto-approval condition failed: {e}")

    async def _check_conditional_approval(self, request: ApprovalRequest) -> None:
        """检查条件审批"""
        # 条件审批逻辑
        pass

    async def _timeout_watcher(self, request_id: str) -> None:
        """超时监视器"""
        request = self._requests.get(request_id)
        if not request or not request.expires_at:
            return

        wait_seconds = (request.expires_at - datetime.utcnow()).total_seconds()
        if wait_seconds > 0:
            await asyncio.sleep(wait_seconds)

        request = self._requests.get(request_id)
        if request and request.status == ApprovalStatus.PENDING:
            request.status = ApprovalStatus.EXPIRED
            logger.warning(f"Request {request_id} expired")

    async def _escalation_watcher(
        self,
        request_id: str,
        policy_id: str,
    ) -> None:
        """升级监视器"""
        policy = self._escalation_policies.get(policy_id)
        if not policy:
            return

        for level in policy.get("levels", []):
            wait_minutes = level.get("wait_minutes", 30)
            await asyncio.sleep(wait_minutes * 60)

            request = self._requests.get(request_id)
            if not request or request.status != ApprovalStatus.PENDING:
                return

            # 升级
            request.escalation_level += 1
            new_approvers = level.get("approvers", [])
            request.approvers.extend(new_approvers)
            request.status = ApprovalStatus.ESCALATED

            logger.info(f"Request {request_id} escalated to level {request.escalation_level}")

    async def _notify_approval_handlers(self, request: ApprovalRequest) -> None:
        """通知审批处理器"""
        for handler in self._approval_handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(request)
                else:
                    handler(request)
            except Exception as e:
                logger.error(f"Approval handler failed: {e}")

    def register_approval_handler(self, handler: Callable) -> None:
        """
        注册审批处理器

        Args:
            handler: 处理器函数
        """
        self._approval_handlers.append(handler)

    def add_escalation_policy(
        self,
        policy_id: str,
        levels: List[Dict[str, Any]],
    ) -> None:
        """
        添加升级策略

        Args:
            policy_id: 策略ID
            levels: 升级级别配置
        """
        self._escalation_policies[policy_id] = {"levels": levels}

    def get_request(self, request_id: str) -> Optional[ApprovalRequest]:
        """
        获取审批请求

        Args:
            request_id: 请求ID

        Returns:
            审批请求对象
        """
        return self._requests.get(request_id)

    def list_pending_requests(
        self,
        approver: Optional[str] = None,
    ) -> List[ApprovalRequest]:
        """
        列出待审批请求

        Args:
            approver: 审批人过滤

        Returns:
            审批请求列表
        """
        requests = [
            r for r in self._requests.values()
            if r.status == ApprovalStatus.PENDING
        ]

        if approver:
            requests = [
                r for r in requests
                if approver in r.approvers
            ]

        return requests


# 便捷函数
def create_approval_gate(
    default_timeout: int = 3600,
) -> ApprovalGate:
    """
    创建审批门的工厂函数

    Args:
        default_timeout: 默认超时时间（秒）

    Returns:
        审批门实例
    """
    return ApprovalGate(default_timeout=default_timeout)
