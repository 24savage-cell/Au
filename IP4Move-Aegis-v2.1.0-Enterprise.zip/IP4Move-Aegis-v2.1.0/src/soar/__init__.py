"""
SOAR自动化响应编排模块

提供安全编排自动化与响应(SOAR)功能，包括：
- 剧本引擎（YAML解析、步骤执行、条件分支、并行执行）
- 响应剧本（IP封禁、账号锁定、事件遏制）
- 响应动作（网络操作、终端操作、身份操作）
- 工作流执行器（DAG执行、重试、超时、审批门）
- 外部集成（防火墙API、EDR连接器、工单系统）
"""

from .playbooks.playbook_engine import PlaybookEngine, Playbook
from .playbooks.ip_blocking import IPBlockingPlaybook
from .playbooks.account_lockdown import AccountLockdownPlaybook
from .playbooks.incident_containment import IncidentContainmentPlaybook
from .actions.network_actions import NetworkActions
from .actions.endpoint_actions import EndpointActions
from .actions.identity_actions import IdentityActions
from .workflows.workflow_executor import WorkflowExecutor, Workflow
from .workflows.approval_gate import ApprovalGate
from .integration.firewall_api import FirewallAPI, PaloAltoConnector, FortinetConnector
from .integration.edr_connector import EDRConnector, CrowdStrikeConnector, SentinelOneConnector
from .integration.ticketing_system import TicketingSystem, JIRAConnector, ServiceNowConnector

__version__ = "1.0.0"
__all__ = [
    # Playbooks
    "PlaybookEngine",
    "Playbook",
    "IPBlockingPlaybook",
    "AccountLockdownPlaybook",
    "IncidentContainmentPlaybook",
    # Actions
    "NetworkActions",
    "EndpointActions",
    "IdentityActions",
    # Workflows
    "WorkflowExecutor",
    "Workflow",
    "ApprovalGate",
    # Integration
    "FirewallAPI",
    "PaloAltoConnector",
    "FortinetConnector",
    "EDRConnector",
    "CrowdStrikeConnector",
    "SentinelOneConnector",
    "TicketingSystem",
    "JIRAConnector",
    "ServiceNowConnector",
]
