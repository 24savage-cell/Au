"""
差分隐私指标 - 防止元数据泄露

修复问题:
1. Prometheus指标暴露流量模式
2. 节点在线时长可被分析
3. 入站/出站比例泄露信息

解决方案:
1. 添加拉普拉斯噪声
2. 本地聚合后上报
3. 时间分箱降低精度

版本: v2.1.0
"""

from __future__ import annotations

import logging
import math
import random
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable

logger = logging.getLogger(__name__)


# ============================================================================
# 差分隐私配置
# ============================================================================

@dataclass
class DifferentialPrivacyConfig:
    """差分隐私配置"""
    # 隐私预算 (ε)
    epsilon: float = 1.0
    
    # 敏感度 (查询结果最大变化)
    sensitivity: float = 1.0
    
    # 噪声类型
    noise_type: str = "laplace"  # laplace 或 gaussian
    
    # 聚合配置
    aggregation_window_s: float = 3600.0  # 1小时聚合
    time_bin_size_s: float = 300.0        # 5分钟时间分箱
    
    # 上报配置
    local_aggregation: bool = True         # 本地聚合
    report_interval_s: float = 3600.0      # 每小时上报一次
    min_samples_for_report: int = 10       # 最小样本数


# ============================================================================
# 拉普拉斯噪声
# ============================================================================

def laplace_noise(scale: float) -> float:
    """
    生成拉普拉斯噪声
    
    Lap(b) where b = sensitivity / epsilon
    
    概率密度: p(x) = (1/2b) * exp(-|x|/b)
    """
    u = random.random() - 0.5
    return -scale * math.copysign(1, u) * math.log(1 - 2 * abs(u))


def gaussian_noise(sigma: float) -> float:
    """
    生成高斯噪声
    
    用于(ε, δ)-差分隐私
    """
    return random.gauss(0, sigma)


def add_noise(
    value: float,
    epsilon: float,
    sensitivity: float,
    noise_type: str = "laplace",
) -> float:
    """
    添加差分隐私噪声
    
    Args:
        value: 原始值
        epsilon: 隐私预算
        sensitivity: 敏感度
        noise_type: 噪声类型
    
    Returns:
        加噪声后的值
    """
    if noise_type == "laplace":
        scale = sensitivity / epsilon
        noise = laplace_noise(scale)
    else:  # gaussian
        # 对于(ε, δ)-DP: σ = sensitivity * sqrt(2 * ln(1.25/δ)) / ε
        delta = 1e-5
        sigma = sensitivity * math.sqrt(2 * math.log(1.25 / delta)) / epsilon
        noise = gaussian_noise(sigma)
    
    return value + noise


# ============================================================================
# 时间分箱
# ============================================================================

def time_bin(timestamp: float, bin_size: float) -> int:
    """
    将时间戳分箱
    
    降低时间精度，防止精确时间分析
    """
    return int(timestamp // bin_size)


def bin_to_time_range(bin_id: int, bin_size: float) -> tuple:
    """将分箱ID转换为时间范围"""
    start = bin_id * bin_size
    end = (bin_id + 1) * bin_size
    return start, end


# ============================================================================
# 差分隐私计数器
# ============================================================================

class DPCounter:
    """
    差分隐私计数器
    
    对计数添加噪声，防止精确计数分析
    """
    
    def __init__(
        self,
        name: str,
        epsilon: float = 1.0,
        sensitivity: float = 1.0,
    ):
        self._name = name
        self._epsilon = epsilon
        self._sensitivity = sensitivity
        
        self._count = 0
        self._noisy_count: Optional[float] = None
    
    def increment(self, delta: int = 1):
        """增加计数"""
        self._count += delta
        self._noisy_count = None  # 清除缓存
    
    def decrement(self, delta: int = 1):
        """减少计数"""
        self._count -= delta
        self._noisy_count = None
    
    def get(self, add_noise: bool = True) -> float:
        """
        获取计数
        
        Args:
            add_noise: 是否添加噪声
        
        Returns:
            计数值 (可能带噪声)
        """
        if not add_noise:
            return self._count
        
        if self._noisy_count is None:
            self._noisy_count = add_noise(
                self._count,
                self._epsilon,
                self._sensitivity,
            )
        
        return self._noisy_count
    
    def reset(self):
        """重置计数"""
        self._count = 0
        self._noisy_count = None


# ============================================================================
# 差分隐私直方图
# ============================================================================

class DPHistogram:
    """
    差分隐私直方图
    
    对分布添加噪声，防止流量模式分析
    """
    
    def __init__(
        self,
        name: str,
        epsilon: float = 1.0,
        num_bins: int = 10,
    ):
        self._name = name
        self._epsilon = epsilon / num_bins  # 组合隐私预算
        self._num_bins = num_bins
        
        self._bins: Dict[int, int] = defaultdict(int)
        self._noisy_bins: Optional[Dict[int, float]] = None
    
    def add(self, value: float, min_val: float, max_val: float):
        """
        添加值到直方图
        
        Args:
            value: 值
            min_val: 最小值
            max_val: 最大值
        """
        if max_val <= min_val:
            return
        
        # 计算分箱
        normalized = (value - min_val) / (max_val - min_val)
        bin_id = min(int(normalized * self._num_bins), self._num_bins - 1)
        
        self._bins[bin_id] += 1
        self._noisy_bins = None
    
    def get(self, add_noise: bool = True) -> Dict[int, float]:
        """
        获取直方图
        
        Returns:
            分箱ID -> 计数
        """
        if not add_noise:
            return dict(self._bins)
        
        if self._noisy_bins is None:
            self._noisy_bins = {}
            for bin_id, count in self._bins.items():
                self._noisy_bins[bin_id] = add_noise(
                    count,
                    self._epsilon,
                    1.0,  # 敏感度=1 (单个用户影响一个分箱)
                )
        
        return self._noisy_bins
    
    def reset(self):
        """重置直方图"""
        self._bins.clear()
        self._noisy_bins = None


# ============================================================================
# 本地聚合器
# ============================================================================

class LocalAggregator:
    """
    本地聚合器
    
    在本地聚合数据后上报，减少上报频率
    """
    
    def __init__(
        self,
        config: DifferentialPrivacyConfig,
    ):
        self._config = config
        
        # 时间分箱数据
        self._time_bins: Dict[int, Dict[str, List[float]]] = defaultdict(
            lambda: defaultdict(list)
        )
        
        # 上报回调
        self._report_callback: Optional[Callable[[Dict], None]] = None
        
        # 上次上报时间
        self._last_report = time.time()
    
    def set_report_callback(self, callback: Callable[[Dict], None]):
        """设置上报回调"""
        self._report_callback = callback
    
    def record(self, metric_name: str, value: float, timestamp: Optional[float] = None):
        """
        记录指标值
        
        Args:
            metric_name: 指标名称
            value: 值
            timestamp: 时间戳 (None使用当前时间)
        """
        if timestamp is None:
            timestamp = time.time()
        
        # 时间分箱
        bin_id = time_bin(timestamp, self._config.time_bin_size_s)
        
        self._time_bins[bin_id][metric_name].append(value)
    
    def _aggregate_bin(self, bin_id: int) -> Dict[str, float]:
        """
        聚合单个时间分箱
        
        Returns:
            metric_name -> aggregated_value
        """
        result = {}
        
        for metric_name, values in self._time_bins[bin_id].items():
            if len(values) < self._config.min_samples_for_report:
                continue
            
            # 计算聚合值 (求和)
            total = sum(values)
            
            # 添加差分隐私噪声
            noisy_total = add_noise(
                total,
                self._config.epsilon,
                self._config.sensitivity,
                self._config.noise_type,
            )
            
            result[metric_name] = noisy_total
            result[f"{metric_name}_count"] = len(values)
            result[f"{metric_name}_avg"] = noisy_total / len(values) if values else 0
        
        return result
    
    def should_report(self) -> bool:
        """检查是否应该上报"""
        if not self._config.local_aggregation:
            return True
        
        return time.time() - self._last_report >= self._config.report_interval_s
    
    def get_report(self) -> Dict[str, Any]:
        """
        生成上报数据
        
        Returns:
            聚合后的指标数据
        """
        now = time.time()
        report = {
            "timestamp": now,
            "aggregation_window_s": self._config.aggregation_window_s,
            "time_bin_size_s": self._config.time_bin_size_s,
            "metrics": {},
        }
        
        # 聚合所有时间分箱
        for bin_id in sorted(self._time_bins.keys()):
            time_start, time_end = bin_to_time_range(
                bin_id, self._config.time_bin_size_s
            )
            
            # 只上报窗口内的数据
            if time_end < now - self._config.aggregation_window_s:
                continue
            
            aggregated = self._aggregate_bin(bin_id)
            
            if aggregated:
                report["metrics"][str(bin_id)] = {
                    "time_start": time_start,
                    "time_end": time_end,
                    "values": aggregated,
                }
        
        return report
    
    def report(self) -> Optional[Dict[str, Any]]:
        """
        执行上报
        
        Returns:
            上报数据，如果不需要上报返回None
        """
        if not self.should_report():
            return None
        
        report = self.get_report()
        
        # 清理旧数据
        cutoff = time.time() - self._config.aggregation_window_s
        old_bins = [
            bin_id for bin_id in self._time_bins
            if bin_id * self._config.time_bin_size_s < cutoff
        ]
        for bin_id in old_bins:
            del self._time_bins[bin_id]
        
        self._last_report = time.time()
        
        # 调用回调
        if self._report_callback:
            try:
                self._report_callback(report)
            except Exception as e:
                logger.error(f"上报回调失败: {e}")
        
        return report


# ============================================================================
# 差分隐私指标管理器
# ============================================================================

class DPMetricsManager:
    """
    差分隐私指标管理器
    
    整合所有差分隐私指标:
    - 计数器
    - 直方图
    - 本地聚合
    """
    
    def __init__(
        self,
        config: Optional[DifferentialPrivacyConfig] = None,
    ):
        self._config = config or DifferentialPrivacyConfig()
        
        # 计数器
        self._counters: Dict[str, DPCounter] = {}
        
        # 直方图
        self._histograms: Dict[str, DPHistogram] = {}
        
        # 本地聚合器
        self._aggregator = LocalAggregator(self._config)
    
    def counter(
        self,
        name: str,
        epsilon: Optional[float] = None,
    ) -> DPCounter:
        """
        获取或创建计数器
        
        Args:
            name: 计数器名称
            epsilon: 隐私预算 (None使用默认)
        """
        if name not in self._counters:
            self._counters[name] = DPCounter(
                name,
                epsilon=epsilon or self._config.epsilon,
                sensitivity=self._config.sensitivity,
            )
        return self._counters[name]
    
    def histogram(
        self,
        name: str,
        num_bins: int = 10,
        epsilon: Optional[float] = None,
    ) -> DPHistogram:
        """
        获取或创建直方图
        """
        if name not in self._histograms:
            self._histograms[name] = DPHistogram(
                name,
                epsilon=epsilon or self._config.epsilon,
                num_bins=num_bins,
            )
        return self._histograms[name]
    
    def record_metric(self, name: str, value: float):
        """
        记录指标值 (用于本地聚合)
        """
        self._aggregator.record(name, value)
    
    def get_all_metrics(self, add_noise: bool = True) -> Dict[str, Any]:
        """
        获取所有指标
        
        Returns:
            所有指标的快照
        """
        metrics = {
            "counters": {},
            "histograms": {},
            "aggregated": None,
        }
        
        # 计数器
        for name, counter in self._counters.items():
            metrics["counters"][name] = counter.get(add_noise)
        
        # 直方图
        for name, hist in self._histograms.items():
            metrics["histograms"][name] = hist.get(add_noise)
        
        # 本地聚合
        if self._aggregator.should_report():
            metrics["aggregated"] = self._aggregator.report()
        
        return metrics
    
    def reset_all(self):
        """重置所有指标"""
        for counter in self._counters.values():
            counter.reset()
        for hist in self._histograms.values():
            hist.reset()


# ============================================================================
# Prometheus集成
# ============================================================================

def create_dp_prometheus_metrics(manager: DPMetricsManager):
    """
    创建差分隐私保护的Prometheus指标
    
    返回的指标已添加噪声，可直接暴露
    """
    try:
        from prometheus_client import Counter, Histogram, Gauge
        
        # 包装Prometheus指标
        class DPCounterWrapper:
            """差分隐私计数器包装"""
            
            def __init__(self, name: str, dp_manager: DPMetricsManager):
                self._name = name
                self._dp = dp_manager
                self._counter = Counter(name, f"DP-protected counter: {name}")
                self._dp_counter = dp_manager.counter(name)
            
            def inc(self, amount: float = 1.0):
                self._counter.inc(amount)
                self._dp_counter.increment(int(amount))
            
            def get_noisy(self) -> float:
                return self._dp_counter.get(add_noise=True)
        
        class DPHistogramWrapper:
            """差分隐私直方图包装"""
            
            def __init__(self, name: str, dp_manager: DPMetricsManager, buckets: tuple = None):
                self._name = name
                self._dp = dp_manager
                buckets = buckets or (0.1, 0.5, 1.0, 5.0, 10.0, float('inf'))
                self._histogram = Histogram(name, f"DP-protected histogram: {name}", buckets=buckets)
                self._dp_hist = dp_manager.histogram(name, num_bins=len(buckets))
            
            def observe(self, value: float):
                self._histogram.observe(value)
                # 这里简化处理，实际应根据bucket边界分箱
            
            def get_noisy(self) -> Dict[int, float]:
                return self._dp_hist.get(add_noise=True)
        
        return DPCounterWrapper, DPHistogramWrapper
        
    except ImportError:
        logger.warning("prometheus_client未安装")
        return None, None
