"""
隐私计算与差分隐私增强模块 (Privacy Computing & Differential Privacy Enhanced Module)

本模块实现了 IP4Move Aegis 系统中的隐私计算核心功能，包括：
1. 差分隐私信誉系统 - 通过拉普拉斯/高斯机制保护信誉查询隐私
2. 联邦学习式攻击检测 - 在不共享原始数据的前提下协作检测攻击
3. 安全多方计算(SMC) - 基于秘密共享的分布式安全计算
4. 隐私预算管理器 - 管理和跟踪差分隐私预算消耗

所有实现均遵循严格的隐私保护原则，确保系统安全性不依赖
于暴露用户敏感数据。

This module implements core privacy computing functionalities for the
IP4Move Aegis system:
1. Differential Privacy Reputation - protects reputation queries via
   Laplacian/Gaussian mechanisms
2. Federated Anomaly Detection - collaborative attack detection without
   sharing raw data
3. Secure Multi-Party Computation (SMC) - distributed secure computation
   based on secret sharing
4. Privacy Budget Manager - manages and tracks differential privacy
   budget consumption
"""

from __future__ import annotations

import hashlib
import heapq
import json
import logging
import math
import os
import random
import secrets
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Set,
    Tuple,
)

logger = logging.getLogger(__name__)


# ============================================================================
# 工具类和枚举定义 (Utility Classes and Enumerations)
# ============================================================================


class PrivacyMechanism(Enum):
    """隐私噪声机制枚举 (Privacy noise mechanism enumeration)"""
    LAPLACIAN = "laplacian"       # 拉普拉斯机制 - 适用于纯差分隐私
    GAUSSIAN = "gaussian"         # 高斯机制 - 适用于(epsilon, delta)-差分隐私
    EXPONENTIAL = "exponential"   # 指数机制 - 适用于离散选择场景


class SMCProtocol(Enum):
    """安全多方计算协议枚举 (SMC protocol enumeration)"""
    ADDITIVE_SECRET_SHARING = "additive_secret_sharing"  # 加法秘密共享
    MULTIPLICATIVE = "multiplicative"                     # 乘法协议
    COMPARISON = "comparison"                             # 比较协议


class ModelUpdateStatus(Enum):
    """模型更新状态枚举 (Model update status enumeration)"""
    ACCEPTED = "accepted"         # 已接受
    REJECTED = "rejected"         # 已拒绝
    PENDING = "pending"           # 待验证
    POISONOUS = "poisonous"       # 检测到投毒攻击


@dataclass
class PrivacyBudget:
    """隐私预算数据结构 (Privacy budget data structure)

    跟踪单个查询类型的隐私预算消耗情况。
    Tracks privacy budget consumption for a single query type.

    Attributes:
        total_epsilon: 总隐私预算 (epsilon)
        used_epsilon: 已消耗的隐私预算
        total_delta: 总失败概率预算 (delta)
        used_delta: 已消耗的失败概率预算
        query_type: 查询类型标识
        last_reset: 上次预算重置时间
    """
    total_epsilon: float
    total_delta: float
    used_epsilon: float = 0.0
    used_delta: float = 0.0
    query_type: str = "default"
    last_reset: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def remaining_epsilon(self) -> float:
        """剩余的 epsilon 预算 (Remaining epsilon budget)"""
        return max(0.0, self.total_epsilon - self.used_epsilon)

    @property
    def remaining_delta(self) -> float:
        """剩余的 delta 预算 (Remaining delta budget)"""
        return max(0.0, self.total_delta - self.used_delta)

    @property
    def is_exhausted(self) -> bool:
        """预算是否已耗尽 (Whether the budget is exhausted)"""
        return self.remaining_epsilon <= 0.0 or self.remaining_delta <= 0.0

    @property
    def utilization_ratio(self) -> float:
        """预算使用率 (Budget utilization ratio)"""
        if self.total_epsilon <= 0:
            return 1.0
        return min(1.0, self.used_epsilon / self.total_epsilon)

    def consume(self, epsilon: float, delta: float = 0.0) -> bool:
        """消耗隐私预算 (Consume privacy budget)

        Args:
            epsilon: 要消耗的 epsilon 值
            delta: 要消耗的 delta 值

        Returns:
            bool: 预算是否充足并成功消耗
        """
        if self.remaining_epsilon < epsilon or self.remaining_delta < delta:
            return False
        self.used_epsilon += epsilon
        self.used_delta += delta
        return True

    def reset(self) -> None:
        """重置隐私预算 (Reset privacy budget)"""
        self.used_epsilon = 0.0
        self.used_delta = 0.0
        self.last_reset = datetime.now(timezone.utc)


@dataclass
class SMCParticipant:
    """SMC 参与者信息 (SMC participant information)

    Attributes:
        participant_id: 参与者唯一标识
        public_key: 参与者公钥（用于验证身份）
        secret_shares: 持有的秘密份额列表
        is_active: 是否活跃
        last_heartbeat: 最后心跳时间
    """
    participant_id: str
    public_key: str = ""
    secret_shares: List[int] = field(default_factory=list)
    is_active: bool = True
    last_heartbeat: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def update_heartbeat(self) -> None:
        """更新心跳时间 (Update heartbeat timestamp)"""
        self.last_heartbeat = datetime.now(timezone.utc)


@dataclass
class FederatedModelUpdate:
    """联邦学习模型更新 (Federated learning model update)

    Attributes:
        node_id: 提交更新的节点标识
        model_params: 模型参数（序列化后的字典）
        num_samples: 本地训练使用的样本数
        timestamp: 提交时间戳
        status: 更新验证状态
        anomaly_score: 异常分数（0-1，越高越可疑）
        checksum: 参数校验和
    """
    node_id: str
    model_params: Dict[str, Any]
    num_samples: int
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    status: ModelUpdateStatus = ModelUpdateStatus.PENDING
    anomaly_score: float = 0.0
    checksum: str = ""

    def __post_init__(self) -> None:
        """初始化后计算校验和 (Compute checksum after initialization)"""
        if not self.checksum:
            self.checksum = self._compute_checksum()

    def _compute_checksum(self) -> str:
        """计算模型参数的校验和 (Compute checksum of model parameters)"""
        param_str = json.dumps(self.model_params, sort_keys=True)
        return hashlib.sha256(param_str.encode()).hexdigest()[:16]


# ============================================================================
# 差分隐私信誉系统 (Differential Privacy Reputation System)
# ============================================================================


class DifferentialPrivacyReputation:
    """差分隐私信誉系统 (Differential Privacy Reputation System)

    通过差分隐私机制保护节点信誉查询的隐私性。支持拉普拉斯机制和
    高斯机制两种噪声注入方式，并提供隐私预算管理功能。

    本系统确保：
    - 信誉查询结果中添加了 calibrated 噪声，防止推断单个节点的信誉
    - 隐私预算(epsilon)可配置，支持严格的隐私保证
    - 支持隐私预算的衰减和周期性重置

    Protects the privacy of node reputation queries through differential
    privacy mechanisms. Supports both Laplacian and Gaussian noise injection,
    with configurable privacy budget management.

    Example:
        >>> dpr = DifferentialPrivacyReputation(epsilon=1.0, sensitivity=1.0)
        >>> noisy_score = dpr.query_reputation("node_001", true_score=0.85)
        >>> print(f"带噪声的信誉分数: {noisy_score:.4f}")
    """

    def __init__(
        self,
        epsilon: float = 1.0,
        delta: float = 1e-5,
        sensitivity: float = 1.0,
        mechanism: PrivacyMechanism = PrivacyMechanism.LAPLACIAN,
        decay_factor: float = 0.95,
        reset_period_hours: int = 24,
    ) -> None:
        """初始化差分隐私信誉系统 (Initialize the DP reputation system)

        Args:
            epsilon: 隐私预算参数，值越小隐私保护越强但噪声越大
            delta: 失败概率参数（仅高斯机制需要），通常设为 1/n^2
            sensitivity: 查询灵敏度，即单个记录变化对查询结果的最大影响
            mechanism: 噪声机制类型（拉普拉斯或高斯）
            decay_factor: 隐私预算衰减因子（每次查询后 epsilon 乘以此因子）
            reset_period_hours: 隐私预算重置周期（小时）
        """
        if epsilon <= 0:
            raise ValueError(f"epsilon 必须为正数，当前值: {epsilon}")
        if delta < 0 or delta >= 1:
            raise ValueError(f"delta 必须在 [0, 1) 范围内，当前值: {delta}")
        if sensitivity <= 0:
            raise ValueError(f"sensitivity 必须为正数，当前值: {sensitivity}")
        if not (0 < decay_factor <= 1):
            raise ValueError(f"decay_factor 必须在 (0, 1] 范围内，当前值: {decay_factor}")

        self._epsilon = epsilon
        self._delta = delta
        self._sensitivity = sensitivity
        self._mechanism = mechanism
        self._decay_factor = decay_factor
        self._reset_period = timedelta(hours=reset_period_hours)

        # 信誉存储（真实值）- 内部使用，不对外暴露
        # Reputation storage (true values) - internal use only
        self._reputations: Dict[str, float] = {}

        # 查询计数器
        self._query_count: int = 0

        # 上次重置时间
        self._last_reset: datetime = datetime.now(timezone.utc)

        # 线程锁，确保并发安全
        self._lock = threading.RLock()

        # 审计日志
        self._audit_log: List[Dict[str, Any]] = []

        logger.info(
            "差分隐私信誉系统初始化完成: epsilon=%.4f, delta=%.2e, "
            "sensitivity=%.2f, mechanism=%s",
            epsilon, delta, sensitivity, mechanism.value,
        )

    # ------------------------------------------------------------------
    # 噪声生成方法 (Noise Generation Methods)
    # ------------------------------------------------------------------

    def _laplacian_noise(self, scale: float) -> float:
        """生成拉普拉斯噪声 (Generate Laplacian noise)

        拉普拉斯分布的概率密度函数为:
            f(x) = (1 / 2b) * exp(-|x| / b)
        其中 b = sensitivity / epsilon

        Args:
            scale: 拉普拉斯分布的尺度参数 b

        Returns:
            float: 从拉普拉斯分布中采样的噪声值
        """
        # 使用逆变换采样法生成拉普拉斯随机变量
        # Inverse transform sampling for Laplacian distribution
        u = random.uniform(-0.5, 0.5)
        return -scale * math.copysign(1.0, u) * math.log(1.0 - 2.0 * abs(u))

    def _gaussian_noise(self, sigma: float) -> float:
        """生成高斯噪声 (Generate Gaussian noise)

        高斯机制满足 (epsilon, delta)-差分隐私，其中:
            sigma = sensitivity * sqrt(2 * ln(1.25 / delta)) / epsilon

        Args:
            sigma: 高斯分布的标准差

        Returns:
            float: 从高斯分布中采样的噪声值
        """
        # Box-Muller 变换生成标准正态分布随机变量
        # Box-Muller transform for standard normal distribution
        u1 = random.random()
        u2 = random.random()
        # 避免 log(0) 的情况
        u1 = max(u1, 1e-15)
        z = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
        return sigma * z

    def _add_noise(self, value: float) -> float:
        """为查询值添加差分隐私噪声 (Add differential privacy noise to query value)

        根据配置的机制类型选择拉普拉斯或高斯噪声。

        Args:
            value: 原始查询值

        Returns:
            float: 添加噪声后的值
        """
        if self._mechanism == PrivacyMechanism.LAPLACIAN:
            # 拉普拉斯机制: b = sensitivity / epsilon
            scale = self._sensitivity / self._epsilon
            noise = self._laplacian_noise(scale)
        elif self._mechanism == PrivacyMechanism.GAUSSIAN:
            # 高斯机制: sigma = sensitivity * sqrt(2 * ln(1.25/delta)) / epsilon
            sigma = (self._sensitivity
                     * math.sqrt(2.0 * math.log(1.25 / self._delta))
                     / self._epsilon)
            noise = self._gaussian_noise(sigma)
        else:
            raise ValueError(f"不支持的噪声机制: {self._mechanism}")

        noisy_value = value + noise
        logger.debug(
            "添加噪声: 原始值=%.4f, 噪声=%.4f, 结果=%.4f, 机制=%s",
            value, noise, noisy_value, self._mechanism.value,
        )
        return noisy_value

    # ------------------------------------------------------------------
    # 隐私预算管理 (Privacy Budget Management)
    # ------------------------------------------------------------------

    def _check_and_reset_budget(self) -> None:
        """检查并按需重置隐私预算 (Check and reset privacy budget if needed)

        如果距离上次重置超过配置的周期，则自动重置预算。
        """
        now = datetime.now(timezone.utc)
        if now - self._last_reset >= self._reset_period:
            with self._lock:
                self._epsilon = self._epsilon  # epsilon 保持不变
                self._query_count = 0
                self._last_reset = now
                logger.info("隐私预算已周期性重置")

    def _decay_epsilon(self) -> None:
        """应用隐私预算衰减 (Apply privacy budget decay)

        每次查询后，epsilon 乘以衰减因子，逐渐收紧隐私保护。
        """
        old_epsilon = self._epsilon
        self._epsilon *= self._decay_factor
        logger.debug(
            "隐私预算衰减: %.6f -> %.6f (衰减因子=%.4f)",
            old_epsilon, self._epsilon, self._decay_factor,
        )

    def reset_budget(self, new_epsilon: Optional[float] = None) -> None:
        """手动重置隐私预算 (Manually reset privacy budget)

        Args:
            new_epsilon: 可选的新 epsilon 值，为 None 则保持原值
        """
        with self._lock:
            if new_epsilon is not None:
                if new_epsilon <= 0:
                    raise ValueError(f"new_epsilon 必须为正数，当前值: {new_epsilon}")
                self._epsilon = new_epsilon
            self._query_count = 0
            self._last_reset = datetime.now(timezone.utc)
            logger.info("隐私预算已手动重置, epsilon=%.4f", self._epsilon)

    @property
    def current_epsilon(self) -> float:
        """获取当前有效的 epsilon 值 (Get current effective epsilon value)"""
        return self._epsilon

    @property
    def query_count(self) -> int:
        """获取总查询次数 (Get total query count)"""
        return self._query_count

    # ------------------------------------------------------------------
    # 信誉管理 (Reputation Management)
    # ------------------------------------------------------------------

    def update_reputation(self, node_id: str, score: float) -> None:
        """更新节点信誉分数（内部操作，不受差分隐私保护）

        更新内部存储的信誉分数。此操作仅在系统内部调用，
        不对外暴露真实值。

        Args:
            node_id: 节点唯一标识
            score: 新的信誉分数（通常在 [0, 1] 范围内）
        """
        if not node_id:
            raise ValueError("node_id 不能为空")
        if not (0.0 <= score <= 1.0):
            logger.warning(
                "信誉分数 %.4f 不在 [0,1] 范围内，将进行裁剪", score
            )
            score = max(0.0, min(1.0, score))

        with self._lock:
            self._reputations[node_id] = score
            logger.debug("更新节点 %s 信誉分数: %.4f", node_id, score)

    def query_reputation(self, node_id: str) -> float:
        """查询节点信誉分数（差分隐私保护）

        返回添加了 calibrated 噪声的信誉分数，确保满足差分隐私保证。
        如果节点不存在，返回添加噪声后的默认值 0.5。

        Args:
            node_id: 节点唯一标识

        Returns:
            float: 添加差分隐私噪声后的信誉分数
        """
        if not node_id:
            raise ValueError("node_id 不能为空")

        with self._lock:
            self._check_and_reset_budget()

            # 获取真实信誉分数（不存在则使用默认值）
            true_score = self._reputations.get(node_id, 0.5)

            # 添加差分隐私噪声
            noisy_score = self._add_noise(true_score)

            # 裁剪到 [0, 1] 范围
            noisy_score = max(0.0, min(1.0, noisy_score))

            # 更新查询计数并衰减预算
            self._query_count += 1
            self._decay_epsilon()

            # 记录审计日志
            self._audit_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "query_reputation",
                "node_id": node_id,
                "epsilon_used": self._epsilon,
                "mechanism": self._mechanism.value,
            })

            logger.info(
                "信誉查询: node=%s, 带噪声分数=%.4f, 当前epsilon=%.6f",
                node_id, noisy_score, self._epsilon,
            )
            return noisy_score

    def query_reputation_batch(
        self, node_ids: List[str]
    ) -> Dict[str, float]:
        """批量查询节点信誉分数（差分隐私保护）

        使用组合定理（sequential composition），批量查询的
        总隐私预算为各次查询 epsilon 之和。

        Args:
            node_ids: 节点标识列表

        Returns:
            Dict[str, float]: 节点标识到带噪声信誉分数的映射
        """
        if not node_ids:
            return {}

        results: Dict[str, float] = {}
        for node_id in node_ids:
            try:
                results[node_id] = self.query_reputation(node_id)
            except Exception as e:
                logger.error("查询节点 %s 信誉失败: %s", node_id, e)
                results[node_id] = 0.5  # 返回默认值

        logger.info(
            "批量信誉查询完成: %d 个节点, 总隐私消耗约 %.4f",
            len(node_ids), self._epsilon * len(node_ids),
        )
        return results

    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取审计日志 (Get audit log)

        Args:
            limit: 返回的最大日志条数

        Returns:
            List[Dict]: 审计日志列表
        """
        with self._lock:
            return self._audit_log[-limit:]


# ============================================================================
# 联邦学习式攻击检测器 (Federated Learning-based Anomaly Detector)
# ============================================================================


class FederatedAnomalyDetector:
    """联邦学习式攻击检测器 (Federated Learning-based Anomaly Detector)

    通过联邦学习的方式在多个节点间协作训练攻击检测模型，而无需
    共享原始流量数据。每个节点在本地训练模型，仅共享模型参数（梯度），
    通过 FedAvg 算法聚合全局模型。

    安全特性：
    - 梯度噪声注入：保护本地训练数据的隐私
    - 投毒攻击检测：识别恶意节点提交的异常模型更新
    - 模型更新验证：基于统计方法验证模型参数的合理性

    Example:
        >>> detector = FederatedAnomalyDetector(
        ...     num_features=10,
        ...     noise_multiplier=1.1,
        ...     poison_threshold=3.0,
        ... )
        >>> detector.add_node("node_001")
        >>> detector.submit_update("node_001", {"w": [0.1, 0.2, ...]}, num_samples=100)
        >>> global_model = detector.aggregate_models()
    """

    def __init__(
        self,
        num_features: int = 10,
        learning_rate: float = 0.01,
        noise_multiplier: float = 1.1,
        clip_norm: float = 1.0,
        poison_threshold: float = 3.0,
        min_participants: int = 3,
        max_rounds: int = 1000,
    ) -> None:
        """初始化联邦学习式攻击检测器 (Initialize the federated anomaly detector)

        Args:
            num_features: 输入特征维度
            learning_rate: 学习率
            noise_multiplier: 梯度噪声乘数（DP-SGD 参数）
            clip_norm: 梯度裁剪范数
            poison_threshold: 投毒攻击检测阈值（标准差倍数）
            min_participants: 聚合所需的最少参与者数
            max_rounds: 最大训练轮数
        """
        if num_features <= 0:
            raise ValueError(f"num_features 必须为正数，当前值: {num_features}")
        if learning_rate <= 0:
            raise ValueError(f"learning_rate 必须为正数，当前值: {learning_rate}")
        if noise_multiplier < 0:
            raise ValueError(f"noise_multiplier 不能为负数，当前值: {noise_multiplier}")
        if poison_threshold <= 0:
            raise ValueError(f"poison_threshold 必须为正数，当前值: {poison_threshold}")

        self._num_features = num_features
        self._learning_rate = learning_rate
        self._noise_multiplier = noise_multiplier
        self._clip_norm = clip_norm
        self._poison_threshold = poison_threshold
        self._min_participants = min_participants
        self._max_rounds = max_rounds

        # 全局模型参数（简化为权重向量和偏置）
        # Global model parameters (simplified as weight vector and bias)
        self._global_weights: List[float] = [0.0] * num_features
        self._global_bias: float = 0.0

        # 注册的节点
        self._nodes: Set[str] = set()

        # 待聚合的模型更新
        self._pending_updates: Dict[str, FederatedModelUpdate] = {}

        # 历史模型参数（用于投毒检测）
        self._weight_history: List[List[float]] = []

        # 训练轮次计数
        self._round_count: int = 0

        # 节点信誉（基于历史更新的质量）
        self._node_reputation: Dict[str, float] = {}

        # 线程锁
        self._lock = threading.RLock()

        logger.info(
            "联邦学习式攻击检测器初始化完成: features=%d, lr=%.4f, "
            "noise_mult=%.2f, poison_thresh=%.2f",
            num_features, learning_rate, noise_multiplier, poison_threshold,
        )

    # ------------------------------------------------------------------
    # 节点管理 (Node Management)
    # ------------------------------------------------------------------

    def add_node(self, node_id: str) -> bool:
        """注册参与联邦学习的节点 (Register a node for federated learning)

        Args:
            node_id: 节点唯一标识

        Returns:
            bool: 是否成功注册（已存在则返回 False）
        """
        if not node_id:
            raise ValueError("node_id 不能为空")

        with self._lock:
            if node_id in self._nodes:
                logger.warning("节点 %s 已注册", node_id)
                return False
            self._nodes.add(node_id)
            self._node_reputation[node_id] = 1.0  # 初始信誉为满分
            logger.info("节点 %s 已注册到联邦学习", node_id)
            return True

    def remove_node(self, node_id: str) -> bool:
        """移除联邦学习节点 (Remove a node from federated learning)

        Args:
            node_id: 节点唯一标识

        Returns:
            bool: 是否成功移除
        """
        with self._lock:
            if node_id not in self._nodes:
                return False
            self._nodes.discard(node_id)
            self._pending_updates.pop(node_id, None)
            self._node_reputation.pop(node_id, None)
            logger.info("节点 %s 已从联邦学习中移除", node_id)
            return True

    @property
    def registered_nodes(self) -> Set[str]:
        """获取已注册的节点集合 (Get registered node set)"""
        return self._nodes.copy()

    # ------------------------------------------------------------------
    # 本地模型训练辅助 (Local Model Training Helpers)
    # ------------------------------------------------------------------

    def _clip_gradient(self, gradient: List[float]) -> List[float]:
        """梯度裁剪 (Gradient clipping)

        将梯度向量的 L2 范数裁剪到 clip_norm 以内，
        限制单个样本对模型更新的最大影响。

        Args:
            gradient: 原始梯度向量

        Returns:
            List[float]: 裁剪后的梯度向量
        """
        # 计算 L2 范数
        norm = math.sqrt(sum(g * g for g in gradient))
        if norm <= self._clip_norm or norm == 0:
            return gradient

        # 按比例缩放
        scale = self._clip_norm / norm
        return [g * scale for g in gradient]

    def _inject_gradient_noise(self, gradient: List[float]) -> List[float]:
        """梯度噪声注入 (Gradient noise injection)

        为梯度添加 calibrated 高斯噪声，实现 DP-SGD（差分隐私随机梯度下降）。
        噪声标准差 = noise_multiplier * clip_norm

        Args:
            gradient: 裁剪后的梯度向量

        Returns:
            List[float]: 添加噪声后的梯度向量
        """
        if self._noise_multiplier <= 0:
            return gradient

        sigma = self._noise_multiplier * self._clip_norm
        noisy_gradient = []
        for g in gradient:
            # Box-Muller 变换生成高斯噪声
            u1 = max(random.random(), 1e-15)
            u2 = random.random()
            z = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
            noisy_gradient.append(g + sigma * z)

        return noisy_gradient

    def simulate_local_training(
        self,
        node_id: str,
        features: List[float],
        label: int,
    ) -> Dict[str, Any]:
        """模拟本地模型训练（简化版逻辑回归）

        在实际部署中，每个节点会在本地数据上训练模型。
        这里提供一个简化的训练模拟，用于演示和测试。

        Args:
            node_id: 节点标识
            features: 输入特征向量
            label: 二分类标签 (0 或 1)

        Returns:
            Dict[str, Any]: 包含模型参数的字典
        """
        if len(features) != self._num_features:
            raise ValueError(
                f"特征维度不匹配: 期望 {self._num_features}, 实际 {len(features)}"
            )
        if label not in (0, 1):
            raise ValueError(f"label 必须为 0 或 1，当前值: {label}")

        # 简化的 sigmoid 函数
        def sigmoid(x: float) -> float:
            if x >= 0:
                return 1.0 / (1.0 + math.exp(-x))
            else:
                ex = math.exp(x)
                return ex / (1.0 + ex)

        # 前向传播
        z = sum(w * f for w, f in zip(self._global_weights, features)) + self._global_bias
        prediction = sigmoid(z)

        # 计算梯度（二元交叉熵损失）
        error = prediction - label
        gradient = [error * f for f in features]
        bias_gradient = error

        # 梯度裁剪
        gradient = self._clip_gradient(gradient)

        # 梯度噪声注入（保护本地数据隐私）
        gradient = self._inject_gradient_noise(gradient)

        # 更新本地模型参数
        local_weights = [
            w - self._learning_rate * g
            for w, g in zip(self._global_weights, gradient)
        ]
        local_bias = self._global_bias - self._learning_rate * bias_gradient

        logger.debug(
            "节点 %s 本地训练完成: loss=%.4f, prediction=%.4f",
            node_id, -label * math.log(max(prediction, 1e-15))
            - (1 - label) * math.log(max(1 - prediction, 1e-15)),
            prediction,
        )

        return {
            "weights": local_weights,
            "bias": local_bias,
            "num_samples": 1,
            "gradient_norm": math.sqrt(sum(g * g for g in gradient)),
        }

    # ------------------------------------------------------------------
    # 模型更新提交与验证 (Model Update Submission & Validation)
    # ------------------------------------------------------------------

    def submit_update(
        self,
        node_id: str,
        model_params: Dict[str, Any],
        num_samples: int,
    ) -> ModelUpdateStatus:
        """提交本地模型更新 (Submit local model update)

        Args:
            node_id: 提交更新的节点标识
            model_params: 模型参数字典，包含 "weights" 和 "bias"
            num_samples: 本地训练使用的样本数

        Returns:
            ModelUpdateStatus: 更新验证状态
        """
        if node_id not in self._nodes:
            logger.error("节点 %s 未注册", node_id)
            return ModelUpdateStatus.REJECTED

        if num_samples <= 0:
            logger.error("节点 %s 提交的样本数为 0", node_id)
            return ModelUpdateStatus.REJECTED

        # 验证模型参数格式
        weights = model_params.get("weights", [])
        if len(weights) != self._num_features:
            logger.error(
                "节点 %s 权重维度不匹配: 期望 %d, 实际 %d",
                node_id, self._num_features, len(weights),
            )
            return ModelUpdateStatus.REJECTED

        # 创建模型更新对象
        update = FederatedModelUpdate(
            node_id=node_id,
            model_params=model_params,
            num_samples=num_samples,
        )

        # 验证模型更新（投毒检测）
        anomaly_score = self._detect_poisoning(update)
        update.anomaly_score = anomaly_score

        if anomaly_score > self._poison_threshold:
            update.status = ModelUpdateStatus.POISONOUS
            # 降低节点信誉
            self._node_reputation[node_id] = max(
                0.0, self._node_reputation.get(node_id, 1.0) - 0.3
            )
            logger.warning(
                "检测到可能的投毒攻击: node=%s, anomaly_score=%.4f",
                node_id, anomaly_score,
            )
        else:
            update.status = ModelUpdateStatus.ACCEPTED

        with self._lock:
            self._pending_updates[node_id] = update

        return update.status

    def _detect_poisoning(self, update: FederatedModelUpdate) -> float:
        """投毒攻击检测 (Poisoning attack detection)

        通过统计方法检测模型更新是否异常：
        1. 计算权重更新的 L2 范数
        2. 与历史更新的统计分布比较
        3. 使用 Z-score 衡量异常程度

        Args:
            update: 待检测的模型更新

        Returns:
            float: 异常分数（0-1，越高越可疑）
        """
        weights = update.model_params.get("weights", [])

        # 计算权重更新的 L2 范数
        weight_diffs = [
            w - gw for w, gw in zip(weights, self._global_weights)
        ]
        update_norm = math.sqrt(sum(d * d for d in weight_diffs))

        if not self._weight_history:
            # 没有历史数据时，使用简单的阈值判断
            return min(1.0, update_norm / (self._clip_norm * 10))

        # 计算历史权重更新的均值和标准差
        history_norms = []
        for hist_weights in self._weight_history:
            diffs = [
                hw - gw for hw, gw in zip(hist_weights, self._global_weights)
            ]
            history_norms.append(math.sqrt(sum(d * d for d in diffs)))

        if not history_norms:
            return min(1.0, update_norm / (self._clip_norm * 10))

        mean_norm = sum(history_norms) / len(history_norms)
        std_norm = math.sqrt(
            sum((n - mean_norm) ** 2 for n in history_norms) / len(history_norms)
        )

        if std_norm == 0:
            # 历史更新全部相同，任何偏差都视为异常
            return 1.0 if update_norm > 1e-6 else 0.0

        # Z-score 作为异常分数
        z_score = abs(update_norm - mean_norm) / std_norm
        # 归一化到 [0, 1]
        anomaly_score = min(1.0, z_score / self._poison_threshold)

        return anomaly_score

    # ------------------------------------------------------------------
    # 模型聚合 (Model Aggregation - FedAvg)
    # ------------------------------------------------------------------

    def aggregate_models(self) -> Optional[Dict[str, Any]]:
        """FedAvg 算法聚合模型参数 (Aggregate model parameters using FedAvg)

        使用加权平均（按样本数加权）聚合所有已接受的模型更新。

        Returns:
            Optional[Dict]: 聚合后的全局模型参数，参与者不足时返回 None
        """
        with self._lock:
            # 筛选已接受的更新
            accepted_updates = [
                u for u in self._pending_updates.values()
                if u.status == ModelUpdateStatus.ACCEPTED
            ]

            if len(accepted_updates) < self._min_participants:
                logger.warning(
                    "参与者不足: 已接受 %d, 最少需要 %d",
                    len(accepted_updates), self._min_participants,
                )
                return None

            # 计算总样本数（用于加权平均）
            total_samples = sum(u.num_samples for u in accepted_updates)
            if total_samples == 0:
                logger.error("总样本数为 0，无法聚合")
                return None

            # FedAvg: 加权平均
            new_weights = [0.0] * self._num_features
            new_bias = 0.0

            for update in accepted_updates:
                weight_factor = update.num_samples / total_samples
                weights = update.model_params.get("weights", [])
                bias = update.model_params.get("bias", 0.0)

                for i in range(self._num_features):
                    new_weights[i] += weight_factor * weights[i]
                new_bias += weight_factor * bias

            # 保存历史权重（用于后续投毒检测）
            self._weight_history.append(self._global_weights.copy())
            # 限制历史长度
            if len(self._weight_history) > 100:
                self._weight_history = self._weight_history[-100:]

            # 更新全局模型
            self._global_weights = new_weights
            self._global_bias = new_bias
            self._round_count += 1

            # 清空待聚合的更新
            self._pending_updates.clear()

            logger.info(
                "FedAvg 聚合完成: 轮次=%d, 参与者=%d, 总样本=%d",
                self._round_count, len(accepted_updates), total_samples,
            )

            return {
                "weights": self._global_weights.copy(),
                "bias": self._global_bias,
                "round": self._round_count,
                "participants": len(accepted_updates),
                "total_samples": total_samples,
            }

    def predict(self, features: List[float]) -> Tuple[int, float]:
        """使用全局模型进行预测 (Make prediction using global model)

        Args:
            features: 输入特征向量

        Returns:
            Tuple[int, float]: (预测标签, 置信度)
        """
        if len(features) != self._num_features:
            raise ValueError(
                f"特征维度不匹配: 期望 {self._num_features}, 实际 {len(features)}"
            )

        def sigmoid(x: float) -> float:
            if x >= 0:
                return 1.0 / (1.0 + math.exp(-x))
            else:
                ex = math.exp(x)
                return ex / (1.0 + ex)

        z = sum(w * f for w, f in zip(self._global_weights, features)) + self._global_bias
        probability = sigmoid(z)
        label = 1 if probability >= 0.5 else 0
        confidence = abs(probability - 0.5) * 2  # 归一化到 [0, 1]

        return label, confidence

    @property
    def round_count(self) -> int:
        """获取当前训练轮次 (Get current training round)"""
        return self._round_count

    @property
    def node_reputations(self) -> Dict[str, float]:
        """获取节点信誉分数 (Get node reputation scores)"""
        return self._node_reputation.copy()


# ============================================================================
# 安全多方计算 (Secure Multi-Party Computation)
# ============================================================================


class SecureMultiPartyComputation:
    """安全多方计算模块 (Secure Multi-Party Computation Module)

    基于秘密共享协议实现的安全多方计算，支持多个参与方在不暴露
    各自输入的前提下协作计算。主要功能包括：

    - 加法秘密共享：将秘密拆分为多个份额
    - 乘法协议：基于 Beaver 三元组的乘法运算
    - 比较协议：用于阈值判断的安全比较

    安全保证：
    - 诚实多数假设下（honest majority），协议是信息论安全的
    - 单个恶意参与者无法获取其他参与者的输入信息

    Example:
        >>> smc = SecureMultiPartyComputation(threshold=2, num_parties=3)
        >>> smc.add_participant("party_001")
        >>> smc.add_participant("party_002")
        >>> smc.add_participant("party_003")
        >>> shares = smc.distribute_secret(42)
        >>> result = smc.reconstruct_secret(shares)
    """

    def __init__(
        self,
        threshold: int = 2,
        num_parties: int = 3,
        prime_modulus: int = 2**31 - 1,
    ) -> None:
        """初始化安全多方计算模块 (Initialize SMC module)

        Args:
            threshold: 秘密重建所需的最少份额数 (t)
            num_parties: 参与方总数 (n)，必须 >= threshold
            prime_modulus: 素数模数，用于有限域运算
        """
        if threshold <= 0:
            raise ValueError(f"threshold 必须为正数，当前值: {threshold}")
        if num_parties < threshold:
            raise ValueError(
                f"num_parties (%d) 必须 >= threshold (%d)",
                num_parties, threshold,
            )
        if prime_modulus <= 1:
            raise ValueError(f"prime_modulus 必须大于 1，当前值: {prime_modulus}")

        self._threshold = threshold
        self._num_parties = num_parties
        self._prime = prime_modulus

        # 参与者管理
        self._participants: Dict[str, SMCParticipant] = {}

        # 线程锁
        self._lock = threading.RLock()

        # 通信消息缓冲区（模拟网络通信）
        self._message_buffer: List[Dict[str, Any]] = []

        # 操作日志
        self._operation_log: List[Dict[str, Any]] = []

        logger.info(
            "SMC 模块初始化完成: threshold=%d, parties=%d, prime=%d",
            threshold, num_parties, prime_modulus,
        )

    # ------------------------------------------------------------------
    # 参与者管理 (Participant Management)
    # ------------------------------------------------------------------

    def add_participant(
        self,
        participant_id: str,
        public_key: str = "",
    ) -> bool:
        """添加 SMC 参与者 (Add SMC participant)

        Args:
            participant_id: 参与者唯一标识
            public_key: 参与者公钥（可选，用于身份验证）

        Returns:
            bool: 是否成功添加
        """
        if not participant_id:
            raise ValueError("participant_id 不能为空")

        with self._lock:
            if len(self._participants) >= self._num_parties:
                logger.error("已达到最大参与者数: %d", self._num_parties)
                return False

            if participant_id in self._participants:
                logger.warning("参与者 %s 已存在", participant_id)
                return False

            self._participants[participant_id] = SMCParticipant(
                participant_id=participant_id,
                public_key=public_key,
            )
            logger.info(
                "SMC 参与者已添加: %s (当前 %d/%d)",
                participant_id, len(self._participants), self._num_parties,
            )
            return True

    def remove_participant(self, participant_id: str) -> bool:
        """移除 SMC 参与者 (Remove SMC participant)

        Args:
            participant_id: 参与者标识

        Returns:
            bool: 是否成功移除
        """
        with self._lock:
            if participant_id not in self._participants:
                return False
            del self._participants[participant_id]
            logger.info("SMC 参与者已移除: %s", participant_id)
            return True

    @property
    def participants(self) -> Dict[str, SMCParticipant]:
        """获取所有参与者信息 (Get all participant information)"""
        return {
            pid: SMCParticipant(
                participant_id=p.participant_id,
                public_key=p.public_key,
                is_active=p.is_active,
                last_heartbeat=p.last_heartbeat,
            )
            for pid, p in self._participants.items()
        }

    @property
    def is_ready(self) -> bool:
        """检查是否满足计算条件（参与者数 >= threshold）"""
        return len(self._participants) >= self._threshold

    # ------------------------------------------------------------------
    # 有限域运算 (Finite Field Operations)
    # ------------------------------------------------------------------

    def _mod(self, value: int) -> int:
        """模运算 (Modular arithmetic)

        Args:
            value: 输入值

        Returns:
            int: value mod prime
        """
        return value % self._prime

    def _mod_inverse(self, value: int) -> int:
        """模逆运算 (Modular inverse)

        使用扩展欧几里得算法计算 value 在模 prime 下的乘法逆元。

        Args:
            value: 输入值

        Returns:
            int: value^(-1) mod prime

        Raises:
            ValueError: 如果逆元不存在
        """
        if value == 0:
            raise ValueError("0 没有模逆元")

        # 扩展欧几里得算法
        original_prime = self._prime
        a, m = value % original_prime, original_prime
        x0, x1 = 1, 0

        while m != 0:
            q, a, m = a // m, m, a % m
            x0, x1 = x1, x0 - q * x1

        if a != 1:
            raise ValueError(f"模逆元不存在: gcd({value}, {original_prime}) = {a}")

        return x0 % original_prime

    # ------------------------------------------------------------------
    # 秘密共享 (Secret Sharing)
    # ------------------------------------------------------------------

    def distribute_secret(
        self,
        secret: int,
        participant_ids: Optional[List[str]] = None,
    ) -> Dict[str, int]:
        """基于 Shamir 秘密共享方案分发秘密 (Distribute secret using Shamir's scheme)

        将秘密 secret 拆分为 n 个份额，任意 t 个份额可重建秘密，
        但少于 t 个份额无法获取关于秘密的任何信息。

        使用多项式插值：构造一个 t-1 次随机多项式 f(x)，
        使得 f(0) = secret，份额为 f(1), f(2), ..., f(n)。

        Args:
            secret: 要共享的秘密（整数）
            participant_ids: 参与者 ID 列表，为 None 则使用所有已注册参与者

        Returns:
            Dict[str, int]: 参与者 ID 到秘密份额的映射

        Raises:
            RuntimeError: 参与者不足时抛出
        """
        if participant_ids is None:
            participant_ids = list(self._participants.keys())

        if len(participant_ids) < self._threshold:
            raise RuntimeError(
                f"参与者不足: 需要 {self._threshold} 个, 当前 {len(participant_ids)} 个"
            )

        # 将秘密限制在有限域内
        secret = self._mod(secret)

        # 生成 t-1 次随机多项式系数
        # f(x) = a_0 + a_1*x + a_2*x^2 + ... + a_{t-1}*x^{t-1}
        # 其中 a_0 = secret
        coefficients = [secret]
        for _ in range(self._threshold - 1):
            coefficients.append(secrets.randbelow(self._prime))

        # 为每个参与者计算份额 f(i)
        shares: Dict[str, int] = {}
        for idx, pid in enumerate(participant_ids):
            x = idx + 1  # 参与者的 x 坐标（从 1 开始）
            # 计算 f(x) = sum(a_i * x^i)
            share = 0
            x_power = 1
            for coeff in coefficients:
                share = self._mod(share + coeff * x_power)
                x_power = self._mod(x_power * x)
            shares[pid] = share

        # 记录操作日志
        self._log_operation("distribute_secret", {
            "num_shares": len(shares),
            "threshold": self._threshold,
        })

        logger.info(
            "秘密已分发: %d 个份额, 阈值=%d",
            len(shares), self._threshold,
        )
        return shares

    def reconstruct_secret(self, shares: Dict[str, int]) -> int:
        """使用 Lagrange 插值重建秘密 (Reconstruct secret using Lagrange interpolation)

        给定至少 t 个份额，使用 Lagrange 插值在 x=0 处重建秘密。

        Args:
            shares: 参与者 ID 到份额的映射

        Returns:
            int: 重建的秘密值

        Raises:
            RuntimeError: 份额不足时抛出
        """
        if len(shares) < self._threshold:
            raise RuntimeError(
                f"份额不足: 需要 {self._threshold} 个, 当前 {len(shares)} 个"
            )

        # 获取参与者 ID 列表，确定 x 坐标
        participant_ids = list(self._participants.keys())
        id_to_x: Dict[str, int] = {
            pid: idx + 1 for idx, pid in enumerate(participant_ids)
        }

        # Lagrange 插值
        secret = 0
        share_items = list(shares.items())

        for i, (pid_i, share_i) in enumerate(share_items):
            x_i = id_to_x.get(pid_i, i + 1)

            # 计算 Lagrange 基函数 L_i(0)
            numerator = 1
            denominator = 1
            for j, (pid_j, _) in enumerate(share_items):
                if i == j:
                    continue
                x_j = id_to_x.get(pid_j, j + 1)
                numerator = self._mod(numerator * (0 - x_j))
                denominator = self._mod(denominator * (x_i - x_j))

            # L_i(0) = numerator / denominator (mod prime)
            lagrange_coeff = self._mod(numerator * self._mod_inverse(denominator))
            secret = self._mod(secret + share_i * lagrange_coeff)

        self._log_operation("reconstruct_secret", {
            "num_shares_used": len(shares),
        })

        logger.info("秘密已重建，使用了 %d 个份额", len(shares))
        return secret

    # ------------------------------------------------------------------
    # 加法秘密共享 (Additive Secret Sharing)
    # ------------------------------------------------------------------

    def additive_share(
        self,
        value: int,
        participant_ids: Optional[List[str]] = None,
    ) -> Dict[str, int]:
        """加法秘密共享 (Additive secret sharing)

        将值 v 拆分为 n 个随机份额，使得所有份额之和等于 v。
        这是两方安全计算中最简单的秘密共享方案。

        Args:
            value: 要共享的值
            participant_ids: 参与者 ID 列表

        Returns:
            Dict[str, int]: 参与者 ID 到份额的映射
        """
        if participant_ids is None:
            participant_ids = list(self._participants.keys())

        n = len(participant_ids)
        if n < 2:
            raise RuntimeError("加法秘密共享至少需要 2 个参与者")

        value = self._mod(value)

        # 生成 n-1 个随机份额
        shares: Dict[str, int] = {}
        random_sum = 0
        for pid in participant_ids[:-1]:
            share = secrets.randbelow(self._prime)
            shares[pid] = share
            random_sum = self._mod(random_sum + share)

        # 最后一个份额 = value - sum(other shares)
        last_share = self._mod(value - random_sum)
        shares[participant_ids[-1]] = last_share

        self._log_operation("additive_share", {"num_shares": len(shares)})
        return shares

    def additive_reconstruct(self, shares: Dict[str, int]) -> int:
        """重建加法秘密共享的值 (Reconstruct additive secret sharing)

        Args:
            shares: 所有参与者的份额

        Returns:
            int: 重建的原始值
        """
        result = 0
        for share in shares.values():
            result = self._mod(result + share)

        self._log_operation("additive_reconstruct", {"num_shares": len(shares)})
        return result

    # ------------------------------------------------------------------
    # 乘法协议 (Multiplication Protocol)
    # ------------------------------------------------------------------

    def secure_multiply(
        self,
        shares_a: Dict[str, int],
        shares_b: Dict[str, int],
    ) -> Dict[str, int]:
        """安全乘法协议 (Secure multiplication protocol)

        基于 Beaver 三元组的安全乘法。在简化实现中，
        使用加法秘密共享的乘法性质：
        如果 a = sum(a_i), b = sum(b_i)，则
        a * b = sum(a_i * b_j) 对所有 i,j

        注意：完整实现需要通信轮次来重新共享中间结果。
        此处为简化版本。

        Args:
            shares_a: 值 a 的秘密份额
            shares_b: 值 b 的秘密份额

        Returns:
            Dict[str, int]: 乘积 a*b 的秘密份额
        """
        if set(shares_a.keys()) != set(shares_b.keys()):
            raise ValueError("两个输入的参与者集合不一致")

        participant_ids = list(shares_a.keys())
        n = len(participant_ids)

        # 简化的乘法：每个参与者计算本地份额的乘积
        # 然后重新共享
        local_products: Dict[str, int] = {}
        for pid in participant_ids:
            local_products[pid] = self._mod(shares_a[pid] * shares_b[pid])

        # 重新共享乘积
        result_shares = self.additive_share(
            self.additive_reconstruct(local_products),
            participant_ids,
        )

        self._log_operation("secure_multiply", {"participants": n})
        return result_shares

    # ------------------------------------------------------------------
    # 比较协议 (Comparison Protocol)
    # ------------------------------------------------------------------

    def secure_compare(
        self,
        shares_a: Dict[str, int],
        shares_b: Dict[str, int],
    ) -> Dict[str, int]:
        """安全比较协议 (Secure comparison protocol)

        比较两个秘密共享的值 a 和 b，返回 a > b 的秘密共享结果（0 或 1）。

        简化实现：基于差值的符号位判断。
        在实际部署中，应使用更复杂的比特分解协议。

        Args:
            shares_a: 值 a 的秘密份额
            shares_b: 值 b 的秘密份额

        Returns:
            Dict[str, int]: 比较结果 (a > b) 的秘密共享（0 或 1）
        """
        # 计算 a - b 的秘密共享
        diff_shares: Dict[str, int] = {}
        for pid in shares_a:
            diff_shares[pid] = self._mod(shares_a[pid] - shares_b[pid])

        # 重建差值（在实际 SMC 中，这一步需要安全协议）
        diff = self.additive_reconstruct(diff_shares)

        # 将差值映射到 [0, prime) 范围
        diff = self._mod(diff)

        # 判断 a > b（简化：直接比较重建后的值）
        # 注意：在实际 SMC 中，比较应在秘密共享状态下完成
        half_prime = self._prime // 2
        result = 1 if diff < half_prime else 0

        # 重新共享结果
        result_shares = self.additive_share(result, list(shares_a.keys()))

        self._log_operation("secure_compare", {
            "result": result,
        })

        return result_shares

    # ------------------------------------------------------------------
    # 通信协议抽象 (Communication Protocol Abstraction)
    # ------------------------------------------------------------------

    def send_message(
        self,
        sender_id: str,
        recipient_id: str,
        message_type: str,
        payload: Dict[str, Any],
    ) -> bool:
        """发送 SMC 协议消息 (Send SMC protocol message)

        模拟参与者之间的安全通信通道。

        Args:
            sender_id: 发送者 ID
            recipient_id: 接收者 ID
            message_type: 消息类型
            payload: 消息负载

        Returns:
            bool: 是否成功发送
        """
        if sender_id not in self._participants:
            logger.error("发送者 %s 不是注册的参与者", sender_id)
            return False
        if recipient_id not in self._participants:
            logger.error("接收者 %s 不是注册的参与者", recipient_id)
            return False

        message = {
            "sender": sender_id,
            "recipient": recipient_id,
            "type": message_type,
            "payload": payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "message_id": secrets.token_hex(8),
        }

        self._message_buffer.append(message)
        logger.debug(
            "SMC 消息已发送: %s -> %s, type=%s",
            sender_id, recipient_id, message_type,
        )
        return True

    def receive_messages(
        self,
        participant_id: str,
        message_type: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """接收 SMC 协议消息 (Receive SMC protocol messages)

        Args:
            participant_id: 接收者 ID
            message_type: 可选的消息类型过滤

        Returns:
            List[Dict]: 匹配的消息列表
        """
        messages = [
            msg for msg in self._message_buffer
            if msg["recipient"] == participant_id
            and (message_type is None or msg["type"] == message_type)
        ]
        return messages

    def clear_message_buffer(self) -> None:
        """清空消息缓冲区 (Clear message buffer)"""
        self._message_buffer.clear()

    # ------------------------------------------------------------------
    # 操作日志 (Operation Log)
    # ------------------------------------------------------------------

    def _log_operation(self, operation: str, details: Dict[str, Any]) -> None:
        """记录操作日志 (Log operation)"""
        self._operation_log.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "operation": operation,
            "details": details,
            "participants": list(self._participants.keys()),
        })

    def get_operation_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取操作日志 (Get operation log)"""
        return self._operation_log[-limit:]


# ============================================================================
# 隐私预算管理器 (Privacy Budget Manager)
# ============================================================================


class PrivacyBudgetManager:
    """隐私预算管理器 (Privacy Budget Manager)

    集中管理系统中所有差分隐私操作的隐私预算消耗。支持：
    - 按查询类型分配和跟踪预算
    - 预算耗尽时的降级策略
    - 周期性预算重置
    - 完整的审计日志

    隐私预算管理是差分隐私系统的核心组件，确保系统在整个生命周期内
    不会超过预定的隐私损失上限。

    Example:
        >>> manager = PrivacyBudgetManager(
        ...     global_epsilon=10.0,
        ...     global_delta=1e-4,
        ...     reset_period_hours=24,
        ... )
        >>> manager.register_query_type("reputation", epsilon=1.0, delta=1e-6)
        >>> granted = manager.request_budget("reputation", epsilon=0.5)
        >>> print(f"预算请求: {'通过' if granted else '拒绝'}")
    """

    def __init__(
        self,
        global_epsilon: float = 10.0,
        global_delta: float = 1e-4,
        reset_period_hours: int = 24,
        degradation_strategy: str = "reject",
    ) -> None:
        """初始化隐私预算管理器 (Initialize privacy budget manager)

        Args:
            global_epsilon: 全局 epsilon 预算上限
            global_delta: 全局 delta 预算上限
            reset_period_hours: 预算重置周期（小时）
            degradation_strategy: 预算耗尽时的降级策略
                - "reject": 直接拒绝请求
                - "reduce_noise": 降低噪声精度（减少 epsilon 消耗）
                - "cache": 返回缓存结果
        """
        if global_epsilon <= 0:
            raise ValueError(f"global_epsilon 必须为正数，当前值: {global_epsilon}")
        if global_delta < 0 or global_delta >= 1:
            raise ValueError(f"global_delta 必须在 [0, 1) 范围内，当前值: {global_delta}")
        if degradation_strategy not in ("reject", "reduce_noise", "cache"):
            raise ValueError(f"不支持的降级策略: {degradation_strategy}")

        self._global_epsilon = global_epsilon
        self._global_delta = global_delta
        self._reset_period = timedelta(hours=reset_period_hours)
        self._degradation_strategy = degradation_strategy

        # 全局已消耗预算
        self._global_used_epsilon: float = 0.0
        self._global_used_delta: float = 0.0

        # 按查询类型分配的预算
        self._query_budgets: Dict[str, PrivacyBudget] = {}

        # 上次重置时间
        self._last_reset: datetime = datetime.now(timezone.utc)

        # 结果缓存（用于 cache 降级策略）
        self._result_cache: Dict[str, Tuple[Any, datetime]] = {}

        # 审计日志
        self._audit_log: List[Dict[str, Any]] = []

        # 线程锁
        self._lock = threading.RLock()

        logger.info(
            "隐私预算管理器初始化完成: global_epsilon=%.2f, global_delta=%.2e, "
            "reset_period=%dh, strategy=%s",
            global_epsilon, global_delta, reset_period_hours, degradation_strategy,
        )

    # ------------------------------------------------------------------
    # 查询类型注册 (Query Type Registration)
    # ------------------------------------------------------------------

    def register_query_type(
        self,
        query_type: str,
        epsilon: float,
        delta: float = 0.0,
    ) -> bool:
        """注册查询类型并分配预算 (Register query type and allocate budget)

        Args:
            query_type: 查询类型标识
            epsilon: 分配给该类型的 epsilon 预算
            delta: 分配给该类型的 delta 预算

        Returns:
            bool: 是否成功注册
        """
        if not query_type:
            raise ValueError("query_type 不能为空")
        if epsilon <= 0:
            raise ValueError(f"epsilon 必须为正数，当前值: {epsilon}")

        with self._lock:
            # 检查总分配是否超过全局预算
            existing_total = sum(
                b.total_epsilon for b in self._query_budgets.values()
            )
            if existing_total + epsilon > self._global_epsilon:
                logger.warning(
                    "预算分配将超过全局上限: 已分配=%.2f, 新增=%.2f, 上限=%.2f",
                    existing_total, epsilon, self._global_epsilon,
                )

            self._query_budgets[query_type] = PrivacyBudget(
                total_epsilon=epsilon,
                total_delta=delta,
                query_type=query_type,
            )
            logger.info(
                "查询类型已注册: %s, epsilon=%.4f, delta=%.2e",
                query_type, epsilon, delta,
            )
            return True

    def unregister_query_type(self, query_type: str) -> bool:
        """注销查询类型 (Unregister query type)

        Args:
            query_type: 查询类型标识

        Returns:
            bool: 是否成功注销
        """
        with self._lock:
            if query_type not in self._query_budgets:
                return False
            del self._query_budgets[query_type]
            logger.info("查询类型已注销: %s", query_type)
            return True

    # ------------------------------------------------------------------
    # 预算请求 (Budget Request)
    # ------------------------------------------------------------------

    def request_budget(
        self,
        query_type: str,
        epsilon: float,
        delta: float = 0.0,
    ) -> Tuple[bool, float]:
        """请求隐私预算 (Request privacy budget)

        检查并消耗指定查询类型的隐私预算。如果预算不足，
        根据配置的降级策略处理。

        Args:
            query_type: 查询类型标识
            epsilon: 请求的 epsilon 值
            delta: 请求的 delta 值

        Returns:
            Tuple[bool, float]: (是否批准, 实际分配的 epsilon)
                - 如果批准: (True, 请求的 epsilon)
                - 如果降级(reduce_noise): (True, 减少后的 epsilon)
                - 如果拒绝: (False, 0.0)
        """
        if epsilon <= 0:
            raise ValueError(f"epsilon 必须为正数，当前值: {epsilon}")

        with self._lock:
            self._check_auto_reset()

            # 检查查询类型是否已注册
            budget = self._query_budgets.get(query_type)
            if budget is None:
                logger.error("未注册的查询类型: %s", query_type)
                return False, 0.0

            # 检查类型级别预算
            if budget.remaining_epsilon < epsilon:
                return self._handle_degradation(
                    query_type, epsilon, delta, "query_type_exhausted"
                )

            # 检查全局预算
            if (self._global_epsilon - self._global_used_epsilon) < epsilon:
                return self._handle_degradation(
                    query_type, epsilon, delta, "global_exhausted"
                )

            # 批准预算请求
            budget.consume(epsilon, delta)
            self._global_used_epsilon += epsilon
            self._global_used_delta += delta

            # 记录审计日志
            self._audit_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "budget_request",
                "query_type": query_type,
                "epsilon_requested": epsilon,
                "epsilon_granted": epsilon,
                "delta_requested": delta,
                "status": "granted",
                "global_remaining": self._global_epsilon - self._global_used_epsilon,
            })

            logger.info(
                "预算已批准: type=%s, epsilon=%.4f, 全局剩余=%.4f",
                query_type, epsilon,
                self._global_epsilon - self._global_used_epsilon,
            )
            return True, epsilon

    def _handle_degradation(
        self,
        query_type: str,
        epsilon: float,
        delta: float,
        reason: str,
    ) -> Tuple[bool, float]:
        """处理预算耗尽的降级逻辑 (Handle budget exhaustion degradation)

        Args:
            query_type: 查询类型
            epsilon: 请求的 epsilon
            delta: 请求的 delta
            reason: 耗尽原因

        Returns:
            Tuple[bool, float]: (是否批准, 实际分配的 epsilon)
        """
        logger.warning(
            "预算不足: type=%s, reason=%s, strategy=%s",
            query_type, reason, self._degradation_strategy,
        )

        if self._degradation_strategy == "reject":
            self._audit_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "budget_request",
                "query_type": query_type,
                "epsilon_requested": epsilon,
                "epsilon_granted": 0.0,
                "status": "rejected",
                "reason": reason,
            })
            return False, 0.0

        elif self._degradation_strategy == "reduce_noise":
            # 降低噪声精度：使用剩余预算的一小部分
            budget = self._query_budgets.get(query_type)
            remaining = budget.remaining_epsilon if budget else 0.0
            global_remaining = self._global_epsilon - self._global_used_epsilon
            reduced_epsilon = min(remaining, global_remaining) * 0.5

            if reduced_epsilon < 1e-6:
                return False, 0.0

            if budget:
                budget.consume(reduced_epsilon, delta * 0.5)
            self._global_used_epsilon += reduced_epsilon
            self._global_used_delta += delta * 0.5

            self._audit_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "budget_request",
                "query_type": query_type,
                "epsilon_requested": epsilon,
                "epsilon_granted": reduced_epsilon,
                "status": "degraded",
                "reason": reason,
            })

            logger.info(
                "降级处理: type=%s, 原始epsilon=%.4f, 降级后=%.4f",
                query_type, epsilon, reduced_epsilon,
            )
            return True, reduced_epsilon

        elif self._degradation_strategy == "cache":
            # 返回缓存结果（epsilon 消耗为 0）
            self._audit_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "budget_request",
                "query_type": query_type,
                "epsilon_requested": epsilon,
                "epsilon_granted": 0.0,
                "status": "cached",
                "reason": reason,
            })
            return True, 0.0

        return False, 0.0

    # ------------------------------------------------------------------
    # 缓存管理 (Cache Management)
    # ------------------------------------------------------------------

    def cache_result(self, query_type: str, key: str, result: Any) -> None:
        """缓存查询结果 (Cache query result)

        用于 cache 降级策略，当预算耗尽时返回缓存的结果。

        Args:
            query_type: 查询类型
            key: 查询键
            result: 查询结果
        """
        cache_key = f"{query_type}:{key}"
        self._result_cache[cache_key] = (result, datetime.now(timezone.utc))
        logger.debug("结果已缓存: %s", cache_key)

    def get_cached_result(
        self, query_type: str, key: str
    ) -> Optional[Any]:
        """获取缓存的查询结果 (Get cached query result)

        Args:
            query_type: 查询类型
            key: 查询键

        Returns:
            Optional[Any]: 缓存的结果，不存在或已过期返回 None
        """
        cache_key = f"{query_type}:{key}"
        entry = self._result_cache.get(cache_key)
        if entry is None:
            return None

        result, timestamp = entry
        # 缓存有效期为一个重置周期
        if datetime.now(timezone.utc) - timestamp > self._reset_period:
            del self._result_cache[cache_key]
            return None

        return result

    # ------------------------------------------------------------------
    # 预算重置 (Budget Reset)
    # ------------------------------------------------------------------

    def _check_auto_reset(self) -> None:
        """检查并自动重置预算 (Check and auto-reset budget)"""
        now = datetime.now(timezone.utc)
        if now - self._last_reset >= self._reset_period:
            self.reset_all_budgets()

    def reset_all_budgets(self) -> None:
        """重置所有预算 (Reset all budgets)

        将所有查询类型的已消耗预算归零，并清空结果缓存。
        """
        with self._lock:
            for budget in self._query_budgets.values():
                budget.reset()

            self._global_used_epsilon = 0.0
            self._global_used_delta = 0.0
            self._last_reset = datetime.now(timezone.utc)
            self._result_cache.clear()

            self._audit_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "budget_reset",
                "details": "所有预算已重置",
            })

            logger.info("所有隐私预算已重置")

    # ------------------------------------------------------------------
    # 状态查询 (Status Query)
    # ------------------------------------------------------------------

    def get_status(self) -> Dict[str, Any]:
        """获取预算管理器状态 (Get budget manager status)

        Returns:
            Dict: 包含全局预算和各查询类型预算状态的字典
        """
        with self._lock:
            query_statuses = {}
            for qtype, budget in self._query_budgets.items():
                query_statuses[qtype] = {
                    "total_epsilon": budget.total_epsilon,
                    "used_epsilon": budget.used_epsilon,
                    "remaining_epsilon": budget.remaining_epsilon,
                    "utilization_ratio": budget.utilization_ratio,
                    "is_exhausted": budget.is_exhausted,
                }

            return {
                "global_epsilon": self._global_epsilon,
                "global_used_epsilon": self._global_used_epsilon,
                "global_remaining_epsilon": self._global_epsilon - self._global_used_epsilon,
                "global_delta": self._global_delta,
                "global_used_delta": self._global_used_delta,
                "global_utilization": (
                    self._global_used_epsilon / self._global_epsilon
                    if self._global_epsilon > 0 else 1.0
                ),
                "degradation_strategy": self._degradation_strategy,
                "last_reset": self._last_reset.isoformat(),
                "next_reset": (
                    self._last_reset + self._reset_period
                ).isoformat(),
                "query_types": query_statuses,
                "cached_results": len(self._result_cache),
            }

    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取审计日志 (Get audit log)

        Args:
            limit: 返回的最大日志条数

        Returns:
            List[Dict]: 审计日志列表
        """
        with self._lock:
            return self._audit_log[-limit:]


# ============================================================================
# 模块自测试 (Module Self-Test)
# ============================================================================


def _run_self_test() -> None:
    """运行模块自测试 (Run module self-test)

    验证所有核心类的基本功能是否正常工作。
    """
    print("=" * 60)
    print("隐私计算模块自测试 (Privacy Compute Module Self-Test)")
    print("=" * 60)

    # 测试 1: 差分隐私信誉系统
    print("\n[测试 1] 差分隐私信誉系统")
    dpr = DifferentialPrivacyReputation(epsilon=1.0, sensitivity=0.1)
    dpr.update_reputation("node_001", 0.85)
    dpr.update_reputation("node_002", 0.62)
    scores = dpr.query_reputation_batch(["node_001", "node_002"])
    for node_id, score in scores.items():
        print(f"  {node_id}: 带噪声信誉分数 = {score:.4f}")
    print(f"  当前 epsilon: {dpr.current_epsilon:.6f}")
    print(f"  查询次数: {dpr.query_count}")

    # 测试 2: 联邦学习式攻击检测器
    print("\n[测试 2] 联邦学习式攻击检测器")
    detector = FederatedAnomalyDetector(
        num_features=5, noise_multiplier=1.1, poison_threshold=3.0,
        min_participants=2,
    )
    for i in range(3):
        detector.add_node(f"node_{i:03d}")

    # 模拟本地训练和提交更新
    for node_id in detector.registered_nodes:
        features = [random.random() for _ in range(5)]
        label = random.randint(0, 1)
        params = detector.simulate_local_training(node_id, features, label)
        status = detector.submit_update(
            node_id, params, num_samples=params["num_samples"]
        )
        print(f"  {node_id}: 更新状态 = {status.value}")

    global_model = detector.aggregate_models()
    if global_model:
        print(f"  全局模型轮次: {global_model['round']}")

    # 测试 3: 安全多方计算
    print("\n[测试 3] 安全多方计算")
    smc = SecureMultiPartyComputation(threshold=2, num_parties=3)
    for i in range(3):
        smc.add_participant(f"party_{i:03d}")

    secret = 42
    shares = smc.distribute_secret(secret)
    print(f"  原始秘密: {secret}")
    for pid, share in shares.items():
        print(f"  {pid} 的份额: {share}")

    # 使用部分份额重建
    partial_shares = dict(list(shares.items())[:2])
    reconstructed = smc.reconstruct_secret(partial_shares)
    print(f"  重建秘密: {reconstructed}")
    assert reconstructed == secret, f"秘密重建失败: 期望 {secret}, 得到 {reconstructed}"

    # 加法秘密共享测试
    add_shares = smc.additive_share(100)
    add_result = smc.additive_reconstruct(add_shares)
    print(f"  加法秘密共享: 100 -> 重建 = {add_result}")
    assert add_result == 100, "加法秘密共享重建失败"

    # 测试 4: 隐私预算管理器
    print("\n[测试 4] 隐私预算管理器")
    manager = PrivacyBudgetManager(
        global_epsilon=10.0, global_delta=1e-4, degradation_strategy="reduce_noise",
    )
    manager.register_query_type("reputation", epsilon=5.0, delta=1e-5)
    manager.register_query_type("statistics", epsilon=3.0, delta=1e-5)

    for i in range(8):
        granted, actual_eps = manager.request_budget("reputation", epsilon=0.8)
        print(f"  请求 #{i+1}: {'批准' if granted else '拒绝'}, "
              f"epsilon={actual_eps:.4f}")

    status = manager.get_status()
    print(f"  全局预算使用率: {status['global_utilization']:.2%}")
    print(f"  reputation 类型耗尽: {status['query_types']['reputation']['is_exhausted']}")

    print("\n" + "=" * 60)
    print("所有自测试通过!")
    print("=" * 60)


if __name__ == "__main__":
    _run_self_test()
