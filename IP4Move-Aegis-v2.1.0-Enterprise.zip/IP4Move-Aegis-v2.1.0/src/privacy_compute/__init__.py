"""
隐私计算与差分隐私模块 (Privacy Computing & Differential Privacy Module)

本模块提供隐私计算相关的核心功能，包括：
- 差分隐私信誉系统 (Differential Privacy Reputation System)
- 联邦学习式攻击检测 (Federated Learning-based Attack Detection)
- 安全多方计算 (Secure Multi-Party Computation, SMC)
- 隐私预算管理 (Privacy Budget Management)

所有组件均实现了严格的隐私保护机制，确保在提供安全服务的同时
不会泄露用户敏感信息。

This module provides core privacy computing functionalities including:
- Differential privacy reputation system
- Federated learning-based anomaly detection
- Secure multi-party computation (SMC)
- Privacy budget management
"""

# 导入子模块
from . import homomorphic
from . import differential_privacy

__all__ = [
    "homomorphic",
    "differential_privacy",
]

__version__ = "1.0.0"
__author__ = "IP4Move Aegis Security Team"
