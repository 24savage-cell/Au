"""
同态加密计算模块

提供多种同态加密方案实现，支持加密数据的直接计算。
支持半同态加密(Paillier)和全同态加密(BFV/CKKS/TFHE)方案。

主要组件:
    - schemes: 各种同态加密方案实现
    - operations: 加密数据上的运算操作
    - applications: 隐私保护应用实现
    - optimization: 性能优化技术
"""

from .schemes.paillier import PaillierScheme, PaillierKeyPair, PaillierCiphertext
from .schemes.bfv import BFVScheme, BFVParameters, BFVCiphertext
from .schemes.ckks import CKKSScheme, CKKSParameters, CKKSCiphertext
from .schemes.tfhe import TFHEScheme, TFHEParameters, TFHECiphertext

__version__ = "1.0.0"
__author__ = "IP4Move Team"

__all__ = [
    # Paillier半同态加密
    "PaillierScheme",
    "PaillierKeyPair", 
    "PaillierCiphertext",
    # BFV全同态加密
    "BFVScheme",
    "BFVParameters",
    "BFVCiphertext",
    # CKKS全同态加密
    "CKKSScheme",
    "CKKSParameters",
    "CKKSCiphertext",
    # TFHE布尔电路同态
    "TFHEScheme",
    "TFHEParameters",
    "TFHECiphertext",
]