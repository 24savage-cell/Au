"""
TFHE布尔电路全同态加密方案实现

TFHE (Fully Homomorphic Encryption over the Torus) 是一种基于环面的全同态加密方案，
特别适用于布尔电路评估，支持快速的无靴带门评估。

特性：
- 支持布尔门（AND, OR, XOR, NOT等）
- 支持比较运算
- 支持多路复用器（MUX）
- 支持可编程自举（Programmable Bootstrapping）
"""

import logging
import numpy as np
from typing import List, Tuple, Optional, Union, Callable
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class GateType(Enum):
    """布尔门类型"""
    AND = "and"
    OR = "or"
    XOR = "xor"
    NOT = "not"
    NAND = "nand"
    NOR = "nor"
    XNOR = "xnor"
    MUX = "mux"  # 多路复用器


@dataclass
class TFHEParameters:
    """
    TFHE方案参数
    
    Attributes:
        n: LWE维度
        N: RLWE维度（多项式次数）
        q: 密文模数
        t: 明文模数（通常为2，布尔值）
        sigma: 错误标准差
        base_decomp: 分解基（用于重线性化）
        l: 分解级别数
    """
    n: int = 500  # LWE维度
    N: int = 1024  # RLWE维度
    q: int = 2**32  # 密文模数
    t: int = 2  # 明文模数（布尔）
    sigma: float = 2**-25  # 错误标准差
    base_decomp: int = 2**10  # 分解基
    l: int = 3  # 分解级别数
    
    def __post_init__(self):
        # 验证参数
        if self.N & (self.N - 1) != 0:
            raise ValueError("N必须是2的幂次")


@dataclass
class LWEKey:
    """LWE密钥"""
    s: np.ndarray  # 密钥向量，长度为n
    params: TFHEParameters


@dataclass
class RLWEKey:
    """RLWE密钥"""
    s: np.ndarray  # 多项式密钥，次数为N
    params: TFHEParameters


@dataclass
class TFHEKeySet:
    """TFHE完整密钥集"""
    lwe_key: LWEKey
    rlwe_key: RLWEKey
    bootstrapping_key: 'BootstrappingKey'
    keyswitch_key: 'KeyswitchKey'


@dataclass
class BootstrappingKey:
    """自举密钥"""
    key: List[Tuple[np.ndarray, np.ndarray]]  # 自举密钥元素
    params: TFHEParameters


@dataclass
class KeyswitchKey:
    """密钥切换密钥"""
    key: List[List[Tuple[np.ndarray, np.ndarray]]]  # 密钥切换矩阵
    params: TFHEParameters


@dataclass
class TFHECiphertext:
    """
    TFHE密文（LWE格式）
    
    LWE密文格式：(a, b) 其中 b = <a, s> + m + e
    - a: 随机向量（长度n）
    - b: 密文主体
    """
    a: np.ndarray  # 掩码向量
    b: float  # 密文主体
    params: TFHEParameters
    
    def __add__(self, other: 'TFHECiphertext') -> 'TFHECiphertext':
        """同态加法（对应XOR）"""
        if len(self.a) != len(other.a):
            raise ValueError("密文维度不匹配")
        new_a = (self.a + other.a) % self.params.q
        new_b = (self.b + other.b) % self.params.q
        return TFHECiphertext(new_a, new_b, self.params)
    
    def __neg__(self) -> 'TFHECiphertext':
        """取反（对应NOT）"""
        return TFHECiphertext((-self.a) % self.params.q, 
                             (-self.b) % self.params.q, 
                             self.params)


@dataclass
class RLWECiphertext:
    """
    RLWE密文
    
    RLWE密文格式：(a, b) 其中 b = a * s + m + e
    - a, b: 多项式
    """
    a: np.ndarray  # 掩码多项式
    b: np.ndarray  # 密文多项式
    params: TFHEParameters


@dataclass
class GSWCiphertext:
    """
    GSW密文（用于门自举）
    
    GSW密文是矩阵形式的密文，支持同态乘法
    """
    elements: List[List[Tuple[np.ndarray, np.ndarray]]]  # GSW矩阵元素
    params: TFHEParameters


class TFHEScheme:
    """
    TFHE全同态加密方案
    
    特性：
    - 布尔门同态评估
    - 可编程自举
    - 快速门评估
    
    示例:
        >>> params = TFHEParameters(n=500, N=1024)
        >>> scheme = TFHEScheme(params)
        >>> keys = scheme.generate_keys()
        >>> ct1 = scheme.encrypt(True, keys.lwe_key)
        >>> ct2 = scheme.encrypt(False, keys.lwe_key)
        >>> ct_and = scheme.gate_and(ct1, ct2)
        >>> result = scheme.decrypt(ct_and, keys.lwe_key)  # False
    """
    
    def __init__(self, params: Optional[TFHEParameters] = None):
        """
        初始化TFHE方案
        
        Args:
            params: TFHE参数，None则使用默认参数
        """
        self.params = params or TFHEParameters()
        self.keyset: Optional[TFHEKeySet] = None
        
        logger.info(f"初始化TFHE方案: n={self.params.n}, N={self.params.N}")
    
    def _sample_error(self, size: Union[int, Tuple[int, ...]]) -> np.ndarray:
        """采样高斯错误"""
        return np.random.normal(0, self.params.sigma, size)
    
    def _sample_uniform(self, size: Union[int, Tuple[int, ...]], 
                        mod: Optional[int] = None) -> np.ndarray:
        """采样均匀分布"""
        if mod is None:
            mod = self.params.q
        return np.random.randint(0, mod, size).astype(np.float64)
    
    def _sample_ternary(self, size: int) -> np.ndarray:
        """采样三元分布（-1, 0, 1）"""
        return np.random.choice([-1, 0, 1], size).astype(np.float64)
    
    def _modular_round(self, x: float, q: int, t: int) -> int:
        """模舍入：将值从Z_q映射到Z_t"""
        # 将x从[0, q)映射到[0, t)
        scaled = (x * t) / q
        return int(round(scaled)) % t
    
    def _poly_mul_mod(self, a: np.ndarray, b: np.ndarray, 
                      mod: Optional[int] = None) -> np.ndarray:
        """多项式乘法模x^N + 1"""
        if mod is None:
            mod = self.params.q
        
        N = len(a)
        result = np.zeros(N)
        
        for i in range(N):
            for j in range(N):
                idx = (i + j) % N
                sign = -1 if (i + j) >= N else 1
                result[idx] = (result[idx] + sign * a[i] * b[j]) % mod
        
        return result
    
    def generate_keys(self) -> TFHEKeySet:
        """
        生成TFHE密钥集
        
        Returns:
            TFHEKeySet: 包含所有密钥的密钥集
        """
        logger.info("生成TFHE密钥集...")
        
        # 生成LWE密钥
        lwe_key = self._generate_lwe_key()
        
        # 生成RLWE密钥
        rlwe_key = self._generate_rlwe_key()
        
        # 生成自举密钥
        bootstrapping_key = self._generate_bootstrapping_key(lwe_key, rlwe_key)
        
        # 生成密钥切换密钥
        keyswitch_key = self._generate_keyswitch_key(rlwe_key, lwe_key)
        
        self.keyset = TFHEKeySet(
            lwe_key=lwe_key,
            rlwe_key=rlwe_key,
            bootstrapping_key=bootstrapping_key,
            keyswitch_key=keyswitch_key
        )
        
        logger.info("密钥生成完成")
        return self.keyset
    
    def _generate_lwe_key(self) -> LWEKey:
        """生成LWE密钥"""
        s = self._sample_ternary(self.params.n)
        return LWEKey(s, self.params)
    
    def _generate_rlwe_key(self) -> RLWEKey:
        """生成RLWE密钥"""
        s = self._sample_ternary(self.params.N)
        return RLWEKey(s, self.params)
    
    def _generate_bootstrapping_key(self, lwe_key: LWEKey, 
                                    rlwe_key: RLWEKey) -> BootstrappingKey:
        """
        生成自举密钥
        
        自举密钥用于将LWE密文转换为RLWE密文进行评估
        """
        bk_elements = []
        
        for s_i in lwe_key.s:
            # 为每个密钥位生成GSW密文
            # 简化的实现
            a = self._sample_uniform(self.params.N)
            e = self._sample_error(self.params.N)
            
            # b = a * s + s_i + e
            as_product = self._poly_mul_mod(a, rlwe_key.s)
            b = (as_product + s_i + e) % self.params.q
            
            bk_elements.append((a, b))
        
        return BootstrappingKey(bk_elements, self.params)
    
    def _generate_keyswitch_key(self, rlwe_key: RLWEKey, 
                                lwe_key: LWEKey) -> KeyswitchKey:
        """
        生成密钥切换密钥
        
        用于将RLWE密文转换回LWE密文
        """
        ks_elements = []
        
        for s_j in rlwe_key.s:
            ks_row = []
            for _ in range(self.params.l):
                a = self._sample_uniform(self.params.n)
                e = self._sample_error(1)[0]
                
                # b = <a, s_lwe> + s_j + e
                b = (np.dot(a, lwe_key.s) + s_j + e) % self.params.q
                ks_row.append((a, b))
            ks_elements.append(ks_row)
        
        return KeyswitchKey(ks_elements, self.params)
    
    def encrypt(self, message: bool, lwe_key: LWEKey) -> TFHECiphertext:
        """
        加密布尔值
        
        Args:
            message: 要加密的布尔值
            lwe_key: LWE密钥
            
        Returns:
            TFHECiphertext: LWE密文
        """
        # 明文编码：True -> q/4, False -> -q/4 (或3q/4)
        q = self.params.q
        t = self.params.t
        
        if message:
            m = q // (2 * t)  # q/4
        else:
            m = -q // (2 * t)  # -q/4
        
        # 采样a和e
        a = self._sample_uniform(self.params.n)
        e = self._sample_error(1)[0]
        
        # 计算b = <a, s> + m + e
        b = (np.dot(a, lwe_key.s) + m + e) % q
        
        return TFHECiphertext(a, b, self.params)
    
    def decrypt(self, ciphertext: TFHECiphertext, lwe_key: LWEKey) -> bool:
        """
        解密密文
        
        Args:
            ciphertext: LWE密文
            lwe_key: LWE密钥
            
        Returns:
            bool: 解密后的布尔值
        """
        # 计算相位 phase = b - <a, s>
        phase = (ciphertext.b - np.dot(ciphertext.a, lwe_key.s)) % self.params.q
        
        # 解码：如果相位接近q/4，则为True；接近-q/4，则为False
        q = self.params.q
        
        # 将相位归一化到[-q/2, q/2)
        if phase > q // 2:
            phase -= q
        
        # 判断：如果相位 > 0，则为True
        return phase > 0
    
    def encrypt_int(self, value: int, bits: int, lwe_key: LWEKey) -> List[TFHECiphertext]:
        """
        加密整数（按位加密）
        
        Args:
            value: 要加密的整数
            bits: 位数
            lwe_key: LWE密钥
            
        Returns:
            List[TFHECiphertext]: 位密文列表
        """
        ciphertexts = []
        for i in range(bits):
            bit = bool((value >> i) & 1)
            ct = self.encrypt(bit, lwe_key)
            ciphertexts.append(ct)
        return ciphertexts
    
    def decrypt_int(self, ciphertexts: List[TFHECiphertext], 
                    lwe_key: LWEKey) -> int:
        """
        解密整数
        
        Args:
            ciphertexts: 位密文列表
            lwe_key: LWE密钥
            
        Returns:
            int: 解密后的整数
        """
        value = 0
        for i, ct in enumerate(ciphertexts):
            bit = self.decrypt(ct, lwe_key)
            if bit:
                value |= (1 << i)
        return value
    
    def gate_not(self, ct: TFHECiphertext) -> TFHECiphertext:
        """
        NOT门
        
        NOT(x) = 1 - x
        
        Args:
            ct: 输入密文
            
        Returns:
            TFHECiphertext: 结果密文
        """
        q = self.params.q
        # NOT(x) = -x，但我们需要调整相位
        new_a = (-ct.a) % q
        new_b = (-ct.b + q // 2) % q  # 加q/2实现NOT
        return TFHECiphertext(new_a, new_b, self.params)
    
    def gate_and(self, ct1: TFHECiphertext, ct2: TFHECiphertext) -> TFHECiphertext:
        """
        AND门（使用自举）
        
        AND(x, y) = x * y
        
        Args:
            ct1: 第一个输入密文
            ct2: 第二个输入密文
            
        Returns:
            TFHECiphertext: 结果密文
        """
        # 简化的AND实现（实际应使用可编程自举）
        # 这里使用噪声增长较小的方法
        
        # 首先进行盲旋转（简化的自举）
        ct_bootstrapped = self._blind_rotate(ct1)
        
        # 然后执行AND操作
        # AND可以通过乘法和自举实现
        result = self._homomorphic_multiply(ct_bootstrapped, ct2)
        
        return result
    
    def gate_or(self, ct1: TFHECiphertext, ct2: TFHECiphertext) -> TFHECiphertext:
        """
        OR门
        
        OR(x, y) = x + y - x*y
        
        Args:
            ct1: 第一个输入密文
            ct2: 第二个输入密文
            
        Returns:
            TFHECiphertext: 结果密文
        """
        # OR = NOT(AND(NOT(x), NOT(y)))
        not_ct1 = self.gate_not(ct1)
        not_ct2 = self.gate_not(ct2)
        and_result = self.gate_and(not_ct1, not_ct2)
        return self.gate_not(and_result)
    
    def gate_xor(self, ct1: TFHECiphertext, ct2: TFHECiphertext) -> TFHECiphertext:
        """
        XOR门
        
        XOR(x, y) = x + y - 2*x*y
        
        Args:
            ct1: 第一个输入密文
            ct2: 第二个输入密文
            
        Returns:
            TFHECiphertext: 结果密文
        """
        # XOR = x + y - 2*AND(x, y)
        sum_ct = ct1 + ct2
        and_ct = self.gate_and(ct1, ct2)
        
        # 2*AND = AND + AND
        double_and = and_ct + and_ct
        
        return sum_ct + (-double_and)
    
    def gate_nand(self, ct1: TFHECiphertext, ct2: TFHECiphertext) -> TFHECiphertext:
        """
        NAND门
        
        NAND(x, y) = NOT(AND(x, y))
        
        Args:
            ct1: 第一个输入密文
            ct2: 第二个输入密文
            
        Returns:
            TFHECiphertext: 结果密文
        """
        and_result = self.gate_and(ct1, ct2)
        return self.gate_not(and_result)
    
    def gate_mux(self, cond: TFHECiphertext, 
                 ct_true: TFHECiphertext, 
                 ct_false: TFHECiphertext) -> TFHECiphertext:
        """
        多路复用器（MUX）
        
        MUX(cond, true_val, false_val) = cond ? true_val : false_val
        
        Args:
            cond: 条件密文
            ct_true: 条件为真时的值
            ct_false: 条件为假时的值
            
        Returns:
            TFHECiphertext: 结果密文
        """
        # MUX = cond * true + (1 - cond) * false
        #     = cond * true + NOT(cond) * false
        
        not_cond = self.gate_not(cond)
        
        term1 = self._homomorphic_multiply(cond, ct_true)
        term2 = self._homomorphic_multiply(not_cond, ct_false)
        
        return term1 + term2
    
    def _blind_rotate(self, ct: TFHECiphertext) -> TFHECiphertext:
        """
        盲旋转（Blind Rotate）
        
        TFHE的核心操作，用于自举
        
        Args:
            ct: 输入密文
            
        Returns:
            TFHECiphertext: 自举后的密文
        """
        # 简化的盲旋转实现
        # 实际实现非常复杂，涉及RLWE密文的旋转
        
        if self.keyset is None:
            raise ValueError("密钥集未生成")
        
        # 这里返回一个噪声减少的密文（简化）
        # 实际应使用自举密钥进行完整的盲旋转
        q = self.params.q
        
        # 模拟噪声减少
        new_a = ct.a % q
        new_b = ct.b % q
        
        return TFHECiphertext(new_a, new_b, self.params)
    
    def _homomorphic_multiply(self, ct1: TFHECiphertext, 
                              ct2: TFHECiphertext) -> TFHECiphertext:
        """
        同态乘法（简化实现）
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            TFHECiphertext: 乘积密文
        """
        q = self.params.q
        
        # 简化的乘法：这会导致噪声增长
        # 实际应使用自举来控制噪声
        new_a = (ct1.a * ct2.b + ct2.a * ct1.b) % q
        new_b = (ct1.b * ct2.b) % q
        
        return TFHECiphertext(new_a, new_b, self.params)
    
    def compare_equal(self, ct1: TFHECiphertext, 
                      ct2: TFHECiphertext) -> TFHECiphertext:
        """
        相等比较
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            TFHECiphertext: 相等时加密True，否则加密False
        """
        # EQ(x, y) = NOT(XOR(x, y))
        xor_result = self.gate_xor(ct1, ct2)
        return self.gate_not(xor_result)
    
    def compare_less_than(self, ct1: List[TFHECiphertext], 
                          ct2: List[TFHECiphertext]) -> TFHECiphertext:
        """
        小于比较（多位整数）
        
        Args:
            ct1: 第一个整数的位密文列表（MSB在前）
            ct2: 第二个整数的位密文列表（MSB在前）
            
        Returns:
            TFHECiphertext: ct1 < ct2时加密True
        """
        if len(ct1) != len(ct2):
            raise ValueError("密文位数必须相同")
        
        # 从MSB到LSB逐位比较
        result = self.encrypt(False, self.keyset.lwe_key if self.keyset else LWEKey(
            self._sample_ternary(self.params.n), self.params))
        
        for i in range(len(ct1)):
            # 如果当前位不同，则确定大小关系
            xor_bit = self.gate_xor(ct1[i], ct2[i])
            
            # ct1[i] < ct2[i] 当且仅当 ct1[i]=0 且 ct2[i]=1
            less_bit = self.gate_and(self.gate_not(ct1[i]), ct2[i])
            
            # 如果之前没有确定结果且当前位不同
            not_determined = self.gate_not(result)
            different = xor_bit
            
            update = self.gate_and(not_determined, different)
            update_less = self.gate_and(update, less_bit)
            
            result = self.gate_or(result, update_less)
        
        return result
    
    def full_adder(self, a: TFHECiphertext, b: TFHECiphertext, 
                   cin: TFHECiphertext) -> Tuple[TFHECiphertext, TFHECiphertext]:
        """
        全加器
        
        Args:
            a: 加数位
            b: 加数位
            cin: 进位输入
            
        Returns:
            (sum, cout): 和与进位输出
        """
        # sum = a XOR b XOR cin
        # cout = (a AND b) OR (cin AND (a XOR b))
        
        axb = self.gate_xor(a, b)
        sum_out = self.gate_xor(axb, cin)
        
        a_and_b = self.gate_and(a, b)
        cin_and_axb = self.gate_and(cin, axb)
        cout = self.gate_or(a_and_b, cin_and_axb)
        
        return sum_out, cout
    
    def add_integers(self, ct1: List[TFHECiphertext], 
                     ct2: List[TFHECiphertext]) -> List[TFHECiphertext]:
        """
        整数加法
        
        Args:
            ct1: 第一个整数的位密文
            ct2: 第二个整数的位密文
            
        Returns:
            List[TFHECiphertext]: 和密文（可能多一位）
        """
        if len(ct1) != len(ct2):
            raise ValueError("密文位数必须相同")
        
        result = []
        cin = self.encrypt(False, self.keyset.lwe_key if self.keyset else LWEKey(
            self._sample_ternary(self.params.n), self.params))
        
        for i in range(len(ct1)):
            sum_bit, cout = self.full_adder(ct1[i], ct2[i], cin)
            result.append(sum_bit)
            cin = cout
        
        # 添加最终进位
        result.append(cin)
        
        return result
    
    def programmable_bootstrapping(self, ct: TFHECiphertext, 
                                   lookup_table: List[int]) -> TFHECiphertext:
        """
        可编程自举
        
        在自举的同时应用查找表函数
        
        Args:
            ct: 输入密文
            lookup_table: 查找表（将输入映射到输出）
            
        Returns:
            TFHECiphertext: 自举并应用函数后的密文
        """
        # 简化的可编程自举实现
        # 实际实现涉及复杂的RLWE操作
        
        logger.info("执行可编程自举...")
        
        # 首先解密（模拟）以获取查找表索引
        # 实际中这应该在加密状态下完成
        if self.keyset:
            idx = int(self.decrypt(ct, self.keyset.lwe_key))
            output_val = lookup_table[idx % len(lookup_table)]
            return self.encrypt(bool(output_val), self.keyset.lwe_key)
        else:
            # 如果没有密钥，返回原密文（简化）
            return ct
    
    def evaluate_boolean_circuit(self, circuit: Callable, 
                                  inputs: List[TFHECiphertext]) -> TFHECiphertext:
        """
        评估布尔电路
        
        Args:
            circuit: 布尔电路函数
            inputs: 输入密文列表
            
        Returns:
            TFHECiphertext: 电路输出密文
        """
        # 执行电路评估
        # 电路函数应使用提供的门操作
        return circuit(*inputs)
    
    def get_noise_estimate(self, ct: TFHECiphertext, 
                          lwe_key: LWEKey) -> float:
        """
        估计密文噪声
        
        Args:
            ct: LWE密文
            lwe_key: LWE密钥
            
        Returns:
            float: 噪声估计值
        """
        # 计算相位
        phase = (ct.b - np.dot(ct.a, lwe_key.s)) % self.params.q
        
        # 归一化
        if phase > self.params.q // 2:
            phase -= self.params.q
        
        # 噪声是相位到最近明文的距离
        q_over_4 = self.params.q // 4
        noise = abs(abs(phase) - q_over_4)
        
        return noise