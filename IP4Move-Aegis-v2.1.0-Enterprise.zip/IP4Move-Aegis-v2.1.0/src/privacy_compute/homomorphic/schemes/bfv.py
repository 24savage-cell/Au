"""
BFV全同态加密方案实现

BFV (Brakerski-Fan-Vercauteren) 是一种基于RLWE问题的全同态加密方案，
适用于整数运算场景。

特性：
- 支持整数上的加法和乘法同态运算
- 支持SIMD批处理（通过多项式编码）
- 支持重线性化和模切换
"""

import random
import logging
import numpy as np
from typing import List, Tuple, Optional, Union
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class SecurityLevel(Enum):
    """安全级别定义"""
    TC128 = 128  # 128位安全
    TC192 = 192  # 192位安全
    TC256 = 256  # 256位安全


@dataclass
class BFVParameters:
    """
    BFV方案参数
    
    Attributes:
        poly_degree: 多项式次数（环维度），通常为2的幂次
        plain_modulus: 明文模数，决定明文空间
        cipher_modulus: 密文模数，决定噪声容限
        security_level: 安全级别
    """
    poly_degree: int = 4096  # 多项式次数n
    plain_modulus: int = 65537  # 明文模数t
    cipher_modulus: int = 0  # 密文模数q，0表示自动计算
    security_level: SecurityLevel = SecurityLevel.TC128
    
    def __post_init__(self):
        if self.cipher_modulus == 0:
            # 根据多项式次数自动选择密文模数
            self.cipher_modulus = self._select_cipher_modulus()
        
        # 验证参数有效性
        self._validate_parameters()
    
    def _select_cipher_modulus(self) -> int:
        """根据安全级别选择密文模数"""
        # 简化的模数选择，实际应根据安全分析确定
        modulus_map = {
            1024: 2**27,
            2048: 2**54,
            4096: 2**109,
            8192: 2**218,
            16384: 2**438
        }
        return modulus_map.get(self.poly_degree, 2**109)
    
    def _validate_parameters(self):
        """验证参数有效性"""
        # 多项式次数必须是2的幂次
        if self.poly_degree & (self.poly_degree - 1) != 0:
            raise ValueError("多项式次数必须是2的幂次")
        
        # 明文模数必须小于密文模数
        if self.plain_modulus >= self.cipher_modulus:
            raise ValueError("明文模数必须小于密文模ulus")


@dataclass
class BFVSecretKey:
    """BFV私钥"""
    s: np.ndarray  # 秘密多项式（小系数）
    params: BFVParameters


@dataclass
class BFVPublicKey:
    """BFV公钥"""
    p0: np.ndarray  # 公钥第一部分
    p1: np.ndarray  # 公钥第二部分
    params: BFVParameters


@dataclass
class BFVEvaluationKey:
    """BFV重线性化密钥"""
    evk0: np.ndarray
    evk1: np.ndarray
    params: BFVParameters


@dataclass
class BFVCiphertext:
    """
    BFV密文
    
    BFV密文是RNS (Residue Number System) 表示的多项式对 (c0, c1)
    满足：Decrypt(c) = c0 + c1 * s mod t
    """
    c0: np.ndarray  # 密文第一部分
    c1: np.ndarray  # 密文第二部分
    params: BFVParameters
    scale: float = 1.0  # 缩放因子（用于浮点编码）
    
    def __add__(self, other: Union['BFVCiphertext', int, np.ndarray]) -> 'BFVCiphertext':
        """同态加法"""
        if isinstance(other, BFVCiphertext):
            if self.params.poly_degree != other.params.poly_degree:
                raise ValueError("密文参数不匹配")
            new_c0 = (self.c0 + other.c0) % self.params.cipher_modulus
            new_c1 = (self.c1 + other.c1) % self.params.cipher_modulus
            return BFVCiphertext(new_c0, new_c1, self.params, self.scale)
        else:
            # 与明文相加
            plain_poly = self._encode_plaintext(other)
            new_c0 = (self.c0 + plain_poly) % self.params.cipher_modulus
            return BFVCiphertext(new_c0, self.c1.copy(), self.params, self.scale)
    
    def __radd__(self, other):
        return self.__add__(other)
    
    def __sub__(self, other: Union['BFVCiphertext', int, np.ndarray]) -> 'BFVCiphertext':
        """同态减法"""
        if isinstance(other, BFVCiphertext):
            new_c0 = (self.c0 - other.c0) % self.params.cipher_modulus
            new_c1 = (self.c1 - other.c1) % self.params.cipher_modulus
            return BFVCiphertext(new_c0, new_c1, self.params, self.scale)
        else:
            plain_poly = self._encode_plaintext(other)
            new_c0 = (self.c0 - plain_poly) % self.params.cipher_modulus
            return BFVCiphertext(new_c0, self.c1.copy(), self.params, self.scale)
    
    def __mul__(self, other: Union['BFVCiphertext', int, np.ndarray]) -> 'BFVCiphertext':
        """
        同态乘法（返回3项式，需要重线性化）
        
        注意：此方法返回未重线性化的密文，实际使用时需要调用relinearize
        """
        if isinstance(other, BFVCiphertext):
            # 密文-密文乘法（返回3项）
            # c0' = c0 * other.c0
            # c1' = c0 * other.c1 + c1 * other.c0
            # c2' = c1 * other.c1
            c0_new = self._poly_mul_mod(self.c0, other.c0, self.params.cipher_modulus)
            c1_new = (self._poly_mul_mod(self.c0, other.c1, self.params.cipher_modulus) +
                     self._poly_mul_mod(self.c1, other.c0, self.params.cipher_modulus)) % self.params.cipher_modulus
            c2_new = self._poly_mul_mod(self.c1, other.c1, self.params.cipher_modulus)
            
            # 返回扩展密文（3项）
            return BFVCiphertext(c0_new, c1_new, self.params, self.scale * other.scale, c2=c2_new)
        else:
            # 密文-明文乘法
            plain_poly = self._encode_plaintext(other)
            new_c0 = self._poly_mul_mod(self.c0, plain_poly, self.params.cipher_modulus)
            new_c1 = self._poly_mul_mod(self.c1, plain_poly, self.params.cipher_modulus)
            return BFVCiphertext(new_c0, new_c1, self.params, self.scale)
    
    def __rmul__(self, other):
        return self.__mul__(other)
    
    def _encode_plaintext(self, value: Union[int, np.ndarray]) -> np.ndarray:
        """将明文编码为多项式"""
        n = self.params.poly_degree
        if isinstance(value, int):
            poly = np.zeros(n, dtype=np.int64)
            poly[0] = value % self.params.plain_modulus
            return poly
        elif isinstance(value, np.ndarray):
            if len(value) > n:
                raise ValueError(f"明文数组长度超过多项式次数 {n}")
            poly = np.zeros(n, dtype=np.int64)
            poly[:len(value)] = value % self.params.plain_modulus
            return poly
        else:
            raise TypeError(f"不支持的明文类型: {type(value)}")
    
    def _poly_mul_mod(self, a: np.ndarray, b: np.ndarray, mod: int) -> np.ndarray:
        """多项式乘法模x^n+1"""
        n = len(a)
        result = np.zeros(n, dtype=np.int64)
        
        for i in range(n):
            for j in range(n):
                idx = (i + j) % n
                sign = -1 if (i + j) >= n else 1
                result[idx] = (result[idx] + sign * a[i] * b[j]) % mod
        
        return result
    
    def __post_init__(self):
        # 初始化扩展项（用于乘法后的3项密文）
        if not hasattr(self, 'c2'):
            self.c2 = None


class BFVScheme:
    """
    BFV全同态加密方案
    
    特性：
    - 整数上的全同态运算
    - 批处理编码支持
    - 重线性化和模切换
    
    示例:
        >>> params = BFVParameters(poly_degree=4096, plain_modulus=65537)
        >>> scheme = BFVScheme(params)
        >>> sk, pk = scheme.generate_keys()
        >>> ct1 = scheme.encrypt(42, pk)
        >>> ct2 = scheme.encrypt(100, pk)
        >>> ct_sum = ct1 + ct2  # 同态加法
        >>> result = scheme.decrypt(ct_sum, sk)  # 142
    """
    
    def __init__(self, params: Optional[BFVParameters] = None):
        """
        初始化BFV方案
        
        Args:
            params: BFV参数，None则使用默认参数
        """
        self.params = params or BFVParameters()
        self.secret_key: Optional[BFVSecretKey] = None
        self.public_key: Optional[BFVPublicKey] = None
        self.evaluation_key: Optional[BFVEvaluationKey] = None
        
        logger.info(f"初始化BFV方案: n={self.params.poly_degree}, "
                   f"t={self.params.plain_modulus}, q={self.params.cipher_modulus}")
    
    def _sample_error(self) -> np.ndarray:
        """采样错误多项式（高斯分布）"""
        n = self.params.poly_degree
        # 使用中心二项分布近似离散高斯
        error = np.random.binomial(2, 0.5, n) - np.random.binomial(2, 0.5, n)
        return error.astype(np.int64)
    
    def _sample_uniform(self, mod: int) -> np.ndarray:
        """采样均匀分布多项式"""
        n = self.params.poly_degree
        return np.random.randint(0, mod, n, dtype=np.int64)
    
    def _sample_ternary(self) -> np.ndarray:
        """采样三元分布多项式（系数为-1, 0, 1）"""
        n = self.params.poly_degree
        return np.random.choice([-1, 0, 1], n).astype(np.int64)
    
    def _poly_mul_mod(self, a: np.ndarray, b: np.ndarray, mod: int) -> np.ndarray:
        """多项式乘法模x^n+1"""
        n = len(a)
        result = np.zeros(n, dtype=np.int64)
        
        for i in range(n):
            for j in range(n):
                idx = (i + j) % n
                sign = -1 if (i + j) >= n else 1
                result[idx] = (result[idx] + sign * a[i] * b[j]) % mod
        
        return result
    
    def _ntt_transform(self, poly: np.ndarray, root: int, mod: int) -> np.ndarray:
        """
        数论变换(NTT) - 用于快速多项式乘法
        
        这是一个简化实现，实际应使用优化的NTT库
        """
        n = len(poly)
        result = np.zeros(n, dtype=np.int64)
        
        for k in range(n):
            sum_val = 0
            for j in range(n):
                sum_val = (sum_val + poly[j] * pow(root, j * k, mod)) % mod
            result[k] = sum_val
        
        return result
    
    def generate_keys(self) -> Tuple[BFVSecretKey, BFVPublicKey]:
        """
        生成BFV密钥对
        
        Returns:
            (secret_key, public_key): 私钥和公钥
        """
        logger.info("生成BFV密钥对...")
        
        n = self.params.poly_degree
        q = self.params.cipher_modulus
        
        # 采样私钥 s ← R_2 (系数为-1, 0, 1)
        s = self._sample_ternary()
        
        # 采样a ← R_q均匀随机
        a = self._sample_uniform(q)
        
        # 采样错误e
        e = self._sample_error()
        
        # 计算b = -(a * s + e) mod q
        as_product = self._poly_mul_mod(a, s, q)
        b = (-(as_product + e)) % q
        
        # 创建密钥对象
        self.secret_key = BFVSecretKey(s, self.params)
        self.public_key = BFVPublicKey(b, a, self.params)
        
        logger.info("密钥生成完成")
        return self.secret_key, self.public_key
    
    def generate_evaluation_key(self) -> BFVEvaluationKey:
        """
        生成重线性化密钥
        
        用于将乘法后的3项密文转换回2项
        
        Returns:
            BFVEvaluationKey: 重线性化密钥
        """
        if self.secret_key is None:
            raise ValueError("必须先生成密钥对")
        
        logger.info("生成重线性化密钥...")
        
        n = self.params.poly_degree
        q = self.params.cipher_modulus
        s = self.secret_key.s
        
        # 重线性化密钥生成
        # 简化的实现，实际应使用更复杂的密钥生成
        a_evk = self._sample_uniform(q)
        e_evk = self._sample_error()
        
        # evk0 = -(a_evk * s + e_evk) + w * s^2
        w = 2**20  # 分解基
        s_squared = self._poly_mul_mod(s, s, q)
        
        as_evk = self._poly_mul_mod(a_evk, s, q)
        evk0 = (-(as_evk + e_evk) + w * s_squared) % q
        evk1 = a_evk
        
        self.evaluation_key = BFVEvaluationKey(evk0, evk1, self.params)
        return self.evaluation_key
    
    def encrypt(self, plaintext: Union[int, List[int], np.ndarray], 
                public_key: BFVPublicKey) -> BFVCiphertext:
        """
        加密明文
        
        Args:
            plaintext: 待加密的明文（整数或整数数组）
            public_key: BFV公钥
            
        Returns:
            BFVCiphertext: 密文
        """
        n = self.params.poly_degree
        q = self.params.cipher_modulus
        t = self.params.plain_modulus
        
        # 编码明文为多项式
        if isinstance(plaintext, int):
            m = np.zeros(n, dtype=np.int64)
            m[0] = plaintext % t
        elif isinstance(plaintext, list):
            m = np.zeros(n, dtype=np.int64)
            for i, val in enumerate(plaintext[:n]):
                m[i] = val % t
        else:
            m = plaintext % t
        
        # 采样u, e1, e2
        u = self._sample_ternary()
        e1 = self._sample_error()
        e2 = self._sample_error()
        
        # 计算密文
        # c0 = p0 * u + e1 + delta * m
        # c1 = p1 * u + e2
        delta = q // t
        
        p0_u = self._poly_mul_mod(public_key.p0, u, q)
        c0 = (p0_u + e1 + delta * m) % q
        
        p1_u = self._poly_mul_mod(public_key.p1, u, q)
        c1 = (p1_u + e2) % q
        
        return BFVCiphertext(c0, c1, self.params)
    
    def decrypt(self, ciphertext: BFVCiphertext, 
                secret_key: BFVSecretKey) -> np.ndarray:
        """
        解密密文
        
        Args:
            ciphertext: BFV密文
            secret_key: BFV私钥
            
        Returns:
            np.ndarray: 解密后的明文多项式
        """
        q = self.params.cipher_modulus
        t = self.params.plain_modulus
        
        # 计算 m = round(t/q * (c0 + c1 * s))
        c1_s = self._poly_mul_mod(ciphertext.c1, secret_key.s, q)
        noisy_plain = (ciphertext.c0 + c1_s) % q
        
        # 缩放并舍入
        plain = np.round(noisy_plain * t / q).astype(np.int64) % t
        
        return plain
    
    def decrypt_to_int(self, ciphertext: BFVCiphertext, 
                       secret_key: BFVSecretKey) -> int:
        """
        解密为单个整数（第一个系数）
        
        Args:
            ciphertext: BFV密文
            secret_key: BFV私钥
            
        Returns:
            int: 解密后的整数值
        """
        plain = self.decrypt(ciphertext, secret_key)
        return int(plain[0])
    
    def relinearize(self, ciphertext: BFVCiphertext) -> BFVCiphertext:
        """
        重线性化（将3项密文转换回2项）
        
        乘法后的密文有3项(c0, c1, c2)，需要重线性化为2项
        
        Args:
            ciphertext: 可能包含3项的密文
            
        Returns:
            BFVCiphertext: 2项密文
        """
        if not hasattr(ciphertext, 'c2') or ciphertext.c2 is None:
            return ciphertext  # 已经是2项密文
        
        if self.evaluation_key is None:
            raise ValueError("重线性化密钥未生成")
        
        q = self.params.cipher_modulus
        
        # 使用重线性化密钥转换
        # c0' = c0 + evk0 * c2
        # c1' = c1 + evk1 * c2
        evk0_c2 = self._poly_mul_mod(self.evaluation_key.evk0, ciphertext.c2, q)
        evk1_c2 = self._poly_mul_mod(self.evaluation_key.evk1, ciphertext.c2, q)
        
        new_c0 = (ciphertext.c0 + evk0_c2) % q
        new_c1 = (ciphertext.c1 + evk1_c2) % q
        
        return BFVCiphertext(new_c0, new_c1, self.params, ciphertext.scale)
    
    def multiply_and_relinearize(self, ct1: BFVCiphertext, 
                                  ct2: BFVCiphertext) -> BFVCiphertext:
        """
        执行乘法并重线性化
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            BFVCiphertext: 重线性化后的密文
        """
        # 执行乘法（得到3项密文）
        ct_mul = ct1 * ct2
        
        # 重线性化
        return self.relinearize(ct_mul)
    
    def batch_encode(self, values: List[int]) -> np.ndarray:
        """
        批处理编码（SIMD编码）
        
        将多个整数编码为单个多项式，支持SIMD并行计算
        
        Args:
            values: 整数列表
            
        Returns:
            np.ndarray: 编码后的多项式
        """
        n = self.params.poly_degree
        slots = n // 2  # BFV批处理槽位数
        
        if len(values) > slots:
            raise ValueError(f"值数量超过批处理容量 {slots}")
        
        # 简化的批处理编码（实际应使用NTT）
        poly = np.zeros(n, dtype=np.int64)
        for i, val in enumerate(values):
            poly[i] = val % self.params.plain_modulus
        
        return poly
    
    def batch_decode(self, poly: np.ndarray) -> List[int]:
        """
        批处理解码
        
        Args:
            poly: 编码的多项式
            
        Returns:
            List[int]: 解码后的整数列表
        """
        n = self.params.poly_degree
        slots = n // 2
        
        return [int(poly[i] % self.params.plain_modulus) for i in range(slots)]
    
    def rotate(self, ciphertext: BFVCiphertext, steps: int) -> BFVCiphertext:
        """
        旋转密文（循环移位批处理槽位）
        
        Args:
            ciphertext: BFV密文
            steps: 旋转步数（正数向右，负数向左）
            
        Returns:
            BFVCiphertext: 旋转后的密文
        """
        # 简化的旋转实现（实际需要Galois密钥）
        n = self.params.poly_degree
        q = self.params.cipher_modulus
        
        # 对密文多项式系数进行循环移位
        new_c0 = np.roll(ciphertext.c0, steps)
        new_c1 = np.roll(ciphertext.c1, steps)
        
        return BFVCiphertext(new_c0, new_c1, self.params, ciphertext.scale)
    
    def sum_slots(self, ciphertext: BFVCiphertext) -> BFVCiphertext:
        """
        对所有批处理槽位求和（将结果复制到所有槽位）
        
        Args:
            ciphertext: BFV密文
            
        Returns:
            BFVCiphertext: 求和后的密文
        """
        n = self.params.poly_degree
        result = ciphertext
        
        # 使用旋转和加法实现全求和
        for i in range(n // 2 - 1):
            rotated = self.rotate(ciphertext, i + 1)
            result = result + rotated
        
        return result
    
    def get_noise_budget(self, ciphertext: BFVCiphertext, 
                         secret_key: BFVSecretKey) -> float:
        """
        估计剩余噪声预算
        
        Args:
            ciphertext: BFV密文
            secret_key: BFV私钥
            
        Returns:
            float: 剩余噪声预算（比特）
        """
        q = self.params.cipher_modulus
        t = self.params.plain_modulus
        
        # 计算当前噪声
        c1_s = self._poly_mul_mod(ciphertext.c1, secret_key.s, q)
        noisy_plain = (ciphertext.c0 + c1_s) % q
        
        # 噪声 = (t/q * noisy_plain) - round(t/q * noisy_plain)
        scaled = noisy_plain * t / q
        noise = np.max(np.abs(scaled - np.round(scaled)))
        
        # 计算噪声预算
        max_noise = q / (2 * t)
        noise_budget = np.log2(max_noise / (noise + 1e-10))
        
        return max(0, noise_budget)