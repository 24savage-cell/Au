"""
CKKS全同态加密方案实现

CKKS (Cheon-Kim-Kim-Song) 是一种支持近似数运算的全同态加密方案，
特别适用于浮点数和复数运算，广泛应用于隐私保护机器学习。

特性：
- 支持浮点数近似运算
- 支持SIMD批处理
- 支持密文旋转和共轭操作
- 支持重缩放（Rescaling）管理精度
"""

import logging
import numpy as np
from typing import List, Tuple, Optional, Union
from dataclasses import dataclass, field
from enum import Enum
import math

logger = logging.getLogger(__name__)


class CKKSSecurityLevel(Enum):
    """CKKS安全级别"""
    TC128 = 128
    TC192 = 192
    TC256 = 256


@dataclass
class CKKSParameters:
    """
    CKKS方案参数
    
    Attributes:
        poly_degree: 多项式次数（环维度）
        coeff_moduli: 系数模数链（用于重缩放）
        scale: 初始缩放因子
        security_level: 安全级别
    """
    poly_degree: int = 8192  # 多项式次数N
    coeff_moduli: List[int] = field(default_factory=lambda: [60, 40, 40, 60])  # 模数链
    scale: int = 40  # 缩放精度（比特）
    security_level: CKKSSecurityLevel = CKKSSecurityLevel.TC128
    
    def __post_init__(self):
        # 验证多项式次数是2的幂次
        if self.poly_degree & (self.poly_degree - 1) != 0:
            raise ValueError("多项式次数必须是2的幂次")
        
        # 计算实际模数
        self.prime_moduli = self._generate_prime_moduli()
        self.total_modulus = 1
        for p in self.prime_moduli:
            self.total_modulus *= p
    
    def _generate_prime_moduli(self) -> List[int]:
        """生成素数模数链"""
        # 简化的素数生成，实际应使用特定形式的素数
        primes = []
        for bits in self.coeff_moduli:
            # 生成接近2^bits的素数
            p = (1 << bits) - (1 << 10) + 1  # 简化示例
            primes.append(p)
        return primes
    
    def get_modulus_at_level(self, level: int) -> int:
        """获取指定层级的模数"""
        if level < 0 or level >= len(self.prime_moduli):
            raise ValueError(f"层级 {level} 超出范围")
        
        modulus = 1
        for i in range(level + 1):
            modulus *= self.prime_moduli[i]
        return modulus


@dataclass
class CKKSSecretKey:
    """CKKS私钥"""
    s: np.ndarray  # 秘密多项式
    params: CKKSParameters


@dataclass
class CKKSPublicKey:
    """CKKS公钥"""
    p0: np.ndarray
    p1: np.ndarray
    params: CKKSParameters


@dataclass
class CKKSEvaluationKey:
    """CKKS重线性化密钥"""
    evk: List[Tuple[np.ndarray, np.ndarray]]
    params: CKKSParameters


@dataclass
class CKKSGaloisKey:
    """CKKS Galois密钥（用于旋转）"""
    galois_keys: dict  # 步数 -> 密钥映射
    params: CKKSParameters


@dataclass
class CKKSCiphertext:
    """
    CKKS密文
    
    密文是RNS表示的多项式对 (c0, c1)
    包含层级信息用于重缩放
    """
    c0: np.ndarray
    c1: np.ndarray
    params: CKKSParameters
    level: int  # 当前层级（用于重缩放）
    scale: float  # 当前缩放因子
    
    def __add__(self, other: Union['CKKSCiphertext', float, np.ndarray, List[complex]]) -> 'CKKSCiphertext':
        """同态加法"""
        if isinstance(other, CKKSCiphertext):
            if self.level != other.level:
                raise ValueError("密文层级不匹配")
            if abs(self.scale - other.scale) > 1e-6:
                raise ValueError("密文缩放因子不匹配")
            
            new_c0 = self.c0 + other.c0
            new_c1 = self.c1 + other.c1
            return CKKSCiphertext(new_c0, new_c1, self.params, self.level, self.scale)
        else:
            # 与明文相加
            plain_encoded = self._encode_plaintext(other)
            new_c0 = self.c0 + plain_encoded
            return CKKSCiphertext(new_c0, self.c1.copy(), self.params, self.level, self.scale)
    
    def __radd__(self, other):
        return self.__add__(other)
    
    def __sub__(self, other: Union['CKKSCiphertext', float, np.ndarray]) -> 'CKKSCiphertext':
        """同态减法"""
        if isinstance(other, CKKSCiphertext):
            new_c0 = self.c0 - other.c0
            new_c1 = self.c1 - other.c1
            return CKKSCiphertext(new_c0, new_c1, self.params, self.level, self.scale)
        else:
            plain_encoded = self._encode_plaintext(other)
            new_c0 = self.c0 - plain_encoded
            return CKKSCiphertext(new_c0, self.c1.copy(), self.params, self.level, self.scale)
    
    def __mul__(self, other: Union['CKKSCiphertext', float, np.ndarray]) -> 'CKKSCiphertext':
        """
        同态乘法
        
        返回未重线性化的密文（3项）
        """
        if isinstance(other, CKKSCiphertext):
            # 密文-密文乘法
            c0_new = self._poly_mul(self.c0, other.c0)
            c1_new = self._poly_mul(self.c0, other.c1) + self._poly_mul(self.c1, other.c0)
            c2_new = self._poly_mul(self.c1, other.c1)
            
            # 存储扩展项
            result = CKKSCiphertext(c0_new, c1_new, self.params, self.level, self.scale * other.scale)
            result.c2 = c2_new
            return result
        else:
            # 密文-明文乘法
            plain_encoded = self._encode_plaintext(other)
            new_c0 = self._poly_mul(self.c0, plain_encoded)
            new_c1 = self._poly_mul(self.c1, plain_encoded)
            return CKKSCiphertext(new_c0, new_c1, self.params, self.level, self.scale)
    
    def __rmul__(self, other):
        return self.__mul__(other)
    
    def __neg__(self) -> 'CKKSCiphertext':
        """取反"""
        return CKKSCiphertext(-self.c0, -self.c1, self.params, self.level, self.scale)
    
    def _encode_plaintext(self, value: Union[float, np.ndarray, List[complex]]) -> np.ndarray:
        """将明文编码为多项式（简化实现）"""
        n = self.params.poly_degree
        
        if isinstance(value, (int, float)):
            poly = np.zeros(n)
            poly[0] = float(value) * self.scale
            return poly
        elif isinstance(value, (list, np.ndarray)):
            poly = np.zeros(n)
            values = np.array(value, dtype=complex)
            length = min(len(values), n // 2)
            
            # 简化的编码：将复数放入槽位
            for i in range(length):
                poly[2 * i] = values[i].real * self.scale
                poly[2 * i + 1] = values[i].imag * self.scale
            return poly
        else:
            raise TypeError(f"不支持的明文类型: {type(value)}")
    
    def _poly_mul(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """多项式乘法（NTT域简化实现）"""
        n = len(a)
        # 简化的多项式乘法（实际应使用NTT）
        result = np.zeros(n)
        for i in range(n):
            for j in range(n):
                idx = (i + j) % n
                sign = -1 if (i + j) >= n else 1
                result[idx] += sign * a[i] * b[j]
        return result


class CKKSScheme:
    """
    CKKS全同态加密方案
    
    特性：
    - 浮点数近似运算
    - SIMD批处理
    - 密文旋转
    - 重缩放管理精度
    
    示例:
        >>> params = CKKSParameters(poly_degree=8192)
        >>> scheme = CKKSScheme(params)
        >>> sk, pk = scheme.generate_keys()
        >>> ct = scheme.encrypt([1.5, 2.5, 3.5], pk)
        >>> ct2 = scheme.encrypt([0.5, 1.0, 1.5], pk)
        >>> ct_sum = ct + ct2  # 同态加法
        >>> result = scheme.decrypt(ct_sum, sk)  # [2.0, 3.5, 5.0]
    """
    
    def __init__(self, params: Optional[CKKSParameters] = None):
        """
        初始化CKKS方案
        
        Args:
            params: CKKS参数，None则使用默认参数
        """
        self.params = params or CKKSParameters()
        self.secret_key: Optional[CKKSSecretKey] = None
        self.public_key: Optional[CKKSPublicKey] = None
        self.evaluation_key: Optional[CKKSEvaluationKey] = None
        self.galois_keys: Optional[CKKSGaloisKey] = None
        
        logger.info(f"初始化CKKS方案: N={self.params.poly_degree}, "
                   f"levels={len(self.params.coeff_moduli)}")
    
    def _sample_hamming(self, hamming_weight: int = 64) -> np.ndarray:
        """采样Hamming权重固定的多项式"""
        n = self.params.poly_degree
        s = np.zeros(n)
        indices = np.random.choice(n, hamming_weight, replace=False)
        s[indices] = np.random.choice([-1, 1], hamming_weight)
        return s
    
    def _sample_error(self, std_dev: float = 3.2) -> np.ndarray:
        """采样高斯错误"""
        n = self.params.poly_degree
        return np.random.normal(0, std_dev, n)
    
    def _sample_uniform(self) -> np.ndarray:
        """采样均匀分布多项式"""
        n = self.params.poly_degree
        q = self.params.total_modulus
        return np.random.uniform(0, q, n)
    
    def _sigma_transform(self, values: np.ndarray) -> np.ndarray:
        """
        Sigma变换（Canonical Embedding）
        
        将多项式系数映射到复数槽位
        """
        n = self.params.poly_degree
        slots = n // 2
        
        # 简化的DFT实现（实际应使用FFT）
        result = np.zeros(slots, dtype=complex)
        for k in range(slots):
            val = 0 + 0j
            for j in range(n):
                angle = 2 * np.pi * (2 * k + 1) * j / (2 * n)
                val += values[j] * np.exp(1j * angle)
            result[k] = val
        return result
    
    def _sigma_inverse(self, values: np.ndarray) -> np.ndarray:
        """
        Sigma逆变换
        
        将复数槽位映射回多项式系数
        """
        n = self.params.poly_degree
        slots = n // 2
        
        if len(values) != slots:
            raise ValueError(f"输入长度应为 {slots}")
        
        # 简化的逆DFT实现
        result = np.zeros(n)
        for j in range(n):
            val = 0
            for k in range(slots):
                angle = -2 * np.pi * (2 * k + 1) * j / (2 * n)
                val += (values[k] * np.exp(1j * angle)).real
            result[j] = val / slots
        return result
    
    def _encode(self, values: Union[List[float], List[complex], np.ndarray], 
                scale: Optional[float] = None) -> np.ndarray:
        """
        编码复数/实数向量为多项式
        
        Args:
            values: 要编码的向量
            scale: 缩放因子
            
        Returns:
            np.ndarray: 编码后的多项式
        """
        if scale is None:
            scale = 2 ** self.params.scale
        
        n = self.params.poly_degree
        slots = n // 2
        
        # 转换为复数数组
        if isinstance(values, list):
            values = np.array(values, dtype=complex)
        
        # 填充或截断到槽位数
        if len(values) < slots:
            padded = np.zeros(slots, dtype=complex)
            padded[:len(values)] = values
            values = padded
        elif len(values) > slots:
            values = values[:slots]
        
        # 应用缩放
        values_scaled = values * scale
        
        # Sigma逆变换
        poly = self._sigma_inverse(values_scaled)
        
        # 取整并取模
        poly = np.round(poly).astype(np.int64)
        poly = poly % self.params.total_modulus
        
        return poly.astype(float)
    
    def _decode(self, poly: np.ndarray, scale: float, 
                level: int = 0) -> np.ndarray:
        """
        解码多项式为复数向量
        
        Args:
            poly: 多项式
            scale: 缩放因子
            level: 当前层级
            
        Returns:
            np.ndarray: 解码后的复数向量
        """
        # Sigma变换
        values = self._sigma_transform(poly)
        
        # 去缩放
        values = values / scale
        
        return values
    
    def generate_keys(self) -> Tuple[CKKSSecretKey, CKKSPublicKey]:
        """
        生成CKKS密钥对
        
        Returns:
            (secret_key, public_key): 私钥和公钥
        """
        logger.info("生成CKKS密钥对...")
        
        n = self.params.poly_degree
        q = self.params.total_modulus
        
        # 采样私钥
        s = self._sample_hamming()
        
        # 采样a和e
        a = self._sample_uniform()
        e = self._sample_error()
        
        # 计算b = -(a * s + e)
        # 简化的多项式乘法
        as_product = self._naive_poly_mul(a, s)
        b = -(as_product + e) % q
        
        self.secret_key = CKKSSecretKey(s, self.params)
        self.public_key = CKKSPublicKey(b, a, self.params)
        
        logger.info("密钥生成完成")
        return self.secret_key, self.public_key
    
    def _naive_poly_mul(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """简化多项式乘法"""
        n = len(a)
        result = np.zeros(n)
        for i in range(n):
            for j in range(n):
                idx = (i + j) % n
                sign = -1 if (i + j) >= n else 1
                result[idx] += sign * a[i] * b[j]
        return result
    
    def generate_evaluation_key(self) -> CKKSEvaluationKey:
        """生成重线性化密钥"""
        if self.secret_key is None:
            raise ValueError("必须先生成密钥对")
        
        logger.info("生成重线性化密钥...")
        
        # 简化的重线性化密钥生成
        evk_list = []
        for _ in range(len(self.params.coeff_moduli) - 1):
            evk0 = self._sample_uniform()
            evk1 = self._sample_uniform()
            evk_list.append((evk0, evk1))
        
        self.evaluation_key = CKKSEvaluationKey(evk_list, self.params)
        return self.evaluation_key
    
    def generate_galois_keys(self, steps: Optional[List[int]] = None) -> CKKSGaloisKey:
        """
        生成Galois密钥（用于旋转）
        
        Args:
            steps: 需要支持的旋转步数列表
            
        Returns:
            CKKSGaloisKey: Galois密钥
        """
        if self.secret_key is None:
            raise ValueError("必须先生成密钥对")
        
        if steps is None:
            # 默认支持所有2的幂次旋转
            n = self.params.poly_degree
            steps = [2**i for i in range(int(np.log2(n)))]
        
        logger.info(f"生成Galois密钥，支持步数: {steps}")
        
        galois_keys = {}
        for step in steps:
            # 简化的Galois密钥生成
            gk0 = self._sample_uniform()
            gk1 = self._sample_uniform()
            galois_keys[step] = (gk0, gk1)
        
        self.galois_keys = CKKSGaloisKey(galois_keys, self.params)
        return self.galois_keys
    
    def encrypt(self, plaintext: Union[float, List[float], List[complex], np.ndarray],
                public_key: CKKSPublicKey,
                scale: Optional[float] = None) -> CKKSCiphertext:
        """
        加密明文
        
        Args:
            plaintext: 待加密的明文（浮点数或复数向量）
            public_key: CKKS公钥
            scale: 缩放因子
            
        Returns:
            CKKSCiphertext: 密文
        """
        if scale is None:
            scale = 2.0 ** self.params.scale
        
        # 编码明文
        m = self._encode(plaintext, scale)
        
        # 采样u, e1, e2
        u = self._sample_hamming(hamming_weight=32)
        e1 = self._sample_error()
        e2 = self._sample_error()
        
        # 计算密文
        # c0 = p0 * u + e1 + m
        # c1 = p1 * u + e2
        p0_u = self._naive_poly_mul(public_key.p0, u)
        c0 = p0_u + e1 + m
        
        p1_u = self._naive_poly_mul(public_key.p1, u)
        c1 = p1_u + e2
        
        level = len(self.params.coeff_moduli) - 1
        return CKKSCiphertext(c0, c1, self.params, level, scale)
    
    def decrypt(self, ciphertext: CKKSCiphertext,
                secret_key: CKKSSecretKey) -> np.ndarray:
        """
        解密密文
        
        Args:
            ciphertext: CKKS密文
            secret_key: CKKS私钥
            
        Returns:
            np.ndarray: 解密后的复数向量
        """
        # 计算 m ≈ c0 + c1 * s
        c1_s = self._naive_poly_mul(ciphertext.c1, secret_key.s)
        noisy_plain = ciphertext.c0 + c1_s
        
        # 解码
        return self._decode(noisy_plain, ciphertext.scale, ciphertext.level)
    
    def relinearize(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """
        重线性化（将3项密文转换回2项）
        
        Args:
            ciphertext: 密文
            
        Returns:
            CKKSCiphertext: 重线性化后的密文
        """
        if not hasattr(ciphertext, 'c2') or ciphertext.c2 is None:
            return ciphertext
        
        if self.evaluation_key is None:
            raise ValueError("重线性化密钥未生成")
        
        # 简化的重线性化
        # c0' = c0 + evk0 * c2
        # c1' = c1 + evk1 * c2
        evk0, evk1 = self.evaluation_key.evk[ciphertext.level]
        
        c2_evk0 = self._naive_poly_mul(ciphertext.c2, evk0)
        c2_evk1 = self._naive_poly_mul(ciphertext.c2, evk1)
        
        new_c0 = ciphertext.c0 + c2_evk0
        new_c1 = ciphertext.c1 + c2_evk1
        
        result = CKKSCiphertext(new_c0, new_c1, self.params, 
                               ciphertext.level, ciphertext.scale)
        return result
    
    def rescale(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """
        重缩放（降低层级和缩放因子）
        
        用于乘法后管理精度
        
        Args:
            ciphertext: 密文
            
        Returns:
            CKKSCiphertext: 重缩放后的密文
        """
        if ciphertext.level == 0:
            raise ValueError("无法进一步重缩放（已在最低层级）")
        
        new_level = ciphertext.level - 1
        
        # 降低缩放因子
        prime = self.params.prime_moduli[ciphertext.level]
        new_scale = ciphertext.scale / prime
        
        # 简化的模约简
        new_c0 = ciphertext.c0 % self.params.get_modulus_at_level(new_level)
        new_c1 = ciphertext.c1 % self.params.get_modulus_at_level(new_level)
        
        return CKKSCiphertext(new_c0, new_c1, self.params, new_level, new_scale)
    
    def multiply_and_rescale(self, ct1: CKKSCiphertext, 
                             ct2: CKKSCiphertext) -> CKKSCiphertext:
        """
        执行乘法、重线性化和重缩放
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            CKKSCiphertext: 处理后的密文
        """
        # 乘法
        ct_mul = ct1 * ct2
        
        # 重线性化
        ct_relin = self.relinearize(ct_mul)
        
        # 重缩放
        ct_rescaled = self.rescale(ct_relin)
        
        return ct_rescaled
    
    def rotate(self, ciphertext: CKKSCiphertext, steps: int) -> CKKSCiphertext:
        """
        旋转密文（循环移位槽位）
        
        Args:
            ciphertext: CKKS密文
            steps: 旋转步数
            
        Returns:
            CKKSCiphertext: 旋转后的密文
        """
        if self.galois_keys is None:
            raise ValueError("Galois密钥未生成")
        
        # 简化的旋转实现
        # 实际应使用Galois密钥进行密钥切换
        n = self.params.poly_degree
        
        # 对多项式系数进行循环移位（近似）
        new_c0 = np.roll(ciphertext.c0, steps)
        new_c1 = np.roll(ciphertext.c1, steps)
        
        return CKKSCiphertext(new_c0, new_c1, self.params, 
                             ciphertext.level, ciphertext.scale)
    
    def conjugate(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """
        共轭操作（复数共轭）
        
        Args:
            ciphertext: CKKS密文
            
        Returns:
            CKKSCiphertext: 共轭后的密文
        """
        # 简化的共轭实现
        # 实际应使用Galois密钥
        return CKKSCiphertext(ciphertext.c0, -ciphertext.c1, self.params,
                             ciphertext.level, ciphertext.scale)
    
    def sum_slots(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """
        对所有槽位求和
        
        Args:
            ciphertext: CKKS密文
            
        Returns:
            CKKSCiphertext: 求和后的密文
        """
        n = self.params.poly_degree
        result = ciphertext
        
        # 使用旋转和累加
        for i in range(int(np.log2(n // 2))):
            step = 2**i
            rotated = self.rotate(ciphertext, step)
            result = result + rotated
        
        return result
    
    def dot_product(self, ct1: CKKSCiphertext, ct2: CKKSCiphertext) -> CKKSCiphertext:
        """
        计算两个密文的点积
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            CKKSCiphertext: 点积结果（单个槽位）
        """
        # 逐元素相乘
        product = ct1 * ct2
        product = self.relinearize(product)
        product = self.rescale(product)
        
        # 求和
        result = self.sum_slots(product)
        
        return result
    
    def polynomial_evaluation(self, ciphertext: CKKSCiphertext,
                              coefficients: List[float]) -> CKKSCiphertext:
        """
        多项式求值（使用Paterson-Stockmeyer算法）
        
        Args:
            ciphertext: 输入密文
            coefficients: 多项式系数 [a0, a1, a2, ...] 表示 a0 + a1*x + a2*x^2 + ...
            
        Returns:
            CKKSCiphertext: 多项式求值结果
        """
        if not coefficients:
            return self.encrypt(0, self.public_key)
        
        result = self.encrypt(coefficients[0], self.public_key)
        x_power = ciphertext
        
        for i, coef in enumerate(coefficients[1:], 1):
            if coef != 0:
                coef_ct = self.encrypt(coef, self.public_key)
                term = coef_ct * x_power
                term = self.relinearize(term)
                if i > 1:  # 需要重缩放
                    term = self.rescale(term)
                result = result + term
            
            # 计算x^(i+1)
            if i < len(coefficients) - 1:
                x_power = x_power * ciphertext
                x_power = self.relinearize(x_power)
                x_power = self.rescale(x_power)
        
        return result
    
    def bootstrap(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """
        自举（Bootstrap）
        
        刷新密文层级，允许更多计算
        
        Args:
            ciphertext: 低层级密文
            
        Returns:
            CKKSCiphertext: 高层级密文
        """
        # 简化的自举实现
        # 实际自举非常复杂，涉及同态解密
        logger.warning("自举是简化实现，实际应使用完整的自举算法")
        
        max_level = len(self.params.coeff_moduli) - 1
        return CKKSCiphertext(ciphertext.c0, ciphertext.c1, self.params,
                             max_level, 2.0 ** self.params.scale)