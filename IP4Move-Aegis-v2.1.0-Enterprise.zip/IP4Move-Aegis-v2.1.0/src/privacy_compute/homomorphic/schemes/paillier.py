"""
Paillier半同态加密方案实现

Paillier加密是一种概率性非对称加密算法，具有同态加法性质：
- E(m1) * E(m2) = E(m1 + m2)
- E(m)^k = E(k * m)

适用于需要保护隐私的聚合计算场景。
"""

import random
import logging
from typing import Optional, Tuple, Union
from dataclasses import dataclass

# 配置日志
logger = logging.getLogger(__name__)


@dataclass
class PaillierKeyPair:
    """Paillier密钥对"""
    public_key: 'PaillierPublicKey'
    private_key: 'PaillierPrivateKey'


@dataclass  
class PaillierPublicKey:
    """Paillier公钥"""
    n: int  # 模数 n = p * q
    g: int  # 生成元
    n_squared: int  # n^2，预计算优化
    
    def __post_init__(self):
        if self.n_squared == 0:
            self.n_squared = self.n * self.n


@dataclass
class PaillierPrivateKey:
    """Paillier私钥"""
    p: int  # 大素数p
    q: int  # 大素数q
    n: int  # 模数
    lambda_val: int  # λ = lcm(p-1, q-1)
    mu: int  # μ = L(g^λ mod n^2)^(-1) mod n


@dataclass
class PaillierCiphertext:
    """Paillier密文"""
    c: int  # 密文值
    public_key: PaillierPublicKey
    
    def __add__(self, other: Union['PaillierCiphertext', int]) -> 'PaillierCiphertext':
        """同态加法：支持密文+密文或密文+明文"""
        if isinstance(other, PaillierCiphertext):
            if self.public_key.n != other.public_key.n:
                raise ValueError("密文必须使用相同的公钥")
            # E(m1) * E(m2) mod n^2 = E(m1 + m2)
            new_c = (self.c * other.c) % self.public_key.n_squared
        else:
            # E(m) * g^plaintext mod n^2 = E(m + plaintext)
            new_c = (self.c * pow(self.public_key.g, other, self.public_key.n_squared)) % self.public_key.n_squared
        return PaillierCiphertext(new_c, self.public_key)
    
    def __radd__(self, other: int) -> 'PaillierCiphertext':
        return self.__add__(other)
    
    def __mul__(self, scalar: int) -> 'PaillierCiphertext':
        """标量乘法：密文 * 标量 = E(m * scalar)"""
        # E(m)^scalar mod n^2 = E(m * scalar)
        new_c = pow(self.c, scalar, self.public_key.n_squared)
        return PaillierCiphertext(new_c, self.public_key)
    
    def __rmul__(self, scalar: int) -> 'PaillierCiphertext':
        return self.__mul__(scalar)


class PaillierScheme:
    """
    Paillier半同态加密方案
    
    特性：
    - 同态加法：支持密文相加
    - 标量乘法：支持密文与常数相乘
    - 概率加密：相同明文加密得到不同密文
    
    示例:
        >>> scheme = PaillierScheme(key_size=2048)
        >>> keypair = scheme.generate_keypair()
        >>> ct1 = scheme.encrypt(100, keypair.public_key)
        >>> ct2 = scheme.encrypt(200, keypair.public_key)
        >>> ct_sum = ct1 + ct2  # 同态加法
        >>> result = scheme.decrypt(ct_sum, keypair.private_key)  # 300
    """
    
    def __init__(self, key_size: int = 2048):
        """
        初始化Paillier加密方案
        
        Args:
            key_size: 密钥位数，默认2048位（推荐）
        """
        self.key_size = key_size
        logger.info(f"初始化Paillier方案，密钥长度: {key_size}位")
    
    def _is_prime(self, n: int, k: int = 10) -> bool:
        """
        Miller-Rabin素性测试
        
        Args:
            n: 待测试的数
            k: 测试轮数，越大准确率越高
            
        Returns:
            是否为素数
        """
        if n < 2:
            return False
        if n == 2 or n == 3:
            return True
        if n % 2 == 0:
            return False
        
        # 将n-1写成2^r * d的形式
        r, d = 0, n - 1
        while d % 2 == 0:
            r += 1
            d //= 2
        
        # 进行k轮测试
        for _ in range(k):
            a = random.randrange(2, n - 1)
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                continue
            for _ in range(r - 1):
                x = pow(x, 2, n)
                if x == n - 1:
                    break
            else:
                return False
        return True
    
    def _generate_prime(self, bits: int) -> int:
        """
        生成指定位数的大素数
        
        Args:
            bits: 素数的位数
            
        Returns:
            大素数
        """
        while True:
            # 生成奇数
            n = random.getrandbits(bits) | 1 | (1 << (bits - 1))
            if self._is_prime(n):
                return n
    
    def _lcm(self, a: int, b: int) -> int:
        """计算最小公倍数"""
        from math import gcd
        return abs(a * b) // gcd(a, b)
    
    def _L(self, u: int, n: int) -> int:
        """
        L函数：L(u) = (u - 1) / n
        
        Args:
            u: 输入值
            n: 模数
            
        Returns:
            L(u)的值
        """
        return (u - 1) // n
    
    def generate_keypair(self) -> PaillierKeyPair:
        """
        生成Paillier密钥对
        
        Returns:
            PaillierKeyPair: 包含公钥和私钥的密钥对
            
        Raises:
            ValueError: 密钥生成失败时抛出
        """
        try:
            logger.info("开始生成Paillier密钥对...")
            
            # 生成两个大素数p和q
            p = self._generate_prime(self.key_size // 2)
            q = self._generate_prime(self.key_size // 2)
            
            # 确保p ≠ q
            while p == q:
                q = self._generate_prime(self.key_size // 2)
            
            # 计算n和n^2
            n = p * q
            n_squared = n * n
            
            # 计算λ = lcm(p-1, q-1)
            lambda_val = self._lcm(p - 1, q - 1)
            
            # 选择g，通常g = n + 1是安全的选择
            g = n + 1
            
            # 计算μ = L(g^λ mod n^2)^(-1) mod n
            g_lambda = pow(g, lambda_val, n_squared)
            L_g_lambda = self._L(g_lambda, n)
            
            # 计算模逆元
            def mod_inverse(a: int, m: int) -> int:
                """计算模逆元"""
                def extended_gcd(a: int, b: int) -> Tuple[int, int, int]:
                    if a == 0:
                        return b, 0, 1
                    gcd, x1, y1 = extended_gcd(b % a, a)
                    x = y1 - (b // a) * x1
                    y = x1
                    return gcd, x, y
                
                _, x, _ = extended_gcd(a % m, m)
                return (x % m + m) % m
            
            mu = mod_inverse(L_g_lambda, n)
            
            # 创建密钥对象
            public_key = PaillierPublicKey(n=n, g=g, n_squared=n_squared)
            private_key = PaillierPrivateKey(
                p=p, q=q, n=n, 
                lambda_val=lambda_val, 
                mu=mu
            )
            
            logger.info(f"密钥对生成成功，n的位数: {n.bit_length()}")
            return PaillierKeyPair(public_key, private_key)
            
        except Exception as e:
            logger.error(f"密钥生成失败: {str(e)}")
            raise ValueError(f"密钥生成失败: {str(e)}")
    
    def encrypt(self, plaintext: int, public_key: PaillierPublicKey) -> PaillierCiphertext:
        """
        加密明文
        
        Paillier加密公式：
        c = g^m * r^n mod n^2
        其中r是随机数，保证概率加密性质
        
        Args:
            plaintext: 待加密的明文（非负整数，且小于n）
            public_key: Paillier公钥
            
        Returns:
            PaillierCiphertext: 密文对象
            
        Raises:
            ValueError: 明文超出有效范围时抛出
        """
        if plaintext < 0:
            raise ValueError("Paillier加密只支持非负整数")
        if plaintext >= public_key.n:
            raise ValueError(f"明文必须小于n ({public_key.n})")
        
        try:
            # 选择随机数r，满足gcd(r, n) = 1
            while True:
                r = random.randrange(1, public_key.n)
                from math import gcd
                if gcd(r, public_key.n) == 1:
                    break
            
            # 计算密文：c = g^m * r^n mod n^2
            g_m = pow(public_key.g, plaintext, public_key.n_squared)
            r_n = pow(r, public_key.n, public_key.n_squared)
            ciphertext = (g_m * r_n) % public_key.n_squared
            
            return PaillierCiphertext(ciphertext, public_key)
            
        except Exception as e:
            logger.error(f"加密失败: {str(e)}")
            raise ValueError(f"加密失败: {str(e)}")
    
    def decrypt(self, ciphertext: PaillierCiphertext, private_key: PaillierPrivateKey) -> int:
        """
        解密密文
        
        Paillier解密公式：
        m = L(c^λ mod n^2) * μ mod n
        
        Args:
            ciphertext: 待解密的密文
            private_key: Paillier私钥
            
        Returns:
            int: 解密后的明文
            
        Raises:
            ValueError: 解密失败时抛出
        """
        try:
            n = private_key.n
            n_squared = n * n
            
            # 计算c^λ mod n^2
            c_lambda = pow(ciphertext.c, private_key.lambda_val, n_squared)
            
            # 计算L(c^λ mod n^2)
            L_c = self._L(c_lambda, n)
            
            # 计算明文：m = L(c^λ) * μ mod n
            plaintext = (L_c * private_key.mu) % n
            
            return plaintext
            
        except Exception as e:
            logger.error(f"解密失败: {str(e)}")
            raise ValueError(f"解密失败: {str(e)}")
    
    def add_encrypted(
        self, 
        ct1: PaillierCiphertext, 
        ct2: PaillierCiphertext
    ) -> PaillierCiphertext:
        """
        同态加法：E(m1) + E(m2) = E(m1 + m2)
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            PaillierCiphertext: 加密后的和
        """
        return ct1 + ct2
    
    def add_plaintext(
        self, 
        ciphertext: PaillierCiphertext, 
        plaintext: int
    ) -> PaillierCiphertext:
        """
        密文与明文相加：E(m1) + m2 = E(m1 + m2)
        
        Args:
            ciphertext: 密文
            plaintext: 要加的明文
            
        Returns:
            PaillierCiphertext: 加密后的和
        """
        return ciphertext + plaintext
    
    def multiply_scalar(
        self, 
        ciphertext: PaillierCiphertext, 
        scalar: int
    ) -> PaillierCiphertext:
        """
        标量乘法：E(m) * k = E(m * k)
        
        Args:
            ciphertext: 密文
            scalar: 标量乘数
            
        Returns:
            PaillierCiphertext: 加密后的积
        """
        return ciphertext * scalar
    
    def encrypt_batch(
        self, 
        plaintexts: list, 
        public_key: PaillierPublicKey
    ) -> list:
        """
        批量加密多个明文
        
        Args:
            plaintexts: 明文列表
            public_key: Paillier公钥
            
        Returns:
            list: 密文列表
        """
        return [self.encrypt(p, public_key) for p in plaintexts]
    
    def decrypt_batch(
        self, 
        ciphertexts: list, 
        private_key: PaillierPrivateKey
    ) -> list:
        """
        批量解密多个密文
        
        Args:
            ciphertexts: 密文列表
            private_key: Paillier私钥
            
        Returns:
            list: 明文列表
        """
        return [self.decrypt(c, private_key) for c in ciphertexts]
    
    def sum_encrypted(
        self, 
        ciphertexts: list
    ) -> PaillierCiphertext:
        """
        计算多个密文的和（同态聚合）
        
        Args:
            ciphertexts: 密文列表
            
        Returns:
            PaillierCiphertext: 加密后的总和
        """
        if not ciphertexts:
            raise ValueError("密文列表不能为空")
        
        result = ciphertexts[0]
        for ct in ciphertexts[1:]:
            result = result + ct
        return result
    
    def get_public_key_bytes(self, public_key: PaillierPublicKey) -> bytes:
        """
        将公钥序列化为字节
        
        Args:
            public_key: Paillier公钥
            
        Returns:
            bytes: 序列化后的公钥
        """
        import pickle
        return pickle.dumps({
            'n': public_key.n,
            'g': public_key.g,
            'n_squared': public_key.n_squared
        })
    
    def load_public_key_from_bytes(self, data: bytes) -> PaillierPublicKey:
        """
        从字节反序列化公钥
        
        Args:
            data: 序列化的公钥数据
            
        Returns:
            PaillierPublicKey: 公钥对象
        """
        import pickle
        key_data = pickle.loads(data)
        return PaillierPublicKey(
            n=key_data['n'],
            g=key_data['g'],
            n_squared=key_data['n_squared']
        )