"""
批处理优化模块

提供SIMD编码和批处理技术，提高同态加密运算效率：
- SIMD编码：单指令多数据
- DFT编码：离散傅里叶变换编码
- 批处理运算
"""

import logging
import numpy as np
from typing import List, Optional, Any, Union, Tuple
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class BatchConfig:
    """批处理配置"""
    slot_count: int  # 槽位数
    scale: float     # 缩放因子
    modulus_chain: List[int]  # 模数链


class SIMDEncoder:
    """
    SIMD编码器
    
    将多个数据值编码到单个密文的多个槽位中，
    实现单指令多数据并行计算。
    
    示例:
        >>> encoder = SIMDEncoder(slot_count=4096)
        >>> values = [1.0, 2.0, 3.0, 4.0]
        >>> encoded = encoder.encode(values)
        >>> # 对encoded的一次运算同时作用于所有值
    """
    
    def __init__(self, slot_count: int = 4096, scale: float = 2**40):
        """
        初始化SIMD编码器
        
        Args:
            slot_count: 槽位数（通常为多项式次数的一半）
            scale: 缩放因子
        """
        self.slot_count = slot_count
        self.scale = scale
        
        logger.info(f"初始化SIMD编码器: slots={slot_count}, scale={scale}")
    
    def encode(self, values: List[float], 
               fill_empty: bool = True) -> np.ndarray:
        """
        编码值列表到多项式
        
        Args:
            values: 要编码的值列表
            fill_empty: 是否填充空槽位
            
        Returns:
            np.ndarray: 编码后的多项式系数
        """
        if len(values) > self.slot_count:
            raise ValueError(f"值数量超过槽位数 {self.slot_count}")
        
        # 创建槽位数组
        slots = np.zeros(self.slot_count, dtype=complex)
        
        # 填充值
        for i, val in enumerate(values):
            slots[i] = complex(val, 0)
        
        # 应用缩放
        slots = slots * self.scale
        
        # 逆DFT转换为多项式系数
        poly = self._inverse_dft(slots)
        
        # 取整并取模
        poly = np.round(poly.real).astype(np.int64)
        
        return poly
    
    def decode(self, poly: np.ndarray, 
               num_values: Optional[int] = None) -> List[float]:
        """
        解码多项式为值列表
        
        Args:
            poly: 多项式系数
            num_values: 要解码的值数量
            
        Returns:
            List[float]: 解码后的值列表
        """
        # DFT转换为槽位
        slots = self._dft(poly)
        
        # 去缩放
        slots = slots / self.scale
        
        # 提取实部
        if num_values is None:
            num_values = self.slot_count
        
        values = [float(slots[i].real) for i in range(min(num_values, self.slot_count))]
        
        return values
    
    def _dft(self, poly: np.ndarray) -> np.ndarray:
        """
        离散傅里叶变换
        
        Args:
            poly: 多项式系数
            
        Returns:
            np.ndarray: 变换后的槽位值
        """
        n = len(poly)
        result = np.zeros(n // 2, dtype=complex)
        
        for k in range(n // 2):
            val = 0 + 0j
            for j in range(n):
                angle = 2 * np.pi * (2 * k + 1) * j / (2 * n)
                val += poly[j] * np.exp(1j * angle)
            result[k] = val
        
        return result
    
    def _inverse_dft(self, slots: np.ndarray) -> np.ndarray:
        """
        逆离散傅里叶变换
        
        Args:
            slots: 槽位值
            
        Returns:
            np.ndarray: 多项式系数
        """
        n = self.slot_count * 2
        result = np.zeros(n)
        
        for j in range(n):
            val = 0 + 0j
            for k in range(self.slot_count):
                angle = -2 * np.pi * (2 * k + 1) * j / (2 * n)
                val += slots[k] * np.exp(1j * angle)
            result[j] = val.real / self.slot_count
        
        return result
    
    def batch_add(self, poly_a: np.ndarray, poly_b: np.ndarray) -> np.ndarray:
        """
        批处理加法
        
        对两个编码多项式执行槽位级加法
        
        Args:
            poly_a: 第一个多项式
            poly_b: 第二个多项式
            
        Returns:
            np.ndarray: 结果多项式
        """
        return poly_a + poly_b
    
    def batch_multiply(self, poly_a: np.ndarray, 
                       poly_b: np.ndarray) -> np.ndarray:
        """
        批处理乘法
        
        对两个编码多项式执行槽位级乘法
        
        Args:
            poly_a: 第一个多项式
            poly_b: 第二个多项式
            
        Returns:
            np.ndarray: 结果多项式
        """
        # 在DFT域中，乘法对应于槽位级乘法
        slots_a = self._dft(poly_a)
        slots_b = self._dft(poly_b)
        
        slots_result = slots_a * slots_b
        
        return self._inverse_dft(slots_result)
    
    def rotate_slots(self, poly: np.ndarray, 
                     steps: int) -> np.ndarray:
        """
        旋转槽位
        
        将槽位循环移位
        
        Args:
            poly: 多项式
            steps: 旋转步数
            
        Returns:
            np.ndarray: 旋转后的多项式
        """
        slots = self._dft(poly)
        slots_rotated = np.roll(slots, steps)
        return self._inverse_dft(slots_rotated)
    
    def sum_all_slots(self, poly: np.ndarray) -> np.ndarray:
        """
        求和所有槽位
        
        将所有槽位的值相加，结果放在每个槽位中
        
        Args:
            poly: 多项式
            
        Returns:
            np.ndarray: 求和后的多项式
        """
        slots = self._dft(poly)
        total = np.sum(slots)
        
        # 将总和放入所有槽位
        slots_filled = np.full(self.slot_count, total / self.slot_count)
        
        return self._inverse_dft(slots_filled)


class DFTCoder:
    """
    DFT编码器
    
    使用离散傅里叶变换进行编码，支持复数运算。
    """
    
    def __init__(self, size: int = 4096):
        """
        初始化DFT编码器
        
        Args:
            size: 变换大小
        """
        self.size = size
        
        logger.info(f"初始化DFT编码器: size={size}")
    
    def encode(self, values: List[complex]) -> np.ndarray:
        """
        编码复数列表
        
        Args:
            values: 复数列表
            
        Returns:
            np.ndarray: DFT系数
        """
        if len(values) > self.size:
            raise ValueError(f"值数量超过大小 {self.size}")
        
        # 填充
        padded = np.zeros(self.size, dtype=complex)
        padded[:len(values)] = values
        
        # DFT
        return np.fft.fft(padded)
    
    def decode(self, coefficients: np.ndarray, 
               num_values: Optional[int] = None) -> List[complex]:
        """
        解码DFT系数
        
        Args:
            coefficients: DFT系数
            num_values: 要解码的值数量
            
        Returns:
            List[complex]: 复数列表
        """
        # 逆DFT
        values = np.fft.ifft(coefficients)
        
        if num_values is None:
            num_values = self.size
        
        return values[:num_values].tolist()


class BatchingOptimizer:
    """
    批处理优化器
    
    管理批处理操作，优化同态加密计算效率。
    """
    
    def __init__(self, scheme: Any, slot_count: int = 4096):
        """
        初始化批处理优化器
        
        Args:
            scheme: 同态加密方案实例
            slot_count: 槽位数
        """
        self.scheme = scheme
        self.slot_count = slot_count
        self.encoder = SIMDEncoder(slot_count)
        
        logger.info(f"初始化批处理优化器: slots={slot_count}")
    
    def batch_encrypt(self, values_list: List[List[float]], 
                      public_key: Any) -> List[Any]:
        """
        批量加密多个值列表
        
        每个列表编码到一个密文中
        
        Args:
            values_list: 值列表的列表
            public_key: 公钥
            
        Returns:
            加密密文列表
        """
        ciphertexts = []
        
        for values in values_list:
            # 编码
            encoded = self.encoder.encode(values)
            
            # 加密
            ct = self.scheme.encrypt(encoded, public_key)
            ciphertexts.append(ct)
        
        return ciphertexts
    
    def batch_add(self, ciphertexts_a: List[Any], 
                  ciphertexts_b: List[Any]) -> List[Any]:
        """
        批量加法
        
        Args:
            ciphertexts_a: 第一组密文
            ciphertexts_b: 第二组密文
            
        Returns:
            结果密文列表
        """
        if len(ciphertexts_a) != len(ciphertexts_b):
            raise ValueError("密文数量不匹配")
        
        return [a + b for a, b in zip(ciphertexts_a, ciphertexts_b)]
    
    def batch_multiply(self, ciphertexts_a: List[Any], 
                       ciphertexts_b: List[Any]) -> List[Any]:
        """
        批量乘法
        
        Args:
            ciphertexts_a: 第一组密文
            ciphertexts_b: 第二组密文
            
        Returns:
            结果密文列表
        """
        if len(ciphertexts_a) != len(ciphertexts_b):
            raise ValueError("密文数量不匹配")
        
        result = []
        for a, b in zip(ciphertexts_a, ciphertexts_b):
            product = a * b
            
            # 重线性化
            if hasattr(self.scheme, 'relinearize'):
                product = self.scheme.relinearize(product)
            
            result.append(product)
        
        return result
    
    def pack_vectors(self, vectors: List[List[float]]) -> List[np.ndarray]:
        """
        打包多个向量
        
        将多个向量打包到最少数量的编码多项式中
        
        Args:
            vectors: 向量列表
            
        Returns:
            编码多项式列表
        """
        packed = []
        current_batch = []
        current_size = 0
        
        for vec in vectors:
            vec_len = len(vec)
            
            if current_size + vec_len > self.slot_count:
                # 当前批次已满，编码并开始新批次
                if current_batch:
                    encoded = self.encoder.encode(
                        [x for batch in current_batch for x in batch]
                    )
                    packed.append(encoded)
                
                current_batch = [vec]
                current_size = vec_len
            else:
                current_batch.append(vec)
                current_size += vec_len
        
        # 编码最后一批
        if current_batch:
            encoded = self.encoder.encode(
                [x for batch in current_batch for x in batch]
            )
            packed.append(encoded)
        
        return packed
    
    def compute_batch_statistics(self, 
                                  ciphertexts: List[Any],
                                  secret_key: Any) -> dict:
        """
        计算批处理的统计信息
        
        Args:
            ciphertexts: 密文列表
            secret_key: 私钥
            
        Returns:
            统计信息字典
        """
        # 解密所有密文
        all_values = []
        for ct in ciphertexts:
            decoded = self.scheme.decrypt(ct, secret_key)
            if isinstance(decoded, np.ndarray):
                values = self.encoder.decode(decoded)
                all_values.extend(values)
        
        # 计算统计量
        if all_values:
            return {
                'count': len(all_values),
                'mean': np.mean(all_values),
                'std': np.std(all_values),
                'min': np.min(all_values),
                'max': np.max(all_values)
            }
        
        return {}