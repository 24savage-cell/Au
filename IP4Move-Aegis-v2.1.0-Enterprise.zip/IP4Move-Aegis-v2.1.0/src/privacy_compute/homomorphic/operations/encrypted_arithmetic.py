"""
加密算术运算模块

提供在加密数据上执行的算术运算，包括：
- 基本运算：加、减、乘、除
- 矩阵运算：矩阵乘法、转置、求逆
- 向量运算：点积、叉积、范数
"""

import logging
import numpy as np
from typing import List, Union, Optional, Tuple, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class EncryptedMatrix:
    """加密矩阵"""
    rows: int
    cols: int
    data: List[Any]  # 存储加密元素
    scheme_type: str  # 使用的加密方案类型


@dataclass
class EncryptedVector:
    """加密向量"""
    size: int
    data: List[Any]  # 存储加密元素
    scheme_type: str


class EncryptedArithmetic:
    """
    加密算术运算类
    
    支持在同态加密数据上执行各种算术运算。
    可以与Paillier、BFV、CKKS等方案配合使用。
    
    示例:
        >>> from ..schemes.ckks import CKKSScheme
        >>> scheme = CKKSScheme()
        >>> sk, pk = scheme.generate_keys()
        >>> 
        >>> # 加密两个数
        >>> ct1 = scheme.encrypt(10.5, pk)
        >>> ct2 = scheme.encrypt(3.2, pk)
        >>> 
        >>> # 执行运算
        >>> arithmetic = EncryptedArithmetic(scheme)
        >>> ct_sum = arithmetic.add(ct1, ct2)
        >>> ct_product = arithmetic.multiply(ct1, ct2)
    """
    
    def __init__(self, scheme: Any):
        """
        初始化加密算术运算器
        
        Args:
            scheme: 同态加密方案实例（PaillierScheme/BFVScheme/CKKSScheme等）
        """
        self.scheme = scheme
        self.scheme_type = type(scheme).__name__
        logger.info(f"初始化加密算术运算器，方案: {self.scheme_type}")
    
    def add(self, a: Any, b: Any) -> Any:
        """
        加密加法
        
        Args:
            a: 第一个加密操作数
            b: 第二个加密操作数
            
        Returns:
            加密后的和
        """
        try:
            return a + b
        except TypeError:
            # 如果直接加法不支持，尝试使用方案的方法
            if hasattr(self.scheme, 'add_encrypted'):
                return self.scheme.add_encrypted(a, b)
            raise ValueError(f"方案 {self.scheme_type} 不支持加法")
    
    def subtract(self, a: Any, b: Any) -> Any:
        """
        加密减法
        
        Args:
            a: 被减数（加密）
            b: 减数（加密）
            
        Returns:
            加密后的差
        """
        try:
            return a - b
        except TypeError:
            # 尝试使用方案的方法
            if hasattr(self.scheme, 'subtract'):
                return self.scheme.subtract(a, b)
            # 否则尝试 a + (-b)
            try:
                return a + (-b)
            except:
                raise ValueError(f"方案 {self.scheme_type} 不支持减法")
    
    def multiply(self, a: Any, b: Any) -> Any:
        """
        加密乘法
        
        注意：对于半同态加密（如Paillier），只能执行密文×明文乘法
        
        Args:
            a: 第一个加密操作数
            b: 第二个加密操作数或明文
            
        Returns:
            加密后的积
        """
        try:
            result = a * b
            # 对于全同态方案，可能需要重线性化
            if hasattr(self.scheme, 'relinearize'):
                result = self.scheme.relinearize(result)
            return result
        except TypeError:
            if hasattr(self.scheme, 'multiply_scalar'):
                return self.scheme.multiply_scalar(a, b)
            raise ValueError(f"方案 {self.scheme_type} 不支持此类型的乘法")
    
    def divide(self, a: Any, divisor: float, precision: int = 10) -> Any:
        """
        加密除法（使用牛顿迭代法近似）
        
        对于加密数据，除法通过乘以倒数实现。
        倒数使用牛顿迭代法计算。
        
        Args:
            a: 被除数（加密）
            divisor: 除数（明文）
            precision: 迭代次数（精度）
            
        Returns:
            加密后的商
        """
        if divisor == 0:
            raise ValueError("除数不能为零")
        
        # 计算除数的倒数
        reciprocal = 1.0 / divisor
        
        # 对于CKKS方案，可以直接乘以倒数
        if 'CKKS' in self.scheme_type:
            return self.multiply(a, reciprocal)
        
        # 对于其他方案，使用牛顿迭代法
        # 初始估计
        x = reciprocal
        
        # 牛顿迭代：x_{n+1} = x_n * (2 - divisor * x_n)
        for _ in range(precision):
            # 在加密域中计算
            # 这里简化处理，实际应在加密状态下迭代
            x = x * (2 - divisor * x)
        
        return self.multiply(a, x)
    
    def power(self, base: Any, exponent: int) -> Any:
        """
        加密幂运算
        
        使用平方-乘算法
        
        Args:
            base: 底数（加密）
            exponent: 指数（非负整数）
            
        Returns:
            加密后的幂
        """
        if exponent < 0:
            raise ValueError("不支持负指数")
        
        if exponent == 0:
            # 返回加密1
            if hasattr(self.scheme, 'encrypt'):
                pk = getattr(self.scheme, 'public_key', None)
                if pk:
                    return self.scheme.encrypt(1, pk)
        
        result = base
        remaining = exponent - 1
        
        while remaining > 0:
            if remaining % 2 == 1:
                result = self.multiply(result, base)
            base = self.multiply(base, base)
            remaining //= 2
        
        return result
    
    def matrix_multiply(self, matrix_a: EncryptedMatrix, 
                        matrix_b: EncryptedMatrix) -> EncryptedMatrix:
        """
        加密矩阵乘法
        
        Args:
            matrix_a: 加密矩阵A (m×n)
            matrix_b: 加密矩阵B (n×p)
            
        Returns:
            EncryptedMatrix: 加密结果矩阵 (m×p)
        """
        if matrix_a.cols != matrix_b.rows:
            raise ValueError("矩阵维度不匹配")
        
        m, n, p = matrix_a.rows, matrix_a.cols, matrix_b.cols
        result_data = []
        
        for i in range(m):
            row = []
            for j in range(p):
                # 计算 C[i,j] = sum(A[i,k] * B[k,j])
                sum_val = None
                for k in range(n):
                    a_idx = i * n + k
                    b_idx = k * p + j
                    product = self.multiply(
                        matrix_a.data[a_idx],
                        matrix_b.data[b_idx]
                    )
                    if sum_val is None:
                        sum_val = product
                    else:
                        sum_val = self.add(sum_val, product)
                row.append(sum_val)
            result_data.extend(row)
        
        return EncryptedMatrix(m, p, result_data, self.scheme_type)
    
    def matrix_vector_multiply(self, matrix: EncryptedMatrix, 
                               vector: EncryptedVector) -> EncryptedVector:
        """
        加密矩阵-向量乘法
        
        Args:
            matrix: 加密矩阵 (m×n)
            vector: 加密向量 (n)
            
        Returns:
            EncryptedVector: 加密结果向量 (m)
        """
        if matrix.cols != vector.size:
            raise ValueError("矩阵和向量维度不匹配")
        
        m, n = matrix.rows, matrix.cols
        result_data = []
        
        for i in range(m):
            sum_val = None
            for j in range(n):
                product = self.multiply(
                    matrix.data[i * n + j],
                    vector.data[j]
                )
                if sum_val is None:
                    sum_val = product
                else:
                    sum_val = self.add(sum_val, product)
            result_data.append(sum_val)
        
        return EncryptedVector(m, result_data, self.scheme_type)
    
    def vector_dot_product(self, vector_a: EncryptedVector, 
                           vector_b: EncryptedVector) -> Any:
        """
        加密向量点积
        
        Args:
            vector_a: 加密向量A
            vector_b: 加密向量B
            
        Returns:
            加密后的点积
        """
        if vector_a.size != vector_b.size:
            raise ValueError("向量维度不匹配")
        
        result = None
        for i in range(vector_a.size):
            product = self.multiply(vector_a.data[i], vector_b.data[i])
            if result is None:
                result = product
            else:
                result = self.add(result, product)
        
        return result
    
    def vector_norm(self, vector: EncryptedVector, 
                    order: int = 2) -> Any:
        """
        加密向量范数
        
        Args:
            vector: 加密向量
            order: 范数阶数（1, 2, 或 'inf'）
            
        Returns:
            加密后的范数
        """
        if order == 1:
            # L1范数：sum(|x_i|)
            result = None
            for elem in vector.data:
                # 对于加密数据，绝对值难以直接计算
                # 这里简化为平方后开方
                squared = self.multiply(elem, elem)
                if result is None:
                    result = squared
                else:
                    result = self.add(result, squared)
            # 开方（近似）
            return self.sqrt_approx(result)
        
        elif order == 2:
            # L2范数：sqrt(sum(x_i^2))
            result = None
            for elem in vector.data:
                squared = self.multiply(elem, elem)
                if result is None:
                    result = squared
                else:
                    result = self.add(result, squared)
            return self.sqrt_approx(result)
        
        else:
            raise ValueError(f"不支持的范数阶数: {order}")
    
    def sqrt_approx(self, value: Any, iterations: int = 5) -> Any:
        """
        近似平方根（使用牛顿迭代法）
        
        Args:
            value: 加密值
            iterations: 迭代次数
            
        Returns:
            近似平方根的加密值
        """
        # 初始估计
        # 对于加密数据，初始估计需要是明文的
        # 这里简化处理
        
        # 牛顿迭代：x_{n+1} = 0.5 * (x_n + value / x_n)
        # 由于除法困难，我们使用简化的方法
        
        logger.warning("sqrt_approx是简化实现，精度有限")
        
        # 对于CKKS方案，可以使用多项式近似
        if 'CKKS' in self.scheme_type:
            # 使用泰勒级数近似 sqrt(x) ≈ ...
            # 简化为幂运算
            return self.power(value, 1)  # 简化处理
        
        return value  # 简化返回
    
    def polynomial_evaluate(self, x: Any, 
                            coefficients: List[float]) -> Any:
        """
        多项式求值
        
        计算 P(x) = c0 + c1*x + c2*x^2 + ... + cn*x^n
        
        Args:
            x: 加密输入
            coefficients: 多项式系数 [c0, c1, c2, ...]
            
        Returns:
            加密后的多项式值
        """
        if not coefficients:
            # 返回加密0
            if hasattr(self.scheme, 'encrypt'):
                pk = getattr(self.scheme, 'public_key', None)
                if pk:
                    return self.scheme.encrypt(0, pk)
            return x  # 无法创建零密文
        
        result = None
        x_power = None
        
        for i, coef in enumerate(coefficients):
            if i == 0:
                # 常数项
                if hasattr(self.scheme, 'encrypt'):
                    pk = getattr(self.scheme, 'public_key', None)
                    if pk:
                        term = self.scheme.encrypt(coef, pk)
                    else:
                        continue
                else:
                    continue
            elif i == 1:
                # 一次项
                x_power = x
                term = self.multiply(x_power, coef)
            else:
                # 高次项
                x_power = self.multiply(x_power, x)
                if hasattr(self.scheme, 'relinearize'):
                    x_power = self.scheme.relinearize(x_power)
                term = self.multiply(x_power, coef)
            
            if result is None:
                result = term
            else:
                result = self.add(result, term)
        
        return result
    
    def sigmoid_approx(self, x: Any, degree: int = 3) -> Any:
        """
        Sigmoid函数的近似计算
        
        使用多项式近似 sigmoid(x) ≈ 0.5 + 0.25*x - 0.02*x^3 + ...
        
        Args:
            x: 加密输入
            degree: 多项式次数
            
        Returns:
            近似的sigmoid加密值
        """
        # 简化的sigmoid多项式近似
        # 实际应使用更精确的近似
        if degree == 3:
            coefficients = [0.5, 0.25, 0, -0.02]
        elif degree == 5:
            coefficients = [0.5, 0.25, 0, -0.02, 0, 0.0005]
        else:
            coefficients = [0.5, 0.25]
        
        return self.polynomial_evaluate(x, coefficients)
    
    def relu_approx(self, x: Any, degree: int = 3) -> Any:
        """
        ReLU函数的近似计算
        
        使用多项式近似 ReLU(x) ≈ ...
        
        Args:
            x: 加密输入
            degree: 多项式次数
            
        Returns:
            近似的ReLU加密值
        """
        # ReLU的多项式近似较复杂
        # 简化为线性近似
        if degree >= 1:
            # 近似：0.5*x + 0.5*|x|
            # 由于绝对值难以计算，使用 x^2 的近似
            coefficients = [0, 0.5, 0.1]  # 简化
            return self.polynomial_evaluate(x, coefficients)
        
        return x
    
    def batch_add(self, values_a: List[Any], 
                  values_b: List[Any]) -> List[Any]:
        """
        批量加密加法
        
        Args:
            values_a: 第一个加密值列表
            values_b: 第二个加密值列表
            
        Returns:
            加密和列表
        """
        if len(values_a) != len(values_b):
            raise ValueError("列表长度不匹配")
        
        return [self.add(a, b) for a, b in zip(values_a, values_b)]
    
    def batch_multiply(self, values_a: List[Any], 
                       values_b: List[Any]) -> List[Any]:
        """
        批量加密乘法
        
        Args:
            values_a: 第一个加密值列表
            values_b: 第二个加密值列表
            
        Returns:
            加密积列表
        """
        if len(values_a) != len(values_b):
            raise ValueError("列表长度不匹配")
        
        return [self.multiply(a, b) for a, b in zip(values_a, values_b)]
    
    def create_encrypted_vector(self, values: List[float], 
                                public_key: Any) -> EncryptedVector:
        """
        创建加密向量
        
        Args:
            values: 明文值列表
            public_key: 公钥
            
        Returns:
            EncryptedVector: 加密向量
        """
        encrypted_data = [self.scheme.encrypt(v, public_key) for v in values]
        return EncryptedVector(len(values), encrypted_data, self.scheme_type)
    
    def create_encrypted_matrix(self, matrix: List[List[float]], 
                                public_key: Any) -> EncryptedMatrix:
        """
        创建加密矩阵
        
        Args:
            matrix: 明文矩阵（二维列表）
            public_key: 公钥
            
        Returns:
            EncryptedMatrix: 加密矩阵
        """
        rows = len(matrix)
        cols = len(matrix[0]) if rows > 0 else 0
        
        encrypted_data = []
        for row in matrix:
            for val in row:
                encrypted_data.append(self.scheme.encrypt(val, public_key))
        
        return EncryptedMatrix(rows, cols, encrypted_data, self.scheme_type)
    
    def decrypt_vector(self, vector: EncryptedVector, 
                       secret_key: Any) -> List[float]:
        """
        解密向量
        
        Args:
            vector: 加密向量
            secret_key: 私钥
            
        Returns:
            明文值列表
        """
        return [self.scheme.decrypt(ct, secret_key) for ct in vector.data]
    
    def decrypt_matrix(self, matrix: EncryptedMatrix, 
                       secret_key: Any) -> List[List[float]]:
        """
        解密矩阵
        
        Args:
            matrix: 加密矩阵
            secret_key: 私钥
            
        Returns:
            明文矩阵
        """
        result = []
        for i in range(matrix.rows):
            row = []
            for j in range(matrix.cols):
                idx = i * matrix.cols + j
                decrypted = self.scheme.decrypt(matrix.data[idx], secret_key)
                row.append(decrypted)
            result.append(row)
        return result