"""
加密比较运算模块

提供在加密数据上执行的比较运算，包括：
- 大小比较：等于、不等于、大于、小于
- 排序：加密排序算法
- Top-K：查找最大的K个元素
"""

import logging
import heapq
from typing import List, Tuple, Optional, Any, Callable
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ComparisonResult:
    """比较结果"""
    is_equal: Any  # 加密布尔值
    is_less: Any   # 加密布尔值
    is_greater: Any  # 加密布尔值


class EncryptedComparison:
    """
    加密比较运算类
    
    支持在同态加密数据上执行各种比较运算。
    主要用于TFHE方案（支持布尔运算），也可用于其他方案。
    
    示例:
        >>> from ..schemes.tfhe import TFHEScheme
        >>> scheme = TFHEScheme()
        >>> keys = scheme.generate_keys()
        >>> 
        >>> ct1 = scheme.encrypt_int(42, 8, keys.lwe_key)
        >>> ct2 = scheme.encrypt_int(100, 8, keys.lwe_key)
        >>> 
        >>> comparison = EncryptedComparison(scheme)
        >>> result = comparison.less_than(ct1, ct2)  # 加密True
    """
    
    def __init__(self, scheme: Any):
        """
        初始化加密比较器
        
        Args:
            scheme: 同态加密方案实例
        """
        self.scheme = scheme
        self.scheme_type = type(scheme).__name__
        logger.info(f"初始化加密比较器，方案: {self.scheme_type}")
    
    def equal(self, a: Any, b: Any) -> Any:
        """
        相等比较
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            加密布尔值（True表示相等）
        """
        if 'TFHE' in self.scheme_type:
            return self.scheme.compare_equal(a, b)
        
        # 对于其他方案，使用减法后判断是否为零
        try:
            diff = a - b
            # 判断diff是否为零（需要方案支持）
            return self._is_zero(diff)
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持相等比较")
    
    def not_equal(self, a: Any, b: Any) -> Any:
        """
        不等比较
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            加密布尔值（True表示不等）
        """
        eq_result = self.equal(a, b)
        if 'TFHE' in self.scheme_type:
            return self.scheme.gate_not(eq_result)
        
        # 对于其他方案，返回 1 - eq_result
        try:
            return 1 - eq_result
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持不等比较")
    
    def less_than(self, a: Any, b: Any) -> Any:
        """
        小于比较
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            加密布尔值（True表示a < b）
        """
        if 'TFHE' in self.scheme_type:
            # TFHE支持直接比较
            if isinstance(a, list) and isinstance(b, list):
                return self.scheme.compare_less_than(a, b)
            # 对于单个密文，使用差值
            return self.scheme.compare_less_than([a], [b])
        
        # 对于CKKS，可以使用符号函数近似
        if 'CKKS' in self.scheme_type:
            diff = b - a  # b - a > 0 意味着 a < b
            return self._sign_approx(diff)
        
        raise ValueError(f"方案 {self.scheme_type} 不支持小于比较")
    
    def greater_than(self, a: Any, b: Any) -> Any:
        """
        大于比较
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            加密布尔值（True表示a > b）
        """
        return self.less_than(b, a)
    
    def less_or_equal(self, a: Any, b: Any) -> Any:
        """
        小于等于比较
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            加密布尔值（True表示a <= b）
        """
        # a <= b 等价于 NOT(a > b)
        gt = self.greater_than(a, b)
        if 'TFHE' in self.scheme_type:
            return self.scheme.gate_not(gt)
        
        try:
            return 1 - gt
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持小于等于比较")
    
    def greater_or_equal(self, a: Any, b: Any) -> Any:
        """
        大于等于比较
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            加密布尔值（True表示a >= b）
        """
        return self.less_or_equal(b, a)
    
    def compare(self, a: Any, b: Any) -> ComparisonResult:
        """
        完整比较（返回所有比较结果）
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            ComparisonResult: 包含所有比较结果
        """
        return ComparisonResult(
            is_equal=self.equal(a, b),
            is_less=self.less_than(a, b),
            is_greater=self.greater_than(a, b)
        )
    
    def max(self, a: Any, b: Any) -> Any:
        """
        最大值
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            加密的较大值
        """
        # max(a, b) = MUX(a > b, a, b)
        if 'TFHE' in self.scheme_type:
            gt = self.greater_than(a, b)
            return self.scheme.gate_mux(gt, a, b)
        
        # 对于其他方案
        # max(a, b) = (a + b + |a - b|) / 2
        try:
            diff = a - b
            abs_diff = self._abs_approx(diff)
            return (a + b + abs_diff) / 2
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持max运算")
    
    def min(self, a: Any, b: Any) -> Any:
        """
        最小值
        
        Args:
            a: 第一个加密值
            b: 第二个加密值
            
        Returns:
            加密的较小值
        """
        # min(a, b) = MUX(a < b, a, b)
        if 'TFHE' in self.scheme_type:
            lt = self.less_than(a, b)
            return self.scheme.gate_mux(lt, a, b)
        
        # 对于其他方案
        # min(a, b) = (a + b - |a - b|) / 2
        try:
            diff = a - b
            abs_diff = self._abs_approx(diff)
            return (a + b - abs_diff) / 2
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持min运算")
    
    def sort_encrypted(self, values: List[Any], 
                       ascending: bool = True) -> List[Any]:
        """
        加密排序（冒泡排序的加密版本）
        
        注意：此操作计算复杂度较高，O(n^2)次比较
        
        Args:
            values: 加密值列表
            ascending: 是否升序
            
        Returns:
            排序后的加密值列表
        """
        if len(values) <= 1:
            return values
        
        result = values.copy()
        n = len(result)
        
        # 冒泡排序
        for i in range(n):
            for j in range(0, n - i - 1):
                # 比较相邻元素
                if ascending:
                    should_swap = self.greater_than(result[j], result[j + 1])
                else:
                    should_swap = self.less_than(result[j], result[j + 1])
                
                # 条件交换
                result[j], result[j + 1] = self._conditional_swap(
                    result[j], result[j + 1], should_swap
                )
        
        return result
    
    def top_k(self, values: List[Any], k: int) -> List[Any]:
        """
        查找最大的K个元素
        
        使用加密堆或排序实现
        
        Args:
            values: 加密值列表
            k: 要找的元素个数
            
        Returns:
            最大的K个加密值
        """
        if k <= 0:
            return []
        
        if k >= len(values):
            return self.sort_encrypted(values, ascending=False)
        
        # 使用排序方法（简化实现）
        sorted_values = self.sort_encrypted(values, ascending=False)
        return sorted_values[:k]
    
    def bottom_k(self, values: List[Any], k: int) -> List[Any]:
        """
        查找最小的K个元素
        
        Args:
            values: 加密值列表
            k: 要找的元素个数
            
        Returns:
            最小的K个加密值
        """
        if k <= 0:
            return []
        
        if k >= len(values):
            return self.sort_encrypted(values, ascending=True)
        
        sorted_values = self.sort_encrypted(values, ascending=True)
        return sorted_values[:k]
    
    def median(self, values: List[Any]) -> Any:
        """
        中位数
        
        Args:
            values: 加密值列表
            
        Returns:
            加密的中位数
        """
        if not values:
            raise ValueError("空列表")
        
        sorted_values = self.sort_encrypted(values)
        n = len(sorted_values)
        
        if n % 2 == 1:
            return sorted_values[n // 2]
        else:
            # 偶数个元素，取中间两个的平均
            mid1 = sorted_values[n // 2 - 1]
            mid2 = sorted_values[n // 2]
            return (mid1 + mid2) / 2
    
    def argmax(self, values: List[Any]) -> int:
        """
        最大值索引（返回明文索引）
        
        注意：返回的是明文索引，不泄露值的信息
        
        Args:
            values: 加密值列表
            
        Returns:
            最大值索引（明文int）
        """
        if not values:
            raise ValueError("空列表")
        
        # 线性扫描找最大值
        max_idx = 0
        max_val = values[0]
        
        for i in range(1, len(values)):
            # 比较当前值和最大值
            is_greater = self.greater_than(values[i], max_val)
            
            # 如果当前值更大，更新最大值和索引
            # 注意：这里无法直接在加密状态下更新索引
            # 实际应用需要更复杂的协议
            if 'TFHE' in self.scheme_type:
                max_val = self.scheme.gate_mux(is_greater, values[i], max_val)
            else:
                # 对于非布尔方案，需要近似
                max_val = self.max(max_val, values[i])
        
        # 返回明文索引（简化处理）
        # 实际应用可能需要安全多方计算
        return max_idx
    
    def argmin(self, values: List[Any]) -> int:
        """
        最小值索引
        
        Args:
            values: 加密值列表
            
        Returns:
            最小值索引（明文int）
        """
        if not values:
            raise ValueError("空列表")
        
        min_idx = 0
        min_val = values[0]
        
        for i in range(1, len(values)):
            is_less = self.less_than(values[i], min_val)
            
            if 'TFHE' in self.scheme_type:
                min_val = self.scheme.gate_mux(is_less, values[i], min_val)
            else:
                min_val = self.min(min_val, values[i])
        
        return min_idx
    
    def range_query(self, values: List[Any], 
                    lower_bound: Any, 
                    upper_bound: Any) -> List[Any]:
        """
        范围查询
        
        返回在[lower_bound, upper_bound]范围内的所有值
        
        Args:
            values: 加密值列表
            lower_bound: 下界（加密）
            upper_bound: 上界（加密）
            
        Returns:
            在范围内的加密值列表
        """
        result = []
        
        for val in values:
            # 检查 val >= lower_bound AND val <= upper_bound
            ge_lower = self.greater_or_equal(val, lower_bound)
            le_upper = self.less_or_equal(val, upper_bound)
            
            if 'TFHE' in self.scheme_type:
                in_range = self.scheme.gate_and(ge_lower, le_upper)
                # 使用MUX选择值或0
                selected = self.scheme.gate_mux(in_range, val, 
                    self.scheme.encrypt(0, self.scheme.keyset.lwe_key))
                result.append(selected)
            else:
                # 对于其他方案，使用乘法作为AND
                in_range = ge_lower * le_upper
                selected = val * in_range
                result.append(selected)
        
        return result
    
    def _is_zero(self, value: Any, tolerance: float = 1e-6) -> Any:
        """
        判断加密值是否为零
        
        Args:
            value: 加密值
            tolerance: 容差
            
        Returns:
            加密布尔值
        """
        # 简化的实现：判断 |value| < tolerance
        abs_val = self._abs_approx(value)
        
        if 'CKKS' in self.scheme_type:
            # 使用sigmoid近似
            return self._sigmoid_approx(tolerance - abs_val)
        
        # 对于其他方案，需要特定实现
        raise NotImplementedError("_is_zero需要特定方案实现")
    
    def _abs_approx(self, value: Any) -> Any:
        """
        近似绝对值
        
        Args:
            value: 加密值
            
        Returns:
            近似的绝对值
        """
        # 使用 sqrt(x^2) 近似 |x|
        try:
            squared = value * value
            # 简化为平方（实际应开方）
            return squared
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持绝对值运算")
    
    def _sign_approx(self, value: Any) -> Any:
        """
        近似符号函数
        
        Args:
            value: 加密值
            
        Returns:
            近似的符号（正数为1，负数为0）
        """
        # 使用sigmoid近似：sign(x) ≈ sigmoid(k*x) for large k
        if 'CKKS' in self.scheme_type:
            return self._sigmoid_approx(value * 10)  # 放大后通过sigmoid
        
        raise NotImplementedError("_sign_approx需要特定方案实现")
    
    def _sigmoid_approx(self, x: Any) -> Any:
        """
        Sigmoid近似
        
        Args:
            x: 加密值
            
        Returns:
            近似的sigmoid值
        """
        # 简化的sigmoid：1 / (1 + exp(-x))
        # 使用多项式近似
        if 'CKKS' in self.scheme_type:
            # 使用简单的多项式近似
            return 0.5 + 0.25 * x  # 在0附近的线性近似
        
        raise NotImplementedError("_sigmoid_approx需要特定方案实现")
    
    def _conditional_swap(self, a: Any, b: Any, condition: Any) -> Tuple[Any, Any]:
        """
        条件交换
        
        如果condition为True，交换a和b
        
        Args:
            a: 第一个值
            b: 第二个值
            condition: 加密布尔条件
            
        Returns:
            (new_a, new_b): 可能交换后的值
        """
        if 'TFHE' in self.scheme_type:
            # 使用MUX
            new_a = self.scheme.gate_mux(condition, b, a)
            new_b = self.scheme.gate_mux(condition, a, b)
            return new_a, new_b
        
        # 对于其他方案
        # new_a = condition * b + (1 - condition) * a
        # new_b = condition * a + (1 - condition) * b
        try:
            not_condition = 1 - condition
            new_a = condition * b + not_condition * a
            new_b = condition * a + not_condition * b
            return new_a, new_b
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持条件交换")