"""
加密聚合运算模块

提供在加密数据上执行的聚合运算，包括：
- 求和、平均值、方差
- 加权聚合
- 安全多方聚合
"""

import logging
import numpy as np
from typing import List, Optional, Any, Union, Tuple
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class AggregationResult:
    """聚合结果"""
    sum: Any
    count: int
    mean: Optional[Any] = None
    variance: Optional[Any] = None
    std: Optional[Any] = None


class EncryptedAggregation:
    """
    加密聚合运算类
    
    支持在同态加密数据上执行各种聚合运算。
    主要用于Paillier（加法同态）和CKKS/BFV（全同态）方案。
    
    示例:
        >>> from ..schemes.paillier import PaillierScheme
        >>> scheme = PaillierScheme()
        >>> keypair = scheme.generate_keypair()
        >>> 
        >>> # 加密多个值
        >>> values = [scheme.encrypt(x, keypair.public_key) for x in [10, 20, 30, 40]]
        >>> 
        >>> # 执行聚合
        >>> agg = EncryptedAggregation(scheme)
        >>> total = agg.sum(values)
        >>> avg = agg.mean(values)
        >>> var = agg.variance(values)
    """
    
    def __init__(self, scheme: Any):
        """
        初始化加密聚合器
        
        Args:
            scheme: 同态加密方案实例
        """
        self.scheme = scheme
        self.scheme_type = type(scheme).__name__
        logger.info(f"初始化加密聚合器，方案: {self.scheme_type}")
    
    def sum(self, values: List[Any]) -> Any:
        """
        加密求和
        
        Args:
            values: 加密值列表
            
        Returns:
            加密后的总和
        """
        if not values:
            raise ValueError("空列表")
        
        if len(values) == 1:
            return values[0]
        
        # 使用同态加法累加
        result = values[0]
        for val in values[1:]:
            result = result + val
        
        return result
    
    def mean(self, values: List[Any]) -> Any:
        """
        加密平均值
        
        Args:
            values: 加密值列表
            
        Returns:
            加密后的平均值
        """
        if not values:
            raise ValueError("空列表")
        
        total = self.sum(values)
        n = len(values)
        
        # 除以n
        if 'Paillier' in self.scheme_type:
            # Paillier只支持标量乘法，不支持除法
            # 需要解密后计算平均值，或使用近似方法
            logger.warning("Paillier方案不支持直接的平均值计算")
            return total
        
        # 对于CKKS/BFV，可以乘以1/n
        try:
            return total * (1.0 / n)
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持平均值计算")
    
    def variance(self, values: List[Any], ddof: int = 0) -> Any:
        """
        加密方差
        
        计算样本方差：var = sum((x - mean)^2) / (n - ddof)
        
        Args:
            values: 加密值列表
            ddof: 自由度（通常为0或1）
            
        Returns:
            加密后的方差
        """
        if len(values) <= ddof:
            raise ValueError("样本数量不足")
        
        # 计算均值
        mean_val = self.mean(values)
        
        # 计算平方差之和
        squared_diffs = []
        for val in values:
            diff = val - mean_val
            squared = diff * diff
            
            # 对于全同态方案，可能需要重线性化
            if hasattr(self.scheme, 'relinearize'):
                squared = self.scheme.relinearize(squared)
            
            squared_diffs.append(squared)
        
        # 求和并除以(n - ddof)
        sum_squared_diffs = self.sum(squared_diffs)
        divisor = len(values) - ddof
        
        try:
            return sum_squared_diffs * (1.0 / divisor)
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持方差计算")
    
    def std(self, values: List[Any], ddof: int = 0) -> Any:
        """
        加密标准差
        
        Args:
            values: 加密值列表
            ddof: 自由度
            
        Returns:
            加密后的标准差
        """
        var = self.variance(values, ddof)
        
        # 开平方（近似）
        if 'CKKS' in self.scheme_type:
            # CKKS可以使用多项式近似sqrt
            return self._sqrt_approx(var)
        
        logger.warning("标准差计算需要开方，当前方案可能不支持")
        return var
    
    def weighted_sum(self, values: List[Any], weights: List[float]) -> Any:
        """
        加密加权求和
        
        Args:
            values: 加密值列表
            weights: 权重列表（明文）
            
        Returns:
            加密后的加权和
        """
        if len(values) != len(weights):
            raise ValueError("值和权重数量不匹配")
        
        if not values:
            raise ValueError("空列表")
        
        # 计算加权和
        weighted_values = []
        for val, weight in zip(values, weights):
            weighted = val * weight
            weighted_values.append(weighted)
        
        return self.sum(weighted_values)
    
    def weighted_mean(self, values: List[Any], weights: List[float]) -> Any:
        """
        加密加权平均值
        
        Args:
            values: 加密值列表
            weights: 权重列表（明文）
            
        Returns:
            加密后的加权平均值
        """
        weighted_sum = self.weighted_sum(values, weights)
        total_weight = sum(weights)
        
        if total_weight == 0:
            raise ValueError("权重总和为零")
        
        try:
            return weighted_sum * (1.0 / total_weight)
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持加权平均值计算")
    
    def min(self, values: List[Any]) -> Any:
        """
        加密最小值
        
        注意：需要比较运算支持（如TFHE）
        
        Args:
            values: 加密值列表
            
        Returns:
            加密后的最小值
        """
        if not values:
            raise ValueError("空列表")
        
        if len(values) == 1:
            return values[0]
        
        # 使用比较运算找最小值
        result = values[0]
        for val in values[1:]:
            # 需要比较运算
            if hasattr(self.scheme, 'compare_less_than'):
                is_less = self.scheme.compare_less_than([val], [result])
                result = self.scheme.gate_mux(is_less, val, result)
            else:
                raise ValueError(f"方案 {self.scheme_type} 不支持最小值计算")
        
        return result
    
    def max(self, values: List[Any]) -> Any:
        """
        加密最大值
        
        Args:
            values: 加密值列表
            
        Returns:
            加密后的最大值
        """
        if not values:
            raise ValueError("空列表")
        
        if len(values) == 1:
            return values[0]
        
        result = values[0]
        for val in values[1:]:
            if hasattr(self.scheme, 'compare_less_than'):
                is_greater = self.scheme.compare_less_than([result], [val])
                result = self.scheme.gate_mux(is_greater, val, result)
            else:
                raise ValueError(f"方案 {self.scheme_type} 不支持最大值计算")
        
        return result
    
    def count(self, values: List[Any]) -> int:
        """
        计数（明文）
        
        Args:
            values: 加密值列表
            
        Returns:
            元素数量（明文int）
        """
        return len(values)
    
    def product(self, values: List[Any]) -> Any:
        """
        加密乘积
        
        需要全同态加密支持
        
        Args:
            values: 加密值列表
            
        Returns:
            加密后的乘积
        """
        if not values:
            # 返回加密1
            if hasattr(self.scheme, 'encrypt'):
                pk = getattr(self.scheme, 'public_key', None)
                if pk:
                    return self.scheme.encrypt(1, pk)
            raise ValueError("无法创建单位元密文")
        
        result = values[0]
        for val in values[1:]:
            result = result * val
            
            # 对于全同态方案，可能需要重线性化
            if hasattr(self.scheme, 'relinearize'):
                result = self.scheme.relinearize(result)
        
        return result
    
    def geometric_mean(self, values: List[Any]) -> Any:
        """
        加密几何平均数
        
        geometric_mean = (product)^(1/n)
        
        Args:
            values: 加密值列表
            
        Returns:
            加密后的几何平均数
        """
        if not values:
            raise ValueError("空列表")
        
        # 计算乘积
        prod = self.product(values)
        n = len(values)
        
        # 开n次方（近似）
        if 'CKKS' in self.scheme_type:
            return self._nth_root_approx(prod, n)
        
        raise ValueError(f"方案 {self.scheme_type} 不支持几何平均数计算")
    
    def harmonic_mean(self, values: List[Any]) -> Any:
        """
        加密调和平均数
        
        harmonic_mean = n / sum(1/x)
        
        Args:
            values: 加密值列表
            
        Returns:
            加密后的调和平均数
        """
        if not values:
            raise ValueError("空列表")
        
        # 计算倒数之和
        reciprocals = []
        for val in values:
            # 计算1/x（近似）
            reciprocal = self._reciprocal_approx(val)
            reciprocals.append(reciprocal)
        
        sum_reciprocals = self.sum(reciprocals)
        n = len(values)
        
        # n / sum(1/x)
        try:
            return n * self._reciprocal_approx(sum_reciprocals)
        except:
            raise ValueError(f"方案 {self.scheme_type} 不支持调和平均数计算")
    
    def cumulative_sum(self, values: List[Any]) -> List[Any]:
        """
        加密累积和
        
        Args:
            values: 加密值列表
            
        Returns:
            累积和列表
        """
        if not values:
            return []
        
        result = []
        cumsum = values[0]
        result.append(cumsum)
        
        for val in values[1:]:
            cumsum = cumsum + val
            result.append(cumsum)
        
        return result
    
    def moving_average(self, values: List[Any], window: int) -> List[Any]:
        """
        加密移动平均
        
        Args:
            values: 加密值列表
            window: 窗口大小
            
        Returns:
            移动平均列表
        """
        if window <= 0:
            raise ValueError("窗口大小必须为正")
        
        if window > len(values):
            raise ValueError("窗口大小超过数据长度")
        
        result = []
        for i in range(len(values) - window + 1):
            window_values = values[i:i + window]
            avg = self.mean(window_values)
            result.append(avg)
        
        return result
    
    def percentile(self, values: List[Any], p: float) -> Any:
        """
        加密百分位数
        
        Args:
            values: 加密值列表
            p: 百分位（0-100）
            
        Returns:
            加密的百分位数值
        """
        if not 0 <= p <= 100:
            raise ValueError("百分位必须在0-100之间")
        
        # 需要排序后取对应位置的值
        # 这里简化处理，实际实现较复杂
        logger.warning("percentile是简化实现")
        
        # 使用近似方法
        sorted_values = sorted(values, key=lambda x: 0)  # 伪排序
        index = int(len(values) * p / 100)
        return sorted_values[min(index, len(values) - 1)]
    
    def aggregate_all(self, values: List[Any]) -> AggregationResult:
        """
        计算所有聚合统计量
        
        Args:
            values: 加密值列表
            
        Returns:
            AggregationResult: 包含所有统计量
        """
        total = self.sum(values)
        count = len(values)
        
        try:
            mean_val = self.mean(values)
        except:
            mean_val = None
        
        try:
            var_val = self.variance(values)
        except:
            var_val = None
        
        try:
            std_val = self.std(values)
        except:
            std_val = None
        
        return AggregationResult(
            sum=total,
            count=count,
            mean=mean_val,
            variance=var_val,
            std=std_val
        )
    
    def _sqrt_approx(self, value: Any, iterations: int = 5) -> Any:
        """
        近似平方根
        
        Args:
            value: 加密值
            iterations: 迭代次数
            
        Returns:
            近似平方根
        """
        # 牛顿迭代法
        # x_{n+1} = 0.5 * (x_n + value / x_n)
        
        # 初始估计
        x = value
        
        for _ in range(iterations):
            # 简化的迭代
            x = 0.5 * (x + value / x)
        
        return x
    
    def _nth_root_approx(self, value: Any, n: int, iterations: int = 5) -> Any:
        """
        近似n次方根
        
        Args:
            value: 加密值
            n: 根的次数
            iterations: 迭代次数
            
        Returns:
            近似n次方根
        """
        # 牛顿迭代法
        # x_{n+1} = ((n-1)*x + value/x^(n-1)) / n
        
        x = value
        
        for _ in range(iterations):
            x = ((n - 1) * x + value / (x ** (n - 1))) / n
        
        return x
    
    def _reciprocal_approx(self, value: Any, iterations: int = 5) -> Any:
        """
        近似倒数
        
        Args:
            value: 加密值
            iterations: 迭代次数
            
        Returns:
            近似倒数
        """
        # 牛顿迭代法
        # x_{n+1} = x_n * (2 - value * x_n)
        
        # 初始估计（简化）
        x = 0.1
        
        for _ in range(iterations):
            x = x * (2 - value * x)
        
        return x
    
    def secure_multiparty_aggregate(self, 
                                    encrypted_shares: List[List[Any]],
                                    aggregation_fn: Optional[callable] = None) -> Any:
        """
        安全多方聚合
        
        聚合来自多方的加密份额
        
        Args:
            encrypted_shares: 各方的加密份额列表
            aggregation_fn: 自定义聚合函数
            
        Returns:
            聚合结果
        """
        if not encrypted_shares:
            raise ValueError("空份额列表")
        
        if aggregation_fn is None:
            # 默认使用求和
            aggregation_fn = self.sum
        
        # 合并所有份额
        all_values = []
        for shares in encrypted_shares:
            all_values.extend(shares)
        
        return aggregation_fn(all_values)
    
    def federated_average(self, 
                          client_values: List[List[Any]],
                          client_weights: Optional[List[float]] = None) -> List[Any]:
        """
        联邦平均
        
        用于联邦学习中的模型参数聚合
        
        Args:
            client_values: 各客户端的加密参数列表
            client_weights: 各客户端的权重
            
        Returns:
            聚合后的加密参数
        """
        if not client_values:
            raise ValueError("空客户端列表")
        
        num_clients = len(client_values)
        
        if client_weights is None:
            client_weights = [1.0 / num_clients] * num_clients
        
        # 确保所有客户端有相同数量的参数
        num_params = len(client_values[0])
        
        aggregated_params = []
        
        for param_idx in range(num_params):
            # 收集所有客户端的第param_idx个参数
            param_values = [client_values[i][param_idx] for i in range(num_clients)]
            
            # 加权平均
            weighted_avg = self.weighted_mean(param_values, client_weights)
            aggregated_params.append(weighted_avg)
        
        return aggregated_params