"""
隐私统计计算模块

提供基于同态加密的隐私保护统计计算：
- 均值、方差、标准差
- 直方图
- 分位数
- 相关性分析
"""

import logging
import numpy as np
from typing import List, Optional, Any, Dict, Tuple
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class StatisticsResult:
    """统计结果"""
    mean: Optional[Any] = None
    variance: Optional[Any] = None
    std: Optional[Any] = None
    min: Optional[Any] = None
    max: Optional[Any] = None
    median: Optional[Any] = None
    histogram: Optional[Dict[str, Any]] = None
    quantiles: Optional[Dict[str, Any]] = None


class PrivateStatistics:
    """
    隐私统计计算类
    
    在加密数据上执行统计计算，保护数据隐私。
    
    示例:
        >>> from ..schemes.ckks import CKKSScheme
        >>> scheme = CKKSScheme()
        >>> sk, pk = scheme.generate_keys()
        >>> 
        >>> # 加密数据
        >>> data = [scheme.encrypt(x, pk) for x in [1.5, 2.3, 3.7, 4.1, 5.0]]
        >>> 
        >>> # 计算统计量
        >>> stats = PrivateStatistics(scheme)
        >>> result = stats.compute_all(data)
    """
    
    def __init__(self, scheme: Any):
        """
        初始化隐私统计计算器
        
        Args:
            scheme: 同态加密方案实例
        """
        self.scheme = scheme
        self.scheme_type = type(scheme).__name__
        
        # 导入聚合运算
        from ..operations.encrypted_aggregation import EncryptedAggregation
        self.aggregator = EncryptedAggregation(scheme)
        
        logger.info(f"初始化隐私统计计算器，方案: {self.scheme_type}")
    
    def mean(self, data: List[Any]) -> Any:
        """
        计算均值
        
        Args:
            data: 加密数据列表
            
        Returns:
            加密均值
        """
        return self.aggregator.mean(data)
    
    def variance(self, data: List[Any], ddof: int = 0) -> Any:
        """
        计算方差
        
        Args:
            data: 加密数据列表
            ddof: 自由度
            
        Returns:
            加密方差
        """
        return self.aggregator.variance(data, ddof)
    
    def std(self, data: List[Any], ddof: int = 0) -> Any:
        """
        计算标准差
        
        Args:
            data: 加密数据列表
            ddof: 自由度
            
        Returns:
            加密标准差
        """
        return self.aggregator.std(data, ddof)
    
    def histogram(self, data: List[Any], 
                  bins: int = 10,
                  min_val: Optional[float] = None,
                  max_val: Optional[float] = None) -> Dict[str, Any]:
        """
        计算加密直方图
        
        注意：这是一个简化实现，实际加密直方图计算较复杂
        
        Args:
            data: 加密数据列表
            bins: 分箱数量
            min_val: 最小值（明文，用于确定范围）
            max_val: 最大值（明文，用于确定范围）
            
        Returns:
            加密直方图结果
        """
        logger.warning("histogram是简化实现，实际应用需要更复杂的协议")
        
        # 简化的直方图实现
        # 实际应在加密状态下统计每个分箱的计数
        
        if min_val is None or max_val is None:
            raise ValueError("加密直方图需要明文的范围边界")
        
        bin_width = (max_val - min_val) / bins
        bin_edges = [min_val + i * bin_width for i in range(bins + 1)]
        
        # 初始化加密计数器
        encrypted_counts = []
        for _ in range(bins):
            if hasattr(self.scheme, 'encrypt'):
                pk = getattr(self.scheme, 'public_key', None)
                if pk:
                    encrypted_counts.append(self.scheme.encrypt(0, pk))
        
        # 对每个数据点，确定其所属分箱并增加计数
        # 这里简化处理
        for val in data:
            # 实际应在加密状态下进行比较和更新
            pass
        
        return {
            'counts': encrypted_counts,
            'bin_edges': bin_edges,
            'bins': bins
        }
    
    def quantile(self, data: List[Any], q: float) -> Any:
        """
        计算分位数
        
        Args:
            data: 加密数据列表
            q: 分位点（0-1）
            
        Returns:
            加密分位数值
        """
        if not 0 <= q <= 1:
            raise ValueError("分位点必须在0-1之间")
        
        # 分位数计算需要排序
        # 这里使用近似方法
        logger.warning("quantile是简化实现")
        
        # 简化的分位数估计
        # 实际应在加密状态下进行选择和插值
        sorted_data = sorted(data, key=lambda x: 0)  # 伪排序
        
        index = int(q * (len(data) - 1))
        return sorted_data[index]
    
    def median(self, data: List[Any]) -> Any:
        """
        计算中位数
        
        Args:
            data: 加密数据列表
            
        Returns:
            加密中位数
        """
        return self.quantile(data, 0.5)
    
    def correlation(self, x: List[Any], y: List[Any]) -> Any:
        """
        计算皮尔逊相关系数
        
        correlation = cov(x,y) / (std(x) * std(y))
        
        Args:
            x: 第一个加密数据集
            y: 第二个加密数据集
            
        Returns:
            加密相关系数
        """
        if len(x) != len(y):
            raise ValueError("数据集长度不匹配")
        
        n = len(x)
        
        # 计算均值
        mean_x = self.mean(x)
        mean_y = self.mean(y)
        
        # 计算协方差
        cov_terms = []
        for xi, yi in zip(x, y):
            diff_x = xi - mean_x
            diff_y = yi - mean_y
            product = diff_x * diff_y
            
            if hasattr(self.scheme, 'relinearize'):
                product = self.scheme.relinearize(product)
            
            cov_terms.append(product)
        
        covariance = self.aggregator.mean(cov_terms)
        
        # 计算标准差
        std_x = self.std(x)
        std_y = self.std(y)
        
        # 相关系数 = 协方差 / (std_x * std_y)
        denominator = std_x * std_y
        if hasattr(self.scheme, 'relinearize'):
            denominator = self.scheme.relinearize(denominator)
        
        # 除法（近似）
        correlation = covariance * self._reciprocal_approx(denominator)
        
        return correlation
    
    def covariance(self, x: List[Any], y: List[Any]) -> Any:
        """
        计算协方差
        
        Args:
            x: 第一个加密数据集
            y: 第二个加密数据集
            
        Returns:
            加密协方差
        """
        if len(x) != len(y):
            raise ValueError("数据集长度不匹配")
        
        mean_x = self.mean(x)
        mean_y = self.mean(y)
        
        cov_terms = []
        for xi, yi in zip(x, y):
            diff_x = xi - mean_x
            diff_y = yi - mean_y
            product = diff_x * diff_y
            
            if hasattr(self.scheme, 'relinearize'):
                product = self.scheme.relinearize(product)
            
            cov_terms.append(product)
        
        return self.aggregator.mean(cov_terms)
    
    def linear_regression(self, x: List[Any], y: List[Any]) -> Tuple[Any, Any]:
        """
        简单线性回归
        
        y = a + b*x
        
        返回 (intercept, slope)
        
        Args:
            x: 自变量（加密）
            y: 因变量（加密）
            
        Returns:
            (截距, 斜率) 加密值
        """
        if len(x) != len(y):
            raise ValueError("数据集长度不匹配")
        
        n = len(x)
        
        # 计算均值
        mean_x = self.mean(x)
        mean_y = self.mean(y)
        
        # 计算斜率 b = cov(x,y) / var(x)
        numerator_terms = []
        denominator_terms = []
        
        for xi, yi in zip(x, y):
            diff_x = xi - mean_x
            diff_y = yi - mean_y
            
            num_term = diff_x * diff_y
            den_term = diff_x * diff_x
            
            if hasattr(self.scheme, 'relinearize'):
                num_term = self.scheme.relinearize(num_term)
                den_term = self.scheme.relinearize(den_term)
            
            numerator_terms.append(num_term)
            denominator_terms.append(den_term)
        
        numerator = self.aggregator.sum(numerator_terms)
        denominator = self.aggregator.sum(denominator_terms)
        
        slope = numerator * self._reciprocal_approx(denominator)
        
        # 计算截距 a = mean_y - b * mean_x
        intercept = mean_y - slope * mean_x
        
        return intercept, slope
    
    def compute_all(self, data: List[Any]) -> StatisticsResult:
        """
        计算所有统计量
        
        Args:
            data: 加密数据列表
            
        Returns:
            StatisticsResult: 包含所有统计结果
        """
        result = StatisticsResult()
        
        try:
            result.mean = self.mean(data)
        except Exception as e:
            logger.warning(f"均值计算失败: {e}")
        
        try:
            result.variance = self.variance(data)
        except Exception as e:
            logger.warning(f"方差计算失败: {e}")
        
        try:
            result.std = self.std(data)
        except Exception as e:
            logger.warning(f"标准差计算失败: {e}")
        
        try:
            result.median = self.median(data)
        except Exception as e:
            logger.warning(f"中位数计算失败: {e}")
        
        return result
    
    def _reciprocal_approx(self, value: Any, iterations: int = 5) -> Any:
        """
        近似倒数
        
        Args:
            value: 加密值
            iterations: 迭代次数
            
        Returns:
            近似倒数
        """
        x = 0.1  # 初始估计
        
        for _ in range(iterations):
            x = x * (2 - value * x)
        
        return x