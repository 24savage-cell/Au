"""
基础组合定理实现

提供差分隐私的基础组合定理：
- 串行组合定理
- 并行组合定理
"""

import logging
from typing import List, Tuple, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class PrivacyBudget:
    """隐私预算"""
    epsilon: float
    delta: float = 0.0


class BasicComposer:
    """
    基础组合器
    
    实现差分隐私的基础组合定理。
    
    示例:
        >>> composer = BasicComposer()
        >>> 
        >>> # 串行组合
        >>> budgets = [PrivacyBudget(0.1, 0), PrivacyBudget(0.2, 0)]
        >>> total = composer.sequential_compose(budgets)
        >>> print(f"总隐私预算: ε={total.epsilon}, δ={total.delta}")
    """
    
    def __init__(self):
        """初始化基础组合器"""
        logger.info("初始化基础组合器")
    
    def sequential_compose(self, budgets: List[PrivacyBudget]) -> PrivacyBudget:
        """
        串行组合定理
        
        如果M1提供(ε1, δ1)-DP，M2提供(ε2, δ2)-DP，
        则它们的组合提供(ε1+ε2, δ1+δ2)-DP。
        
        Args:
            budgets: 隐私预算列表
            
        Returns:
            组合后的隐私预算
        """
        total_epsilon = sum(b.epsilon for b in budgets)
        total_delta = sum(b.delta for b in budgets)
        
        logger.debug(f"串行组合: ε={total_epsilon}, δ={total_delta}")
        
        return PrivacyBudget(total_epsilon, total_delta)
    
    def parallel_compose(self, budgets: List[PrivacyBudget],
                         num_disjoint_sets: int = 1) -> PrivacyBudget:
        """
        并行组合定理
        
        如果多个机制作用于不相交的数据子集，
        则总隐私预算为各机制预算的最大值。
        
        Args:
            budgets: 隐私预算列表
            num_disjoint_sets: 不相交数据集数量
            
        Returns:
            组合后的隐私预算
        """
        if not budgets:
            return PrivacyBudget(0.0, 0.0)
        
        # 取最大值
        max_epsilon = max(b.epsilon for b in budgets)
        max_delta = max(b.delta for b in budgets)
        
        logger.debug(f"并行组合: ε={max_epsilon}, δ={max_delta}")
        
        return PrivacyBudget(max_epsilon, max_delta)
    
    def compose_k_times(self, budget: PrivacyBudget,
                        k: int) -> PrivacyBudget:
        """
        同一机制执行k次的组合
        
        Args:
            budget: 单次执行的隐私预算
            k: 执行次数
            
        Returns:
            组合后的隐私预算
        """
        return PrivacyBudget(
            epsilon=budget.epsilon * k,
            delta=budget.delta * k
        )
    
    def verify_budget_sufficient(self, available: PrivacyBudget,
                                  required: PrivacyBudget) -> bool:
        """
        验证隐私预算是否充足
        
        Args:
            available: 可用预算
            required: 所需预算
            
        Returns:
            是否充足
        """
        return (available.epsilon >= required.epsilon and
                available.delta >= required.delta)


class SimpleComposition:
    """
    简单组合
    
    用于跟踪多个机制的累积隐私损失。
    """
    
    def __init__(self, total_epsilon: float = 1.0,
                 total_delta: float = 0.0):
        """
        初始化简单组合
        
        Args:
            total_epsilon: 总隐私预算ε
            total_delta: 总隐私预算δ
        """
        self.total_budget = PrivacyBudget(total_epsilon, total_delta)
        self.used_budget = PrivacyBudget(0.0, 0.0)
        self.composer = BasicComposer()
    
    def allocate(self, epsilon: float, delta: float = 0.0) -> bool:
        """
        分配隐私预算
        
        Args:
            epsilon: 所需ε
            delta: 所需δ
            
        Returns:
            是否分配成功
        """
        required = PrivacyBudget(epsilon, delta)
        
        # 计算使用后的总预算
        new_used = self.composer.sequential_compose(
            [self.used_budget, required]
        )
        
        # 检查是否超出总预算
        if self.composer.verify_budget_sufficient(self.total_budget, new_used):
            self.used_budget = new_used
            return True
        
        return False
    
    def get_remaining_budget(self) -> PrivacyBudget:
        """
        获取剩余预算
        
        Returns:
            剩余隐私预算
        """
        return PrivacyBudget(
            epsilon=self.total_budget.epsilon - self.used_budget.epsilon,
            delta=self.total_budget.delta - self.used_budget.delta
        )
    
    def reset(self):
        """重置已使用预算"""
        self.used_budget = PrivacyBudget(0.0, 0.0)