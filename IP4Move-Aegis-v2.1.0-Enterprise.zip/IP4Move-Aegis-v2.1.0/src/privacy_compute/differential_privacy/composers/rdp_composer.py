"""
Rényi差分隐私组合实现

RDP (Rényi Differential Privacy) 提供比标准DP更紧的组合界，
特别适用于重复应用相同机制的场合。
"""

import logging
import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from scipy.special import logsumexp

logger = logging.getLogger(__name__)


@dataclass
class RDPPrivacyBudget:
    """RDP隐私预算"""
    alpha: float  # Rényi阶数
    epsilon: float  # RDP epsilon
    
    def to_approx_dp(self, delta: float) -> Tuple[float, float]:
        """
        转换为近似差分隐私
        
        (α, ε)-RDP => (ε + log(1/δ)/(α-1), δ)-DP
        
        Args:
            delta: 目标delta
            
        Returns:
            (epsilon, delta) 近似DP参数
        """
        if self.alpha <= 1:
            raise ValueError("alpha必须大于1")
        
        approx_epsilon = self.epsilon + np.log(1 / delta) / (self.alpha - 1)
        return approx_epsilon, delta


class RDPComposer:
    """
    RDP组合器
    
    RDP的组合是简单的加法：
    如果M1满足(α, ε1)-RDP，M2满足(α, ε2)-RDP，
    则它们的组合满足(α, ε1+ε2)-RDP。
    
    示例:
        >>> composer = RDPComposer()
        >>> composer.add_mechanism(alpha=10, epsilon=0.1)
        >>> composer.add_mechanism(alpha=10, epsilon=0.1)
        >>> rdp_budget = composer.get_rdp_budget(alpha=10)
        >>> epsilon, delta = rdp_budget.to_approx_dp(delta=1e-5)
    """
    
    def __init__(self):
        """初始化RDP组合器"""
        self.mechanisms: Dict[float, List[float]] = {}
        logger.info("初始化RDP组合器")
    
    def add_mechanism(self, alpha: float, epsilon: float):
        """
        添加一个RDP机制
        
        Args:
            alpha: Rényi阶数
            epsilon: RDP epsilon
        """
        if alpha not in self.mechanisms:
            self.mechanisms[alpha] = []
        self.mechanisms[alpha].append(epsilon)
    
    def get_rdp_budget(self, alpha: float) -> RDPPrivacyBudget:
        """
        获取指定alpha的RDP预算
        
        Args:
            alpha: Rényi阶数
            
        Returns:
            RDP隐私预算
        """
        if alpha not in self.mechanisms:
            return RDPPrivacyBudget(alpha, 0.0)
        
        total_epsilon = sum(self.mechanisms[alpha])
        return RDPPrivacyBudget(alpha, total_epsilon)
    
    def compose_gaussian(self, sigma: float, k: int, alpha: float) -> float:
        """
        计算高斯机制的RDP
        
        对于敏感度为1的高斯机制，RDP为：
        ε(α) = α / (2 * σ^2)
        
        Args:
            sigma: 噪声标准差
            k: 机制数量
            alpha: Rényi阶数
            
        Returns:
            组合后的RDP epsilon
        """
        single_epsilon = alpha / (2 * sigma ** 2)
        return k * single_epsilon
    
    def compose_randomized_response(self, p: float, k: int, alpha: float) -> float:
        """
        计算随机响应的RDP
        
        Args:
            p: 真实概率
            k: 机制数量
            alpha: Rényi阶数
            
        Returns:
            组合后的RDP epsilon
        """
        # 简化的计算
        q = 1 - p
        single_epsilon = (1 / (alpha - 1)) * np.log(
            p ** alpha * q ** (1 - alpha) + q ** alpha * p ** (1 - alpha)
        )
        return k * single_epsilon
    
    def find_optimal_alpha(self, delta: float, 
                           alpha_range: Tuple[float, float] = (1.1, 100),
                           num_points: int = 100) -> Tuple[float, float]:
        """
        找到最优的alpha以最小化近似DP的epsilon
        
        Args:
            delta: 目标delta
            alpha_range: alpha搜索范围
            num_points: 搜索点数
            
        Returns:
            (最优alpha, 最小epsilon)
        """
        alphas = np.linspace(alpha_range[0], alpha_range[1], num_points)
        min_epsilon = float('inf')
        best_alpha = alphas[0]
        
        for alpha in alphas:
            rdp_budget = self.get_rdp_budget(alpha)
            if rdp_budget.epsilon > 0:
                approx_epsilon, _ = rdp_budget.to_approx_dp(delta)
                if approx_epsilon < min_epsilon:
                    min_epsilon = approx_epsilon
                    best_alpha = alpha
        
        return best_alpha, min_epsilon
    
    def get_total_rdp(self) -> Dict[float, float]:
        """
        获取所有alpha的RDP预算
        
        Returns:
            alpha -> epsilon 映射
        """
        return {alpha: sum(epsilons) 
                for alpha, epsilons in self.mechanisms.items()}
    
    def reset(self):
        """重置所有机制"""
        self.mechanisms.clear()


class RDPAccountant:
    """
    RDP会计
    
    跟踪累积的RDP并转换为标准DP。
    """
    
    def __init__(self):
        """初始化RDP会计"""
        self.composer = RDPComposer()
        logger.info("初始化RDP会计")
    
    def add_gaussian_mechanism(self, sigma: float, sensitivity: float = 1.0):
        """
        添加高斯机制
        
        Args:
            sigma: 噪声标准差
            sensitivity: 敏感度
        """
        # 归一化sigma
        normalized_sigma = sigma / sensitivity
        
        # 为多个alpha添加RDP
        for alpha in [1.5, 2, 3, 5, 10, 20, 50, 100]:
            epsilon = alpha / (2 * normalized_sigma ** 2)
            self.composer.add_mechanism(alpha, epsilon)
    
    def add_laplace_mechanism(self, epsilon: float, k: int = 1):
        """
        添加拉普拉斯机制
        
        Args:
            epsilon: 拉普拉斯机制的epsilon
            k: 执行次数
        """
        # 拉普拉斯机制在RDP中的表示
        for alpha in [1.5, 2, 3, 5, 10]:
            rdp_epsilon = k * epsilon * (alpha - 1) / alpha
            self.composer.add_mechanism(alpha, rdp_epsilon)
    
    def get_epsilon(self, delta: float) -> float:
        """
        获取给定delta下的最小epsilon
        
        Args:
            delta: 目标delta
            
        Returns:
            最小epsilon
        """
        _, min_epsilon = self.composer.find_optimal_alpha(delta)
        return min_epsilon
    
    def verify_budget(self, epsilon_target: float, delta_target: float) -> bool:
        """
        验证是否满足目标隐私预算
        
        Args:
            epsilon_target: 目标epsilon
            delta_target: 目标delta
            
        Returns:
            是否满足
        """
        actual_epsilon = self.get_epsilon(delta_target)
        return actual_epsilon <= epsilon_target