"""
高级组合定理实现

提供差分隐私的高级组合定理（Advanced Composition），
相比基础组合定理，在多次查询时提供更紧的隐私界。
"""

import logging
import numpy as np
from typing import List, Tuple, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class AdvancedPrivacyBudget:
    """高级组合隐私预算"""
    epsilon: float
    delta: float
    k: int  # 机制数量


class AdvancedComposer:
    """
    高级组合器
    
    实现Kairouz等人的高级组合定理。
    
    对于k个机制，每个提供(ε, δ)-DP，
    高级组合定理给出的隐私界为：
    (ε', kδ + δ')-DP
    
    其中 ε' = sqrt(2k * ln(1/δ')) * ε + k * ε * (e^ε - 1) / (e^ε + 1)
    
    示例:
        >>> composer = AdvancedComposer(delta_prime=1e-5)
        >>> budget = composer.compose(epsilon=0.1, delta=0, k=100)
        >>> print(f"组合后: ε={budget.epsilon}, δ={budget.delta}")
    """
    
    def __init__(self, delta_prime: float = 1e-5):
        """
        初始化高级组合器
        
        Args:
            delta_prime: 额外的delta参数
        """
        self.delta_prime = delta_prime
        logger.info(f"初始化高级组合器: δ'={delta_prime}")
    
    def compose(self, epsilon: float, delta: float, k: int) -> AdvancedPrivacyBudget:
        """
        高级组合
        
        Args:
            epsilon: 单个机制的ε
            delta: 单个机制的δ
            k: 机制数量
            
        Returns:
            组合后的隐私预算
        """
        if epsilon <= 0:
            return AdvancedPrivacyBudget(0.0, k * delta + self.delta_prime, k)
        
        # 高级组合公式
        # ε' = sqrt(2k * ln(1/δ')) * ε + k * ε * (e^ε - 1) / (e^ε + 1)
        
        term1 = np.sqrt(2 * k * np.log(1 / self.delta_prime)) * epsilon
        term2 = k * epsilon * (np.exp(epsilon) - 1) / (np.exp(epsilon) + 1)
        
        epsilon_total = term1 + term2
        delta_total = k * delta + self.delta_prime
        
        logger.debug(f"高级组合: k={k}, ε'={epsilon_total:.6f}, δ'={delta_total:.6e}")
        
        return AdvancedPrivacyBudget(epsilon_total, delta_total, k)
    
    def compose_heterogeneous(self, budgets: List[Tuple[float, float]]) -> AdvancedPrivacyBudget:
        """
        异构机制的高级组合
        
        Args:
            budgets: (epsilon, delta)列表
            
        Returns:
            组合后的隐私预算
        """
        k = len(budgets)
        
        # 计算平均epsilon
        epsilons = [b[0] for b in budgets]
        avg_epsilon = np.mean(epsilons)
        max_epsilon = max(epsilons)
        
        # 使用最大epsilon进行保守估计
        deltas = [b[1] for b in budgets]
        sum_delta = sum(deltas)
        
        return self.compose(max_epsilon, sum_delta / k, k)


class ZeroConcentratedDPComposer:
    """
    零集中差分隐私(zCDP)组合器
    
    zCDP提供更紧的组合界。
    """
    
    def __init__(self):
        """初始化zCDP组合器"""
        logger.info("初始化zCDP组合器")
    
    def compose(self, rho: float, k: int) -> float:
        """
        zCDP组合
        
        k个ρ-zCDP机制的组合提供kρ-zCDP。
        
        Args:
            rho: zCDP参数
            k: 机制数量
            
        Returns:
            组合后的ρ
        """
        return k * rho
    
    def zcdp_to_approx_dp(self, rho: float, delta: float) -> float:
        """
        将zCDP转换为近似差分隐私
        
        Args:
            rho: zCDP参数
            delta: 目标delta
            
        Returns:
            对应的epsilon
        """
        # ε = ρ + sqrt(4ρ * log(1/δ))
        return rho + np.sqrt(4 * rho * np.log(1 / delta))