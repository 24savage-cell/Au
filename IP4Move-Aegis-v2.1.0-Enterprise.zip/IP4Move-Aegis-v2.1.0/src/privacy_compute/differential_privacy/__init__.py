"""
差分隐私模块

提供差分隐私机制实现，保护数据隐私的同时允许统计分析。

主要组件:
    - mechanisms: 各种差分隐私机制（拉普拉斯、高斯、指数等）
    - composers: 隐私预算组合定理
    - queries: 差分隐私查询
    - epsilon_management: 隐私预算管理
    - applications: 隐私保护应用
"""

from .mechanisms.laplace import LaplaceMechanism
from .mechanisms.gaussian import GaussianMechanism
from .mechanisms.exponential import ExponentialMechanism
from .mechanisms.geometric import GeometricMechanism
from .composers.basic_composer import BasicComposer
from .composers.advanced_composer import AdvancedComposer
from .composers.rdp_composer import RDPComposer
from .epsilon_management.budget_tracker import BudgetTracker
from .epsilon_management.adaptive_allocation import AdaptiveAllocator

__version__ = "1.0.0"
__author__ = "IP4Move Team"

__all__ = [
    # 机制
    "LaplaceMechanism",
    "GaussianMechanism",
    "ExponentialMechanism",
    "GeometricMechanism",
    # 组合器
    "BasicComposer",
    "AdvancedComposer",
    "RDPComposer",
    # 隐私预算管理
    "BudgetTracker",
    "AdaptiveAllocator",
]