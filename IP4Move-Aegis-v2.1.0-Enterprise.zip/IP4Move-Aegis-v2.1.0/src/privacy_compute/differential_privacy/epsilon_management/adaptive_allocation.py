"""
自适应隐私预算分配

根据查询特性和数据分布动态分配隐私预算。
"""

import logging
import numpy as np
from typing import List, Dict, Optional, Callable, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class QueryInfo:
    """查询信息"""
    query_id: str
    importance: float  # 查询重要性（0-1）
    sensitivity: float  # 敏感度
    expected_utility: float  # 期望效用


class AdaptiveAllocator:
    """
    自适应隐私预算分配器
    
    根据查询特性和数据分布动态分配预算。
    
    示例:
        >>> allocator = AdaptiveAllocator(total_epsilon=1.0)
        >>> 
        >>> # 注册查询
        >>> allocator.register_query("q1", importance=0.8, sensitivity=1.0)
        >>> allocator.register_query("q2", importance=0.5, sensitivity=2.0)
        >>> 
        >>> # 分配预算
        >>> budget = allocator.allocate("q1")
    """
    
    def __init__(self, total_epsilon: float, total_delta: float = 0.0):
        """
        初始化自适应分配器
        
        Args:
            total_epsilon: 总隐私预算
            total_delta: 总隐私预算δ
        """
        self.total_epsilon = total_epsilon
        self.total_delta = total_delta
        self.remaining_epsilon = total_epsilon
        self.remaining_delta = total_delta
        self.queries: Dict[str, QueryInfo] = {}
        self.allocations: Dict[str, float] = {}
        
        logger.info(f"初始化自适应分配器: 总预算 ε={total_epsilon}")
    
    def register_query(self, query_id: str,
                       importance: float = 1.0,
                       sensitivity: float = 1.0,
                       expected_utility: float = 1.0):
        """
        注册查询
        
        Args:
            query_id: 查询ID
            importance: 重要性（0-1）
            sensitivity: 敏感度
            expected_utility: 期望效用
        """
        self.queries[query_id] = QueryInfo(
            query_id=query_id,
            importance=importance,
            sensitivity=sensitivity,
            expected_utility=expected_utility
        )
    
    def allocate(self, query_id: str, 
                 allocation_strategy: str = "proportional") -> Dict[str, float]:
        """
        为查询分配预算
        
        Args:
            query_id: 查询ID
            allocation_strategy: 分配策略
            
        Returns:
            分配的预算
        """
        if query_id not in self.queries:
            raise ValueError(f"查询 {query_id} 未注册")
        
        query = self.queries[query_id]
        
        if allocation_strategy == "proportional":
            epsilon = self._proportional_allocation(query)
        elif allocation_strategy == "importance":
            epsilon = self._importance_based_allocation(query)
        elif allocation_strategy == "uniform":
            epsilon = self._uniform_allocation()
        else:
            epsilon = self._proportional_allocation(query)
        
        # 确保不超过剩余预算
        epsilon = min(epsilon, self.remaining_epsilon)
        
        self.allocations[query_id] = epsilon
        self.remaining_epsilon -= epsilon
        
        return {'epsilon': epsilon, 'delta': self.total_delta}
    
    def _proportional_allocation(self, query: QueryInfo) -> float:
        """
        按比例分配
        
        基于查询重要性和敏感度分配预算。
        """
        if not self.queries:
            return self.total_epsilon
        
        # 计算总权重
        total_weight = sum(
            q.importance / q.sensitivity 
            for q in self.queries.values()
        )
        
        # 查询权重
        query_weight = query.importance / query.sensitivity
        
        # 按比例分配
        epsilon = self.total_epsilon * (query_weight / total_weight)
        
        return epsilon
    
    def _importance_based_allocation(self, query: QueryInfo) -> float:
        """
        基于重要性的分配
        """
        total_importance = sum(q.importance for q in self.queries.values())
        
        if total_importance == 0:
            return self.total_epsilon / len(self.queries)
        
        return self.total_epsilon * (query.importance / total_importance)
    
    def _uniform_allocation(self) -> float:
        """
        均匀分配
        """
        if not self.queries:
            return self.total_epsilon
        
        return self.total_epsilon / len(self.queries)
    
    def get_allocation_summary(self) -> Dict[str, Any]:
        """
        获取分配摘要
        
        Returns:
            分配摘要
        """
        return {
            'total_epsilon': self.total_epsilon,
            'remaining_epsilon': self.remaining_epsilon,
            'allocated_epsilon': self.total_epsilon - self.remaining_epsilon,
            'allocations': self.allocations.copy(),
            'num_queries': len(self.queries)
        }
