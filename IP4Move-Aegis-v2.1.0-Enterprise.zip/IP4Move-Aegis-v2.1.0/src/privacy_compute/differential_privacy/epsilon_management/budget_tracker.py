"""
隐私预算追踪器

追踪和管理差分隐私的隐私预算消耗。
"""

import logging
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class BudgetRecord:
    """预算使用记录"""
    epsilon: float
    delta: float
    mechanism: str
    timestamp: datetime = field(default_factory=datetime.now)
    description: str = ""


class BudgetTracker:
    """
    隐私预算追踪器
    
    追踪和管理隐私预算的使用情况。
    
    示例:
        >>> tracker = BudgetTracker(total_epsilon=1.0, total_delta=1e-5)
        >>> 
        >>> # 记录预算使用
        >>> tracker.consume(epsilon=0.1, delta=0, mechanism="Laplace")
        >>> tracker.consume(epsilon=0.2, delta=0, mechanism="Gaussian")
        >>> 
        >>> # 检查剩余预算
        >>> remaining = tracker.get_remaining_budget()
        >>> print(f"剩余: ε={remaining['epsilon']}, δ={remaining['delta']}")
    """
    
    def __init__(self, total_epsilon: float, total_delta: float = 0.0):
        """
        初始化预算追踪器
        
        Args:
            total_epsilon: 总隐私预算ε
            total_delta: 总隐私预算δ
        """
        self.total_epsilon = total_epsilon
        self.total_delta = total_delta
        self.used_epsilon = 0.0
        self.used_delta = 0.0
        self.records: List[BudgetRecord] = []
        
        logger.info(f"初始化预算追踪器: 总预算 ε={total_epsilon}, δ={total_delta}")
    
    def consume(self, epsilon: float, delta: float = 0.0,
                mechanism: str = "", description: str = "") -> bool:
        """
        消耗隐私预算
        
        Args:
            epsilon: 消耗的ε
            delta: 消耗的δ
            mechanism: 使用的机制
            description: 描述
            
        Returns:
            是否成功消耗
        """
        # 检查是否有足够预算
        if not self.check_budget(epsilon, delta):
            logger.warning("隐私预算不足")
            return False
        
        # 记录消耗
        self.used_epsilon += epsilon
        self.used_delta += delta
        
        record = BudgetRecord(
            epsilon=epsilon,
            delta=delta,
            mechanism=mechanism,
            description=description
        )
        self.records.append(record)
        
        logger.debug(f"消耗预算: ε={epsilon}, δ={delta}, 机制={mechanism}")
        
        return True
    
    def check_budget(self, epsilon: float, delta: float = 0.0) -> bool:
        """
        检查是否有足够预算
        
        Args:
            epsilon: 需要的ε
            delta: 需要的δ
            
        Returns:
            是否有足够预算
        """
        remaining_epsilon = self.total_epsilon - self.used_epsilon
        remaining_delta = self.total_delta - self.used_delta
        
        return remaining_epsilon >= epsilon and remaining_delta >= delta
    
    def get_remaining_budget(self) -> Dict[str, float]:
        """
        获取剩余预算
        
        Returns:
            剩余预算字典
        """
        return {
            'epsilon': self.total_epsilon - self.used_epsilon,
            'delta': self.total_delta - self.used_delta
        }
    
    def get_usage_stats(self) -> Dict[str, Any]:
        """
        获取使用统计
        
        Returns:
            使用统计字典
        """
        return {
            'total_epsilon': self.total_epsilon,
            'total_delta': self.total_delta,
            'used_epsilon': self.used_epsilon,
            'used_delta': self.used_delta,
            'remaining_epsilon': self.total_epsilon - self.used_epsilon,
            'remaining_delta': self.total_delta - self.used_delta,
            'usage_percentage': (self.used_epsilon / self.total_epsilon) * 100,
            'num_queries': len(self.records)
        }
    
    def get_records(self) -> List[BudgetRecord]:
        """
        获取所有记录
        
        Returns:
            预算使用记录列表
        """
        return self.records.copy()
    
    def reset(self):
        """重置预算追踪器"""
        self.used_epsilon = 0.0
        self.used_delta = 0.0
        self.records.clear()
        logger.info("预算追踪器已重置")
