"""
隐私联邦学习应用

基于差分隐私的联邦学习实现。
"""

import logging
import numpy as np
from typing import List, Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)


class PrivateFederatedLearning:
    """
    隐私联邦学习
    
    在联邦学习中集成差分隐私保护。
    
    示例:
        >>> pfl = PrivateFederatedLearning(
        ...     epsilon=1.0,
        ...     delta=1e-5,
        ...     num_clients=10
        ... )
        >>> 
        >>> # 模拟客户端更新
        >>> client_updates = [np.random.randn(10) for _ in range(10)]
        >>> aggregated = pfl.aggregate(client_updates)
    """
    
    def __init__(self,
                 epsilon: float = 1.0,
                 delta: float = 1e-5,
                 num_clients: int = 10,
                 max_grad_norm: float = 1.0):
        """
        初始化隐私联邦学习
        
        Args:
            epsilon: 隐私预算
            delta: 松弛参数
            num_clients: 客户端数量
            max_grad_norm: 最大梯度范数
        """
        self.epsilon = epsilon
        self.delta = delta
        self.num_clients = num_clients
        self.max_grad_norm = max_grad_norm
        
        logger.info(f"初始化隐私联邦学习: ε={epsilon}, δ={delta}, "
                   f"客户端数={num_clients}")
    
    def clip_update(self, update: np.ndarray) -> np.ndarray:
        """
        裁剪客户端更新
        
        Args:
            update: 客户端更新
            
        Returns:
            裁剪后的更新
        """
        norm = np.linalg.norm(update)
        if norm > self.max_grad_norm:
            return update * (self.max_grad_norm / norm)
        return update
    
    def add_noise(self, aggregated: np.ndarray) -> np.ndarray:
        """
        为聚合结果添加噪声
        
        Args:
            aggregated: 聚合结果
            
        Returns:
            带噪声的结果
        """
        # 计算噪声标准差
        sigma = np.sqrt(2 * np.log(1.25 / self.delta)) / self.epsilon
        sigma = sigma * self.max_grad_norm / self.num_clients
        
        noise = np.random.normal(0, sigma, aggregated.shape)
        return aggregated + noise
    
    def aggregate(self, 
                  client_updates: List[np.ndarray],
                  weights: Optional[List[float]] = None) -> np.ndarray:
        """
        聚合客户端更新
        
        Args:
            client_updates: 客户端更新列表
            weights: 权重列表
            
        Returns:
            聚合结果
        """
        # 裁剪每个客户端的更新
        clipped_updates = [self.clip_update(u) for u in client_updates]
        
        # 加权平均
        if weights is None:
            aggregated = np.mean(clipped_updates, axis=0)
        else:
            total_weight = sum(weights)
            normalized_weights = [w / total_weight for w in weights]
            aggregated = sum(u * w for u, w in zip(clipped_updates, normalized_weights))
        
        # 添加噪声
        noisy_aggregated = self.add_noise(aggregated)
        
        return noisy_aggregated
