"""
高斯机制实现

高斯机制通过在查询结果中添加高斯（正态）分布的噪声
来实现(ε,δ)-差分隐私。

相比拉普拉斯机制，高斯机制对L2敏感度更优，适合高维数据。
"""

import logging
import numpy as np
from typing import Union, List, Optional, Callable, Any
from dataclasses import dataclass
from scipy.stats import norm

logger = logging.getLogger(__name__)


@dataclass
class GaussianPrivacyParams:
    """高斯机制隐私参数"""
    epsilon: float
    delta: float
    sigma: float  # 噪声标准差


class GaussianMechanism:
    """
    高斯机制
    
    通过在查询结果中添加高斯噪声来实现(ε,δ)-差分隐私。
    
    对于L2敏感度为s的查询，噪声标准差为：
    sigma = s * sqrt(2 * ln(1.25/δ)) / ε
    
    示例:
        >>> mechanism = GaussianMechanism(epsilon=1.0, delta=1e-5)
        >>> data = [23.5, 45.2, 67.8, 89.1, 12.3]
        >>> 
        >>> # 均值查询
        >>> mean = mechanism.mean_query(data, lower_bound=0, upper_bound=100)
        >>> print(f"私有均值: {mean}")
    """
    
    def __init__(self, epsilon: float = 1.0, 
                 delta: float = 1e-5,
                 random_state: Optional[int] = None):
        """
        初始化高斯机制
        
        Args:
            epsilon: 隐私预算参数
            delta: 松弛参数（必须 > 0）
            random_state: 随机种子
        """
        if epsilon <= 0:
            raise ValueError("epsilon必须大于0")
        if delta <= 0 or delta >= 1:
            raise ValueError("delta必须在(0,1)之间")
        
        self.epsilon = epsilon
        self.delta = delta
        self.random_state = random_state
        
        if random_state is not None:
            np.random.seed(random_state)
        
        logger.info(f"初始化高斯机制: epsilon={epsilon}, delta={delta}")
    
    def compute_sigma(self, l2_sensitivity: float) -> float:
        """
        计算噪声标准差
        
        根据(ε,δ)-差分隐私要求计算sigma
        
        Args:
            l2_sensitivity: L2敏感度
            
        Returns:
            噪声标准差
        """
        # sigma = l2_sensitivity * sqrt(2 * ln(1.25/δ)) / ε
        sigma = l2_sensitivity * np.sqrt(2 * np.log(1.25 / self.delta)) / self.epsilon
        return sigma
    
    def add_noise(self, value: float, l2_sensitivity: float) -> float:
        """
        添加高斯噪声
        
        Args:
            value: 原始值
            l2_sensitivity: L2敏感度
            
        Returns:
            添加噪声后的值
        """
        sigma = self.compute_sigma(l2_sensitivity)
        noise = np.random.normal(loc=0.0, scale=sigma)
        
        logger.debug(f"添加高斯噪声: sigma={sigma:.4f}, noise={noise:.4f}")
        
        return value + noise
    
    def add_noise_vector(self, vector: np.ndarray, 
                         l2_sensitivity: float) -> np.ndarray:
        """
        为向量添加高斯噪声
        
        Args:
            vector: 原始向量
            l2_sensitivity: L2敏感度
            
        Returns:
            添加噪声后的向量
        """
        sigma = self.compute_sigma(l2_sensitivity)
        noise = np.random.normal(loc=0.0, scale=sigma, size=vector.shape)
        
        return vector + noise
    
    def add_noise_matrix(self, matrix: np.ndarray,
                         l2_sensitivity: float) -> np.ndarray:
        """
        为矩阵添加高斯噪声
        
        Args:
            matrix: 原始矩阵
            l2_sensitivity: L2敏感度
            
        Returns:
            添加噪声后的矩阵
        """
        sigma = self.compute_sigma(l2_sensitivity)
        noise = np.random.normal(loc=0.0, scale=sigma, size=matrix.shape)
        
        return matrix + noise
    
    def count_query(self, data: List[Any]) -> float:
        """
        差分隐私计数查询
        
        Args:
            data: 数据列表
            
        Returns:
            带噪声的计数
        """
        true_count = len(data)
        # 计数查询的L2敏感度为1
        return self.add_noise(float(true_count), 1.0)
    
    def sum_query(self, data: List[float],
                  lower_bound: float,
                  upper_bound: float) -> float:
        """
        差分隐私求和查询
        
        Args:
            data: 数值列表
            lower_bound: 下界
            upper_bound: 上界
            
        Returns:
            带噪声的求和结果
        """
        # 裁剪数据
        clipped_data = np.clip(data, lower_bound, upper_bound)
        true_sum = np.sum(clipped_data)
        
        # L2敏感度（单维）
        l2_sensitivity = max(abs(lower_bound), abs(upper_bound))
        
        return self.add_noise(true_sum, l2_sensitivity)
    
    def mean_query(self, data: List[float],
                   lower_bound: float,
                   upper_bound: float) -> float:
        """
        差分隐私均值查询
        
        Args:
            data: 数值列表
            lower_bound: 下界
            upper_bound: 上界
            
        Returns:
            带噪声的均值
        """
        n = len(data)
        if n == 0:
            return 0.0
        
        private_sum = self.sum_query(data, lower_bound, upper_bound)
        private_count = self.count_query(data)
        private_count = max(private_count, 1.0)
        
        return private_sum / private_count
    
    def vector_query(self, vector: np.ndarray,
                     l2_sensitivity: float) -> np.ndarray:
        """
        差分隐私向量查询
        
        Args:
            vector: 输入向量
            l2_sensitivity: L2敏感度
            
        Returns:
            带噪声的向量
        """
        return self.add_noise_vector(vector, l2_sensitivity)
    
    def get_privacy_parameters(self) -> dict:
        """
        获取隐私参数
        
        Returns:
            隐私参数字典
        """
        return {
            'epsilon': self.epsilon,
            'delta': self.delta,
            'mechanism': 'Gaussian',
            'type': 'approx_dp'
        }


class AnalyticGaussianMechanism:
    """
    解析高斯机制
    
    使用解析方法计算最优的sigma，提供更紧的隐私保证。
    """
    
    def __init__(self, epsilon: float = 1.0, delta: float = 1e-5):
        """
        初始化解析高斯机制
        
        Args:
            epsilon: 隐私预算
            delta: 松弛参数
        """
        self.epsilon = epsilon
        self.delta = delta
    
    def compute_sigma_analytic(self, l2_sensitivity: float) -> float:
        """
        使用解析方法计算sigma
        
        基于Balle&Wang的解析高斯机制
        
        Args:
            l2_sensitivity: L2敏感度
            
        Returns:
            噪声标准差
        """
        # 简化的解析计算
        # 实际应使用更复杂的数值方法
        return GaussianMechanism(self.epsilon, self.delta).compute_sigma(l2_sensitivity)


class GaussianMechanismWithConcentratedDP:
    """
    集中差分隐私高斯机制
    
    使用集中差分隐私（CDP）框架分析高斯机制。
    """
    
    def __init__(self, rho: float = 0.1):
        """
        初始化CDP高斯机制
        
        Args:
            rho: 隐私损失参数
        """
        self.rho = rho
    
    def compute_sigma_cdp(self, l2_sensitivity: float) -> float:
        """
        基于CDP计算sigma
        
        Args:
            l2_sensitivity: L2敏感度
            
        Returns:
            噪声标准差
        """
        # 在CDP中，sigma = l2_sensitivity / sqrt(2*rho)
        return l2_sensitivity / np.sqrt(2 * self.rho)
    
    def cdp_to_approx_dp(self, rho: float, delta: float) -> float:
        """
        将CDP转换为近似差分隐私参数
        
        Args:
            rho: CDP参数
            delta: 目标delta
            
        Returns:
            对应的epsilon
        """
        # epsilon = rho + 2*sqrt(rho * log(1/delta))
        return rho + 2 * np.sqrt(rho * np.log(1 / delta))