"""
几何机制实现

几何机制是拉普拉斯机制在整数域上的离散版本，
通过在查询结果中添加几何分布的噪声来实现差分隐私。

适用于整数查询和计数数据。
"""

import logging
import numpy as np
from typing import Union, List, Optional, Callable, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


class GeometricMechanism:
    """
    几何机制
    
    几何分布的概率质量函数：
    P(X = k) = (1 - α) * α^|k|，其中 α = exp(-ε/sensitivity)
    
    这是拉普拉斯机制在整数域上的离散对应。
    
    示例:
        >>> mechanism = GeometricMechanism(epsilon=1.0)
        >>> 
        >>> # 整数计数查询
        >>> count = mechanism.add_noise(100, sensitivity=1)
        >>> print(f"私有计数: {count}")
    """
    
    def __init__(self, epsilon: float = 1.0,
                 random_state: Optional[int] = None):
        """
        初始化几何机制
        
        Args:
            epsilon: 隐私预算参数
            random_state: 随机种子
        """
        if epsilon <= 0:
            raise ValueError("epsilon必须大于0")
        
        self.epsilon = epsilon
        self.random_state = random_state
        
        if random_state is not None:
            np.random.seed(random_state)
        
        logger.info(f"初始化几何机制: epsilon={epsilon}")
    
    def sample_geometric(self, alpha: float) -> int:
        """
        从对称几何分布采样
        
        Args:
            alpha: 分布参数 (0 < alpha < 1)
            
        Returns:
            采样的整数值
        """
        if alpha <= 0 or alpha >= 1:
            raise ValueError("alpha必须在(0,1)之间")
        
        # 几何分布：P(X = k) = (1-α) * α^k for k >= 0
        # 对称版本：P(X = k) = (1-α)/(1+α) * α^|k|
        
        # 使用逆变换采样
        u = np.random.random()
        
        # 计算累积分布函数的逆
        if u < 0.5:
            # 正半部分
            v = 2 * u
            k = int(np.floor(np.log(v) / np.log(alpha)))
        else:
            # 负半部分
            v = 2 * (1 - u)
            k = -int(np.floor(np.log(v) / np.log(alpha)))
        
        return k
    
    def add_noise(self, value: int, sensitivity: float = 1.0) -> int:
        """
        添加几何噪声
        
        Args:
            value: 原始整数值
            sensitivity: 查询敏感度
            
        Returns:
            添加噪声后的整数值
        """
        # 计算参数 α = exp(-ε/sensitivity)
        alpha = np.exp(-self.epsilon / sensitivity)
        
        # 采样噪声
        noise = self.sample_geometric(alpha)
        
        logger.debug(f"添加几何噪声: alpha={alpha:.4f}, noise={noise}")
        
        return value + noise
    
    def add_noise_vector(self, values: np.ndarray,
                         sensitivity: float = 1.0) -> np.ndarray:
        """
        为整数向量添加几何噪声
        
        Args:
            values: 整数向量
            sensitivity: 敏感度
            
        Returns:
            带噪声的整数向量
        """
        alpha = np.exp(-self.epsilon / sensitivity)
        
        noises = [self.sample_geometric(alpha) for _ in range(len(values))]
        return values + np.array(noises)
    
    def count_query(self, data: List[Any]) -> int:
        """
        差分隐私计数查询
        
        Args:
            data: 数据列表
            
        Returns:
            带噪声的计数
        """
        true_count = len(data)
        return self.add_noise(true_count, sensitivity=1)
    
    def sum_query(self, data: List[int],
                  lower_bound: int,
                  upper_bound: int) -> int:
        """
        差分隐私求和查询
        
        Args:
            data: 整数列表
            lower_bound: 下界
            upper_bound: 上界
            
        Returns:
            带噪声的求和结果
        """
        # 裁剪数据
        clipped_data = np.clip(data, lower_bound, upper_bound)
        true_sum = int(np.sum(clipped_data))
        
        # 敏感度
        sensitivity = upper_bound - lower_bound
        
        return self.add_noise(true_sum, sensitivity)
    
    def histogram_query(self, data: List[Any],
                        bins: List[Any]) -> dict:
        """
        差分隐私直方图查询
        
        Args:
            data: 数据列表
            bins: 分箱定义
            
        Returns:
            带噪声的直方图
        """
        histogram = {}
        
        for bin_val in bins:
            count = sum(1 for x in data if x == bin_val)
            # 每个分箱敏感度为1
            histogram[bin_val] = self.add_noise(count, sensitivity=1)
        
        return histogram
    
    def get_privacy_parameters(self) -> dict:
        """
        获取隐私参数
        
        Returns:
            隐私参数字典
        """
        return {
            'epsilon': self.epsilon,
            'delta': 0.0,
            'mechanism': 'Geometric',
            'type': 'pure_dp'
        }


class TruncatedGeometricMechanism:
    """
    截断几何机制
    
    将输出限制在指定范围内，避免噪声过大导致的不合理结果。
    """
    
    def __init__(self, epsilon: float = 1.0,
                 min_value: int = 0,
                 max_value: int = 100):
        """
        初始化截断几何机制
        
        Args:
            epsilon: 隐私预算
            min_value: 最小输出值
            max_value: 最大输出值
        """
        self.epsilon = epsilon
        self.min_value = min_value
        self.max_value = max_value
        self.base_mechanism = GeometricMechanism(epsilon)
    
    def add_noise(self, value: int, sensitivity: float = 1.0) -> int:
        """
        添加截断的几何噪声
        
        Args:
            value: 原始值
            sensitivity: 敏感度
            
        Returns:
            带噪声的截断值
        """
        noisy_value = self.base_mechanism.add_noise(value, sensitivity)
        
        # 截断到有效范围
        return int(np.clip(noisy_value, self.min_value, self.max_value))


class TwoSidedGeometricMechanism:
    """
    双边几何机制
    
    标准几何机制的对称版本。
    """
    
    def __init__(self, epsilon: float = 1.0):
        """
        初始化双边几何机制
        
        Args:
            epsilon: 隐私预算
        """
        self.epsilon = epsilon
    
    def sample_two_sided_geometric(self, alpha: float) -> int:
        """
        从双边几何分布采样
        
        Args:
            alpha: 分布参数
            
        Returns:
            采样的整数值
        """
        # 首先采样一个几何分布（正半部分）
        geo = np.random.geometric(1 - alpha) - 1
        
        # 然后以0.5概率取正或负
        sign = 1 if np.random.random() < 0.5 else -1
        
        return sign * geo