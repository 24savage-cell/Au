"""
指数机制实现

指数机制用于非数值型查询，从离散集合中选择输出。
它根据效用函数为每个候选输出分配概率，效用越高概率越大。

适用于：分类、选择、排序等非数值查询。
"""

import logging
import numpy as np
from typing import List, Tuple, Optional, Callable, Any, Union
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ExponentialMechanismResult:
    """指数机制结果"""
    selected_item: Any
    probability: float
    all_probabilities: dict


class ExponentialMechanism:
    """
    指数机制
    
    从候选集合中根据效用函数选择输出，提供差分隐私保护。
    
    选择概率：P[r] ∝ exp(ε * u(r) / (2 * Δu))
    
    其中：
    - u(r) 是候选r的效用
    - Δu 是效用函数的敏感度
    - ε 是隐私预算
    
    示例:
        >>> mechanism = ExponentialMechanism(epsilon=1.0)
        >>> 
        >>> # 定义效用函数
        >>> def utility(candidate, data):
        >>>     return -abs(candidate - np.mean(data))
        >>> 
        >>> candidates = [1, 2, 3, 4, 5]
        >>> data = [2.5, 3.5, 4.5]
        >>> 
        >>> result = mechanism.select(candidates, utility, data)
        >>> print(f"选中: {result}")
    """
    
    def __init__(self, epsilon: float = 1.0,
                 random_state: Optional[int] = None):
        """
        初始化指数机制
        
        Args:
            epsilon: 隐私预算参数
            random_state: 随机种子
        """
        if epsilon <= 0:
            raise ValueError("epsilon必须大于0")
        
        self.epsilon = epsilon
        self.random_state = random_state
        
        if random_state is not None:
            np.random.seed(random_state)
        
        logger.info(f"初始化指数机制: epsilon={epsilon}")
    
    def select(self, candidates: List[Any],
               utility_function: Callable[[Any, Any], float],
               data: Any,
               sensitivity: float = 1.0) -> ExponentialMechanismResult:
        """
        从候选集合中选择一项
        
        Args:
            candidates: 候选集合
            utility_function: 效用函数 u(candidate, data)
            data: 输入数据
            sensitivity: 效用函数敏感度
            
        Returns:
            ExponentialMechanismResult: 选择结果
        """
        if not candidates:
            raise ValueError("候选集合不能为空")
        
        # 计算每个候选的效用
        utilities = {}
        for candidate in candidates:
            try:
                utility = utility_function(candidate, data)
                utilities[candidate] = utility
            except Exception as e:
                logger.warning(f"计算候选 {candidate} 的效用失败: {e}")
                utilities[candidate] = float('-inf')
        
        # 计算概率（指数机制公式）
        # P[r] ∝ exp(ε * u(r) / (2 * Δu))
        probabilities = {}
        max_utility = max(utilities.values())
        
        # 使用数值稳定的计算
        exp_scores = {}
        for candidate, utility in utilities.items():
            # 减去最大值防止溢出
            normalized_utility = utility - max_utility
            score = (self.epsilon * normalized_utility) / (2 * sensitivity)
            exp_scores[candidate] = np.exp(score)
        
        # 归一化
        total = sum(exp_scores.values())
        for candidate in candidates:
            probabilities[candidate] = exp_scores[candidate] / total
        
        # 根据概率采样
        selected = np.random.choice(candidates, p=list(probabilities.values()))
        
        return ExponentialMechanismResult(
            selected_item=selected,
            probability=probabilities[selected],
            all_probabilities=probabilities
        )
    
    def select_top_k(self, candidates: List[Any],
                     utility_function: Callable[[Any, Any], float],
                     data: Any,
                     k: int,
                     sensitivity: float = 1.0,
                     with_replacement: bool = False) -> List[Any]:
        """
        选择Top-K项
        
        Args:
            candidates: 候选集合
            utility_function: 效用函数
            data: 输入数据
            k: 选择数量
            sensitivity: 敏感度
            with_replacement: 是否允许重复选择
            
        Returns:
            选中的Top-K项列表
        """
        if k <= 0:
            return []
        
        if k >= len(candidates) and not with_replacement:
            return candidates.copy()
        
        selected = []
        remaining = candidates.copy()
        
        for _ in range(k):
            if not remaining:
                break
            
            # 从剩余候选中选择
            result = self.select(remaining, utility_function, data, sensitivity)
            selected.append(result.selected_item)
            
            if not with_replacement:
                remaining.remove(result.selected_item)
        
        return selected
    
    def report_noisy_max(self, scores: List[float],
                         sensitivity: float = 1.0) -> int:
        """
        报告带噪声的最大值（Report Noisy Max）
        
        这是指数机制的特例，用于选择分数最高的索引。
        
        Args:
            scores: 分数列表
            sensitivity: 分数敏感度
            
        Returns:
            选中项的索引
        """
        candidates = list(range(len(scores)))
        
        def utility(idx, _):
            return scores[idx]
        
        result = self.select(candidates, utility, None, sensitivity)
        return result.selected_item
    
    def permute_and_flip(self, candidates: List[Any],
                         utility_function: Callable[[Any, Any], float],
                         data: Any,
                         sensitivity: float = 1.0) -> Any:
        """
        Permute-and-Flip机制
        
        指数机制的变体，在某些情况下提供更优的效用。
        
        Args:
            candidates: 候选集合
            utility_function: 效用函数
            data: 输入数据
            sensitivity: 敏感度
            
        Returns:
            选中的项
        """
        if not candidates:
            raise ValueError("候选集合不能为空")
        
        # 随机排列候选
        permuted = candidates.copy()
        np.random.shuffle(permuted)
        
        # 计算效用
        utilities = {c: utility_function(c, data) for c in permuted}
        max_utility = max(utilities.values())
        
        # 遍历排列后的候选
        for candidate in permuted:
            utility = utilities[candidate]
            gap = max_utility - utility
            
            # 以概率 exp(-ε * gap / (2 * sensitivity)) 接受
            prob = np.exp(-self.epsilon * gap / (2 * sensitivity))
            
            if np.random.random() < prob:
                return candidate
        
        # 如果没有接受任何候选，返回最后一个
        return permuted[-1]
    
    def get_selection_probability(self, candidate: Any,
                                   candidates: List[Any],
                                   utility_function: Callable,
                                   data: Any,
                                   sensitivity: float = 1.0) -> float:
        """
        计算特定候选被选中的概率
        
        Args:
            candidate: 目标候选
            candidates: 所有候选
            utility_function: 效用函数
            data: 输入数据
            sensitivity: 敏感度
            
        Returns:
            被选中的概率
        """
        utilities = {c: utility_function(c, data) for c in candidates}
        
        # 计算指数分数
        exp_scores = {}
        for c in candidates:
            score = (self.epsilon * utilities[c]) / (2 * sensitivity)
            exp_scores[c] = np.exp(score)
        
        total = sum(exp_scores.values())
        return exp_scores.get(candidate, 0) / total


class ExponentialMechanismWithQuality:
    """
    带质量阈值的指数机制
    
    只考虑效用超过阈值的候选。
    """
    
    def __init__(self, epsilon: float = 1.0,
                 quality_threshold: float = 0.0):
        """
        初始化
        
        Args:
            epsilon: 隐私预算
            quality_threshold: 质量阈值
        """
        self.epsilon = epsilon
        self.quality_threshold = quality_threshold
        self.base_mechanism = ExponentialMechanism(epsilon)
    
    def select(self, candidates: List[Any],
               utility_function: Callable[[Any, Any], float],
               data: Any,
               sensitivity: float = 1.0) -> Any:
        """
        从满足质量阈值的候选中选择
        
        Args:
            candidates: 候选集合
            utility_function: 效用函数
            data: 输入数据
            sensitivity: 敏感度
            
        Returns:
            选中的项
        """
        # 过滤满足阈值的候选
        qualified = []
        for candidate in candidates:
            utility = utility_function(candidate, data)
            if utility >= self.quality_threshold:
                qualified.append(candidate)
        
        if not qualified:
            # 如果没有满足的候选，从所有候选中选择
            qualified = candidates
        
        result = self.base_mechanism.select(
            qualified, utility_function, data, sensitivity
        )
        return result.selected_item