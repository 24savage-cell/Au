"""
拉普拉斯机制实现

拉普拉斯机制是差分隐私中最基本的机制，通过在查询结果中添加
拉普拉斯分布的噪声来实现隐私保护。

适用于数值型查询，提供严格的ε-差分隐私保证。
"""

import logging
import numpy as np
from typing import Union, List, Optional, Callable, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class SensitivityConfig:
    """敏感度配置"""
    l1_sensitivity: float  # L1敏感度
    l2_sensitivity: Optional[float] = None  # L2敏感度


class LaplaceMechanism:
    """
    拉普拉斯机制
    
    通过在查询结果中添加拉普拉斯噪声来实现ε-差分隐私。
    
    拉普拉斯分布的概率密度函数：
    f(x | b) = (1 / 2b) * exp(-|x| / b)
    
    其中 b = sensitivity / epsilon
    
    示例:
        >>> mechanism = LaplaceMechanism(epsilon=1.0)
        >>> data = [23, 45, 67, 89, 12]
        >>> 
        >>> # 计数查询
        >>> count = mechanism.count_query(data)
        >>> print(f"私有计数: {count}")
        >>> 
        >>> # 求和查询
        >>> total = mechanism.sum_query(data, lower_bound=0, upper_bound=100)
        >>> print(f"私有求和: {total}")
    """
    
    def __init__(self, epsilon: float = 1.0, 
                 delta: float = 0.0,
                 random_state: Optional[int] = None):
        """
        初始化拉普拉斯机制
        
        Args:
            epsilon: 隐私预算参数（越小隐私保护越强）
            delta: 松弛参数（通常为0，纯差分隐私）
            random_state: 随机种子
        """
        if epsilon <= 0:
            raise ValueError("epsilon必须大于0")
        
        self.epsilon = epsilon
        self.delta = delta
        self.random_state = random_state
        
        if random_state is not None:
            np.random.seed(random_state)
        
        logger.info(f"初始化拉普拉斯机制: epsilon={epsilon}, delta={delta}")
    
    def add_noise(self, value: float, sensitivity: float) -> float:
        """
        添加拉普拉斯噪声
        
        Args:
            value: 原始值
            sensitivity: 查询的敏感度
            
        Returns:
            添加噪声后的值
        """
        # 计算尺度参数 b = sensitivity / epsilon
        scale = sensitivity / self.epsilon
        
        # 从拉普拉斯分布采样噪声
        noise = np.random.laplace(loc=0.0, scale=scale)
        
        logger.debug(f"添加噪声: scale={scale}, noise={noise:.4f}")
        
        return value + noise
    
    def add_noise_vector(self, values: np.ndarray, 
                         sensitivity: float) -> np.ndarray:
        """
        为向量添加拉普拉斯噪声
        
        Args:
            values: 原始值向量
            sensitivity: L1敏感度
            
        Returns:
            添加噪声后的向量
        """
        scale = sensitivity / self.epsilon
        noise = np.random.laplace(loc=0.0, scale=scale, size=values.shape)
        
        return values + noise
    
    def count_query(self, data: List[Any]) -> float:
        """
        差分隐私计数查询
        
        计数的敏感度为1（添加/删除一个记录最多改变计数1）
        
        Args:
            data: 数据列表
            
        Returns:
            带噪声的计数
        """
        true_count = len(data)
        sensitivity = 1.0  # 计数查询的敏感度
        
        return self.add_noise(float(true_count), sensitivity)
    
    def sum_query(self, data: List[float], 
                  lower_bound: float,
                  upper_bound: float) -> float:
        """
        差分隐私求和查询
        
        使用裁剪（clipping）限制敏感度
        
        Args:
            data: 数值列表
            lower_bound: 下界（裁剪）
            upper_bound: 上界（裁剪）
            
        Returns:
            带噪声的求和结果
        """
        # 裁剪数据
        clipped_data = np.clip(data, lower_bound, upper_bound)
        
        # 计算真实求和
        true_sum = np.sum(clipped_data)
        
        # 敏感度 = upper_bound - lower_bound
        sensitivity = upper_bound - lower_bound
        
        return self.add_noise(true_sum, sensitivity)
    
    def mean_query(self, data: List[float],
                   lower_bound: float,
                   upper_bound: float) -> float:
        """
        差分隐私均值查询
        
        使用分解方法：mean = sum / count
        
        Args:
            data: 数值列表
            lower_bound: 下界
            upper_bound: 上界
            
        Returns:
            带噪声的均值
        """
        n = len(data)
        if n == 0:
            return 0.0
        
        # 私有求和
        private_sum = self.sum_query(data, lower_bound, upper_bound)
        
        # 私有计数
        private_count = self.count_query(data)
        
        # 确保计数为正
        private_count = max(private_count, 1.0)
        
        return private_sum / private_count
    
    def histogram_query(self, data: List[Any], 
                        bins: List[Any]) -> dict:
        """
        差分隐私直方图查询
        
        为每个分箱独立添加噪声
        
        Args:
            data: 数据列表
            bins: 分箱定义
            
        Returns:
            带噪声的直方图计数
        """
        # 计算每个分箱的计数
        histogram = {}
        for bin_val in bins:
            count = sum(1 for x in data if x == bin_val)
            # 为每个分箱添加噪声（敏感度为1）
            histogram[bin_val] = self.add_noise(float(count), 1.0)
        
        return histogram
    
    def report_noisy_max(self, scores: List[float],
                         sensitivity: float = 1.0) -> int:
        """
        报告带噪声的最大值（Report Noisy Max）
        
        选择分数最高的选项，使用拉普拉斯噪声
        
        Args:
            scores: 分数列表
            sensitivity: 分数函数的敏感度
            
        Returns:
            选中项的索引
        """
        # 为每个分数添加噪声
        noisy_scores = [
            self.add_noise(score, sensitivity) 
            for score in scores
        ]
        
        # 返回最大值的索引
        return int(np.argmax(noisy_scores))
    
    def sparse_vector_technique(self, queries: List[Callable],
                                threshold: float,
                                max_above_threshold: int,
                                sensitivity: float = 1.0) -> List[int]:
        """
        稀疏向量技术（Sparse Vector Technique）
        
        高效处理大量查询，只报告超过阈值的查询
        
        Args:
            queries: 查询函数列表
            threshold: 阈值
            max_above_threshold: 最多报告的查询数
            sensitivity: 查询敏感度
            
        Returns:
            超过阈值的查询索引列表
        """
        results = []
        
        # 为阈值添加噪声
        noisy_threshold = threshold + np.random.laplace(
            loc=0.0, 
            scale=(2 * sensitivity) / self.epsilon
        )
        
        # 处理每个查询
        for i, query in enumerate(queries):
            if len(results) >= max_above_threshold:
                break
            
            # 计算查询结果
            result = query()
            
            # 添加噪声
            noisy_result = result + np.random.laplace(
                loc=0.0,
                scale=(4 * max_above_threshold * sensitivity) / self.epsilon
            )
            
            # 检查是否超过阈值
            if noisy_result >= noisy_threshold:
                results.append(i)
        
        return results
    
    def get_privacy_parameters(self) -> dict:
        """
        获取隐私参数
        
        Returns:
            隐私参数字典
        """
        return {
            'epsilon': self.epsilon,
            'delta': self.delta,
            'mechanism': 'Laplace',
            'type': 'pure_dp' if self.delta == 0 else 'approx_dp'
        }


class VectorLaplaceMechanism:
    """
    向量拉普拉斯机制
    
    为高维数据添加拉普拉斯噪声。
    """
    
    def __init__(self, epsilon: float = 1.0, 
                 dimension: int = 1):
        """
        初始化向量拉普拉斯机制
        
        Args:
            epsilon: 隐私预算
            dimension: 数据维度
        """
        self.epsilon = epsilon
        self.dimension = dimension
        self.base_mechanism = LaplaceMechanism(epsilon)
    
    def add_noise(self, vector: np.ndarray, 
                  l1_sensitivity: float) -> np.ndarray:
        """
        为向量添加噪声
        
        Args:
            vector: 输入向量
            l1_sensitivity: L1敏感度
            
        Returns:
            带噪声的向量
        """
        # 对于k维数据，每维分配 epsilon/k 的预算
        per_dim_epsilon = self.epsilon / self.dimension
        
        scale = l1_sensitivity / per_dim_epsilon
        noise = np.random.laplace(loc=0.0, scale=scale, size=vector.shape)
        
        return vector + noise


class LaplaceMechanismWithAdaptiveBudget:
    """
    自适应预算拉普拉斯机制
    
    根据数据特性动态调整隐私预算分配。
    """
    
    def __init__(self, total_epsilon: float = 1.0,
                 num_queries: int = 1):
        """
        初始化自适应预算机制
        
        Args:
            total_epsilon: 总隐私预算
            num_queries: 查询数量
        """
        self.total_epsilon = total_epsilon
        self.num_queries = num_queries
        self.query_count = 0
    
    def get_epsilon_for_query(self) -> float:
        """
        获取当前查询的epsilon
        
        Returns:
            当前查询的隐私预算
        """
        # 简单的平均分配策略
        remaining_queries = self.num_queries - self.query_count
        if remaining_queries <= 0:
            return 0.0
        
        epsilon = self.total_epsilon / remaining_queries
        self.query_count += 1
        
        return epsilon
    
    def add_noise(self, value: float, sensitivity: float) -> float:
        """
        添加噪声（使用自适应预算）
        
        Args:
            value: 原始值
            sensitivity: 敏感度
            
        Returns:
            带噪声的值
        """
        epsilon = self.get_epsilon_for_query()
        if epsilon <= 0:
            raise ValueError("隐私预算已耗尽")
        
        mechanism = LaplaceMechanism(epsilon)
        return mechanism.add_noise(value, sensitivity)