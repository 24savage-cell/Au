"""
机器学习查询实现

差分隐私随机梯度下降（DP-SGD）实现。
"""

import logging
import numpy as np
from typing import List, Tuple, Optional, Callable, Any

logger = logging.getLogger(__name__)


class DP_SGD:
    """
    差分隐私随机梯度下降
    
    在SGD训练过程中添加噪声以实现差分隐私。
    
    示例:
        >>> dp_sgd = DP_SGD(
        ...     learning_rate=0.01,
        ...     noise_multiplier=1.1,
        ...     max_grad_norm=1.0,
        ...     batch_size=64
        ... )
        >>> 
        >>> # 训练模型
        >>> for epoch in range(10):
        ...     for batch in data_loader:
        ...         gradients = compute_gradients(model, batch)
        ...         dp_gradients = dp_sgd.clip_and_noise_gradients(gradients)
        ...         model.update(dp_gradients)
    """
    
    def __init__(self,
                 learning_rate: float = 0.01,
                 noise_multiplier: float = 1.1,
                 max_grad_norm: float = 1.0,
                 batch_size: int = 64,
                 epochs: int = 10):
        """
        初始化DP-SGD
        
        Args:
            learning_rate: 学习率
            noise_multiplier: 噪声乘数
            max_grad_norm: 梯度裁剪范数
            batch_size: 批次大小
            epochs: 训练轮数
        """
        self.learning_rate = learning_rate
        self.noise_multiplier = noise_multiplier
        self.max_grad_norm = max_grad_norm
        self.batch_size = batch_size
        self.epochs = epochs
        
        logger.info(f"初始化DP-SGD: lr={learning_rate}, "
                   f"noise_multiplier={noise_multiplier}, "
                   f"max_grad_norm={max_grad_norm}")
    
    def clip_gradients(self, gradients: np.ndarray) -> np.ndarray:
        """
        裁剪梯度
        
        Args:
            gradients: 梯度数组
            
        Returns:
            裁剪后的梯度
        """
        grad_norm = np.linalg.norm(gradients)
        
        if grad_norm > self.max_grad_norm:
            gradients = gradients * (self.max_grad_norm / grad_norm)
        
        return gradients
    
    def add_noise_to_gradients(self, 
                               gradients: np.ndarray,
                               num_samples: int) -> np.ndarray:
        """
        为梯度添加噪声
        
        Args:
            gradients: 梯度数组
            num_samples: 样本总数
            
        Returns:
            添加噪声后的梯度
        """
        # 计算噪声标准差
        # sigma = noise_multiplier * max_grad_norm / batch_size
        sigma = self.noise_multiplier * self.max_grad_norm / self.batch_size
        
        # 添加高斯噪声
        noise = np.random.normal(0, sigma, gradients.shape)
        
        # 缩放噪声以适应样本数
        noise = noise * num_samples / self.batch_size
        
        return gradients + noise
    
    def process_gradients(self, 
                         per_sample_gradients: List[np.ndarray],
                         num_samples: int) -> np.ndarray:
        """
        处理梯度（裁剪并添加噪声）
        
        Args:
            per_sample_gradients: 每个样本的梯度列表
            num_samples: 样本总数
            
        Returns:
            处理后的平均梯度
        """
        # 裁剪每个样本的梯度
        clipped_grads = [self.clip_gradients(g) for g in per_sample_gradients]
        
        # 计算平均梯度
        avg_gradient = np.mean(clipped_grads, axis=0)
        
        # 添加噪声
        noisy_gradient = self.add_noise_to_gradients(avg_gradient, num_samples)
        
        return noisy_gradient
    
    def compute_epsilon(self, 
                       num_samples: int,
                       target_delta: float = 1e-5) -> float:
        """
        计算隐私预算epsilon
        
        使用简化公式估算epsilon。
        
        Args:
            num_samples: 样本总数
            target_delta: 目标delta
            
        Returns:
            隐私预算epsilon
        """
        # 简化的epsilon计算
        # 实际应使用更精确的会计方法
        steps = self.epochs * (num_samples // self.batch_size)
        
        # 基于噪声乘数估算
        epsilon = steps * self.noise_multiplier / np.sqrt(num_samples)
        
        return epsilon


class PrivateSGD:
    """
    私有SGD（简化接口）
    
    提供更易用的DP-SGD接口。
    """
    
    def __init__(self,
                 model: Any,
                 epsilon: float = 1.0,
                 delta: float = 1e-5,
                 learning_rate: float = 0.01,
                 max_grad_norm: float = 1.0):
        """
        初始化私有SGD
        
        Args:
            model: 模型对象
            epsilon: 隐私预算
            delta: 松弛参数
            learning_rate: 学习率
            max_grad_norm: 最大梯度范数
        """
        self.model = model
        self.epsilon = epsilon
        self.delta = delta
        self.learning_rate = learning_rate
        self.max_grad_norm = max_grad_norm
        
        # 计算噪声乘数
        self.noise_multiplier = self._compute_noise_multiplier()
        
        logger.info(f"初始化PrivateSGD: ε={epsilon}, δ={delta}")
    
    def _compute_noise_multiplier(self) -> float:
        """计算噪声乘数"""
        # 简化的计算
        return 1.0 / self.epsilon
    
    def train_step(self, 
                  X: np.ndarray,
                  y: np.ndarray,
                  loss_fn: Callable,
                  grad_fn: Callable) -> float:
        """
        执行一步训练
        
        Args:
            X: 输入特征
            y: 标签
            loss_fn: 损失函数
            grad_fn: 梯度函数
            
        Returns:
            损失值
        """
        # 计算损失和梯度
        loss = loss_fn(self.model, X, y)
        gradients = grad_fn(self.model, X, y)
        
        # 裁剪梯度
        grad_norm = np.linalg.norm(gradients)
        if grad_norm > self.max_grad_norm:
            gradients = gradients * (self.max_grad_norm / grad_norm)
        
        # 添加噪声
        noise = np.random.normal(0, self.noise_multiplier * self.max_grad_norm, gradients.shape)
        noisy_gradients = gradients + noise
        
        # 更新模型
        self.model -= self.learning_rate * noisy_gradients
        
        return loss
