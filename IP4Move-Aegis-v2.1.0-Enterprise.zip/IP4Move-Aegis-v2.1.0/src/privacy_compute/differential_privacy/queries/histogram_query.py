"""
直方图查询实现

差分隐私直方图查询，为每个分箱添加噪声。
"""

import logging
import numpy as np
from typing import List, Any, Optional, Callable, Dict

logger = logging.getLogger(__name__)


class HistogramQuery:
    """
    差分隐私直方图查询
    
    为每个分箱独立添加噪声。
    
    示例:
        >>> from ..mechanisms.laplace import LaplaceMechanism
        >>> mechanism = LaplaceMechanism(epsilon=1.0)
        >>> query = HistogramQuery(mechanism)
        >>> 
        >>> data = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4]
        >>> histogram = query.execute(data, bins=[1, 2, 3, 4])
        >>> print(f"直方图: {histogram}")
    """
    
    def __init__(self, mechanism: Any):
        """
        初始化直方图查询
        
        Args:
            mechanism: 差分隐私机制
        """
        self.mechanism = mechanism
        logger.info("初始化直方图查询")
    
    def execute(self, data: List[Any], 
                bins: List[Any],
                bin_func: Optional[Callable[[Any], Any]] = None) -> Dict[Any, float]:
        """
        执行直方图查询
        
        Args:
            data: 数据列表
            bins: 分箱列表
            bin_func: 分箱函数（可选）
            
        Returns:
            带噪声的直方图
        """
        if bin_func is None:
            bin_func = lambda x: x
        
        # 计算每个分箱的计数
        histogram = {}
        for bin_val in bins:
            count = sum(1 for x in data if bin_func(x) == bin_val)
            # 为每个分箱添加噪声（敏感度为1）
            histogram[bin_val] = self.mechanism.add_noise(float(count), sensitivity=1.0)
        
        return histogram
    
    def execute_range(self, data: List[float],
                      num_bins: int,
                      min_val: Optional[float] = None,
                      max_val: Optional[float] = None) -> Dict[str, float]:
        """
        范围直方图查询
        
        Args:
            data: 数值列表
            num_bins: 分箱数量
            min_val: 最小值（可选）
            max_val: 最大值（可选）
            
        Returns:
            带噪声的范围直方图
        """
        if min_val is None:
            min_val = min(data)
        if max_val is None:
            max_val = max(data)
        
        # 创建等宽分箱
        bin_width = (max_val - min_val) / num_bins
        bins = [min_val + i * bin_width for i in range(num_bins)]
        
        # 分箱函数
        def bin_func(x):
            if x >= max_val:
                return num_bins - 1
            return int((x - min_val) / bin_width)
        
        # 计算直方图
        histogram = {}
        for i in range(num_bins):
            bin_start = min_val + i * bin_width
            bin_end = bin_start + bin_width
            count = sum(1 for x in data if bin_start <= x < bin_end)
            
            # 最后一个分箱包含最大值
            if i == num_bins - 1:
                count = sum(1 for x in data if bin_start <= x <= max_val)
            
            histogram[f"{bin_start:.2f}-{bin_end:.2f}"] = self.mechanism.add_noise(
                float(count), sensitivity=1.0
            )
        
        return histogram
    
    def execute_2d(self, data: List[tuple],
                   x_bins: List[Any],
                   y_bins: List[Any]) -> Dict[tuple, float]:
        """
        二维直方图查询
        
        Args:
            data: (x, y)元组列表
            x_bins: x轴分箱
            y_bins: y轴分箱
            
        Returns:
            带噪声的二维直方图
        """
        histogram = {}
        
        for x_bin in x_bins:
            for y_bin in y_bins:
                count = sum(1 for x, y in data if x == x_bin and y == y_bin)
                histogram[(x_bin, y_bin)] = self.mechanism.add_noise(
                    float(count), sensitivity=1.0
                )
        
        return histogram
