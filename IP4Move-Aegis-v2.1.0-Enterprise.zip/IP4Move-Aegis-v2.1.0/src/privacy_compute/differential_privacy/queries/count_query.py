"""
计数查询实现

差分隐私计数查询，用于统计满足条件的记录数。
"""

import logging
from typing import List, Any, Optional, Callable

logger = logging.getLogger(__name__)


class CountQuery:
    """
    差分隐私计数查询
    
    用于统计满足条件的记录数量。
    
    示例:
        >>> from ..mechanisms.laplace import LaplaceMechanism
        >>> mechanism = LaplaceMechanism(epsilon=1.0)
        >>> query = CountQuery(mechanism)
        >>> 
        >>> data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        >>> count = query.execute(data, condition=lambda x: x > 5)
        >>> print(f"大于5的元素数量: {count}")
    """
    
    def __init__(self, mechanism: Any):
        """
        初始化计数查询
        
        Args:
            mechanism: 差分隐私机制（如LaplaceMechanism）
        """
        self.mechanism = mechanism
        logger.info("初始化计数查询")
    
    def execute(self, data: List[Any], 
                condition: Optional[Callable[[Any], bool]] = None) -> float:
        """
        执行计数查询
        
        Args:
            data: 数据列表
            condition: 过滤条件函数
            
        Returns:
            带噪声的计数
        """
        if condition is None:
            true_count = len(data)
        else:
            true_count = sum(1 for x in data if condition(x))
        
        # 添加噪声
        return self.mechanism.add_noise(float(true_count), sensitivity=1.0)
    
    def execute_groupby(self, data: List[Any], 
                        group_key: Callable[[Any], Any]) -> dict:
        """
        分组计数查询
        
        Args:
            data: 数据列表
            group_key: 分组键函数
            
        Returns:
            各组的带噪声计数
        """
        # 分组
        groups = {}
        for item in data:
            key = group_key(item)
            if key not in groups:
                groups[key] = 0
            groups[key] += 1
        
        # 为每组添加噪声
        result = {}
        for key, count in groups.items():
            result[key] = self.mechanism.add_noise(float(count), sensitivity=1.0)
        
        return result
