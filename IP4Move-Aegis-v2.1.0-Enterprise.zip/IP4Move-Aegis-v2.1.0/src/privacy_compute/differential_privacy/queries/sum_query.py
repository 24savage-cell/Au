"""
求和查询实现

差分隐私求和查询，支持裁剪策略限制敏感度。
"""

import logging
import numpy as np
from typing import List, Optional, Callable, Any

logger = logging.getLogger(__name__)


class SumQuery:
    """
    差分隐私求和查询
    
    支持数据裁剪以限制敏感度。
    
    示例:
        >>> from ..mechanisms.laplace import LaplaceMechanism
        >>> mechanism = LaplaceMechanism(epsilon=1.0)
        >>> query = SumQuery(mechanism, lower_bound=0, upper_bound=100)
        >>> 
        >>> data = [23, 45, 67, 89, 12]
        >>> total = query.execute(data)
        >>> print(f"私有求和: {total}")
    """
    
    def __init__(self, mechanism: Any,
                 lower_bound: float,
                 upper_bound: float):
        """
        初始化求和查询
        
        Args:
            mechanism: 差分隐私机制
            lower_bound: 数据下界（裁剪）
            upper_bound: 数据上界（裁剪）
        """
        self.mechanism = mechanism
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound
        self.sensitivity = upper_bound - lower_bound
        
        logger.info(f"初始化求和查询: 范围=[{lower_bound}, {upper_bound}], "
                   f"敏感度={self.sensitivity}")
    
    def execute(self, data: List[float],
                weights: Optional[List[float]] = None) -> float:
        """
        执行求和查询
        
        Args:
            data: 数值列表
            weights: 权重列表（可选）
            
        Returns:
            带噪声的求和结果
        """
        # 裁剪数据
        clipped_data = np.clip(data, self.lower_bound, self.upper_bound)
        
        # 加权求和
        if weights is not None:
            if len(weights) != len(data):
                raise ValueError("权重数量与数据数量不匹配")
            true_sum = np.sum(clipped_data * np.array(weights))
            # 调整敏感度
            max_weight = max(abs(w) for w in weights)
            sensitivity = self.sensitivity * max_weight
        else:
            true_sum = np.sum(clipped_data)
            sensitivity = self.sensitivity
        
        # 添加噪声
        return self.mechanism.add_noise(float(true_sum), sensitivity)
    
    def execute_groupby(self, data: List[Any],
                        value_func: Callable[[Any], float],
                        group_key: Callable[[Any], Any]) -> dict:
        """
        分组求和查询
        
        Args:
            data: 数据列表
            value_func: 提取数值的函数
            group_key: 分组键函数
            
        Returns:
            各组的带噪声求和
        """
        # 分组求和
        groups = {}
        for item in data:
            key = group_key(item)
            value = np.clip(value_func(item), self.lower_bound, self.upper_bound)
            
            if key not in groups:
                groups[key] = 0.0
            groups[key] += value
        
        # 为每组添加噪声
        result = {}
        for key, sum_val in groups.items():
            result[key] = self.mechanism.add_noise(sum_val, self.sensitivity)
        
        return result
