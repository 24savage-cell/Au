/*
 * IP4Move-Aegis XDP 线速流量拦截引擎
 * 内核态 eBPF/XDP 数据包过滤与攻击特征匹配
 *
 * 功能:
 *  1. 基于 BPF Map 的 IP 黑名单实时过滤
 *  2. 基于包大小/协议的攻击特征匹配
 *  3. 每源速率限制 (PPS/BPS)
 *  4. 攻击指纹匹配 (tagging/replay 检测)
 *  5. 统计计数器 (per-CPU, 线速无锁)
 *  6. 与用户态联动的事件上报
 *
 * 编译: make -C src/xdp_engine/
 * 加载: 通过 Python 控制面 xdp_controller.py 加载
 */

#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <linux/in.h>
#include <linux/pkt_cls.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>

/* ============================================================
 * 常量定义
 * ============================================================ */

#define MAX_BANNED_IPS        65536   /* IP 黑名单最大容量 */
#define MAX_RATE_LIMITERS     65536   /* 速率限制器最大容量 */
#define MAX_FINGERPRINTS      4096    /* 攻击指纹最大容量 */
#define RATE_LIMIT_WINDOW_NS  1000000000ULL  /* 1秒窗口 (纳秒) */
#define FLOOD_PPS_THRESHOLD   1000    /* 洪水攻击 PPS 阈值 */
#define FLOOD_BPS_THRESHOLD   (100 * 1024 * 1024ULL)  /* 100MB/s 阈值 */
#define MIN_PKT_SIZE_FOR_TAG  20      /* 标记攻击最小包大小 */
#define TAG_CHUNK_SIZE        16      /* 标记攻击分块大小 */
#define TAG_MAX_CHUNKS        100     /* 标记攻击最大分块数 */
#define REPLAY_HASH_SEED      0xAEGIS /* 重放检测哈希种子 */

/* ============================================================
 * BPF Map 定义
 * ============================================================ */

/*
 * IP 黑名单 Map
 * key:   __u32 (IPv4 地址, network byte order)
 * value: __u64 (封禁过期时间, unix timestamp, 0=永久)
 * type:  HASH, 用于 O(1) 查找
 */
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, MAX_BANNED_IPS);
    __type(key, __u32);
    __type(value, __u64);
    __uint(pinning, LIBBPF_PIN_BY_NAME);
} banned_ips SEC(".maps");

/*
 * 每源速率限制 Map
 * key:   __u32 (源 IP 地址)
 * value: struct rate_limit_data (包计数 + 字节计数 + 窗口起始时间)
 * type:  PERCPU_HASH, 无锁 per-CPU 计数
 */
struct rate_limit_data {
    __u64 packets;
    __u64 bytes;
    __u64 window_start;
};

struct {
    __uint(type, BPF_MAP_TYPE_PERCPU_HASH);
    __uint(max_entries, MAX_RATE_LIMITERS);
    __type(key, __u32);
    __type(value, struct rate_limit_data);
    __uint(pinning, LIBBPF_PIN_BY_NAME);
} rate_limits SEC(".maps");

/*
 * 攻击指纹 Map (用于标记攻击/重放检测)
 * key:   struct fingerprint_key (源IP + 包特征哈希)
 * value: __u64 (首次发现时间戳)
 * type:  LRU_HASH, 自动淘汰旧条目
 */
struct fingerprint_key {
    __u32 src_ip;
    __u32 feature_hash;
};

struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, MAX_FINGERPRINTS);
    __type(key, struct fingerprint_key);
    __type(value, __u64);
    __uint(pinning, LIBBPF_PIN_BY_NAME);
} attack_fingerprints SEC(".maps");

/*
 * 全局配置 Map
 * key:   __u32 (配置项 ID)
 * value: __u64 (配置值)
 */
#define CONFIG_FLOOD_PPS       0
#define CONFIG_FLOOD_BPS       1
#define CONFIG_MODE            2  /* 0=pass, 1=learn, 2=enforce */
#define CONFIG_TAG_THRESHOLD   3  /* 标记攻击重复率阈值 (0-100) */

struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 16);
    __type(key, __u32);
    __type(value, __u64);
    __uint(pinning, LIBBPF_PIN_BY_NAME);
} xdp_config SEC(".maps");

/*
 * 统计计数器 Map (per-CPU)
 * key:   __u32 (统计类型)
 * value: __u64 (计数)
 */
#define STAT_TOTAL_PACKETS     0
#define STAT_DROPPED_PACKETS   1
#define STAT_BANNED_IP_DROPS   2
#define STAT_FLOOD_DROPS       3
#define STAT_TAGGING_DROPS     4
#define STAT_REPLAY_DROPS      5
#define STAT_PASS_PACKETS      6

struct {
    __uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 32);
    __type(key, __u32);
    __type(value, __u64);
    __uint(pinning, LIBBPF_PIN_BY_NAME);
} xdp_stats SEC(".maps");

/*
 * 事件上报 Map (ring buffer, 内核态 -> 用户态)
 * 用于将检测到的攻击事件发送到用户态
 */
struct xdp_event {
    __u64 timestamp;
    __u32 src_ip;
    __u32 dst_ip;
    __u16 src_port;
    __u16 dst_port;
    __u8  protocol;
    __u8  event_type;  /* 1=banned, 2=flood, 3=tagging, 4=replay */
    __u32 pkt_size;
    __u32 feature_hash;
};

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024);  /* 256KB ring buffer */
} events SEC(".maps");

/* ============================================================
 * 辅助函数
 * ============================================================ */

static __always_inline void increment_stat(__u32 stat_id)
{
    __u64 *count = bpf_map_lookup_elem(&xdp_stats, &stat_id);
    if (count)
        __sync_fetch_and_add(count, 1);
}

static __always_inline __u64 get_config(__u32 config_id)
{
    __u64 *val = bpf_map_lookup_elem(&xdp_config, &config_id);
    return val ? *val : 0;
}

/*
 * 简单的包特征哈希 (FNV-1a 变体)
 * 用于标记攻击和重放检测
 */
static __always_inline __u32 pkt_feature_hash(struct __sk_buff *skb, __u32 offset, __u32 len)
{
    __u32 hash = 2166136261U;  /* FNV offset basis */
    __u8 buf[64];
    __u32 i, remaining = len;

    #pragma unroll
    for (i = 0; i < 64 && i < remaining && i < 256; i++) {
        buf[i] = 0;
    }

    /* 限制读取长度 */
    if (remaining > 256)
        remaining = 256;

    /* 分块读取包数据 */
    #pragma unroll
    for (i = 0; i < 4; i++) {
        __u32 read_len = (remaining > 64) ? 64 : remaining;
        if (read_len == 0)
            break;
        bpf_skb_load_bytes(skb, offset + i * 64, buf, read_len);
        #pragma unroll
        for (__u32 j = 0; j < read_len && j < 64; j++) {
            hash ^= buf[j];
            hash *= 16777619U;  /* FNV prime */
        }
        remaining -= read_len;
    }

    return hash;
}

/*
 * 检查 IP 是否在黑名单中
 * 返回: 1=已封禁, 0=未封禁
 */
static __always_inline int is_ip_banned(__u32 ip)
{
    __u64 *expiry = bpf_map_lookup_elem(&banned_ips, &ip);
    if (!expiry)
        return 0;

    if (*expiry == 0)
        return 1;  /* 永久封禁 */

    __u64 now = bpf_ktime_get_ns() / 1000000000ULL;
    if (now < *expiry)
        return 1;

    /* 封禁已过期, 删除条目 */
    bpf_map_delete_elem(&banned_ips, &ip);
    return 0;
}

/*
 * 检查并更新速率限制
 * 返回: 1=超限应丢弃, 0=正常通过
 */
static __always_inline int check_rate_limit(__u32 src_ip, __u32 pkt_size)
{
    struct rate_limit_data zero = {};
    struct rate_limit_data *data;
    __u64 now = bpf_ktime_get_ns();
    __u64 pps_threshold = get_config(CONFIG_FLOOD_PPS);
    __u64 bps_threshold = get_config(CONFIG_FLOOD_BPS);

    if (pps_threshold == 0)
        pps_threshold = FLOOD_PPS_THRESHOLD;
    if (bps_threshold == 0)
        bps_threshold = FLOOD_BPS_THRESHOLD;

    data = bpf_map_lookup_elem(&rate_limits, &src_ip);
    if (!data) {
        bpf_map_update_elem(&rate_limits, &src_ip, &zero, BPF_ANY);
        data = bpf_map_lookup_elem(&rate_limits, &src_ip);
        if (!data)
            return 0;
    }

    /* 检查窗口是否过期 */
    if (now - data->window_start >= RATE_LIMIT_WINDOW_NS) {
        data->packets = 0;
        data->bytes = 0;
        data->window_start = now;
    }

    data->packets++;
    data->bytes += pkt_size;

    /* PPS 检查 */
    if (data->packets > pps_threshold)
        return 1;

    /* BPS 检查 */
    if (data->bytes > bps_threshold)
        return 1;

    return 0;
}

/*
 * 标记攻击检测
 * 检查包内是否存在高重复率的固定大小分块
 * 返回: 1=检测到标记攻击, 0=正常
 */
static __always_inline int detect_tagging(struct __sk_buff *skb, __u32 payload_offset, __u32 pkt_size)
{
    __u8 chunks[TAG_CHUNK_SIZE];
    __u32 hash_count = 0;
    __u32 duplicate_count = 0;
    __u32 offset = payload_offset;
    __u32 total_chunks = 0;
    __u32 threshold = get_config(CONFIG_TAG_THRESHOLD);

    if (threshold == 0)
        threshold = 50;  /* 默认 50% */

    if (pkt_size < MIN_PKT_SIZE_FOR_TAG)
        return 0;

    /* 限制检查范围 */
    __u32 max_check = pkt_size - offset;
    if (max_check > TAG_CHUNK_SIZE * TAG_MAX_CHUNKS)
        max_check = TAG_CHUNK_SIZE * TAG_MAX_CHUNKS;

    /* 使用简单的哈希来检测重复分块 (BPF 中无法使用复杂容器) */
    __u32 seen_hashes[32] = {};
    __u32 seen_count = 0;

    #pragma unroll
    for (__u32 i = 0; i < TAG_MAX_CHUNKS && offset + TAG_CHUNK_SIZE <= payload_offset + max_check; i++) {
        if (bpf_skb_load_bytes(skb, offset, chunks, TAG_CHUNK_SIZE) < 0)
            break;

        /* 计算分块哈希 */
        __u32 chunk_hash = 0;
        #pragma unroll
        for (__u32 j = 0; j < TAG_CHUNK_SIZE; j++) {
            chunk_hash = (chunk_hash * 31 + chunks[j]) & 0xFFFFFF;
        }

        /* 检查是否已见过此哈希 */
        #pragma unroll
        for (__u32 k = 0; k < 32 && k < seen_count; k++) {
            if (seen_hashes[k] == chunk_hash) {
                duplicate_count++;
                break;
            }
        }

        if (seen_count < 32) {
            seen_hashes[seen_count] = chunk_hash;
            seen_count++;
        }

        hash_count++;
        offset += TAG_CHUNK_SIZE;
        total_chunks++;
    }

    if (total_chunks < 3)
        return 0;

    /* 计算重复率 */
    __u32 repetition_rate = (duplicate_count * 100) / total_chunks;
    return repetition_rate > threshold;
}

/*
 * 重放攻击检测 (基于包特征哈希)
 * 返回: 1=检测到重放, 0=正常
 */
static __always_inline int detect_replay(struct __sk_buff *skb, __u32 src_ip, __u32 payload_offset, __u32 pkt_size)
{
    struct fingerprint_key fkey = {};
    __u32 fhash;

    /* 计算包特征哈希 (前256字节) */
    fhash = pkt_feature_hash(skb, payload_offset, pkt_size);

    fkey.src_ip = src_ip;
    fkey.feature_hash = fhash;

    /* 检查是否已存在 */
    __u64 *existing = bpf_map_lookup_elem(&attack_fingerprints, &fkey);
    if (existing)
        return 1;  /* 重放! */

    /* 记录新指纹 */
    __u64 now = bpf_ktime_get_ns() / 1000000000ULL;
    bpf_map_update_elem(&attack_fingerprints, &fkey, &now, BPF_ANY);

    return 0;
}

/*
 * 上报事件到用户态 (通过 ring buffer)
 */
static __always_inline void submit_event(
    __u8 event_type, __u32 src_ip, __u32 dst_ip,
    __u16 src_port, __u16 dst_port, __u8 protocol,
    __u32 pkt_size, __u32 feature_hash)
{
    struct xdp_event *e;

    e = bpf_ringbuf_reserve(&events, sizeof(*e), 0);
    if (!e)
        return;

    e->timestamp = bpf_ktime_get_ns();
    e->src_ip = src_ip;
    e->dst_ip = dst_ip;
    e->src_port = src_port;
    e->dst_port = dst_port;
    e->protocol = protocol;
    e->event_type = event_type;
    e->pkt_size = pkt_size;
    e->feature_hash = feature_hash;

    bpf_ringbuf_submit(e, 0);
}

/* ============================================================
 * XDP 主程序
 * ============================================================ */

SEC("xdp")
int aegis_xdp_prog(struct xdp_md *ctx)
{
    void *data_end = (void *)(long)ctx->data_end;
    void *data = (void *)(long)ctx->data;
    struct ethhdr *eth;
    struct iphdr *ip;
    __u32 src_ip, dst_ip;
    __u16 src_port = 0, dst_port = 0;
    __u8 protocol;
    __u32 pkt_size = data_end - data;
    __u32 mode;
    __u32 payload_offset;
    int action = XDP_PASS;

    /* 统计总包数 */
    increment_stat(STAT_TOTAL_PACKETS);

    /* 解析以太网头 */
    eth = (struct ethhdr *)data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;

    /* 仅处理 IPv4 */
    if (eth->h_proto != bpf_htons(ETH_P_IP))
        return XDP_PASS;

    /* 解析 IP 头 */
    ip = (struct iphdr *)(eth + 1);
    if ((void *)(ip + 1) > data_end)
        return XDP_PASS;

    src_ip = ip->saddr;
    dst_ip = ip->daddr;
    protocol = ip->protocol;
    payload_offset = sizeof(struct ethhdr) + (ip->ihl * 4);

    /* 解析传输层端口 */
    if (protocol == IPPROTO_TCP) {
        struct tcphdr *tcp = (struct tcphdr *)((void *)ip + (ip->ihl * 4));
        if ((void *)(tcp + 1) <= data_end) {
            src_port = tcp->source;
            dst_port = tcp->dest;
        }
    } else if (protocol == IPPROTO_UDP) {
        struct udphdr *udp = (struct udphdr *)((void *)ip + (ip->ihl * 4));
        if ((void *)(udp + 1) <= data_end) {
            src_port = udp->source;
            dst_port = udp->dest;
        }
    }

    /* 获取运行模式 */
    mode = get_config(CONFIG_MODE);

    /* ---- 检查 1: IP 黑名单 ---- */
    if (is_ip_banned(src_ip)) {
        increment_stat(STAT_BANNED_IP_DROPS);
        increment_stat(STAT_DROPPED_PACKETS);
        submit_event(1, src_ip, dst_ip, src_port, dst_port, protocol, pkt_size, 0);
        if (mode == 2)
            return XDP_DROP;
    }

    /* ---- 检查 2: 速率限制 (洪水攻击) ---- */
    if (check_rate_limit(src_ip, pkt_size)) {
        increment_stat(STAT_FLOOD_DROPS);
        increment_stat(STAT_DROPPED_PACKETS);
        submit_event(2, src_ip, dst_ip, src_port, dst_port, protocol, pkt_size, 0);
        if (mode == 2)
            return XDP_DROP;
    }

    /* ---- 检查 3: 标记攻击检测 ---- */
    if (detect_tagging(ctx->data, payload_offset, pkt_size)) {
        increment_stat(STAT_TAGGING_DROPS);
        increment_stat(STAT_DROPPED_PACKETS);
        __u32 fhash = pkt_feature_hash(ctx->data, payload_offset, pkt_size);
        submit_event(3, src_ip, dst_ip, src_port, dst_port, protocol, pkt_size, fhash);
        if (mode == 2)
            return XDP_DROP;
    }

    /* ---- 检查 4: 重放攻击检测 ---- */
    if (detect_replay(ctx->data, src_ip, payload_offset, pkt_size)) {
        increment_stat(STAT_REPLAY_DROPS);
        increment_stat(STAT_DROPPED_PACKETS);
        __u32 fhash = pkt_feature_hash(ctx->data, payload_offset, pkt_size);
        submit_event(4, src_ip, dst_ip, src_port, dst_port, protocol, pkt_size, fhash);
        if (mode == 2)
            return XDP_DROP;
    }

    /* 通过所有检查 */
    increment_stat(STAT_PASS_PACKETS);
    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
