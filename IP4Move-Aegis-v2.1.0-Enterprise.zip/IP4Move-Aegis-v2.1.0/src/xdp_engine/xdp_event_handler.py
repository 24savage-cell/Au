"""
XDP 事件处理器

将 XDP 内核事件与 attack_detector 联动, 实现:
1. 自动提取攻击指纹
2. 触发 attack_detector 的检测逻辑
3. 同步到全网免疫系统
"""

import logging
from typing import Optional, Callable, List
from dataclasses import dataclass
from datetime import datetime

from src.xdp_engine.xdp_controller import XDPController, XDPEvent, EventType
from src.security.attack_detector import AttackDetector, AttackAlert, AttackType

logger = logging.getLogger(__name__)


@dataclass
class XDPEventContext:
    """XDP 事件上下文"""
    event: XDPEvent
    alert: Optional[AttackAlert] = None
    fingerprint: Optional[dict] = None
    synced_to_network: bool = False


class XDPEventHandler:
    """
    XDP 事件处理器

    桥接 XDP 内核态检测和 attack_detector 用户态检测,
    实现完整的攻击检测-响应-同步链路。
    """

    def __init__(
        self,
        xdp_controller: XDPController,
        attack_detector: Optional[AttackDetector] = None,
        enable_auto_ban: bool = True,
        enable_fingerprint_sync: bool = True,
    ):
        """
        初始化事件处理器

        Args:
            xdp_controller: XDP 控制器实例
            attack_detector: 攻击检测器实例 (可选)
            enable_auto_ban: 是否自动封禁检测到的攻击源
            enable_fingerprint_sync: 是否同步攻击指纹到全网
        """
        self._xdp = xdp_controller
        self._detector = attack_detector
        self._enable_auto_ban = enable_auto_ban
        self._enable_fingerprint_sync = enable_fingerprint_sync

        # 回调
        self._fingerprint_callbacks: List[Callable[[dict], None]] = []

        # 注册事件回调
        self._xdp.register_event_callback(self._on_xdp_event)

        logger.info("XDPEventHandler 初始化完成")

    def register_fingerprint_callback(self, callback: Callable[[dict], None]) -> None:
        """注册攻击指纹回调 (用于同步到全网)"""
        self._fingerprint_callbacks.append(callback)

    def _on_xdp_event(self, event: Optional[XDPEvent]) -> None:
        """处理 XDP 内核事件"""
        if event is None:
            return

        logger.debug(f"收到 XDP 事件: type={event.event_type}, src={event.src_ip}")

        # 1. 提取攻击指纹
        fingerprint = self._extract_fingerprint(event)

        # 2. 如果启用了 attack_detector, 通知它
        if self._detector:
            self._notify_detector(event, fingerprint)

        # 3. 自动封禁 (如果启用)
        if self._enable_auto_ban:
            self._auto_ban(event)

        # 4. 同步攻击指纹到全网
        if self._enable_fingerprint_sync and fingerprint:
            self._sync_fingerprint(fingerprint)

    def _extract_fingerprint(self, event: XDPEvent) -> Optional[dict]:
        """
        从 XDP 事件提取攻击指纹

        指纹包含:
        - 攻击类型
        - 源 IP/端口
        - 目标 IP/端口
        - 协议
        - 包特征哈希
        - 时间戳
        """
        # 映射事件类型到攻击类型
        attack_type_map = {
            EventType.BANNED_IP: "banned_ip",
            EventType.FLOOD: "flooding",
            EventType.TAGGING: "tagging",
            EventType.REPLAY: "replay",
        }

        fingerprint = {
            "type": attack_type_map.get(event.event_type, "unknown"),
            "src_ip": event.src_ip,
            "src_port": event.src_port,
            "dst_ip": event.dst_ip,
            "dst_port": event.dst_port,
            "protocol": event.protocol,
            "feature_hash": event.feature_hash,
            "pkt_size": event.pkt_size,
            "timestamp": event.timestamp,
            "version": 1,
        }

        return fingerprint

    def _notify_detector(self, event: XDPEvent, fingerprint: Optional[dict]) -> None:
        """通知 attack_detector"""
        if not self._detector:
            return

        try:
            # 构造模拟数据包 (用于 detector 的 observe_packet)
            # 这里简化处理, 实际应该根据事件类型构造合适的数据
            mock_data = b"XDP_EVENT:" + str(event.feature_hash).encode()

            # 调用 detector
            alert = self._detector.observe_packet(
                data=mock_data,
                source=event.src_ip
            )

            if alert:
                logger.info(f"AttackDetector 检测到攻击: {alert.attack_type.value}")

        except Exception as e:
            logger.error(f"通知 AttackDetector 失败: {e}")

    def _auto_ban(self, event: XDPEvent) -> None:
        """自动封禁攻击源"""
        try:
            # 根据事件类型决定封禁时长
            ban_duration = {
                EventType.BANNED_IP: 0,      # 永久
                EventType.FLOOD: 3600,       # 1小时
                EventType.TAGGING: 7200,     # 2小时
                EventType.REPLAY: 1800,      # 30分钟
            }.get(event.event_type, 3600)

            # 调用 XDP 封禁
            self._xdp.ban_ip(event.src_ip, duration=ban_duration)

            logger.info(f"自动封禁攻击源: {event.src_ip} (时长: {ban_duration}s)")

        except Exception as e:
            logger.error(f"自动封禁失败: {e}")

    def _sync_fingerprint(self, fingerprint: dict) -> None:
        """同步攻击指纹到全网"""
        for callback in self._fingerprint_callbacks:
            try:
                callback(fingerprint)
            except Exception as e:
                logger.error(f"指纹同步回调错误: {e}")

    async def close(self) -> None:
        """关闭处理器"""
        self._xdp.unregister_event_callback(self._on_xdp_event)
        logger.info("XDPEventHandler 已关闭")
