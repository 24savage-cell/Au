"""
XDP 控制器 - Python 用户态控制面

功能:
  1. 加载/卸载 eBPF/XDP 程序到网卡
  2. 管理 BPF Map (IP黑名单、速率限制、配置等)
  3. 接收内核事件并处理
  4. 与 attack_detector 联动

依赖:
  - bcc (BPF Compiler Collection) Python 绑定
  - 内核版本 >= 4.8 (XDP 支持)
  - 内核版本 >= 5.0 (BPF ring buffer 支持)

使用方法:
  controller = XDPController(interface="eth0")
  await controller.load()
  controller.ban_ip("192.168.1.100", duration=3600)
  await controller.unload()
"""

import os
import time
import logging
import asyncio
import struct
import socket
import ipaddress
from typing import Optional, Dict, List, Callable, Set, Tuple, Any
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path

logger = logging.getLogger(__name__)

# 尝试导入 bcc
try:
    from bcc import BPF, libbcc
    BCC_AVAILABLE = True
except ImportError:
    BCC_AVAILABLE = False
    logger.warning("bcc 库未安装, XDP 功能将不可用")


class XDPMode(IntEnum):
    """XDP 运行模式"""
    PASS = 0      # 学习模式: 只检测不拦截
    LEARN = 1     # 学习模式: 检测并记录
    ENFORCE = 2   # 执行模式: 检测并拦截


class EventType(IntEnum):
    """事件类型"""
    BANNED_IP = 1
    FLOOD = 2
    TAGGING = 3
    REPLAY = 4


@dataclass
class XDPStats:
    """XDP 统计信息"""
    total_packets: int = 0
    dropped_packets: int = 0
    banned_ip_drops: int = 0
    flood_drops: int = 0
    tagging_drops: int = 0
    replay_drops: int = 0
    pass_packets: int = 0


@dataclass
class XDPEvent:
    """XDP 事件"""
    timestamp: float
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: int
    event_type: EventType
    pkt_size: int
    feature_hash: int


class XDPController:
    """
    XDP 控制器 - 用户态控制面
    
    管理 eBPF/XDP 程序的加载、配置和事件处理。
    """

    # 默认配置
    DEFAULT_FLOOD_PPS = 1000
    DEFAULT_FLOOD_BPS = 100 * 1024 * 1024  # 100MB/s
    DEFAULT_TAG_THRESHOLD = 50  # 50%

    # BPF Map 名称
    MAP_BANNED_IPS = "banned_ips"
    MAP_RATE_LIMITS = "rate_limits"
    MAP_FINGERPRINTS = "attack_fingerprints"
    MAP_CONFIG = "xdp_config"
    MAP_STATS = "xdp_stats"
    MAP_EVENTS = "events"

    def __init__(
        self,
        interface: str = "eth0",
        mode: XDPMode = XDPMode.LEARN,
        src_path: Optional[str] = None,
        auto_event_poll: bool = True,
    ):
        """
        初始化 XDP 控制器

        Args:
            interface: 要附加 XDP 程序的网卡接口名
            mode: 运行模式 (PASS/LEARN/ENFORCE)
            src_path: eBPF C 源码路径, 默认使用内置路径
            auto_event_poll: 是否自动轮询事件
        """
        self._interface = interface
        self._mode = mode
        self._auto_event_poll = auto_event_poll

        # 确定源码路径
        if src_path is None:
            base_dir = Path(__file__).parent
            self._src_path = str(base_dir / "aegis_xdp.c")
        else:
            self._src_path = src_path

        # BPF 对象
        self._bpf: Optional[BPF] = None
        self._func: Optional[Any] = None

        # 回调函数
        self._event_callbacks: List[Callable[[XDPEvent], None]] = []
        self._poll_task: Optional[asyncio.Task] = None

        # 运行状态
        self._loaded = False
        self._closed = False

        logger.info(f"XDPController 初始化完成 (interface={interface}, mode={mode.name})")

    @property
    def is_loaded(self) -> bool:
        """检查 XDP 程序是否已加载"""
        return self._loaded

    @property
    def mode(self) -> XDPMode:
        """获取当前运行模式"""
        return self._mode

    def set_mode(self, mode: XDPMode) -> None:
        """设置运行模式 (无需重新加载)"""
        self._mode = mode
        if self._loaded:
            self._set_config(2, mode.value)  # CONFIG_MODE = 2
        logger.info(f"XDP 模式切换为: {mode.name}")

    async def load(self) -> bool:
        """
        加载 XDP 程序到网卡

        Returns:
            True if successful, False otherwise
        """
        if not BCC_AVAILABLE:
            logger.error("bcc 库不可用, 无法加载 XDP 程序")
            return False

        if self._loaded:
            logger.warning("XDP 程序已加载")
            return True

        try:
            # 检查源码文件
            if not os.path.exists(self._src_path):
                logger.error(f"XDP 源码文件不存在: {self._src_path}")
                return False

            # 编译并加载 BPF 程序
            logger.info(f"正在编译并加载 XDP 程序: {self._src_path}")
            self._bpf = BPF(src_file=self._src_path, cflags=["-g", "-O2"])

            # 获取 XDP 函数
            self._func = self._bpf.load_func("aegis_xdp_prog", BPF.XDP)

            # 附加到网卡
            self._bpf.attach_xdp(self._interface, self._func, BPF.XDP_FLAGS_SKB_MODE)

            # 初始化配置
            self._init_config()

            # 启动事件轮询
            if self._auto_event_poll:
                self._poll_task = asyncio.create_task(self._poll_events())

            self._loaded = True
            logger.info(f"XDP 程序已成功加载到 {self._interface}")
            return True

        except Exception as e:
            logger.error(f"加载 XDP 程序失败: {e}")
            await self._cleanup()
            return False

    async def unload(self) -> None:
        """卸载 XDP 程序"""
        if not self._loaded:
            return

        logger.info("正在卸载 XDP 程序...")

        # 停止事件轮询
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
            self._poll_task = None

        await self._cleanup()
        self._loaded = False
        logger.info("XDP 程序已卸载")

    async def _cleanup(self) -> None:
        """清理资源"""
        try:
            if self._bpf:
                self._bpf.remove_xdp(self._interface)
                self._bpf.cleanup()
                self._bpf = None
        except Exception as e:
            logger.warning(f"清理 XDP 资源时出错: {e}")

    def _init_config(self) -> None:
        """初始化默认配置"""
        self._set_config(0, self.DEFAULT_FLOOD_PPS)   # CONFIG_FLOOD_PPS
        self._set_config(1, self.DEFAULT_FLOOD_BPS)   # CONFIG_FLOOD_BPS
        self._set_config(2, self._mode.value)         # CONFIG_MODE
        self._set_config(3, self.DEFAULT_TAG_THRESHOLD)  # CONFIG_TAG_THRESHOLD

    def _set_config(self, key: int, value: int) -> None:
        """设置配置项"""
        if not self._bpf:
            return
        try:
            config_map = self._bpf.get_table(self.MAP_CONFIG)
            config_map[config_map.Key(key)] = config_map.Leaf(value)
        except Exception as e:
            logger.warning(f"设置配置失败 (key={key}): {e}")

    def _get_config(self, key: int) -> int:
        """获取配置项"""
        if not self._bpf:
            return 0
        try:
            config_map = self._bpf.get_table(self.MAP_CONFIG)
            return int(config_map[config_map.Key(key)].value)
        except Exception:
            return 0

    # ============================================================
    # IP 黑名单管理
    # ============================================================

    def ban_ip(self, ip: str, duration: int = 0) -> bool:
        """
        封禁 IP 地址

        Args:
            ip: IP 地址 (IPv4)
            duration: 封禁时长(秒), 0=永久

        Returns:
            True if successful
        """
        if not self._bpf:
            logger.warning("XDP 程序未加载")
            return False

        try:
            ip_int = int(ipaddress.IPv4Address(ip))
            banned_map = self._bpf.get_table(self.MAP_BANNED_IPS)

            if duration > 0:
                expiry = int(time.time()) + duration
            else:
                expiry = 0  # 永久

            banned_map[banned_map.Key(ip_int)] = banned_map.Leaf(expiry)
            logger.info(f"已封禁 IP: {ip} (时长: {duration if duration > 0 else '永久'}秒)")
            return True

        except Exception as e:
            logger.error(f"封禁 IP 失败 ({ip}): {e}")
            return False

    def unban_ip(self, ip: str) -> bool:
        """解封 IP 地址"""
        if not self._bpf:
            return False

        try:
            ip_int = int(ipaddress.IPv4Address(ip))
            banned_map = self._bpf.get_table(self.MAP_BANNED_IPS)
            del banned_map[banned_map.Key(ip_int)]
            logger.info(f"已解封 IP: {ip}")
            return True

        except Exception as e:
            logger.error(f"解封 IP 失败 ({ip}): {e}")
            return False

    def is_ip_banned(self, ip: str) -> bool:
        """检查 IP 是否被封禁"""
        if not self._bpf:
            return False

        try:
            ip_int = int(ipaddress.IPv4Address(ip))
            banned_map = self._bpf.get_table(self.MAP_BANNED_IPS)
            return banned_map.Key(ip_int) in banned_map
        except Exception:
            return False

    def get_banned_ips(self) -> List[Tuple[str, int]]:
        """
        获取所有被封禁的 IP

        Returns:
            List of (ip, expiry) tuples
        """
        if not self._bpf:
            return []

        result = []
        try:
            banned_map = self._bpf.get_table(self.MAP_BANNED_IPS)
            for key, leaf in banned_map.items():
                ip = str(ipaddress.IPv4Address(key.value))
                expiry = leaf.value
                result.append((ip, expiry))
        except Exception as e:
            logger.warning(f"获取封禁列表失败: {e}")

        return result

    def clear_banned_ips(self) -> None:
        """清空 IP 黑名单"""
        if not self._bpf:
            return

        try:
            banned_map = self._bpf.get_table(self.MAP_BANNED_IPS)
            for key in list(banned_map.keys()):
                del banned_map[key]
            logger.info("已清空 IP 黑名单")
        except Exception as e:
            logger.error(f"清空黑名单失败: {e}")

    # ============================================================
    # 速率限制配置
    # ============================================================

    def set_flood_thresholds(self, pps: int, bps: int) -> None:
        """
        设置洪水攻击阈值

        Args:
            pps: 每秒包数阈值
            bps: 每秒字节数阈值
        """
        self._set_config(0, pps)
        self._set_config(1, bps)
        logger.info(f"洪水攻击阈值已更新: PPS={pps}, BPS={bps}")

    # ============================================================
    # 统计信息
    # ============================================================

    def get_stats(self) -> XDPStats:
        """获取 XDP 统计信息"""
        stats = XDPStats()

        if not self._bpf:
            return stats

        try:
            stats_map = self._bpf.get_table(self.MAP_STATS)

            # 读取 per-CPU 计数并求和
            for cpu_id, values in stats_map.items():
                stats.total_packets += values[0].value
                stats.dropped_packets += values[1].value
                stats.banned_ip_drops += values[2].value
                stats.flood_drops += values[3].value
                stats.tagging_drops += values[4].value
                stats.replay_drops += values[5].value
                stats.pass_packets += values[6].value

        except Exception as e:
            logger.warning(f"获取统计信息失败: {e}")

        return stats

    # ============================================================
    # 事件处理
    # ============================================================

    def register_event_callback(self, callback: Callable[[XDPEvent], None]) -> None:
        """注册事件回调函数"""
        self._event_callbacks.append(callback)

    def unregister_event_callback(self, callback: Callable[[XDPEvent], None]) -> None:
        """注销事件回调函数"""
        if callback in self._event_callbacks:
            self._event_callbacks.remove(callback)

    async def _poll_events(self) -> None:
        """轮询内核事件 (ring buffer)"""
        if not self._bpf:
            return

        try:
            events_map = self._bpf.get_table(self.MAP_EVENTS)

            while not self._closed:
                try:
                    # 尝试读取事件 (非阻塞)
                    events_map.ring_buffer_poll(timeout_ms=100)

                    # 处理回调
                    for callback in self._event_callbacks:
                        try:
                            callback(None)  # 简化处理
                        except Exception as e:
                            logger.error(f"事件回调错误: {e}")

                    await asyncio.sleep(0.01)  # 10ms 间隔

                except Exception as e:
                    logger.warning(f"事件轮询错误: {e}")
                    await asyncio.sleep(1)

        except asyncio.CancelledError:
            logger.debug("事件轮询已停止")
        except Exception as e:
            logger.error(f"事件轮询异常: {e}")

    def _parse_event(self, data: bytes) -> Optional[XDPEvent]:
        """解析内核事件数据"""
        if len(data) < 32:
            return None

        try:
            # struct xdp_event 布局:
            # timestamp(8) + src_ip(4) + dst_ip(4) + src_port(2) + dst_port(2) +
            # protocol(1) + event_type(1) + padding(2) + pkt_size(4) + feature_hash(4)
            unpacked = struct.unpack("<QIIHHBBHII", data[:32])

            return XDPEvent(
                timestamp=unpacked[0] / 1e9,  # ns -> s
                src_ip=str(ipaddress.IPv4Address(unpacked[1])),
                dst_ip=str(ipaddress.IPv4Address(unpacked[2])),
                src_port=socket.ntohs(unpacked[3]),
                dst_port=socket.ntohs(unpacked[4]),
                protocol=unpacked[5],
                event_type=EventType(unpacked[6]),
                pkt_size=unpacked[8],
                feature_hash=unpacked[9],
            )
        except Exception as e:
            logger.warning(f"解析事件失败: {e}")
            return None

    async def close(self) -> None:
        """关闭控制器"""
        if self._closed:
            return

        self._closed = True
        await self.unload()
        logger.info("XDPController 已关闭")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        asyncio.create_task(self.close())
