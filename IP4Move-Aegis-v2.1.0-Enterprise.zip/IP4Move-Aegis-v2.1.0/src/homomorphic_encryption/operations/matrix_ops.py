"""
密文矩阵运算类

提供在加密状态下进行矩阵运算的功能，包括：
- 矩阵加法和减法
- 矩阵乘法
- 矩阵转置
- 矩阵与向量乘法
- 矩阵标量乘法

支持多种同态加密方案，特别适用于隐私保护机器学习和数据分析。
"""

import random
from typing import Optional, Union, List, Tuple, Any, Callable
from dataclasses import dataclass

from ..schemes.paillier import PaillierScheme, PaillierCiphertext
from ..schemes.bfv import BFVScheme, BFVCiphertext
from ..schemes.ckks import CKKSScheme, CKKSCiphertext


@dataclass
class EncryptedMatrix:
    """
    加密矩阵
    
    存储加密后的矩阵数据。
    
    Attributes:
        data: 二维密文列表
        rows: 行数
        cols: 列数
        scheme_type: 使用的加密方案类型
    """
    data: List[List[Any]]
    rows: int
    cols: int
    scheme_type: str
    
    def __post_init__(self) -> None:
        """验证矩阵维度"""
        if len(self.data) != self.rows:
            raise ValueError(f"数据行数({len(self.data)})与声明行数({self.rows})不匹配")
        for i, row in enumerate(self.data):
            if len(row) != self.cols:
                raise ValueError(f"第{i}行列数({len(row)})与声明列数({self.cols})不匹配")


@dataclass
class EncryptedVector:
    """
    加密向量
    
    存储加密后的向量数据。
    
    Attributes:
        data: 密文列表
        length: 向量长度
        scheme_type: 使用的加密方案类型
    """
    data: List[Any]
    length: int
    scheme_type: str
    
    def __post_init__(self) -> None:
        """验证向量长度"""
        if len(self.data) != self.length:
            raise ValueError(f"数据长度({len(self.data)})与声明长度({self.length})不匹配")


class EncryptedMatrixOperations:
    """
    密文矩阵运算类
    
    提供在加密状态下执行矩阵运算的功能。
    支持加法、减法、乘法、转置等基本操作。
    
    Attributes:
        scheme: 底层加密方案实例
        scheme_type: 加密方案类型
    
    Example:
        >>> from ..schemes.ckks import CKKSScheme
        >>> scheme = CKKSScheme()
        >>> ops = EncryptedMatrixOperations(scheme)
        >>> 
        >>> # 加密矩阵
        >>> matrix = [[1.0, 2.0], [3.0, 4.0]]
        >>> enc_matrix = ops.encrypt_matrix(matrix)
        >>> 
        >>> # 矩阵乘法
        >>> result = ops.matrix_multiply(enc_matrix, enc_matrix)
    """
    
    def __init__(self, scheme: Union[PaillierScheme, BFVScheme, CKKSScheme]) -> None:
        """
        初始化矩阵运算类
        
        Args:
            scheme: 加密方案实例
        """
        self.scheme = scheme
        
        # 确定方案类型
        if isinstance(scheme, PaillierScheme):
            self.scheme_type = "paillier"
        elif isinstance(scheme, BFVScheme):
            self.scheme_type = "bfv"
        elif isinstance(scheme, CKKSScheme):
            self.scheme_type = "ckks"
        else:
            raise ValueError(f"不支持的加密方案类型: {type(scheme)}")
    
    def encrypt_matrix(
        self,
        matrix: List[List[Union[int, float]]]
    ) -> EncryptedMatrix:
        """
        加密矩阵
        
        将明文矩阵加密为密文矩阵。
        
        Args:
            matrix: 二维明文矩阵
            
        Returns:
            加密矩阵
            
        Raises:
            ValueError: 当矩阵为空或维度不匹配时
        """
        if not matrix or not matrix[0]:
            raise ValueError("矩阵不能为空")
        
        rows = len(matrix)
        cols = len(matrix[0])
        
        # 验证所有行具有相同列数
        for i, row in enumerate(matrix):
            if len(row) != cols:
                raise ValueError(f"第{i}行列数与第一行不匹配")
        
        # 加密每个元素
        encrypted_data = []
        for row in matrix:
            encrypted_row = []
            for val in row:
                if self.scheme_type == "paillier":
                    encrypted_row.append(self.scheme.encrypt(int(val)))
                elif self.scheme_type == "bfv":
                    encrypted_row.append(self.scheme.encrypt(int(val)))
                else:  # ckks
                    encrypted_row.append(self.scheme.encrypt(float(val)))
            encrypted_data.append(encrypted_row)
        
        return EncryptedMatrix(
            data=encrypted_data,
            rows=rows,
            cols=cols,
            scheme_type=self.scheme_type
        )
    
    def decrypt_matrix(
        self,
        enc_matrix: EncryptedMatrix
    ) -> List[List[Union[int, float]]]:
        """
        解密矩阵
        
        将密文矩阵解密为明文矩阵。
        
        Args:
            enc_matrix: 加密矩阵
            
        Returns:
            明文矩阵
        """
        decrypted_data = []
        for row in enc_matrix.data:
            decrypted_row = []
            for ct in row:
                val = self.scheme.decrypt(ct)
                if self.scheme_type == "ckks" and isinstance(val, list):
                    # CKKS返回列表，取第一个值
                    val = val[0] if val else 0.0
                decrypted_row.append(val)
            decrypted_data.append(decrypted_row)
        
        return decrypted_data
    
    def encrypt_vector(
        self,
        vector: List[Union[int, float]]
    ) -> EncryptedVector:
        """
        加密向量
        
        Args:
            vector: 明文向量
            
        Returns:
            加密向量
        """
        if not vector:
            raise ValueError("向量不能为空")
        
        encrypted_data = []
        for val in vector:
            if self.scheme_type == "paillier":
                encrypted_data.append(self.scheme.encrypt(int(val)))
            elif self.scheme_type == "bfv":
                encrypted_data.append(self.scheme.encrypt(int(val)))
            else:  # ckks
                encrypted_data.append(self.scheme.encrypt(float(val)))
        
        return EncryptedVector(
            data=encrypted_data,
            length=len(vector),
            scheme_type=self.scheme_type
        )
    
    def decrypt_vector(
        self,
        enc_vector: EncryptedVector
    ) -> List[Union[int, float]]:
        """
        解密向量
        
        Args:
            enc_vector: 加密向量
            
        Returns:
            明文向量
        """
        decrypted_data = []
        for ct in enc_vector.data:
            val = self.scheme.decrypt(ct)
            if self.scheme_type == "ckks" and isinstance(val, list):
                val = val[0] if val else 0.0
            decrypted_data.append(val)
        
        return decrypted_data
    
    def matrix_add(
        self,
        a: EncryptedMatrix,
        b: EncryptedMatrix
    ) -> EncryptedMatrix:
        """
        矩阵加法
        
        对两个加密矩阵进行逐元素加法。
        
        Args:
            a: 第一个加密矩阵
            b: 第二个加密矩阵
            
        Returns:
            加法结果矩阵
            
        Raises:
            ValueError: 当矩阵维度不匹配时
        """
        if a.rows != b.rows or a.cols != b.cols:
            raise ValueError(
                f"矩阵维度不匹配: ({a.rows}x{a.cols}) vs ({b.rows}x{b.cols})"
            )
        
        result_data = []
        for i in range(a.rows):
            result_row = []
            for j in range(a.cols):
                # 同态加法
                sum_ct = a.data[i][j] + b.data[i][j]
                result_row.append(sum_ct)
            result_data.append(result_row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=a.rows,
            cols=a.cols,
            scheme_type=self.scheme_type
        )
    
    def matrix_subtract(
        self,
        a: EncryptedMatrix,
        b: EncryptedMatrix
    ) -> EncryptedMatrix:
        """
        矩阵减法
        
        对两个加密矩阵进行逐元素减法。
        
        Args:
            a: 被减矩阵
            b: 减矩阵
            
        Returns:
            减法结果矩阵
        """
        if a.rows != b.rows or a.cols != b.cols:
            raise ValueError(
                f"矩阵维度不匹配: ({a.rows}x{a.cols}) vs ({b.rows}x{b.cols})"
            )
        
        result_data = []
        for i in range(a.rows):
            result_row = []
            for j in range(a.cols):
                # 同态减法
                diff_ct = a.data[i][j] - b.data[i][j]
                result_row.append(diff_ct)
            result_data.append(result_row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=a.rows,
            cols=a.cols,
            scheme_type=self.scheme_type
        )
    
    def matrix_multiply(
        self,
        a: EncryptedMatrix,
        b: EncryptedMatrix
    ) -> EncryptedMatrix:
        """
        矩阵乘法
        
        计算两个加密矩阵的乘积。
        
        Args:
            a: 左矩阵
            b: 右矩阵
            
        Returns:
            乘积矩阵
            
        Raises:
            ValueError: 当矩阵维度不匹配时
            RuntimeError: 当使用Paillier方案时（不支持乘法）
        """
        if self.scheme_type == "paillier":
            raise RuntimeError("Paillier方案不支持矩阵乘法（需要密文-密文乘法）")
        
        if a.cols != b.rows:
            raise ValueError(
                f"矩阵维度不匹配: ({a.rows}x{a.cols}) * ({b.rows}x{b.cols})"
            )
        
        result_rows = a.rows
        result_cols = b.cols
        result_data = []
        
        for i in range(result_rows):
            result_row = []
            for j in range(result_cols):
                # 计算 C[i][j] = sum(A[i][k] * B[k][j])
                # 初始化为0
                if self.scheme_type == "bfv":
                    sum_ct = self.scheme.encrypt(0)
                else:  # ckks
                    sum_ct = self.scheme.encrypt(0.0)
                
                for k in range(a.cols):
                    # 同态乘法和加法
                    product = a.data[i][k] * b.data[k][j]
                    sum_ct = sum_ct + product
                
                result_row.append(sum_ct)
            result_data.append(result_row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=result_rows,
            cols=result_cols,
            scheme_type=self.scheme_type
        )
    
    def matrix_transpose(self, matrix: EncryptedMatrix) -> EncryptedMatrix:
        """
        矩阵转置
        
        Args:
            matrix: 加密矩阵
            
        Returns:
            转置后的矩阵
        """
        result_data = []
        for j in range(matrix.cols):
            result_row = []
            for i in range(matrix.rows):
                result_row.append(matrix.data[i][j])
            result_data.append(result_row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=matrix.cols,
            cols=matrix.rows,
            scheme_type=self.scheme_type
        )
    
    def matrix_scalar_multiply(
        self,
        matrix: EncryptedMatrix,
        scalar: Union[int, float]
    ) -> EncryptedMatrix:
        """
        矩阵标量乘法
        
        将矩阵的每个元素乘以标量。
        
        Args:
            matrix: 加密矩阵
            scalar: 标量值
            
        Returns:
            标量乘法结果矩阵
        """
        result_data = []
        for i in range(matrix.rows):
            result_row = []
            for j in range(matrix.cols):
                # 同态标量乘法
                product = matrix.data[i][j] * scalar
                result_row.append(product)
            result_data.append(result_row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=matrix.rows,
            cols=matrix.cols,
            scheme_type=self.scheme_type
        )
    
    def matrix_vector_multiply(
        self,
        matrix: EncryptedMatrix,
        vector: EncryptedVector
    ) -> EncryptedVector:
        """
        矩阵与向量乘法
        
        Args:
            matrix: 加密矩阵
            vector: 加密向量
            
        Returns:
            结果向量
        """
        if self.scheme_type == "paillier":
            raise RuntimeError("Paillier方案不支持矩阵-向量乘法")
        
        if matrix.cols != vector.length:
            raise ValueError(
                f"矩阵列数({matrix.cols})与向量长度({vector.length})不匹配"
            )
        
        result_data = []
        for i in range(matrix.rows):
            # 初始化为0
            if self.scheme_type == "bfv":
                sum_ct = self.scheme.encrypt(0)
            else:  # ckks
                sum_ct = self.scheme.encrypt(0.0)
            
            for j in range(matrix.cols):
                product = matrix.data[i][j] * vector.data[j]
                sum_ct = sum_ct + product
            
            result_data.append(sum_ct)
        
        return EncryptedVector(
            data=result_data,
            length=matrix.rows,
            scheme_type=self.scheme_type
        )
    
    def vector_inner_product(
        self,
        a: EncryptedVector,
        b: EncryptedVector
    ) -> Any:
        """
        向量内积
        
        计算两个向量的点积。
        
        Args:
            a: 第一个向量
            b: 第二个向量
            
        Returns:
            内积密文
        """
        if self.scheme_type == "paillier":
            raise RuntimeError("Paillier方案不支持向量内积")
        
        if a.length != b.length:
            raise ValueError(f"向量长度不匹配: {a.length} vs {b.length}")
        
        # 初始化为0
        if self.scheme_type == "bfv":
            result = self.scheme.encrypt(0)
        else:  # ckks
            result = self.scheme.encrypt(0.0)
        
        for i in range(a.length):
            product = a.data[i] * b.data[i]
            result = result + product
        
        return result
    
    def vector_add(
        self,
        a: EncryptedVector,
        b: EncryptedVector
    ) -> EncryptedVector:
        """
        向量加法
        
        Args:
            a: 第一个向量
            b: 第二个向量
            
        Returns:
            加法结果向量
        """
        if a.length != b.length:
            raise ValueError(f"向量长度不匹配: {a.length} vs {b.length}")
        
        result_data = []
        for i in range(a.length):
            sum_ct = a.data[i] + b.data[i]
            result_data.append(sum_ct)
        
        return EncryptedVector(
            data=result_data,
            length=a.length,
            scheme_type=self.scheme_type
        )
    
    def vector_scalar_multiply(
        self,
        vector: EncryptedVector,
        scalar: Union[int, float]
    ) -> EncryptedVector:
        """
        向量标量乘法
        
        Args:
            vector: 加密向量
            scalar: 标量值
            
        Returns:
            标量乘法结果向量
        """
        result_data = []
        for i in range(vector.length):
            product = vector.data[i] * scalar
            result_data.append(product)
        
        return EncryptedVector(
            data=result_data,
            length=vector.length,
            scheme_type=self.scheme_type
        )
    
    def hadamard_product(
        self,
        a: EncryptedMatrix,
        b: EncryptedMatrix
    ) -> EncryptedMatrix:
        """
        Hadamard积（逐元素乘法）
        
        Args:
            a: 第一个矩阵
            b: 第二个矩阵
            
        Returns:
            Hadamard积矩阵
        """
        if self.scheme_type == "paillier":
            raise RuntimeError("Paillier方案不支持Hadamard积")
        
        if a.rows != b.rows or a.cols != b.cols:
            raise ValueError(
                f"矩阵维度不匹配: ({a.rows}x{a.cols}) vs ({b.rows}x{b.cols})"
            )
        
        result_data = []
        for i in range(a.rows):
            result_row = []
            for j in range(a.cols):
                product = a.data[i][j] * b.data[i][j]
                result_row.append(product)
            result_data.append(result_row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=a.rows,
            cols=a.cols,
            scheme_type=self.scheme_type
        )
    
    def kronecker_product(
        self,
        a: EncryptedMatrix,
        b: EncryptedMatrix
    ) -> EncryptedMatrix:
        """
        Kronecker积（张量积）
        
        Args:
            a: 第一个矩阵
            b: 第二个矩阵
            
        Returns:
            Kronecker积矩阵
        """
        if self.scheme_type == "paillier":
            raise RuntimeError("Paillier方案不支持Kronecker积")
        
        result_rows = a.rows * b.rows
        result_cols = a.cols * b.cols
        result_data = []
        
        for i in range(a.rows):
            for k in range(b.rows):
                result_row = []
                for j in range(a.cols):
                    for l in range(b.cols):
                        product = a.data[i][j] * b.data[k][l]
                        result_row.append(product)
                result_data.append(result_row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=result_rows,
            cols=result_cols,
            scheme_type=self.scheme_type
        )
    
    def extract_diagonal(self, matrix: EncryptedMatrix) -> EncryptedVector:
        """
        提取对角线元素
        
        Args:
            matrix: 方阵
            
        Returns:
            对角线元素向量
        """
        if matrix.rows != matrix.cols:
            raise ValueError("只有方阵才能提取对角线")
        
        diagonal_data = []
        for i in range(matrix.rows):
            diagonal_data.append(matrix.data[i][i])
        
        return EncryptedVector(
            data=diagonal_data,
            length=matrix.rows,
            scheme_type=self.scheme_type
        )
    
    def create_identity_matrix(self, size: int) -> EncryptedMatrix:
        """
        创建加密单位矩阵
        
        Args:
            size: 矩阵大小
            
        Returns:
            加密单位矩阵
        """
        result_data = []
        for i in range(size):
            row = []
            for j in range(size):
                if i == j:
                    # 对角线为1
                    if self.scheme_type == "bfv":
                        row.append(self.scheme.encrypt(1))
                    else:  # ckks
                        row.append(self.scheme.encrypt(1.0))
                else:
                    # 非对角线为0
                    if self.scheme_type == "bfv":
                        row.append(self.scheme.encrypt(0))
                    else:  # ckks
                        row.append(self.scheme.encrypt(0.0))
            result_data.append(row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=size,
            cols=size,
            scheme_type=self.scheme_type
        )
    
    def create_zero_matrix(self, rows: int, cols: int) -> EncryptedMatrix:
        """
        创建加密零矩阵
        
        Args:
            rows: 行数
            cols: 列数
            
        Returns:
            加密零矩阵
        """
        result_data = []
        for i in range(rows):
            row = []
            for j in range(cols):
                if self.scheme_type == "bfv":
                    row.append(self.scheme.encrypt(0))
                else:  # ckks or paillier
                    row.append(self.scheme.encrypt(0 if self.scheme_type == "paillier" else 0.0))
            result_data.append(row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=rows,
            cols=cols,
            scheme_type=self.scheme_type
        )
    
    def batch_matrix_add(
        self,
        matrices: List[EncryptedMatrix]
    ) -> EncryptedMatrix:
        """
        批量矩阵加法
        
        对多个加密矩阵进行求和。
        
        Args:
            matrices: 加密矩阵列表
            
        Returns:
            求和结果矩阵
        """
        if not matrices:
            raise ValueError("矩阵列表不能为空")
        
        result = matrices[0]
        for matrix in matrices[1:]:
            result = self.matrix_add(result, matrix)
        
        return result
    
    def map_matrix(
        self,
        matrix: EncryptedMatrix,
        operation: Callable[[Any], Any]
    ) -> EncryptedMatrix:
        """
        对矩阵每个元素应用操作
        
        Args:
            matrix: 加密矩阵
            operation: 应用于每个元素的操作函数
            
        Returns:
            操作后的矩阵
        """
        result_data = []
        for i in range(matrix.rows):
            result_row = []
            for j in range(matrix.cols):
                result_row.append(operation(matrix.data[i][j]))
            result_data.append(result_row)
        
        return EncryptedMatrix(
            data=result_data,
            rows=matrix.rows,
            cols=matrix.cols,
            scheme_type=self.scheme_type
        )
    
    def get_matrix_dimensions(self, matrix: EncryptedMatrix) -> Tuple[int, int]:
        """
        获取矩阵维度
        
        Args:
            matrix: 加密矩阵
            
        Returns:
            (行数, 列数)元组
        """
        return (matrix.rows, matrix.cols)
    
    def get_vector_length(self, vector: EncryptedVector) -> int:
        """
        获取向量长度
        
        Args:
            vector: 加密向量
            
        Returns:
            向量长度
        """
        return vector.length
