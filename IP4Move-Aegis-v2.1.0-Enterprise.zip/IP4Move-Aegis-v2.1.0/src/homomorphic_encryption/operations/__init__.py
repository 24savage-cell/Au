"""
同态加密操作模块

提供高级同态加密操作，包括：
- EncryptedOperations: 通用密文操作（加解密、计算）
- EncryptedMatrixOperations: 密文矩阵运算

这些操作类封装了底层加密方案，提供更便捷的接口。
"""

from .encrypted_ops import EncryptedOperations
from .matrix_ops import EncryptedMatrixOperations

__all__ = [
    "EncryptedOperations",
    "EncryptedMatrixOperations",
]
