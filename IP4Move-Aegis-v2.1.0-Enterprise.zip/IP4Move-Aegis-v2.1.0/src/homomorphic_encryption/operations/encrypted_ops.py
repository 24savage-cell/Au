"""
通用同态加密操作类

提供统一的接口来执行各种同态加密操作，封装了不同加密方案的细节。
支持Paillier、BFV、CKKS等多种方案。
"""

import random
import math
from typing import Optional, Union, List, Dict, Any, Callable, Type
from enum import Enum
from dataclasses import dataclass

from ..schemes.paillier import PaillierScheme, PaillierCiphertext
from ..schemes.bfv import BFVScheme, BFVCiphertext, BFVParameters
from ..schemes.ckks import CKKSScheme, CKKSCiphertext, CKKSParameters


class SchemeType(Enum):
    """加密方案类型枚举"""
    PAILLIER = "paillier"
    BFV = "bfv"
    CKKS = "ckks"


@dataclass
class EncryptionContext:
    """
    加密上下文
    
    存储加密操作的上下文信息。
    
    Attributes:
        scheme_type: 使用的加密方案类型
        key_size: 密钥大小
        params: 方案特定参数
        metadata: 额外元数据
    """
    scheme_type: SchemeType
    key_size: int = 2048
    params: Optional[Any] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self) -> None:
        if self.metadata is None:
            self.metadata = {}


class EncryptedOperations:
    """
    通用同态加密操作类
    
    提供统一的接口来执行加密、解密和同态运算，
    支持多种同态加密方案。
    
    Attributes:
        scheme: 底层加密方案实例
        scheme_type: 当前使用的方案类型
        context: 加密上下文
    
    Example:
        >>> ops = EncryptedOperations(SchemeType.PAILLIER)
        >>> ct = ops.encrypt(100)
        >>> result = ops.add(ct, 50)
        >>> plaintext = ops.decrypt(result)  # 结果应为150
    """
    
    def __init__(
        self,
        scheme_type: SchemeType = SchemeType.PAILLIER,
        key_size: int = 2048,
        params: Optional[Any] = None
    ) -> None:
        """
        初始化加密操作类
        
        Args:
            scheme_type: 加密方案类型
            key_size: 密钥大小（对于Paillier）
            params: 方案特定参数（对于BFV/CKKS）
        """
        self.scheme_type = scheme_type
        self.context = EncryptionContext(
            scheme_type=scheme_type,
            key_size=key_size,
            params=params
        )
        
        # 初始化对应的加密方案
        if scheme_type == SchemeType.PAILLIER:
            self.scheme = PaillierScheme(key_size=key_size)
        elif scheme_type == SchemeType.BFV:
            if params is None:
                params = BFVParameters()
            elif isinstance(params, dict):
                params = BFVParameters(**params)
            self.scheme = BFVScheme(params)
            self.context.params = params
        elif scheme_type == SchemeType.CKKS:
            if params is None:
                params = CKKSParameters()
            elif isinstance(params, dict):
                params = CKKSParameters(**params)
            self.scheme = CKKSScheme(params)
            self.context.params = params
        else:
            raise ValueError(f"不支持的加密方案: {scheme_type}")
    
    def encrypt(self, plaintext: Union[int, float, List[float], List[int]]) -> Any:
        """
        加密明文
        
        根据当前方案类型加密数据。
        
        Args:
            plaintext: 要加密的明文（整数、浮点数或列表）
            
        Returns:
            密文对象
            
        Raises:
            TypeError: 当明文类型不支持时
            RuntimeError: 当加密失败时
        """
        try:
            if self.scheme_type == SchemeType.PAILLIER:
                if isinstance(plaintext, list):
                    return [self.scheme.encrypt(int(p)) for p in plaintext]
                else:
                    return self.scheme.encrypt(int(plaintext))
            elif self.scheme_type == SchemeType.BFV:
                if isinstance(plaintext, list):
                    return self.scheme.batch_encrypt([int(p) for p in plaintext])
                else:
                    return self.scheme.encrypt(int(plaintext))
            elif self.scheme_type == SchemeType.CKKS:
                return self.scheme.encrypt(plaintext)
            else:
                raise ValueError(f"不支持的方案类型: {self.scheme_type}")
        except Exception as e:
            raise RuntimeError(f"加密失败: {str(e)}")
    
    def decrypt(self, ciphertext: Any) -> Union[int, float, List[int], List[float]]:
        """
        解密密文
        
        根据当前方案类型解密密文。
        
        Args:
            ciphertext: 密文对象或列表
            
        Returns:
            解密后的明文
            
        Raises:
            TypeError: 当密文类型不匹配时
            RuntimeError: 当解密失败时
        """
        try:
            if self.scheme_type == SchemeType.PAILLIER:
                if isinstance(ciphertext, list):
                    return self.scheme.batch_decrypt(ciphertext)
                else:
                    return self.scheme.decrypt(ciphertext)
            elif self.scheme_type == SchemeType.BFV:
                if isinstance(ciphertext, list):
                    return self.scheme.batch_decrypt(ciphertext)
                else:
                    return self.scheme.decrypt(ciphertext)
            elif self.scheme_type == SchemeType.CKKS:
                result = self.scheme.decrypt(ciphertext)
                # 如果结果是复数列表，提取实部
                if isinstance(result, list) and len(result) > 0:
                    if all(isinstance(r, complex) for r in result):
                        return [r.real for r in result]
                return result
            else:
                raise ValueError(f"不支持的方案类型: {self.scheme_type}")
        except Exception as e:
            raise RuntimeError(f"解密失败: {str(e)}")
    
    def add(
        self,
        a: Any,
        b: Any
    ) -> Any:
        """
        同态加法
        
        对两个密文或密文与明文进行加法运算。
        
        Args:
            a: 第一个操作数（密文或明文）
            b: 第二个操作数（密文或明文）
            
        Returns:
            加法结果密文
        """
        try:
            # 处理明文-密文顺序
            if not self._is_ciphertext(a) and self._is_ciphertext(b):
                a, b = b, a
            
            if self._is_ciphertext(a) and self._is_ciphertext(b):
                # 密文 + 密文
                return a + b
            elif self._is_ciphertext(a):
                # 密文 + 明文
                return a + b
            else:
                raise ValueError("至少一个操作数必须是密文")
        except Exception as e:
            raise RuntimeError(f"加法运算失败: {str(e)}")
    
    def subtract(self, a: Any, b: Any) -> Any:
        """
        同态减法
        
        对两个密文或密文与明文进行减法运算。
        
        Args:
            a: 被减数（密文或明文）
            b: 减数（密文或明文）
            
        Returns:
            减法结果密文
        """
        try:
            if self._is_ciphertext(a) and self._is_ciphertext(b):
                return a - b
            elif self._is_ciphertext(a):
                return a - b
            elif self._is_ciphertext(b):
                # a - ciphertext = -(ciphertext - a)
                result = b - a
                return self.negate(result)
            else:
                raise ValueError("至少一个操作数必须是密文")
        except Exception as e:
            raise RuntimeError(f"减法运算失败: {str(e)}")
    
    def multiply(self, a: Any, b: Any) -> Any:
        """
        同态乘法
        
        对两个密文或密文与明文进行乘法运算。
        
        Args:
            a: 第一个操作数（密文或明文）
            b: 第二个操作数（密文或明文）
            
        Returns:
            乘法结果密文
        """
        try:
            # 处理明文-密文顺序
            if not self._is_ciphertext(a) and self._is_ciphertext(b):
                a, b = b, a
            
            if self._is_ciphertext(a) and self._is_ciphertext(b):
                # 密文 * 密文
                if self.scheme_type == SchemeType.PAILLIER:
                    raise ValueError("Paillier不支持密文-密文乘法")
                return a * b
            elif self._is_ciphertext(a):
                # 密文 * 明文
                return a * b
            else:
                raise ValueError("至少一个操作数必须是密文")
        except Exception as e:
            raise RuntimeError(f"乘法运算失败: {str(e)}")
    
    def negate(self, ciphertext: Any) -> Any:
        """
        密文取反
        
        Args:
            ciphertext: 密文
            
        Returns:
            取反后的密文
        """
        if hasattr(self.scheme, 'negate'):
            return self.scheme.negate(ciphertext)
        else:
            # 通用实现：乘以-1
            return ciphertext * (-1)
    
    def sum_encrypted(self, ciphertexts: List[Any]) -> Any:
        """
        密文求和
        
        对多个密文进行求和运算。
        
        Args:
            ciphertexts: 密文列表
            
        Returns:
            求和结果密文
        """
        if not ciphertexts:
            raise ValueError("密文列表不能为空")
        
        result = ciphertexts[0]
        for ct in ciphertexts[1:]:
            result = self.add(result, ct)
        
        return result
    
    def multiply_plaintext_vector(
        self,
        ciphertext: Any,
        plaintext_vector: List[Union[int, float]]
    ) -> List[Any]:
        """
        密文与明文向量逐元素相乘
        
        Args:
            ciphertext: 密文（打包多个值）
            plaintext_vector: 明文向量
            
        Returns:
            结果密文
        """
        if self.scheme_type != SchemeType.CKKS:
            raise ValueError("此操作仅支持CKKS方案")
        
        return ciphertext * plaintext_vector
    
    def compute_polynomial(
        self,
        ciphertext: Any,
        coefficients: List[float]
    ) -> Any:
        """
        计算密文的多项式
        
        计算：coeffs[0] + coeffs[1]*x + coeffs[2]*x^2 + ...
        
        Args:
            ciphertext: 输入密文
            coefficients: 多项式系数（从低次到高次）
            
        Returns:
            多项式结果密文
        """
        if not coefficients:
            raise ValueError("系数列表不能为空")
        
        result = self.encrypt(coefficients[0])
        power = ciphertext
        
        for i, coeff in enumerate(coefficients[1:], 1):
            term = self.multiply(power, coeff)
            result = self.add(result, term)
            if i < len(coefficients) - 1:
                power = self.multiply(power, ciphertext)
        
        return result
    
    def compute_mean(self, ciphertexts: List[Any]) -> Any:
        """
        计算密文平均值
        
        Args:
            ciphertexts: 密文列表
            
        Returns:
            平均值密文
        """
        if not ciphertexts:
            raise ValueError("密文列表不能为空")
        
        total = self.sum_encrypted(ciphertexts)
        count = len(ciphertexts)
        
        if self.scheme_type == SchemeType.PAILLIER:
            # Paillier不支持除法，返回总和
            return total
        else:
            # 乘以 1/count
            return self.multiply(total, 1.0 / count)
    
    def compute_variance(
        self,
        ciphertexts: List[Any],
        mean: Optional[Any] = None
    ) -> Any:
        """
        计算密文方差
        
        Args:
            ciphertexts: 密文列表
            mean: 预计算的均值密文（可选）
            
        Returns:
            方差密文
        """
        if len(ciphertexts) < 2:
            raise ValueError("至少需要两个密文")
        
        if mean is None:
            mean = self.compute_mean(ciphertexts)
        
        # 计算 (x - mean)^2 的和
        squared_diffs = []
        for ct in ciphertexts:
            diff = self.subtract(ct, mean)
            squared = self.multiply(diff, diff)
            squared_diffs.append(squared)
        
        variance = self.sum_encrypted(squared_diffs)
        
        if self.scheme_type != SchemeType.PAILLIER:
            n = len(ciphertexts)
            variance = self.multiply(variance, 1.0 / n)
        
        return variance
    
    def compare_encrypted(
        self,
        a: Any,
        b: Any,
        epsilon: float = 0.001
    ) -> bool:
        """
        比较两个密文是否相等（近似）
        
        注意：此方法会解密数据，仅用于测试/验证。
        
        Args:
            a: 第一个密文
            b: 第二个密文
            epsilon: 误差容限
            
        Returns:
            如果两个密文解密后近似相等返回True
        """
        try:
            val_a = self.decrypt(a)
            val_b = self.decrypt(b)
            
            if isinstance(val_a, list) and isinstance(val_b, list):
                if len(val_a) != len(val_b):
                    return False
                return all(abs(x - y) < epsilon for x, y in zip(val_a, val_b))
            else:
                return abs(val_a - val_b) < epsilon
        except Exception:
            return False
    
    def batch_operation(
        self,
        ciphertexts: List[Any],
        operation: Callable[[Any, Any], Any],
        initial_value: Any
    ) -> Any:
        """
        批量密文操作
        
        对密文列表执行自定义操作。
        
        Args:
            ciphertexts: 密文列表
            operation: 二元操作函数
            initial_value: 初始值
            
        Returns:
            操作结果
        """
        result = initial_value
        for ct in ciphertexts:
            result = operation(result, ct)
        return result
    
    def get_scheme_info(self) -> Dict[str, Any]:
        """
        获取当前方案信息
        
        Returns:
            包含方案信息的字典
        """
        info = {
            "scheme_type": self.scheme_type.value,
            "key_size": self.context.key_size,
        }
        
        if self.context.params:
            if self.scheme_type == SchemeType.BFV:
                info["poly_degree"] = self.context.params.poly_degree
                info["plain_modulus"] = self.context.params.plain_modulus
            elif self.scheme_type == SchemeType.CKKS:
                info["poly_degree"] = self.context.params.poly_degree
                info["num_slots"] = self.context.params.num_slots
                info["scale"] = self.context.params.scale
        
        return info
    
    def _is_ciphertext(self, obj: Any) -> bool:
        """
        检查对象是否为密文
        
        Args:
            obj: 要检查的对象
            
        Returns:
            如果是密文返回True
        """
        return isinstance(obj, (PaillierCiphertext, BFVCiphertext, CKKSCiphertext))
    
    def reseed(self, seed: int) -> None:
        """
        重新设置随机种子
        
        用于测试和可重复性。
        
        Args:
            seed: 随机种子
        """
        random.seed(seed)
        if hasattr(self.scheme, 'reseed'):
            self.scheme.reseed(seed)
