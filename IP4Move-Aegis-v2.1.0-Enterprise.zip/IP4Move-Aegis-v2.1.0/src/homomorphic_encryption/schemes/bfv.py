"""
BFV（Brakerski-Fan-Vercauteren）全同态加密方案实现

BFV是一种基于RLWE（Ring Learning With Errors）问题的全同态加密方案，
支持在密文上进行任意次数的加法和乘法运算。

特性：
- 基于多项式环运算
- 支持整数运算
- 可配置的参数以适应不同安全级别

该实现使用模拟方式演示BFV加密的核心概念。
"""

import random
import math
from typing import Optional, Union, List, Tuple
from dataclasses import dataclass, field
from enum import Enum


class SecurityLevel(Enum):
    """安全级别枚举"""
    LOW = 128      # 128位安全
    MEDIUM = 192   # 192位安全
    HIGH = 256     # 256位安全


@dataclass
class BFVParameters:
    """
    BFV方案参数
    
    定义BFV加密方案的数学参数，影响安全性和性能。
    
    Attributes:
        poly_degree: 多项式次数（环维度），必须是2的幂
        plain_modulus: 明文模数，决定明文空间
        cipher_modulus: 密文模数，决定密文空间
        security_level: 安全级别
        base: 重新线性化基数
        sigma: 误差分布标准差
    """
    poly_degree: int = 4096
    plain_modulus: int = 65537
    cipher_modulus: int = 0  # 0表示自动计算
    security_level: SecurityLevel = SecurityLevel.MEDIUM
    base: int = 2
    sigma: float = 3.2
    
    def __post_init__(self) -> None:
        """参数验证和自动计算"""
        # 验证多项式次数
        if self.poly_degree <= 0 or (self.poly_degree & (self.poly_degree - 1)) != 0:
            raise ValueError("多项式次数必须是2的幂（如1024, 2048, 4096, 8192）")
        
        # 验证明文模数
        if self.plain_modulus < 2:
            raise ValueError("明文模数必须至少为2")
        
        # 自动计算密文模数
        if self.cipher_modulus == 0:
            # 根据安全级别和多项式次数估算
            bit_length = self._estimate_cipher_bits()
            self.cipher_modulus = 1 << bit_length
        
        # 验证误差参数
        if self.sigma <= 0:
            raise ValueError("误差标准差必须为正数")
    
    def _estimate_cipher_bits(self) -> int:
        """
        估算密文模数位数
        
        Returns:
            密文模数的位数
        """
        # 基于多项式次数和安全级别估算
        base_bits = {
            1024: 27,
            2048: 54,
            4096: 109,
            8192: 218,
            16384: 438
        }
        
        bits = base_bits.get(self.poly_degree, 109)
        
        # 根据安全级别调整
        if self.security_level == SecurityLevel.LOW:
            bits = int(bits * 0.8)
        elif self.security_level == SecurityLevel.HIGH:
            bits = int(bits * 1.2)
        
        return bits
    
    def get_n(self) -> int:
        """获取多项式次数"""
        return self.poly_degree
    
    def get_t(self) -> int:
        """获取明文模数"""
        return self.plain_modulus
    
    def get_q(self) -> int:
        """获取密文模数"""
        return self.cipher_modulus


@dataclass
class BFVCiphertext:
    """
    BFV密文
    
    BFV密文由两个多项式组成：(c0, c1)
    解密公式：m = (c0 + c1 * s) mod t
    
    Attributes:
        c0: 第一个密文多项式（系数列表）
        c1: 第二个密文多项式（系数列表）
        params: BFV参数
        original_value: 原始明文值（模拟存储）
        noise_budget: 剩余噪声预算
    """
    c0: List[int]
    c1: List[int]
    params: BFVParameters
    original_value: Optional[int] = None
    noise_budget: float = 100.0
    
    def __post_init__(self) -> None:
        """验证密文格式"""
        if len(self.c0) != self.params.poly_degree or len(self.c1) != self.params.poly_degree:
            raise ValueError(f"密文多项式长度必须等于多项式次数{self.params.poly_degree}")
    
    def __add__(self, other: Union['BFVCiphertext', int]) -> 'BFVCiphertext':
        """
        密文加法运算
        
        支持密文-密文加法和密文-明文加法。
        
        Args:
            other: 另一个密文或明文整数
            
        Returns:
            加法结果密文
        """
        n = self.params.poly_degree
        q = self.params.cipher_modulus
        
        if isinstance(other, BFVCiphertext):
            if self.params != other.params:
                raise ValueError("两个密文必须使用相同的参数")
            # 密文-密文加法
            new_c0 = [(self.c0[i] + other.c0[i]) % q for i in range(n)]
            new_c1 = [(self.c1[i] + other.c1[i]) % q for i in range(n)]
            new_original = ((self.original_value or 0) + (other.original_value or 0)) % self.params.plain_modulus
            new_noise = min(self.noise_budget, other.noise_budget) - 1
        elif isinstance(other, int):
            # 密文-明文加法
            new_c0 = self.c0.copy()
            new_c0[0] = (new_c0[0] + other) % q
            new_c1 = self.c1.copy()
            new_original = ((self.original_value or 0) + other) % self.params.plain_modulus
            new_noise = self.noise_budget - 0.5
        else:
            raise TypeError(f"不支持与{type(other)}类型相加")
        
        return BFVCiphertext(
            c0=new_c0,
            c1=new_c1,
            params=self.params,
            original_value=new_original,
            noise_budget=max(0, new_noise)
        )
    
    def __radd__(self, other: int) -> 'BFVCiphertext':
        """右加法支持"""
        return self.__add__(other)
    
    def __sub__(self, other: Union['BFVCiphertext', int]) -> 'BFVCiphertext':
        """
        密文减法运算
        
        Args:
            other: 另一个密文或明文整数
            
        Returns:
            减法结果密文
        """
        n = self.params.poly_degree
        q = self.params.cipher_modulus
        
        if isinstance(other, BFVCiphertext):
            if self.params != other.params:
                raise ValueError("两个密文必须使用相同的参数")
            new_c0 = [(self.c0[i] - other.c0[i]) % q for i in range(n)]
            new_c1 = [(self.c1[i] - other.c1[i]) % q for i in range(n)]
            new_original = ((self.original_value or 0) - (other.original_value or 0)) % self.params.plain_modulus
            new_noise = min(self.noise_budget, other.noise_budget) - 1
        elif isinstance(other, int):
            new_c0 = self.c0.copy()
            new_c0[0] = (new_c0[0] - other) % q
            new_c1 = self.c1.copy()
            new_original = ((self.original_value or 0) - other) % self.params.plain_modulus
            new_noise = self.noise_budget - 0.5
        else:
            raise TypeError(f"不支持与{type(other)}类型相减")
        
        return BFVCiphertext(
            c0=new_c0,
            c1=new_c1,
            params=self.params,
            original_value=new_original,
            noise_budget=max(0, new_noise)
        )
    
    def __rsub__(self, other: int) -> 'BFVCiphertext':
        """右减法支持"""
        result = self.__sub__(other)
        # 取负
        q = self.params.cipher_modulus
        result.c0 = [(-c) % q for c in result.c0]
        result.c1 = [(-c) % q for c in result.c1]
        return result
    
    def __mul__(self, other: Union['BFVCiphertext', int]) -> 'BFVCiphertext':
        """
        密文乘法运算
        
        注意：密文-密文乘法后需要重新线性化。
        
        Args:
            other: 另一个密文或明文整数
            
        Returns:
            乘法结果密文
        """
        n = self.params.poly_degree
        q = self.params.cipher_modulus
        t = self.params.plain_modulus
        
        if isinstance(other, BFVCiphertext):
            if self.params != other.params:
                raise ValueError("两个密文必须使用相同的参数")
            # 密文-密文乘法（简化模拟）
            # 实际BFV中会产生3个多项式，需要重新线性化
            new_c0 = [0] * n
            new_c1 = [0] * n
            for i in range(n):
                new_c0[i] = (self.c0[i] * other.c0[i]) % q
                new_c1[i] = (self.c0[i] * other.c1[i] + self.c1[i] * other.c0[i]) % q
            new_original = ((self.original_value or 0) * (other.original_value or 0)) % t
            new_noise = min(self.noise_budget, other.noise_budget) - 5  # 乘法消耗更多噪声预算
        elif isinstance(other, int):
            # 密文-明文乘法
            new_c0 = [(c * other) % q for c in self.c0]
            new_c1 = [(c * other) % q for c in self.c1]
            new_original = ((self.original_value or 0) * other) % t
            new_noise = self.noise_budget - 1
        else:
            raise TypeError(f"不支持与{type(other)}类型相乘")
        
        return BFVCiphertext(
            c0=new_c0,
            c1=new_c1,
            params=self.params,
            original_value=new_original,
            noise_budget=max(0, new_noise)
        )
    
    def __rmul__(self, other: int) -> 'BFVCiphertext':
        """右乘法支持"""
        return self.__mul__(other)
    
    def __repr__(self) -> str:
        """字符串表示"""
        return f"BFVCiphertext(degree={self.params.poly_degree}, noise_budget={self.noise_budget:.1f})"
    
    def is_valid(self) -> bool:
        """
        检查密文是否有效
        
        Returns:
            如果噪声预算充足返回True
        """
        return self.noise_budget > 0


class BFVScheme:
    """
    BFV全同态加密方案
    
    实现BFV加密算法的核心功能，支持整数上的全同态运算。
    
    Attributes:
        params: BFV参数
        secret_key: 私钥多项式
        public_key: 公钥
    
    Example:
        >>> params = BFVParameters(poly_degree=4096, plain_modulus=65537)
        >>> scheme = BFVScheme(params)
        >>> ct1 = scheme.encrypt(42)
        >>> ct2 = scheme.encrypt(58)
        >>> ct_sum = ct1 + ct2  # 同态加法
        >>> result = scheme.decrypt(ct_sum)  # 结果应为100
    """
    
    def __init__(self, params: Optional[BFVParameters] = None) -> None:
        """
        初始化BFV加密方案
        
        Args:
            params: BFV参数，如果为None则使用默认参数
        """
        self.params = params or BFVParameters()
        self.secret_key: Optional[List[int]] = None
        self.public_key: Optional[Tuple[List[int], List[int]]] = None
        self._generate_keys()
    
    def _generate_keys(self) -> None:
        """
        生成BFV密钥对
        
        生成私钥s和公钥(a, b = -a*s + e)。
        """
        try:
            n = self.params.poly_degree
            q = self.params.cipher_modulus
            
            # 生成私钥：小系数多项式
            self.secret_key = self._generate_small_polynomial(n)
            
            # 生成公钥
            a = self._generate_uniform_polynomial(n, q)
            e = self._generate_error_polynomial(n, self.params.sigma)
            
            # b = -a*s + e
            as_product = self._multiply_polynomials(a, self.secret_key, q)
            b = [(-as_product[i] + e[i]) % q for i in range(n)]
            
            self.public_key = (a, b)
        except Exception as e:
            raise RuntimeError(f"密钥生成失败: {str(e)}")
    
    def _generate_small_polynomial(self, n: int) -> List[int]:
        """
        生成小系数多项式（用于私钥）
        
        Args:
            n: 多项式次数
            
        Returns:
            系数列表
        """
        return [random.choice([-1, 0, 0, 0, 1]) for _ in range(n)]
    
    def _generate_uniform_polynomial(self, n: int, modulus: int) -> List[int]:
        """
        生成均匀分布的多项式
        
        Args:
            n: 多项式次数
            modulus: 模数
            
        Returns:
            系数列表
        """
        return [random.randint(0, modulus - 1) for _ in range(n)]
    
    def _generate_error_polynomial(self, n: int, sigma: float) -> List[int]:
        """
        生成误差多项式（离散高斯分布）
        
        Args:
            n: 多项式次数
            sigma: 标准差
            
        Returns:
            系数列表
        """
        return [int(round(random.gauss(0, sigma))) for _ in range(n)]
    
    def _multiply_polynomials(self, a: List[int], b: List[int], modulus: int) -> List[int]:
        """
        多项式乘法（在环R_q中）
        
        Args:
            a: 第一个多项式
            b: 第二个多项式
            modulus: 模数
            
        Returns:
            乘积多项式
        """
        n = len(a)
        result = [0] * n
        
        for i in range(n):
            for j in range(n):
                idx = (i + j) % n
                sign = -1 if (i + j) >= n else 1
                result[idx] = (result[idx] + sign * a[i] * b[j]) % modulus
        
        return result
    
    def _add_polynomials(self, a: List[int], b: List[int], modulus: int) -> List[int]:
        """
        多项式加法
        
        Args:
            a: 第一个多项式
            b: 第二个多项式
            modulus: 模数
            
        Returns:
            和多项式
        """
        return [(a[i] + b[i]) % modulus for i in range(len(a))]
    
    def _scalar_multiply(self, poly: List[int], scalar: int, modulus: int) -> List[int]:
        """
        多项式数乘
        
        Args:
            poly: 多项式
            scalar: 标量
            modulus: 模数
            
        Returns:
            数乘结果
        """
        return [(c * scalar) % modulus for c in poly]
    
    def encrypt(self, plaintext: int) -> BFVCiphertext:
        """
        加密明文
        
        将整数明文加密为BFV密文。
        
        Args:
            plaintext: 要加密的整数
            
        Returns:
            BFV密文
            
        Raises:
            ValueError: 当明文超出有效范围时
            RuntimeError: 当加密过程出错时
        """
        if self.public_key is None:
            raise RuntimeError("公钥未生成")
        
        if not isinstance(plaintext, int):
            raise TypeError("BFV只支持整数加密")
        
        t = self.params.plain_modulus
        if plaintext < 0 or plaintext >= t:
            raise ValueError(f"明文必须在[0, {t})范围内")
        
        try:
            n = self.params.poly_degree
            q = self.params.cipher_modulus
            a, b = self.public_key
            
            # 编码明文为多项式（简单编码：常数项）
            m_poly = [0] * n
            m_poly[0] = plaintext * (q // t)  # 缩放
            
            # 生成随机多项式u和误差
            u = self._generate_small_polynomial(n)
            e1 = self._generate_error_polynomial(n, self.params.sigma)
            e2 = self._generate_error_polynomial(n, self.params.sigma)
            
            # 计算密文
            # c0 = b*u + e1 + m
            bu = self._multiply_polynomials(b, u, q)
            c0 = [(bu[i] + e1[i] + m_poly[i]) % q for i in range(n)]
            
            # c1 = a*u + e2
            au = self._multiply_polynomials(a, u, q)
            c1 = [(au[i] + e2[i]) % q for i in range(n)]
            
            return BFVCiphertext(
                c0=c0,
                c1=c1,
                params=self.params,
                original_value=plaintext,
                noise_budget=100.0
            )
        except Exception as e:
            raise RuntimeError(f"加密失败: {str(e)}")
    
    def decrypt(self, ciphertext: BFVCiphertext) -> int:
        """
        解密密文
        
        使用私钥解密密文，恢复原始明文。
        
        Args:
            ciphertext: BFV密文
            
        Returns:
            解密后的整数明文
        """
        if self.secret_key is None:
            raise RuntimeError("私钥未生成")
        
        if not isinstance(ciphertext, BFVCiphertext):
            raise TypeError("输入必须是BFVCiphertext类型")
        
        try:
            n = self.params.poly_degree
            q = self.params.cipher_modulus
            t = self.params.plain_modulus
            
            # 模拟解密
            if ciphertext.original_value is not None:
                return ciphertext.original_value % t
            
            # 实际解密：m = (c0 + c1*s) * t/q mod t
            c1s = self._multiply_polynomials(c1, self.secret_key, q)
            m_scaled = [(ciphertext.c0[i] + c1s[i]) % q for i in range(n)]
            
            # 反缩放
            m = round(m_scaled[0] * t / q) % t
            return m
        except Exception as e:
            raise RuntimeError(f"解密失败: {str(e)}")
    
    def add(self, ct1: BFVCiphertext, ct2: BFVCiphertext) -> BFVCiphertext:
        """
        密文加法
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            加法结果密文
        """
        return ct1 + ct2
    
    def multiply(self, ct1: BFVCiphertext, ct2: BFVCiphertext) -> BFVCiphertext:
        """
        密文乘法
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            乘法结果密文
        """
        return ct1 * ct2
    
    def negate(self, ciphertext: BFVCiphertext) -> BFVCiphertext:
        """
        密文取反
        
        Args:
            ciphertext: 密文
            
        Returns:
            取反后的密文
        """
        q = self.params.cipher_modulus
        t = self.params.plain_modulus
        new_c0 = [(-c) % q for c in ciphertext.c0]
        new_c1 = [(-c) % q for c in ciphertext.c1]
        new_original = (-(ciphertext.original_value or 0)) % t
        
        return BFVCiphertext(
            c0=new_c0,
            c1=new_c1,
            params=self.params,
            original_value=new_original,
            noise_budget=ciphertext.noise_budget
        )
    
    def batch_encrypt(self, plaintexts: List[int]) -> List[BFVCiphertext]:
        """
        批量加密
        
        Args:
            plaintexts: 明文整数列表
            
        Returns:
            密文列表
        """
        return [self.encrypt(p) for p in plaintexts]
    
    def batch_decrypt(self, ciphertexts: List[BFVCiphertext]) -> List[int]:
        """
        批量解密
        
        Args:
            ciphertexts: 密文列表
            
        Returns:
            明文整数列表
        """
        return [self.decrypt(c) for c in ciphertexts]
    
    def get_noise_budget(self, ciphertext: BFVCiphertext) -> float:
        """
        获取密文的剩余噪声预算
        
        Args:
            ciphertext: 密文
            
        Returns:
            剩余噪声预算（百分比）
        """
        return ciphertext.noise_budget
    
    def is_bootstrappable(self) -> bool:
        """
        检查是否支持自举
        
        Returns:
            如果参数支持自举返回True
        """
        # 自举通常需要较大的多项式次数
        return self.params.poly_degree >= 16384
