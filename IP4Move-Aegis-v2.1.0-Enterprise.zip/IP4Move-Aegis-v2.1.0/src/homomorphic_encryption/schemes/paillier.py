"""
Paillier同态加密方案实现

Paillier加密是一种概率性非对称加密算法，具有同态加法性质：
- 支持密文加法：E(a) * E(b) = E(a + b)
- 支持密文与明文乘法：E(a)^b = E(a * b)

该实现使用模拟方式演示Paillier加密的核心概念。
"""

import random
import hashlib
from typing import Optional, Union, List
from dataclasses import dataclass


@dataclass
class PaillierKeyPair:
    """
    Paillier密钥对
    
    包含公钥和私钥，用于加密和解密操作。
    
    Attributes:
        public_key: 公钥，用于加密
        private_key: 私钥，用于解密
        n: 模数，由两个大素数乘积得到
        g: 生成元
    """
    public_key: tuple[int, int]  # (n, g)
    private_key: tuple[int, int]  # (lambda, mu)
    n: int
    g: int
    
    def __post_init__(self) -> None:
        """初始化后的验证"""
        if self.n <= 0:
            raise ValueError("模数n必须为正整数")
        if self.g <= 0:
            raise ValueError("生成元g必须为正整数")


@dataclass
class PaillierCiphertext:
    """
    Paillier密文
    
    存储加密后的数据，支持同态运算。
    
    Attributes:
        value: 密文数值
        n: 模数
        original_value: 原始明文值（模拟存储，实际加密中不存在）
        noise: 随机噪声（模拟Paillier的概率性特性）
    """
    value: int
    n: int
    original_value: Optional[int] = None
    noise: int = 0
    
    def __post_init__(self) -> None:
        """初始化后的验证"""
        if self.n <= 0:
            raise ValueError("模数n必须为正整数")
    
    def __add__(self, other: Union['PaillierCiphertext', int]) -> 'PaillierCiphertext':
        """
        密文加法运算（同态加法）
        
        支持：
        - 密文 + 密文 = 密文（对应明文相加）
        - 密文 + 明文 = 密文（对应明文相加）
        
        Args:
            other: 另一个密文或明文整数
            
        Returns:
            加法运算后的新密文
            
        Raises:
            ValueError: 当两个密文使用不同模数时
            TypeError: 当操作数类型不支持时
        """
        if isinstance(other, PaillierCiphertext):
            if self.n != other.n:
                raise ValueError("两个密文必须使用相同的模数")
            # 模拟同态加法：密文相乘对应明文相加
            new_value = (self.value * other.value) % (self.n * self.n)
            new_original = (self.original_value or 0) + (other.original_value or 0)
            return PaillierCiphertext(
                value=new_value,
                n=self.n,
                original_value=new_original,
                noise=self.noise + other.noise
            )
        elif isinstance(other, int):
            # 密文与明文相加
            new_value = (self.value + other) % (self.n * self.n)
            new_original = (self.original_value or 0) + other
            return PaillierCiphertext(
                value=new_value,
                n=self.n,
                original_value=new_original,
                noise=self.noise
            )
        else:
            raise TypeError(f"不支持与{type(other)}类型相加")
    
    def __radd__(self, other: int) -> 'PaillierCiphertext':
        """右加法支持"""
        return self.__add__(other)
    
    def __mul__(self, other: int) -> 'PaillierCiphertext':
        """
        密文与明文乘法运算（同态乘法）
        
        Paillier支持密文与明文相乘，对应明文相乘。
        
        Args:
            other: 明文整数
            
        Returns:
            乘法运算后的新密文
            
        Raises:
            TypeError: 当乘数不是整数时
        """
        if not isinstance(other, int):
            raise TypeError("Paillier密文只能与整数相乘")
        
        # 模拟同态乘法：密文的幂次对应明文相乘
        new_value = pow(self.value, other, self.n * self.n)
        new_original = (self.original_value or 0) * other
        return PaillierCiphertext(
            value=new_value,
            n=self.n,
            original_value=new_original,
            noise=self.noise * other
        )
    
    def __rmul__(self, other: int) -> 'PaillierCiphertext':
        """右乘法支持"""
        return self.__mul__(other)
    
    def __repr__(self) -> str:
        """字符串表示"""
        return f"PaillierCiphertext(value={self.value}, n={self.n})"


class PaillierScheme:
    """
    Paillier同态加密方案
    
    实现Paillier加密算法的核心功能，包括密钥生成、加密和解密。
    这是一个模拟实现，用于演示Paillier加密的同态特性。
    
    Attributes:
        key_size: 密钥位数
        key_pair: 密钥对
    
    Example:
        >>> scheme = PaillierScheme(key_size=1024)
        >>> ct1 = scheme.encrypt(100)
        >>> ct2 = scheme.encrypt(200)
        >>> ct_sum = ct1 + ct2  # 同态加法
        >>> result = scheme.decrypt(ct_sum)  # 结果应为300
    """
    
    def __init__(self, key_size: int = 2048) -> None:
        """
        初始化Paillier加密方案
        
        Args:
            key_size: 密钥位数，默认为2048位
            
        Raises:
            ValueError: 当密钥大小不合法时
        """
        if key_size < 512:
            raise ValueError("密钥大小至少为512位")
        if key_size > 4096:
            raise ValueError("密钥大小不能超过4096位")
            
        self.key_size = key_size
        self.key_pair: Optional[PaillierKeyPair] = None
        self._generate_keys()
    
    def _generate_keys(self) -> None:
        """
        生成Paillier密钥对
        
        模拟密钥生成过程，实际应用中应使用安全的大素数。
        """
        try:
            # 模拟生成大素数（实际应用中使用加密安全的随机数）
            # 这里使用固定种子以确保可重复性
            random.seed(42)
            
            # 生成模拟的模数n（实际应为两个大素数的乘积）
            bit_length = self.key_size // 2
            p = self._generate_prime(bit_length)
            q = self._generate_prime(bit_length)
            n = p * q
            
            # 计算lambda = lcm(p-1, q-1)
            lambda_val = (p - 1) * (q - 1) // self._gcd(p - 1, q - 1)
            
            # 选择生成元g
            g = n + 1  # 简化选择
            
            # 计算mu = (L(g^lambda mod n^2))^-1 mod n
            # L(u) = (u - 1) / n
            n_square = n * n
            g_lambda = pow(g, lambda_val, n_square)
            l_g_lambda = (g_lambda - 1) // n
            mu = self._mod_inverse(l_g_lambda, n)
            
            self.key_pair = PaillierKeyPair(
                public_key=(n, g),
                private_key=(lambda_val, mu),
                n=n,
                g=g
            )
        except Exception as e:
            raise RuntimeError(f"密钥生成失败: {str(e)}")
    
    def _generate_prime(self, bits: int) -> int:
        """
        生成指定位数的素数（模拟）
        
        Args:
            bits: 位数
            
        Returns:
            模拟的素数
        """
        # 模拟素数生成（实际应使用素性测试）
        lower = 1 << (bits - 1)
        upper = (1 << bits) - 1
        return random.randint(lower, upper) | 1  # 确保为奇数
    
    def _gcd(self, a: int, b: int) -> int:
        """计算最大公约数"""
        while b:
            a, b = b, a % b
        return a
    
    def _mod_inverse(self, a: int, m: int) -> int:
        """
        计算模逆元
        
        Args:
            a: 整数
            m: 模数
            
        Returns:
            a的模逆元
            
        Raises:
            ValueError: 当逆元不存在时
        """
        def extended_gcd(a: int, b: int) -> tuple[int, int, int]:
            if a == 0:
                return b, 0, 1
            gcd, x1, y1 = extended_gcd(b % a, a)
            x = y1 - (b // a) * x1
            y = x1
            return gcd, x, y
        
        gcd, x, _ = extended_gcd(a % m, m)
        if gcd != 1:
            raise ValueError("模逆元不存在")
        return (x % m + m) % m
    
    def encrypt(self, plaintext: int) -> PaillierCiphertext:
        """
        加密明文
        
        使用公钥加密整数明文，生成Paillier密文。
        
        Args:
            plaintext: 要加密的整数
            
        Returns:
            Paillier密文
            
        Raises:
            ValueError: 当明文超出有效范围时
            RuntimeError: 当加密过程出错时
        """
        if self.key_pair is None:
            raise RuntimeError("密钥对未生成")
        
        if not isinstance(plaintext, int):
            raise TypeError("Paillier只支持整数加密")
        
        # 检查明文范围（应小于n）
        if plaintext < 0 or plaintext >= self.key_pair.n:
            raise ValueError(f"明文必须在[0, {self.key_pair.n})范围内")
        
        try:
            n = self.key_pair.n
            g = self.key_pair.g
            n_square = n * n
            
            # 生成随机数r（与n互质）
            r = random.randint(1, n - 1)
            while self._gcd(r, n) != 1:
                r = random.randint(1, n - 1)
            
            # 计算密文：c = g^m * r^n mod n^2
            # 模拟加密过程
            g_m = pow(g, plaintext, n_square)
            r_n = pow(r, n, n_square)
            ciphertext_value = (g_m * r_n) % n_square
            
            # 添加随机噪声以模拟概率加密
            noise = random.randint(1, 1000)
            
            return PaillierCiphertext(
                value=ciphertext_value,
                n=n,
                original_value=plaintext,  # 模拟存储（实际加密中不存在）
                noise=noise
            )
        except Exception as e:
            raise RuntimeError(f"加密失败: {str(e)}")
    
    def decrypt(self, ciphertext: PaillierCiphertext) -> int:
        """
        解密密文
        
        使用私钥解密密文，恢复原始明文。
        
        Args:
            ciphertext: Paillier密文
            
        Returns:
            解密后的整数明文
            
        Raises:
            ValueError: 当密文格式不正确时
            RuntimeError: 当解密过程出错时
        """
        if self.key_pair is None:
            raise RuntimeError("密钥对未生成")
        
        if not isinstance(ciphertext, PaillierCiphertext):
            raise TypeError("输入必须是PaillierCiphertext类型")
        
        if ciphertext.n != self.key_pair.n:
            raise ValueError("密文与当前密钥不匹配")
        
        try:
            # 模拟解密过程
            # 实际解密：m = L(c^lambda mod n^2) * mu mod n
            # 这里使用模拟值
            
            # 在模拟中，我们使用存储的原始值
            if ciphertext.original_value is not None:
                return ciphertext.original_value
            
            # 如果没有存储原始值，返回模拟值
            lambda_val, mu = self.key_pair.private_key
            n = self.key_pair.n
            n_square = n * n
            
            c_lambda = pow(ciphertext.value, lambda_val, n_square)
            l_c = (c_lambda - 1) // n
            plaintext = (l_c * mu) % n
            
            return plaintext
        except Exception as e:
            raise RuntimeError(f"解密失败: {str(e)}")
    
    def add(self, ct1: PaillierCiphertext, ct2: PaillierCiphertext) -> PaillierCiphertext:
        """
        密文加法
        
        对两个密文进行同态加法运算。
        
        Args:
            ct1: 第一个密文
            ct2: 第二个密文
            
        Returns:
            加法结果密文
        """
        return ct1 + ct2
    
    def add_plaintext(self, ciphertext: PaillierCiphertext, plaintext: int) -> PaillierCiphertext:
        """
        密文与明文相加
        
        将密文与明文整数相加。
        
        Args:
            ciphertext: 密文
            plaintext: 明文整数
            
        Returns:
            加法结果密文
        """
        return ciphertext + plaintext
    
    def multiply(self, ciphertext: PaillierCiphertext, plaintext: int) -> PaillierCiphertext:
        """
        密文与明文相乘
        
        将密文与明文整数相乘（同态乘法）。
        
        Args:
            ciphertext: 密文
            plaintext: 明文整数
            
        Returns:
            乘法结果密文
        """
        return ciphertext * plaintext
    
    def batch_encrypt(self, plaintexts: List[int]) -> List[PaillierCiphertext]:
        """
        批量加密
        
        一次性加密多个明文值。
        
        Args:
            plaintexts: 明文整数列表
            
        Returns:
            密文列表
        """
        return [self.encrypt(p) for p in plaintexts]
    
    def batch_decrypt(self, ciphertexts: List[PaillierCiphertext]) -> List[int]:
        """
        批量解密
        
        一次性解密多个密文。
        
        Args:
            ciphertexts: 密文列表
            
        Returns:
            明文整数列表
        """
        return [self.decrypt(c) for c in ciphertexts]
    
    def get_public_key(self) -> tuple[int, int]:
        """
        获取公钥
        
        Returns:
            公钥元组(n, g)
        """
        if self.key_pair is None:
            raise RuntimeError("密钥对未生成")
        return self.key_pair.public_key
    
    def reseed(self, seed: int) -> None:
        """
        重新设置随机种子
        
        用于测试和可重复性。
        
        Args:
            seed: 随机种子
        """
        random.seed(seed)
