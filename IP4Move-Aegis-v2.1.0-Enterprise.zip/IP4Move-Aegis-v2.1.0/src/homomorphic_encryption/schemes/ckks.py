"""
CKKS（Cheon-Kim-Kim-Song）全同态加密方案实现

CKKS是一种基于RLWE问题的全同态加密方案，专为浮点数和复数运算设计。
支持在密文上进行近似计算，适用于机器学习等需要实数运算的场景。

特性：
- 支持浮点数和复数运算
- 基于多项式环运算
- 支持重缩放（rescaling）管理精度
- 支持打包多个值进行SIMD式计算

该实现使用模拟方式演示CKKS加密的核心概念。
"""

import random
import math
import cmath
from typing import Optional, Union, List, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
import copy


class CKKSSecurityLevel(Enum):
    """CKKS安全级别枚举"""
    TC128 = 128    # 128位安全（传统）
    TC192 = 192    # 192位安全（传统）
    TC256 = 256    # 256位安全（传统）


@dataclass
class CKKSParameters:
    """
    CKKS方案参数
    
    定义CKKS加密方案的数学参数，影响安全性、精度和性能。
    
    Attributes:
        poly_degree: 多项式次数（环维度），必须是2的幂
        coeff_moduli: 系数模数链（用于重缩放）
        scale: 缩放因子，决定精度
        security_level: 安全级别
        num_slots: 打包槽位数（等于poly_degree/2）
    """
    poly_degree: int = 8192
    coeff_moduli: List[int] = field(default_factory=lambda: [60, 40, 40, 60])
    scale: float = 2**40
    security_level: CKKSSecurityLevel = CKKSSecurityLevel.TC128
    
    def __post_init__(self) -> None:
        """参数验证"""
        # 验证多项式次数
        if self.poly_degree <= 0 or (self.poly_degree & (self.poly_degree - 1)) != 0:
            raise ValueError("多项式次数必须是2的幂（如2048, 4096, 8192, 16384）")
        
        # 验证系数模数链
        if not self.coeff_moduli or len(self.coeff_moduli) < 2:
            raise ValueError("系数模数链至少需要2个模数")
        
        # 验证缩放因子
        if self.scale <= 0:
            raise ValueError("缩放因子必须为正数")
    
    @property
    def num_slots(self) -> int:
        """获取打包槽位数"""
        return self.poly_degree // 2
    
    @property
    def total_coeff_modulus(self) -> int:
        """获取总系数模数（乘积）"""
        result = 1
        for mod in self.coeff_moduli:
            result *= mod
        return result
    
    def get_modulus_at_level(self, level: int) -> int:
        """
        获取指定层级的模数
        
        Args:
            level: 层级索引
            
        Returns:
            该层级的模数
        """
        if level < 0 or level >= len(self.coeff_moduli):
            raise ValueError(f"层级必须在[0, {len(self.coeff_moduli)})范围内")
        return self.coeff_moduli[level]


@dataclass
class CKKSCiphertext:
    """
    CKKS密文
    
    CKKS密文由两个多项式组成：(c0, c1)
    支持打包多个复数进行SIMD计算。
    
    Attributes:
        c0: 第一个密文多项式（系数列表）
        c1: 第二个密文多项式（系数列表）
        params: CKKS参数
        level: 当前层级（用于重缩放）
        scale: 当前缩放因子
        original_values: 原始明文值列表（模拟存储）
        noise_budget: 剩余噪声预算
    """
    c0: List[int]
    c1: List[int]
    params: CKKSParameters
    level: int = 0
    scale: float = 1.0
    original_values: Optional[List[complex]] = None
    noise_budget: float = 100.0
    
    def __post_init__(self) -> None:
        """验证密文格式"""
        if len(self.c0) != self.params.poly_degree or len(self.c1) != self.params.poly_degree:
            raise ValueError(f"密文多项式长度必须等于多项式次数{self.params.poly_degree}")
        if self.level < 0 or self.level >= len(self.params.coeff_moduli):
            raise ValueError(f"层级必须在有效范围内")
    
    def __add__(self, other: Union['CKKSCiphertext', List[complex], complex, float, int]) -> 'CKKSCiphertext':
        """
        密文加法运算
        
        支持：
        - 密文 + 密文
        - 密文 + 明文向量
        - 密文 + 标量
        
        Args:
            other: 另一个密文、明文向量或标量
            
        Returns:
            加法结果密文
        """
        q = self.params.total_coeff_modulus
        
        if isinstance(other, CKKSCiphertext):
            if self.params != other.params:
                raise ValueError("两个密文必须使用相同的参数")
            if self.level != other.level:
                raise ValueError("两个密文必须在相同层级")
            # 密文-密文加法
            new_c0 = [(self.c0[i] + other.c0[i]) % q for i in range(self.params.poly_degree)]
            new_c1 = [(self.c1[i] + other.c1[i]) % q for i in range(self.params.poly_degree)]
            new_original = self._add_vectors(self.original_values, other.original_values)
            new_noise = min(self.noise_budget, other.noise_budget) - 1
        elif isinstance(other, list):
            # 密文 + 明文向量
            new_c0 = self.c0.copy()
            # 模拟编码和加法
            for i, val in enumerate(other[:self.params.num_slots]):
                new_c0[i] = (new_c0[i] + int(val.real * self.scale)) % q
            new_original = self._add_vectors(self.original_values, other)
            new_noise = self.noise_budget - 0.5
        elif isinstance(other, (complex, float, int)):
            # 密文 + 标量
            new_c0 = self.c0.copy()
            new_c0[0] = (new_c0[0] + int(other * self.scale)) % q
            scalar_list = [other] * self.params.num_slots
            new_original = self._add_vectors(self.original_values, scalar_list)
            new_noise = self.noise_budget - 0.5
        else:
            raise TypeError(f"不支持与{type(other)}类型相加")
        
        return CKKSCiphertext(
            c0=new_c0,
            c1=new_c1,
            params=self.params,
            level=self.level,
            scale=self.scale,
            original_values=new_original,
            noise_budget=max(0, new_noise)
        )
    
    def __radd__(self, other: Union[List[complex], complex, float, int]) -> 'CKKSCiphertext':
        """右加法支持"""
        return self.__add__(other)
    
    def __sub__(self, other: Union['CKKSCiphertext', List[complex], complex, float, int]) -> 'CKKSCiphertext':
        """
        密文减法运算
        
        Args:
            other: 另一个密文、明文向量或标量
            
        Returns:
            减法结果密文
        """
        q = self.params.total_coeff_modulus
        
        if isinstance(other, CKKSCiphertext):
            if self.params != other.params:
                raise ValueError("两个密文必须使用相同的参数")
            if self.level != other.level:
                raise ValueError("两个密文必须在相同层级")
            new_c0 = [(self.c0[i] - other.c0[i]) % q for i in range(self.params.poly_degree)]
            new_c1 = [(self.c1[i] - other.c1[i]) % q for i in range(self.params.poly_degree)]
            new_original = self._sub_vectors(self.original_values, other.original_values)
            new_noise = min(self.noise_budget, other.noise_budget) - 1
        elif isinstance(other, list):
            new_c0 = self.c0.copy()
            for i, val in enumerate(other[:self.params.num_slots]):
                new_c0[i] = (new_c0[i] - int(val.real * self.scale)) % q
            new_original = self._sub_vectors(self.original_values, other)
            new_noise = self.noise_budget - 0.5
        elif isinstance(other, (complex, float, int)):
            new_c0 = self.c0.copy()
            new_c0[0] = (new_c0[0] - int(other * self.scale)) % q
            scalar_list = [other] * self.params.num_slots
            new_original = self._sub_vectors(self.original_values, scalar_list)
            new_noise = self.noise_budget - 0.5
        else:
            raise TypeError(f"不支持与{type(other)}类型相减")
        
        return CKKSCiphertext(
            c0=new_c0,
            c1=new_c1,
            params=self.params,
            level=self.level,
            scale=self.scale,
            original_values=new_original,
            noise_budget=max(0, new_noise)
        )
    
    def __rsub__(self, other: Union[List[complex], complex, float, int]) -> 'CKKSCiphertext':
        """右减法支持"""
        result = self.__sub__(other)
        q = self.params.total_coeff_modulus
        result.c0 = [(-c) % q for c in result.c0]
        result.c1 = [(-c) % q for c in result.c1]
        return result
    
    def __mul__(self, other: Union['CKKSCiphertext', List[complex], complex, float, int]) -> 'CKKSCiphertext':
        """
        密文乘法运算
        
        注意：密文-密文乘法后需要重缩放。
        
        Args:
            other: 另一个密文、明文向量或标量
            
        Returns:
            乘法结果密文
        """
        q = self.params.total_coeff_modulus
        
        if isinstance(other, CKKSCiphertext):
            if self.params != other.params:
                raise ValueError("两个密文必须使用相同的参数")
            if self.level != other.level:
                raise ValueError("两个密文必须在相同层级")
            # 密文-密文乘法（简化模拟）
            new_c0 = [0] * self.params.poly_degree
            new_c1 = [0] * self.params.poly_degree
            for i in range(self.params.poly_degree):
                new_c0[i] = (self.c0[i] * other.c0[i]) % q
                new_c1[i] = (self.c0[i] * other.c1[i] + self.c1[i] * other.c0[i]) % q
            new_original = self._mul_vectors(self.original_values, other.original_values)
            new_scale = self.scale * other.scale
            new_noise = min(self.noise_budget, other.noise_budget) - 5
        elif isinstance(other, list):
            # 密文 * 明文向量
            new_c0 = self.c0.copy()
            for i, val in enumerate(other[:self.params.num_slots]):
                new_c0[i] = (new_c0[i] * int(val.real)) % q
            new_c1 = [(c * int(other[0].real if other else 1)) % q for c in self.c1]
            new_original = self._mul_vectors(self.original_values, other)
            new_scale = self.scale
            new_noise = self.noise_budget - 1
        elif isinstance(other, (complex, float, int)):
            # 密文 * 标量
            scalar = int(other)
            new_c0 = [(c * scalar) % q for c in self.c0]
            new_c1 = [(c * scalar) % q for c in self.c1]
            scalar_list = [other] * self.params.num_slots
            new_original = self._mul_vectors(self.original_values, scalar_list)
            new_scale = self.scale
            new_noise = self.noise_budget - 1
        else:
            raise TypeError(f"不支持与{type(other)}类型相乘")
        
        return CKKSCiphertext(
            c0=new_c0,
            c1=new_c1,
            params=self.params,
            level=self.level,
            scale=new_scale,
            original_values=new_original,
            noise_budget=max(0, new_noise)
        )
    
    def __rmul__(self, other: Union[List[complex], complex, float, int]) -> 'CKKSCiphertext':
        """右乘法支持"""
        return self.__mul__(other)
    
    def _add_vectors(self, a: Optional[List[complex]], b: Optional[List[complex]]) -> Optional[List[complex]]:
        """向量加法"""
        if a is None or b is None:
            return None
        n = min(len(a), len(b), self.params.num_slots)
        return [a[i] + b[i] for i in range(n)]
    
    def _sub_vectors(self, a: Optional[List[complex]], b: Optional[List[complex]]) -> Optional[List[complex]]:
        """向量减法"""
        if a is None or b is None:
            return None
        n = min(len(a), len(b), self.params.num_slots)
        return [a[i] - b[i] for i in range(n)]
    
    def _mul_vectors(self, a: Optional[List[complex]], b: Optional[List[complex]]) -> Optional[List[complex]]:
        """向量逐元素乘法"""
        if a is None or b is None:
            return None
        n = min(len(a), len(b), self.params.num_slots)
        return [a[i] * b[i] for i in range(n)]
    
    def __repr__(self) -> str:
        """字符串表示"""
        return f"CKKSCiphertext(degree={self.params.poly_degree}, level={self.level}, scale={self.scale:.2e})"
    
    def is_valid(self) -> bool:
        """检查密文是否有效"""
        return self.noise_budget > 0 and self.level < len(self.params.coeff_moduli)


class CKKSScheme:
    """
    CKKS全同态加密方案
    
    实现CKKS加密算法的核心功能，支持浮点数和复数上的全同态运算。
    特别适合机器学习和数据分析场景。
    
    Attributes:
        params: CKKS参数
        secret_key: 私钥多项式
        public_key: 公钥
    
    Example:
        >>> params = CKKSParameters(poly_degree=8192, scale=2**40)
        >>> scheme = CKKSScheme(params)
        >>> values = [1.5, 2.5, 3.5, 4.5]
        >>> ct = scheme.encrypt(values)
        >>> ct_squared = ct * ct  # 逐元素平方
        >>> result = scheme.decrypt(ct_squared)
    """
    
    def __init__(self, params: Optional[CKKSParameters] = None) -> None:
        """
        初始化CKKS加密方案
        
        Args:
            params: CKKS参数，如果为None则使用默认参数
        """
        self.params = params or CKKSParameters()
        self.secret_key: Optional[List[int]] = None
        self.public_key: Optional[Tuple[List[int], List[int]]] = None
        self._generate_keys()
    
    def _generate_keys(self) -> None:
        """生成CKKS密钥对"""
        try:
            n = self.params.poly_degree
            q = self.params.total_coeff_modulus
            
            # 生成私钥：小系数多项式
            self.secret_key = self._generate_small_polynomial(n)
            
            # 生成公钥
            a = self._generate_uniform_polynomial(n, q)
            e = self._generate_error_polynomial(n, 3.2)
            
            # b = -a*s + e
            as_product = self._multiply_polynomials(a, self.secret_key, q)
            b = [(-as_product[i] + e[i]) % q for i in range(n)]
            
            self.public_key = (a, b)
        except Exception as e:
            raise RuntimeError(f"密钥生成失败: {str(e)}")
    
    def _generate_small_polynomial(self, n: int) -> List[int]:
        """生成小系数多项式"""
        return [random.choice([-1, 0, 0, 0, 1]) for _ in range(n)]
    
    def _generate_uniform_polynomial(self, n: int, modulus: int) -> List[int]:
        """生成均匀分布的多项式"""
        return [random.randint(0, modulus - 1) for _ in range(n)]
    
    def _generate_error_polynomial(self, n: int, sigma: float) -> List[int]:
        """生成误差多项式"""
        return [int(round(random.gauss(0, sigma))) for _ in range(n)]
    
    def _multiply_polynomials(self, a: List[int], b: List[int], modulus: int) -> List[int]:
        """多项式乘法（在环R_q中）"""
        n = len(a)
        result = [0] * n
        
        for i in range(n):
            for j in range(n):
                idx = (i + j) % n
                sign = -1 if (i + j) >= n else 1
                result[idx] = (result[idx] + sign * a[i] * b[j]) % modulus
        
        return result
    
    def _encode(self, values: List[complex]) -> List[int]:
        """
        编码复数向量为多项式
        
        使用逆FFT（Number Theoretic Transform的模拟）进行编码。
        
        Args:
            values: 复数向量
            
        Returns:
            编码后的多项式系数
        """
        n = self.params.poly_degree
        slots = self.params.num_slots
        
        # 填充或截断到槽位数
        padded = values[:slots] + [0] * (slots - len(values))
        
        # 模拟编码（实际应使用NTT/FFT）
        # 这里简单地将值映射到多项式系数
        coeffs = [0] * n
        scale = int(self.params.scale)
        
        for i, val in enumerate(padded):
            coeffs[i] = int(val.real * scale)
            if i + slots < n:
                coeffs[i + slots] = int(val.imag * scale)
        
        return coeffs
    
    def _decode(self, coeffs: List[int]) -> List[complex]:
        """
        解码多项式为复数向量
        
        Args:
            coeffs: 多项式系数
            
        Returns:
            解码后的复数向量
        """
        slots = self.params.num_slots
        scale = self.params.scale
        
        values = []
        for i in range(slots):
            real = coeffs[i] / scale
            imag = coeffs[i + slots] / scale if i + slots < len(coeffs) else 0
            values.append(complex(real, imag))
        
        return values
    
    def encrypt(self, values: Union[List[float], List[complex], float, complex]) -> CKKSCiphertext:
        """
        加密明文
        
        将浮点数或复数向量加密为CKKS密文。
        
        Args:
            values: 要加密的值（标量或向量）
            
        Returns:
            CKKS密文
        """
        if self.public_key is None:
            raise RuntimeError("公钥未生成")
        
        # 统一转换为复数列表
        if isinstance(values, (float, int)):
            values = [complex(float(values), 0)] * self.params.num_slots
        elif isinstance(values, complex):
            values = [values] * self.params.num_slots
        elif isinstance(values, list):
            values = [complex(v) if not isinstance(v, complex) else v for v in values]
        else:
            raise TypeError("不支持的明文类型")
        
        try:
            n = self.params.poly_degree
            q = self.params.total_coeff_modulus
            a, b = self.public_key
            
            # 编码明文
            m_poly = self._encode(values)
            
            # 生成随机多项式u和误差
            u = self._generate_small_polynomial(n)
            e1 = self._generate_error_polynomial(n, 3.2)
            e2 = self._generate_error_polynomial(n, 3.2)
            
            # 计算密文
            bu = self._multiply_polynomials(b, u, q)
            c0 = [(bu[i] + e1[i] + m_poly[i]) % q for i in range(n)]
            
            au = self._multiply_polynomials(a, u, q)
            c1 = [(au[i] + e2[i]) % q for i in range(n)]
            
            return CKKSCiphertext(
                c0=c0,
                c1=c1,
                params=self.params,
                level=0,
                scale=self.params.scale,
                original_values=values[:self.params.num_slots],
                noise_budget=100.0
            )
        except Exception as e:
            raise RuntimeError(f"加密失败: {str(e)}")
    
    def decrypt(self, ciphertext: CKKSCiphertext) -> List[complex]:
        """
        解密密文
        
        Args:
            ciphertext: CKKS密文
            
        Returns:
            解密后的复数向量
        """
        if self.secret_key is None:
            raise RuntimeError("私钥未生成")
        
        if not isinstance(ciphertext, CKKSCiphertext):
            raise TypeError("输入必须是CKKSCiphertext类型")
        
        try:
            # 模拟解密
            if ciphertext.original_values is not None:
                # 反缩放
                scale_factor = ciphertext.scale / self.params.scale
                return [v / scale_factor for v in ciphertext.original_values]
            
            # 实际解密
            n = self.params.poly_degree
            q = self.params.total_coeff_modulus
            
            c1s = self._multiply_polynomials(ciphertext.c1, self.secret_key, q)
            m_poly = [(ciphertext.c0[i] + c1s[i]) % q for i in range(n)]
            
            return self._decode(m_poly)
        except Exception as e:
            raise RuntimeError(f"解密失败: {str(e)}")
    
    def rescale(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """
        重缩放密文
        
        降低密文层级并调整缩放因子，用于管理乘法后的精度。
        
        Args:
            ciphertext: 密文
            
        Returns:
            重缩放后的密文
        """
        if ciphertext.level >= len(self.params.coeff_moduli) - 1:
            raise ValueError("密文已经在最低层级，无法继续重缩放")
        
        new_level = ciphertext.level + 1
        new_scale = ciphertext.scale / self.params.coeff_moduli[new_level]
        
        return CKKSCiphertext(
            c0=ciphertext.c0.copy(),
            c1=ciphertext.c1.copy(),
            params=ciphertext.params,
            level=new_level,
            scale=new_scale,
            original_values=ciphertext.original_values,
            noise_budget=ciphertext.noise_budget
        )
    
    def add(self, ct1: CKKSCiphertext, ct2: CKKSCiphertext) -> CKKSCiphertext:
        """密文加法"""
        return ct1 + ct2
    
    def multiply(self, ct1: CKKSCiphertext, ct2: CKKSCiphertext) -> CKKSCiphertext:
        """密文乘法"""
        return ct1 * ct2
    
    def negate(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """密文取反"""
        q = self.params.total_coeff_modulus
        new_c0 = [(-c) % q for c in ciphertext.c0]
        new_c1 = [(-c) % q for c in ciphertext.c1]
        new_original = None
        if ciphertext.original_values:
            new_original = [-v for v in ciphertext.original_values]
        
        return CKKSCiphertext(
            c0=new_c0,
            c1=new_c1,
            params=ciphertext.params,
            level=ciphertext.level,
            scale=ciphertext.scale,
            original_values=new_original,
            noise_budget=ciphertext.noise_budget
        )
    
    def rotate(self, ciphertext: CKKSCiphertext, steps: int) -> CKKSCiphertext:
        """
        旋转密文（循环移位）
        
        Args:
            ciphertext: 密文
            steps: 旋转步数（正数向右，负数向左）
            
        Returns:
            旋转后的密文
        """
        if ciphertext.original_values is None:
            raise ValueError("无法旋转没有原始值的密文")
        
        n = len(ciphertext.original_values)
        steps = steps % n
        rotated = ciphertext.original_values[-steps:] + ciphertext.original_values[:-steps]
        
        return CKKSCiphertext(
            c0=ciphertext.c0.copy(),
            c1=ciphertext.c1.copy(),
            params=ciphertext.params,
            level=ciphertext.level,
            scale=ciphertext.scale,
            original_values=rotated,
            noise_budget=ciphertext.noise_budget - 2
        )
    
    def conjugate(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """
        共轭运算（复数共轭）
        
        Args:
            ciphertext: 密文
            
        Returns:
            共轭后的密文
        """
        if ciphertext.original_values is None:
            raise ValueError("无法对没有原始值的密文进行共轭")
        
        conjugated = [v.conjugate() for v in ciphertext.original_values]
        
        return CKKSCiphertext(
            c0=ciphertext.c0.copy(),
            c1=ciphertext.c1.copy(),
            params=ciphertext.params,
            level=ciphertext.level,
            scale=ciphertext.scale,
            original_values=conjugated,
            noise_budget=ciphertext.noise_budget - 1
        )
    
    def sum_slots(self, ciphertext: CKKSCiphertext) -> CKKSCiphertext:
        """
        对所有槽位求和
        
        Args:
            ciphertext: 密文
            
        Returns:
            求和后的密文（结果在所有槽位中相同）
        """
        if ciphertext.original_values is None:
            raise ValueError("无法对没有原始值的密文求和")
        
        total = sum(ciphertext.original_values)
        summed = [total] * len(ciphertext.original_values)
        
        return CKKSCiphertext(
            c0=ciphertext.c0.copy(),
            c1=ciphertext.c1.copy(),
            params=ciphertext.params,
            level=ciphertext.level,
            scale=ciphertext.scale,
            original_values=summed,
            noise_budget=ciphertext.noise_budget - 5
        )
    
    def get_noise_budget(self, ciphertext: CKKSCiphertext) -> float:
        """获取剩余噪声预算"""
        return ciphertext.noise_budget
    
    def get_level(self, ciphertext: CKKSCiphertext) -> int:
        """获取密文层级"""
        return ciphertext.level
