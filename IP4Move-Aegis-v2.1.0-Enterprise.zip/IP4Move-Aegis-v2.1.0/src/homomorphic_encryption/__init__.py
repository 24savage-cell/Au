"""
同态加密模块

提供Paillier、BFV、CKKS等全同态加密方案实现
支持密文计算和隐私保护数据分析
"""

from .schemes.paillier import PaillierScheme, PaillierKeyPair, PaillierCiphertext
from .schemes.bfv import BFVScheme, BFVParameters, BFVCiphertext
from .schemes.ckks import CKKSScheme, CKKSParameters, CKKSCiphertext
from .operations.encrypted_ops import EncryptedOperations
from .operations.matrix_ops import EncryptedMatrixOperations

__version__ = "1.0.0"
__all__ = [
    # Paillier
    "PaillierScheme",
    "PaillierKeyPair", 
    "PaillierCiphertext",
    # BFV
    "BFVScheme",
    "BFVParameters",
    "BFVCiphertext",
    # CKKS
    "CKKSScheme",
    "CKKSParameters",
    "CKKSCiphertext",
    # Operations
    "EncryptedOperations",
    "EncryptedMatrixOperations",
]
