"""
证书固定模块

防止中间人攻击，确保连接的是预期的服务器。
"""
import hashlib
import ssl
import base64
from typing import Set, Optional, List


class CertificatePinner:
    """证书固定器"""
    
    def __init__(self):
        self._pins: Set[str] = set()
    
    def add_pin(self, cert_der: bytes) -> None:
        """添加证书指纹"""
        fingerprint = hashlib.sha256(cert_der).hexdigest()
        self._pins.add(fingerprint)
    
    def add_pin_base64(self, pin_base64: str) -> None:
        """从 base64 添加指纹"""
        cert_der = base64.b64decode(pin_base64)
        self.add_pin(cert_der)
    
    def add_pin_hex(self, pin_hex: str) -> None:
        """从十六进制字符串添加指纹"""
        self._pins.add(pin_hex.lower())
    
    def check(self, cert_der: bytes) -> bool:
        """检查证书是否匹配"""
        fingerprint = hashlib.sha256(cert_der).hexdigest()
        return fingerprint in self._pins
    
    def check_hex(self, pin_hex: str) -> bool:
        """检查十六进制指纹是否匹配"""
        return pin_hex.lower() in self._pins
    
    def remove_pin(self, pin_hex: str) -> bool:
        """移除指定指纹"""
        pin_lower = pin_hex.lower()
        if pin_lower in self._pins:
            self._pins.remove(pin_lower)
            return True
        return False
    
    def clear_pins(self) -> None:
        """清除所有指纹"""
        self._pins.clear()
    
    @property
    def pin_count(self) -> int:
        """获取指纹数量"""
        return len(self._pins)
    
    @property
    def pins(self) -> List[str]:
        """获取所有指纹"""
        return list(self._pins)
    
    def create_ssl_context(self) -> ssl.SSLContext:
        """创建带证书固定的 SSL 上下文"""
        context = ssl.create_default_context()
        # 这里应该添加自定义验证回调
        # 实际实现需要使用 OpenSSL 库进行更细粒度的控制
        return context


class PinningHTTPSConnection:
    """
    带证书固定的 HTTPS 连接
    
    使用示例:
        pinner = CertificatePinner()
        pinner.add_pin_hex("sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
        conn = PinningHTTPSConnection("example.com", 443, pinner)
        conn.connect()
    """
    
    def __init__(self, host: str, port: int = 443, pinner: Optional[CertificatePinner] = None):
        self._host = host
        self._port = port
        self._pinner = pinner
        self._sock = None
        self._ssl_sock = None
    
    def connect(self) -> None:
        """建立连接并验证证书"""
        import socket
        
        # 创建 socket 连接
        self._sock = socket.create_connection((self._host, self._port))
        
        # 包装 SSL
        context = ssl.create_default_context()
        self._ssl_sock = context.wrap_socket(self._sock, server_hostname=self._host)
        
        # 验证证书固定
        if self._pinner:
            cert_der = self._ssl_sock.getpeercert(binary_form=True)
            if not self._pinner.check(cert_der):
                self.close()
                raise ssl.SSLError("证书固定验证失败: 服务器证书与预期指纹不匹配")
    
    def close(self) -> None:
        """关闭连接"""
        if self._ssl_sock:
            self._ssl_sock.close()
            self._ssl_sock = None
        if self._sock:
            self._sock.close()
            self._sock = None
    
    def send(self, data: bytes) -> None:
        """发送数据"""
        if self._ssl_sock:
            self._ssl_sock.sendall(data)
    
    def recv(self, bufsize: int = 4096) -> bytes:
        """接收数据"""
        if self._ssl_sock:
            return self._ssl_sock.recv(bufsize)
        return b""
    
    def __enter__(self):
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


def extract_cert_fingerprint(cert_der: bytes, algorithm: str = "sha256") -> str:
    """
    提取证书指纹
    
    Args:
        cert_der: DER 格式的证书
        algorithm: 哈希算法 (sha256, sha1, md5)
    
    Returns:
        十六进制指纹字符串
    """
    if algorithm == "sha256":
        return hashlib.sha256(cert_der).hexdigest()
    elif algorithm == "sha1":
        return hashlib.sha1(cert_der).hexdigest()
    elif algorithm == "md5":
        return hashlib.md5(cert_der).hexdigest()
    else:
        raise ValueError(f"不支持的哈希算法: {algorithm}")


def extract_cert_fingerprint_base64(cert_der: bytes, algorithm: str = "sha256") -> str:
    """
    提取证书指纹（Base64 格式）
    
    Args:
        cert_der: DER 格式的证书
        algorithm: 哈希算法 (sha256, sha1)
    
    Returns:
        Base64 编码的指纹字符串
    """
    fingerprint = extract_cert_fingerprint(cert_der, algorithm)
    return base64.b64encode(bytes.fromhex(fingerprint)).decode()


def verify_hostname_pinning(hostname: str, cert_der: bytes, expected_pins: List[str]) -> bool:
    """
    验证主机名的证书固定
    
    Args:
        hostname: 主机名
        cert_der: DER 格式的证书
        expected_pins: 预期的指纹列表
    
    Returns:
        是否验证通过
    """
    pinner = CertificatePinner()
    for pin in expected_pins:
        pinner.add_pin_hex(pin)
    return pinner.check(cert_der)
