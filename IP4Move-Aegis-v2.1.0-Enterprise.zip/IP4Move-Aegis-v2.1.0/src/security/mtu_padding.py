"""
MTU 填充模块

将数据包填充到固定大小，防止基于包大小的流量分析。
"""

import os
import random
import struct
import logging
from typing import Optional, List
from enum import Enum
from dataclasses import dataclass

logger = logging.getLogger(__name__)


class PaddingStrategy(Enum):
    """填充策略"""
    RANDOM = "random"      # 随机大小
    CONSTANT = "constant"  # 固定大小
    ADAPTIVE = "adaptive"  # 自适应
    EXPONENTIAL = "exponential"  # 指数分布


@dataclass
class PaddingConfig:
    """填充配置"""
    default_mtu: int = 1400
    padding_strategy: PaddingStrategy = PaddingStrategy.RANDOM
    padding_overhead: int = 20
    min_padding: int = 0
    max_padding: int = 1400


class MTUPadding:
    """
    MTU 填充器

    将数据包填充到目标大小:
    - 随机填充: 每包随机目标大小
    - 固定填充: 所有包填充到 MTU
    - 自适应填充: 根据流量模式调整
    - 指数分布填充: 模拟真实流量大小分布
    """

    PADDING_MARKER = b"\x4D\x54\x50"  # "MTP"

    def __init__(self, config: Optional[PaddingConfig] = None):
        self._config = config or PaddingConfig()
        self._stats = {
            "padded_count": 0,
            "total_padding_bytes": 0,
            "avg_padded_size": 0,
        }

    def pad(self, data: bytes, target_size: Optional[int] = None) -> bytes:
        """
        填充数据

        Args:
            data: 原始数据
            target_size: 目标大小，为 None 时根据策略自动确定

        Returns:
            [PADDING_MARKER(3)] [original_length(4)] [padded_data]
        """
        if target_size is None:
            target_size = self._calculate_target_size(len(data))

        original_length = len(data)
        total_overhead = 3 + 4  # marker + length
        payload_target = target_size - total_overhead

        if original_length >= payload_target:
            # 不需要填充
            header = self.PADDING_MARKER + struct.pack("!I", original_length)
            return header + data

        # 生成高熵填充: 防AI包特征匹配
        padding_size = payload_target - original_length
        # 基础随机填充
        padding = bytearray(os.urandom(padding_size))
        # 注入高熵模式: 在填充中嵌入伪协议头，干扰AI特征提取
        if padding_size > 20:
            # 随机选择一种伪协议头模式
            header_patterns = [
                b"\x47\x41\x50\x31",  # HLS
                b"\x00\x00\x00\x20",  # MP4
                b"\x1a\x45\xdf\xa3",  # MKV/WebM
                b"\x52\x49\x46\x46",  # RIFF/AVI
                b"\x49\x44\x33\x03",  # MP3
            ]
            pattern = random.choice(header_patterns)
            offset = random.randint(0, padding_size - len(pattern))
            for j, b in enumerate(pattern):
                padding[offset + j] = b
            # 在其余位置注入周期性模式（模拟加密流）
            period = random.randint(16, 64)
            for j in range(0, padding_size, period):
                if j + 4 < padding_size:
                    val = random.randint(0, 255)
                    for k in range(4):
                        if j + k < padding_size:
                            padding[j + k] ^= (val + k) & 0xFF
        padding = bytes(padding)

        header = self.PADDING_MARKER + struct.pack("!I", original_length)
        result = header + data + padding

        self._stats["padded_count"] += 1
        self._stats["total_padding_bytes"] += padding_size
        self._stats["avg_padded_size"] = (
            self._stats["total_padding_bytes"] / self._stats["padded_count"]
        )

        return result

    def unpad(self, data: bytes) -> Optional[bytes]:
        """
        去除填充

        Returns:
            原始数据，格式错误时返回 None
        """
        if len(data) < 7:
            return None

        # 验证标记
        if data[:3] != self.PADDING_MARKER:
            return None

        # 读取原始长度
        original_length = struct.unpack("!I", data[3:7])[0]

        # 提取原始数据
        original_data = data[7 : 7 + original_length]
        if len(original_data) != original_length:
            return None

        return original_data

    def _calculate_target_size(self, current_size: int) -> int:
        """根据策略计算目标大小"""
        strategy = self._config.padding_strategy

        if strategy == PaddingStrategy.CONSTANT:
            return self._config.default_mtu

        elif strategy == PaddingStrategy.RANDOM:
            min_size = max(64, current_size)
            max_size = self._config.default_mtu
            return random.randint(min_size, max_size)

        elif strategy == PaddingStrategy.ADAPTIVE:
            # 向上取整到最近的 64 字节边界
            aligned = ((current_size + 63) // 64) * 64
            return min(aligned, self._config.default_mtu)

        elif strategy == PaddingStrategy.EXPONENTIAL:
            # 指数分布: 大多数包较小，少数包较大
            size = int(random.expovariate(1.0 / 400))
            return max(64, min(self._config.default_mtu, size))

        return self._config.default_mtu

    def pad_batch(self, data_list: List[bytes]) -> List[bytes]:
        """批量填充"""
        return [self.pad(data) for data in data_list]

    def unpad_batch(self, data_list: List[bytes]) -> List[Optional[bytes]]:
        """批量去填充"""
        return [self.unpad(data) for data in data_list]

    def get_stats(self) -> dict:
        return dict(self._stats)
