"""
噪声注入模块

注入随机噪声包以干扰流量分析。
"""

import os
import asyncio
import time
import random
import logging
from typing import Optional, List, Callable, Awaitable
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class NoiseConfig:
    """噪声配置"""
    enabled: bool = True
    interval_ms: float = 100
    max_packet_size: int = 64
    probability: float = 0.3
    burst_probability: float = 0.05
    burst_size: int = 5


class NoiseInjector:
    """
    噪声注入器

    在正常流量中注入随机噪声包:
    - 固定间隔注入
    - 概率控制注入率
    - 突发模式
    - 可配置噪声大小
    """

    def __init__(self, config: Optional[NoiseConfig] = None):
        self._config = config or NoiseConfig()
        self._is_running = False
        self._inject_task: Optional[asyncio.Task] = None
        self._send_callback: Optional[Callable[[bytes], Awaitable[None]]] = None
        self._stats = {
            "packets_injected": 0,
            "bytes_injected": 0,
            "bursts_triggered": 0,
        }

    def set_send_callback(self, callback: Callable[[bytes], Awaitable[None]]) -> None:
        """设置发送回调"""
        self._send_callback = callback

    def generate_noise(self, size: Optional[int] = None) -> bytes:
        """
        生成噪声包

        Args:
            size: 噪声包大小，为 None 时随机

        Returns:
            噪声数据
        """
        if size is None:
            size = random.randint(16, self._config.max_packet_size)
        return os.urandom(size)

    async def inject_one(self) -> Optional[bytes]:
        """注入一个噪声包"""
        if not self._config.enabled:
            return None
        if random.random() > self._config.probability:
            return None

        noise = self.generate_noise()
        self._stats["packets_injected"] += 1
        self._stats["bytes_injected"] += len(noise)

        if self._send_callback:
            await self._send_callback(noise)

        return noise

    async def inject_burst(self) -> List[bytes]:
        """注入突发噪声"""
        packets = []
        for _ in range(self._config.burst_size):
            noise = self.generate_noise()
            packets.append(noise)
            self._stats["packets_injected"] += 1
            self._stats["bytes_injected"] += len(noise)
            if self._send_callback:
                await self._send_callback(noise)
        self._stats["bursts_triggered"] += 1
        return packets

    async def _injection_loop(self) -> None:
        """注入循环"""
        while self._is_running:
            try:
                # 检查突发
                if random.random() < self._config.burst_probability:
                    await self.inject_burst()
                else:
                    await self.inject_one()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"噪声注入错误: {e}")
            await asyncio.sleep(self._config.interval_ms / 1000.0)

    async def start(self) -> None:
        """启动噪声注入"""
        if self._is_running:
            return
        self._is_running = True
        self._inject_task = asyncio.create_task(self._injection_loop())
        logger.info("噪声注入器已启动")

    async def stop(self) -> None:
        """停止噪声注入"""
        self._is_running = False
        if self._inject_task:
            self._inject_task.cancel()
            try:
                await self._inject_task
            except asyncio.CancelledError:
                pass
        logger.info("噪声注入器已停止")

    def get_stats(self) -> dict:
        return dict(self._stats)

    def generate_flow_aligned_noise(self) -> bytes:
        """
        生成对齐 Netflix/Zoom 流量矩的噪声包

        分析真实流量的统计特征（均值、方差、偏度、峰度），
        生成匹配这些矩的噪声包，使AI分类器无法区分。

        Netflix 流量特征: 均值~1200B, 方差~400B, 偏度正
        Zoom 流量特征: 均值~800B, 方差~300B, 周期性突发
        """
        # 随机选择对齐目标
        target = random.choice(["netflix", "zoom", "youtube", "webex"])

        if target == "netflix":
            # Netflix HLS 流: 大包为主，偶尔小包
            if random.random() < 0.7:
                size = int(random.gauss(1200, 200))
            else:
                size = int(random.gauss(200, 80))
        elif target == "zoom":
            # Zoom: 中等包，周期性突发
            phase = (time.time() % 0.04) / 0.04  # 25fps 周期
            if phase < 0.3:
                size = int(random.gauss(800, 150))
            else:
                size = int(random.gauss(100, 50))
        elif target == "youtube":
            # YouTube: 类似 Netflix 但更平滑
            size = int(random.lognormvariate(6.8, 0.8))
        else:
            # WebEx: 混合大小
            size = int(random.gauss(600, 250))

        size = max(64, min(1400, size))
        return os.urandom(size)

    def get_flow_moments(self, recent_packets: List[bytes]) -> dict:
        """
        计算最近流量包的统计矩

        用于验证噪声是否成功对齐目标流量分布。
        """
        if not recent_packets:
            return {}
        sizes = [len(p) for p in recent_packets]
        n = len(sizes)
        mean = sum(sizes) / n
        variance = sum((s - mean) ** 2 for s in sizes) / n if n > 1 else 0
        std = variance ** 0.5
        # 偏度
        if std > 0 and n > 2:
            skewness = sum((s - mean) ** 3 for s in sizes) / (n * std ** 3)
        else:
            skewness = 0
        # 峰度
        if std > 0 and n > 3:
            kurtosis = sum((s - mean) ** 4 for s in sizes) / (n * std ** 4) - 3
        else:
            kurtosis = 0
        return {
            "count": n,
            "mean": round(mean, 2),
            "std": round(std, 2),
            "variance": round(variance, 2),
            "skewness": round(skewness, 4),
            "kurtosis": round(kurtosis, 4),
        }
