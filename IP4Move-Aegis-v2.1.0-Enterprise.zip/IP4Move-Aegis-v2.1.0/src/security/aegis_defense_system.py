"""
Aegis 统一防御系统 - 集成 XDP 拦截与全网免疫

这是整个防御体系的顶层集成模块, 协调:
1. XDP 内核态拦截引擎
2. attack_detector 用户态检测
3. 全网免疫同步
4. 统一配置和管理
"""

import asyncio
import logging
from typing import Optional, Dict, List, Any
from dataclasses import dataclass

from src.security.attack_detector import AttackDetector, SecureAttackDetector
from src.xdp_engine.xdp_controller import XDPController, XDPMode
from src.xdp_engine.xdp_event_handler import XDPEventHandler
from src.immune_sync.global_immunity_coordinator import GlobalImmunityCoordinator
from src.immune_sync.immunity_database import ImmunityDatabase

logger = logging.getLogger(__name__)


@dataclass
class DefenseSystemConfig:
    """防御系统配置"""
    # XDP 配置
    xdp_interface: str = "eth0"
    xdp_mode: XDPMode = XDPMode.LEARN
    xdp_enabled: bool = True

    # 免疫同步配置
    immunity_enabled: bool = True
    auto_block_threshold: float = 0.7
    sync_interval: int = 300

    # 检测器配置
    detector_enabled: bool = True


class AegisDefenseSystem:
    """
    Aegis 统一防御系统

    提供一键启用的完整防御能力:
    - 内核态 XDP 线速拦截
    - 用户态深度检测
    - 全网攻击特征同步
    - 自动免疫更新
    """

    def __init__(
        self,
        node_id: str,
        config: Optional[DefenseSystemConfig] = None,
        attack_detector: Optional[AttackDetector] = None,
    ):
        """
        初始化防御系统

        Args:
            node_id: 节点唯一标识
            config: 系统配置
            attack_detector: 外部攻击检测器 (可选)
        """
        self._node_id = node_id
        self._config = config or DefenseSystemConfig()

        # 组件
        self._xdp: Optional[XDPController] = None
        self._xdp_handler: Optional[XDPEventHandler] = None
        self._detector: Optional[AttackDetector] = attack_detector
        self._immunity: Optional[GlobalImmunityCoordinator] = None

        # 运行状态
        self._initialized = False
        self._running = False

        logger.info(f"AegisDefenseSystem 初始化 (node={node_id})")

    async def initialize(self) -> bool:
        """
        初始化所有组件

        Returns:
            True if successful
        """
        if self._initialized:
            return True

        try:
            # 1. 初始化攻击检测器 (如果未提供)
            if self._detector is None and self._config.detector_enabled:
                self._detector = SecureAttackDetector()
                logger.info("攻击检测器已创建")

            # 2. 初始化 XDP 控制器
            if self._config.xdp_enabled:
                self._xdp = XDPController(
                    interface=self._config.xdp_interface,
                    mode=self._config.xdp_mode,
                )
                logger.info("XDP 控制器已创建")

            # 3. 初始化 XDP 事件处理器
            if self._xdp and self._detector:
                self._xdp_handler = XDPEventHandler(
                    xdp_controller=self._xdp,
                    attack_detector=self._detector,
                    enable_auto_ban=True,
                    enable_fingerprint_sync=True,
                )
                logger.info("XDP 事件处理器已创建")

            # 4. 初始化免疫协调器
            if self._config.immunity_enabled:
                immunity_db = ImmunityDatabase()

                self._immunity = GlobalImmunityCoordinator(
                    node_id=self._node_id,
                    xdp_controller=self._xdp,
                    attack_detector=self._detector,
                    immunity_db=immunity_db,
                    enable_auto_block=True,
                )

                # 注册指纹回调
                if self._xdp_handler:
                    self._xdp_handler.register_fingerprint_callback(
                        self._on_fingerprint_from_xdp
                    )

                logger.info("免疫协调器已创建")

            self._initialized = True
            logger.info("AegisDefenseSystem 初始化完成")
            return True

        except Exception as e:
            logger.error(f"初始化失败: {e}")
            return False

    async def start(self) -> bool:
        """
        启动防御系统

        Returns:
            True if successful
        """
        if not self._initialized:
            if not await self.initialize():
                return False

        if self._running:
            return True

        try:
            # 1. 加载 XDP 程序
            if self._xdp:
                success = await self._xdp.load()
                if not success:
                    logger.warning("XDP 程序加载失败, 继续以用户态模式运行")

            # 2. 启动免疫协调器
            if self._immunity:
                await self._immunity.start()

            self._running = True
            logger.info("AegisDefenseSystem 已启动")
            return True

        except Exception as e:
            logger.error(f"启动失败: {e}")
            return False

    async def stop(self) -> None:
        """停止防御系统"""
        if not self._running:
            return

        logger.info("正在停止 AegisDefenseSystem...")

        # 停止免疫协调器
        if self._immunity:
            await self._immunity.stop()

        # 卸载 XDP
        if self._xdp:
            await self._xdp.unload()

        self._running = False
        logger.info("AegisDefenseSystem 已停止")

    def _on_fingerprint_from_xdp(self, fingerprint: Dict[str, Any]) -> None:
        """处理来自 XDP 的攻击指纹"""
        # 转发给免疫协调器
        if self._immunity:
            # 这里简化处理, 实际应构造 AttackFingerprint 对象
            pass

    # ============================================================
    # 公共 API
    # ============================================================

    def ban_ip(self, ip: str, duration: int = 3600) -> bool:
        """
        手动封禁 IP

        会同时更新 XDP 黑名单和免疫数据库。
        """
        success = False

        # 更新 XDP
        if self._xdp:
            success = self._xdp.ban_ip(ip, duration) or success

        return success

    def unban_ip(self, ip: str) -> bool:
        """手动解封 IP"""
        if self._xdp:
            return self._xdp.unban_ip(ip)
        return False

    def get_banned_ips(self) -> List[Any]:
        """获取被封禁的 IP 列表"""
        if self._xdp:
            return self._xdp.get_banned_ips()
        return []

    def set_xdp_mode(self, mode: XDPMode) -> None:
        """设置 XDP 运行模式"""
        if self._xdp:
            self._xdp.set_mode(mode)
            self._config.xdp_mode = mode

    def get_stats(self) -> Dict[str, Any]:
        """获取系统统计信息"""
        stats = {
            "node_id": self._node_id,
            "running": self._running,
            "xdp_enabled": self._config.xdp_enabled,
            "xdp_loaded": self._xdp.is_loaded if self._xdp else False,
            "xdp_mode": self._config.xdp_mode.name,
            "immunity_enabled": self._config.immunity_enabled,
        }

        # XDP 统计
        if self._xdp:
            stats["xdp"] = {
                "total_packets": self._xdp.get_stats().total_packets,
                "dropped_packets": self._xdp.get_stats().dropped_packets,
                "banned_ips": len(self._xdp.get_banned_ips()),
            }

        # 免疫统计
        if self._immunity:
            stats["immunity"] = self._immunity.get_stats()

        # 检测器统计
        if self._detector:
            stats["detector"] = self._detector.get_stats()

        return stats

    async def full_sync(self) -> int:
        """手动触发全网同步"""
        if self._immunity:
            return await self._immunity.manual_sync()
        return 0

    def is_immune_to(self, ip: str) -> bool:
        """检查是否对某 IP 免疫"""
        if self._immunity:
            return self._immunity.is_immune_to(ip)
        return False

    async def close(self) -> None:
        """关闭系统"""
        await self.stop()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        asyncio.create_task(self.close())
