"""
协议混淆模块

对协议头和字段进行随机化混淆。
"""

import os
import random
import struct
import logging
from typing import Optional, Dict, List, Tuple

logger = logging.getLogger(__name__)


class ProtocolObfuscator:
    """
    协议混淆器

    对网络协议头进行随机化:
    - TCP: 序列号、窗口大小、选项顺序
    - IP: ID、TTL、DF 标志
    - UDP: 源端口
    - DNS: 查询ID、域名大小写
    """

    # 常见 TCP 窗口大小
    TCP_WINDOWS = [29200, 64240, 65535, 16384, 32768, 8192, 4096]

    # 常见 TTL 值
    TTL_VALUES = [32, 48, 60, 61, 62, 63, 64, 128, 255]

    def __init__(self, seed: Optional[int] = None):
        self._rng = random.Random(seed)

    def obfuscate_tcp_header(
        self,
        src_port: int = 0,
        dst_port: int = 443,
        seq_num: int = 0,
        ack_num: int = 0,
        flags: int = 0x18,
    ) -> bytes:
        """
        生成混淆的 TCP 头

        Returns:
            20字节 TCP 头
        """
        if src_port == 0:
            src_port = self._rng.randint(1024, 65535)
        if seq_num == 0:
            seq_num = self._rng.randint(0, 2**32 - 1)

        window = self._rng.choice(self.TCP_WINDOWS)
        ttl = self._rng.choice(self.TTL_VALUES)

        # TCP 头 (20 bytes)
        header = struct.pack("!HHIIBBHHH",
            src_port,       # 源端口
            dst_port,       # 目标端口
            seq_num,        # 序列号
            ack_num,        # 确认号
            0x50,           # 数据偏移 (5 * 4 = 20)
            flags,          # 标志位
            window,         # 窗口大小
            0,              # 校验和 (简化)
            0,              # 紧急指针
        )
        return header

    def obfuscate_ip_header(
        self,
        src_ip: str = "0.0.0.0",
        dst_ip: str = "0.0.0.0",
        protocol: int = 6,  # TCP
        payload_size: int = 0,
    ) -> bytes:
        """
        生成混淆的 IP 头

        Returns:
            20字节 IP 头
        """
        version_ihl = 0x45  # IPv4, IHL=5
        tos = self._rng.randint(0, 255)
        identification = self._rng.randint(0, 65535)
        flags_fragment = 0x4000  # DF flag set
        ttl = self._rng.choice(self.TTL_VALUES)

        total_length = 20 + payload_size

        header = struct.pack("!BBHHHBBH4s4s",
            version_ihl,
            tos,
            total_length,
            identification,
            flags_fragment,
            ttl,
            protocol,
            0,  # 校验和 (简化)
            self._ip_to_bytes(src_ip),
            self._ip_to_bytes(dst_ip),
        )
        return header

    def obfuscate_udp_header(
        self,
        src_port: int = 0,
        dst_port: int = 53,
        payload_size: int = 0,
    ) -> bytes:
        """生成混淆的 UDP 头"""
        if src_port == 0:
            src_port = self._rng.randint(1024, 65535)
        length = 8 + payload_size
        return struct.pack("!HHHH",
            src_port, dst_port, length, 0
        )

    def obfuscate_dns_query(
        self,
        domain: str,
        query_type: int = 1,  # A record
    ) -> bytes:
        """
        生成混淆的 DNS 查询

        随机化查询ID和域名大小写 (0x20 encoding)。
        """
        query_id = self._rng.randint(0, 65535)

        # DNS 头
        flags = 0x0100  # Standard query, recursion desired
        header = struct.pack("!HHHHHH",
            query_id, flags, 1, 0, 0, 0
        )

        # 0x20 编码: 随机化域名大小写
        obfuscated_domain = self._apply_0x20_encoding(domain)

        # 构建查询
        question = b""
        for label in obfuscated_domain.split("."):
            question += struct.pack("!B", len(label))
            question += label.encode("ascii")
        question += b"\x00"  # 结束标记
        question += struct.pack("!HH", query_type, 1)  # Type, Class

        return header + question

    def _apply_0x20_encoding(self, domain: str) -> str:
        """应用 0x20 编码: 随机化域名大小写"""
        result = []
        for char in domain:
            if char.isalpha():
                if self._rng.random() < 0.5:
                    result.append(char.upper())
                else:
                    result.append(char.lower())
            else:
                result.append(char)
        return "".join(result)

    @staticmethod
    def _ip_to_bytes(ip: str) -> bytes:
        """IP 地址转字节"""
        return bytes(int(octet) for octet in ip.split("."))

    def randomize_header_order(self, headers: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
        """随机化 HTTP 头顺序"""
        result = list(headers)
        self._rng.shuffle(result)
        return result

    def generate_fake_headers(self, count: int = 3) -> List[Tuple[str, str]]:
        """生成虚假 HTTP 头"""
        fake_headers_pool = [
            ("X-Request-Id", os.urandom(16).hex()),
            ("X-Forwarded-For", f"{self._rng.randint(1,255)}.{self._rng.randint(1,255)}.{self._rng.randint(1,255)}.{self._rng.randint(1,255)}"),
            ("Accept-Language", random.choice(["en-US,en;q=0.9", "zh-CN,zh;q=0.9", "ja,en;q=0.8"])),
            ("X-Client-IP", f"{self._rng.randint(1,255)}.{self._rng.randint(1,255)}.{self._rng.randint(1,255)}.{self._rng.randint(1,255)}"),
            ("Via", f"1.1 proxy-{os.urandom(4).hex()}"),
            ("X-Custom", os.urandom(8).hex()),
        ]
        return self._rng.sample(fake_headers_pool, min(count, len(fake_headers_pool)))
