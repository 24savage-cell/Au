"""
攻击检测模块 (安全修复版 v2)

修复内容:
1. 限制内存使用（_seen_packets无界增长）
2. 限制_alerts列表大小
3. 限制_source_timestamps大小
4. 添加输入验证
5. 防止正则DoS
6. 添加基于统计的异常检测（滑动窗口）
7. 添加机器学习异常检测（Isolation Forest）
8. 添加自动响应机制（自动封禁可疑IP）
"""

import time
import math
import hashlib
import logging
import collections
from typing import Optional, Dict, List, Tuple, Callable, Set
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

# 安全常量
MAX_SEEN_PACKETS = 10000      # 最大已见包记录数
MAX_ALERTS = 10000            # 最大警报记录数
MAX_SOURCE_TRACK = 10000      # 最大源追踪数
MAX_PACKET_SIZE = 16 * 1024 * 1024  # 最大包大小 (16MB)
MAX_NODE_ID_LENGTH = 256      # 最大节点ID长度
FLOOD_THRESHOLD = 1000        # 洪水攻击阈值
REPLAY_WINDOW = 300           # 重放检测窗口(秒)
ALERT_COOLDOWN = 60           # 警报冷却时间(秒)

# 统计异常检测常量
STAT_WINDOW_SIZE = 100        # 滑动窗口大小
ANOMALY_THRESHOLD = 3.0       # 异常阈值（标准差倍数）
MIN_SAMPLES_FOR_STATS = 10    # 最小样本数

# 自动响应常量
AUTO_BAN_THRESHOLD = 0.9      # 自动封禁阈值
BAN_DURATION = 3600           # 封禁时长（秒）
BAN_COOLDOWN = 300            # 封禁冷却时间（秒）


class AttackType(Enum):
    """攻击类型"""
    TIMING = "timing"
    TRAFFIC = "traffic"
    REPLAY = "replay"
    TAGGING = "tagging"
    FLOODING = "flooding"
    SYBIL = "sybil"
    EAVESDROP = "eavesdrop"
    CORRELATION = "correlation"
    STATISTICAL_ANOMALY = "statistical_anomaly"
    ML_ANOMALY = "ml_anomaly"


@dataclass
class AttackAlert:
    """攻击警报"""
    attack_type: AttackType
    severity: float
    source: str
    description: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict = field(default_factory=dict)


@dataclass
class BannedIP:
    """被封禁的IP信息"""
    ip: str
    banned_at: float
    expires_at: float
    reason: str


class TrafficWindow:
    """流量窗口统计"""

    def __init__(self, window_size: int = 100):
        self._window_size = min(window_size, 10000)  # 限制窗口大小
        self._timestamps: List[float] = []
        self._sizes: List[int] = []

    def add(self, size: int) -> None:
        """添加数据包"""
        if size < 0 or size > MAX_PACKET_SIZE:
            return  # 忽略异常大小
        now = time.time()
        self._timestamps.append(now)
        self._sizes.append(size)
        self._cleanup(now)

    def _cleanup(self, now: float) -> None:
        """清理过期数据"""
        while self._timestamps and len(self._timestamps) > self._window_size:
            self._timestamps.pop(0)
            self._sizes.pop(0)

    @property
    def packet_count(self) -> int:
        return len(self._timestamps)

    @property
    def total_bytes(self) -> int:
        return sum(self._sizes)

    @property
    def avg_size(self) -> float:
        return sum(self._sizes) / max(1, len(self._sizes))

    @property
    def size_variance(self) -> float:
        if len(self._sizes) < 2:
            return 0.0
        avg = self.avg_size
        return sum((s - avg) ** 2 for s in self._sizes) / len(self._sizes)

    @property
    def size_std(self) -> float:
        return math.sqrt(self.size_variance)

    def inter_arrival_times(self) -> List[float]:
        if len(self._timestamps) < 2:
            return []
        return [
            self._timestamps[i + 1] - self._timestamps[i]
            for i in range(len(self._timestamps) - 1)
        ]

    @property
    def avg_inter_arrival(self) -> float:
        iats = self.inter_arrival_times()
        return sum(iats) / max(1, len(iats))

    @property
    def inter_arrival_variance(self) -> float:
        iats = self.inter_arrival_times()
        if len(iats) < 2:
            return 0.0
        avg = self.avg_inter_arrival
        return sum((t - avg) ** 2 for t in iats) / len(iats)


class StatisticalAnomalyDetector:
    """
    基于统计的异常检测器
    
    使用滑动窗口计算均值和方差，检测偏离正常模式的流量。
    """
    
    def __init__(self, window_size: int = STAT_WINDOW_SIZE):
        self._window_size = window_size
        self._packet_sizes: collections.deque = collections.deque(maxlen=window_size)
        self._inter_arrival_times: collections.deque = collections.deque(maxlen=window_size)
        self._last_timestamp: Optional[float] = None
    
    def add_sample(self, packet_size: int, timestamp: float) -> None:
        """添加样本"""
        self._packet_sizes.append(packet_size)
        
        if self._last_timestamp is not None:
            iat = timestamp - self._last_timestamp
            if iat > 0:
                self._inter_arrival_times.append(iat)
        
        self._last_timestamp = timestamp
    
    def _compute_stats(self, data: collections.deque) -> Tuple[float, float]:
        """计算均值和标准差"""
        if len(data) < MIN_SAMPLES_FOR_STATS:
            return 0.0, 0.0
        
        mean = sum(data) / len(data)
        variance = sum((x - mean) ** 2 for x in data) / len(data)
        std = math.sqrt(variance)
        return mean, std
    
    def detect_anomaly(self, packet_size: int, timestamp: float) -> Tuple[bool, float, str]:
        """
        检测异常
        
        返回: (是否异常, 异常分数, 描述)
        """
        self.add_sample(packet_size, timestamp)
        
        if len(self._packet_sizes) < MIN_SAMPLES_FOR_STATS:
            return False, 0.0, "样本不足"
        
        # 计算包大小统计
        size_mean, size_std = self._compute_stats(self._packet_sizes)
        
        # 计算到达间隔统计
        iat_mean, iat_std = self._compute_stats(self._inter_arrival_times)
        
        anomalies = []
        anomaly_score = 0.0
        
        # 检测包大小异常
        if size_std > 0:
            size_zscore = abs(packet_size - size_mean) / size_std
            if size_zscore > ANOMALY_THRESHOLD:
                anomalies.append(f"包大小异常: z-score={size_zscore:.2f}")
                anomaly_score = max(anomaly_score, min(1.0, size_zscore / (ANOMALY_THRESHOLD * 2)))
        
        # 检测到达间隔异常
        if self._last_timestamp and iat_std > 0:
            current_iat = timestamp - self._last_timestamp
            iat_zscore = abs(current_iat - iat_mean) / iat_std
            if iat_zscore > ANOMALY_THRESHOLD:
                anomalies.append(f"到达间隔异常: z-score={iat_zscore:.2f}")
                anomaly_score = max(anomaly_score, min(1.0, iat_zscore / (ANOMALY_THRESHOLD * 2)))
        
        is_anomaly = len(anomalies) > 0
        description = "; ".join(anomalies) if anomalies else "正常"
        
        return is_anomaly, anomaly_score, description


class MLAnomalyDetector:
    """
    机器学习异常检测器
    
    使用 Isolation Forest 算法检测异常模式。
    如果 sklearn 不可用，则回退到简化的异常检测逻辑。
    """
    
    def __init__(self, contamination: float = 0.1, n_estimators: int = 100):
        self._contamination = contamination
        self._n_estimators = n_estimators
        self._model = None
        self._samples: collections.deque = collections.deque(maxlen=1000)
        self._sklearn_available = self._check_sklearn()
    
    def _check_sklearn(self) -> bool:
        """检查 sklearn 是否可用"""
        try:
            from sklearn.ensemble import IsolationForest
            return True
        except ImportError:
            logger.warning("sklearn 不可用，使用回退异常检测")
            return False
    
    def _init_model(self):
        """初始化模型"""
        if self._sklearn_available and self._model is None:
            try:
                from sklearn.ensemble import IsolationForest
                self._model = IsolationForest(
                    contamination=self._contamination,
                    n_estimators=self._n_estimators,
                    random_state=42
                )
            except Exception as e:
                logger.error(f"初始化 Isolation Forest 失败: {e}")
                self._sklearn_available = False
    
    def add_sample(self, features: List[float]) -> None:
        """添加特征样本"""
        self._samples.append(features)
    
    def detect_anomaly(self, features: List[float]) -> Tuple[bool, float, str]:
        """
        检测异常
        
        返回: (是否异常, 异常分数, 描述)
        """
        self.add_sample(features)
        
        # 如果样本不足，无法检测
        if len(self._samples) < MIN_SAMPLES_FOR_STATS * 2:
            return False, 0.0, "样本不足"
        
        # 使用 Isolation Forest
        if self._sklearn_available:
            return self._detect_with_isolation_forest(features)
        else:
            return self._detect_fallback(features)
    
    def _detect_with_isolation_forest(self, features: List[float]) -> Tuple[bool, float, str]:
        """使用 Isolation Forest 检测"""
        self._init_model()
        
        if self._model is None:
            return self._detect_fallback(features)
        
        try:
            import numpy as np
            
            # 确保模型已训练
            if len(self._samples) >= MIN_SAMPLES_FOR_STATS * 2:
                X = np.array(list(self._samples))
                self._model.fit(X)
            else:
                return self._detect_fallback(features)
            
            # 预测
            X_test = np.array([features])
            prediction = self._model.predict(X_test)[0]
            score = -self._model.score_samples(X_test)[0]  # 异常分数
            
            is_anomaly = prediction == -1
            normalized_score = min(1.0, max(0.0, score))
            
            if is_anomaly:
                return True, normalized_score, f"ML异常检测: 分数={normalized_score:.3f}"
            return False, normalized_score, "正常"
            
        except Exception as e:
            logger.debug(f"Isolation Forest 检测失败: {e}")
            return self._detect_fallback(features)
    
    def _detect_fallback(self, features: List[float]) -> Tuple[bool, float, str]:
        """回退检测方法：基于距离的简单异常检测"""
        if len(self._samples) < MIN_SAMPLES_FOR_STATS:
            return False, 0.0, "样本不足"
        
        # 计算与历史样本的平均距离
        distances = []
        for sample in self._samples:
            distance = math.sqrt(sum((a - b) ** 2 for a, b in zip(features, sample)))
            distances.append(distance)
        
        mean_distance = sum(distances) / len(distances)
        std_distance = math.sqrt(sum((d - mean_distance) ** 2 for d in distances) / len(distances))
        
        current_distance = math.sqrt(sum((a - b) ** 2 for a, b in zip(features, list(self._samples)[-1])))
        
        if std_distance > 0:
            zscore = abs(current_distance - mean_distance) / std_distance
            if zscore > ANOMALY_THRESHOLD:
                score = min(1.0, zscore / (ANOMALY_THRESHOLD * 2))
                return True, score, f"距离异常检测: z-score={zscore:.2f}"
        
        return False, 0.0, "正常"


class AutoResponseManager:
    """
    自动响应管理器
    
    根据检测到的威胁自动执行响应操作，如封禁IP。
    """
    
    def __init__(self):
        self._banned_ips: Dict[str, BannedIP] = {}
        self._suspicious_ips: Dict[str, List[Tuple[float, float]]] = {}  # IP -> [(时间, 威胁分数)]
        self._callbacks: List[Callable[[str, str], None]] = []
    
    def register_callback(self, callback: Callable[[str, str], None]) -> None:
        """注册响应回调"""
        self._callbacks.append(callback)
    
    def report_threat(self, ip: str, threat_score: float, threat_type: str) -> bool:
        """
        报告威胁
        
        返回: 是否触发了封禁
        """
        now = time.time()
        
        # 清理过期记录
        self._cleanup_expired_bans(now)
        
        # 如果IP已被封禁，跳过
        if ip in self._banned_ips:
            return False
        
        # 记录威胁
        if ip not in self._suspicious_ips:
            self._suspicious_ips[ip] = []
        self._suspicious_ips[ip].append((now, threat_score))
        
        # 清理旧记录（保留最近5分钟）
        self._suspicious_ips[ip] = [
            (t, s) for t, s in self._suspicious_ips[ip]
            if now - t < BAN_COOLDOWN
        ]
        
        # 计算综合威胁分数
        total_score = sum(s for _, s in self._suspicious_ips[ip])
        avg_score = total_score / len(self._suspicious_ips[ip])
        
        # 检查是否达到封禁阈值
        should_ban = (
            threat_score >= AUTO_BAN_THRESHOLD or
            (avg_score >= AUTO_BAN_THRESHOLD * 0.7 and len(self._suspicious_ips[ip]) >= 3)
        )
        
        if should_ban:
            self._ban_ip(ip, now, f"自动封禁: {threat_type}, 分数={threat_score:.2f}")
            return True
        
        return False
    
    def _ban_ip(self, ip: str, now: float, reason: str) -> None:
        """封禁IP"""
        ban = BannedIP(
            ip=ip,
            banned_at=now,
            expires_at=now + BAN_DURATION,
            reason=reason
        )
        self._banned_ips[ip] = ban
        
        logger.warning(f"自动封禁IP: {ip}, 原因: {reason}")
        
        # 触发回调
        for callback in self._callbacks:
            try:
                callback(ip, reason)
            except Exception as e:
                logger.error(f"响应回调错误: {e}")
    
    def _cleanup_expired_bans(self, now: float) -> None:
        """清理过期封禁"""
        expired = [ip for ip, ban in self._banned_ips.items() if now > ban.expires_at]
        for ip in expired:
            del self._banned_ips[ip]
            logger.info(f"封禁过期，解除IP: {ip}")
    
    def is_banned(self, ip: str) -> bool:
        """检查IP是否被封禁"""
        self._cleanup_expired_bans(time.time())
        return ip in self._banned_ips
    
    def get_banned_ips(self) -> List[BannedIP]:
        """获取所有被封禁的IP"""
        self._cleanup_expired_bans(time.time())
        return list(self._banned_ips.values())
    
    def unban_ip(self, ip: str) -> bool:
        """手动解封IP"""
        if ip in self._banned_ips:
            del self._banned_ips[ip]
            logger.info(f"手动解除封禁: {ip}")
            return True
        return False


class SecureAttackDetector:
    """
    安全攻击检测器 (增强版)
    
    安全增强:
    - 内存使用限制
    - 输入验证
    - 资源清理
    - 基于统计的异常检测
    - 机器学习异常检测
    - 自动响应机制
    """

    def __init__(
        self,
        window_size: int = 100,
        threshold: float = 0.8,
        alert_cooldown: float = ALERT_COOLDOWN,
        enable_auto_response: bool = True,
        enable_statistical_detection: bool = True,
        enable_ml_detection: bool = True,
    ):
        self._window = TrafficWindow(window_size)
        self._threshold = max(0.1, min(1.0, threshold))
        self._alert_cooldown = alert_cooldown
        self._alerts: List[AttackAlert] = []
        self._last_alert_time: Dict[str, float] = {}
        self._seen_packets: Dict[str, float] = {}
        self._node_reputation: Dict[str, float] = {}
        self._callbacks: List[Callable] = []
        self._source_timestamps: Dict[str, List[float]] = {}
        
        # 新增组件
        self._enable_auto_response = enable_auto_response
        self._enable_statistical_detection = enable_statistical_detection
        self._enable_ml_detection = enable_ml_detection
        
        self._stat_detectors: Dict[str, StatisticalAnomalyDetector] = {}
        self._ml_detector = MLAnomalyDetector() if enable_ml_detection else None
        self._auto_response = AutoResponseManager() if enable_auto_response else None
    
    def on_alert(self, callback: Callable) -> None:
        """注册警报回调"""
        if len(self._callbacks) < 10:  # 限制回调数量
            self._callbacks.append(callback)
    
    def on_auto_response(self, callback: Callable[[str, str], None]) -> None:
        """注册自动响应回调"""
        if self._auto_response:
            self._auto_response.register_callback(callback)
    
    def _validate_source(self, source: str) -> bool:
        """验证来源标识"""
        if not isinstance(source, str):
            return False
        if len(source) > MAX_NODE_ID_LENGTH:
            return False
        return True
    
    def _cleanup_seen_packets(self) -> None:
        """清理过期的已见包记录"""
        now = time.time()
        if len(self._seen_packets) > MAX_SEEN_PACKETS:
            expired = [h for h, t in self._seen_packets.items() if now - t > REPLAY_WINDOW]
            for h in expired:
                del self._seen_packets[h]
            # 如果仍然过多，截断最旧的50%
            if len(self._seen_packets) > MAX_SEEN_PACKETS:
                sorted_items = sorted(self._seen_packets.items(), key=lambda x: x[1])
                remove_count = len(sorted_items) // 2
                for h, _ in sorted_items[:remove_count]:
                    del self._seen_packets[h]

    def _cleanup_alerts(self) -> None:
        """清理过期警报"""
        if len(self._alerts) > MAX_ALERTS:
            self._alerts = self._alerts[-MAX_ALERTS // 2:]

    def _cleanup_source_timestamps(self) -> None:
        """清理过期的源时间戳"""
        now = time.time()
        for key in list(self._source_timestamps.keys()):
            self._source_timestamps[key] = [
                t for t in self._source_timestamps[key] if now - t < 1.0
            ]
            if not self._source_timestamps[key]:
                del self._source_timestamps[key]
        # 限制总追踪源数
        if len(self._source_timestamps) > MAX_SOURCE_TRACK:
            sorted_sources = sorted(
                self._source_timestamps.keys(),
                key=lambda k: len(self._source_timestamps[k])
            )
            for key in sorted_sources[:len(sorted_sources) - MAX_SOURCE_TRACK]:
                del self._source_timestamps[key]

    def observe_packet(self, data: bytes, source: str = "unknown") -> Optional[AttackAlert]:
        """
        观察数据包并检测攻击
        
        安全增强:
        - 输入验证
        - 内存限制
        - 自动响应
        """
        # 输入验证
        if not isinstance(data, bytes):
            return None
        if not self._validate_source(source):
            source = "invalid"
        if len(data) > MAX_PACKET_SIZE:
            return None
        
        # 检查IP是否被封禁
        if self._auto_response and self._auto_response.is_banned(source):
            return None
        
        now = time.time()
        self._window.add(len(data))

        # 检测各种攻击
        alert = self._check_timing_attack(source)
        if alert:
            self._handle_alert(alert, source)
            return alert

        alert = self._check_traffic_attack(source)
        if alert:
            self._handle_alert(alert, source)
            return alert

        alert = self._check_replay_attack(data, source)
        if alert:
            self._handle_alert(alert, source)
            return alert

        alert = self._check_tagging_attack(data, source)
        if alert:
            self._handle_alert(alert, source)
            return alert

        alert = self._check_flooding_attack(source)
        if alert:
            self._handle_alert(alert, source)
            return alert
        
        # 统计异常检测
        if self._enable_statistical_detection:
            alert = self._check_statistical_anomaly(len(data), source, now)
            if alert:
                self._handle_alert(alert, source)
                return alert
        
        # ML异常检测
        if self._enable_ml_detection and self._ml_detector:
            alert = self._check_ml_anomaly(data, source, now)
            if alert:
                self._handle_alert(alert, source)
                return alert

        return None
    
    def _handle_alert(self, alert: AttackAlert, source: str) -> None:
        """处理警报，触发自动响应"""
        # 触发自动响应
        if self._auto_response:
            self._auto_response.report_threat(source, alert.severity, alert.attack_type.value)

    def _check_timing_attack(self, source: str) -> Optional[AttackAlert]:
        """检测时序攻击"""
        iat_var = self._window.inter_arrival_variance
        avg_iat = self._window.avg_inter_arrival

        if avg_iat > 0 and iat_var / (avg_iat ** 2) < 0.01:
            severity = 1.0 - (iat_var / (avg_iat ** 2))
            if severity > self._threshold:
                return self._create_alert(
                    AttackType.TIMING,
                    severity,
                    source,
                    f"检测到异常时序模式: 方差={iat_var:.6f}, 均值={avg_iat:.3f}",
                )
        return None

    def _check_traffic_attack(self, source: str) -> Optional[AttackAlert]:
        """检测流量分析攻击"""
        size_std = self._window.size_std
        avg_size = self._window.avg_size

        if avg_size > 0 and size_std / avg_size < 0.05:
            severity = 1.0 - (size_std / avg_size)
            if severity > self._threshold:
                return self._create_alert(
                    AttackType.TRAFFIC,
                    severity,
                    source,
                    f"检测到异常流量模式: 标准差={size_std:.1f}, 均值={avg_size:.1f}",
                )
        return None

    def _check_replay_attack(self, data: bytes, source: str) -> Optional[AttackAlert]:
        """检测重放攻击"""
        packet_hash = hashlib.sha256(data).hexdigest()

        now = time.time()
        if packet_hash in self._seen_packets:
            last_seen = self._seen_packets[packet_hash]
            if now - last_seen < REPLAY_WINDOW:
                return self._create_alert(
                    AttackType.REPLAY,
                    0.9,
                    source,
                    f"检测到重放攻击: 包哈希={packet_hash[:16]}...",
                )
        self._seen_packets[packet_hash] = now

        # 定期清理
        self._cleanup_seen_packets()
        return None

    def _check_tagging_attack(self, data: bytes, source: str) -> Optional[AttackAlert]:
        """检测标记攻击"""
        if len(data) < 20:
            return None

        chunk_size = 16
        chunks = [data[i:i+chunk_size] for i in range(0, min(len(data), 1600), chunk_size)]
        if len(chunks) < 3:
            return None

        unique_chunks = set(chunks)
        repetition_rate = 1.0 - len(unique_chunks) / len(chunks)

        if repetition_rate > 0.5:
            return self._create_alert(
                AttackType.TAGGING,
                repetition_rate,
                source,
                f"检测到可能的标记攻击: 重复率={repetition_rate:.2f}",
            )
        return None

    def _check_flooding_attack(self, source: str) -> Optional[AttackAlert]:
        """检测洪水攻击"""
        now = time.time()
        source_key = f"flood:{source}"
        
        if source_key not in self._source_timestamps:
            self._source_timestamps[source_key] = []
        
        # 添加当前时间戳
        self._source_timestamps[source_key].append(now)
        
        # 获取当前条目数（在清理前检查，确保能检测到快速洪水）
        recent = len(self._source_timestamps[source_key])
        
        # 检测洪水攻击
        if recent > FLOOD_THRESHOLD:
            # 计算严重性：超过阈值即视为高严重性
            severity = 1.0
            
            # 清理后才返回，避免内存无限增长
            self._source_timestamps[source_key] = [
                t for t in self._source_timestamps[source_key] if now - t < 1.0
            ]
            
            return self._create_alert(
                AttackType.FLOODING,
                severity,
                source,
                f"检测到洪水攻击: {recent} 包/秒",
            )
        
        # 定期清理过期条目（只在条目数较多时清理，避免影响洪水检测）
        # 使用 1500 作为清理阈值，确保在达到 FLOOD_THRESHOLD (1000) 时不会触发清理
        if recent > 1500 and recent % 500 == 0:
            self._source_timestamps[source_key] = [
                t for t in self._source_timestamps[source_key] if now - t < 1.0
            ]
        
        # 定期清理所有源
        if len(self._source_timestamps) > MAX_SOURCE_TRACK:
            self._cleanup_source_timestamps()
        
        return None
    
    def _check_statistical_anomaly(self, packet_size: int, source: str, timestamp: float) -> Optional[AttackAlert]:
        """基于统计的异常检测"""
        if source not in self._stat_detectors:
            self._stat_detectors[source] = StatisticalAnomalyDetector()
        
        detector = self._stat_detectors[source]
        is_anomaly, score, description = detector.detect_anomaly(packet_size, timestamp)
        
        if is_anomaly and score > self._threshold:
            return self._create_alert(
                AttackType.STATISTICAL_ANOMALY,
                score,
                source,
                f"统计异常检测: {description}",
                metadata={"score": score, "description": description}
            )
        return None
    
    def _check_ml_anomaly(self, data: bytes, source: str, timestamp: float) -> Optional[AttackAlert]:
        """机器学习异常检测"""
        if not self._ml_detector:
            return None
        
        # 提取特征
        features = self._extract_features(data, source, timestamp)
        
        is_anomaly, score, description = self._ml_detector.detect_anomaly(features)
        
        if is_anomaly and score > self._threshold:
            return self._create_alert(
                AttackType.ML_ANOMALY,
                score,
                source,
                f"ML异常检测: {description}",
                metadata={"score": score, "description": description}
            )
        return None
    
    def _extract_features(self, data: bytes, source: str, timestamp: float) -> List[float]:
        """提取数据包特征用于ML检测"""
        features = [
            float(len(data)),  # 包大小
            float(len(data) % 256),  # 包大小模256
            float(hash(source) % 1000) / 1000.0,  # 源标识哈希
            float(timestamp % 60) / 60.0,  # 秒数归一化
        ]
        
        # 添加字节分布特征
        if data:
            byte_counts = [0] * 256
            for b in data[:min(len(data), 1000)]:  # 只取前1000字节
                byte_counts[b] += 1
            
            # 计算熵
            total = sum(byte_counts)
            if total > 0:
                entropy = 0.0
                for count in byte_counts:
                    if count > 0:
                        p = count / total
                        entropy -= p * math.log2(p)
                features.append(entropy / 8.0)  # 归一化到0-1
            else:
                features.append(0.0)
        else:
            features.append(0.0)
        
        return features

    def _create_alert(
        self,
        attack_type: AttackType,
        severity: float,
        source: str,
        description: str,
        metadata: Dict = None,
    ) -> Optional[AttackAlert]:
        """创建攻击警报"""
        alert_key = f"{attack_type.value}:{source}"
        now = time.time()
        if alert_key in self._last_alert_time:
            if now - self._last_alert_time[alert_key] < self._alert_cooldown:
                return None

        self._last_alert_time[alert_key] = now

        # 限制警报列表大小
        self._cleanup_alerts()

        alert = AttackAlert(
            attack_type=attack_type,
            severity=min(1.0, max(0.0, severity)),
            source=source,
            description=description,
            metadata=metadata or {},
        )
        self._alerts.append(alert)

        # 降低来源信誉
        current_rep = self._node_reputation.get(source, 1.0)
        self._node_reputation[source] = max(0.0, current_rep - 0.1)

        # 通知回调
        for callback in self._callbacks:
            try:
                callback(alert)
            except Exception as e:
                logger.error(f"警报回调错误: {e}")

        logger.warning(f"攻击检测: [{attack_type.value}] {description}")
        return alert

    def get_node_reputation(self, node_id: str) -> float:
        """获取节点信誉"""
        return self._node_reputation.get(node_id, 1.0)

    def get_alerts(self, limit: int = 100) -> List[AttackAlert]:
        """获取最近的警报"""
        limit = min(limit, 1000)  # 限制返回数量
        return self._alerts[-limit:]
    
    def get_banned_ips(self) -> List[BannedIP]:
        """获取被封禁的IP列表"""
        if self._auto_response:
            return self._auto_response.get_banned_ips()
        return []
    
    def unban_ip(self, ip: str) -> bool:
        """手动解封IP"""
        if self._auto_response:
            return self._auto_response.unban_ip(ip)
        return False

    def get_stats(self) -> dict:
        return {
            "total_alerts": len(self._alerts),
            "alerts_by_type": {
                t.value: sum(1 for a in self._alerts if a.attack_type == t)
                for t in AttackType
            },
            "packets_observed": self._window.packet_count,
            "tracked_nodes": len(self._node_reputation),
            "seen_packets_cache_size": len(self._seen_packets),
            "banned_ips_count": len(self.get_banned_ips()),
            "statistical_detectors": len(self._stat_detectors),
        }


# 向后兼容
AttackDetector = SecureAttackDetector
