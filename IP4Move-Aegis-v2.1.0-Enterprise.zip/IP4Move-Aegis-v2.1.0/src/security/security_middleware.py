"""
通用安全防御中间件

为 IP4Move-Aegis 提供多层安全防御:
- F-004: SQL注入防护
- F-005: 命令注入防护
- F-006: 文件上传安全
- S-004: SSRF防护
- S-005: XSS防护
- H-005: 目录遍历防护
- H-006: 验证码支持
- M-001: CORS增强
- M-009: 错误信息脱敏
"""

import os
import re
import ipaddress
import logging
import secrets
import time
import hashlib
import hmac
from typing import Optional, Set, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# ============================================
# F-004: SQL注入防护
# ============================================

# 常见SQL注入模式
SQL_INJECTION_PATTERNS = re.compile(
    r"""
    (?i)
    (\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|CREATE|EXEC|EXECUTE)\b
    .*\b(FROM|INTO|TABLE|DATABASE|WHERE|SET|SELECT)\b)
    |
    (\bUNION\b\s+\bSELECT\b)
    |
    (--|;|/\*|\*/|xp_|0x[0-9a-fA-F]{8,})
    |
    (\b(OR|AND)\s+\d+\s*=\s*\d+)
    |
    ('\s*(OR|AND)\s+')
    |
    (CHAR\s*\(|CONCAT\s*\(|GROUP_CONCAT\s*\()
    |
    (WAITFOR\s+DELAY|BENCHMARK\s*\(|SLEEP\s*\()
    """,
    re.VERBOSE,
)


def detect_sql_injection(input_str: str) -> bool:
    """
    检测输入中是否包含SQL注入模式
    
    Args:
        input_str: 待检测的输入字符串
        
    Returns:
        True 如果检测到可能的SQL注入
    """
    if not isinstance(input_str, str):
        return False
    return bool(SQL_INJECTION_PATTERNS.search(input_str))


def sanitize_sql_input(input_str: str) -> str:
    """
    净化SQL输入（防御性编程，建议使用参数化查询）
    
    Args:
        input_str: 待净化的输入
        
    Returns:
        净化后的字符串
    """
    if not isinstance(input_str, str):
        return str(input_str)
    # 转义单引号
    return input_str.replace("'", "''").replace("\\", "\\\\")


# ============================================
# F-005: 命令注入防护
# ============================================

# 命令注入模式
COMMAND_INJECTION_PATTERNS = re.compile(
    r"""
    (?i)
    (;|\||&|\$\(|`|<|>)
    |
    (\b(cat|ls|rm|wget|curl|bash|sh|nc|ncat|python|perl|ruby|php)\b\s)
    |
    (\$\{.*\})
    |
    (\b(eval|exec|system|popen|proc_open|passthru|shell_exec)\s*\()
    |
    (/etc/passwd|/etc/shadow|/proc/|/dev/)
    """,
    re.VERBOSE,
)


def detect_command_injection(input_str: str) -> bool:
    """
    检测输入中是否包含命令注入模式
    
    Args:
        input_str: 待检测的输入字符串
        
    Returns:
        True 如果检测到可能的命令注入
    """
    if not isinstance(input_str, str):
        return False
    return bool(COMMAND_INJECTION_PATTERNS.search(input_str))


# ============================================
# F-006: 文件上传安全
# ============================================

# 允许的文件类型 (MIME类型)
ALLOWED_UPLOAD_MIME_TYPES: Set[str] = {
    "application/json",
    "text/plain",
    "application/octet-stream",
}

# 允许的文件扩展名
ALLOWED_UPLOAD_EXTENSIONS: Set[str] = {".json", ".txt", ".bin", ".dat", ".pem", ".pub"}

# 危险文件扩展名（禁止上传）
DANGEROUS_EXTENSIONS: Set[str] = {
    ".py", ".sh", ".bash", ".bat", ".cmd", ".ps1",
    ".exe", ".dll", ".so", ".dylib",
    ".php", ".asp", ".aspx", ".jsp",
    ".html", ".htm", ".js", ".vbs",
    ".sql", ".rb", ".pl",
    ".pif", ".scr", ".com",
}

MAX_UPLOAD_FILE_SIZE = 10 * 1024 * 1024  # 10MB


@dataclass
class UploadValidationResult:
    """文件上传验证结果"""
    is_valid: bool
    error: str = ""
    sanitized_filename: str = ""


def validate_upload(
    filename: str,
    file_size: int,
    content_type: str = "",
    content_bytes: Optional[bytes] = None,
) -> UploadValidationResult:
    """
    验证文件上传安全性
    
    Args:
        filename: 原始文件名
        file_size: 文件大小(字节)
        content_type: MIME类型
        content_bytes: 文件内容(可选，用于魔术字节验证)
        
    Returns:
        UploadValidationResult 验证结果
    """
    # 检查文件名
    if not filename or len(filename) > 255:
        return UploadValidationResult(False, "Invalid filename")

    # 检查文件名中的路径遍历
    if ".." in filename or "/" in filename or "\\" in filename:
        return UploadValidationResult(False, "Path traversal detected in filename")

    # 检查空字节注入
    if "\x00" in filename:
        return UploadValidationResult(False, "Null byte detected in filename")

    # 检查危险扩展名
    ext = os.path.splitext(filename)[1].lower()
    if ext in DANGEROUS_EXTENSIONS:
        return UploadValidationResult(False, f"Dangerous file extension: {ext}")

    # 检查文件大小
    if file_size > MAX_UPLOAD_FILE_SIZE:
        return UploadValidationResult(False, f"File too large: {file_size} > {MAX_UPLOAD_FILE_SIZE}")

    if file_size <= 0:
        return UploadValidationResult(False, "Empty file")

    # 生成安全的文件名
    safe_name = secrets.token_hex(16) + ext

    return UploadValidationResult(
        is_valid=True,
        sanitized_filename=safe_name,
    )


# ============================================
# S-004: SSRF防护
# ============================================


def validate_url_safety(url: str) -> Tuple[bool, str]:
    """
    验证URL安全性，防止SSRF攻击
    
    Args:
        url: 待验证的URL
        
    Returns:
        (is_safe, reason) 元组
    """
    if not isinstance(url, str):
        return False, "URL must be a string"

    url = url.strip()

    # 检查协议
    if not url.startswith(("http://", "https://")):
        return False, "Only HTTP/HTTPS protocols are allowed"

    # 解析URL
    from urllib.parse import urlparse
    try:
        parsed = urlparse(url)
    except Exception:
        return False, "Invalid URL format"

    hostname = parsed.hostname
    if not hostname:
        return False, "Missing hostname"

    # 阻止私有/内部IP地址
    try:
        ip = ipaddress.ip_address(hostname)
        if ip.is_private or ip.is_loopback or ip.is_reserved or ip.is_link_local:
            return False, "Private/internal IP addresses are not allowed"
        if ip.is_multicast or ip.is_unspecified:
            return False, "Multicast/unspecified addresses are not allowed"
    except ValueError:
        # 不是IP地址，检查域名
        blocked_domains = {
            "localhost", "metadata.google.internal", "metadata",
            "169.254.169.254", "instance-data",
        }
        if hostname.lower() in blocked_domains:
            return False, f"Blocked hostname: {hostname}"

        # 阻止通过DNS重绑定绕过（检查解析后的IP）
        import socket
        try:
            resolved_ips = socket.getaddrinfo(hostname, None)
            for _, _, _, _, sockaddr in resolved_ips:
                ip = ipaddress.ip_address(sockaddr[0])
                if ip.is_private or ip.is_loopback or ip.is_reserved:
                    return False, f"Hostname resolves to private IP: {sockaddr[0]}"
        except socket.gaierror:
            pass

    # 阻止非标准端口
    port = parsed.port
    if port and port not in (80, 443, 8080, 8443):
        return False, f"Non-standard port not allowed: {port}"

    return True, ""


# ============================================
# S-005: XSS防护
# ============================================


def sanitize_html_output(input_str: str) -> str:
    """
    净化HTML输出，防止XSS攻击
    
    Args:
        input_str: 待净化的字符串
        
    Returns:
        净化后的安全字符串
    """
    if not isinstance(input_str, str):
        return str(input_str)
    
    # HTML实体编码
    replacements = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#x27;",
        "/": "&#x2F;",
    }
    
    result = input_str
    for char, entity in replacements.items():
        result = result.replace(char, entity)
    
    return result


def detect_xss(input_str: str) -> bool:
    """
    检测输入中是否包含XSS攻击模式
    
    Args:
        input_str: 待检测的输入字符串
        
    Returns:
        True 如果检测到可能的XSS攻击
    """
    if not isinstance(input_str, str):
        return False
    
    xss_patterns = re.compile(
        r"""
        (?i)
        (<script[\s>])
        |
        (javascript\s*:)
        |
        (on\w+\s*=)  # onclick=, onerror=, etc.
        |
        (<iframe[\s>])
        |
        (<object[\s>])
        |
        (<embed[\s>])
        |
        (<img[^>]+on\w+\s*=)
        |
        (expression\s*\()
        |
        (url\s*\(\s*['"]?\s*javascript)
        """,
        re.VERBOSE,
    )
    
    return bool(xss_patterns.search(input_str))


# ============================================
# H-005: 目录遍历防护
# ============================================


def validate_path_safety(file_path: str, allowed_base_dir: Optional[str] = None) -> Tuple[bool, str]:
    """
    验证文件路径安全性，防止目录遍历攻击
    
    Args:
        file_path: 待验证的文件路径
        allowed_base_dir: 允许的基础目录(可选)
        
    Returns:
        (is_safe, reason) 元组
    """
    if not isinstance(file_path, str):
        return False, "Path must be a string"

    # 检查路径遍历模式
    if ".." in file_path:
        return False, "Path traversal detected"

    # 检查空字节
    if "\x00" in file_path:
        return False, "Null byte detected in path"

    # 规范化路径
    normalized = os.path.normpath(file_path)

    # 检查绝对路径（如果未指定基础目录）
    if os.path.isabs(normalized) and allowed_base_dir is None:
        return False, "Absolute paths not allowed without base directory"

    # 如果指定了基础目录，验证路径是否在其下
    if allowed_base_dir:
        base = os.path.realpath(allowed_base_dir)
        target = os.path.realpath(normalized)
        if not target.startswith(base + os.sep) and target != base:
            return False, f"Path escapes allowed directory: {allowed_base_dir}"

    return True, ""


# ============================================
# H-006: 验证码支持
# ============================================


@dataclass
class CaptchaChallenge:
    """验证码挑战"""
    challenge_id: str
    question: str
    answer_hash: str
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0
    attempts: int = 0
    max_attempts: int = 3


class CaptchaManager:
    """
    验证码管理器
    
    提供数学运算验证码，防止暴力破解和自动化攻击。
    """

    def __init__(self, expiry_seconds: int = 300, max_challenges: int = 10000):
        self._challenges: dict[str, CaptchaChallenge] = {}
        self._expiry = expiry_seconds
        self._max_challenges = max_challenges

    def generate(self) -> CaptchaChallenge:
        """
        生成验证码挑战
        
        Returns:
            CaptchaChallenge 验证码挑战
        """
        # 清理过期挑战
        self._cleanup()

        # 生成数学题
        a = secrets.randbelow(50) + 1
        b = secrets.randbelow(50) + 1
        op = secrets.choice(["+", "-", "*"])

        if op == "+":
            answer = a + b
            question = f"{a} + {b} = ?"
        elif op == "-":
            if a < b:
                a, b = b, a
            answer = a - b
            question = f"{a} - {b} = ?"
        else:
            a = secrets.randbelow(12) + 1
            b = secrets.randbelow(12) + 1
            answer = a * b
            question = f"{a} × {b} = ?"

        challenge_id = secrets.token_hex(16)
        answer_hash = hashlib.sha256(str(answer).encode()).hexdigest()

        challenge = CaptchaChallenge(
            challenge_id=challenge_id,
            question=question,
            answer_hash=answer_hash,
            expires_at=time.time() + self._expiry,
        )

        self._challenges[challenge_id] = challenge
        return challenge

    def verify(self, challenge_id: str, answer: str) -> bool:
        """
        验证验证码答案
        
        Args:
            challenge_id: 挑战ID
            answer: 用户答案
            
        Returns:
            True 如果验证通过
        """
        challenge = self._challenges.get(challenge_id)
        if not challenge:
            return False

        # 检查过期
        if time.time() > challenge.expires_at:
            del self._challenges[challenge_id]
            return False

        # 检查尝试次数
        challenge.attempts += 1
        if challenge.attempts > challenge.max_attempts:
            del self._challenges[challenge_id]
            return False

        # 恒定时间比较
        answer_hash = hashlib.sha256(str(answer).strip().encode()).hexdigest()
        if hmac.compare_digest(answer_hash, challenge.answer_hash):
            # 验证通过，删除挑战
            del self._challenges[challenge_id]
            return True

        return False

    def _cleanup(self) -> None:
        """清理过期挑战"""
        now = time.time()
        expired = [k for k, v in self._challenges.items() if now > v.expires_at]
        for k in expired:
            del self._challenges[k]

        # 限制最大挑战数
        if len(self._challenges) > self._max_challenges:
            sorted_items = sorted(
                self._challenges.items(),
                key=lambda x: x[1].created_at,
            )
            for k, _ in sorted_items[: len(sorted_items) - self._max_challenges]:
                del self._challenges[k]


# ============================================
# M-001: CORS增强
# ============================================

# 允许的HTTP方法
ALLOWED_CORS_METHODS: Set[str] = {"GET", "POST", "PUT", "DELETE", "OPTIONS"}

# 允许的请求头
ALLOWED_CORS_HEADERS: Set[str] = {
    "X-API-Key",
    "Authorization",
    "Content-Type",
    "Accept",
    "Origin",
}


def validate_cors_request(
    origin: str,
    method: str,
    headers: dict,
    allowed_origins: Optional[Set[str]] = None,
) -> Tuple[bool, str]:
    """
    验证CORS请求安全性
    
    Args:
        origin: 请求来源
        method: HTTP方法
        headers: 请求头
        allowed_origins: 允许的来源列表
        
    Returns:
        (is_allowed, reason) 元组
    """
    # 检查方法
    if method.upper() not in ALLOWED_CORS_METHODS:
        return False, f"Method not allowed: {method}"

    # 如果指定了允许的来源，验证origin
    if allowed_origins and origin not in allowed_origins:
        return False, f"Origin not allowed: {origin}"

    # 检查null origin（可能是沙箱iframe）
    if origin == "null":
        return False, "Null origin not allowed"

    return True, ""


# ============================================
# M-009: 错误信息脱敏
# ============================================


class SafeErrorFormatter:
    """安全错误格式化器"""

    # 不应暴露给用户的内部信息模式
    SENSITIVE_PATTERNS = re.compile(
        r"""
        (?i)
        (file\s*["'][^"']+["'])       # 文件路径
        |
        (line\s+\d+)                  # 行号
        |
        (traceback|exception|error)    # 堆栈信息
        |
        (/home/|/var/|/etc/|/usr/)    # 系统路径
        |
        (password|secret|key|token)    # 敏感字段名
        """,
        re.VERBOSE,
    )

    @classmethod
    def format_for_user(cls, error: Exception) -> dict:
        """
        格式化错误信息供用户查看（脱敏）
        
        Args:
            error: 异常对象
            
        Returns:
            安全的错误信息字典
        """
        error_type = type(error).__name__
        error_msg = str(error)

        # 脱敏
        sanitized_msg = cls.SENSITIVE_PATTERNS.sub("[REDACTED]", error_msg)

        return {
            "error": {
                "code": error_type,
                "message": sanitized_msg if sanitized_msg else "An internal error occurred",
                "request_id": secrets.token_hex(8),
            }
        }

    @classmethod
    def format_for_log(cls, error: Exception, include_traceback: bool = True) -> str:
        """
        格式化错误信息供日志记录（完整信息）
        
        Args:
            error: 异常对象
            include_traceback: 是否包含堆栈
            
        Returns:
            完整的错误信息字符串
        """
        import traceback
        msg = f"{type(error).__name__}: {error}"
        if include_traceback:
            msg += f"\n{traceback.format_exc()}"
        return msg


# ============================================
# 综合输入验证
# ============================================


def validate_input_security(input_str: str) -> Tuple[bool, list]:
    """
    综合输入安全验证
    
    Args:
        input_str: 待验证的输入字符串
        
    Returns:
        (is_safe, detected_threats) 元组
    """
    threats = []

    if detect_sql_injection(input_str):
        threats.append("SQL_INJECTION")

    if detect_command_injection(input_str):
        threats.append("COMMAND_INJECTION")

    if detect_xss(input_str):
        threats.append("XSS")

    return len(threats) == 0, threats
