"""安全模块"""

from src.security.noise_injector import NoiseInjector
from src.security.mtu_padding import MTUPadding
from src.security.protocol_obfuscator import ProtocolObfuscator
from src.security.attack_detector import (
    AttackDetector,
    SecureAttackDetector,
    AttackType,
    AttackAlert,
    BannedIP,
)
from src.security.cert_pinning import (
    CertificatePinner,
    PinningHTTPSConnection,
    extract_cert_fingerprint,
    extract_cert_fingerprint_base64,
    verify_hostname_pinning,
)

# XDP 引擎集成 (新增)
try:
    from src.xdp_engine import XDPController, XDPEventHandler
    XDP_AVAILABLE = True
except ImportError:
    XDP_AVAILABLE = False

# 免疫同步集成 (新增)
try:
    from src.immune_sync import (
        AttackFingerprint,
        FingerprintType,
        ImmuneSyncProtocol,
        ImmunityDatabase,
        GlobalImmunityCoordinator,
    )
    IMMUNE_SYNC_AVAILABLE = True
except ImportError:
    IMMUNE_SYNC_AVAILABLE = False

__all__ = [
    "NoiseInjector",
    "MTUPadding",
    "ProtocolObfuscator",
    "AttackDetector",
    "SecureAttackDetector",
    "AttackType",
    "AttackAlert",
    "BannedIP",
    "CertificatePinner",
    "PinningHTTPSConnection",
    "extract_cert_fingerprint",
    "extract_cert_fingerprint_base64",
    "verify_hostname_pinning",
    # XDP 引擎 (可选)
    "XDPController",
    "XDPEventHandler",
    "XDP_AVAILABLE",
    # 免疫同步 (可选)
    "AttackFingerprint",
    "FingerprintType",
    "ImmuneSyncProtocol",
    "ImmunityDatabase",
    "GlobalImmunityCoordinator",
    "IMMUNE_SYNC_AVAILABLE",
]
