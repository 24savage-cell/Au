"""
抗审查设计 - 主动探测防御

修复问题:
1. 伪装流量无真实连接 → 主动探测可识别
2. 无协议一致性测试 → 响应模式异常
3. 无"暗号"机制 → 易被探测

解决方案:
1. 协议一致性验证
2. 主动探测检测与响应
3. 连接前密码学证明

版本: v2.1.0
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import secrets
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Dict, List, Optional, Any

logger = logging.getLogger(__name__)


# ============================================================================
# 探测类型
# ============================================================================

class ProbeType(Enum):
    """主动探测类型"""
    TCP_SYN = auto()        # TCP SYN探测
    HTTP_GET = auto()       # HTTP GET探测
    TLS_CLIENT_HELLO = auto()  # TLS握手探测
    DNS_QUERY = auto()      # DNS查询探测
    DOH_QUERY = auto()      # DoH查询探测
    UNKNOWN = auto()


# ============================================================================
# 探测检测器
# ============================================================================

@dataclass
class ProbeSignature:
    """探测特征签名"""
    probe_type: ProbeType
    source_ip: str
    timestamp: float
    payload_hash: bytes
    frequency: int = 1
    last_seen: float = field(default_factory=time.time)


class ProbeDetector:
    """
    主动探测检测器
    
    检测策略:
    1. 连接频率异常
    2. 请求模式异常
    3. 已知探测特征匹配
    """
    
    def __init__(
        self,
        max_connections_per_ip: int = 10,
        connection_window: float = 60.0,
        probe_threshold: int = 5,
    ):
        self._max_conn = max_connections_per_ip
        self._window = connection_window
        self._threshold = probe_threshold
        
        # IP -> 连接时间戳列表
        self._connections: Dict[str, List[float]] = {}
        # IP -> 探测签名
        self._probes: Dict[str, ProbeSignature] = {}
        # 黑名单IP
        self._blacklist: set = set()
    
    def record_connection(self, source_ip: str) -> bool:
        """
        记录连接并检测是否为探测
        
        Returns:
            True如果允许连接，False如果是探测
        """
        # 检查黑名单
        if source_ip in self._blacklist:
            return False
        
        now = time.time()
        
        # 记录连接
        if source_ip not in self._connections:
            self._connections[source_ip] = []
        
        # 清理过期记录
        self._connections[source_ip] = [
            t for t in self._connections[source_ip]
            if now - t < self._window
        ]
        
        # 检查频率
        if len(self._connections[source_ip]) >= self._max_conn:
            self._mark_as_probe(source_ip, ProbeType.TCP_SYN)
            return False
        
        self._connections[source_ip].append(now)
        return True
    
    def _mark_as_probe(self, source_ip: str, probe_type: ProbeType):
        """标记为探测源"""
        if source_ip in self._probes:
            self._probes[source_ip].frequency += 1
            self._probes[source_ip].last_seen = time.time()
        else:
            self._probes[source_ip] = ProbeSignature(
                probe_type=probe_type,
                source_ip=source_ip,
                timestamp=time.time(),
                payload_hash=b"\x00" * 16,
            )
        
        # 超过阈值加入黑名单
        if self._probes[source_ip].frequency >= self._threshold:
            self._blacklist.add(source_ip)
            logger.warning(f"IP {source_ip} 已加入黑名单 (探测行为)")
    
    def analyze_request(
        self,
        source_ip: str,
        request_data: bytes,
        request_type: str = "http",
    ) -> Tuple[bool, Optional[ProbeType]]:
        """
        分析请求是否为探测
        
        Returns:
            (是否正常, 探测类型)
        """
        # 检查已知探测特征
        probe_type = self._match_probe_signature(request_data, request_type)
        
        if probe_type:
            self._mark_as_probe(source_ip, probe_type)
            return False, probe_type
        
        return True, None
    
    def _match_probe_signature(
        self,
        data: bytes,
        request_type: str,
    ) -> Optional[ProbeType]:
        """匹配已知探测特征"""
        # HTTP探测特征
        if request_type == "http":
            # 空User-Agent或异常User-Agent
            if b"User-Agent:" not in data and len(data) < 200:
                return ProbeType.HTTP_GET
            
            # 常见探测路径
            probe_paths = [b"/admin", b"/.env", b"/config", b"/wp-admin"]
            for path in probe_paths:
                if path in data:
                    return ProbeType.HTTP_GET
        
        # TLS探测特征
        elif request_type == "tls":
            # 不完整的ClientHello
            if len(data) < 100:
                return ProbeType.TLS_CLIENT_HELLO
        
        return None
    
    def is_blacklisted(self, source_ip: str) -> bool:
        """检查IP是否在黑名单"""
        return source_ip in self._blacklist
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            "total_ips_tracked": len(self._connections),
            "known_probes": len(self._probes),
            "blacklist_size": len(self._blacklist),
            "top_probes": sorted(
                [(ip, sig.frequency) for ip, sig in self._probes.items()],
                key=lambda x: x[1],
                reverse=True,
            )[:10],
        }


# ============================================================================
# 协议一致性验证
# ============================================================================

class ProtocolConsistencyChecker:
    """
    协议一致性验证器
    
    确保伪装响应与真实协议完全一致
    """
    
    @staticmethod
    async def verify_doh_response(
        our_response: bytes,
        query_domain: str,
        real_doh_url: str = "https://dns.google/dns-query",
    ) -> Tuple[bool, str]:
        """
        验证DoH响应与真实响应一致性
        
        Returns:
            (是否一致, 差异描述)
        """
        try:
            import httpx
            
            # 构建真实DNS查询
            from src.traffic_disguise_v2.real_transport import (
                DNSPacketBuilder, DataEncoder
            )
            
            query_packet = DNSPacketBuilder.build_query(query_domain)
            
            # 发送到真实DoH服务器
            async with httpx.AsyncClient(timeout=5.0) as client:
                real_response = await client.post(
                    real_doh_url,
                    content=query_packet,
                    headers={
                        "Accept": "application/dns-message",
                        "Content-Type": "application/dns-message",
                    },
                )
            
            if real_response.status_code != 200:
                return False, f"真实DoH返回 {real_response.status_code}"
            
            real_data = real_response.content
            
            # 比较响应结构 (不比较具体内容)
            # DNS响应头部格式应该一致
            if len(our_response) < 12 or len(real_data) < 12:
                return False, "响应长度不足"
            
            # 检查QR位 (查询/响应标志)
            our_qr = (our_response[2] >> 7) & 1
            real_qr = (real_data[2] >> 7) & 1
            
            if our_qr != real_qr:
                return False, f"QR位不一致: ours={our_qr}, real={real_qr}"
            
            # 检查ANCOUNT (回答数)
            our_ancount = (our_response[6] << 8) | our_response[7]
            real_ancount = (real_data[6] << 8) | real_data[7]
            
            # 我们的响应应该有回答 (可能是模拟的)
            if our_ancount == 0 and real_ancount > 0:
                return False, "缺少DNS回答"
            
            return True, "一致"
            
        except Exception as e:
            return False, f"验证失败: {e}"
    
    @staticmethod
    def verify_tls_response(our_response: bytes) -> Tuple[bool, str]:
        """
        验证TLS响应格式
        
        检查是否为合法的TLS ServerHello
        """
        if len(our_response) < 5:
            return False, "响应太短"
        
        # TLS记录层
        content_type = our_response[0]
        if content_type != 0x16:  # Handshake
            return False, f"非Handshake内容类型: {content_type}"
        
        # TLS版本
        version = (our_response[1] << 8) | our_response[2]
        if version not in [0x0301, 0x0302, 0x0303]:  # TLS 1.0/1.1/1.2
            # TLS 1.3使用0x0303在记录层
            if version != 0x0303:
                return False, f"异常TLS版本: {version:#x}"
        
        return True, "TLS格式正确"


# ============================================================================
# 连接前证明 (暗号机制)
# ============================================================================

@dataclass
class ConnectionProof:
    """连接证明"""
    timestamp: float
    challenge: bytes
    response: bytes
    node_id: bytes
    difficulty: int = 16
    
    def to_bytes(self) -> bytes:
        """序列化"""
        import struct
        return (
            struct.pack(">d", self.timestamp) +
            self.challenge +
            self.response +
            self.node_id +
            struct.pack(">I", self.difficulty)
        )
    
    @classmethod
    def from_bytes(cls, data: bytes) -> "ConnectionProof":
        """反序列化"""
        import struct
        timestamp = struct.unpack(">d", data[:8])[0]
        challenge = data[8:40]
        response = data[40:72]
        node_id = data[72:92]
        difficulty = struct.unpack(">I", data[92:96])[0]
        
        return cls(
            timestamp=timestamp,
            challenge=challenge,
            response=response,
            node_id=node_id,
            difficulty=difficulty,
        )


class ProofOfWorkChallenge:
    """
    连接前PoW挑战
    
    客户端必须完成PoW才能连接，防止主动探测
    
    工作流程:
    1. 客户端请求挑战
    2. 服务端发送challenge
    3. 客户端计算response (PoW)
    4. 服务端验证后允许连接
    """
    
    def __init__(
        self,
        difficulty: int = 16,
        challenge_ttl: float = 60.0,
    ):
        self._difficulty = difficulty
        self._challenge_ttl = challenge_ttl
        
        # 待验证的挑战
        self._pending_challenges: Dict[bytes, float] = {}
    
    def create_challenge(self, node_id: bytes) -> Tuple[bytes, int]:
        """
        创建挑战
        
        Returns:
            (challenge, difficulty)
        """
        challenge = secrets.token_bytes(32)
        self._pending_challenges[challenge] = time.time()
        
        return challenge, self._difficulty
    
    def verify_response(
        self,
        challenge: bytes,
        response: bytes,
        node_id: bytes,
    ) -> bool:
        """
        验证PoW响应
        
        检查: SHA256(challenge || response)前difficulty位为0
        """
        # 检查挑战是否存在
        if challenge not in self._pending_challenges:
            return False
        
        # 检查是否过期
        if time.time() - self._pending_challenges[challenge] > self._challenge_ttl:
            del self._pending_challenges[challenge]
            return False
        
        # 验证PoW
        digest = hashlib.sha256(challenge + response).digest()
        
        # 检查前difficulty位
        full_bytes = self._difficulty // 8
        extra_bits = self._difficulty % 8
        
        if digest[:full_bytes] != b"\x00" * full_bytes:
            return False
        
        if extra_bits > 0:
            extra_byte = digest[full_bytes]
            if extra_byte >= (1 << (8 - extra_bits)):
                return False
        
        # 验证通过，移除挑战
        del self._pending_challenges[challenge]
        logger.info(f"PoW验证通过: node={node_id.hex()[:16]}")
        
        return True
    
    @staticmethod
    def solve_challenge(
        challenge: bytes,
        difficulty: int,
        max_iterations: int = 2**20,
    ) -> Optional[bytes]:
        """
        解决PoW挑战 (客户端)
        
        Returns:
            response，失败返回None
        """
        nonce = 0
        target_bytes = difficulty // 8
        extra_bits = difficulty % 8
        
        while nonce < max_iterations:
            response = nonce.to_bytes(8, "big")
            digest = hashlib.sha256(challenge + response).digest()
            
            if digest[:target_bytes] == b"\x00" * target_bytes:
                if extra_bits == 0:
                    return response
                if digest[target_bytes] < (1 << (8 - extra_bits)):
                    return response
            
            nonce += 1
        
        return None


# ============================================================================
# 抗审查管理器
# ============================================================================

class AntiCensorshipManager:
    """
    抗审查管理器
    
    整合:
    - 探测检测
    - 协议一致性验证
    - 连接前证明
    """
    
    def __init__(
        self,
        pow_enabled: bool = True,
        pow_difficulty: int = 16,
    ):
        self._probe_detector = ProbeDetector()
        self._consistency_checker = ProtocolConsistencyChecker()
        self._pow = ProofOfWorkChallenge(difficulty=pow_difficulty) if pow_enabled else None
        
        self._pow_enabled = pow_enabled
    
    def check_connection(self, source_ip: str) -> Tuple[bool, str]:
        """
        检查连接是否允许
        
        Returns:
            (是否允许, 原因)
        """
        # 黑名单检查
        if self._probe_detector.is_blacklisted(source_ip):
            return False, "IP在黑名单中"
        
        # 频率检查
        if not self._probe_detector.record_connection(source_ip):
            return False, "连接频率超限"
        
        return True, "允许"
    
    def require_pow(self, node_id: bytes) -> Optional[Tuple[bytes, int]]:
        """
        要求PoW证明
        
        Returns:
            (challenge, difficulty) 或 None (如果不需要)
        """
        if self._pow_enabled and self._pow:
            return self._pow.create_challenge(node_id)
        return None
    
    def verify_pow(
        self,
        challenge: bytes,
        response: bytes,
        node_id: bytes,
    ) -> bool:
        """验证PoW"""
        if self._pow_enabled and self._pow:
            return self._pow.verify_response(challenge, response, node_id)
        return True  # 不需要PoW时直接通过
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            "probe_detection": self._probe_detector.get_stats(),
            "pow_enabled": self._pow_enabled,
        }
