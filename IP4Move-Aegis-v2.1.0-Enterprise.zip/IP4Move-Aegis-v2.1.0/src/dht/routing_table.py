"""
DHT 路由表模块

实现 Kademlia 路由表，管理节点联系人信息。
"""

import time
import logging
from typing import Optional, List, Dict
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class Contact:
    """联系人"""
    node_id: bytes
    address: str
    port: int
    last_seen: float = field(default_factory=time.time)
    last_pinged: float = 0.0
    ping_count: int = 0
    failed_pings: int = 0

    @property
    def is_stale(self) -> bool:
        """是否过期 (15分钟未响应)"""
        return time.time() - self.last_seen > 900

    @property
    def success_rate(self) -> float:
        if self.ping_count == 0:
            return 1.0
        return (self.ping_count - self.failed_pings) / self.ping_count


class KBucket:
    """
    Kademlia K-Bucket

    存储距离范围相同的节点联系人。
    """

    def __init__(self, min_range: int, max_range: int, k: int = 20):
        self._min_range = min_range
        self._max_range = max_range
        self._k = k
        self._contacts: List[Contact] = []
        self._replacement_cache: List[Contact] = []

    @property
    def size(self) -> int:
        return len(self._contacts)

    @property
    def is_full(self) -> bool:
        return len(self._contacts) >= self._k

    def add_contact(self, contact: Contact) -> Optional[Contact]:
        """
        添加联系人

        如果桶已满，检查最旧联系人是否响应。
        响应则替换，不响应则加入替换缓存。

        Returns:
            被替换的联系人，或 None
        """
        # 检查是否已存在
        for i, existing in enumerate(self._contacts):
            if existing.node_id == contact.node_id:
                # 更新已有联系人
                self._contacts[i] = contact
                return None

        if not self.is_full:
            self._contacts.append(contact)
            self._contacts.sort(key=lambda c: c.last_seen, reverse=True)
            return None

        # 桶已满，检查最旧联系人
        oldest = self._contacts[-1]
        if oldest.is_stale:
            # 替换最旧的联系人
            self._contacts[-1] = contact
            self._contacts.sort(key=lambda c: c.last_seen, reverse=True)
            return oldest
        else:
            # 加入替换缓存
            self._replacement_cache.append(contact)
            if len(self._replacement_cache) > self._k:
                self._replacement_cache.pop(0)
            return None

    def remove_contact(self, node_id: bytes) -> bool:
        """移除联系人"""
        for i, contact in enumerate(self._contacts):
            if contact.node_id == node_id:
                removed = self._contacts.pop(i)
                # 从替换缓存中补充
                if self._replacement_cache:
                    replacement = self._replacement_cache.pop(0)
                    self._contacts.append(replacement)
                return True
        return False

    def get_contact(self, node_id: bytes) -> Optional[Contact]:
        """获取联系人"""
        for contact in self._contacts:
            if contact.node_id == node_id:
                return contact
        return None

    def get_all_contacts(self) -> List[Contact]:
        """获取所有联系人"""
        return list(self._contacts)

    def needs_refresh(self) -> bool:
        """是否需要刷新"""
        if not self._contacts:
            return False
        oldest = min(self._contacts, key=lambda c: c.last_seen)
        return time.time() - oldest.last_seen > 3600

    def split(self, local_id: bytes) -> tuple:
        """
        分裂桶

        Returns:
            (lower_bucket, upper_bucket)
        """
        mid = (self._min_range + self._max_range) // 2
        lower = KBucket(self._min_range, mid, self._k)
        upper = KBucket(mid + 1, self._max_range, self._k)

        for contact in self._contacts:
            dist = int.from_bytes(
                bytes(a ^ b for a, b in zip(local_id, contact.node_id)), "big"
            )
            if dist <= mid:
                lower.add_contact(contact)
            else:
                upper.add_contact(contact)

        return lower, upper


class RoutingTable:
    """
    Kademlia 路由表

    管理 256 个 K-Bucket (每个 bit 一个桶)。
    """

    def __init__(self, local_id: bytes, k: int = 20):
        self._local_id = local_id
        self._k = k
        self._buckets: List[Optional[KBucket]] = [None] * 256
        # 初始化一个覆盖整个范围的桶
        self._buckets[0] = KBucket(0, 2**256 - 1, k)

    @property
    def size(self) -> int:
        return sum(b.size if b else 0 for b in self._buckets)

    @property
    def bucket_count(self) -> int:
        return sum(1 for b in self._buckets if b is not None)

    def _bucket_index(self, node_id: bytes) -> int:
        """计算节点ID对应的桶索引"""
        distance = int.from_bytes(
            bytes(a ^ b for a, b in zip(self._local_id, node_id)), "big"
        )
        if distance == 0:
            return 0
        # 找到最高有效位
        bit_length = distance.bit_length()
        return bit_length - 1

    def add_contact(self, node_id: bytes, address: str, port: int) -> None:
        """添加联系人到路由表"""
        if node_id == self._local_id:
            return

        idx = self._bucket_index(node_id)
        contact = Contact(
            node_id=node_id,
            address=address,
            port=port,
        )

        bucket = self._buckets[idx]
        if bucket is None:
            bucket = KBucket(0, 2**256 - 1, self._k)
            self._buckets[idx] = bucket

        bucket.add_contact(contact)

    def remove_contact(self, node_id: bytes) -> bool:
        """从路由表移除联系人"""
        idx = self._bucket_index(node_id)
        bucket = self._buckets[idx]
        if bucket:
            return bucket.remove_contact(node_id)
        return False

    def find_closest(self, target_id: bytes, count: int = 20) -> List[Contact]:
        """
        查找最接近目标ID的节点

        Args:
            target_id: 目标ID
            count: 返回数量

        Returns:
            按距离排序的联系人列表
        """
        all_contacts = []
        for bucket in self._buckets:
            if bucket:
                all_contacts.extend(bucket.get_all_contacts())

        # 计算距离并排序
        target_int = int.from_bytes(target_id, "big")
        all_contacts.sort(
            key=lambda c: int.from_bytes(
                bytes(a ^ b for a, b in zip(target_id, c.node_id)), "big"
            )
        )
        return all_contacts[:count]

    def get_bucket(self, index: int) -> Optional[KBucket]:
        """获取指定索引的桶"""
        if 0 <= index < len(self._buckets):
            return self._buckets[index]
        return None

    def get_all_contacts(self) -> List[Contact]:
        """获取所有联系人"""
        contacts = []
        for bucket in self._buckets:
            if bucket:
                contacts.extend(bucket.get_all_contacts())
        return contacts
