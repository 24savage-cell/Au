"""
节点发现模块

通过 DHT 网络发现网络中的节点。
"""

import os
import asyncio
import time
import hashlib
import struct
import logging
from typing import Optional, List, Dict, Callable

logger = logging.getLogger(__name__)


class NodeDiscovery:
    """
    节点发现器

    通过 DHT 网络发现可用的网络节点:
    - 种子节点引导
    - 迭代查找
    - 节点质量评估
    - 定期重新发现
    """

    def __init__(
        self,
        local_node_id: Optional[bytes] = None,
        bootstrap_nodes: Optional[List[Dict]] = None,
        discovery_timeout: float = 10.0,
        max_parallel_lookups: int = 3,
    ):
        self._node_id = local_node_id or os.urandom(32)
        self._bootstrap_nodes = bootstrap_nodes or []
        self._discovery_timeout = discovery_timeout
        self._max_parallel = max_parallel_lookups
        self._discovered_nodes: Dict[str, Dict] = {}
        self._blacklist: set = set()
        self._callbacks: List[Callable] = []
        self._is_running = False
        self._discovery_task: Optional[asyncio.Task] = None

    @property
    def discovered_count(self) -> int:
        return len(self._discovered_nodes)

    def on_node_discovered(self, callback: Callable) -> None:
        """注册节点发现回调"""
        self._callbacks.append(callback)

    async def bootstrap(self) -> List[Dict]:
        """
        通过种子节点引导

        Returns:
            发现的节点列表
        """
        discovered = []
        for seed in self._bootstrap_nodes:
            node_info = {
                "node_id": seed.get("node_id", os.urandom(32).hex()),
                "address": seed["address"],
                "port": seed["port"],
                "discovered_at": time.time(),
                "source": "bootstrap",
                "quality": 0.5,
            }
            node_key = f"{node_info['address']}:{node_info['port']}"
            if node_key not in self._blacklist:
                self._discovered_nodes[node_key] = node_info
                discovered.append(node_info)
                for cb in self._callbacks:
                    try:
                        await cb(node_info)
                    except Exception:
                        pass
        logger.info(f"引导完成: 发现 {len(discovered)} 个种子节点")
        return discovered

    async def discover(self, target_type: str = "mix") -> List[Dict]:
        """
        发现指定类型的节点

        Args:
            target_type: 节点类型 (mix, relay, exit, all)

        Returns:
            发现的节点列表
        """
        results = []
        # 使用种子节点进行迭代查找
        seeds = list(self._discovered_nodes.values())[:self._max_parallel]

        tasks = []
        for seed in seeds:
            tasks.append(self._lookup(seed, target_type))

        if tasks:
            lookup_results = await asyncio.gather(*tasks, return_exceptions=True)
            for result in lookup_results:
                if isinstance(result, list):
                    results.extend(result)

        # 去重
        seen = set()
        unique = []
        for node in results:
            key = f"{node['address']}:{node['port']}"
            if key not in seen and key not in self._blacklist:
                seen.add(key)
                unique.append(node)
                self._discovered_nodes[key] = node

        logger.info(f"发现 {len(unique)} 个 {target_type} 节点")
        return unique

    async def _lookup(self, seed: Dict, target_type: str) -> List[Dict]:
        """从种子节点查找更多节点"""
        # 模拟网络查找
        await asyncio.sleep(0.1)
        # 实际实现中会发送 FIND_NODE RPC
        return []

    def evaluate_quality(self, node: Dict) -> float:
        """
        评估节点质量

        Args:
            node: 节点信息

        Returns:
            质量分数 (0.0 ~ 1.0)
        """
        score = 0.5
        # 考虑延迟
        latency = node.get("latency_ms", 100)
        if latency < 50:
            score += 0.3
        elif latency < 200:
            score += 0.2
        elif latency < 500:
            score += 0.1
        # 考虑在线时间
        uptime = node.get("uptime_s", 0)
        if uptime > 86400:
            score += 0.2
        elif uptime > 3600:
            score += 0.1
        # 考虑成功率
        success_rate = node.get("success_rate", 0.9)
        score += success_rate * 0.2
        return min(1.0, max(0.0, score))

    def blacklist_node(self, address: str, port: int, reason: str = "") -> None:
        """将节点加入黑名单"""
        key = f"{address}:{port}"
        self._blacklist.add(key)
        if key in self._discovered_nodes:
            del self._discovered_nodes[key]
        logger.debug(f"节点加入黑名单: {key} ({reason})")

    def get_discovered_nodes(self, min_quality: float = 0.0) -> List[Dict]:
        """获取已发现的节点"""
        return [
            n for n in self._discovered_nodes.values()
            if self.evaluate_quality(n) >= min_quality
        ]

    async def _periodic_discovery(self) -> None:
        """定期发现新节点"""
        while self._is_running:
            try:
                await self.discover("all")
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"定期发现错误: {e}")
            await asyncio.sleep(300)

    async def start(self) -> None:
        """启动节点发现"""
        self._is_running = True
        await self.bootstrap()
        self._discovery_task = asyncio.create_task(self._periodic_discovery())

    async def stop(self) -> None:
        """停止节点发现"""
        self._is_running = False
        if self._discovery_task:
            self._discovery_task.cancel()
            try:
                await self._discovery_task
            except asyncio.CancelledError:
                pass

    def sign_discovery_response(self, response_data: bytes, signing_key: bytes) -> bytes:
        """
        使用后量子签名签署节点发现响应

        防止恶意节点伪造发现结果。
        """
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PrivateKey,
            )
            private_key = MLDSA65PrivateKey.from_private_bytes(signing_key)
            signature = private_key.sign(response_data)
            return struct.pack("!I", len(signature)) + signature + response_data
        except ImportError:
            import hmac as hmac_mod
            mac = hmac_mod.new(signing_key, response_data, hashlib.sha512).digest()
            return struct.pack("!I", len(mac)) + mac + response_data

    def verify_discovery_response(self, signed_data: bytes, verify_key: bytes) -> Optional[bytes]:
        """
        验证节点发现响应的后量子签名
        """
        try:
            sig_len = struct.unpack("!I", signed_data[:4])[0]
            signature = signed_data[4:4+sig_len]
            response_data = signed_data[4+sig_len:]
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PublicKey,
            )
            public_key = MLDSA65PublicKey.from_public_bytes(verify_key)
            public_key.verify(signature, response_data)
            return response_data
        except Exception:
            return None
