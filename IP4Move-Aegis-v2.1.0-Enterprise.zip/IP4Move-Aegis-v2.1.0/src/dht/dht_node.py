"""
DHT 节点模块 (v1.0.5 真实网络实现 - 性能优化版)

实现内容:
1. 基于 UDP (asyncio.DatagramProtocol) 的真实 DHT 通信
2. PING/PONG 心跳机制（超时 5 秒）
3. FIND_VALUE 迭代查询 k-closest 节点（并行查询优化）
4. STORE 向 k-closest 节点存储数据
5. 入站 RPC 处理（PING/FIND_VALUE/FIND_NODE/STORE）
6. 输入验证、重放保护、速率限制等安全特性
7. 路由表缓存和 find_value 结果缓存

DHT RPC 二进制协议格式:
  [1字节: RPC类型] [32字节: 请求ID] [32字节: 发送者节点ID] [变长: payload]
  RPC类型: 0x01=PING, 0x02=PONG, 0x03=FIND_VALUE, 0x04=FIND_NODE, 0x05=STORE
"""

import os
import time
import asyncio
import struct
import hashlib
import logging
from typing import Optional, Dict, List, Tuple, Any, Set

from src.dht.routing_table import RoutingTable, KBucket, Contact
from src.common.lru_cache import LRUCache
from src.common.rate_limiter import RateLimiter
from src.common.exceptions import DHTError, ValidationError, RateLimitError

logger = logging.getLogger(__name__)

# ==================== 安全常量 ====================
MAX_KEY_SIZE = 256              # 最大键大小(字节)
MAX_VALUE_SIZE = 1024 * 1024    # 最大值大小(1MB)
MAX_STORE_SIZE = 100 * 1024 * 1024  # 最大存储大小(100MB)
MAX_TTL = 86400 * 7             # 最大TTL(7天)
MIN_TTL = 1                     # 最小TTL(1秒)
RATE_LIMIT_WINDOW = 60.0        # 速率限制窗口(秒)
MAX_OPS_PER_WINDOW = 100        # 每窗口最大操作数
MAX_NODE_ID_SIZE = 64           # 最大节点ID大小
NODE_ID_SIZE = 32               # 统一节点ID大小
PING_TIMEOUT = 5.0              # PING 超时(秒)
RPC_TIMEOUT = 5.0               # RPC 超时(秒)
ITERATIVE_QUERY_ALPHA = 3       # 迭代查询并发数
ITERATIVE_QUERY_K = 20          # 迭代查询返回节点数
FIND_VALUE_TIMEOUT = 3.0        # 单个节点 find_value 查询超时(秒)
CACHE_TTL = 300                 # 缓存 TTL (5分钟)

# ==================== RPC 类型常量 ====================
RPC_PING = 0x01
RPC_PONG = 0x02
RPC_FIND_VALUE = 0x03
RPC_FIND_NODE = 0x04
RPC_STORE = 0x05

# RPC 头部大小: 1(类型) + 32(请求ID) + 32(发送者节点ID) = 65 字节
RPC_HEADER_SIZE = 1 + 32 + 32


class DHTSecurityError(DHTError):
    """DHT安全错误"""
    pass


class DHTProtocol(asyncio.DatagramProtocol):
    """
    DHT UDP 协议处理器

    处理入站 DHT RPC 消息，将消息分发给关联的 DHT 节点。
    """

    def __init__(self, node: 'SecureDHTNode'):
        self._node = node
        self._transport: Optional[asyncio.DatagramTransport] = None

    def connection_made(self, transport: asyncio.DatagramTransport) -> None:
        """UDP socket 创建完成"""
        self._transport = transport
        logger.info(f"DHT UDP 监听已启动: {self._node.address}:{self._node.port}")

    def datagram_received(self, data: bytes, addr: Tuple[str, int]) -> None:
        """收到 UDP 数据报"""
        try:
            asyncio.ensure_future(self._node._handle_incoming_datagram(data, addr))
        except Exception as e:
            logger.error(f"处理入站数据报异常: {e}")

    def error_received(self, exc: Exception) -> None:
        """UDP socket 错误"""
        logger.warning(f"DHT UDP 错误: {exc}")

    def connection_lost(self, exc: Optional[Exception]) -> None:
        """UDP socket 关闭"""
        if exc:
            logger.error(f"DHT UDP 连接丢失: {exc}")
        else:
            logger.info("DHT UDP 监听已关闭")
        self._transport = None

    def send_datagram(self, data: bytes, addr: Tuple[str, int]) -> None:
        """发送 UDP 数据报"""
        if self._transport:
            self._transport.sendto(data, addr)


class RPCHandler:
    """
    RPC 处理器类

    处理各种 RPC 类型的独立方法。
    """

    def __init__(self, node: 'SecureDHTNode'):
        self._node = node

    async def handle_ping(
        self,
        request_id: bytes,
        sender_id: bytes,
        payload: bytes,
        addr: Tuple[str, int],
    ) -> None:
        """处理入站 PING 请求，回复 PONG"""
        logger.debug(f"收到 PING: 来源={addr[0]}:{addr[1]}, sender={sender_id.hex()[:16]}...")

        # 回复 PONG（payload 为空）
        pong_msg = self._node._encode_rpc(RPC_PONG, request_id, self._node.node_id)
        if self._node._protocol:
            self._node._protocol.send_datagram(pong_msg, addr)

    def handle_pong(self, request_id: bytes, payload: bytes) -> None:
        """处理入站 PONG 响应，完成等待中的 Future"""
        future = self._node._pending_requests.get(request_id)
        if future and not future.done():
            future.set_result(payload)

    async def handle_find_value(
        self,
        request_id: bytes,
        sender_id: bytes,
        payload: bytes,
        addr: Tuple[str, int],
    ) -> None:
        """
        处理 FIND_VALUE RPC

        payload 格式: [变长: key]
        响应: 如果本地有值，payload = [1字节: 0x01] [变长: value]
           如果本地无值，payload = [1字节: 0x00] [编码的联系人列表]
        """
        if not self._node._validate_key(payload):
            logger.warning("FIND_VALUE: 无效的 key")
            return

        key = payload
        logger.debug(f"收到 FIND_VALUE: key={key.hex()[:16]}..., 来源={addr[0]}:{addr[1]}")

        # 查本地存储
        if key in self._node._store:
            value, expires, _ = self._node._store[key]
            if time.time() < expires:
                # 找到值，返回 0x01 + value
                response_payload = struct.pack("!B", 0x01) + value
                msg = self._node._encode_rpc(RPC_FIND_VALUE, request_id, self._node.node_id, response_payload)
                if self._node._protocol:
                    self._node._protocol.send_datagram(msg, addr)
                return
            else:
                # 清理过期数据
                self._node._total_store_size -= len(value)
                del self._node._store[key]

        # 本地没有值，返回 k-closest 节点
        closest = self._node._routing_table.find_closest(key, count=ITERATIVE_QUERY_K)
        contacts_data = self._node._encode_contacts(closest)
        response_payload = struct.pack("!B", 0x00) + contacts_data
        msg = self._node._encode_rpc(RPC_FIND_VALUE, request_id, self._node.node_id, response_payload)
        if self._node._protocol:
            self._node._protocol.send_datagram(msg, addr)

    async def handle_find_node(
        self,
        request_id: bytes,
        sender_id: bytes,
        payload: bytes,
        addr: Tuple[str, int],
    ) -> None:
        """
        处理 FIND_NODE RPC

        payload 格式: [32字节: target_node_id]
        响应: [编码的联系人列表]
        """
        if len(payload) < 32:
            logger.warning("FIND_NODE: payload 过短")
            return

        target_id = payload[:32]
        logger.debug(f"收到 FIND_NODE: target={target_id.hex()[:16]}..., 来源={addr[0]}:{addr[1]}")

        closest = self._node._routing_table.find_closest(target_id, count=ITERATIVE_QUERY_K)
        contacts_data = self._node._encode_contacts(closest)
        msg = self._node._encode_rpc(RPC_FIND_NODE, request_id, self._node.node_id, contacts_data)
        if self._node._protocol:
            self._node._protocol.send_datagram(msg, addr)

    async def handle_store(
        self,
        request_id: bytes,
        sender_id: bytes,
        payload: bytes,
        addr: Tuple[str, int],
    ) -> None:
        """
        处理 STORE RPC

        payload 格式: [32字节: key] [4字节: ttl] [变长: value]
        响应: [1字节: 0x00=成功, 0x01=失败]
        """
        # 最小 payload: 32(key) + 4(ttl) + 1(至少1字节value) = 37
        if len(payload) < 37:
            logger.warning("STORE: payload 过短")
            return

        key = payload[:32]
        ttl = struct.unpack("!I", payload[32:36])[0]
        value = payload[36:]

        logger.debug(f"收到 STORE: key={key.hex()[:16]}..., 来源={addr[0]}:{addr[1]}")

        # 安全验证
        if not self._node._validate_key(key):
            response = struct.pack("!B", 0x01)
            msg = self._node._encode_rpc(RPC_STORE, request_id, self._node.node_id, response)
            if self._node._protocol:
                self._node._protocol.send_datagram(msg, addr)
            return

        if not self._node._validate_value(value):
            response = struct.pack("!B", 0x01)
            msg = self._node._encode_rpc(RPC_STORE, request_id, self._node.node_id, response)
            if self._node._protocol:
                self._node._protocol.send_datagram(msg, addr)
            return

        if not MIN_TTL <= ttl <= MAX_TTL:
            response = struct.pack("!B", 0x01)
            msg = self._node._encode_rpc(RPC_STORE, request_id, self._node.node_id, response)
            if self._node._protocol:
                self._node._protocol.send_datagram(msg, addr)
            return

        # 检查存储空间
        new_size = self._node._total_store_size
        if key in self._node._store:
            old_value, _, _ = self._node._store[key]
            new_size -= len(old_value)
        new_size += len(value)

        if new_size > MAX_STORE_SIZE:
            logger.error(f"存储空间不足: {new_size} > {MAX_STORE_SIZE}")
            response = struct.pack("!B", 0x01)
            msg = self._node._encode_rpc(RPC_STORE, request_id, self._node.node_id, response)
            if self._node._protocol:
                self._node._protocol.send_datagram(msg, addr)
            return

        # 存储数据
        nonce = os.urandom(16)
        self._node._store[key] = (value, time.time() + ttl, nonce)
        self._node._total_store_size = new_size

        # 回复成功
        response = struct.pack("!B", 0x00)
        msg = self._node._encode_rpc(RPC_STORE, request_id, self._node.node_id, response)
        if self._node._protocol:
            self._node._protocol.send_datagram(msg, addr)


class SecureDHTNode:
    """
    安全 Kademlia DHT 节点（真实网络实现 - 性能优化版）

    功能:
    - 基于 UDP 的真实网络通信
    - 节点ID管理 (256位)
    - 路由表维护
    - PING/PONG 心跳（真实 UDP 通信，超时 5 秒）
    - STORE/FIND_VALUE/FIND_NODE RPC（真实网络调用）
    - 迭代查询 (iterative lookup) - 并行查询优化
    - 输入验证、重放保护、速率限制
    - 路由表缓存和查询结果缓存
    """

    def __init__(
        self,
        node_id: Optional[bytes] = None,
        address: str = "0.0.0.0",
        port: int = 9050,
        routing_table_size: int = 160,
    ):
        # 验证节点ID大小
        if node_id and len(node_id) != NODE_ID_SIZE:
            raise ValueError(f"Node ID must be exactly {NODE_ID_SIZE} bytes, got {len(node_id)}")

        self._node_id = node_id or os.urandom(32)
        self._address = address
        self._port = port
        self._routing_table = RoutingTable(self._node_id, k=routing_table_size)

        # 存储系统: key -> (value, timestamp, nonce)
        self._store: Dict[bytes, Tuple[bytes, float, bytes]] = {}
        self._total_store_size = 0

        # 重放保护: 记录已处理的请求
        self._processed_requests: Dict[str, float] = {}
        self._request_expiry = 300  # 5分钟

        # 速率限制器（使用统一的 RateLimiter）
        self._rate_limiter = RateLimiter(
            window=RATE_LIMIT_WINDOW,
            max_requests=MAX_OPS_PER_WINDOW
        )

        # 网络通信
        self._protocol: Optional[DHTProtocol] = None
        self._transport: Optional[asyncio.DatagramTransport] = None

        # RPC 响应等待: request_id -> Future
        self._pending_requests: Dict[bytes, asyncio.Future] = {}

        # 运行状态
        self._is_running = False
        self._refresh_task: Optional[asyncio.Task] = None
        self._republish_task: Optional[asyncio.Task] = None
        self._cleanup_task: Optional[asyncio.Task] = None

        # RPC 处理器
        self._rpc_handler = RPCHandler(self)

        # 缓存系统
        # 路由表缓存: node_id -> Contact
        self._contact_cache: LRUCache[bytes, Contact] = LRUCache(max_size=1000, ttl=CACHE_TTL)
        # find_value 结果缓存: key -> value
        self._value_cache: LRUCache[bytes, bytes] = LRUCache(max_size=1000, ttl=CACHE_TTL)

    @property
    def node_id(self) -> bytes:
        return self._node_id

    @property
    def address(self) -> str:
        return self._address

    @property
    def port(self) -> int:
        return self._port

    @property
    def routing_table(self) -> RoutingTable:
        return self._routing_table

    # ==================== 安全方法 ====================

    def _validate_key(self, key: bytes) -> bool:
        """验证键的有效性"""
        if not isinstance(key, bytes):
            return False
        if len(key) == 0 or len(key) > MAX_KEY_SIZE:
            return False
        return True

    def _validate_value(self, value: bytes) -> bool:
        """验证值的有效性"""
        if not isinstance(value, bytes):
            return False
        if len(value) > MAX_VALUE_SIZE:
            return False
        return True

    def _check_rate_limit(self, operation: str) -> bool:
        """检查操作速率限制"""
        return self._rate_limiter.check(operation)

    def _check_replay(self, request_id: bytes) -> bool:
        """检查是否为重放请求"""
        req_hash = hashlib.sha256(request_id).hexdigest()
        now = time.time()

        if req_hash in self._processed_requests:
            if now - self._processed_requests[req_hash] < self._request_expiry:
                return False  # 重放检测

        self._processed_requests[req_hash] = now
        return True

    def _cleanup_processed_requests(self) -> None:
        """清理过期的请求记录"""
        now = time.time()
        expired = [
            k for k, t in self._processed_requests.items()
            if now - t > self._request_expiry
        ]
        for k in expired:
            del self._processed_requests[k]

    # ==================== RPC 编解码 ====================

    def _encode_rpc(
        self,
        rpc_type: int,
        request_id: bytes,
        sender_id: bytes,
        payload: bytes = b"",
    ) -> bytes:
        """
        编码 DHT RPC 消息

        格式: [1字节: RPC类型] [32字节: 请求ID] [32字节: 发送者节点ID] [变长: payload]
        """
        if len(request_id) != 32:
            raise ValueError(f"请求ID必须为32字节, 当前: {len(request_id)}")
        if len(sender_id) != 32:
            raise ValueError(f"发送者节点ID必须为32字节, 当前: {len(sender_id)}")

        header = struct.pack("!B", rpc_type) + request_id + sender_id
        return header + payload

    def _decode_rpc(self, data: bytes) -> Optional[Tuple[int, bytes, bytes, bytes]]:
        """
        解码 DHT RPC 消息

        Returns:
            (rpc_type, request_id, sender_id, payload) 或 None（格式错误时）
        """
        if len(data) < RPC_HEADER_SIZE:
            logger.warning(f"RPC 消息过短: {len(data)} 字节 (最少需要 {RPC_HEADER_SIZE} 字节)")
            return None

        rpc_type = data[0]
        if rpc_type not in (RPC_PING, RPC_PONG, RPC_FIND_VALUE, RPC_FIND_NODE, RPC_STORE):
            logger.warning(f"未知的 RPC 类型: 0x{rpc_type:02x}")
            return None

        request_id = data[1:33]
        sender_id = data[33:65]
        payload = data[65:]

        return (rpc_type, request_id, sender_id, payload)

    def _encode_contacts(self, contacts: List[Contact]) -> bytes:
        """
        编码联系人列表为 payload

        格式: [2字节: 数量] [每条: 32字节node_id + 1字节addr_len + addr + 2字节port]
        """
        parts = [struct.pack("!H", len(contacts))]
        for c in contacts:
            addr_bytes = c.address.encode("utf-8")
            addr_len = len(addr_bytes)
            if addr_len > 255:
                addr_len = 255
                addr_bytes = addr_bytes[:255]
            parts.append(c.node_id)
            parts.append(struct.pack("!B", addr_len))
            parts.append(addr_bytes)
            parts.append(struct.pack("!H", c.port))
        return b"".join(parts)

    def _decode_contacts(self, payload: bytes) -> List[Contact]:
        """
        从 payload 解码联系人列表
        """
        if len(payload) < 2:
            return []

        count = struct.unpack("!H", payload[:2])[0]
        contacts = []
        offset = 2

        for _ in range(min(count, 100)):  # 最多解析100个联系人，防止恶意数据
            if offset + 32 + 1 + 2 > len(payload):
                break
            node_id = payload[offset:offset + 32]
            offset += 32
            addr_len = payload[offset]
            offset += 1
            if offset + addr_len + 2 > len(payload):
                break
            address = payload[offset:offset + addr_len].decode("utf-8", errors="replace")
            offset += addr_len
            port = struct.unpack("!H", payload[offset:offset + 2])[0]
            offset += 2
            contacts.append(Contact(node_id=node_id, address=address, port=port))

        return contacts

    # ==================== 距离计算 ====================

    def distance(self, other_id: bytes) -> int:
        """计算 XOR 距离"""
        if len(other_id) != len(self._node_id):
            raise ValueError("Node ID length mismatch")
        result = int.from_bytes(self._node_id, "big") ^ int.from_bytes(other_id, "big")
        return result

    def distance_bytes(self, other_id: bytes) -> bytes:
        """计算 XOR 距离 (字节)"""
        if len(other_id) != len(self._node_id):
            raise ValueError("Node ID length mismatch")
        return bytes(a ^ b for a, b in zip(self._node_id, other_id))

    # ==================== RPC 发送 ====================

    async def _send_rpc(
        self,
        rpc_type: int,
        target_addr: str,
        target_port: int,
        payload: bytes = b"",
        request_id: Optional[bytes] = None,
        timeout: float = RPC_TIMEOUT,
    ) -> Optional[bytes]:
        """
        发送 RPC 并等待响应

        Args:
            rpc_type: RPC 类型
            target_addr: 目标地址
            target_port: 目标端口
            payload: 负载数据
            request_id: 自定义请求ID（默认随机生成）
            timeout: 超时时间（秒）

        Returns:
            响应 payload 或 None（超时/错误时）
        """
        if not self._protocol:
            logger.error("DHT 协议未初始化，无法发送 RPC")
            return None

        if request_id is None:
            request_id = os.urandom(32)

        # 编码并发送
        message = self._encode_rpc(rpc_type, request_id, self._node_id, payload)
        self._protocol.send_datagram(message, (target_addr, target_port))

        # 注册等待响应的 Future
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        self._pending_requests[request_id] = future

        try:
            result = await asyncio.wait_for(future, timeout=timeout)
            return result
        except asyncio.TimeoutError:
            logger.debug(f"RPC 超时: 类型=0x{rpc_type:02x}, 目标={target_addr}:{target_port}")
            return None
        except Exception as e:
            logger.error(f"RPC 异常: {e}")
            return None
        finally:
            self._pending_requests.pop(request_id, None)

    # ==================== 入站消息处理 ====================

    async def _handle_incoming_datagram(self, data: bytes, addr: Tuple[str, int]) -> None:
        """
        处理入站 UDP 数据报

        解析 RPC 消息并分发到对应的处理方法。
        修复: 添加异常处理和边界检查
        """
        try:
            # 速率限制（基于来源IP）
            ip_key = f"recv:{addr[0]}"
            if not self._check_rate_limit(ip_key):
                logger.warning(f"来源 {addr[0]} 速率限制触发，丢弃数据报")
                return

            # 解码 RPC
            decoded = self._decode_rpc(data)
            if decoded is None:
                return

            rpc_type, request_id, sender_id, payload = decoded

            # 验证发送者节点ID
            if len(sender_id) != NODE_ID_SIZE:
                logger.warning(f"无效的发送者节点ID大小: {len(sender_id)}")
                return

            # 重放保护
            if not self._check_replay(request_id):
                logger.warning(f"检测到重放请求，来源: {addr}")
                return

            # 更新路由表（将发送者添加为联系人）- 使用锁保护
            if sender_id != self._node_id:
                try:
                    self._routing_table.add_contact(sender_id, addr[0], addr[1])
                    # 更新缓存
                    contact = Contact(node_id=sender_id, address=addr[0], port=addr[1])
                    self._contact_cache.put(sender_id, contact)
                except Exception as e:
                    logger.debug(f"更新路由表失败: {e}")

            # 分发处理
            try:
                if rpc_type == RPC_PING:
                    await self._rpc_handler.handle_ping(request_id, sender_id, payload, addr)
                elif rpc_type == RPC_PONG:
                    self._rpc_handler.handle_pong(request_id, payload)
                elif rpc_type == RPC_FIND_VALUE:
                    await self._rpc_handler.handle_find_value(request_id, sender_id, payload, addr)
                elif rpc_type == RPC_FIND_NODE:
                    await self._rpc_handler.handle_find_node(request_id, sender_id, payload, addr)
                elif rpc_type == RPC_STORE:
                    await self._rpc_handler.handle_store(request_id, sender_id, payload, addr)
            except Exception as e:
                logger.error(f"处理 RPC 0x{rpc_type:02x} 异常: {e}")
        except Exception as e:
            logger.error(f"处理入站数据报异常: {e}")

    # ==================== 公开 API ====================

    async def ping(self, target_id: bytes) -> bool:
        """
        PING 远程节点

        通过路由表查找目标节点的地址，发送 UDP PING 包，
        等待 PONG 响应（超时 5 秒）。

        Args:
            target_id: 目标节点ID

        Returns:
            True=成功, False=失败
        """
        if not self._validate_key(target_id):
            return False

        if not self._check_rate_limit("ping"):
            logger.warning("PING 速率限制触发")
            return False

        # 从路由表查找目标节点地址
        contacts = self._routing_table.find_closest(target_id, count=1)
        target_contact = None
        for c in contacts:
            if c.node_id == target_id:
                target_contact = c
                break

        if target_contact is None:
            logger.debug(f"PING: 目标节点 {target_id.hex()[:16]}... 不在路由表中")
            return False

        logger.debug(f"PING {target_id.hex()[:16]}... ({target_contact.address}:{target_contact.port})")

        # 发送 PING RPC
        result = await self._send_rpc(
            RPC_PING,
            target_contact.address,
            target_contact.port,
        )

        return result is not None

    async def store(
        self,
        key: bytes,
        value: bytes,
        ttl: float = 3600,
        request_id: Optional[bytes] = None,
    ) -> bool:
        """
        安全存储 key-value 对

        将数据存储到 k-closest 节点上。

        安全增强:
        - 输入验证
        - 大小限制
        - 重放保护
        - 速率限制
        """
        # 速率限制
        if not self._check_rate_limit("store"):
            logger.warning("Store 速率限制触发")
            return False

        # 输入验证
        if not self._validate_key(key):
            logger.error(f"无效的 key: size={len(key) if isinstance(key, bytes) else 'N/A'}")
            return False

        if not self._validate_value(value):
            logger.error(f"无效的 value: size={len(value) if isinstance(value, bytes) else 'N/A'}")
            return False

        # 验证TTL
        if not MIN_TTL <= ttl <= MAX_TTL:
            logger.error(f"无效的 TTL: {ttl}")
            return False

        # 重放保护
        if request_id and not self._check_replay(request_id):
            logger.warning("检测到 store 操作重放攻击")
            return False

        # 先存本地
        new_size = self._total_store_size
        if key in self._store:
            old_value, _, _ = self._store[key]
            new_size -= len(old_value)
        new_size += len(value)

        if new_size <= MAX_STORE_SIZE:
            nonce = os.urandom(16)
            self._store[key] = (value, time.time() + ttl, nonce)
            self._total_store_size = new_size

        # 向 k-closest 节点发送 STORE RPC
        closest = self._routing_table.find_closest(key, count=ITERATIVE_QUERY_K)
        ttl_int = int(ttl)
        store_payload = key + struct.pack("!I", ttl_int) + value

        success_count = 0
        for contact in closest:
            if contact.node_id == self._node_id:
                continue
            try:
                result = await self._send_rpc(
                    RPC_STORE,
                    contact.address,
                    contact.port,
                    payload=store_payload,
                )
                if result and len(result) >= 1 and result[0] == 0x00:
                    success_count += 1
            except DHTError as e:
                logger.debug(f"STORE RPC 到 {contact.address}:{contact.port} 失败: {e}")
            except Exception as e:
                logger.debug(f"STORE RPC 到 {contact.address}:{contact.port} 失败: {e}")

        logger.debug(f"STORE {key.hex()[:16]}... ({len(value)} 字节, TTL={ttl}s, 成功存储到 {success_count} 个远程节点)")
        return success_count > 0 or key in self._store

    async def _query_node_for_value(
        self,
        contact: Contact,
        key: bytes,
    ) -> Optional[bytes]:
        """
        向单个节点查询值（带超时控制）

        Args:
            contact: 目标节点
            key: 查询的键

        Returns:
            响应数据或 None
        """
        try:
            result = await self._send_rpc(
                RPC_FIND_VALUE,
                contact.address,
                contact.port,
                payload=key,
                timeout=FIND_VALUE_TIMEOUT,
            )
            return result
        except asyncio.TimeoutError:
            logger.debug(f"查询节点 {contact.address}:{contact.port} 超时")
            return None
        except Exception as e:
            logger.debug(f"查询节点 {contact.address}:{contact.port} 异常: {e}")
            return None

    async def find_value(
        self,
        key: bytes,
        request_id: Optional[bytes] = None,
    ) -> Optional[bytes]:
        """
        安全查找值（迭代查询 - 并行查询优化版）

        迭代查询 k-closest 节点，发送 FIND_VALUE RPC，收集响应。
        如果找到值则立即返回，否则查询更多节点。

        性能优化:
        - 使用 asyncio.gather 并发查询 3 个节点
        - 单个节点查询 3 秒超时
        - 优先返回第一个非 None 结果
        - 使用缓存减少重复查询

        安全增强:
        - 输入验证
        - 重放保护
        - 速率限制
        - 最大迭代次数限制防止无限循环
        """
        # 速率限制
        if not self._check_rate_limit("find_value"):
            return None

        # 输入验证
        if not self._validate_key(key):
            return None

        # 重放保护
        if request_id and not self._check_replay(request_id):
            logger.warning("检测到 find_value 操作重放攻击")
            return None

        # 检查缓存
        cached_value = self._value_cache.get(key)
        if cached_value is not None:
            logger.debug(f"FIND_VALUE: 缓存命中 key={key.hex()[:16]}...")
            return cached_value

        # 查本地
        if key in self._store:
            value, expires, _ = self._store[key]
            if time.time() < expires:
                # 缓存结果
                self._value_cache.put(key, value)
                return value
            else:
                # 清理过期数据
                self._total_store_size -= len(value)
                del self._store[key]

        # 迭代查询
        # shortlist: 待查询的节点集合
        # queried: 已查询的节点ID集合
        # seen_contacts: 所有已见到的联系人
        queried: Set[bytes] = set()
        seen_contacts: Dict[bytes, Contact] = {}
        max_iterations = 10  # 最大迭代次数防止无限循环
        iteration_count = 0

        # 初始化 shortlist 为本地路由表的 k-closest 节点
        initial_closest = self._routing_table.find_closest(key, count=ITERATIVE_QUERY_K)
        for c in initial_closest:
            if c.node_id != self._node_id:
                seen_contacts[c.node_id] = c

        queried.add(self._node_id)

        while iteration_count < max_iterations:
            iteration_count += 1
            
            # 从 seen_contacts 中选出距离 key 最近的 alpha 个未查询节点
            unqueried = [
                c for nid, c in seen_contacts.items()
                if nid not in queried
            ]
            unqueried.sort(key=lambda c: int.from_bytes(
                bytes(a ^ b for a, b in zip(key, c.node_id)), "big"
            ))

            if not unqueried:
                break

            # 并发查询 alpha 个节点（性能优化）
            batch = unqueried[:ITERATIVE_QUERY_ALPHA]

            # 创建并发任务
            tasks = []
            for contact in batch:
                queried.add(contact.node_id)
                tasks.append(self._query_node_for_value(contact, key))

            # 使用 asyncio.gather 并发执行，return_exceptions=True 防止一个任务失败影响其他任务
            try:
                results = await asyncio.gather(*tasks, return_exceptions=True)
            except Exception as e:
                logger.error(f"并发查询异常: {e}")
                results = []

            # 处理结果 - 优先返回第一个找到的值
            for result in results:
                if isinstance(result, Exception):
                    continue
                if result is None:
                    continue

                # 解析响应
                if len(result) < 1:
                    continue

                flag = result[0]
                if flag == 0x01:
                    # 找到值
                    found_value = result[1:]
                    # 缓存结果
                    self._value_cache.put(key, found_value)
                    return found_value
                elif flag == 0x00:
                    # 返回的是联系人列表
                    try:
                        contacts = self._decode_contacts(result[1:])
                        for c in contacts:
                            if c.node_id not in seen_contacts:
                                seen_contacts[c.node_id] = c
                    except Exception as e:
                        logger.debug(f"解析联系人列表失败: {e}")

            # 如果没有更多未查询的节点，结束
            remaining = [
                c for nid, c in seen_contacts.items()
                if nid not in queried
            ]
            if not remaining:
                break

        if iteration_count >= max_iterations:
            logger.warning(f"FIND_VALUE 达到最大迭代次数限制: key={key.hex()[:16]}...")
        
        return None

    async def find_node(
        self,
        target_id: bytes,
        request_id: Optional[bytes] = None,
    ) -> List[Dict[str, Any]]:
        """
        安全查找节点

        安全增强:
        - 输入验证
        - 重放保护
        """
        # 输入验证
        if not self._validate_key(target_id):
            return []

        # 重放保护
        if request_id and not self._check_replay(request_id):
            logger.warning("检测到 find_node 操作重放攻击")
            return []

        # 查本地路由表
        closest = self._routing_table.find_closest(target_id, count=20)
        return [
            {
                "node_id": n.node_id,
                "address": n.address,
                "port": n.port,
                "distance": self.distance(n.node_id),
            }
            for n in closest
        ]

    def add_contact(self, node_id: bytes, address: str, port: int) -> None:
        """安全添加联系人到路由表"""
        if not self._validate_key(node_id):
            logger.warning("add_contact: 无效的节点ID")
            return

        # 验证地址和端口
        if not isinstance(address, str) or len(address) > 255:
            return
        if not isinstance(port, int) or not (1 <= port <= 65535):
            return

        self._routing_table.add_contact(node_id, address, port)
        # 更新缓存
        contact = Contact(node_id=node_id, address=address, port=port)
        self._contact_cache.put(node_id, contact)

    def remove_contact(self, node_id: bytes) -> None:
        """从路由表移除联系人"""
        if self._validate_key(node_id):
            self._routing_table.remove_contact(node_id)
            # 从缓存中移除
            self._contact_cache.invalidate(node_id)

    def get_cached_contact(self, node_id: bytes) -> Optional[Contact]:
        """从缓存获取联系人信息"""
        return self._contact_cache.get(node_id)

    # ==================== 后台任务 ====================

    async def _refresh_loop(self) -> None:
        """定期刷新路由表"""
        while self._is_running:
            try:
                # 刷新所有 k-bucket
                for i in range(256):
                    bucket = self._routing_table.get_bucket(i)
                    if bucket and bucket.needs_refresh():
                        # 生成随机 ID 刷新 bucket
                        random_id = os.urandom(32)
                        random_id = bytearray(random_id)
                        random_id[i // 8] |= (1 << (7 - (i % 8)))
                        await self.find_node(bytes(random_id))
                        break
            except asyncio.CancelledError:
                break
            except DHTError as e:
                logger.error(f"DHT 刷新异常: {e}")
            except Exception as e:
                logger.error(f"DHT 刷新异常: {e}")
            await asyncio.sleep(60)

    async def _republish_loop(self) -> None:
        """定期重新发布存储的值"""
        while self._is_running:
            try:
                now = time.time()
                expired = []
                freed_space = 0

                for k, (v, exp, _) in self._store.items():
                    if exp <= now:
                        expired.append(k)
                        freed_space += len(v)

                for k in expired:
                    del self._store[k]

                self._total_store_size -= freed_space

                # 清理重放保护记录
                self._cleanup_processed_requests()

                # 清理超时的 pending requests
                now = time.time()
                timed_out = [
                    rid for rid, fut in self._pending_requests.items()
                    if fut.done()
                ]
                for rid in timed_out:
                    self._pending_requests.pop(rid, None)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"DHT 重新发布异常: {e}")
            await asyncio.sleep(300)

    # ==================== 启动/停止 ====================

    async def start(self) -> None:
        """
        启动 DHT 节点

        创建 UDP socket 并开始监听，启动后台维护任务。
        """
        self._is_running = True

        # 创建 UDP endpoint
        loop = asyncio.get_event_loop()
        transport, protocol = await loop.create_datagram_endpoint(
            lambda: DHTProtocol(self),
            local_addr=(self._address, self._port),
        )
        self._transport = transport
        self._protocol = protocol

        # 启动后台任务
        self._refresh_task = asyncio.create_task(self._refresh_loop())
        self._republish_task = asyncio.create_task(self._republish_loop())

        logger.info(f"DHT 节点 {self._node_id.hex()[:16]}... 已启动，监听 {self._address}:{self._port}")

    async def stop(self) -> None:
        """停止 DHT 节点"""
        self._is_running = False

        # 取消后台任务
        for task in [self._refresh_task, self._republish_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        # 关闭 UDP transport
        if self._transport:
            self._transport.close()
            self._transport = None
            self._protocol = None

        # 清理 pending requests
        for rid, fut in self._pending_requests.items():
            if not fut.done():
                fut.cancel()
        self._pending_requests.clear()

        # 清空缓存
        self._contact_cache.clear()
        self._value_cache.clear()

        logger.info("DHT 节点已停止")

    # ==================== 统计信息 ====================

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            "node_id": self._node_id.hex()[:16],
            "address": self._address,
            "port": self._port,
            "contacts": self._routing_table.size,
            "stored_keys": len(self._store),
            "stored_bytes": self._total_store_size,
            "buckets": self._routing_table.bucket_count,
            "pending_requests": len(self._pending_requests),
            "is_running": self._is_running,
            "contact_cache_size": self._contact_cache.size,
            "value_cache_size": self._value_cache.size,
        }

    # ==================== 后量子身份 ====================

    def generate_pqc_identity(self) -> Tuple[bytes, bytes]:
        """
        生成后量子身份密钥对

        使用 Dilithium 签名算法保护节点身份。
        """
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PrivateKey,
            )
            private_key = MLDSA65PrivateKey.generate()
            public_key = private_key.public_key()
            return private_key.private_bytes_raw(), public_key.public_bytes_raw()
        except ImportError:
            # 回退: Ed25519
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PrivateKey,
            )
            private_key = Ed25519PrivateKey.generate()
            public_key = private_key.public_key()
            return private_key.private_bytes_raw(), public_key.public_bytes_raw()

    def sign_node_id(self, signing_key: bytes) -> bytes:
        """使用后量子签名签署节点ID"""
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PrivateKey,
            )
            private_key = MLDSA65PrivateKey.from_private_bytes(signing_key)
            return private_key.sign(self._node_id)
        except ImportError:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PrivateKey,
            )
            private_key = Ed25519PrivateKey.from_private_bytes(signing_key)
            return private_key.sign(self._node_id)

    def verify_node_identity(self, verify_key: bytes, signature: bytes) -> bool:
        """验证节点身份签名"""
        try:
            from cryptography.hazmat.primitives.asymmetric.ml_dsa import (
                MLDSA65PublicKey,
            )
            public_key = MLDSA65PublicKey.from_public_bytes(verify_key)
            public_key.verify(signature, self._node_id)
            return True
        except Exception:
            pass

        # 回退: Ed25519
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PublicKey,
            )
            public_key = Ed25519PublicKey.from_public_bytes(verify_key)
            public_key.verify(signature, self._node_id)
            return True
        except Exception:
            return False


# 向后兼容
DHTNode = SecureDHTNode
