"""
AI Traffic - AI对抗流量分析模块 (Adversarial Traffic Analysis Module)

本模块提供AI驱动的对抗流量分析与混淆功能，包括：
- 流量分类器：基于 GMM/KNN 的流量类型识别
- 对抗性流量生成：基于 cGAN/FGSM 的对抗样本生成

典型用法:
    from src.ai_traffic.adversarial_traffic import TrafficClassifier, AdversarialTrafficGenerator

    # 流量分类
    classifier = TrafficClassifier(n_components=4)
    classifier.train(features, labels)
    result = classifier.predict(sample)

    # 对抗流量生成
    generator = AdversarialTrafficGenerator(feature_dim=4)
    generator.train(real_features)
    adversarial = generator.generate(real_features)
"""

# 版本信息
__version__ = "1.0.5"
__author__ = "IP4Move Aegis Security Team"
__protocol_version__ = "AIS-2025-R1"

# 从 adversarial_traffic 模块导出所有公开类
from src.ai_traffic.adversarial_traffic import (
    TrafficClassifier,
    AdversarialTrafficGenerator,
)

__all__ = [
    "TrafficClassifier",
    "AdversarialTrafficGenerator",
]
