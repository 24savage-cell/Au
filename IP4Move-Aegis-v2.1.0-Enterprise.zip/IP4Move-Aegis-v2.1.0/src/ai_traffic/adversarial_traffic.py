"""
AI 对抗流量模块 (精简重写版)

功能:
1. TrafficClassifier - 基于高斯混合模型 (GMM) 的流量分类
2. AdversarialTrafficGenerator - 基于条件 GAN (cGAN) 的对抗性流量生成

依赖:
- scikit-learn (可选): 用于 GMM 分类
- PyTorch (可选): 用于 cGAN 对抗流量生成
- 无外部依赖时使用纯 Python 回退实现
"""

import os
import json
import math
import logging
import struct
from typing import Optional, List, Dict, Tuple, Any

logger = logging.getLogger(__name__)

# 检测可选依赖
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

try:
    from sklearn.mixture import GaussianMixture
    from sklearn.preprocessing import StandardScaler
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False

try:
    import torch
    import torch.nn as nn
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


# ============================================================
# TrafficClassifier - 流量分类器
# ============================================================

class TrafficClassifier:
    """
    流量分类器

    特征维度:
    - 0: 包大小 (bytes)
    - 1: 包间隔 (ms)
    - 2: 突发长度 (包数)
    - 3: 字节率 (bytes/s)

    支持两种模式:
    - sklearn 可用: 使用高斯混合模型 (GMM)
    - sklearn 不可用: 使用纯 Python KNN (K=3)
    """

    def __init__(
        self,
        n_components: int = 4,
        n_neighbors: int = 3,
        random_state: int = 42,
    ):
        """
        初始化分类器

        Args:
            n_components: GMM 组件数 (sklearn 模式)
            n_neighbors: KNN 近邻数 (回退模式)
            random_state: 随机种子
        """
        self._n_components = n_components
        self._n_neighbors = n_neighbors
        self._random_state = random_state
        self._is_trained = False
        self._labels_map: Dict[int, str] = {}

        if HAS_SKLEARN:
            self._model = GaussianMixture(
                n_components=n_components,
                random_state=random_state,
            )
            self._scaler = StandardScaler()
            logger.info("TrafficClassifier: 使用 sklearn GMM 模式")
        else:
            self._model = None
            self._scaler = None
            # KNN 回退: 存储训练数据
            self._train_features: List[List[float]] = []
            self._train_labels: List[int] = []
            logger.info("TrafficClassifier: 使用纯 Python KNN 回退模式")

    def train(self, features: List[List[float]], labels: List[int]) -> None:
        """
        训练分类器

        Args:
            features: 特征列表, 每个元素为 [包大小, 包间隔, 突发长度, 字节率]
            labels: 标签列表, 整数类型
        """
        if len(features) != len(labels):
            raise ValueError(f"特征数量 ({len(features)}) 与标签数量 ({len(labels)}) 不匹配")
        if len(features) == 0:
            raise ValueError("训练数据不能为空")

        # 构建标签映射
        unique_labels = sorted(set(labels))
        self._labels_map = {i: str(lbl) for i, lbl in enumerate(unique_labels)}

        if HAS_SKLEARN and self._model is not None:
            # sklearn GMM 模式
            import numpy as _np
            X = _np.array(features, dtype=_np.float64)
            X_scaled = self._scaler.fit_transform(X)
            self._model.fit(X_scaled)
            self._is_trained = True
            logger.info(f"GMM 分类器训练完成: {len(features)} 样本, {self._n_components} 组件")
        else:
            # 纯 Python KNN 回退
            self._train_features = [list(f) for f in features]
            self._train_labels = list(labels)
            self._is_trained = True
            logger.info(f"KNN 回退分类器训练完成: {len(features)} 样本, K={self._n_neighbors}")

    def predict(self, features: List[List[float]]) -> List[int]:
        """
        预测流量类型

        Args:
            features: 特征列表

        Returns:
            预测标签列表
        """
        if not self._is_trained:
            raise RuntimeError("分类器尚未训练")

        if HAS_SKLEARN and self._model is not None:
            import numpy as _np
            X = _np.array(features, dtype=_np.float64)
            X_scaled = self._scaler.transform(X)
            return self._model.predict(X_scaled).tolist()
        else:
            return [self._knn_predict(f) for f in features]

    def predict_proba(self, features: List[List[float]]) -> List[List[float]]:
        """
        返回预测概率分布

        Args:
            features: 特征列表

        Returns:
            每个样本的概率分布列表
        """
        if not self._is_trained:
            raise RuntimeError("分类器尚未训练")

        if HAS_SKLEARN and self._model is not None:
            import numpy as _np
            X = _np.array(features, dtype=_np.float64)
            X_scaled = self._scaler.transform(X)
            return self._model.predict_proba(X_scaled).tolist()
        else:
            # KNN 回退: 基于近邻投票的概率
            results = []
            for f in features:
                probs = self._knn_predict_proba(f)
                results.append(probs)
            return results

    def _knn_predict(self, feature: List[float]) -> int:
        """纯 Python KNN 预测"""
        distances = []
        for i, train_f in enumerate(self._train_features):
            dist = self._euclidean_distance(feature, train_f)
            distances.append((dist, self._train_labels[i]))
        distances.sort(key=lambda x: x[0])
        # K 近邻投票
        top_k = distances[:self._n_neighbors]
        votes: Dict[int, int] = {}
        for _, label in top_k:
            votes[label] = votes.get(label, 0) + 1
        return max(votes, key=votes.get)

    def _knn_predict_proba(self, feature: List[float]) -> List[float]:
        """纯 Python KNN 概率预测"""
        distances = []
        for i, train_f in enumerate(self._train_features):
            dist = self._euclidean_distance(feature, train_f)
            distances.append((dist, self._train_labels[i]))
        distances.sort(key=lambda x: x[0])
        top_k = distances[:self._n_neighbors]
        # 计算各类别的投票比例
        votes: Dict[int, int] = {}
        for _, label in top_k:
            votes[label] = votes.get(label, 0) + 1
        total = sum(votes.values())
        unique_labels = sorted(set(self._train_labels))
        return [votes.get(lbl, 0) / total for lbl in unique_labels]

    @staticmethod
    def _euclidean_distance(a: List[float], b: List[float]) -> float:
        """计算欧氏距离"""
        return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))

    def save_model(self, path: str) -> None:
        """
        保存模型到文件

        Args:
            path: 文件路径
        """
        data = {
            "type": "sklearn_gmm" if HAS_SKLEARN and self._model else "knn_fallback",
            "n_components": self._n_components,
            "n_neighbors": self._n_neighbors,
            "is_trained": self._is_trained,
            "labels_map": self._labels_map,
        }

        if HAS_SKLEARN and self._model is not None and self._is_trained:
            import pickle
            data["model_params"] = {
                "weights_": self._model.weights_.tolist(),
                "means_": self._model.means_.tolist(),
                "covariances_": self._model.covariances_.tolist(),
                "precisions_cholesky_": self._model.precisions_cholesky_.tolist(),
                "scale_mean": self._scaler.mean_.tolist(),
                "scale_var": self._scaler.var_.tolist(),
            }
        else:
            data["train_features"] = self._train_features
            data["train_labels"] = self._train_labels

        with open(path, "w") as f:
            json.dump(data, f)
        logger.info(f"分类器模型已保存: {path}")

    def load_model(self, path: str) -> None:
        """
        从文件加载模型

        Args:
            path: 文件路径
        """
        with open(path, "r") as f:
            data = json.load(f)

        self._n_components = data["n_components"]
        self._n_neighbors = data["n_neighbors"]
        self._is_trained = data["is_trained"]
        self._labels_map = data.get("labels_map", {})

        if data["type"] == "sklearn_gmm" and HAS_SKLEARN and "model_params" in data:
            import numpy as _np
            params = data["model_params"]
            self._model.weights_ = _np.array(params["weights_"])
            self._model.means_ = _np.array(params["means_"])
            self._model.covariances_ = _np.array(params["covariances_"])
            self._model.precisions_cholesky_ = _np.array(params["precisions_cholesky_"])
            self._model.n_components = len(params["weights_"])
            self._model.converged_ = True
            self._scaler.mean_ = _np.array(params["scale_mean"])
            self._scaler.var_ = _np.array(params["scale_var"])
            self._scaler.scale_ = _np.sqrt(self._scaler.var_)
            self._scaler.n_features_in_ = len(params["scale_mean"])
        else:
            self._train_features = data.get("train_features", [])
            self._train_labels = data.get("train_labels", [])

        logger.info(f"分类器模型已加载: {path}")


# ============================================================
# AdversarialTrafficGenerator - 对抗性流量生成器
# ============================================================

class Generator(nn.Module):
    """PyTorch 生成器网络"""

    def __init__(self, input_dim: int = 8, output_dim: int = 4, hidden_dim: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
            nn.Tanh(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class Discriminator(nn.Module):
    """PyTorch 判别器网络"""

    def __init__(self, input_dim: int = 4, hidden_dim: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class AdversarialTrafficGenerator:
    """
    对抗性流量生成器

    支持两种模式:
    - PyTorch 可用: 使用条件 GAN (cGAN)
    - PyTorch 不可用: 使用纯 Python FGSM 对抗扰动
    """

    def __init__(
        self,
        feature_dim: int = 4,
        noise_dim: int = 8,
        hidden_dim: int = 32,
        learning_rate: float = 0.001,
        random_state: int = 42,
    ):
        """
        初始化对抗性流量生成器

        Args:
            feature_dim: 特征维度
            noise_dim: 噪声维度
            hidden_dim: 隐藏层维度
            learning_rate: 学习率
            random_state: 随机种子
        """
        self._feature_dim = feature_dim
        self._noise_dim = noise_dim
        self._hidden_dim = hidden_dim
        self._learning_rate = learning_rate
        self._random_state = random_state
        self._is_trained = False

        if HAS_TORCH:
            self._generator = Generator(noise_dim, feature_dim, hidden_dim)
            self._discriminator = Discriminator(feature_dim, hidden_dim)
            self._optimizer_g = torch.optim.Adam(
                self._generator.parameters(), lr=learning_rate
            )
            self._optimizer_d = torch.optim.Adam(
                self._discriminator.parameters(), lr=learning_rate
            )
            self._criterion = nn.BCELoss()
            logger.info("AdversarialTrafficGenerator: 使用 PyTorch cGAN 模式")
        else:
            self._generator = None
            self._discriminator = None
            logger.info("AdversarialTrafficGenerator: 使用纯 Python FGSM 回退模式")

    def train(self, real_features: List[List[float]], epochs: int = 100) -> None:
        """
        训练对抗模型

        Args:
            real_features: 真实流量特征列表
            epochs: 训练轮数
        """
        if len(real_features) == 0:
            raise ValueError("训练数据不能为空")

        if HAS_TORCH and self._generator is not None:
            self._train_cgan(real_features, epochs)
        else:
            # 纯 Python 回退: 计算特征统计量用于 FGSM
            self._feature_stats = self._compute_stats(real_features)
            self._is_trained = True
            logger.info(f"FGSM 回退模型训练完成: {len(real_features)} 样本")

    def _train_cgan(self, real_features: List[List[float]], epochs: int) -> None:
        """训练条件 GAN"""
        import numpy as _np
        X = torch.tensor(real_features, dtype=torch.float32)
        batch_size = min(32, len(real_features))
        n_batches = max(1, len(real_features) // batch_size)

        for epoch in range(epochs):
            for _ in range(n_batches):
                idx = torch.randint(0, len(X), (batch_size,))
                real_batch = X[idx]

                # 训练判别器
                self._discriminator.zero_grad()
                label_real = torch.ones(batch_size, 1)
                label_fake = torch.zeros(batch_size, 1)

                output_real = self._discriminator(real_batch)
                loss_d_real = self._criterion(output_real, label_real)

                noise = torch.randn(batch_size, self._noise_dim)
                fake = self._generator(noise).detach()
                output_fake = self._discriminator(fake)
                loss_d_fake = self._criterion(output_fake, label_fake)

                loss_d = loss_d_real + loss_d_fake
                loss_d.backward()
                self._optimizer_d.step()

                # 训练生成器
                self._generator.zero_grad()
                noise = torch.randn(batch_size, self._noise_dim)
                fake = self._generator(noise)
                output = self._discriminator(fake)
                loss_g = self._criterion(output, label_real)
                loss_g.backward()
                self._optimizer_g.step()

            if (epoch + 1) % 20 == 0:
                logger.debug(f"cGAN 训练进度: {epoch + 1}/{epochs}")

        self._is_trained = True
        logger.info(f"cGAN 训练完成: {epochs} 轮, {len(real_features)} 样本")

    def generate(self, real_features: List[List[float]]) -> List[List[float]]:
        """
        生成对抗性流量

        Args:
            real_features: 真实流量特征 (作为条件输入)

        Returns:
            对抗性流量特征列表
        """
        if not self._is_trained:
            raise RuntimeError("模型尚未训练")

        if HAS_TORCH and self._generator is not None:
            self._generator.eval()
            n = len(real_features)
            noise = torch.randn(n, self._noise_dim)
            with torch.no_grad():
                adversarial = self._generator(noise).tolist()
            self._generator.train()
            return adversarial
        else:
            # 纯 Python 回退: 在真实特征基础上添加扰动
            return [self._fgsm_perturb(f) for f in real_features]

    def perturb(self, features: List[List[float]], epsilon: float = 0.1) -> List[List[float]]:
        """
        FGSM 对抗扰动

        Args:
            features: 原始特征列表
            epsilon: 扰动幅度

        Returns:
            扰动后的特征列表
        """
        if HAS_TORCH and self._is_trained:
            self._generator.eval()
            self._discriminator.eval()
            X = torch.tensor(features, dtype=torch.float32, requires_grad=True)
            output = self._discriminator(X)
            # 最大化判别器损失 (使判别器难以区分)
            target = torch.zeros_like(output)
            loss = self._criterion(output, target)
            loss.backward()
            # FGSM: 沿梯度方向添加扰动
            perturbed = X + epsilon * X.grad.sign()
            result = perturbed.detach().tolist()
            self._generator.train()
            self._discriminator.train()
            return result
        else:
            return [self._fgsm_perturb(f, epsilon) for f in features]

    def _fgsm_perturb(self, feature: List[float], epsilon: float = 0.1) -> List[float]:
        """
        纯 Python FGSM 扰动 (梯度近似)

        使用数值梯度近似: 对每个特征维度做微小扰动，
        观察特征范数的变化方向，沿该方向添加扰动。
        """
        if not hasattr(self, '_feature_stats'):
            # 未训练时使用简单随机扰动
            return [x + epsilon * (1 if i % 2 == 0 else -1) for i, x in enumerate(feature)]

        stats = self._feature_stats
        perturbed = []
        for i, x in enumerate(feature):
            # 使用均值和标准差归一化后添加扰动
            mean = stats["means"][i]
            std = stats["stds"][i] if stats["stds"][i] > 0 else 1.0
            normalized = (x - mean) / std
            # 沿远离均值的方向扰动 (对抗性)
            direction = 1.0 if normalized >= 0 else -1.0
            perturbed_val = x + epsilon * std * direction
            perturbed.append(perturbed_val)
        return perturbed

    @staticmethod
    def _compute_stats(features: List[List[float]]) -> Dict[str, List[float]]:
        """计算特征统计量"""
        n = len(features)
        dim = len(features[0]) if features else 0
        means = [0.0] * dim
        for f in features:
            for i in range(dim):
                means[i] += f[i]
        means = [m / n for m in means]

        stds = [0.0] * dim
        for f in features:
            for i in range(dim):
                stds[i] += (f[i] - means[i]) ** 2
        stds = [math.sqrt(s / n) for s in stds]

        return {"means": means, "stds": stds}

    def save_model(self, path: str) -> None:
        """
        保存模型到文件

        Args:
            path: 文件路径
        """
        data = {
            "type": "cgan_torch" if HAS_TORCH and self._generator else "fgsm_fallback",
            "feature_dim": self._feature_dim,
            "noise_dim": self._noise_dim,
            "hidden_dim": self._hidden_dim,
            "learning_rate": self._learning_rate,
            "is_trained": self._is_trained,
        }

        if HAS_TORCH and self._generator is not None and self._is_trained:
            # 保存 PyTorch 模型状态
            model_path = path + ".pt"
            torch.save({
                "generator": self._generator.state_dict(),
                "discriminator": self._discriminator.state_dict(),
            }, model_path)
            data["model_file"] = model_path
        elif hasattr(self, '_feature_stats'):
            data["feature_stats"] = self._feature_stats

        with open(path, "w") as f:
            json.dump(data, f)
        logger.info(f"对抗模型已保存: {path}")

    def load_model(self, path: str) -> None:
        """
        从文件加载模型

        Args:
            path: 文件路径
        """
        with open(path, "r") as f:
            data = json.load(f)

        self._feature_dim = data["feature_dim"]
        self._noise_dim = data["noise_dim"]
        self._hidden_dim = data["hidden_dim"]
        self._learning_rate = data["learning_rate"]
        self._is_trained = data["is_trained"]

        if data["type"] == "cgan_torch" and HAS_TORCH and "model_file" in data:
            model_path = data["model_file"]
            if os.path.exists(model_path):
                checkpoint = torch.load(model_path, map_location="cpu", weights_only=True)
                self._generator.load_state_dict(checkpoint["generator"])
                self._discriminator.load_state_dict(checkpoint["discriminator"])
        elif "feature_stats" in data:
            self._feature_stats = data["feature_stats"]

        logger.info(f"对抗模型已加载: {path}")
