"""
IP.4/Move-Aegis Prometheus 指标

提供企业级监控指标:
- 节点运行状态
- 路由性能
- 加密操作延迟
- 网络吞吐量
- 安全事件计数

安全说明:
- node_id 使用哈希处理，不暴露原始值
- 敏感信息不作为 label
"""

import hashlib
import time
from functools import wraps
from typing import Any, Callable, Optional

from prometheus_client import (
    REGISTRY,
    Counter,
    Gauge,
    Histogram,
    Info,
    generate_latest,
)


def _hash_node_id(node_id: str) -> str:
    """
    安全处理 node_id: 使用 SHA-256 哈希
    
    安全依据:
    - 原始 node_id 可能包含敏感信息
    - 哈希后的值仍可用于区分不同节点
    - 不可逆，无法从哈希值反推原始 node_id
    """
    if not node_id:
        return "unknown"
    return hashlib.sha256(node_id.encode()).hexdigest()[:16]


# ============ 节点指标 ============
# 安全修复: node_id 使用哈希处理
NODE_UPTIME = Gauge(
    "ip4move_node_uptime_seconds",
    "Node uptime in seconds",
    ["node_hash", "role"],  # 使用 node_hash 替代 node_id
)

NODE_ACTIVE_CONNECTIONS = Gauge(
    "ip4move_node_active_connections",
    "Number of active connections",
    ["node_hash"],  # 使用 node_hash 替代 node_id
)

NODE_MEMORY_USAGE = Gauge(
    "ip4move_node_memory_bytes",
    "Node memory usage in bytes",
    ["node_hash"],
)

NODE_CPU_USAGE = Gauge(
    "ip4move_node_cpu_percent",
    "Node CPU usage percentage",
    ["node_hash"],
)

# ============ 路由指标 ============
ROUTING_PATHS_BUILT = Counter(
    "ip4move_routing_paths_built_total",
    "Total number of paths built",
    ["status"],
)

ROUTING_PATH_LATENCY = Histogram(
    "ip4move_routing_path_latency_seconds",
    "Path construction latency in seconds",
    ["hop_count"],
    buckets=[0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
)

ROUTING_ACTIVE_PATHS = Gauge(
    "ip4move_routing_active_paths",
    "Number of currently active paths",
)

ROUTING_DECOY_PATHS = Counter(
    "ip4move_routing_decoy_paths_total",
    "Total number of decoy paths created",
)

# ============ 加密指标 ============
CRYPTO_OPERATIONS = Counter(
    "ip4move_crypto_operations_total",
    "Total number of cryptographic operations",
    ["algorithm", "operation"],
)

CRYPTO_OPERATION_LATENCY = Histogram(
    "ip4move_crypto_operation_latency_seconds",
    "Cryptographic operation latency in seconds",
    ["algorithm"],
    buckets=[0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25],
)

CRYPTO_PQC_OPERATIONS = Counter(
    "ip4move_crypto_pqc_operations_total",
    "Total number of post-quantum cryptographic operations",
    ["algorithm", "operation"],
)

# ============ 网络指标 ============
NETWORK_BYTES_RECEIVED = Counter(
    "ip4move_network_bytes_received_total",
    "Total bytes received",
    ["protocol"],
)

NETWORK_BYTES_SENT = Counter(
    "ip4move_network_bytes_sent_total",
    "Total bytes sent",
    ["protocol"],
)

NETWORK_PACKETS_DROPPED = Counter(
    "ip4move_network_packets_dropped_total",
    "Total packets dropped",
    ["reason"],
)

NETWORK_CONNECTION_ERRORS = Counter(
    "ip4move_network_connection_errors_total",
    "Total connection errors",
    ["error_type"],
)

NETWORK_THROUGHPUT = Gauge(
    "ip4move_network_throughput_bytes_per_sec",
    "Current network throughput in bytes/sec",
    ["direction"],
)

# ============ Mixnet 指标 ============
MIXNET_MESSAGES_PROCESSED = Counter(
    "ip4move_mixnet_messages_processed_total",
    "Total messages processed by mix nodes",
    ["node_role"],
)

MIXNET_BATCH_SIZE = Histogram(
    "ip4move_mixnet_batch_size",
    "Batch forwarding size distribution",
    buckets=[1, 5, 10, 20, 50, 100],
)

MIXNET_DELAY_SECONDS = Histogram(
    "ip4move_mixnet_delay_seconds",
    "Mix node delay distribution in seconds",
    ["node_role"],
    buckets=[0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0],
)

# ============ 安全指标 ============
SECURITY_EVENTS = Counter(
    "ip4move_security_events_total",
    "Total security events",
    ["event_type", "severity"],
)

SECURITY_ATTACKS_DETECTED = Counter(
    "ip4move_security_attacks_detected_total",
    "Total attacks detected",
    ["attack_type"],
)

SECURITY_NOISE_INJECTED = Counter(
    "ip4move_security_noise_injected_total",
    "Total noise packets injected",
    ["noise_type"],
)

# ============ 系统信息 ============
SYSTEM_INFO = Info(
    "ip4move_system",
    "IP.4/Move-Aegis system information",
)


def init_system_info(version: str = "1.0.0") -> None:
    """初始化系统信息指标"""
    import platform
    SYSTEM_INFO.info({
        "version": version,
        "python_version": platform.python_version(),
        "platform": platform.system(),
    })


def timed_histogram(
    histogram: Histogram,
    algorithm: str = "",
) -> Callable:
    """
    计时装饰器: 自动记录函数执行时间到 Prometheus Histogram

    Usage:
        @timed_histogram(CRYPTO_OPERATION_LATENCY, algorithm="aes-256-gcm")
        def encrypt(self, data: bytes) -> bytes:
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                return result
            finally:
                elapsed = time.perf_counter() - start
                histogram.labels(algorithm=algorithm).observe(elapsed)
        return wrapper
    return decorator


def get_metrics() -> bytes:
    """获取 Prometheus 格式的指标数据"""
    return generate_latest(REGISTRY)
