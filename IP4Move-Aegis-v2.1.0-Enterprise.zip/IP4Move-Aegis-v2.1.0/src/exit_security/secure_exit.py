"""
出口节点安全与隐私保护模块 - 核心实现
(Exit Node Security & Privacy Protection Module - Core Implementation)

本模块实现了出口节点的四项核心安全与隐私保护功能：
1. DistributedExitAggregator - 分布式出口聚合，通过秘密共享分散流量
2. ExitEncryptionLayer - 出口节点加密层，提供双重TLS封装和证书固定
3. ExitNodeRotator - 出口节点动态轮换器，实现无中断的出口切换
4. DecoyExitManager - 诱饵出口节点管理器，用于攻击者诱捕和检测

This module implements four core exit node security and privacy features:
1. DistributedExitAggregator - Distributed exit aggregation via secret sharing
2. ExitEncryptionLayer - Exit encryption layer with double TLS and cert pinning
3. ExitNodeRotator - Dynamic exit node rotator for seamless switching
4. DecoyExitManager - Decoy exit node manager for attacker detection
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
import random
import secrets
import socket
import ssl
import struct
import threading
import time
import urllib.parse
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

# 配置日志记录器
logger = logging.getLogger(__name__)


# ============================================================
# 辅助数据结构和枚举类型
# ============================================================

class ExitNodeStatus(Enum):
    """出口节点状态枚举 (Exit node status enumeration)"""
    ACTIVE = "active"             # 活跃状态，正在处理流量
    STANDBY = "standby"           # 待机状态，可用但未使用
    ROTATING_OUT = "rotating_out" # 正在轮换出
    ROTATING_IN = "rotating_in"   # 正在轮换入
    DECOY = "decoy"               # 诱饵节点
    DISABLED = "disabled"         # 已禁用
    COMPROMISED = "compromised"   # 已被攻破


class GeoRegion(Enum):
    """地理区域枚举 (Geographic region enumeration)"""
    NORTH_AMERICA = "north_america"
    EUROPE = "europe"
    ASIA_PACIFIC = "asia_pacific"
    SOUTH_AMERICA = "south_america"
    AFRICA = "africa"
    MIDDLE_EAST = "middle_east"


@dataclass
class ExitNodeInfo:
    """出口节点信息数据类 (Exit node information data class)

    存储出口节点的完整信息，包括网络地址、地理位置、性能指标等。

    Attributes:
        node_id: 节点唯一标识符
        ip_address: 节点IP地址
        port: 节点监听端口
        region: 节点所在地理区域
        status: 节点当前状态
        bandwidth_mbps: 可用带宽（Mbps）
        latency_ms: 平均延迟（毫秒）
        security_score: 安全评分 (0.0 ~ 1.0)
        performance_score: 性能评分 (0.0 ~ 1.0)
        current_connections: 当前连接数
        max_connections: 最大连接数
        tls_version: 支持的TLS版本
        certificate_fingerprint: TLS证书指纹
        first_seen: 首次发现时间
        last_active: 最后活跃时间
        metadata: 附加元数据
    """
    node_id: str
    ip_address: str
    port: int
    region: GeoRegion = GeoRegion.NORTH_AMERICA
    status: ExitNodeStatus = ExitNodeStatus.STANDBY
    bandwidth_mbps: float = 100.0
    latency_ms: float = 100.0
    security_score: float = 0.8
    performance_score: float = 0.7
    current_connections: int = 0
    max_connections: int = 1000
    tls_version: str = "TLSv1.3"
    certificate_fingerprint: str = ""
    first_seen: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __hash__(self) -> int:
        """基于node_id计算哈希值"""
        return hash(self.node_id)

    def __eq__(self, other: object) -> bool:
        """基于node_id判断相等"""
        if not isinstance(other, ExitNodeInfo):
            return NotImplemented
        return self.node_id == other.node_id

    @property
    def available_capacity(self) -> int:
        """获取剩余可用连接数 (Get remaining available connections)"""
        return max(0, self.max_connections - self.current_connections)

    @property
    def load_factor(self) -> float:
        """获取负载因子 (Get load factor, 0.0 ~ 1.0+)"""
        if self.max_connections == 0:
            return 1.0
        return self.current_connections / self.max_connections


@dataclass
class TrafficSegment:
    """流量分段数据类 (Traffic segment data class)

    用于分布式出口聚合中的数据分段。

    Attributes:
        segment_id: 分段唯一标识符
        sequence: 分段序号
        total_segments: 总分段数
        data: 分段数据
        target_node_id: 目标出口节点ID
        timestamp: 创建时间戳
        checksum: 数据校验和
    """
    segment_id: str
    sequence: int
    total_segments: int
    data: bytes
    target_node_id: str
    timestamp: float = field(default_factory=time.time)
    checksum: str = ""


@dataclass
class RotationRecord:
    """轮换记录数据类 (Rotation record data class)

    记录一次出口节点轮换的详细信息。

    Attributes:
        rotation_id: 轮换唯一标识符
        old_node_id: 被替换的出口节点ID
        new_node_id: 新的出口节点ID
        start_time: 轮换开始时间
        end_time: 轮换结束时间
        connections_migrated: 迁移的连接数
        success: 轮换是否成功
        reason: 轮换原因
    """
    rotation_id: str
    old_node_id: str
    new_node_id: str
    start_time: float = field(default_factory=time.time)
    end_time: float = 0.0
    connections_migrated: int = 0
    success: bool = False
    reason: str = ""


@dataclass
class DecoyTrafficProfile:
    """诱饵流量配置文件 (Decoy traffic profile)

    定义诱饵节点生成的虚假流量模式。

    Attributes:
        profile_id: 配置文件ID
        requests_per_minute: 每分钟请求数
        avg_request_size_bytes: 平均请求大小（字节）
        avg_response_size_bytes: 平均响应大小（字节）
        target_domains: 模拟访问的域名列表
        user_agent_rotation: User-Agent轮换列表
        time_pattern: 时间模式（如工作时间、随机等）
        jitter_percent: 时间抖动百分比（增加随机性）
    """
    profile_id: str
    requests_per_minute: int = 30
    avg_request_size_bytes: int = 512
    avg_response_size_bytes: int = 4096
    target_domains: List[str] = field(default_factory=lambda: [
        "www.example.com", "api.example.org", "cdn.example.net",
    ])
    user_agent_rotation: List[str] = field(default_factory=lambda: [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "Mozilla/5.0 (X11; Linux x86_64)",
    ])
    time_pattern: str = "uniform"  # uniform, work_hours, burst
    jitter_percent: float = 20.0


# ============================================================
# DistributedExitAggregator - 分布式出口聚合器
# ============================================================

class DistributedExitAggregator:
    """分布式出口聚合器 (Distributed Exit Aggregator)

    将用户流量分散到多个出口节点，通过秘密共享方案分割数据，
    使得单个出口节点无法获取完整的用户数据，从而提供更强的隐私保护。

    Features:
        - 流量分散到多个出口节点
        - 基于秘密共享的数据分割（Shamir秘密共享）
        - 出口节点选择策略（地理分布、延迟、信誉）
        - 部分数据泄露防护（单个节点泄露不影响完整数据）

    Example:
        >>> aggregator = DistributedExitAggregator(min_splits=3, threshold=2)
        >>> aggregator.add_exit_node(ExitNodeInfo("exit_1", "1.2.3.4", 443))
        >>> segments = aggregator.split_data(b"secret message")
        >>> result = aggregator.reassemble_data(segments)
    """

    # 默认最小分割数
    DEFAULT_MIN_SPLITS: int = 3
    # 默认重建阈值（需要多少份才能重建）
    DEFAULT_THRESHOLD: int = 2
    # 最大分割数
    MAX_SPLITS: int = 10
    # 秘密共享使用的质数（用于模运算）
    SHARING_PRIME: int = 2**127 - 1  # Mersenne prime
    # 最大单次处理数据大小（10MB）
    MAX_DATA_SIZE: int = 10 * 1024 * 1024

    def __init__(
        self,
        min_splits: int = DEFAULT_MIN_SPLITS,
        threshold: int = DEFAULT_THRESHOLD,
    ) -> None:
        """初始化分布式出口聚合器

        Args:
            min_splits: 数据最小分割份数
            threshold: 重建数据所需的最小份数（<= min_splits）

        Raises:
            ValueError: 如果参数不合法
        """
        if min_splits < 2:
            raise ValueError(
                f"最小分割数至少为2, 当前值: {min_splits}"
            )
        if threshold < 1 or threshold > min_splits:
            raise ValueError(
                f"重建阈值必须在 [1, {min_splits}] 范围内, "
                f"当前值: {threshold}"
            )

        self._min_splits: int = min_splits
        self._threshold: int = threshold

        # 出口节点池: node_id -> ExitNodeInfo
        self._exit_nodes: Dict[str, ExitNodeInfo] = {}
        # 活跃的分发任务: task_id -> (segments, timestamp)
        self._active_tasks: Dict[str, Tuple[List[TrafficSegment], float]] = {}
        # 线程锁
        self._lock: threading.Lock = threading.Lock()
        # 统计计数器
        self._total_bytes_split: int = 0
        self._total_bytes_reassembled: int = 0
        self._total_splits: int = 0

        logger.info(
            "DistributedExitAggregator 初始化完成, "
            "分割数: %d, 重建阈值: %d",
            min_splits, threshold
        )

    def add_exit_node(self, node: ExitNodeInfo) -> None:
        """添加出口节点到节点池 (Add exit node to the pool)

        Args:
            node: 出口节点信息
        """
        with self._lock:
            self._exit_nodes[node.node_id] = node
            node.status = ExitNodeStatus.STANDBY

        logger.debug(
            "出口节点 %s 已添加 (%s:%d, 区域: %s)",
            node.node_id, node.ip_address, node.port, node.region.value
        )

    def remove_exit_node(self, node_id: str) -> bool:
        """移除出口节点 (Remove exit node)

        Args:
            node_id: 要移除的节点ID

        Returns:
            True如果移除成功
        """
        with self._lock:
            if node_id in self._exit_nodes:
                del self._exit_nodes[node_id]
                logger.info("出口节点 %s 已移除", node_id)
                return True
            return False

    def split_data(
        self,
        data: bytes,
        task_id: Optional[str] = None,
    ) -> List[TrafficSegment]:
        """将数据分割成多个分段 (Split data into multiple segments)

        使用简化的秘密共享方案将数据分割成多个分段，
        每个分段发送到不同的出口节点。

        数据分割过程：
        1. 生成随机分割密钥
        2. 将数据分成等大小的块
        3. 对每个块应用秘密共享
        4. 将分段分配到不同的出口节点

        Args:
            data: 要分割的原始数据
            task_id: 可选的任务ID，用于跟踪

        Returns:
            流量分段列表

        Raises:
            ValueError: 如果数据为空或过大
            RuntimeError: 如果没有足够的出口节点
        """
        if not data:
            raise ValueError("数据不能为空 (data cannot be empty)")

        if len(data) > self.MAX_DATA_SIZE:
            raise ValueError(
                f"数据大小超过限制 ({len(data)} > {self.MAX_DATA_SIZE})"
            )

        with self._lock:
            # 获取可用的出口节点
            available_nodes = self._select_exit_nodes()
            num_splits = min(len(available_nodes), self._min_splits)

            if num_splits < self._threshold:
                raise RuntimeError(
                    f"可用出口节点不足: 需要 {self._threshold} 个, "
                    f"实际 {num_splits} 个"
                )

            # 生成任务ID
            if task_id is None:
                task_id = secrets.token_hex(16)

            # 生成随机分割密钥（用于秘密共享）
            share_keys = [secrets.token_bytes(32) for _ in range(num_splits)]

            # 将数据分成块并应用秘密共享
            segments: List[TrafficSegment] = []
            chunk_size = max(1, len(data) // num_splits)

            for i in range(num_splits):
                # 计算此分段的数据范围
                start = i * chunk_size
                end = start + chunk_size if i < num_splits - 1 else len(data)
                chunk = data[start:end]

                # 使用密钥对数据块进行XOR加密（简化秘密共享）
                key = share_keys[i]
                encrypted_chunk = self._xor_data(chunk, key)

                # 创建流量分段
                segment = TrafficSegment(
                    segment_id=f"{task_id}_seg_{i}",
                    sequence=i,
                    total_segments=num_splits,
                    data=encrypted_chunk,
                    target_node_id=available_nodes[i].node_id,
                    checksum=hashlib.sha256(encrypted_chunk).hexdigest(),
                )
                segments.append(segment)

            # 存储活跃任务
            self._active_tasks[task_id] = (segments, time.time())
            self._total_bytes_split += len(data)
            self._total_splits += 1

            # 更新节点状态
            for seg in segments:
                if seg.target_node_id in self._exit_nodes:
                    self._exit_nodes[seg.target_node_id].status = (
                        ExitNodeStatus.ACTIVE
                    )
                    self._exit_nodes[seg.target_node_id].current_connections += 1

        logger.info(
            "数据分割完成: 任务 %s, %d 字节 -> %d 个分段",
            task_id, len(data), len(segments)
        )
        return segments

    def reassemble_data(
        self,
        segments: List[TrafficSegment],
        task_id: Optional[str] = None,
    ) -> bytes:
        """重新组装分段数据 (Reassemble segmented data)

        将多个分段重新组装成原始数据。需要至少 threshold 个分段
        才能成功重建。

        Args:
            segments: 流量分段列表
            task_id: 可选的任务ID

        Returns:
            重新组装的原始数据

        Raises:
            ValueError: 如果分段不足或校验失败
        """
        if not segments:
            raise ValueError("分段列表不能为空")

        # 按序号排序
        sorted_segments = sorted(segments, key=lambda s: s.sequence)

        # 验证分段完整性
        expected_total = sorted_segments[0].total_segments
        if len(sorted_segments) < self._threshold:
            raise ValueError(
                f"分段不足: 需要 {self._threshold} 个, "
                f"实际 {len(sorted_segments)} 个"
            )

        # 验证校验和
        for seg in sorted_segments:
            expected_checksum = hashlib.sha256(seg.data).hexdigest()
            if seg.checksum and seg.checksum != expected_checksum:
                raise ValueError(
                    f"分段 {seg.segment_id} 校验和不匹配"
                )

        # 重新组装数据（简化：直接拼接解密后的块）
        reassembled = b""
        for seg in sorted_segments:
            # 在实际实现中，这里会使用秘密共享的逆运算
            # 简化版本：直接使用数据（XOR是自逆运算）
            reassembled += seg.data

        # 更新统计
        with self._lock:
            self._total_bytes_reassembled += len(reassembled)
            # 清理活跃任务
            if task_id and task_id in self._active_tasks:
                del self._active_tasks[task_id]
            # 更新节点连接数
            for seg in segments:
                if seg.target_node_id in self._exit_nodes:
                    node = self._exit_nodes[seg.target_node_id]
                    node.current_connections = max(
                        0, node.current_connections - 1
                    )
                    if node.current_connections == 0:
                        node.status = ExitNodeStatus.STANDBY

        logger.info(
            "数据重组完成: %d 个分段 -> %d 字节",
            len(sorted_segments), len(reassembled)
        )
        return reassembled

    def _select_exit_nodes(self) -> List[ExitNodeInfo]:
        """选择出口节点 (Select exit nodes for traffic distribution)

        基于多维度评分选择最优的出口节点子集：
        - 地理分布多样性
        - 低延迟
        - 高安全评分
        - 可用容量

        必须在持有锁的情况下调用。

        Returns:
            选中的出口节点列表（按评分排序）
        """
        candidates = [
            node for node in self._exit_nodes.values()
            if node.status in (
                ExitNodeStatus.ACTIVE, ExitNodeStatus.STANDBY
            )
            and node.available_capacity > 0
        ]

        if not candidates:
            return []

        # 计算综合评分
        scored_nodes: List[Tuple[float, ExitNodeInfo]] = []
        for node in candidates:
            score = self._calculate_node_selection_score(node)
            scored_nodes.append((score, node))

        # 按评分降序排序
        scored_nodes.sort(key=lambda x: x[0], reverse=True)

        # 选择节点，同时考虑地理多样性
        selected: List[ExitNodeInfo] = []
        used_regions: Set[GeoRegion] = set()

        # 第一轮：每个区域选择一个节点（保证多样性）
        for score, node in scored_nodes:
            if node.region not in used_regions:
                selected.append(node)
                used_regions.add(node.region)

        # 第二轮：按评分填充剩余名额
        for score, node in scored_nodes:
            if len(selected) >= self._min_splits:
                break
            if node not in selected:
                selected.append(node)

        return selected

    def _calculate_node_selection_score(self, node: ExitNodeInfo) -> float:
        """计算节点选择评分 (Calculate node selection score)

        综合考虑延迟、安全评分、可用容量和负载因子。

        Args:
            node: 出口节点信息

        Returns:
            综合评分 (0.0 ~ 1.0)
        """
        # 延迟评分（延迟越低越好）
        latency_score = max(0.0, 1.0 - node.latency_ms / 1000.0)

        # 安全评分
        security_score = node.security_score

        # 容量评分（可用容量越大越好）
        capacity_score = min(1.0, node.available_capacity / 100.0)

        # 负载评分（负载越低越好）
        load_score = max(0.0, 1.0 - node.load_factor)

        # 加权平均
        composite = (
            0.25 * latency_score
            + 0.35 * security_score
            + 0.20 * capacity_score
            + 0.20 * load_score
        )

        return composite

    @staticmethod
    def _xor_data(data: bytes, key: bytes) -> bytes:
        """XOR加密/解密数据 (XOR encrypt/decrypt data)

        使用密钥对数据进行XOR运算。如果数据比密钥长，
        则循环使用密钥。

        Args:
            data: 原始数据
            key: 加密密钥

        Returns:
            加密/解密后的数据
        """
        if not key:
            return data
        return bytes(
            b ^ key[i % len(key)] for i, b in enumerate(data)
        )

    def get_statistics(self) -> Dict[str, Any]:
        """获取聚合器统计信息 (Get aggregator statistics)

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            active_nodes = sum(
                1 for n in self._exit_nodes.values()
                if n.status == ExitNodeStatus.ACTIVE
            )
            total_capacity = sum(
                n.available_capacity for n in self._exit_nodes.values()
            )

            return {
                "total_exit_nodes": len(self._exit_nodes),
                "active_nodes": active_nodes,
                "standby_nodes": len(self._exit_nodes) - active_nodes,
                "total_capacity": total_capacity,
                "min_splits": self._min_splits,
                "threshold": self._threshold,
                "total_bytes_split": self._total_bytes_split,
                "total_bytes_reassembled": self._total_bytes_reassembled,
                "total_splits": self._total_splits,
                "active_tasks": len(self._active_tasks),
            }


# ============================================================
# ExitEncryptionLayer - 出口节点加密层
# ============================================================

class ExitEncryptionLayer:
    """出口节点加密层 (Exit Encryption Layer)

    在出口节点与目标服务器之间提供额外的加密保护层，
    包括双重TLS封装、证书固定和安全的DNS解析。

    Features:
        - 出口与目标服务器间的额外TLS加密
        - 双重TLS封装（内层 + 外层TLS）
        - 证书固定（certificate pinning）
        - DoH/DoT出口DNS解析

    Example:
        >>> enc = ExitEncryptionLayer()
        >>> enc.add_pinned_certificate("example.com", "sha256_pin_here")
        >>> result = enc.establish_connection("example.com", 443)
    """

    # 支持的TLS版本
    SUPPORTED_TLS_VERSIONS: List[str] = ["TLSv1.3", "TLSv1.2"]
    # 默认TLS版本
    DEFAULT_TLS_VERSION: str = "TLSv1.3"
    # 默认密码套件
    DEFAULT_CIPHER_SUITES: List[str] = [
        "TLS_AES_256_GCM_SHA384",
        "TLS_CHACHA20_POLY1305_SHA256",
        "TLS_AES_128_GCM_SHA256",
    ]
    # 证书固定哈希算法
    PIN_HASH_ALGORITHM: str = "sha256"
    # 连接超时（秒）
    CONNECTION_TIMEOUT: float = 10.0
    # DNS解析超时（秒）
    DNS_TIMEOUT: float = 5.0
    # DoH服务器列表
    DEFAULT_DOH_SERVERS: List[str] = [
        "https://dns.google/dns-query",
        "https://cloudflare-dns.com/dns-query",
        "https://dns.quad9.net/dns-query",
    ]

    def __init__(
        self,
        tls_version: str = DEFAULT_TLS_VERSION,
        enable_double_tls: bool = True,
    ) -> None:
        """初始化出口加密层

        Args:
            tls_version: 使用的TLS版本
            enable_double_tls: 是否启用双重TLS封装
        """
        if tls_version not in self.SUPPORTED_TLS_VERSIONS:
            raise ValueError(
                f"不支持的TLS版本: {tls_version}, "
                f"支持: {self.SUPPORTED_TLS_VERSIONS}"
            )

        self._tls_version: str = tls_version
        self._enable_double_tls: bool = enable_double_tls

        # 证书固定存储: domain -> set of pinned hashes
        self._pinned_certs: Dict[str, Set[str]] = {}
        # 活跃的加密连接: connection_id -> connection info
        self._active_connections: Dict[str, Dict[str, Any]] = {}
        # DoH服务器列表
        self._doh_servers: List[str] = list(self.DEFAULT_DOH_SERVERS)
        # DNS缓存: domain -> (ip, timestamp)
        self._dns_cache: Dict[str, Tuple[str, float]] = {}
        # DNS缓存有效期（秒）
        self._dns_cache_ttl: int = 300
        # 线程锁
        self._lock: threading.Lock = threading.Lock()
        # 统计计数器
        self._total_encrypted_connections: int = 0
        self._total_cert_verifications: int = 0
        self._total_cert_failures: int = 0

        logger.info(
            "ExitEncryptionLayer 初始化完成, TLS: %s, 双重TLS: %s",
            tls_version, enable_double_tls
        )

    def add_pinned_certificate(
        self,
        domain: str,
        pin_hash: str,
    ) -> None:
        """添加证书固定规则 (Add certificate pinning rule)

        为指定域名添加一个证书指纹固定规则。连接时会验证
        服务器证书的指纹是否匹配。

        Args:
            domain: 目标域名
            pin_hash: 证书的SPKI指纹（Base64编码的SHA-256哈希）

        Raises:
            ValueError: 如果参数为空
        """
        if not domain or not pin_hash:
            raise ValueError("域名和证书指纹不能为空")

        with self._lock:
            if domain not in self._pinned_certs:
                self._pinned_certs[domain] = set()
            self._pinned_certs[domain].add(pin_hash)

        logger.info(
            "已添加证书固定规则: %s -> %s...",
            domain, pin_hash[:16]
        )

    def remove_pinned_certificate(
        self,
        domain: str,
        pin_hash: str,
    ) -> bool:
        """移除证书固定规则 (Remove certificate pinning rule)

        Args:
            domain: 目标域名
            pin_hash: 要移除的证书指纹

        Returns:
            True如果移除成功
        """
        with self._lock:
            if domain in self._pinned_certs:
                if pin_hash in self._pinned_certs[domain]:
                    self._pinned_certs[domain].discard(pin_hash)
                    if not self._pinned_certs[domain]:
                        del self._pinned_certs[domain]
                    logger.info(
                        "已移除证书固定规则: %s -> %s...",
                        domain, pin_hash[:16]
                    )
                    return True
            return False

    def verify_certificate(
        self,
        domain: str,
        cert_der: bytes,
    ) -> bool:
        """验证服务器证书 (Verify server certificate)

        验证服务器证书是否符合固定规则。如果域名配置了
        证书固定，则证书指纹必须匹配至少一个固定规则。

        Args:
            domain: 目标域名
            cert_der: 证书的DER编码数据

        Returns:
            True如果证书验证通过
        """
        with self._lock:
            self._total_cert_verifications += 1

            # 如果没有配置证书固定，默认通过
            if domain not in self._pinned_certs:
                logger.debug(
                    "域名 %s 未配置证书固定, 默认通过", domain
                )
                return True

            # 计算证书的SPKI指纹
            cert_pin = self._compute_spki_pin(cert_der)
            pinned_hashes = self._pinned_certs[domain]

            if cert_pin in pinned_hashes:
                logger.debug(
                    "域名 %s 证书验证通过 (匹配固定规则)", domain
                )
                return True

            self._total_cert_failures += 1
            logger.warning(
                "域名 %s 证书验证失败! 计算指纹: %s..., "
                "期望指纹: %s",
                domain, cert_pin[:16],
                [h[:16] for h in pinned_hashes]
            )
            return False

    def establish_connection(
        self,
        target_host: str,
        target_port: int,
        connection_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """建立加密连接 (Establish encrypted connection)

        在出口节点与目标服务器之间建立加密连接。
        如果启用了双重TLS，会创建两层TLS封装。

        Args:
            target_host: 目标服务器主机名
            target_port: 目标服务器端口
            connection_id: 可选的连接ID

        Returns:
            连接信息字典，包含连接ID、TLS版本、密码套件等
        """
        if connection_id is None:
            connection_id = secrets.token_hex(16)

        # 解析DNS（使用DoH）
        resolved_ip = self._resolve_dns(target_host)

        # 模拟建立TLS连接
        connection_info = {
            "connection_id": connection_id,
            "target_host": target_host,
            "target_port": target_port,
            "resolved_ip": resolved_ip,
            "tls_version": self._tls_version,
            "cipher_suite": self.DEFAULT_CIPHER_SUITES[0],
            "double_tls": self._enable_double_tls,
            "outer_tls": None,
            "established_at": time.time(),
            "status": "connected",
        }

        # 如果启用双重TLS，添加外层TLS信息
        if self._enable_double_tls:
            connection_info["outer_tls"] = {
                "version": self._tls_version,
                "cipher_suite": self.DEFAULT_CIPHER_SUITES[1]
                if len(self.DEFAULT_CIPHER_SUITES) > 1
                else self.DEFAULT_CIPHER_SUITES[0],
                "wrapped": True,
            }

        with self._lock:
            self._active_connections[connection_id] = connection_info
            self._total_encrypted_connections += 1

        logger.info(
            "加密连接已建立: %s -> %s:%d (TLS: %s, 双重: %s)",
            connection_id[:12], target_host, target_port,
            self._tls_version, self._enable_double_tls
        )

        return connection_info

    def close_connection(self, connection_id: str) -> bool:
        """关闭加密连接 (Close encrypted connection)

        Args:
            connection_id: 要关闭的连接ID

        Returns:
            True如果关闭成功
        """
        with self._lock:
            if connection_id in self._active_connections:
                conn = self._active_connections.pop(connection_id)
                conn["status"] = "closed"
                conn["closed_at"] = time.time()
                logger.info(
                    "加密连接已关闭: %s (持续时间: %.1fs)",
                    connection_id[:12],
                    conn["closed_at"] - conn["established_at"]
                )
                return True
            return False

    def resolve_dns_secure(
        self,
        domain: str,
        use_doh: bool = True,
    ) -> str:
        """安全DNS解析 (Secure DNS resolution)

        使用DoH (DNS over HTTPS) 或 DoT (DNS over TLS) 进行DNS解析，
        防止DNS劫持和窃听。

        Args:
            domain: 要解析的域名
            use_doh: 是否使用DoH（False则使用DoT）

        Returns:
            解析到的IP地址

        Raises:
            RuntimeError: 如果DNS解析失败
        """
        if use_doh:
            return self._resolve_dns_doh(domain)
        else:
            return self._resolve_dns_dot(domain)

    def _resolve_dns(self, domain: str) -> str:
        """DNS解析（带缓存）(DNS resolution with caching)

        Args:
            domain: 要解析的域名

        Returns:
            解析到的IP地址
        """
        with self._lock:
            # 检查缓存
            if domain in self._dns_cache:
                ip, cached_time = self._dns_cache[domain]
                if time.time() - cached_time < self._dns_cache_ttl:
                    logger.debug(
                        "DNS缓存命中: %s -> %s", domain, ip
                    )
                    return ip
                else:
                    # 缓存过期，移除
                    del self._dns_cache[domain]

        # 缓存未命中，执行DoH解析
        try:
            ip = self._resolve_dns_doh(domain)
            with self._lock:
                self._dns_cache[domain] = (ip, time.time())
            return ip
        except Exception as e:
            logger.error("DNS解析失败: %s, 错误: %s", domain, str(e))
            # 回退到系统DNS
            try:
                ip = socket.gethostbyname(domain)
                logger.warning(
                    "使用系统DNS回退: %s -> %s", domain, ip
                )
                return ip
            except socket.gaierror:
                raise RuntimeError(
                    f"DNS解析完全失败: {domain}"
                )

    def _resolve_dns_doh(self, domain: str) -> str:
        """使用DoH解析DNS (Resolve DNS using DNS over HTTPS)

        模拟DoH DNS解析过程。在实际实现中，会向DoH服务器
        发送HTTPS请求获取DNS记录。

        Args:
            domain: 要解析的域名

        Returns:
            解析到的IP地址（模拟）
        """
        # 在实际实现中，这里会发送HTTPS请求到DoH服务器
        # 模拟返回一个IP地址
        logger.debug(
            "DoH解析: %s (通过 %s)",
            domain, self._doh_servers[0] if self._doh_servers else "default"
        )

        # 模拟DNS解析结果
        simulated_ip = f"93.184.216.{random.randint(1, 254)}"
        return simulated_ip

    def _resolve_dns_dot(self, domain: str) -> str:
        """使用DoT解析DNS (Resolve DNS using DNS over TLS)

        模拟DoT DNS解析过程。

        Args:
            domain: 要解析的域名

        Returns:
            解析到的IP地址（模拟）
        """
        logger.debug("DoT解析: %s", domain)
        simulated_ip = f"93.184.216.{random.randint(1, 254)}"
        return simulated_ip

    @staticmethod
    def _compute_spki_pin(cert_der: bytes) -> str:
        """计算证书的SPKI指纹 (Compute SPKI pin of a certificate)

        按照RFC 7469标准计算证书的Subject Public Key Info (SPKI)
        指纹，用于证书固定。

        Args:
            cert_der: 证书的DER编码

        Returns:
            Base64编码的SHA-256 SPKI指纹
        """
        import base64
        # 在实际实现中，需要从DER编码中提取SPKI部分
        # 这里简化为对整个证书计算哈希
        digest = hashlib.sha256(cert_der).digest()
        return base64.b64encode(digest).decode("ascii")

    def get_statistics(self) -> Dict[str, Any]:
        """获取加密层统计信息 (Get encryption layer statistics)

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            return {
                "tls_version": self._tls_version,
                "double_tls_enabled": self._enable_double_tls,
                "active_connections": len(self._active_connections),
                "total_encrypted_connections": self._total_encrypted_connections,
                "total_cert_verifications": self._total_cert_verifications,
                "total_cert_failures": self._total_cert_failures,
                "pinned_domains": len(self._pinned_certs),
                "dns_cache_size": len(self._dns_cache),
                "doh_servers": len(self._doh_servers),
            }


# ============================================================
# ExitNodeRotator - 出口节点动态轮换器
# ============================================================

class ExitNodeRotator:
    """出口节点动态轮换器 (Exit Node Rotator)

    定期自动轮换出口节点，实现流量的无中断切换。
    轮换策略基于节点的性能评分和安全评分，优先选择
    评分高的节点作为新的出口。

    Features:
        - 默认10分钟轮换间隔
        - 平滑轮换（无中断切换）
        - 轮换策略（基于性能和安全评分）
        - 轮换历史记录

    Example:
        >>> rotator = ExitNodeRotator(rotation_interval=600)
        >>> rotator.add_node(ExitNodeInfo("exit_1", "1.2.3.4", 443))
        >>> rotator.add_node(ExitNodeInfo("exit_2", "5.6.7.8", 443))
        >>> record = rotator.rotate()
    """

    # 默认轮换间隔（秒）- 10分钟
    DEFAULT_ROTATION_INTERVAL: int = 600
    # 最小轮换间隔（秒）
    MIN_ROTATION_INTERVAL: int = 60
    # 最大轮换间隔（秒）
    MAX_ROTATION_INTERVAL: int = 3600
    # 平滑轮换过渡时间（秒）
    SMOOTH_TRANSITION_TIME: float = 30.0
    # 最大轮换历史记录数
    MAX_HISTORY_SIZE: int = 1000
    # 连接迁移超时（秒）
    MIGRATION_TIMEOUT: float = 10.0

    def __init__(
        self,
        rotation_interval: int = DEFAULT_ROTATION_INTERVAL,
    ) -> None:
        """初始化出口节点轮换器

        Args:
            rotation_interval: 轮换间隔（秒）

        Raises:
            ValueError: 如果间隔超出范围
        """
        if not self.MIN_ROTATION_INTERVAL <= rotation_interval <= self.MAX_ROTATION_INTERVAL:
            raise ValueError(
                f"轮换间隔必须在 [{self.MIN_ROTATION_INTERVAL}, "
                f"{self.MAX_ROTATION_INTERVAL}] 范围内, "
                f"当前值: {rotation_interval}"
            )

        self._rotation_interval: int = rotation_interval

        # 所有出口节点: node_id -> ExitNodeInfo
        self._all_nodes: Dict[str, ExitNodeInfo] = {}
        # 当前活跃的出口节点
        self._current_exit: Optional[ExitNodeInfo] = None
        # 上一个出口节点（用于平滑过渡）
        self._previous_exit: Optional[ExitNodeInfo] = None
        # 轮换历史记录
        self._rotation_history: List[RotationRecord] = []
        # 是否正在轮换中
        self._is_rotating: bool = False
        # 上次轮换时间
        self._last_rotation: float = time.time()
        # 线程锁
        self._lock: threading.Lock = threading.Lock()
        # 统计计数器
        self._total_rotations: int = 0
        self._successful_rotations: int = 0
        self._failed_rotations: int = 0

        logger.info(
            "ExitNodeRotator 初始化完成, 轮换间隔: %ds",
            rotation_interval
        )

    def add_node(self, node: ExitNodeInfo) -> None:
        """添加出口节点 (Add exit node)

        Args:
            node: 出口节点信息
        """
        with self._lock:
            self._all_nodes[node.node_id] = node
            # 如果没有当前出口节点，设置第一个添加的节点
            if self._current_exit is None:
                self._current_exit = node
                node.status = ExitNodeStatus.ACTIVE
                logger.info(
                    "设置初始出口节点: %s (%s:%d)",
                    node.node_id, node.ip_address, node.port
                )

        logger.debug(
            "出口节点 %s 已添加到轮换池", node.node_id
        )

    def remove_node(self, node_id: str) -> bool:
        """移除出口节点 (Remove exit node)

        如果移除的是当前活跃节点，会触发紧急轮换。

        Args:
            node_id: 要移除的节点ID

        Returns:
            True如果移除成功
        """
        with self._lock:
            if node_id not in self._all_nodes:
                return False

            node = self._all_nodes.pop(node_id)
            node.status = ExitNodeStatus.DISABLED

            # 如果移除的是当前出口节点
            if self._current_exit and self._current_exit.node_id == node_id:
                logger.warning(
                    "当前出口节点 %s 被移除, 触发紧急轮换",
                    node_id
                )
                self._current_exit = None

            return True

    def rotate(
        self,
        reason: str = "scheduled",
    ) -> Optional[RotationRecord]:
        """执行出口节点轮换 (Execute exit node rotation)

        将当前出口节点切换到评分更高的备用节点。
        使用平滑过渡策略，确保在过渡期间不会中断现有连接。

        轮换过程：
        1. 选择新的出口节点（基于综合评分）
        2. 建立到新节点的连接
        3. 将现有连接迁移到新节点
        4. 关闭旧节点的连接
        5. 更新状态

        Args:
            reason: 轮换原因（scheduled, performance, security, emergency）

        Returns:
            轮换记录，如果没有可用的替代节点则返回None
        """
        with self._lock:
            if self._is_rotating:
                logger.warning("轮换正在进行中，跳过")
                return None

            if not self._current_exit:
                logger.warning("没有当前出口节点，无法轮换")
                return None

            # 检查是否有可用的替代节点
            candidates = self._get_rotation_candidates()
            if not candidates:
                logger.warning("没有可用的替代节点，无法轮换")
                return None

            # 标记轮换开始
            self._is_rotating = True
            old_node = self._current_exit
            new_node = candidates[0]  # 评分最高的候选

            # 创建轮换记录
            record = RotationRecord(
                rotation_id=secrets.token_hex(8),
                old_node_id=old_node.node_id,
                new_node_id=new_node.node_id,
                start_time=time.time(),
                reason=reason,
            )

            logger.info(
                "开始轮换: %s -> %s (原因: %s)",
                old_node.node_id, new_node.node_id, reason
            )

        # 在锁外执行实际的连接迁移（可能耗时）
        try:
            migrated = self._migrate_connections(old_node, new_node)

            with self._lock:
                # 更新节点状态
                old_node.status = ExitNodeStatus.STANDBY
                new_node.status = ExitNodeStatus.ACTIVE
                self._previous_exit = old_node
                self._current_exit = new_node

                # 完成轮换记录
                record.end_time = time.time()
                record.connections_migrated = migrated
                record.success = True
                self._rotation_history.append(record)
                self._last_rotation = time.time()
                self._total_rotations += 1
                self._successful_rotations += 1

                # 限制历史记录大小
                if len(self._rotation_history) > self.MAX_HISTORY_SIZE:
                    self._rotation_history = (
                        self._rotation_history[-self.MAX_HISTORY_SIZE:]
                    )

            logger.info(
                "轮换完成: %s -> %s, 迁移 %d 个连接, "
                "耗时 %.2fs",
                old_node.node_id, new_node.node_id,
                migrated, record.end_time - record.start_time
            )

        except Exception as e:
            with self._lock:
                record.end_time = time.time()
                record.success = False
                self._rotation_history.append(record)
                self._total_rotations += 1
                self._failed_rotations += 1

            logger.error(
                "轮换失败: %s -> %s, 错误: %s",
                old_node.node_id, new_node.node_id, str(e)
            )
        finally:
            with self._lock:
                self._is_rotating = False

        return record

    def should_rotate(self) -> bool:
        """检查是否应该执行轮换 (Check if rotation should be performed)

        Returns:
            True如果距离上次轮换已超过间隔时间
        """
        with self._lock:
            elapsed = time.time() - self._last_rotation
            return elapsed >= self._rotation_interval

    def get_current_exit(self) -> Optional[ExitNodeInfo]:
        """获取当前活跃的出口节点 (Get current active exit node)

        Returns:
            当前出口节点信息，如果没有则返回None
        """
        with self._lock:
            return self._current_exit

    def force_rotation(self, reason: str = "forced") -> Optional[RotationRecord]:
        """强制执行轮换 (Force a rotation)

        无论是否到达轮换间隔，立即执行轮换。

        Args:
            reason: 轮换原因

        Returns:
            轮换记录
        """
        logger.info("强制轮换触发, 原因: %s", reason)
        return self.rotate(reason=reason)

    def get_rotation_history(
        self,
        limit: int = 20,
    ) -> List[RotationRecord]:
        """获取轮换历史记录 (Get rotation history)

        Args:
            limit: 返回的最大记录数

        Returns:
            轮换记录列表（按时间倒序）
        """
        with self._lock:
            history = list(reversed(self._rotation_history))
            return history[:limit]

    def get_statistics(self) -> Dict[str, Any]:
        """获取轮换器统计信息 (Get rotator statistics)

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            avg_migration_time = 0.0
            if self._rotation_history:
                times = [
                    r.end_time - r.start_time
                    for r in self._rotation_history
                    if r.end_time > 0
                ]
                if times:
                    avg_migration_time = sum(times) / len(times)

            return {
                "rotation_interval": self._rotation_interval,
                "total_rotations": self._total_rotations,
                "successful_rotations": self._successful_rotations,
                "failed_rotations": self._failed_rotations,
                "success_rate": (
                    self._successful_rotations / self._total_rotations
                    if self._total_rotations > 0 else 0.0
                ),
                "avg_migration_time": round(avg_migration_time, 4),
                "current_exit": (
                    self._current_exit.node_id
                    if self._current_exit else None
                ),
                "available_nodes": len(self._all_nodes),
                "is_rotating": self._is_rotating,
                "last_rotation": self._last_rotation,
                "time_since_last_rotation": (
                    time.time() - self._last_rotation
                ),
            }

    def _get_rotation_candidates(self) -> List[ExitNodeInfo]:
        """获取轮换候选节点 (Get rotation candidate nodes)

        返回按综合评分排序的可用候选节点列表。
        排除当前活跃节点和不可用节点。

        必须在持有锁的情况下调用。

        Returns:
            候选节点列表（按评分降序）
        """
        if not self._current_exit:
            return []

        candidates = [
            node for node in self._all_nodes.values()
            if node.node_id != self._current_exit.node_id
            and node.status not in (
                ExitNodeStatus.DISABLED,
                ExitNodeStatus.COMPROMISED,
            )
            and node.available_capacity > 0
        ]

        # 按综合评分排序
        candidates.sort(
            key=lambda n: (
                0.5 * n.security_score + 0.3 * n.performance_score
                + 0.2 * (1.0 - n.load_factor)
            ),
            reverse=True,
        )

        return candidates

    def _migrate_connections(
        self,
        old_node: ExitNodeInfo,
        new_node: ExitNodeInfo,
    ) -> int:
        """迁移连接从旧节点到新节点 (Migrate connections from old to new node)

        模拟连接迁移过程。在实际实现中，这里会：
        1. 在新节点上建立新的连接
        2. 将旧连接的状态复制到新连接
        3. 更新连接映射
        4. 关闭旧连接

        Args:
            old_node: 旧出口节点
            new_node: 新出口节点

        Returns:
            成功迁移的连接数
        """
        # 模拟连接迁移
        connections_to_migrate = old_node.current_connections

        logger.debug(
            "开始迁移 %d 个连接: %s -> %s",
            connections_to_migrate, old_node.node_id, new_node.node_id
        )

        # 模拟迁移过程
        migrated = 0
        for i in range(connections_to_migrate):
            try:
                # 在实际实现中，这里会执行实际的连接迁移
                # 模拟: 95%的连接迁移成功
                if random.random() < 0.95:
                    migrated += 1
            except Exception as e:
                logger.warning(
                    "连接 %d 迁移失败: %s", i, str(e)
                )

        # 更新连接计数
        old_node.current_connections = max(
            0, connections_to_migrate - migrated
        )
        new_node.current_connections += migrated

        logger.debug(
            "连接迁移完成: %d/%d 成功",
            migrated, connections_to_migrate
        )

        return migrated


# ============================================================
# DecoyExitManager - 诱饵出口节点管理器
# ============================================================

class DecoyExitManager:
    """诱饵出口节点管理器 (Decoy Exit Node Manager)

    管理诱饵出口节点的部署、流量生成和攻击者检测。
    诱饵节点看起来像真实的出口节点，但实际上用于检测
    和识别恶意行为。

    Features:
        - 诱饵出口部署策略
        - 虚假流量生成（模拟真实用户行为）
        - 攻击者诱捕和检测
        - 诱饵节点资源管理

    Example:
        >>> manager = DecoyExitManager(max_decoys=5)
        >>> manager.deploy_decoy(ExitNodeInfo("decoy_1", "10.0.0.1", 443))
        >>> alerts = manager.check_for_intrusions()
    """

    # 默认最大诱饵节点数
    DEFAULT_MAX_DECOYS: int = 5
    # 流量生成间隔（秒）
    TRAFFIC_GEN_INTERVAL: float = 2.0
    # 可疑行为检测阈值
    SUSPICIOUS_REQUEST_THRESHOLD: int = 100  # 每分钟请求数
    # 异常数据包大小阈值（字节）
    ANOMALOUS_PACKET_SIZE: int = 65536
    # 诱饵节点心跳间隔（秒）
    HEARTBEAT_INTERVAL: int = 30
    # 诱饵节点最大资源使用率
    MAX_RESOURCE_USAGE: float = 0.3  # 30%

    def __init__(
        self,
        max_decoys: int = DEFAULT_MAX_DECOYS,
        traffic_profiles: Optional[List[DecoyTrafficProfile]] = None,
    ) -> None:
        """初始化诱饵出口节点管理器

        Args:
            max_decoys: 最大诱饵节点数量
            traffic_profiles: 自定义流量配置文件列表
        """
        if max_decoys < 0:
            raise ValueError(
                f"最大诱饵节点数不能为负数: {max_decoys}"
            )

        self._max_decoys: int = max_decoys

        # 诱饵节点: node_id -> ExitNodeInfo
        self._decoy_nodes: Dict[str, ExitNodeInfo] = {}
        # 流量配置文件
        self._traffic_profiles: List[DecoyTrafficProfile] = (
            traffic_profiles or [DecoyTrafficProfile(profile_id="default")]
        )
        # 安全告警记录
        self._alerts: List[Dict[str, Any]] = []
        # 每个诱饵节点的请求计数: node_id -> list of timestamps
        self._request_counts: Dict[str, List[float]] = {}
        # 检测到的可疑IP: ip -> (count, first_seen, last_seen)
        self._suspicious_ips: Dict[str, Tuple[int, float, float]] = {}
        # 流量生成线程控制
        self._traffic_gen_running: bool = False
        self._traffic_gen_thread: Optional[threading.Thread] = None
        # 线程锁
        self._lock: threading.Lock = threading.Lock()
        # 统计计数器
        self._total_fake_requests: int = 0
        self._total_intrusions_detected: int = 0
        self._total_decoys_deployed: int = 0

        logger.info(
            "DecoyExitManager 初始化完成, 最大诱饵数: %d",
            max_decoys
        )

    def deploy_decoy(self, node: ExitNodeInfo) -> bool:
        """部署诱饵出口节点 (Deploy a decoy exit node)

        将一个节点标记为诱饵节点并开始监控。

        Args:
            node: 要部署为诱饵的节点信息

        Returns:
            True如果部署成功

        Raises:
            RuntimeError: 如果已达到最大诱饵节点数
        """
        with self._lock:
            if len(self._decoy_nodes) >= self._max_decoys:
                raise RuntimeError(
                    f"已达到最大诱饵节点数 ({self._max_decoys})"
                )

            node.status = ExitNodeStatus.DECOY
            self._decoy_nodes[node.node_id] = node
            self._request_counts[node.node_id] = []
            self._total_decoys_deployed += 1

        logger.info(
            "诱饵节点已部署: %s (%s:%d, 区域: %s)",
            node.node_id, node.ip_address, node.port, node.region.value
        )
        return True

    def remove_decoy(self, node_id: str) -> bool:
        """移除诱饵节点 (Remove a decoy node)

        Args:
            node_id: 要移除的诱饵节点ID

        Returns:
            True如果移除成功
        """
        with self._lock:
            if node_id in self._decoy_nodes:
                node = self._decoy_nodes.pop(node_id)
                node.status = ExitNodeStatus.DISABLED
                self._request_counts.pop(node_id, None)
                logger.info("诱饵节点已移除: %s", node_id)
                return True
            return False

    def record_request(
        self,
        node_id: str,
        source_ip: str,
        request_size: int = 0,
        path: str = "",
    ) -> Optional[Dict[str, Any]]:
        """记录到诱饵节点的请求 (Record a request to a decoy node)

        分析请求是否可疑，如果检测到异常行为则生成告警。

        可疑行为包括：
        - 请求频率异常高
        - 请求数据包大小异常
        - 尝试访问敏感路径
        - 端口扫描行为

        Args:
            node_id: 诱饵节点ID
            source_ip: 请求来源IP
            request_size: 请求数据大小（字节）
            path: 请求路径

        Returns:
            如果检测到可疑行为则返回告警信息，否则返回None
        """
        alert: Optional[Dict[str, Any]] = None

        with self._lock:
            if node_id not in self._decoy_nodes:
                return None

            now = time.time()

            # 记录请求时间戳
            if node_id not in self._request_counts:
                self._request_counts[node_id] = []
            self._request_counts[node_id].append(now)

            # 清理1分钟前的请求记录
            cutoff = now - 60.0
            self._request_counts[node_id] = [
                t for t in self._request_counts[node_id] if t > cutoff
            ]

            # 检查1: 请求频率是否异常
            requests_per_minute = len(self._request_counts[node_id])
            if requests_per_minute > self.SUSPICIOUS_REQUEST_THRESHOLD:
                alert = self._create_alert(
                    alert_type="high_frequency",
                    node_id=node_id,
                    source_ip=source_ip,
                    severity="high",
                    details={
                        "requests_per_minute": requests_per_minute,
                        "threshold": self.SUSPICIOUS_REQUEST_THRESHOLD,
                    },
                )

            # 检查2: 数据包大小是否异常
            if request_size > self.ANOMALOUS_PACKET_SIZE:
                alert = self._create_alert(
                    alert_type="anomalous_packet",
                    node_id=node_id,
                    source_ip=source_ip,
                    severity="medium",
                    details={
                        "packet_size": request_size,
                        "threshold": self.ANOMALOUS_PACKET_SIZE,
                    },
                )

            # 检查3: 敏感路径访问
            sensitive_paths = {
                "/admin", "/config", "/.env", "/etc/passwd",
                "/wp-admin", "/phpmyadmin", "/shell",
            }
            if path and any(
                sensitive in path.lower()
                for sensitive in sensitive_paths
            ):
                alert = self._create_alert(
                    alert_type="sensitive_path_access",
                    node_id=node_id,
                    source_ip=source_ip,
                    severity="high",
                    details={"path": path},
                )

            # 更新可疑IP记录
            if alert:
                if source_ip not in self._suspicious_ips:
                    self._suspicious_ips[source_ip] = (
                        0, now, now
                    )
                count, first_seen, _ = self._suspicious_ips[source_ip]
                self._suspicious_ips[source_ip] = (
                    count + 1, first_seen, now
                )

        return alert

    def generate_fake_traffic(self) -> int:
        """为所有诱饵节点生成虚假流量 (Generate fake traffic for all decoy nodes)

        模拟真实用户行为生成虚假流量，使诱饵节点看起来
        像真实的出口节点。

        Returns:
            生成的虚假请求数量
        """
        total_requests = 0

        with self._lock:
            for node_id, node in self._decoy_nodes.items():
                # 为每个诱饵节点选择一个流量配置文件
                profile = random.choice(self._traffic_profiles)

                # 根据配置生成请求
                num_requests = self._calculate_request_count(profile)
                total_requests += num_requests

                # 模拟生成虚假请求
                for _ in range(num_requests):
                    # 随机选择目标域名
                    domain = random.choice(profile.target_domains)
                    # 随机选择User-Agent
                    ua = random.choice(profile.user_agent_rotation)
                    # 模拟请求大小
                    req_size = int(
                        profile.avg_request_size_bytes
                        * (0.5 + random.random())
                    )

                    logger.debug(
                        "诱饵 %s: 虚假请求 -> %s (UA: %s..., 大小: %d)",
                        node_id, domain, ua[:30], req_size
                    )

                # 更新节点活跃时间
                node.last_active = time.time()

            self._total_fake_requests += total_requests

        if total_requests > 0:
            logger.debug(
                "虚假流量生成完成: %d 个请求 (%d 个诱饵节点)",
                total_requests, len(self._decoy_nodes)
            )

        return total_requests

    def start_traffic_generation(self) -> None:
        """启动后台流量生成 (Start background traffic generation)

        启动一个后台线程，定期为诱饵节点生成虚假流量。
        """
        with self._lock:
            if self._traffic_gen_running:
                logger.warning("流量生成已在运行中")
                return

            self._traffic_gen_running = True
            self._traffic_gen_thread = threading.Thread(
                target=self._traffic_gen_loop,
                daemon=True,
            )
            self._traffic_gen_thread.start()

        logger.info("后台流量生成已启动")

    def stop_traffic_generation(self) -> None:
        """停止后台流量生成 (Stop background traffic generation)"""
        with self._lock:
            self._traffic_gen_running = False

        if self._traffic_gen_thread is not None:
            self._traffic_gen_thread.join(timeout=5.0)
            self._traffic_gen_thread = None

        logger.info("后台流量生成已停止")

    def check_for_intrusions(self) -> List[Dict[str, Any]]:
        """检查所有诱饵节点的入侵迹象 (Check all decoy nodes for intrusion signs)

        分析所有诱饵节点的请求模式，检测潜在的攻击行为。

        Returns:
            检测到的告警列表
        """
        all_alerts: List[Dict[str, Any]] = []

        with self._lock:
            for node_id in self._decoy_nodes:
                # 获取此节点的最近告警
                node_alerts = [
                    a for a in self._alerts
                    if a.get("node_id") == node_id
                ]
                all_alerts.extend(node_alerts)

            # 按严重程度排序
            severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
            all_alerts.sort(
                key=lambda a: severity_order.get(
                    a.get("severity", "low"), 4
                )
            )

        if all_alerts:
            logger.warning(
                "检测到 %d 个安全告警", len(all_alerts)
            )

        return all_alerts

    def get_suspicious_ips(self) -> List[Dict[str, Any]]:
        """获取可疑IP列表 (Get list of suspicious IPs)

        Returns:
            可疑IP信息列表，按告警次数降序排列
        """
        with self._lock:
            ip_list = [
                {
                    "ip": ip,
                    "alert_count": count,
                    "first_seen": first_seen,
                    "last_seen": last_seen,
                }
                for ip, (count, first_seen, last_seen)
                in self._suspicious_ips.items()
            ]
            ip_list.sort(key=lambda x: x["alert_count"], reverse=True)
            return ip_list

    def get_decoy_nodes(self) -> List[ExitNodeInfo]:
        """获取所有诱饵节点 (Get all decoy nodes)

        Returns:
            诱饵节点列表
        """
        with self._lock:
            return list(self._decoy_nodes.values())

    def get_statistics(self) -> Dict[str, Any]:
        """获取诱饵管理器统计信息 (Get decoy manager statistics)

        Returns:
            包含统计信息的字典
        """
        with self._lock:
            return {
                "max_decoys": self._max_decoys,
                "active_decoys": len(self._decoy_nodes),
                "total_decoys_deployed": self._total_decoys_deployed,
                "total_fake_requests": self._total_fake_requests,
                "total_intrusions_detected": self._total_intrusions_detected,
                "total_alerts": len(self._alerts),
                "suspicious_ips": len(self._suspicious_ips),
                "traffic_gen_running": self._traffic_gen_running,
                "traffic_profiles": len(self._traffic_profiles),
            }

    def _create_alert(
        self,
        alert_type: str,
        node_id: str,
        source_ip: str,
        severity: str,
        details: Dict[str, Any],
    ) -> Dict[str, Any]:
        """创建安全告警 (Create a security alert)

        必须在持有锁的情况下调用。

        Args:
            alert_type: 告警类型
            node_id: 相关的诱饵节点ID
            source_ip: 来源IP
            severity: 严重程度
            details: 告警详情

        Returns:
            告警信息字典
        """
        alert = {
            "alert_id": secrets.token_hex(8),
            "alert_type": alert_type,
            "node_id": node_id,
            "source_ip": source_ip,
            "severity": severity,
            "details": details,
            "timestamp": time.time(),
        }

        self._alerts.append(alert)
        self._total_intrusions_detected += 1

        # 限制告警记录数量
        if len(self._alerts) > 10000:
            self._alerts = self._alerts[-10000:]

        logger.warning(
            "安全告警 [%s]: 类型=%s, 节点=%s, 来源=%s, 详情=%s",
            severity, alert_type, node_id, source_ip, details
        )

        return alert

    def _calculate_request_count(
        self,
        profile: DecoyTrafficProfile,
    ) -> int:
        """根据流量配置计算请求数量 (Calculate request count from profile)

        考虑时间模式和抖动，计算本次应该生成的请求数量。

        Args:
            profile: 流量配置文件

        Returns:
            应该生成的请求数量
        """
        # 基础请求数（每秒）
        base_rps = profile.requests_per_minute / 60.0

        # 应用时间模式
        if profile.time_pattern == "work_hours":
            hour = time.localtime().tm_hour
            if 9 <= hour <= 17:
                base_rps *= 1.5  # 工作时间流量更高
            else:
                base_rps *= 0.3  # 非工作时间流量较低
        elif profile.time_pattern == "burst":
            # 突发模式: 20%概率产生3倍流量
            if random.random() < 0.2:
                base_rps *= 3.0

        # 应用抖动
        jitter = profile.jitter_percent / 100.0
        actual_rps = base_rps * (1.0 + random.uniform(-jitter, jitter))

        # 每次调用生成 TRAFFIC_GEN_INTERVAL 秒的流量
        count = int(actual_rps * self.TRAFFIC_GEN_INTERVAL)
        return max(0, count)

    def _traffic_gen_loop(self) -> None:
        """流量生成循环 (Traffic generation loop)

        后台线程的主循环，定期生成虚假流量。
        """
        logger.info("流量生成循环已启动")

        while self._traffic_gen_running:
            try:
                self.generate_fake_traffic()
            except Exception as e:
                logger.error(
                    "流量生成出错: %s", str(e), exc_info=True
                )

            # 等待下一次生成
            time.sleep(self.TRAFFIC_GEN_INTERVAL)

        logger.info("流量生成循环已退出")


# ============================================================
# 模块自测试
# ============================================================

def _run_self_tests() -> None:
    """运行模块自测试 (Run module self-tests)"""
    logging.basicConfig(level=logging.DEBUG)
    print("=" * 60)
    print("出口节点安全与隐私保护模块 - 自测试")
    print("=" * 60)

    # 测试 DistributedExitAggregator
    print("\n--- 测试 DistributedExitAggregator ---")
    aggregator = DistributedExitAggregator(min_splits=3, threshold=2)

    # 添加不同区域的出口节点
    regions = [
        GeoRegion.NORTH_AMERICA, GeoRegion.EUROPE,
        GeoRegion.ASIA_PACIFIC, GeoRegion.SOUTH_AMERICA,
    ]
    for i, region in enumerate(regions):
        node = ExitNodeInfo(
            f"exit_{i}", f"10.0.{i}.1", 443,
            region=region,
            bandwidth_mbps=100 + i * 50,
            latency_ms=50 + i * 30,
            security_score=0.7 + i * 0.05,
        )
        aggregator.add_exit_node(node)

    # 测试数据分割和重组
    test_data = b"Hello, this is a secret message for testing!"
    segments = aggregator.split_data(test_data)
    print(f"  数据分割: {len(test_data)} 字节 -> {len(segments)} 个分段")
    for seg in segments:
        print(f"    分段 {seg.sequence}: 目标节点={seg.target_node_id}, "
              f"大小={len(seg.data)} 字节")

    reassembled = aggregator.reassemble_data(segments)
    print(f"  数据重组: {len(segments)} 个分段 -> {len(reassembled)} 字节")
    stats = aggregator.get_statistics()
    print(f"  统计信息: {stats}")

    # 测试 ExitEncryptionLayer
    print("\n--- 测试 ExitEncryptionLayer ---")
    enc_layer = ExitEncryptionLayer(
        tls_version="TLSv1.3", enable_double_tls=True
    )

    # 添加证书固定
    enc_layer.add_pinned_certificate(
        "example.com",
        "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
    )
    enc_layer.add_pinned_certificate(
        "secure.example.org",
        "sha256/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB="
    )

    # 测试证书验证
    fake_cert = b"fake_certificate_data_for_testing"
    result1 = enc_layer.verify_certificate("example.com", fake_cert)
    print(f"  证书验证 (不匹配): {result1}")

    # 测试建立连接
    conn = enc_layer.establish_connection("example.com", 443)
    print(f"  建立连接: {conn['connection_id'][:16]}... "
          f"-> {conn['target_host']}:{conn['target_port']}")
    print(f"  双重TLS: {conn['double_tls']}")

    # 测试DNS解析
    ip = enc_layer.resolve_dns_secure("example.com")
    print(f"  DNS解析: example.com -> {ip}")

    enc_layer.close_connection(conn["connection_id"])
    stats = enc_layer.get_statistics()
    print(f"  统计信息: {stats}")

    # 测试 ExitNodeRotator
    print("\n--- 测试 ExitNodeRotator ---")
    rotator = ExitNodeRotator(rotation_interval=300)

    for i in range(5):
        node = ExitNodeInfo(
            f"rot_exit_{i}", f"172.16.{i}.1", 443,
            security_score=0.6 + i * 0.08,
            performance_score=0.7 + i * 0.05,
            current_connections=random.randint(10, 200),
        )
        rotator.add_node(node)

    # 执行轮换
    record = rotator.rotate(reason="test")
    if record:
        print(f"  轮换完成: {record.old_node_id} -> {record.new_node_id}")
        print(f"  迁移连接: {record.connections_migrated}")
        print(f"  耗时: {record.end_time - record.start_time:.4f}s")

    current = rotator.get_current_exit()
    print(f"  当前出口: {current.node_id if current else 'None'}")

    history = rotator.get_rotation_history(5)
    print(f"  轮换历史: {len(history)} 条记录")
    stats = rotator.get_statistics()
    print(f"  统计信息: {stats}")

    # 测试 DecoyExitManager
    print("\n--- 测试 DecoyExitManager ---")
    decoy_mgr = DecoyExitManager(max_decoys=3)

    # 部署诱饵节点
    for i in range(3):
        node = ExitNodeInfo(
            f"decoy_{i}", f"192.168.{i}.1", 443,
            region=GeoRegion.NORTH_AMERICA,
        )
        decoy_mgr.deploy_decoy(node)

    # 模拟正常请求
    decoy_mgr.record_request("decoy_0", "10.0.0.1", 512, "/index.html")
    print("  正常请求: 无告警")

    # 模拟可疑请求
    alert = decoy_mgr.record_request(
        "decoy_0", "10.0.0.2", 100000, "/admin"
    )
    print(f"  可疑请求 (敏感路径): "
          f"{'告警' if alert else '无告警'}")

    # 模拟高频请求
    for _ in range(110):
        decoy_mgr.record_request("decoy_1", "10.0.0.3", 256)
    alert = decoy_mgr.record_request("decoy_1", "10.0.0.3", 256)
    print(f"  高频请求: {'告警' if alert else '无告警'}")

    # 生成虚假流量
    fake_count = decoy_mgr.generate_fake_traffic()
    print(f"  虚假流量生成: {fake_count} 个请求")

    # 检查入侵
    alerts = decoy_mgr.check_for_intrusions()
    print(f"  安全告警: {len(alerts)} 个")

    suspicious = decoy_mgr.get_suspicious_ips()
    print(f"  可疑IP: {len(suspicious)} 个")

    stats = decoy_mgr.get_statistics()
    print(f"  统计信息: {stats}")

    print("\n" + "=" * 60)
    print("所有自测试完成!")
    print("=" * 60)


if __name__ == "__main__":
    _run_self_tests()
