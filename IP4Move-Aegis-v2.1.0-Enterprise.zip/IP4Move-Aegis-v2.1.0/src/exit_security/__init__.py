"""
出口节点安全与隐私保护模块 (Exit Node Security & Privacy Protection Module)

本模块提供了出口节点的安全与隐私保护功能，包括：
- 分布式出口聚合，通过秘密共享分散流量
- 出口节点加密层，提供双重TLS封装和证书固定
- 出口节点动态轮换，实现无中断的出口切换
- 诱饵出口节点，用于攻击者诱捕和检测

This module provides exit node security and privacy protection features,
including distributed exit aggregation, exit encryption layer, dynamic exit
node rotation, and decoy exit node management.
"""

from src.exit_security.secure_exit import (
    DistributedExitAggregator,
    ExitEncryptionLayer,
    ExitNodeRotator,
    DecoyExitManager,
)

__all__ = [
    "DistributedExitAggregator",
    "ExitEncryptionLayer",
    "ExitNodeRotator",
    "DecoyExitManager",
]

__version__ = "1.0.0"
__author__ = "IP4Move-Aegis Security Team"
