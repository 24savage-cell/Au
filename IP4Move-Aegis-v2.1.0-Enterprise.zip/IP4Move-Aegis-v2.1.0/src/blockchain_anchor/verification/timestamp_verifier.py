"""
时间戳验证器

验证区块链时间戳的有效性。
"""

import logging
import time
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class TimestampVerification:
    """时间戳验证结果"""
    valid: bool
    blockchain_time: Optional[int]
    local_time: int
    drift_seconds: int
    sources: List[str]
    error_message: Optional[str] = None


class TimestampVerifier:
    """
    时间戳验证器
    
    验证区块链时间戳并与本地时间对比。
    """
    
    def __init__(self, max_drift_seconds: int = 300):
        """
        初始化时间戳验证器
        
        Args:
            max_drift_seconds: 最大允许时间漂移（秒）
        """
        self.max_drift_seconds = max_drift_seconds
        self.time_sources: List[str] = ["blockchain", "ntp", "system"]
        logger.info(f"初始化时间戳验证器: max_drift={max_drift_seconds}s")
    
    def verify_timestamp(self, blockchain_timestamp: int, 
                        tx_hash: Optional[str] = None) -> TimestampVerification:
        """
        验证时间戳
        
        Args:
            blockchain_timestamp: 区块链时间戳
            tx_hash: 交易哈希（可选）
            
        Returns:
            验证结果
        """
        try:
            local_time = int(time.time())
            drift = abs(local_time - blockchain_timestamp)
            
            valid = drift <= self.max_drift_seconds
            
            sources = ["blockchain"]
            
            # 如果提供了交易哈希，验证交易存在性
            if tx_hash:
                if self._verify_transaction_exists(tx_hash):
                    sources.append("tx_verified")
                else:
                    return TimestampVerification(
                        valid=False,
                        blockchain_time=blockchain_timestamp,
                        local_time=local_time,
                        drift_seconds=drift,
                        sources=sources,
                        error_message="交易不存在"
                    )
            
            result = TimestampVerification(
                valid=valid,
                blockchain_time=blockchain_timestamp,
                local_time=local_time,
                drift_seconds=drift,
                sources=sources,
                error_message=None if valid else f"时间漂移过大: {drift}s > {self.max_drift_seconds}s"
            )
            
            logger.info(f"时间戳验证: valid={valid}, drift={drift}s")
            return result
            
        except Exception as e:
            logger.error(f"时间戳验证失败: {e}")
            return TimestampVerification(
                valid=False,
                blockchain_time=None,
                local_time=int(time.time()),
                drift_seconds=0,
                sources=[],
                error_message=str(e)
            )
    
    def _verify_transaction_exists(self, tx_hash: str) -> bool:
        """
        验证交易是否存在
        
        Args:
            tx_hash: 交易哈希
            
        Returns:
            是否存在
        """
        # 实际应查询区块链
        logger.debug(f"验证交易存在: {tx_hash}")
        return True
    
    def get_blockchain_time(self, blockchain: str = "ethereum") -> Optional[int]:
        """
        获取区块链当前时间
        
        Args:
            blockchain: 区块链类型
            
        Returns:
            当前时间戳
        """
        try:
            # 实际应通过RPC查询最新区块时间
            logger.debug(f"获取 {blockchain} 当前时间")
            return int(time.time())
        except Exception as e:
            logger.error(f"获取区块链时间失败: {e}")
            return None
    
    def format_timestamp(self, timestamp: int) -> str:
        """
        格式化时间戳
        
        Args:
            timestamp: 时间戳
            
        Returns:
            格式化字符串
        """
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
