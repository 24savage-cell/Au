"""
区块链证明验证器

验证区块链上的锚定证明。
"""

import logging
import hashlib
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class VerificationResult:
    """验证结果"""
    valid: bool
    block_height: Optional[int]
    timestamp: Optional[int]
    confirmations: int
    error_message: Optional[str] = None


class BlockchainProofVerifier:
    """
    区块链证明验证器
    
    验证数据在区块链上的锚定证明。
    """
    
    def __init__(self, min_confirmations: int = 6):
        """
        初始化验证器
        
        Args:
            min_confirmations: 最小确认数
        """
        self.min_confirmations = min_confirmations
        self.cache: Dict[str, VerificationResult] = {}
        logger.info(f"初始化区块链证明验证器: min_confirmations={min_confirmations}")
    
    def verify_transaction(self, tx_hash: str, data_hash: str, 
                          blockchain: str = "ethereum") -> VerificationResult:
        """
        验证交易
        
        Args:
            tx_hash: 交易哈希
            data_hash: 数据哈希
            blockchain: 区块链类型
            
        Returns:
            验证结果
        """
        cache_key = f"{blockchain}:{tx_hash}"
        
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        try:
            logger.info(f"验证交易: {tx_hash} on {blockchain}")
            
            # 查询交易
            tx_info = self._query_transaction(tx_hash, blockchain)
            
            if not tx_info:
                return VerificationResult(
                    valid=False,
                    block_height=None,
                    timestamp=None,
                    confirmations=0,
                    error_message="交易未找到"
                )
            
            # 验证数据哈希
            if not self._verify_data_in_tx(tx_info, data_hash):
                return VerificationResult(
                    valid=False,
                    block_height=tx_info.get("block_height"),
                    timestamp=tx_info.get("timestamp"),
                    confirmations=tx_info.get("confirmations", 0),
                    error_message="数据哈希不匹配"
                )
            
            # 检查确认数
            confirmations = tx_info.get("confirmations", 0)
            valid = confirmations >= self.min_confirmations
            
            result = VerificationResult(
                valid=valid,
                block_height=tx_info.get("block_height"),
                timestamp=tx_info.get("timestamp"),
                confirmations=confirmations,
                error_message=None if valid else f"确认数不足: {confirmations} < {self.min_confirmations}"
            )
            
            self.cache[cache_key] = result
            
            logger.info(f"验证结果: valid={valid}, confirmations={confirmations}")
            return result
            
        except Exception as e:
            logger.error(f"验证失败: {e}")
            return VerificationResult(
                valid=False,
                block_height=None,
                timestamp=None,
                confirmations=0,
                error_message=str(e)
            )
    
    def _query_transaction(self, tx_hash: str, blockchain: str) -> Optional[Dict[str, Any]]:
        """
        查询交易
        
        Args:
            tx_hash: 交易哈希
            blockchain: 区块链类型
            
        Returns:
            交易信息
        """
        # 实际应通过区块链节点查询
        logger.debug(f"查询交易: {tx_hash} on {blockchain}")
        
        # 模拟返回
        return {
            "tx_hash": tx_hash,
            "block_height": 1000000,
            "timestamp": 1609459200,
            "confirmations": 10,
            "data": "0x..."
        }
    
    def _verify_data_in_tx(self, tx_info: Dict[str, Any], data_hash: str) -> bool:
        """
        验证交易中的数据
        
        Args:
            tx_info: 交易信息
            data_hash: 数据哈希
            
        Returns:
            是否匹配
        """
        # 实际应解析交易数据验证
        return True
    
    def verify_merkle_proof(self, merkle_root: str, leaf_hash: str, 
                           proof_path: List[str]) -> bool:
        """
        验证默克尔证明
        
        Args:
            merkle_root: 默克尔根
            leaf_hash: 叶子哈希
            proof_path: 证明路径
            
        Returns:
            是否有效
        """
        try:
            current_hash = leaf_hash
            
            for sibling in proof_path:
                # 按字典序合并哈希
                if current_hash < sibling:
                    combined = current_hash + sibling
                else:
                    combined = sibling + current_hash
                
                current_hash = hashlib.sha256(combined.encode()).hexdigest()
            
            valid = current_hash == merkle_root
            logger.info(f"默克尔证明验证: {valid}")
            return valid
            
        except Exception as e:
            logger.error(f"默克尔证明验证失败: {e}")
            return False
