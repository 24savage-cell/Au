"""
区块链审计锚定模块

提供审计日志的区块链锚定功能，支持多种区块链平台。
"""

from .anchors.ethereum_anchor import EthereumAnchor
from .anchors.bitcoin_anchor import BitcoinAnchor
from .anchors.cosmos_anchor import CosmosAnchor
from .merkle.merkle_tree import MerkleTree
from .merkle.merkle_proof import ProofVerifier, MerkleProof
from .batching.log_batcher import LogBatcher, LogBatch
from .batching.gas_optimizer import GasOptimizer, GasEstimate, GasStrategy
from .verification.proof_verifier import BlockchainProofVerifier, VerificationResult
from .verification.timestamp_verifier import TimestampVerifier, TimestampVerification

__version__ = "1.0.0"
__author__ = "IP4Move Aegis Security Team"

__all__ = [
    # 锚定适配器
    "EthereumAnchor",
    "BitcoinAnchor",
    "CosmosAnchor",
    # 默克尔树
    "MerkleTree",
    "ProofVerifier",
    "MerkleProof",
    # 批处理
    "LogBatcher",
    "LogBatch",
    "GasOptimizer",
    "GasEstimate",
    "GasStrategy",
    # 验证
    "BlockchainProofVerifier",
    "VerificationResult",
    "TimestampVerifier",
    "TimestampVerification",
]
