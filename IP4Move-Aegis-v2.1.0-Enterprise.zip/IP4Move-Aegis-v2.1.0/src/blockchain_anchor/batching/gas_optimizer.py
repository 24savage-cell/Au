"""
Gas优化器

优化区块链交易的Gas费用。
"""

import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class GasStrategy(Enum):
    """Gas策略"""
    FIXED = "fixed"
    DYNAMIC = "dynamic"
    OPTIMAL = "optimal"


@dataclass
class GasEstimate:
    """Gas估算"""
    gas_price: int
    gas_limit: int
    total_cost: int
    estimated_time: int
    strategy: GasStrategy


class GasOptimizer:
    """
    Gas优化器
    
    优化交易Gas费用。
    """
    
    def __init__(self, strategy: GasStrategy = GasStrategy.OPTIMAL):
        """
        初始化Gas优化器
        
        Args:
            strategy: Gas策略
        """
        self.strategy = strategy
        self.gas_prices: List[int] = []
        self.avg_block_time = 12  # 秒
        logger.info(f"初始化Gas优化器: strategy={strategy.value}")
    
    def estimate_gas(self, data_size: int, priority: str = "normal") -> GasEstimate:
        """
        估算Gas
        
        Args:
            data_size: 数据大小
            priority: 优先级 (low/normal/high)
            
        Returns:
            Gas估算
        """
        base_gas = 21000  # 基础交易Gas
        data_gas = data_size * 68  # 每字节数据Gas
        gas_limit = base_gas + data_gas + 10000  # 缓冲
        
        if self.strategy == GasStrategy.FIXED:
            gas_price = 20_000_000_000  # 20 Gwei
        elif self.strategy == GasStrategy.DYNAMIC:
            gas_price = self._get_dynamic_gas_price(priority)
        else:  # OPTIMAL
            gas_price = self._get_optimal_gas_price()
        
        total_cost = gas_price * gas_limit
        estimated_time = self._estimate_time(gas_price)
        
        return GasEstimate(
            gas_price=gas_price,
            gas_limit=gas_limit,
            total_cost=total_cost,
            estimated_time=estimated_time,
            strategy=self.strategy
        )
    
    def _get_dynamic_gas_price(self, priority: str) -> int:
        """
        获取动态Gas价格
        
        Args:
            priority: 优先级
            
        Returns:
            Gas价格
        """
        base_price = 20_000_000_000  # 20 Gwei
        
        if priority == "high":
            return int(base_price * 1.5)
        elif priority == "low":
            return int(base_price * 0.8)
        else:
            return base_price
    
    def _get_optimal_gas_price(self) -> int:
        """
        获取最优Gas价格
        
        Returns:
            Gas价格
        """
        # 基于历史数据计算最优价格
        if self.gas_prices:
            avg_price = sum(self.gas_prices) / len(self.gas_prices)
            return int(avg_price * 1.1)  # 略高于平均
        
        return 20_000_000_000  # 默认20 Gwei
    
    def _estimate_time(self, gas_price: int) -> int:
        """
        估算确认时间
        
        Args:
            gas_price: Gas价格
            
        Returns:
            估算时间（秒）
        """
        # 简化估算
        if gas_price > 30_000_000_000:
            return self.avg_block_time * 1
        elif gas_price > 20_000_000_000:
            return self.avg_block_time * 3
        else:
            return self.avg_block_time * 10
    
    def update_gas_prices(self, prices: List[int]):
        """
        更新Gas价格历史
        
        Args:
            prices: 价格列表
        """
        self.gas_prices = prices[-100:]  # 保留最近100个
        logger.debug(f"更新Gas价格历史: {len(prices)} 个价格")
    
    def get_optimal_anchor_time(self) -> str:
        """
        获取最优锚定时间
        
        Returns:
            最优时间描述
        """
        # 基于历史数据返回最优时间
        return "02:00-06:00 UTC"  # 通常网络拥堵较低
