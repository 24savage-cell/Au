"""
日志批处理

批量处理审计日志以优化区块链锚定。
"""

import logging
import hashlib
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import deque

logger = logging.getLogger(__name__)


@dataclass
class LogBatch:
    """日志批次"""
    batch_id: str
    logs: List[Dict[str, Any]]
    merkle_root: Optional[str]
    created_at: datetime
    anchored: bool = False
    anchor_tx_hash: Optional[str] = None


class LogBatcher:
    """
    日志批处理器
    
    批量收集和处理审计日志。
    """
    
    def __init__(self, max_batch_size: int = 100, max_wait_seconds: int = 60):
        """
        初始化日志批处理器
        
        Args:
            max_batch_size: 最大批次大小
            max_wait_seconds: 最大等待时间（秒）
        """
        self.max_batch_size = max_batch_size
        self.max_wait_seconds = max_wait_seconds
        self.pending_logs: deque = deque()
        self.batches: Dict[str, LogBatch] = {}
        self.last_batch_time = datetime.now()
        logger.info(f"初始化日志批处理器: max_size={max_batch_size}, max_wait={max_wait_seconds}s")
    
    def add_log(self, log_entry: Dict[str, Any]) -> bool:
        """
        添加日志
        
        Args:
            log_entry: 日志条目
            
        Returns:
            是否成功添加
        """
        self.pending_logs.append(log_entry)
        logger.debug(f"添加日志到批次，当前待处理: {len(self.pending_logs)}")
        
        # 检查是否需要立即批处理
        if self._should_batch():
            self.create_batch()
        
        return True
    
    def _should_batch(self) -> bool:
        """
        检查是否应该创建批次
        
        Returns:
            是否应该创建批次
        """
        if len(self.pending_logs) >= self.max_batch_size:
            return True
        
        elapsed = (datetime.now() - self.last_batch_time).total_seconds()
        if elapsed >= self.max_wait_seconds and len(self.pending_logs) > 0:
            return True
        
        return False
    
    def create_batch(self) -> Optional[LogBatch]:
        """
        创建批次
        
        Returns:
            日志批次
        """
        if not self.pending_logs:
            return None
        
        batch_logs = []
        while len(batch_logs) < self.max_batch_size and self.pending_logs:
            batch_logs.append(self.pending_logs.popleft())
        
        batch_id = self._generate_batch_id()
        merkle_root = self._compute_merkle_root(batch_logs)
        
        batch = LogBatch(
            batch_id=batch_id,
            logs=batch_logs,
            merkle_root=merkle_root,
            created_at=datetime.now()
        )
        
        self.batches[batch_id] = batch
        self.last_batch_time = datetime.now()
        
        logger.info(f"创建日志批次: {batch_id}, 包含 {len(batch_logs)} 条日志")
        return batch
    
    def _generate_batch_id(self) -> str:
        """
        生成批次ID
        
        Returns:
            批次ID
        """
        timestamp = datetime.now().isoformat()
        return hashlib.sha256(timestamp.encode()).hexdigest()[:16]
    
    def _compute_merkle_root(self, logs: List[Dict[str, Any]]) -> str:
        """
        计算默克尔根
        
        Args:
            logs: 日志列表
            
        Returns:
            默克尔根哈希
        """
        if not logs:
            return ""
        
        # 计算每条日志的哈希
        hashes = []
        for log in logs:
            log_str = str(log)
            log_hash = hashlib.sha256(log_str.encode()).hexdigest()
            hashes.append(log_hash)
        
        # 构建默克尔树
        while len(hashes) > 1:
            if len(hashes) % 2 == 1:
                hashes.append(hashes[-1])  # 复制最后一个
            
            new_hashes = []
            for i in range(0, len(hashes), 2):
                combined = hashes[i] + hashes[i + 1]
                new_hash = hashlib.sha256(combined.encode()).hexdigest()
                new_hashes.append(new_hash)
            
            hashes = new_hashes
        
        return hashes[0]
    
    def get_pending_batch(self) -> Optional[LogBatch]:
        """
        获取待处理的批次
        
        Returns:
            待处理的批次
        """
        for batch in self.batches.values():
            if not batch.anchored:
                return batch
        return None
    
    def mark_anchored(self, batch_id: str, tx_hash: str) -> bool:
        """
        标记批次已锚定
        
        Args:
            batch_id: 批次ID
            tx_hash: 交易哈希
            
        Returns:
            是否成功标记
        """
        if batch_id not in self.batches:
            return False
        
        batch = self.batches[batch_id]
        batch.anchored = True
        batch.anchor_tx_hash = tx_hash
        
        logger.info(f"批次已锚定: {batch_id}, tx_hash={tx_hash}")
        return True
    
    def get_batch(self, batch_id: str) -> Optional[LogBatch]:
        """
        获取批次
        
        Args:
            batch_id: 批次ID
            
        Returns:
            日志批次
        """
        return self.batches.get(batch_id)
