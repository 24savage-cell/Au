"""
默克尔树实现

支持增量构建、根计算和叶子管理。
"""

import hashlib
import logging
from typing import List, Optional, Tuple
from dataclasses import dataclass

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class MerkleNode:
    """默克尔树节点"""
    hash: str
    left: Optional['MerkleNode'] = None
    right: Optional['MerkleNode'] = None
    is_leaf: bool = False
    leaf_index: int = -1
    
    def __repr__(self) -> str:
        return f"MerkleNode(hash={self.hash[:16]}..., leaf={self.is_leaf})"


class MerkleTree:
    """
    默克尔树
    
    用于高效验证大量数据的完整性。
    """
    
    def __init__(self, hash_function: str = "sha256"):
        """
        初始化默克尔树
        
        Args:
            hash_function: 哈希函数名称
        """
        self.hash_function = hash_function
        self.leaves: List[MerkleNode] = []
        self.root: Optional[MerkleNode] = None
        self.layers: List[List[MerkleNode]] = []
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"初始化默克尔树，使用 {hash_function}")
    
    def _hash(self, data: bytes) -> str:
        """计算哈希"""
        if self.hash_function == "sha256":
            return hashlib.sha256(data).hexdigest()
        elif self.hash_function == "sha512":
            return hashlib.sha512(data).hexdigest()
        else:
            return hashlib.sha256(data).hexdigest()
    
    def _hash_pair(self, left: str, right: str) -> str:
        """哈希两个子节点"""
        combined = bytes.fromhex(left) + bytes.fromhex(right)
        return self._hash(combined)
    
    def add_leaf(self, data: bytes) -> int:
        """
        添加叶子节点
        
        Args:
            data: 叶子数据
            
        Returns:
            叶子索引
        """
        leaf_hash = self._hash(data)
        node = MerkleNode(
            hash=leaf_hash,
            is_leaf=True,
            leaf_index=len(self.leaves)
        )
        self.leaves.append(node)
        
        self.logger.debug(f"添加叶子 {node.leaf_index}: {leaf_hash[:16]}...")
        return node.leaf_index
    
    def add_leaves(self, data_list: List[bytes]) -> List[int]:
        """
        批量添加叶子节点
        
        Args:
            data_list: 数据列表
            
        Returns:
            叶子索引列表
        """
        indices = []
        for data in data_list:
            idx = self.add_leaf(data)
            indices.append(idx)
        return indices
    
    def build(self) -> str:
        """
        构建默克尔树
        
        Returns:
            根哈希
        """
        if not self.leaves:
            self.logger.warning("没有叶子节点")
            return ""
        
        self.layers = [self.leaves[:]]  # 复制叶子层
        
        current_layer = self.leaves[:]
        
        while len(current_layer) > 1:
            next_layer = []
            
            # 如果节点数为奇数，复制最后一个
            if len(current_layer) % 2 == 1:
                current_layer.append(current_layer[-1])
            
            # 两两配对创建父节点
            for i in range(0, len(current_layer), 2):
                left = current_layer[i]
                right = current_layer[i + 1]
                
                parent_hash = self._hash_pair(left.hash, right.hash)
                parent = MerkleNode(
                    hash=parent_hash,
                    left=left,
                    right=right
                )
                next_layer.append(parent)
            
            self.layers.append(next_layer)
            current_layer = next_layer
        
        self.root = current_layer[0]
        
        self.logger.info(f"构建完成，根哈希: {self.root.hash[:16]}...")
        return self.root.hash
    
    def get_root(self) -> Optional[str]:
        """获取根哈希"""
        if self.root:
            return self.root.hash
        return None
    
    def get_leaf_hash(self, index: int) -> Optional[str]:
        """获取叶子哈希"""
        if 0 <= index < len(self.leaves):
            return self.leaves[index].hash
        return None
    
    def update_leaf(self, index: int, new_data: bytes) -> str:
        """
        更新叶子节点
        
        Args:
            index: 叶子索引
            new_data: 新数据
            
        Returns:
            新的根哈希
        """
        if index < 0 or index >= len(self.leaves):
            raise ValueError(f"无效的叶子索引: {index}")
        
        # 更新叶子哈希
        new_hash = self._hash(new_data)
        self.leaves[index].hash = new_hash
        
        self.logger.info(f"更新叶子 {index}: {new_hash[:16]}...")
        
        # 重新构建树
        return self.build()
    
    def get_proof(self, index: int) -> List[Tuple[str, str]]:
        """
        获取默克尔证明
        
        Args:
            index: 叶子索引
            
        Returns:
            证明路径 [(兄弟哈希, 方向), ...]
        """
        if not self.layers:
            raise ValueError("树未构建")
        
        if index < 0 or index >= len(self.leaves):
            raise ValueError(f"无效的叶子索引: {index}")
        
        proof = []
        current_idx = index
        
        for layer in self.layers[:-1]:  # 不包括根层
            # 如果当前层节点数为奇数，最后一个节点已复制
            layer_size = len(layer)
            if layer_size % 2 == 1:
                layer = layer + [layer[-1]]
            
            # 确定兄弟节点
            if current_idx % 2 == 0:
                sibling_idx = current_idx + 1
                direction = "right"  # 兄弟在右边
            else:
                sibling_idx = current_idx - 1
                direction = "left"   # 兄弟在左边
            
            if sibling_idx < len(layer):
                proof.append((layer[sibling_idx].hash, direction))
            
            current_idx //= 2
        
        return proof
    
    def verify_proof(
        self,
        leaf_hash: str,
        proof: List[Tuple[str, str]],
        root_hash: str
    ) -> bool:
        """
        验证默克尔证明
        
        Args:
            leaf_hash: 叶子哈希
            proof: 证明路径
            root_hash: 期望的根哈希
            
        Returns:
            验证结果
        """
        current_hash = leaf_hash
        
        for sibling_hash, direction in proof:
            if direction == "right":
                current_hash = self._hash_pair(current_hash, sibling_hash)
            else:
                current_hash = self._hash_pair(sibling_hash, current_hash)
        
        return current_hash == root_hash
    
    def get_tree_info(self) -> dict:
        """获取树信息"""
        return {
            "leaf_count": len(self.leaves),
            "layer_count": len(self.layers),
            "root_hash": self.root.hash if self.root else None,
            "hash_function": self.hash_function
        }


# 便捷函数
def create_merkle_tree(hash_function: str = "sha256") -> MerkleTree:
    """创建默克尔树"""
    return MerkleTree(hash_function)


if __name__ == "__main__":
    # 测试代码
    print("=" * 50)
    print("默克尔树测试")
    print("=" * 50)
    
    tree = MerkleTree()
    
    # 添加数据
    data = [b"data1", b"data2", b"data3", b"data4"]
    indices = tree.add_leaves(data)
    print(f"\n1. 添加 {len(data)} 个叶子节点")
    print(f"   索引: {indices}")
    
    # 构建树
    root = tree.build()
    print(f"\n2. 构建默克尔树")
    print(f"   根哈希: {root}")
    
    # 获取证明
    print(f"\n3. 生成默克尔证明:")
    for i in range(len(data)):
        proof = tree.get_proof(i)
        print(f"   叶子 {i} 的证明路径长度: {len(proof)}")
    
    # 验证证明
    print(f"\n4. 验证证明:")
    leaf_hash = tree.get_leaf_hash(0)
    proof = tree.get_proof(0)
    is_valid = tree.verify_proof(leaf_hash, proof, root)
    print(f"   叶子 0 验证结果: {is_valid}")
    
    # 更新叶子
    print(f"\n5. 更新叶子:")
    new_root = tree.update_leaf(1, b"new_data2")
    print(f"   新根哈希: {new_root}")
    
    print("\n测试完成!")
