"""
默克尔证明

提供默克尔证明的生成和验证功能。
"""

import logging
import hashlib
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class MerkleProof:
    """默克尔证明"""
    leaf_hash: str
    proof_path: List[str]
    proof_indices: List[int]
    root_hash: str
    valid: bool = False


class ProofVerifier:
    """
    证明验证器
    
    验证默克尔证明的有效性。
    """
    
    def __init__(self):
        """初始化证明验证器"""
        self.verified_proofs: Dict[str, bool] = {}
        logger.info("初始化证明验证器")
    
    def verify_proof(self, proof: MerkleProof) -> bool:
        """
        验证默克尔证明
        
        Args:
            proof: 默克尔证明
            
        Returns:
            是否有效
        """
        try:
            logger.debug(f"验证默克尔证明: leaf={proof.leaf_hash}")
            
            current_hash = proof.leaf_hash
            
            for i, sibling_hash in enumerate(proof.proof_path):
                index = proof.proof_indices[i]
                
                if index == 0:
                    # 当前节点在左边
                    current_hash = self._hash_pair(current_hash, sibling_hash)
                else:
                    # 当前节点在右边
                    current_hash = self._hash_pair(sibling_hash, current_hash)
            
            valid = current_hash == proof.root_hash
            proof.valid = valid
            
            self.verified_proofs[proof.leaf_hash] = valid
            
            logger.info(f"默克尔证明验证结果: {valid}")
            return valid
            
        except Exception as e:
            logger.error(f"证明验证失败: {e}")
            return False
    
    def _hash_pair(self, left: str, right: str) -> str:
        """
        哈希两个节点
        
        Args:
            left: 左节点哈希
            right: 右节点哈希
            
        Returns:
            父节点哈希
        """
        combined = left + right
        return hashlib.sha256(combined.encode()).hexdigest()
    
    def batch_verify(self, proofs: List[MerkleProof]) -> Dict[str, bool]:
        """
        批量验证证明
        
        Args:
            proofs: 证明列表
            
        Returns:
            验证结果字典
        """
        results = {}
        for proof in proofs:
            results[proof.leaf_hash] = self.verify_proof(proof)
        return results
    
    def is_verified(self, leaf_hash: str) -> bool:
        """
        检查是否已验证
        
        Args:
            leaf_hash: 叶子哈希
            
        Returns:
            是否已验证
        """
        return self.verified_proofs.get(leaf_hash, False)
